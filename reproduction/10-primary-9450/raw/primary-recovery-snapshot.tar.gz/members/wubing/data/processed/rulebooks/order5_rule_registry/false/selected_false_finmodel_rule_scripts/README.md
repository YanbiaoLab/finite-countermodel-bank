# selected_false_finmodel_rule_scripts

这个目录整理了当前项目中已经发现的 finite model false witnesses，并把主要 witness model 导出成可以独立运行的 Python setcheck 脚本。

目标是给每个有代表性的 finite magma model 一个自包含 checker：输入一个有向 equation pair `(source_eq_id, target_eq_id)`，脚本可以快速判断该 model 是否证明这个 pair 为 `False`，并可以输出对应的 Lean finite-model certificate 模板。

## 当前核心结论

当前全量无重复有向 false pair 数为：

```text
9,722,317
```

历史 witness 明细中，覆盖这些 pair 的去重 finite model 数为：

```text
229,666
```

其中，在 primary 归属口径下，真正贡献非零 primary pair 的 model 数为：

```text
9,452
```

本目录已为其中：

```text
9,450 个 model
```

生成独立 setcheck `.py` 文件。

有 `2` 个 primary 非零 model 因为无法从对应 `models.jsonl.gz` 中取回 model table，被跳过。这个限制记录在：

```text
primary_nonzero_model_generation_summary.json
```

## 目录结构

```text
selected_false_finmodel_rule_scripts/
├── README.md
├── SELF_CONTAINED_NOTE.md
├── false_model_primary_coverage_9722317.md
├── false_model_primary_coverage_9722317.csv
├── false_model_coverage_9722317.csv
├── primary_nonzero_model_generation_summary.json
├── primary_nonzero_model_index.csv
├── primary_nonzero_model_scripts/
│   ├── 00001_affine_n9_micro_orbit_probe_n9_idx67003_23168725ed.py
│   ├── 00002_affine_n9_micro_orbit_probe_n9_idx37096_60f5b2ce0d.py
│   └── ...
├── false_finmodel_setcheck_fin2_and_all_equations_v1.py
├── false_finmodel_setcheck_fin2_left_projection_all_equations_v1.py
├── false_finmodel_setcheck_fin3_addition_mod3_all_equations_v1.py
├── false_finmodel_setcheck_fin3_table_000_110_222_all_equations_v1.py
├── false_finmodel_setcheck_fin4_table_0231_3102_1320_2013_all_equations_v1.py
└── false_finmodel_setcheck_structured_affine_mod5_a0_b1_c4_all_equations_v1.py
```

## Pair 方向

所有 pair 都是有向的：

```text
(source_eq_id, target_eq_id)
```

含义是：

```text
找一个 finite magma model M，使得：
M 满足 source_eq_id 对应等式，
但 M 不满足 target_eq_id 对应等式。
```

记作：

```text
M ⊨ source_eq
M ⊭ target_eq
```

因此 `(3, 1)` 和 `(1, 3)` 是不同问题。

这里的 equation id 是 `1`-based，对应仓库根目录 `equations.txt` 的行号。

## 单个 setcheck 脚本包含什么

每个生成的 `.py` 文件都内嵌一个 `RULE`：

```python
RULE = {
    "model_table": ...,
    "source_bits_payload": ...,
    "target_bits_payload": ...,
    "model_key": ...,
    "primary_unique_false_pairs": ...,
    ...
}
```

核心字段：

| 字段 | 含义 |
|---|---|
| `model_table` | finite magma 的乘法表 |
| `model_order` | finite magma 的底集大小 `n` |
| `model_family` | witness family 名称 |
| `model_idx` | 该 family/source output 内的 model 编号 |
| `model_key` | `family|n=...|idx=...` 形式的 key |
| `source_bits_payload` | 该 model 满足哪些 equation 的 bitset，zlib+base64 压缩 |
| `target_bits_payload` | 该 model 不满足哪些 equation 的 bitset，zlib+base64 压缩 |
| `source_count` | 满足的 equation 数量 |
| `target_count` | 不满足的 equation 数量 |
| `primary_unique_false_pairs` | primary 口径下该 model 贡献的无重复有向 false pair 数 |
| `source_output_dir` | 该 model 来源的历史输出目录 |

## 为什么需要 source/target bitset

脚本需要快速回答：

```python
covers_pair(source_id, target_id)
```

判定条件是：

```text
source_id in source_bits
and target_id in target_bits
```

也就是：

```text
M ⊨ source_id
M ⊭ target_id
```

如果不预存 bitset，每次查询 pair 都要重新用 model table evaluate equation，速度会慢很多。

当前脚本把 bitset 直接压缩嵌入 `.py` 文件，因此单个 `.py` 是自包含的。

## 如何使用单个脚本

查看 metadata：

```bash
python selected_false_finmodel_rule_scripts/primary_nonzero_model_scripts/00001_affine_n9_micro_orbit_probe_n9_idx67003_23168725ed.py --metadata
```

检查某个有向 pair 是否被该 model cover：

```bash
python selected_false_finmodel_rule_scripts/primary_nonzero_model_scripts/00001_affine_n9_micro_orbit_probe_n9_idx67003_23168725ed.py \
  --source-id 10 \
  --target-id 51176
```

如果 cover，会输出 JSON：

```json
{
  "verdict": "false",
  "source_id": 10,
  "target_id": 51176,
  "rule_id": "...",
  "rule": {"...": "..."},
  "code": "... Lean certificate ..."
}
```

如果不 cover，会输出：

```json
null
```

直接输出 Lean certificate 模板：

```bash
python selected_false_finmodel_rule_scripts/primary_nonzero_model_scripts/00001_affine_n9_micro_orbit_probe_n9_idx67003_23168725ed.py
```

## Lean certificate 的形式

对小模型，脚本输出大致如下形式：

```lean
import JudgeProblem
import JudgeDecide.DecideBang
import JudgeFinOp.MemoFinOp
set_option maxRecDepth 1000000
open MemoFinOp

def submission : Goal := by
  let m : Magma (Fin n) := {
    op := finOpTable "[[...], ...]"
  }
  refine ⟨Fin n, m, ?_⟩
  decideFin!
```

对 `n >= 10` 的模型，脚本会用 Lean pattern matching 显式定义乘法表。

## 重要 CSV 文件

### `primary_nonzero_model_index.csv`

这是生成脚本的索引表。

字段：

| 字段 | 含义 |
|---|---|
| `rank` | 按 primary pair 数排序的 rank |
| `script_path` | 对应 `.py` 文件路径 |
| `witness_family` | model family |
| `witness_n` | model order |
| `witness_model_idx` | model idx |
| `model_key` | 去重 model key |
| `primary_unique_false_pairs` | primary 口径贡献数 |
| `source_count` | 该 model 满足的 equation 数 |
| `target_count` | 该 model 不满足的 equation 数 |
| `source_output_dir` | 来源目录 |

### `false_model_primary_coverage_9722317.csv`

229,666 个 model 的 primary 口径统计。

在 primary 口径下，每个 false pair 只归属给第一个命中的 model。因此：

```text
sum(primary_unique_false_pairs) = 9,722,317
```

其中 primary 非零的 model 数是：

```text
9,452
```

### `false_model_coverage_9722317.csv`

229,666 个 model 的 coverage 口径统计。

在 coverage 口径下，同一个 pair 可以被多个 model 同时 cover，因此：

```text
sum(covered_final_false_pairs) = 181,011,287
```

这个数大于 `9,722,317`，因为存在大量重复覆盖。

## Primary 口径 vs Coverage 口径

### Primary 口径

```text
每个 false pair 只归给一个 model。
```

优点：

```text
所有 model 的贡献数可以相加，合计等于全量无重复 false pair 数。
```

当前：

```text
9,452 个 primary 非零 model 覆盖 9,722,317 个无重复有向 false pair。
```

### Coverage 口径

```text
每个 model 统计它能 cover 多少 final false pair。
```

如果一个 pair 被 10 个 model cover，那么 coverage 口径会计 10 次。

当前：

```text
229,666 个 model 的 coverage 合计为 181,011,287。
```

## 当前生成摘要

生成摘要文件：

```text
primary_nonzero_model_generation_summary.json
```

当前内容：

```json
{
  "selected_nonzero_models": 9452,
  "generated_scripts": 9450,
  "missing_models": 0,
  "skipped": 2,
  "output_dir": "selected_false_finmodel_rule_scripts/primary_nonzero_model_scripts",
  "index_csv": "selected_false_finmodel_rule_scripts/primary_nonzero_model_index.csv"
}
```

解释：

- `selected_nonzero_models = 9452`：primary 非零 model 总数。
- `generated_scripts = 9450`：成功生成独立 `.py` 的数量。
- `missing_models = 0`：所有 selected model 都找到了候选来源目录。
- `skipped = 2`：有 2 个 model 在候选目录中没有成功取到 `model_table`，因此未生成脚本。

## 自包含性

生成的 `.py` 文件本身是自包含的。

单个脚本不依赖：

```text
models.jsonl.gz
equation_signature_groups.csv
false_pairs.csv.gz
```

因为它已经内嵌：

```text
model_table
source_bits_payload
target_bits_payload
```

如果只给老师看脚本和索引，建议至少包含：

```text
selected_false_finmodel_rule_scripts/README.md
selected_false_finmodel_rule_scripts/SELF_CONTAINED_NOTE.md
selected_false_finmodel_rule_scripts/primary_nonzero_model_index.csv
selected_false_finmodel_rule_scripts/primary_nonzero_model_scripts/
```

为了保留统计背景，也建议包含：

```text
selected_false_finmodel_rule_scripts/false_model_primary_coverage_9722317.csv
selected_false_finmodel_rule_scripts/false_model_coverage_9722317.csv
selected_false_finmodel_rule_scripts/false_model_primary_coverage_9722317.md
```

## 手工挑选的 6 个 setcheck 脚本

目录根部还有 6 个手工挑选/高覆盖 finite model 脚本：

```text
false_finmodel_setcheck_fin2_and_all_equations_v1.py
false_finmodel_setcheck_fin2_left_projection_all_equations_v1.py
false_finmodel_setcheck_fin3_addition_mod3_all_equations_v1.py
false_finmodel_setcheck_fin3_table_000_110_222_all_equations_v1.py
false_finmodel_setcheck_fin4_table_0231_3102_1320_2013_all_equations_v1.py
false_finmodel_setcheck_structured_affine_mod5_a0_b1_c4_all_equations_v1.py
```

这些脚本和自动生成脚本格式基本一致，也都是自包含 finite-model false checker。

## 当前目录规模

当前目录大小约：

```text
56M
```

文件数约：

```text
9460
```

其中主要是 `primary_nonzero_model_scripts/*.py`。
