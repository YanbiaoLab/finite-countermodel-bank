# 自包含说明

`selected_false_finmodel_rule_scripts` 目录目前包含：

- 6 个手工挑选 finite model setcheck 脚本。
- `primary_nonzero_model_scripts/`：自动生成的 primary 非零 finite model setcheck 脚本。
- `primary_nonzero_model_index.csv`：自动生成脚本索引。
- `primary_nonzero_model_generation_summary.json`：生成摘要。
- `false_model_primary_coverage_9722317.csv`：229,666 个 model 的 primary 归属统计。
- `false_model_coverage_9722317.csv`：229,666 个 model 的 coverage 统计。
- 若干 README/说明文档。

## 脚本是否自包含

`primary_nonzero_model_scripts/*.py` 每个脚本都内嵌：

- `model_table`
- `source_bits_payload`
- `target_bits_payload`
- `model_key`
- `primary_unique_false_pairs`
- `source_output_dir` provenance

因此单个 `.py` 文件可以独立执行：

```bash
python primary_nonzero_model_scripts/00001_affine_n9_micro_orbit_probe_n9_idx67003_23168725ed.py --metadata
python primary_nonzero_model_scripts/00001_affine_n9_micro_orbit_probe_n9_idx67003_23168725ed.py --source-id 10 --target-id 51176
```

不需要读取原始 `models.jsonl.gz` 或 `equation_signature_groups.csv`。

## 当前生成状态

从 `9,452` 个 primary 非零 model 中，成功生成：

```text
9,450 个独立 setcheck py 脚本
```

有 2 个 model 被 skipped，原因是可以定位到统计记录，但在对应 `models.jsonl.gz` 中没有取到 model table。它们没有影响已生成脚本的自包含性。

## 目录规模

当前目录约：

```text
56M
```
