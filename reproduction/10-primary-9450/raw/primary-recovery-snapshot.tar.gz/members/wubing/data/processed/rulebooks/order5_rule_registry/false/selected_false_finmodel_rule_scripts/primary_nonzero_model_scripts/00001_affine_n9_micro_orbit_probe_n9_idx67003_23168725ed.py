from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1343256,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n9_micro_orbit_probe","model_idx":67003,"model_key":"affine_n9_micro_orbit_probe|n=9|idx=67003","model_order":9,"model_table":[[0,7,5,2,6,4,1,8,3],[3,1,8,5,0,7,4,2,6],[6,4,2,8,3,1,7,5,0],[4,2,6,3,1,8,5,0,7],[7,5,0,6,4,2,8,3,1],[1,8,3,0,7,5,2,6,4],[8,3,1,7,5,0,6,4,2],[2,6,4,1,8,3,0,7,5],[5,0,7,4,2,6,3,1,8]],"primary_rank":1,"primary_unique_false_pairs":1343256,"rule_id":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx67003.v1","rule_key":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx67003","source_bits_payload":"eNqtWVtu5SAMBcQH/aOzAuuqC/FI/eiyrEoj3WVP3kBsAwlxq7YXCMGPc2zcfwbN/D2LNybMH5aPX8vQMQPmmPHr2Ly2FDjWp0Wr2OlrE1dM/KTl8TOfwLSnCcUzTtpnlmjomKB8gta3R35onz9dqIJptFTlY9/TmJcTVPHsXIjp7/L1TjBicRg870iLMSX1/brOswmwyrk2n4BszWN+P6L329qzhNJjxLWJ2W7cxbckZB4rd3YuG0PlSBdFjd8UpNxud2Vz2KwffkuWLmQKQkE9lONJEJ/0ItB8u8vf+l5NIaP6g7YQY0C/LyohrC8kZjCqI6Uuzh/7nO3ozkNhGuLqXVAY64c7sQAqyO0GW0yxYtmRT8w5KRcqlNYWlWGFkPz25hGwRZlikIOtTFOZ/XsUzAKcmjxiNchfAJsSUiAf2NsRsKnELmSYMOg2twYjVQjtbvhJYEMFaRB1896VH43YScnRHAPU+MyDlxO7lLN5MZaZ1u7LdVPD6h4vuwfv06GW2Ug0ACoRNQq2Q/fC/wDMkNBM2H2Zrc4wxclGQvLXBBT9BscPSno4GIIEbtU6ycD2RYTZGZqWo747K4RYQ0bkLhqCthXK8yo0RypJ0OsBeJ61fBEDLTMPZm3KYsC2UgDgII9EIC1lsSsRTueKrIykC1nvTzVCYmHId7BjVxt06rkiZ+BJVXg1rhE3wRZ42NjBG+JHWSrUqXZSjd49VUeljHRi7gtClL5cq6avy1c6T2wBefjuO23gg6w9MMePg21Fj0ORjs55PBg/dmdzGv1hs8q9UUZOmXQPCH9WiJ5k4/U1e+FBXIlonhVbRwiygmikugO1zxgLOnOpIHL3weDTO4JEepYpiD2bKmDzaYtPK3Z7ngnGYoNg1tBsnnLojU4PEZZH4ygGMK/o3ZlE6OHw3zKbADZ/vbjvBhvzEPESdbQ/UumEu0fSi5rZ3qHnzuY7AsHUwYaNHpOesy9xWF66lQ9a2GvGIrONNkhCf+tn8KqB2a/TBTTwGEQpLn0/R26t/wVsVBJT4KoF0+XeCtiscmOfx2JYtrPZ0LliucKZYNXoAqlAHm6QKOawvIsx2pGhXC1O9sG0mlhXMxso2I7cm6OW3Jr5ju2zEPLSJIzJePJ/kLrhXrmzIbfa3By0A72mkCwUBfLDU6OI2fYCrif5DysyS+8=","source_count":624,"source_output_dir":"organized/mining_outputs/out_exp106a_affine_n9_micro_orbit_probe","target_bits_payload":"eNqtWVtu5SAMXfaVRhp5Wf2oNF5IdcUKpvzVHwho3kBsAwlxq7YXCMGPc2zcPxHj/D2Li5HmD8vHr2XomDHxmHHr2Ly2FHOsT4tWCdPXJr6Y+EjL7Xc+gWnPSMUzXtpnFhvhmIB8Ata3W35olz9dqIJptFTlZ98zxrcXVHHsXIjp7/L1XjBicRg87wiLMSX13brOsQkTlHNtPjGyNY/5/YjObWvPQqXHgGtjs924i28JZR4rd/Y+G0PlSBdFjd8UpNxud2Vz2KwffkqWLmQKQkE9lONJEJf0AqP5dpd/9b2aAlH1B2whxoB+X1RCWF8IzGBQR0pdvDv2OdvRn4doGuLqXVAY64c7sQAqyO0Gm02xEtiRT8w5KUcVSmuLyrBCSH66+AjYrEwxyMFWpqnM/j0KZgEOTR4JGuQvgE0JKSMf2IURsKnELmQYGnSbX4MRKoR2N/wksKGCNGN1896VD43YQcnRHAPQ+MyDlxO7lLN5MZaZNuzLdVOb1T1Odg/ep0Mts4FoAFQiahRsh+6F/41hhjTNhN2X2eoMU5xsJCT/RkLRb+b4AUkPb4YggVu1DjKwXRFhYYZm4Kjvzgpka8iw3EVD0A5CeV6F5kglafR6wDzPWq6IgZaZB7M2ZDEQWinA4CCPWANaymJXIpzOZVkZCRey3v9qhNjCkC8KY1cb9Oq5LGfgSVXzblwjboKNeNiEwRviT1kq1Kl2Ug1ePVVHpYz0Yu4jIUrfvlXT1+Urnce2gDx89502cCRrb5jjx8G2osejSEfnPE7Rjd3ZvEZ/2Kxyb5SRUybdA8KdFYIn2Xh9zV54AFfCxmcl1BGCrCAaqe6M2me0BZ35VBD5+2Bw6R0kkV5gCmLPpgrYXNriO4jdnmeCsdiA4hqazVMOvdHrIcLyqB3FAOYVvT+TCDwc/ltmE8Dmrhf33WBjHgJeoo72RyqdcP9IelEz24t67myuIxBiHWzY6DHpOfsSh+WlW/lgMHvNWGS20QYJ9bd+Bq8amP06XUCJxyBKcen6OXJr/S9gg5KYiKtGscu9FbAF5cY+j1latgvZ0LliucKZJqjRZaQCebhBopgj8C7GaEcGcrU42VNsNbGuZjajYNtyb45acmvme7bPQshLk9Am48n/QeqGe+XOhtxqc3MwDPSaKFnICuSHp0YRs+0FXE/yCyFOJUc=","target_count":61952}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
