from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1299652,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n9_micro_orbit_probe","model_idx":37096,"model_key":"affine_n9_micro_orbit_probe|n=9|idx=37096","model_order":9,"model_table":[[0,7,5,8,3,1,4,2,6],[3,1,8,2,6,4,7,5,0],[6,4,2,5,0,7,1,8,3],[7,5,0,3,1,8,2,6,4],[1,8,3,6,4,2,5,0,7],[4,2,6,0,7,5,8,3,1],[5,0,7,1,8,3,6,4,2],[8,3,1,4,2,6,0,7,5],[2,6,4,7,5,0,3,1,8]],"primary_rank":2,"primary_unique_false_pairs":1299652,"rule_id":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx37096.v1","rule_key":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx37096","source_bits_payload":"eNqtWWuO7SAIVsIPfrIEl8LszExy933nWE9tC9gHNZNOjloQ4ePVf0nS5y+nlDBxaj9S+5G2P0r7IXXd1l7h9l5K0J4l1favv7QZy66qF6j/5+NC3/phW/cr0NdxWR2DFcM+qjk7hBzHWEchZyH97M6nRdFvCPczqxOAlvsrithc6ld+cERBOB6hjHWxtFIaLVInOAqGlmrHNupG1KYyb1kbknDSijXU7w9aiBM7qzti9fv4O2G29tIJN9d+myIINW/2SFV/aa8w6w5ka7QDDjk9HzjIkAYaVcW/eJTgiCpL+H45WXFjbQ9tikzN1q39eNpzHUIzG/aO/3CAJ32t9iEjDOXo2obQ5FhvYBDMT5xvw3c2fuY0ygna743iEV3mcrbiyHOw5ZLsiJdJWX/tYXeuQJqBDWdCwxEsIa31kEXOCXXo2ecONxUKyx59MS1CtUf96qsa2+iO0Yhr6qiPSxgFWydtB+zqZDBzhJxFNsu0izLSEsVA8bK9BDbtEDec+lmp03hxd9SNrUBJc2ePEnT/PAdKhlcdMgBPTAtkNytB8xf/ZkRRJ3oHbJZo7MH9+cjdO6CJw73YUoLMytYy6cwgOMgNF6Ewr7TJvbi6VlhswxZPwZbbbRUHh+D6gkdgQ57kfC1Mx+9vV09MHBopLUY4C7tuxEgjSVLoYgm8OAqfZKC85/o3aaSGtmUiHAZb8fJxPR3Ox9GvmbQwUW6flgM4+sjH6eHeOD2K5vwXG2FpSSwPUjnxNc1d0ujvsg1SulidBWu2/C2pyYg48FZN0wk0tGa2rUfSqyMPqigqIUq7qWhgm/QZl2vbdWDwJbBBvlr8YgxsU9Tu7o45iG8el1ZmfubNBonRuE16Kmz+4iukqpIw3iBxnU6r4uRpdTa3OKWQ1qDU3chYzeb2tcGwXiwxr4n5ekfJCAb3PFt1w5LVw6VogwSrc0SvD1JCYGPPgzjFIYbANvJ+ON5aPVynnLuaE7CVtchtD1w/ftC1XtKd7k/eqEJOCrTPVD3a2J3UsmwOjWfGkKN5K7ptpaz421+JLjX9Rxrp2PmlL0Z3I5s4RC59MXoU2VqKgNohWxUeKsUfZnI5iWyWYxdnN17bNrmXzGrTtS9GaGRmvt3+B8MjS5c=","source_count":598,"source_output_dir":"organized/mining_outputs/out_exp106a_affine_n9_micro_orbit_probe","target_bits_payload":"eNqtWWuO7SAI3vdNJu5sWIpL4Cc/CHrnWE9tC9gHNZNOjloQ4ePVfxXq56/UWrlibT9q+1G3P3L7AWnd1l7B9l6t0p65pvavv7QZy66kF6j/x+NC3/phm/Yr0td5WR0DFcM+kjk7hBzHWEcmZ6H+7s6nRdFvAPYzqxOIlvsrCthc0ld+cURhOR4hj3WwtJIbLVInOArGlmrHNupG1KYKblkbkmDVijXU7w9aiBM6qzti6fv4O2Gx9tIJN9d+myKINW/0SCV/aa8w6w5ga7QDDqU+HzzIkAYaJcU/e5TkiCpL+H45RXFDbQ9tikzNpq39eNpzHUIzG/SO/3CIJ31K9iEjDOHo2obQ5FhvYJDMT1xuw3c2fuc08gna743sEV3mSrHiyHOwlVztiFdIWX/qYXeuQJqBjWdCyxEsIa31kEXOCXXo2ecONxUqyx59MS1CtUf66isZ2+iO0YBr6qyPSxwFWydtB+zkZDBzhJxFNsu0szLSHMVA9rK9KjbtEDee+llI03hxd6SNrUiuc2fPEHT/OAdKkVcdsghOTEtgNwtB8wf/ZkBRJ3oHbJZo6MH9+SjdO7CJw73YkIPM8tYy6cwgMMiNF6G4rLTJvbi0Vlhow5ZPwVbabWUHh+L6gkdgY5zkfC1Mx+9vV09MHBopLUY4A7puxEgjCWroYkm8OCqfZCC/5/o3aaSGtmUiGAZb9vJxPR3Ox9mvmbQwUW6floM4+ijH6eHesD6K5vgXG2VpSSwPUjnxNc1d0ujPsk1qvVidBWu28i2pyYg48lZN0wk0tBa0rQfqq6MMqgwqIaq7qWhgm/QZl2vbdWD4JbBJuVr8cgxsU9Tu7g4xiG8cl5ZnfubNBonRuK16Kmz+4CskqZIw3iBxnU6r4uBpdTa3OKWQ1qDU3chYzeb2tcWwXs4xr8nlekfJCAb3PFtyw5LVw6Vog4STc0SvD5JDYEPPgzjFIYfANvJ+Od5aOlwnnLuaE7DltchtD14/ftC1XtKd7k/ZqAJOCrTPVDra2J3UMm8OzWfGUKJ5K7ttpaL421+JLjX9Rxrp2PmlL0Z3Ixs4RC59MXoU2VqKwNohWxUeK8UfZko+iWyWYwdnN1/bNrmXgmrTtS9GbGRmvt3+B4lOJZ8=","target_count":61978}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
