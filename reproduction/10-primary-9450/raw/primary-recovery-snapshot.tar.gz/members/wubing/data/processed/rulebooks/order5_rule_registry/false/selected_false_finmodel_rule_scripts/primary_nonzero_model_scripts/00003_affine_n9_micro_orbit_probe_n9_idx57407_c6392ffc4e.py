from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1298479,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n9_micro_orbit_probe","model_idx":57407,"model_key":"affine_n9_micro_orbit_probe|n=9|idx=57407","model_order":9,"model_table":[[0,4,8,5,6,1,7,2,3],[6,1,5,2,3,7,4,8,0],[3,7,2,8,0,4,1,5,6],[1,5,6,3,7,2,8,0,4],[7,2,3,0,4,8,5,6,1],[4,8,0,6,1,5,2,3,7],[2,3,7,4,8,0,6,1,5],[8,0,4,1,5,6,3,7,2],[5,6,1,7,2,3,0,4,8]],"primary_rank":3,"primary_unique_false_pairs":1298479,"rule_id":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx57407.v1","rule_key":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx57407","source_bits_payload":"eNq1WUuO5CAMBcTCSx+Bo7h3cyzPSCP1so885AsBG0jBoFaqU6HAn/f8IX8Nme1vG36/Xjd2v8HzSdinUZqWzz1HOD8gXtzjiU3/+scDOOc9p6eNDZYPtqlgpIGlPNfgctdMmID783IEG+RfbKrIi4GTxdqEsrY2RBx/DFBczUmqXD8lLlRJBgtPVY4PV24TQLD7Pr5yr9VWvkSGY1uvzj1mk9GcjLWLneKQ4QEJPyxITqWfZe+PDqv/yJVODTipWoCHirnSES1hd8jTuKQCSPVY0sdKyLwNiU/0eZKsNmxIlqiu2oHezH4TEO6wUxCLZtzmDA5rjYK5X40oqbNaIKz0CLpqQyr/0jba1fqGWdMNRtjDdL6abafIpjLEb4bbyRZWqeYNotESW/Wdn4M/B+Mi0FjbCPMAgSz5GF6RTYvu/nPkmQbuZBk5i6C3HV5p0pQU/IASU6qdsUnBHTdv34+vZFCH3AHkdGbLpXatLPsuPZtmepczZFhryDvGxws+1iZeoIuS2ajSzK4ARUk274yeinEh9s3RZPjTPVDDwH0coJQyku5likIbzPJhD/fQVSXipY5ALAoiovEN2X5vS0PagE6lqEe9D8gGBnXk0VqMsFfDUZSAv59fxfqElTA6xJSfhDUyvYjspsmWAS+08t6K7Sj3vO+lsVm3nWXk/whRahkZJKC4BX6SezaSVXOLyWZ9QqQLmT0t8OGmZSWrYd6RQUK8rTfxLKHkRfbDzH7W9mfP1SSRbHBvdOzmuOWjGdgQppY6tvEuuU1wFoiN9gsKQsSFxVSUZG6ApWqV5sKe2FtBNMX/kHHOmU7XYmfrVt+pf20pGU5UDhyaxzYnbEZLoJ4gVy/tlZLWvyoUbJdsqkD+PO15ImbmkJB0gQT4wWS/ASoxvcxa4CmygZebQxpozt+SzYZWDz6dywYrXDGpudkDEm4SZ22NgIZIjuIp+/hljY36aiHcF15WkZAa2D2Is4lrx/vmfR3VpMCuHGHx2LRGVBMCu9CgUV1tsnLQ55plpFJr8eoyUlttKyN7pd4HByQ3aR++BVTiVZ9/QZMLc2T6Tix0s83N9RKz6mzEgOwE14Xx7HO+GQWNh7YsI8s3RknVgSR0nkYKWNvOllGwA35a+sfxD6xbTEI=","source_count":598,"source_output_dir":"organized/mining_outputs/out_exp106a_affine_n9_micro_orbit_probe","target_bits_payload":"eNq1WUuO5CAMPfIsWxppxseaXfsoHMFLLxDQ5AsBG0jBoFaqU6HAn/f8Ib8Dhu1vG3a/Xjd+v6HzidmnYZqWzz2HOT84XtzjiU//2scDPuc9p6eNA5UPtqkcpEGlPNeActdMGEP783IYb+RfbKrIi7GTxdqE8r42RBx/AmNczUmqXD9FKFRJBjNPVY4PV25jWLD7Pr5zr9VWvkTmY1urzj1mY9CcTLWLneKQ4cEJPyBIjqWfZe+PDq//yJVONTSpmuGHirnSES1md8jTuKgCSPVY0sdLyLwNSU/0WZSsNmxIkKiu2gHfzH4TEO6wUxALZ9zmAg1rTYK5X40oqfNaIKz0MLpqQyr/0zba1friWdMNRtjDdLaa7afIpjLEbobbyWZWqWYDUdASW/WdnYM/mOAi0EDbiPIAQSD5mF+RTYvu9nPkhQbuZBkhi6C3HV5p0pSU7YASU6qdsUnBHTRv34/vZFBH0AHkdGbLpXatLPsuPYdmepczpFlryDvGxws91kZYoIuS2bDSzK8ARUk264Keimkh9sPRZNjTPVzDwH0coJQyEu9likKbw/LhD/fgVSXSpY5ALDQioukN2f5uS3PaAE+lsEe9D8jGgXTk4VqMgFXDUZQAvp5fxfoElDA6xJRfCWsYehHZTZMtA55p5b0V22HuedtLY7NuO8vI/xGi1DLSSEBxC/wk92woq+YWk83bhEhnMnt6hsNNy0rWALAjA4V4W29iQULJi+xHmf2878+eq0ki2fje6NjNQctHM7BBSi11bONdcpvgLBYb7RcU5IgLT6koydzAS9UqzUU9sbeCaIr/JuOcC52uxc/WrbZT//pSMpqoHMA0j21O2IyWQD1Brl7aKiWtfVUo+C7ZVIHsedrzRMzMISHqAgnw48l+g1ViWpm1DFNkYys3hzjQnL8lmzetHnw6lw1WuGJSc7MHJNAkztoagQKiHMVT9rHLGhv11YK5L7CsIkE1sFsWZyPUjrfN+zqqSYFdOcKCsWmNqCYEdqFBw7raBOWgzzXLSKXWgtVlpLbaVkb2Sr0PDkhu0j58y6TEqz7/jCYX5ci0nVjoZpub6yVm1dmIAdkJrjPj2ed8M8oaD31ZRpZvjJKqA0noPI0UsLadLZNgB/q09I/jB6AWJPQ=","target_count":61978}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
