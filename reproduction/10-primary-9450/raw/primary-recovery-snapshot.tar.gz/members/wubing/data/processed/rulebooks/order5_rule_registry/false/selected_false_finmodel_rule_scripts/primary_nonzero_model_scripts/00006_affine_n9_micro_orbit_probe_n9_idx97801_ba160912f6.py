from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":516777,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n9_micro_orbit_probe","model_idx":97801,"model_key":"affine_n9_micro_orbit_probe|n=9|idx=97801","model_order":9,"model_table":[[0,5,7,1,3,8,2,4,6],[3,8,1,4,6,2,5,7,0],[6,2,4,7,0,5,8,1,3],[4,6,2,5,7,0,3,8,1],[7,0,5,8,1,3,6,2,4],[1,3,8,2,4,6,0,5,7],[8,1,3,6,2,4,7,0,5],[2,4,6,0,5,7,1,3,8],[5,7,0,3,8,1,4,6,2]],"primary_rank":6,"primary_unique_false_pairs":516777,"rule_id":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx97801.v1","rule_key":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx97801","source_bits_payload":"eNrtmc0NgzAMheMoh7SnCHWAHDh0DEZgpIzQERi1aRtSggOBiv6gvo8DiFiRbGL7WZD4BOQvIawA+0AvNXSI1eb4NHHS31u2ckw+Tt1bZ2gk4gjAkmS7ccosnX0aEbem8Q7hRYVggm16bxceu7TXPmp6X9kPsdYXt7wgquB1womTyh9Ok5S+ZsJasyprmXCEdATguzRR6eQmOzcaItSg+4ypf843es5GqbprozNrh96qJCPve6vMzMaszW5mNjco7DLxTXMnTCJR5mS3RfYBAMD6zqbVzPBnWR8EAID/wQwlPZVUPq344wXeyBUTIAxH","source_count":110,"source_output_dir":"organized/mining_outputs/out_exp106a_affine_n9_micro_orbit_probe","target_bits_payload":"eNrtmc0NgzAMhUdlhI6QkRiBMXrgkAEqlFObQxSnaRsowYGQiv6gvo8DiFiRbGL7WZD7BOQv56QD+0CvNRSI1eb4NBHW32u2co4+TttbJ2gs4gjAmmS7cUosHX0aEbem6Q7hRYdggm16bxUeq7jXPmp6X9kvQ63PbnlAVMHrhBNnjT+cKip9zYy1ZlVWMuEI6QjAd2kGpZOa7MRkiDCj7jOl/Tnf6DkbxequHpwpHXq7nIy8720SMxuzVruZ2cSosNvIN82dUJFEWZLdEtkHAADlnU2bheFPsj4IAAD/gxpLesqpfCr44wXeyBU5YGTv","target_count":62466}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
