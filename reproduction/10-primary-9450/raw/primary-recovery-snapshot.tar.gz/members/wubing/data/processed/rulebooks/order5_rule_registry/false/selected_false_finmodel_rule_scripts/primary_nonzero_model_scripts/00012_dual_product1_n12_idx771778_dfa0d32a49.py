from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":71468,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":771778,"model_key":"dual_product1|n=12|idx=771778","model_order":12,"model_table":[[0,0,0,0,0,0,0,2,4,0,2,1],[1,1,1,1,1,1,2,1,3,5,1,3],[2,2,2,2,2,2,4,3,2,4,0,2],[3,3,3,3,3,3,3,5,4,3,5,1],[4,4,4,4,4,4,2,4,0,5,4,0],[5,5,5,5,5,5,1,3,5,1,0,5],[6,8,10,6,8,7,6,6,6,6,6,6],[8,7,9,11,7,9,7,7,7,7,7,7],[10,9,8,10,6,8,8,8,8,8,8,8],[9,11,10,9,11,7,9,9,9,9,9,9],[8,10,6,11,10,6,10,10,10,10,10,10],[7,9,11,7,6,11,11,11,11,11,11,11]],"primary_rank":12,"primary_unique_false_pairs":71468,"rule_id":"false.finmodel.primary.dual_product1.n12.idx771778.v1","rule_key":"false.finmodel.primary.dual_product1.n12.idx771778","source_bits_payload":"eNq9WcFu00AQnXUcbNoKO1UkkKiosVypt/bIrQ6KRMyJT0DiB+BeKUskBD1RVf2A/AF/0KYXvsOf4GMPUcx616KkuxNiaXfm4DSZ2i9vsm92ZvYbywEWz6Gxc3ldyCsM5TVXb/YgkW9yJl6W9WswWln/MjugnoJvdNzXn8x3LOpD5Fk3yOdQMcTBv2C37GGOefYV8Rw9RRzH2LPyEPN4KJV+G1GNSoTd2lLxI42KeslGGoqK1zzXHOHa48OH327+6B+TtV9MWo/3gMDuJdgUUo8CTVGL7kiolQrtaEQBJtTc2K03YKF7MK6ovWv+jtXacmiVQpMaZM65rSTYIT8QrBLuGKwV267SfBtc52I7BTqx/bwDQrHJ5fGESGxn8JIBmdgCkjgKsX0HOlvVO3RgTS3CyNDQksiN2KaEYOVudYsUgg7sHFYBGTV+QhhHvNR1Yr9ZcFAJiiTVz+JNyXuvqKi9CCgDSVQbK/tIyQyus6tJKorxkERsV+P9YjzOExJqHwSzix/hPy2TS3u/X2SDAeMkaTIv0ossTYnWyHGREK5ItFF3YXO49OnQhpTK5nEOzF/v9d1Z7Llvnh7sLWUgc6Bc/iElNVFGbsILl5FNdeBzxrbvsZqllzWLN6FZ3dJ5fbaxC82sUqv+0xzaTWk3uOuZ6Ogiu2Ukzow3HZ3d9hEvI/1YwJV2ywZ0xfEGyG4cN0zCZcE3y6zmmusMS55NwWd5xMXR2fFkJryZ3dFyjD6uP7z8e9Jiy1AwOe63PDRvz4+WJ3p9bFgapTEGHQYkeJbf2W4fnHQW22fTdq5/VJmSTacyUinL4NKPqorYnNy2Nh/jgS0bKwOSwPEWujYgMXxrB0VYu2XPdGqmEyOT+Dp8qfYoo0lRj4uD0VartFOqaeXT9/TkqevP01Xs8y7x/gOOX84A","source_count":1606,"source_output_dir":"organized/mining_outputs/out_exp119a_dual_product_followup_a","target_bits_payload":"eNq9Wc1u00AQdpRDj34EPweXpn0D3iAPUFXlVBBS2Ei9wwsg8QiccJAi4t440lulWsZFRQIpamzUH5s43mG9a1HS3QmxtDtzcJpM7S/fZL/ZmdmXPAIY/ITGTuR1IK8wl9dIvbmBVL6JuHjpe1/BaIH31OwAbwyV0bHjvTXfMfAukWftI5+DzxEHe43dcoM5hvErxHNxjzjOsWdFBeapUSrLNqIalRy7taVS5RoV9RLPNBQVr2GkOYq1xxcPv93w0T+ma7+YtBVbAYHtSLAxJDUFmqKW75JQCxTaxYwCTKi5sb16wQv3YExR+9j8nam15dB8hSY1yJ1z60mwS3YlWKXMMVgrtlul+Ta4zsX2BejE9mwXCMUml8dvIrGdwncOZGIrSeIoxPYC6Kzn3dGBNbUIJ0NDSyI3YhsTggW3/h5SCDqwE+iVZNTYGWEc8VLXiT3h5ZUvKJJUP4PPAVt9o6L2o6QMJFFtrOwdJTM4iA8niSjGCxKxHU6vw+k0SkmovRfMjp8X/7RMLu3DdRgvFpyRpMkoTI7jJCFaI+dhSrgi0UbdhQ3hqKJDm1Mqm2UR8Gq913dnWe2+eXqwT5SBjIBy+ReU1EQZuQmv6Oc21YHPGdu+x2qW7ns824RmdUtn3unGLjS2Ss3/T3NoN6Xt465foqPL7ZaRODPWdHR220e8jKwyARfYLRvQFccaILtx3DAJlwXfKLaaaw5iLHk2BZ/lERdDZ8eTkfDGdkfLGfq45fzo70mLLUPB5Ljf8tC8PT/qn+n1sWFpBMYYdBiQ4Fn+brt9cNJZbG9M27n+kW9KNp3KSKUsg0s/qgozc3Lb2iqMB7ZsrAxISsdb6NqAxPCtHRRh7ZY90qmZToxM4uvwpdqjjCZFPS4OZlut0k6pppXPstaTp66/WldxxbrE+w++EqMn","target_count":60970}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
