from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":68810,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_yield_clone_derivative","model_idx":123928,"model_key":"high_yield_clone_derivative|n=6|idx=123928","model_order":6,"model_table":[[0,1,5,3,4,2],[0,1,2,4,3,5],[4,1,2,3,0,5],[0,5,2,3,4,1],[0,2,1,3,4,5],[3,1,2,0,4,5]],"primary_rank":13,"primary_unique_false_pairs":68810,"rule_id":"false.finmodel.primary.high_yield_clone_derivative.n6.idx123928.v1","rule_key":"false.finmodel.primary.high_yield_clone_derivative.n6.idx123928","source_bits_payload":"eNqtWUmOHSEMBYsF2aGcwJH+QVAriz4WX0r2OXLAZnJhauik1MlXFQUG+z1P9TtFb2I0b2PML2Ni+UPjyg14NNHj24BxDkMe8XnY5Jvg8w9YY7yxqTwyNIB5Gpi6iHVmXPmtPD+VUZrbx7x1IbZ74Ge0YhXMN2EeBvotewQMkwwTgHaRV+wSPC+YYr+xaAL2KXkN3iwdxZQ/noplW5ZVUI7i8x6QTvkjOch3ZfQ7jaYyDdpRUn7Ko1lrNK0d5UWj0FYqB/ugzWLqo3WaCSGWTUKxBVjeK+06BTpHnhGaPsRRjCsqjsYMJdejCBXzC3wUbO+mebH8L3Ub5fmerIDmILNded0KIiRDh6p6eqOYPOYH0xaKGeh1Om1f5rA+Gmc2l7cdGnS8eSj/YZqXSR1Jkw60RXcDW/wydNy8Kqsy1GNFc3LpO6kGC2JLMG6acEuC4Ai3h9cvgnFjhzDCAEVddqA+NtQ/u1Kqh8oK9cK2RGUnFpSwqfvQRVr16dYh1AOBOYWNAPj1BURUZlMycaxE3oc4eQabqKDQ4jLYHxA3XFiwRoLKVpJc8H0lA/c0aK5NwZpfNmfN5EtQwcAV2bYeVuPSGh+MdGX3yAafi6NfyXblP+xsnxOyRSiCsLt7r5Ktx1JprtVVus3WUuATFUHfXI86tgpyUmsjROoy/KJZecYasjQL5WDAERiahDV3eHh98ObsAjEOBlGqyzYncMfXr1clm+Jc2UK+rkY7IWf63h/r8rQ1JeKAI2eusLkim2I2jWzK8IANCtgsZHNnpDuQDQkHlNYcqINH7SqwifRrd+5+JVvPRKXSKR+4hM3wBLPZ4uPIxsEgzIATeV2TiKRKJ6PPJp7vU93uoyVsms6gAqWb9I6PBAoS2LaXZDiGNbDw6+3VA0CAMQQbiZHdiAsCbjPZ3OQNXa0EFBAqMlbjee8GrvM55aseF28oQ3tYNRcnAOlpZKgcmF9FVWuH0D7L8JO68RB8sP7P5omLi7Jmsiatz5ltsya9KkxqJxnu4GlcJduolYSLIrI5Wd2M0qoXT51sY2IHKfOAB1kvYYRQGdlIkBNFFvSI609l8ByeYniwAgP4RK9aqk2vLglRzPs5KkCV0VQxnytwZKMTvXWtyYTokwRJBWgyuirmcwFX2d08itZkQmT7vs5ldFUcjLdPI6s137zczx1sNBkDQNJ4Z4U6CXrRcm4PG0XGBCBpvJM08iZsTokgjdfJBvfIBgrZwmOyKVhTOhr3yPbzmmwr1twONkIB8BWyKQ2YtdL9H2QbrL5PNvfPZPtzwJoOm9cl2eKebNaW2l1md6EXv/VRaiXjlCPtKzWL2zRy22ekmeDjFAezavcrXdd0vbEGpdLFOeZH2TNxrcqulcZFkqoP15otiny+Jr/W02GqQdBoLb1nVwAC9WgBjuL8lQVZRxjw1D1Mm7bJkwbJpnGrPOKeyaZGC1elPpGNNNxLqaHOfGKXtDJuA7Y7R9umkUo/lisN3GWmvv/aXc24TSOnPnc7IQlijkSJ212pf8hb951wmFfAngziJbvgqhtJgj6Fi5o6+Ecw3GjnnpKN8wHh2L3mBhaywSPEVLL1gNODx+hiuLWrdd4f3IvcflpQ2v0hGq2MwxsNp1azcccDRyVfQaa0/tePGmb+2nDdTKitf8sFIM4wWHu4JRj4233+besfZX8ONj3clWzpkYusZCsuKruubrSgdiNF7yd8wSHX1r/7nviDUs2HQetGal+Jnrb+i9HJPXbHvouR80ckfNSF72SjxbM2Ia48TivUSAGn4MCz7IFSDOpq4tpVVYJXHJX1/SjTIhuxWgAiDWlw7GsBcaBiyc+buqNXb4v7UFyU5v3gW+Q8JVAi3ioIc9tj/wUQjAiG","source_count":2144,"source_output_dir":"organized/mining_outputs/out_exp129a_high_yield_clone_derivative","target_bits_payload":"eNqtWUmOHSEMPXL2ifQ5Vi+iiIN8KT5Bi12zQIaAzeTC1JCk1MlXFQUG+z1P9d1Yn6xNr5TSj5Rs+YMUyg16SNbDK2EKAVwe8Xk45Rvn8w/GlHyKpjxKNAB5Gqa6SAxpXPmtPN+UUZrbx3wMzrZ75Ge0YhXMN24eRvote0Rwk4zkkHaRV+wSPC9obL+JkBz0KXkN3iwdJZU/ngplW5FVUI7i8x6ATvnbBMx3ZfSTRk2Zhu0oJj/l0aw1mtaO8qZRbCuVg/2izYLpo3Vacs6WTWKxBUbeK+3aODpHnuGaPsRRUigqtikNJdejCBXzC3wUaO+aebH8z3Qb5fmerADpILNded0KIiBDu6p6eqOY3OYH0xaKGeh1Om1f5rA+pJA2l48dGnS8eSj/gZmXMR1Jkw60RXcDW/wydMK8KqvS1WPZdHLpO6kGc2JLOG6a8EiC8Ai3h9cPgnFjhzDCAEVddqDeNtQ/u4yph8oK9cK2ROUgFpSwqfvQRUb16dYh1ANhOoWNAPj1hURUZpNJdqxE3oc4eQYbq6AwwjLYHxA3gluwRoLKVoxc8HUlA/Y0aK5NwZpfNhfT5EtAwcAV2bYeVuPSGh+SdGX3yIYfi6NfyXblP+JsnxOyWSyCoLt7r5Ktx1JprtVVhs3WjOMTFUFfoUedWAUFqbURInUZftGsPGMNWZqFcjDgCIxNwpo7PLx+8ebiAjEOBlaqKzYncMfXr1clm+Jc2UK+rkY7IWf62h/r8rQ1JeKAI2eusLkim2I2jWzK8IANCNgsZAtnpDuQDQgHlNYcqANH7SqwsfQbd+5+JVvPRKXSKR+4hM3wBLPZ7OPIxsHAzYATeV2TCKTKIKPPJp7vU93uoyVsms6wAqWb9I6PRAoS0LZnZDjGNbDw6+3VA0CQMYQbiZbdSHACbjPZwuQNQ60EFBAqMlbjeR8GrvM55aseFm8oQ7tbNWcnAOlppKscmF8FVWuH0D7L8JO64RB8oP7P5rGLi4ppsiatz5ltsya9KkwaJxnh4GlCJduolYSLIrIFWd2M0qoXT51sY2IHKfOAB1kvboRQGdlIUBBFFvaI609l8ByekniwAgP5RO9aqk2vLgmRzfs5KkCV0VQxn8txZKMTvXStyYTogwRJBWgyuirmcyFX2d08itZkQhT7vs5ldFUcjLdPI6s1X7zczx1sNBkDQNJ4Z4U6CXrTcmEPG0XGBCBpvJM08iZsTokgjdfJhvfIhgrZ3GOyKVhTOhr3yPbzmmwr1sIONkIB+DdkUxowa6X7P8g2WH2fbOGfyfbtgDUdNu9Lstk92WIstbvM7lwvfusj00rGKUfaV2oRtmnkts9IM9HbKQ5m1e5Xuq7pemMNS6ULc8y3smcSWpVdK42LJFUfrjWbFfl8TX6jp8NUg0DSWnrPLocE6tECHMX5OwuKgTDgqXtoNm2TJw2STeNWecQ9k02N5q5KfSIbabiXUkOd+cTBaGXcBmx3jrZNI5V+LFcasMtMff+Nu5pxm0ZOfe52QhLEHLESt7tS/5C37jvhOK8APRmES3bhVTeSBH0IFzV18I9guNHOPSUb5wPCsXvNDSxkw0eIqWTrAacHj9HFCGtX67w/uBe5/bSgtPudTVoZBzcaTq1m444HjEq+gkxp/a8fNdL8teG6mVBb/5ELQJhhsPZwSzDwt/v829Y/yP4cbnq4K9nMIxdZyVZcVHZd3WhO7UaK3o/7C4dcW//h0/AHpZoPo9aN1L4SPW39F6OTe+yOfRcj549I8KgL38lGi2dtol15bFaokQJOwQFn2QOlGNTVhLWrqgQvOyrr+1GmRTZitQCEGdLw2NdC4kDFkp83dUevPhb3obgozfvhl+U8xVEi3iqIdNtj/wE79Giw","target_count":60432}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
