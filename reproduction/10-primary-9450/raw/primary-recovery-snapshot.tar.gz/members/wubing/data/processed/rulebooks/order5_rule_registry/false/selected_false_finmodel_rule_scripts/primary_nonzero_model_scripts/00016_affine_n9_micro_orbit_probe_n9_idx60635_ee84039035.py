from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":64907,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n9_micro_orbit_probe","model_idx":60635,"model_key":"affine_n9_micro_orbit_probe|n=9|idx=60635","model_order":9,"model_table":[[0,8,4,5,1,6,7,3,2],[3,2,7,8,4,0,1,6,5],[6,5,1,2,7,3,4,0,8],[4,0,8,6,5,1,2,7,3],[7,3,2,0,8,4,5,1,6],[1,6,5,3,2,7,8,4,0],[8,4,0,1,6,5,3,2,7],[2,7,3,4,0,8,6,5,1],[5,1,6,7,3,2,0,8,4]],"primary_rank":16,"primary_unique_false_pairs":64907,"rule_id":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx60635.v1","rule_key":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx60635","source_bits_payload":"eNrt2VEKhCAQgOFRfJhHjzBH8WgevS2j3Sxpo6KI/wMbGK0HHVDMSS3JhiAx9tFND/FytlQ+bYLbuK0B+mfFYA8rVW8ra5D2rxEAAAAAAA8US/Bh0RO+vVNKPymbpXRsw9DIfOKosRJ966bFNV4A8GR5FupdpN4+lItuXMx+f3jp4lyUW8cl4A06ppgEoA==","source_count":50,"source_output_dir":"organized/mining_outputs/out_exp106a_affine_n9_micro_orbit_probe","target_bits_payload":"eNrt2VEKhCAQgOGjdzSPMkfwcR5Epy2jXS1po6KI/wMbGK0HHVAsWc3ZhmDeDzHND4t2Npc/LYbbpK0B+mfFYA/JVS8ra+D2rxEAAAAAAA/kc4hh0RO+vXNKPykpUjq1cahnPnHUVImxddOSGi8AeLKuCPUuUm8fykU3Lia/P7x0cS7qWscl4A16pdlslg==","target_count":62526}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
