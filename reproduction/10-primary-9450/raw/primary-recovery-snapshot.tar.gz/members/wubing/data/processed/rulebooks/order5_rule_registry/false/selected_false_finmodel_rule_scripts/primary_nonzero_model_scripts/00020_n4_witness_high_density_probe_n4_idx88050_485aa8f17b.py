from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":45541,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":88050,"model_key":"n4_witness_high_density_probe|n=4|idx=88050","model_order":4,"model_table":[[2,3,2,3],[0,0,3,3],[3,1,1,3],[0,1,2,3]],"primary_rank":20,"primary_unique_false_pairs":45541,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx88050.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx88050","source_bits_payload":"eNrtmM1OwzAMx+0oSBUniyfwoUh7jDDtwG57pGyncRt9Ah4VN236kX4iQOrAP2VV43Tx4jhL/kWYxb0A2LJYUAIPCARlkYuLRpTP7six6gcxFDhYaZWT+imz8Vg4TQdFURRFURRFUX4ZfwHIQpELd0VXfhZRYqmrT4KIMllt4ijXosKyQ9mV1E9Fq3Ow126LVOuJIyduMVscA07YHyvRhzbVkTShCJsAjGG2JNV2x/z9cLDNyHhOTOJ3vT2/5cX1erOGUIR6PdFlr68Gfes8/JLQZsmnaRND3LlPo13VPyTxIPTdPE6d7w4H4+9qsY3Dw0FUr0Qy/Yv6Z0yuVtLYbJfT09TMoeyh7HNjdBI3uNj8+NbUHhFcv708TPBSr04D+4fYQ3uypWTTlgy59c6HqzdtP5s6Iz2QW2NiTT7lRyHOJLfN19L4PnDQit/Fs9aIiTc8tk9afx8J","source_count":232,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmM1OwzAMxx+VJyi7bSeWR9ptHCbIY0yiBz8B8mmqRBQbN/1OPxEgZeCfsqpxunhxnCX/Ei9iX5ldWRwrgQ9i5LLIxTZGks/1DE3VjGIoQLDiJif1Uz7xWFhNB0VRFEVRFEVRfhnzxFyEIhfoi678KKLEYV+fBBHli9oEjVxrFJYby66ofso6nUODdpfFWk8cWXFLxeoYaMZ+q0QfuVhH4owibAMwhU9Jql3P+ePl4tqRwZKYpO96e9vn2eGwcx5JhHo90WWvz55M5zz8ktDm0MRp04S4dx9Hu6o/SOJx6Lt9HHvfHQ/G3NVimwbGg6heiRT6F/XPmF2tqLFJl9P73MyR7KFgcu91EhNcbGZ6a+qOCHbYXh4mYK1Xq4H9Q7xwd7LFaNOWDNkNzoebN22zmDoTPaDdYgJNPuVHQSgkt/3X0vg+sNyJ39Wz1oQJEh7bJ/HyUi0=","target_count":62344}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
