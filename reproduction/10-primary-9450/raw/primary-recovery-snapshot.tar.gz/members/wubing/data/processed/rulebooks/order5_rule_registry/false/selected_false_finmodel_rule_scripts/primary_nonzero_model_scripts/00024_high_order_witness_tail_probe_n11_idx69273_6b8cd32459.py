from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":25934,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_order_witness_tail_probe","model_idx":69273,"model_key":"high_order_witness_tail_probe|n=11|idx=69273","model_order":11,"model_table":[[0,7,3,10,6,2,9,5,1,8,4],[2,9,5,1,8,4,0,7,3,10,6],[4,0,7,3,10,6,2,9,5,1,8],[6,2,9,5,1,8,4,0,7,3,10],[8,4,0,7,3,10,6,2,9,5,1],[10,6,2,9,5,1,8,4,0,7,3],[1,8,4,0,7,3,10,6,2,9,5],[3,10,6,2,9,5,1,8,4,0,7],[5,1,8,4,0,7,3,10,6,2,9],[7,3,10,6,2,9,5,1,8,4,0],[9,5,1,8,4,0,7,3,10,6,2]],"primary_rank":24,"primary_unique_false_pairs":25934,"rule_id":"false.finmodel.primary.high_order_witness_tail_probe.n11.idx69273.v1","rule_key":"false.finmodel.primary.high_order_witness_tail_probe.n11.idx69273","source_bits_payload":"eNrt1z0OgzAMhmETZfDIEXKUDD2Ye4Meudj8tKWy1C6oRe8DAikBhihfggd5qIMAYfzkIRXzW2e4gCN1i9A1j6lWX7tt6/JzjADXpzeuedDJLwAAZ9F6S7v81OkQKXMLlV/ulo5PtPbLNyUT8F/MYpWwueDfLSNTBtoy8Zn+OGhnW6ah7krcdVVWe9vvSv61woACv6HGNhL5tZd09u3CvyoAnM8dPUUKcA==","source_count":70,"source_output_dir":"organized/mining_outputs/out_exp109a_high_order_witness_tail_probe","target_bits_payload":"eNrt1z0OgzAMhuEj9wb1wTr4KDkCY4YouNj8tKWy1C6oRe8DAikBhihfgkd7aKMBYfjkoWriN2W4gCOpROiKx7Q2X7tl6/JziAC3pzeuedDJLwAAZ1G0pF1+1ukw63MLlV/uko5PtOrtm5IJ+C8isUrIXPDvlpEpA2WZ+Ex/HLSzLdOw7krcdVWu8rbf9fxrnQEFfkOLbSTyKy/p1O3CvyoAnM8dDztmxg==","target_count":62506}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
