from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":11412,"excluded_block_payloads":[],"law_count":62576,"model_family":"f2_3_affine_completion","model_idx":5402,"model_key":"f2_3_affine_completion|n=8|idx=5402","model_order":8,"model_table":[[0,5,2,7,6,3,4,1],[4,1,6,3,2,7,0,5],[0,5,2,7,6,3,4,1],[4,1,6,3,2,7,0,5],[2,7,0,5,4,1,6,3],[6,3,4,1,0,5,2,7],[2,7,0,5,4,1,6,3],[6,3,4,1,0,5,2,7]],"primary_rank":45,"primary_unique_false_pairs":11412,"rule_id":"false.finmodel.primary.f2_3_affine_completion.n8.idx5402.v1","rule_key":"false.finmodel.primary.f2_3_affine_completion.n8.idx5402","source_bits_payload":"eNqtWUGy7CAIRMuFS4/gUTiam3/vPy/RiNKomfesqUwlZkSQhob5R0w/H0dEgdLnyp+764biz0y+b36+mJie1+6f3Bfy1zVTub65T9ThrrvCNI+PiGuxz6UME1VwlS7X8/VBqLPPSNTUmKSXW9D1dJigEG5Z8V6yj1y1iPVbqCJ0jG31roqYbS9w16K0fTZVnNSxCFUYW7I0W/u2+qgKBT+buKoSxEHV1W9VgPj5jLi9kske1Yme8+yvJ1JWvKa0wCwWW49Y39VrK8tUQVWaw6sJHwLD9N/712F+Uj4LRfxysWQo3+N+XsM2m7QHersFlyPcMnyzY5JTzWpJHsvg9e9GEWFjso+KAFVoFMcKViN92vuAcE1NVvO09u+tkX2HUgDbjMrR49ZczgZbDdJFISXFA//8yHYvjq1FaY+t1tbix20y8rPV7VGEpR4u2+9Bfng3ssSZG6JQhm5TjNhRzsHWNXNaszi4TRpsVYA3ej35PBgF5THMjlZr57uWwTYcUpeWAXQYeLazgB23oPNdraDSUJNWpLRgydDJxwCbkV8n9hAD/W5UsA35uueuqGGVLUX8gbQKtu6Xj4TuJEx/BjaLIGo+IHK2/06ayVMBH+ikhb8TZmc2QLxAan8XI5dUV6wdm4psJk8zfAiw9a2ChONZemB8POrLwTKFDryjViqz22QjU6dDsBXIB3jMwIFgagdcdeU/rhJkPwMIWA1Z+udJPCEOl2kyOJ57G3k2DuCrtyh3ivXQEw0g32FB7JyJA7bBxkaI6nlsiIJMdGo2CLaHCpTRxwD5BjGa95yH9jUhIkTAAEK6A5ktoioblKaCnyRdDyxlBIvAmjSShxWC4TbAJXif2WChPhMi4DZ7U0olbBqp3Qa2CHChETBnCaIxMVgtDyt4A2xREXiYAdyORsKOhgLbykMKANsoKGg67DUgzmSkc7ClkRMtDLAn5nuwGVbL5zJQZy28s1o4lxFBpRoM8q0fxeeS/5xG9rWbBvF7OUNjzTuDQKjMnZPdIdjlIJtGjmiPZjn6LrPFwRmYQIlYlJfSdyWO2bg1erlLinBII0UpJW0MO01ueSrf0cg5Odt8nLb16Z5GggYlZ0IF6+sGCeiEo54J7v345S3oRoo4682oJaOoQ5wgIh5SFNiGrmrRjdZilXFG7syYo5iZ7UWyO2Elm8z2ItkdELxnbw7HYxCQ4WsgpCQbGXks68MgLesN5Nf9pRls+fHMJbIyCB3pC7AB8qu7kaggedkg8YMz5EU3EhUkbxskxj9X4B+jTL/ObGz5mupG/r7TVBskmiKAgAzCdvWv88xWcIhCbSXUaXpTj8be8JuiFvjHCDxa0le1gf9CLXH/","source_count":883,"source_output_dir":"organized/mining_outputs/out_exp102a_f2_3_affine_completion","target_bits_payload":"eNqtWUGy7CAIvPffeDSO4hFcurCUPy/RiNKomfesqUwlZkSQhob5x8Q/n8LMicPnSp+764bjz4y/b36+iImf1+6f3BfO19Wzu76pT9RRrjtHPI+PiGuxz8UNE1VwlS7Xy/VBqrPPCNzUmKS7W9D1dJjglG5Z8V6yD1+1iPVbqCJ0jG31roqYbS9Q18K1fTZVitTRCVUIW9I1W+e2+qgKpzybuKqSxEHV1W9VgPj5jKi94tke1Yme8+yvB1ZWvKa0QC8WW49Y39VrK8tUQVVawasJHwLD9N/712l+4j4LRfyys2Qo36N+XsM2m7QHersFlyPdMnKzY5BTzWpBHsvg9e+GE2Fjso+KAFVoFMcKVmN92vuAcE1NVsu89u+tkXOHUgLbjMrR49ZcxQZbDdJOISXEA//8yC4vjq1F6Yyt1taix2088rPV7VGE5R4u2+9Bfng3vMRZGaKQh27jjNjhzsHWNStaszi4TRhs5YA3Zj35PBgF+THMjlZr57uWQTYcQpfmAXQIeHaxgB23oMtdraTSUJPmpLRkydDJxwCbkV8n9hAT/25UsA35uueuqGHlLUXygbQKtu6Xj4TuJMR/BjaLIGo+IHJ2/k6ayVMBH+ikhb4TZmc2QLxAan8XI5dUV6wdm4pkJk8zfAiw9a2ChJNJemB8POrLQTKFDryjViqz23gjU4dDsDnIB2jMwIlhagdcdeU/pRLkPAMIWA1Z+udJPCEOl2k8OJ57G342DuCrt6hyivXUEw0g32lB7IqJA7LBRkaI6nlsiILEfGo2CLaHCrjRxwD5BjGa9pyH9zUhIkTAAEJ6AZktoioblKaCnwRdDyxlJIvAmjSShhWS4TbAJWif2WChPhMi4DZ7U0olbBqp3Qa2CHChkTBnSaIxMVjNDytkA2xREXiYAcqORsKOhgLbykMcANsoKGk6nDUgzmSEc7CFkRMtDLAn5nuwGVbz5zJQZy29s1o6lxFBpZoM8q0fxefi/5xG9rWbBvF7OUNjLReDQKjM7YPdIdjlIJtGjmiPZjn6LrPFwRmIQYnolJfydyWO2bg1erlLinBII0UpJW0MO01leSrf0cg5Odt8nLf16Z5GggYleUYF6+sGCeiEo54J7v3k5S3oRoo4m82oJaNoQZwgIh7iFNiGrqrTjVZnlXFG7vSYo5iZ7UWyO2Elm8z2ItkdELxnbwXHYxCQ4WsgpAQbGX4s69MgzesN+Nf9pRls/vHMJbI8CB3hC7AB8qu7kaggedkgyYMz+EU3EhUkbxskxj9X4B8jz7/ObGT5mupG/r7TVBskmiKAgAzCdvWv88zmcIhCbSXUaXpTj8be8JuiFvjHCDxa0le1gf8KU/8o","target_count":61693}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
