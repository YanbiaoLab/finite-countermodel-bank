from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":10471,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":23919,"model_key":"dual_product1|n=6|idx=23919","model_order":6,"model_table":[[2,2,2,2,2,2],[2,2,2,2,2,2],[2,2,2,2,2,2],[1,2,2,2,2,2],[2,2,2,2,2,2],[2,0,2,2,0,2]],"primary_rank":46,"primary_unique_false_pairs":10471,"rule_id":"false.finmodel.primary.dual_product1.n6.idx23919.v1","rule_key":"false.finmodel.primary.dual_product1.n6.idx23919","source_bits_payload":"eNrt2LFKw0AYB/ALCh37CH0IB+kUcLQuDlJ08QEcMgTMUDR5AFdndwtWKai1lnQWSieLqG0KBbO0SadeoW3+agqFEg4j5BTl+w0Z8iX5cpf7ZziFMWaxr9y3P491ZBj5CUM+8VA2ogULoVS0Mg0LarTQnd+iRCvzQjpauG1fXJ82zndPtjdWGRtj2eJJ9aXTKn02QgghhBBCCCGEkP8L8ANMOI45gnA3qFbQAcdwViQ060JExtCmomYyNkMt4dBkTORQ1MyUMZGBqFtaQrO6cCIVCd3GomaqnLAJpChsFLbfCJvjV9HszOz99o0fqAWeH3RegbcnN3BK3ouBs9qkeKh5MPW+Dj/PB+HlO9V1Djs7yiYUtnjSCYUtHiWhsMWiJhS2eL73t7FsJ1wHpn2nOTNz5JWeaxWgcdWMuWzgao9HueKs77aAspGrlBYLqGLvPbSMzQNvzft4r63eZYaD/EHvZYHY4A==","source_count":9966,"source_output_dir":"organized/mining_outputs/out_exp119a_dual_product_followup_a","target_bits_payload":"eNrt2LFKw0AYB/B/2kKvU5N2qSA0jYrUqRScG2qNCkUj1N3Z1QdIlA4ROnTwAVyU0sHFOgqZioMP0UfoWFByagqFEg4j5BTl+w0Z8iX5cpf7Z7iAc+7wr+wYn8cGJpz8hDzLaGh70YKD0CxaSYcFP1ooz28JopV5YRot7BnHB2f1k7vz+6dXzrNYtnhSY+m0T5+NEEIIIYQQQggh5P8CVAUZhgsGJdwNanZ7gO7pbxKalSEiY2hpUTMZm6GOcGgyJjIvaubKmEhF1G0qoVlDOJGBhG5ZUTNfTtgEZhQ2CttvhE1XW6hVUuaNsa8qfpcNCpU1YGWzpOi2tu7htJnpXPU1uL1iD+qAFcLLh61nBnOcGycUtnimCYUtniChsMXiJxS2eL73t3FMPVwHrrnb11NuTrM3mhZQP6zFXDYo9bcuR51UsVQF2t7IshcLyDJvt6ve47X2on2818Pq0YSB/EHv5vCYRw==","target_count":52610}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
