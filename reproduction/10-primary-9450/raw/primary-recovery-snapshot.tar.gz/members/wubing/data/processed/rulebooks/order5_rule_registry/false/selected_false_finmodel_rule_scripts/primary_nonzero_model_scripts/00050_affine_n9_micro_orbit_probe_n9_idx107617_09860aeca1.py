from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":9592,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n9_micro_orbit_probe","model_idx":107617,"model_key":"affine_n9_micro_orbit_probe|n=9|idx=107617","model_order":9,"model_table":[[0,8,7,6,5,4,3,2,1],[0,2,6,1,5,4,8,3,7],[0,3,1,7,5,4,2,8,6],[0,3,1,7,5,4,2,8,6],[0,8,7,6,5,4,3,2,1],[0,8,7,6,5,4,3,2,1],[0,2,6,1,5,4,8,3,7],[0,2,6,1,5,4,8,3,7],[0,3,1,7,5,4,2,8,6]],"primary_rank":50,"primary_unique_false_pairs":9592,"rule_id":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx107617.v1","rule_key":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx107617","source_bits_payload":"eNrtWFGuAiEMLISPfnKEHoWj8RIP/krbLahk9cO8FzedGKPA2nUKs+0kmLhBbZBbIyiQ4X/RkDrfBL8VKLUDJP5WoH42Sim5ATVAKAipcxDiQXldBlQ4qwnGOzOKTCHB+PgSuuRsI5TBHYyk5JGgQCBwQWCa6tFMiVG0OGNjMUmHqgwRSIVUtnVwqIhrtylPBptuMjnklifbC7W5AG5M2OAg8d8nf6gh7Fhjuqs8kCdXdgXCQrdOk8o104eDZZnpdQlUXPZ5ZvNUlUAjm6cxbHrmS5NHcUQ+fdgkPbIF/My8t22OtOUjbc3Tpltj7pN+9cMm5exgTSTKaBPCrLI0LqvKmpwB58o1bTkIlouyHjXl/MrIORFU6QpKh9aPio83Z4akFTSgir+W0bJc+TWah8SsFwrT0ETwk5LYXpWbX4/0wwTgm6wJ07J8cqVX4Hqh9iy0kihynIiWQNLg+FLP5syM39d5DGuPyPY8gh6GeAAEAoFA4C8crdkbPVQq3F1JF2PV2yjk6MmZ8qrvLahHqP4WrZbYzjaUklp/eInaZnE/a4FHo+3y4Kby6BWpgjci2yGhsCJ4l7lSVz3vNMnLz7wGrmOQbIakjVNjygYXb9stKp9+an9PDJLN0MY/38Y4msY7Wys2ZSAQ+D6YGyla2F3xCLbW/2bo1Lu+E8ihyL8B5Vdk","source_count":711,"source_output_dir":"organized/mining_outputs/out_exp106a_affine_n9_micro_orbit_probe","target_bits_payload":"eNrtWFuOwyAMPHil5Wg+io/AJx8IvH7F0Bal/ah21YhRVbVA6nQME3s6DdwoAzUApEqN/hdQMPFN8FulmhNR52+V8mej1NqAEKhQLdQTB0Ee1NdlgJWz2knemdHCFCLJx5ewJWcboQp3JElpkqCNjY0LovShHuBKXFSLWwEWk36oiohAr2iybYOiIqHdrjyNfBp0UuSWJ+GF2lwANyZMOOj89zEeaoVWrDHdWR/Igyu/otBEt02jyTXTV4RlnUl5ClRD9nlm8VTVQJLN0xg+PfJlycN9RD592DQ9ugXizLy3bY60tSNtEGmzrTH2Sbr6YdNyVlhTiXLalDCvLJ3LbLKmZyC4Ck2bDoLnos5HzTi/MlrrSFm7gpoI0lHx8eZs1K2CpmLib2W0Ljd+nWaRmPlCZZpABb8bifCq3Px69B8moLzJmjKtywdXdkWZL7SeBWcSVY474hRIG5xYGtkcmYn7Oo/h7RH6ni9kh2E/ADY2NjY2/sLRGr3RQ6XC3ZV2MV69SSGHT85UVH1vwTxC87dwtsRWtqGW1PbDU1QYxf2oBR6NtsuDm8qjV8RM0Ygsh5TCXCi6zJm6HHnHQV575nXjOgbJYkjbODOmfHDytsOiiumn9vfEIFkMLfzzZYyjabyztfam3NjY+D64G6lamELxkJbW/2Lo1Lu+E0hR5F9KmxnS","target_count":61865}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
