from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":8302,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":425392,"model_key":"dual_product1|n=9|idx=425392","model_order":9,"model_table":[[7,7,7,7,7,6,7,7,6],[7,7,7,7,7,7,7,7,7],[7,7,7,8,7,7,8,7,7],[7,7,6,7,7,7,7,7,6],[7,7,7,7,7,7,7,7,7],[8,7,7,7,7,7,8,7,7],[7,7,7,7,7,7,7,7,7],[7,7,7,7,7,7,7,7,7],[7,7,7,7,7,7,7,7,7]],"primary_rank":52,"primary_unique_false_pairs":8302,"rule_id":"false.finmodel.primary.dual_product1.n9.idx425392.v1","rule_key":"false.finmodel.primary.dual_product1.n9.idx425392","source_bits_payload":"eNpjZGBgaGAgBNbMAZEH/sszjAJ6gA+fd735PzEcU6LhPxiwY8r8AUvYY0o8gGhhxJSBSPBjSqyY02XU2gNkBDixMDD8ACurB7sLxaQD/5GB/Wi0jYJRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBQMX/D//+l/9ZVf6+M+zv8HHgzaWJUEFFOfz0QDyx78xwVo4bU/uCyjxWBoA06vMdPAtg+4LKunRUD+w2UbPw0sO4AzIBlpYNsPXJbZ0yaz4QDso5ltNLMNRGY7/3rTf/e4v/PDzyw//U++8qvbmnk3/v9POrGcQQAz9T4X/fwSpHyv4Gr1b//3S3zSpF1me0BxAJCS2f5QWtqQktkaKC5tSMlsHygtbRrmX0/937/nl/36Gf7T/9p/etUbYbvx//+jE/yxJJt/57WfXQYpr1IO83/zv97wSfD//4+1j9ZwLf7z4uiV//8nhjvP0IcnoJXrJQ5dSufwfqX8Bugul8QJ8l//j4IhCABWJGLX","source_count":8991,"source_output_dir":"organized/mining_outputs/out_exp119a_dual_product_followup_a","target_bits_payload":"eNr79/////r/hEBwMoi0Z3jwfxTQA/DzuAoz5K3AlKhnAIMfmDLMYIkDmBLyEC3/MGUgEh8wJcKTS89WFQMZ6/f+/v+fHaysAewuFJPsGZDBgdFoGwWjYBSMglEwCkbBKBgFo2AUjIJRMApGwSgYvoCBwYSxoY2rYSFfAiN4MMivdS5Q7EbCXxpYJs+AC9DCa8y4LKPFYGg9Tq/9oYFt/Lgsa6BFQDLisu0DDSyzxxmQ/2hgGzsuyw7QJrPhAD9GM9toZhuIzGYg4suwYyFTwgrjCBPGB21cO4MT1RkY5ppH/H+PmXolXvGIgZQ7vQu5wcng8Jz3Gu0ymzzFAUBKZmOmtLQhJbPVU1zakJLZ+CktbeoTNGYxFDizHghI35DBdIBXtGj5IT8GBqv8DViSDaPBFUkdkPLWOys3CDM0nJNew8Agc8Wq+WsMs7iVNgND3oo96RfgCSgs4Lmt7ozvW0TvCAPdtXte/gMuhlEwBAEA9k0OXw==","target_count":53585}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
