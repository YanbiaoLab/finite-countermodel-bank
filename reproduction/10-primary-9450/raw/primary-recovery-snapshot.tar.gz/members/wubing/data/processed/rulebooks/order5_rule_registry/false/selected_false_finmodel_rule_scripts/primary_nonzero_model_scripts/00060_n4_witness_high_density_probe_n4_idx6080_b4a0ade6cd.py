from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":6693,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":6080,"model_key":"n4_witness_high_density_probe|n=4|idx=6080","model_order":4,"model_table":[[0,3,1,0],[2,1,1,0],[3,2,2,1],[3,2,0,3]],"primary_rank":60,"primary_unique_false_pairs":6693,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx6080.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx6080","source_bits_payload":"eNq9WLFO40AQnR32ooHjJENFx56U4ko+YURxSnktFZR8BMVGynUngdB9QD6BT8in8AlXXgf2OhEO8Zh12JknJZE98Y53d96bZ/8GBlhBwiJ9M6cf3x7A+iCkg3R414Z2cSMF4GAuBG5h2h9gCnPAvshkc2/vUdV/d32BWH+o9xIv3fFSmgm4KATqDFX/VMSxUApcSJfGSrp0PRW/EwjQ2c/tqXTjMmhnrF6sXs7nOcOVwf+Xgycww/Vc2FsNPB8+RLuF/AOnFD4q1FKI97GpujM2mdoFQnCCJpTHT4/1OoZokmzFac+mVatuytX54wpSok02XXxLOR5samTpqiYRzhAYxT5RCosvWJON8asHairF1TrutXLGitF5mDWJDn0FARmiGh3+nWR1iVJk6zQ+K7IJ/bU0tiyRerbv0SN9aFQK4aarH+qyvFironvLprec0a7RDFldFVx2FEpd/7nLanXTRW/908DgOWdoI0MAQ/ydKrfOLbIhG07tV9vRjPh2mTTKyEZy26u9kY3sCJgB2WLvI6wS2XafqxXhwZJslSHXNoVhRDa0tJGWmmVZIA3OhzfsuayNHN4rpKIrfTxo+Ul+IbgX2SaM2TpTwEbOBhtNWU5M5AHr86GszDCJ2WJjIHRspLCEhZnvJLJFBYlZipFHhScqLw3ITUugsq0hiqNRt/wL8Vuub41mhzYKsn5BIjc4yuyDI6SGnLhqR3l9kEaTLWRNg0NvjY22kXlS6D5Ptj0N7r4vSEBBMeQXJHaeC9ts6LJqHT+3vCzXMOeRbcyikFhrSDmnxlmIVy+VPsA=","source_count":468,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNq9WDtu20AQdZfSR/BRdIQcQQcwDAdIFwHawodwaVdpUwopjDmCyxQCvO5c2QT8Gyjr2Qm5lGAq4tBLeWceIAnkiDvc3XlvHvmDgXnCCbP0DZB+QnvA6wOfDtLhWRvaxYUU4Le5EDjnZX8A0M+Z+iKrzb39j6r+e+wLuPqDvZcE6Y6n0kw4OiFQZ6j6pyKORVLgWrrUVdKl66mEnYDnzn5uT6Ubl4E7Y/VicnA7zxmuDL4cvH1lM1zOhb3VwNHrqbNbyO98j/6jQi0F9801VXcHJlO7JvZR0ITy+B2oXkfvTJJNIO3ZsmrVTbk6//zklGiTTRePKcepTY1MY9UkogUxkNgnSmH2l2qyAT0HxqZSYq3jQSunq4Bi4EWT6DVU7AnYqdHh8CGrS5QiW6fxWZFN6K+lsWWJ1LPduED4oVEphIuufqjL8mytivE9m95yOrtGM2R1VXDVUSh1/Ycuq9VNF773TwODF6OhjfSeDXG8VG6dW2QjMJzar7ajGfHtKmmUkY2EtlcHIxvZETADsrneR1glsu0+VysisCXZKkOubQrDiGxkaSMtNcuyQBrcDm/YUVkbObxXhEVX+mnQ8qP8QnAvsq2AsnWmgI1cDDaaspxYyQPW531ZmQEUs7nGQOjYSGEJCzM/SmRzChIzFSMnCk9UQRoQmpaAZVuDE0fDbvkX4rdc3xrNjmwUZP2CRG5wmNkHR0gNRnHVXvL6II4mm8+aBvjeGhttI/OkMH6ebHsa3H1fkLCCYsgvSOw8F7XZKGbVOn1ueUGuYcgj25hFQbHWCHNOjbMQ/wAc6zJ2","target_count":62108}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
