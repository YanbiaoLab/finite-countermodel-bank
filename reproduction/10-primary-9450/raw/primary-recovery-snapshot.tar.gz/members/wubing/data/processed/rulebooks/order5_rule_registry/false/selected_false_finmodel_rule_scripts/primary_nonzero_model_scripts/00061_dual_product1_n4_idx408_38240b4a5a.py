from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":6689,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":408,"model_key":"dual_product1|n=4|idx=408","model_order":4,"model_table":[[0,1,1,2],[0,1,3,0],[3,0,2,3],[1,2,2,3]],"primary_rank":61,"primary_unique_false_pairs":6689,"rule_id":"false.finmodel.primary.dual_product1.n4.idx408.v1","rule_key":"false.finmodel.primary.dual_product1.n4.idx408","source_bits_payload":"eNq9WVtuKyEMxciV6B+qsgBU5aPLQFE+0n51SUS6dwPRXUCWemdgngFnmICxqkgjMjG2z7EP9K+wov/rDf2nDU+H8CBMWDH+wc5fS5ihFgQAsfBFvWHJX5PUDnTvKLXguhWVfAUx+IrsfrwS7t8cLnayDqXz4xKhKEGkTQpAMWZ4+a6esvAYStr3FIrAaOEuKPfgnldtMJVT4WQWGU019Ubil8PuTUPDGEp85iiKsphu6u2UQaVqNjRpbOPt69s0RCTZYZnIZps48vanZad0nSMYOiUIbnTqvClRyRb1Qt2IbMR8rU42Ik6myeZmSLLj0ixRwt6ZUXzMjoA5nfRkQyayAbWN6oU8dTJ1lLaOnWxqweotahdjSEGISD/6YuECXBuqWWMmyNutrLliOf/veLt8fkr53mK4udv54/t89q7e49XKjPu92T6VYMbUIech6MeDwWQhuxg2FkxfenRD1jZHadFoH2Rk7IgFMwsZuU6UMoJunS/LSG3T/OIYcwcfkY0hYK5RjXQpbFwXmb+mgCaTLYxowGR59Aoptnicn2ZQr2WkjtWCKh3tVgSy+WDksjKhR8PSxyTYMcanjuWhTRTZz2yUj8HMsIEVqzHfh9o7iOsSfKsJ1Z2miM99QU1J5J5DWh2rthNNp+o4Ya9aeJImDFY/NFqanq6+ih1lJNEi7C6ybMtIIBq7Y7jKoG/COQ5Th+HMFrGYQyL0ZINku1jd2FcCyzjZEvVkuMIg/7Vgnl7dvNZCh+JcEkuXzGGwY5QqmkUqLxK1m2wmKwxrClXlfVcbKL8gyadwcXt2nG2DhLTdvb2XyBZikpCFdVmWXgskhhPt3xaqMRWYCVlhyFKJ/B93CDy+","source_count":468,"source_output_dir":"organized/mining_outputs/out_exp120a_dual_product_followup_b","target_bits_payload":"eNq9WVtuKyEMXWoWUGUDt1JYUr9u8xFFLKMfUcUCooq/Il0Lc2dgngFnmICxqkgjMjG2z7EP9I+Trv/rDfynDE/38OBUWFH+Qc5fS5iiFhwisfBFvSHJX7PUDnTvKLUguhWTfAUg+IrscDsR7v8JWOxkHUrnRyRCMY5Im3UIbszw8l09ZeExlLTvKRQH0cLBUe5RPK/aYCanwsksMppp6o3EL4cdmoYGMZT4TFAUZTHd1Ns1g0rVbGjS0Mbb16dqiEiywzKRTTZx5O29ZacUnSMcOiU6bnTqvClRyRb1At2IbMR8rU42Ik6mySZmSLLjUi1Rwt6Zwf3MjpA5nfRkAyayIbWN6oW8djJ1lLaCnWxmweotahdjyGCISD/6YuECnhqqWaUmyMutrIliOf92O56/v639bTHcxPHy83m5eFe/8Wplxn0cZZ9KVGPqgPMQ9NeDQWUhuxg2ElVfehBD1jZHadFoH2Rk7IgFMwsZuU6UUY5unS/LSC3T/OIYc3cfkYwhoE5RjXQpbEQXmb+mwCaTLYxohGR59AopsnicX2dQr2WkjtWCKR3t0gWy+WDssjKhR+PSxyTYIcanjuWhTBTZz2ywj8HMsMEVqyHfh9k7iOsSfKsJ1Z2mAM99YU1JJJ5D2tyqthNNp+o2Ya9aeJYmDFQ/NEqanqK+ih1lJNEi5C6ybMtIJBq7YLjKoG/COQ5T9+HMFrGYQyL0ZMNku1jd2FcCyzjZEvVkuMIg/7Wgnl7dvNZCh+KcE0vnzGGwY5QamkUmLxKzm2wqKwypClXlYVcbKL8gyadwcXsWnG2DhLTcvb2XyBZispiFdVuWXokkhhPtXxaqMROYiVlh2FKJ/B/VaTR4","target_count":62108}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
