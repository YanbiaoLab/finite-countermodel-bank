from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":6681,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n9_micro_orbit_probe","model_idx":111682,"model_key":"affine_n9_micro_orbit_probe|n=9|idx=111682","model_order":9,"model_table":[[0,5,1,3,8,4,6,2,7],[8,1,6,2,4,0,5,7,3],[4,0,2,7,3,5,1,6,8],[0,5,1,3,8,4,6,2,7],[8,1,6,2,4,0,5,7,3],[4,0,2,7,3,5,1,6,8],[0,5,1,3,8,4,6,2,7],[8,1,6,2,4,0,5,7,3],[4,0,2,7,3,5,1,6,8]],"primary_rank":62,"primary_unique_false_pairs":6681,"rule_id":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx111682.v1","rule_key":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx111682","source_bits_payload":"eNrFWUuS6yAMNCotWHIEHUVHYxbv3s/mjxEYj22GmspUggO0pG4J5d/G2/F3DHSv6Y3R+xvelHtDbobzY8Kg3oRbQxx6IyNOhI2FAb21TG/CFuerF8XjBNL5aLMcjMEnKArTkrqG4j/dj2Gr77Df6ABqT1Bgi4uRCIV7UForBK8gnA0RoGCcPaa5gEL7FFC1+NlHYw+jPzFvK4deuptauRmd4ufbgWjWbWaXes0s3Q0yRPx8M85is4RsXqXNkg27CvsN2bznDsbB5zTHvNH3AmatFy5aIpd/QrY1Y3Vmo4W29GRbltnmZ+0bZJuefWxxO6wW7Hdko++peJHZ9Kt12SCz6V8E1Y0ykmdC8hFbVBeMeDV5TDaeRfZcUP110cE6uemnIICi5Fr3OI9qa+BBZoMEqyGy3V90hrgvQx6ebvHSJNliHv1ppk61+uPUDnmjGpnbCNqI0tjEtIomh8LqnVt2IlsriLwvhdla+zImKZlpI4mvyeYym7uEhqOhTVaLkQC5G4Ft1M7TImQ2jiFw6gNQgFhggEvmmos7W+KAexbi2kJm82EDbbDoiaDsl5E/gnJAPFflXoi4cI5sc1aTyXYODR6RjV29ipnaIZ6FsBHUxkftTbLF9szQakwPGwGhpSXFms5kM0kpTcB9IwzLJXVi9eFslVUYvE1t4Qo7kkKYSElqZQVNlzrz8p1tXW/Idm+hLvwCdH4JojE8QO0agy+aE4Y2frn656GN7cu3SV2IhhA93OgTX0atHkYciBBTz7pUCSWGqJonW68TDilz55xFMjthOhB8NxIamjt55ProqtVCc4ejdsvt/7qK0pXO2Fz9w4TbaFhG6ibWw+mwhNC28aVaeeDE7k8LntWmcgWLlqNp2eXin2rNAxPUxNtkU3PKrx8mCNXDzh2NVg+E7FbrX6XbFf7uzn+n9X/5K9F0g2RJ684M08DJyPj0SNC9+0l3NhC8RfPGYe90f9PwP+BF47YaLX1U0fW6jKROOdpqtPQR3mpL/QeKZUop","source_count":602,"source_output_dir":"organized/mining_outputs/out_exp106a_affine_n9_micro_orbit_probe","target_bits_payload":"eNrFWUuS6yAMvPdbDEfTUXQElixUws/mjxEYj22GmspUggO0pG4J5d8G2/F3DHKv6Y02+xvYrHuDbgbyY8LA3oRbQxxmQy1OhI2Fwb21dG9CFeerF6XjBNL5cFMQjAEnKJbSkqaG4j/dj6Gq74Df6ACqTlB4i4uhCAV6UForBK8Qnw0RoFCcPaahgIL7FGO1+NlHYw+TPzFsK4dZuptduRme4ufbQaTXbaaWek0v3Y0zRPp8M8his4RsXqX1kg27CvsN2bznDsbx5zSnvNH3AqaUFy5cIpd/QrY1Y3Vmw4W29GRbltnmZ9UbZJuefWxxNawW1Hdkw++peJHZzKt12SCzmV8E1Y0yEmZC8hFbbBeMeDV5TDaYRfZcUP110cE6uemnIIDF5Fr3OIxqa4ZBZuMEqyGy2l9Mhrgvgx6eafHiJNliHv1ppk61+uPUznmjGpnbiNuIMtTEtI0m58LqnVt2IlsriLAvRdla+zI6KZluIwmuyeYym7uEhqORSlaLkcC5G0Ft1M7TImQ2iCFw6gNggFhg4Evm6os7W+KAe5bj2kJm82HDbbCYiaDsl5E/gnJwPFflXo64aI5sc1aTyXYODRiRDVy9SpnaIZ6FsBHUxkftTbLF9szQaoAPGwGhpSXFmslk00kpdcB9IwzLJU1i9eFsm1WYvU1V4Qo1kkKeSEl2ZQWNlzrz8p1tXW9IdW+hLvwCdHgJotYwQO0agy+ak4c2frn6h6GN1cu3SVOIhhA90OgTXEatGUYcixBTz7pUCSuGqJ0nW68Tzilz55yFMjt5OhB8N5Ibmjt5hProttVCfYejasvt/7qKMpXOqFz984TbcFhGmibWw+mohNC28aVaeeDE7k8LntW6cgWIlsNp2YXin23NwxPUpNtks3PKbx4mCNvDDh2Ntg+E7Fbr36bbFf3uzn+n9X/5K9F0g2RJ604P08DJyPT0SNy9+0l3Nha8hfPGAe90f9PwP+BF47YaLX1U0fW6jMROOdpqtPQR3WpL/QfCDCcN","target_count":61974}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
