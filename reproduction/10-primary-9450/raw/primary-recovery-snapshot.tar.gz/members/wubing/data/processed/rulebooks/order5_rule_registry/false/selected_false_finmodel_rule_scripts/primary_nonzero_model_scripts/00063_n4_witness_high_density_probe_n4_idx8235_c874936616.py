from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":6637,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":8235,"model_key":"n4_witness_high_density_probe|n=4|idx=8235","model_order":4,"model_table":[[3,2,0,0],[3,2,1,0],[2,2,1,0],[3,2,1,0]],"primary_rank":63,"primary_unique_false_pairs":6637,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx8235.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx8235","source_bits_payload":"eNrtWcGOgyAQBeImeAOzH4CETfoZpPFQ97SfRBMP9tY1/YB+6gJWty7Y6qqtu+EdtKmVYQbe8Ga6R6DFSZirBAz4IQEwv34FFZgLm1x8ZlnksZXzg+B8zFikvkHngUIy8b8SWYek+Yj97z4HH5f7Dk0f6xwRqR0zV9V9AtsoeCOJBwzOnhWhTW5XVlRl+QBrL8pQ42gCZfa+9O3YgPtQVWaYuOOHEpsFZByFoKwfdZYuDNmOWUIp51lWlmSLF8mXb4fWULXjfJsVJaZ0i9MljJ21Z42hJLdu0ZRrY4sw/CRaQ5YDdShxWixFtsZQLqhxy4QyLciSR5Y7DREINIps0BzVPvmVwAhgpszBjfShjeew1stg/OcDeZGzhgP/bY/0S12vap+o2pA1xBqpqLrTQB0brYxmVyLbmRy5GvvndGMW65ugss4chC4pyjegJ8/bimHumgCqcVFTPbGSHpZCd5G7hro/Ze7KkOE2GAgICAgICHg0zuLWmTy34ItAb4/CCBVm58Kdg3Q1vcTV4P3mU3F0mmqhN7QKslG7p6WzHLZKRdi2leFMRWMRIcy09nQqXc9XbCrZVCJRM2ocEcBY40utxyPSSQNOdTVufxKE/eL7W/1Lt2b6Le7MTf3lBknes9e8mR9P9B6qWw0SGIqhoWQbxZZj+IOlV9/EOl8NDWadTSfgQp9Yrwfbd4fW6kcyeJdsJRjeb/4CdZlUxQ==","source_count":687,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWcGOgyAQ/dR+QNP1Vg8m5ZP2tPZgGj6jyRLkAzbCTZI1wAJWty7Y6qqtu+EdtKmVYQbe8GZ6EKrFFpkrVET5AZUyv/5QOzUXzil6ybLKYyvFe4TxmLFYfZPOAyBg4X+lsg5B85H7330OXi/3o5g+1qZiUDtmrqD7RLZR8EaSDxicPCtC59SuLNrF8QOsfQJDjcgEyux96NuxAfcBdplh4hHvY24WkGARgrJ+1Fk6MWSLsoJSjLMsjtmJL5Iv3/etod0R41OWxJzSE8+XMLbRnjWGitS6RXOsjS3C8C1qDVkO1KHkebIU2RpDKaLGLRPKPGFLHlnuNFAg0CiySXNU++RXISvFCTAHt9CHNp/DWi+D+Z8P5EXOGg78tz3SL3W9qn2iahPWEGmkIuhOQ3RstDKaXIlsZ3Lsauyf0y1JqW+IwjpzMLqkKD+rnjxvK4a5awIJxkUN9MQKelgq3UXuGur+lLgrw4bbICogICAgIODR2KBbZ/Lcgq9SvT0KI1SInQt2DtLV9BJXg7ebT1HkNNVCb2gVZKN2T0NnOWyVKrhtK8uZisakEpxo7elUup6vyFSygQKKZtSyYoqQxpdaj1eskwac6mrc/mSC+8X3t/qHbs30W9yZG/jLDZK0Z695Mz+f6L0EtxokMhRDQ8k2ii1R+IOlV9+UOl8NDWadTSfgQp9Srwc5dIfW6gcSeZdssRreb/4C1tgccQ==","target_count":61889}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
