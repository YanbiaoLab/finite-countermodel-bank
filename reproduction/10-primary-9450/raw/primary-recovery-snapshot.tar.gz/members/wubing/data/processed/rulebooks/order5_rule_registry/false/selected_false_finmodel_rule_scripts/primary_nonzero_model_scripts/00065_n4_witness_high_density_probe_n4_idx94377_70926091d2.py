from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":6506,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":94377,"model_key":"n4_witness_high_density_probe|n=4|idx=94377","model_order":4,"model_table":[[3,2,3,0],[3,2,1,2],[0,2,1,0],[3,1,1,0]],"primary_rank":65,"primary_unique_false_pairs":6506,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx94377.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx94377","source_bits_payload":"eNrtWMtuwjAQXK98WG4WX+BWVOIzVohD1K8yEpfeKF/QT238SJOAHQXiRKHySJBDkAc/ZmbXJ2hxdt9MkEB4IyEfCHSCa6NPgA+NpZC0ib0wikFIcP9e1J+W0k+FYW1Q4VllGEuDSezah5FIU4Zux8SlV4jEkmxvUJADplF9wSuBnNKNVblip3Y5I5swC07tZ/dtH9dl2M5QZxT4NLJZJdxSziQHs3VE1bslkgossfEJOF9kiaKWidgL3TjlRc6erb4GuBzrjdvao8nhVP4DJMWm6znfnl5GcWd6XjJrhMJkwGJ+Nzl4+7D+L1XwkGQE6IlkTB0ibDbBysHOjPvlQ721nlDeVBidGrojIE4mW/P7/k+p52haBKKRHDS+jCSd3zr1zYw6AXu3TZHEZSgoKCgoKFgV9HD3iZQ1u87JSsUGaaVP5TZjHHC4PlSxe4fBoQqWEFsoIykceIptVDbI1NZG6vHpFyTXo2WrMH7wRIZuptez+S70r5UKHeY8+PREX6N6ttfCQ1f/k8Ng4OpfhMatYIzYnlBMWbW4Ez4gAGpz9Knl3Iud4o4XDjoIbhhYb5yvIT9h1b8jtCwE","source_count":362,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWMtuwjAQ/NR+AeXWCxL+qioHVO1nIBW1/gLkG3uw7G38CHlgR4E4EVQ7EuQQ5MGPmdn1nlrs/DcgZRDfaCoHJJnhusg9mbvGUgalSL0QCshq8v/e1p+WMkwF6Nmg4rMqMJYkkdm1b6ENzhm6HdOsvUJo12T7JUYJiEb1jFcCeqULp3IFXu16QTYrVpza2+ndPTbrsO2ozigKaeSyyvqlXEgO4uyJqh9HpBU5YhEScLnIsqyWmTha2TjlVi+eraEG2B7qjTu7ownxVP4DZMUm6zkPTy8Ye2N6QTLPCGWyAWvKu8lXsA/n/1pFD8lGgJxJBtghMs0mODm4mUG/fKi3NhDqQYXRqaE7AoJssjW/7/8Ue44mbSSayIHTy0iU5a1TDmbUCdibbUokLhCDwWAwGE8FOd59GiyaXbtspeKCtJJ7vs2YBjNeH6rUvcPoUIw1xBbLSIwHHlMbVQw6t7WJenz+Bcnm4Ngqkz54tkA30+vZQhd6baVih7kMPgPRx6Se7bVw19X/7DAYufq3sXFjTBHbA4rhVUs74R0CwDZHH1rOoz0p6HjhqIOYCxDIi/c1Aw9Y9R8ozEUy","target_count":62214}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
