from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":6235,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":105782,"model_key":"n4_witness_high_density_probe|n=4|idx=105782","model_order":4,"model_table":[[0,3,0,1],[3,1,3,2],[2,3,2,1],[1,0,1,3]],"primary_rank":66,"primary_unique_false_pairs":6235,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx105782.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx105782","source_bits_payload":"eNrdWc2O4jAMtiMjhTkFxANEqAcew6zmwJFHMmhX4tjdJ+ijbpNmxA5NGKpJfFgLUaqo/eKfz47NL2AAPkOQDsM3x99A8OnGx5t4SytvISd+7cFkV9DYXXbBuoPLLvAPQMyuXPMQAD0VFgRKUnpiVFc4v4JYeMiW3sVF+JIm4CZrvTF0D6pM9+z3Pq8Kvc1VKamKaZ2eGMZ/UsxDWcYguo6XA2AvsJtCRAgaycnY4FbaG+N+j9sVcNBOUvxeRoftLDQWz0MImQgU3bllx6YVWkfOBYps0N4sSgjKZlgggxgH6zMYjy7ExqmlIXuKPLHvRJwi2gK2QruaSNfAARrgGC7NsICFL4FsIehjaHbiW5LNu40DHNEi2cKnHd2OuPKwHYDYxCzStyVbZLUfK6AYbE3tDilQ22wQb6eRZwwNs4n8jKx2fg9obcr4zVR0O/GgJn/GDKIGxgJmpYZWPBI1kTUSqYH5AyhKh4pgMmiq1pMmmrkfo9vjcjqv63DAatoRNAMSvKpqBM4mg7a3qUiMSX7ew1WrbMlzwaAXDbJ9ACmQje9kIwWyecXKVmzU/weyaVa2f1Rsn8BcsqWOikbTkKwaI7qV7Yg2b8vYFHzMsbAO/ctzxtgUXG4y+bYOKcn6c96fU46eeiqq033L2I3mScZDWPVRqVMl7/aOC0EZmgLP79HMthJNioPbe6tfkWzbYoa5WSuV6WGfp2qumzeLb5MIVDfPlCfh0Z0xWm21AkjkSsnTAnHdU7R84c+6Rd194c+6Fc+U/UnVu6v0/xHP35ph9fxPjaj961F7mnSbF5Mcq1MxeHSvLCRbprs/53P0455oGdmmy9yQztbvJmnRzr4Zn2lAEkf/agOSMPrXO0ZmhoT8IjUXpBoulxx+7dC5pEAkGJxv0Mz1MPTNVuUvGVNOoQ==","source_count":610,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrdWc2O4jAMftQ+wW6PSLuCPBJHDqPFj8GhQnkABDkNlrBib5NmxA5NGKpJfFgLUaqo/eKfz47NLwER2EqQgcM3xN9C8unGxpt4SzeLkhN7teKzK+zxlF1Ad3DZBfgjzNmVdR5CpKfCgpGSlJ4Y1TWQX2EuPISld0ERvqSJuMla7yDDgyrTPdijzatC73NVSqpyWqcnhrGfFLNSljGI1uPlINwbOU0hYkgayc5jcCsdvXc/x+0acdJOUvxuRoedUBqLhS6ETASK7jyDA98KbSDnAkUujCtkE4KyGZaYzngn1614yy7Exq6lIXuKPME3IkgRjcKt0NY+0jVwgDrZh0szLAEDm0C2EPQxNAdjW5LNuosTHtEi2cKnHd32fLNy7oTAxyzStyVbZLUdK6Dx3JraA1Ogtr8wr3Yjz0AaZhPzO7La2aMwYsr4zVR0J2NFTX6MGUQNDIz4mxpa8UjURK5MpAZmD6IoAyuCmU5TtZ400fz9GN0eF9J5XYcDqGlH0QxIsaqqkThMBm1vU2NiTMLzHq5aZUueCwbdaJDtA0iBbHAnGymQzSpWtmKj/j+QTbOy/aNi+wTmki11VPSahgTVGNGtbHvGvC1jU/Axx+I69C/PGWNTsFmZybd1SElot3l/Tjl66qmoTvdtxm40TzLowqqNSu0qebd3UAjK0BRYeItmxko0KQ5u761+RbKdixlmhWgq0wOfp2qomzeLbzMRqG6eKU/CoztjtGK1AkjkSskThaDuKdp84c+6Rd194c+6Fc+X/UnVu6v0/xHM35ph9fxPjaj961G7m3SbF5Mcq1MxeHSvWUi2THe/zefoxz3RMrJNl7khHdbvJmnRzr4Zn2lAEkf/agOSMPrXO0ZmhoTwIjUXpBoolxx47dC5pEAkGJ5v0M/18PTNVuUvMy0ilQ==","target_count":61966}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
