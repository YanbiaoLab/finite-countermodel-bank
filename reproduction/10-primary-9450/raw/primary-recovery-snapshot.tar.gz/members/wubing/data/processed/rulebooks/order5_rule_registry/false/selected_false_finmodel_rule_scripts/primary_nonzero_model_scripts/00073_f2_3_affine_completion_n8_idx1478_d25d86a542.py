from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":5454,"excluded_block_payloads":[],"law_count":62576,"model_family":"f2_3_affine_completion","model_idx":1478,"model_key":"f2_3_affine_completion|n=8|idx=1478","model_order":8,"model_table":[[0,4,6,2,2,6,4,0],[4,0,2,6,6,2,0,4],[4,0,2,6,6,2,0,4],[0,4,6,2,2,6,4,0],[0,4,6,2,2,6,4,0],[4,0,2,6,6,2,0,4],[4,0,2,6,6,2,0,4],[0,4,6,2,2,6,4,0]],"primary_rank":73,"primary_unique_false_pairs":5454,"rule_id":"false.finmodel.primary.f2_3_affine_completion.n8.idx1478.v1","rule_key":"false.finmodel.primary.f2_3_affine_completion.n8.idx1478","source_bits_payload":"eNrtmUkOwyAMRW3EgiVH8FF8NCr14AWciQSiSh3URv8tMjDYxOBPlDCBS+DJfchy4LFP0XyKVHwz5gAAAAAAAAAAAADgunD9CpTqddhWxHrUTbvpxjf9fdeq9p2JPx2LC4oJAd/ElnzqVcVRa3oiAQbJlhbDbpwlb0IkFQdOScixjV4sz45FLHlYt+l54hQT+zzsSuWcoUsMZBclvz5RmPVilYK2SOa4pU6w3VFDAtYp+G2kJxenosMvCMA9b5WCoP8ZasK3zL7s3pcCbVWyU9SVxPXvXbuLBfYxt89HkpRV1ec+sfosr1lKbLdaLXSKrL1Ws5z7B2oqy3pXc1/G8gAFuRFc","source_count":164,"source_output_dir":"organized/mining_outputs/out_exp102a_f2_3_affine_completion","target_bits_payload":"eNrtmUkOwyAMRQ9eqRzNR/ERWHqBsMuQiQSiSh3URv8tMjDYxOBPlKiBSxAsfsiy6NgnUzp5y74VcwAAAAAAAAAAAABwXbR8BXLlWrYVvhxp0266CU3/0LVKfWccTscShTAh4JvUJe96VX7U2p5IgEGyucVwHGfJm2B22UEkY4taR881z45FymlY9+l5/BST+nk45so5Q5cY8C5KYX0imfVilYK2iOe4uU6w41FDBOsU/Dbck4tT0dEXBOCWtkpG0P8MqsK3zD7v3pfEtirZKepK4vr3rt3FRINP7dPR2CVVDamPLz7zaxaZ1lsqFjpFtT0Vs5r6izWVeb1TdZ/H8gBGx1/a","target_count":62412}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
