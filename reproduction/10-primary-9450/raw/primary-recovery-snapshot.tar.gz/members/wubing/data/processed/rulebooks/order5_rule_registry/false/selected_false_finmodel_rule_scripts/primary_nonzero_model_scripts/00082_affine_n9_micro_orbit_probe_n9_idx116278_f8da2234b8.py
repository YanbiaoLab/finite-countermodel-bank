from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":4452,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n9_micro_orbit_probe","model_idx":116278,"model_key":"affine_n9_micro_orbit_probe|n=9|idx=116278","model_order":9,"model_table":[[0,0,2,0,0,2,0,0,2],[1,1,0,1,1,0,1,1,0],[2,2,1,2,2,1,2,2,1],[3,3,5,3,3,5,3,3,5],[4,4,3,4,4,3,4,4,3],[5,5,4,5,5,4,5,5,4],[6,6,8,6,6,8,6,6,8],[7,7,6,7,7,6,7,7,6],[8,8,7,8,8,7,8,8,7]],"primary_rank":82,"primary_unique_false_pairs":4452,"rule_id":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx116278.v1","rule_key":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx116278","source_bits_payload":"eNrtWUtOwzAQHVuDNKpYOD2BqbLgABzAiyxgxxE4irPrkiOw4KDYdT6GFMuNGCDVvE2sxK3rmbz3ZtweYQISfIXzi1vQAhyXM4t4AjxofebBI5FpPPDChz02CjaE1+HaYfVH2uG62Ki1KbkeXO132XFgaifCb4eX5p9mAAFBsA4Z6Qk0aF4mvs/jXYctM4sepuFLf/S3V5Q1t09kjtI5SCsxko1spBthZDxCWo2N8UrhPizUZ6KlLNd7ae/8qHQ+aCd9ErWfJ9vNKU1RrZ5BWzWmkIdsoHAXFor7UW4MpAKBQJyNocac0Ek5st7Z8jwdtARktbPlSt+I7Av+GkRZ44gg3F7tbJg1v5q59/apu09lqqs8GNgIdKrFdX6E4diczWcxtZxtxrU7WzFFNlR7JEGqgSm+g5s+V3PFttqFzRnJ/z90tu/0d7ir5nmCorOhuT/74C1GUvvk59ptsAijC5grZlAi2wWRkT9ZBPz4AFdBHNM=","source_count":248,"source_output_dir":"organized/mining_outputs/out_exp106a_affine_n9_micro_orbit_probe","target_bits_payload":"eNrtWUtOwzAQPSgLjsCyu/goHIEdLLLwATgAi6j4BI0XqBqJkT3YdT6GFMuNGCDVvE2sxK3rmbz3ZtwGaQICfYVWi1vUEe2WM4t4JNw7d+bBE4DtFfFChT32njaEu+HaYvVHuuG62KgxKbmKdO13mXFgayfSb4cX5p9mCQlJsA4Z6YEcOV4m3szjY4sdM4uep+F9s1NvV5Q1fUhkjtI5SCswkg1MpBtgZDxSWo2N8d7jISzUZKLlDdd7aV7VqHQqaCd8ErWfJ9v7KU1RrR7IGT+mkIds5PEYFor78XoMpCeBQJyNocac0Eo5st7Z8jztnQRktbPlSt+L7Av+GgBZ44gk3F7tbJg1v46591apu09lqq48GNgIXKrFXX6EodmcTWUxNZxtxrU7WzFFJlR7IEGqgS2+g5s+V9PFtlqHzVnJ/z90tu/0d7jr53mCorOhfTn74DZG0qnk505vsAiDC5grZlAi2wWRkT9ZBPz4APUwVGM=","target_count":62328}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
