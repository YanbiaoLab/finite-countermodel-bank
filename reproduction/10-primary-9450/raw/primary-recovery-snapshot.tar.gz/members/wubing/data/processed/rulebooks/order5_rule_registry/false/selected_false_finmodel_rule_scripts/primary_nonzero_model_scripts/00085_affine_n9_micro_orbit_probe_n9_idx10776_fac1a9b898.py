from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":4316,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n9_micro_orbit_probe","model_idx":10776,"model_key":"affine_n9_micro_orbit_probe|n=9|idx=10776","model_order":9,"model_table":[[0,6,3,0,6,3,0,6,3],[4,1,7,4,1,7,4,1,7],[8,5,2,8,5,2,8,5,2],[6,3,0,6,3,0,6,3,0],[1,7,4,1,7,4,1,7,4],[5,2,8,5,2,8,5,2,8],[3,0,6,3,0,6,3,0,6],[7,4,1,7,4,1,7,4,1],[2,8,5,2,8,5,2,8,5]],"primary_rank":85,"primary_unique_false_pairs":4316,"rule_id":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx10776.v1","rule_key":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx10776","source_bits_payload":"eNrtmT9u2zAUxj/KQkQDRSwZHg1XItQ7eAhaVeBgdWp6gh4h3TIUCFF4ULbU6AF6FE09h46g0UNgl6Rix39Yty5EwEn0LSZIWj+8J/LxPYogcbCloiDqZ5Bt9L3CFU5Fb4H7nmmgIihvTAPiC87HRecYyM84uo0ZM4y86WZxEJBGTOk7DndDsylae4aKhw6zoUeqqylhwrGzBKjuOANc+IcesPKCQKtWrVq1eqmqlt6qWS6lOlZpi+W6eS9hN1ZhxfL1+vxVpvWs0uaPrqsUjVilbbhuIWHvrMLKTqUBc+VPbWb16NrG9RULvSQVqM6XFpZX5TPVL+INK8AblqQUnQtco0JJhJ1tUIwlYwQNGl4JDz2McLHOiFv9qz6XUJWcKtwKMpYuVBrZov2IZxPGvsWzPL/j/SBgjPM891Nq472JGe9nnGuQwqZ8mtMgSGlkw7SPEnGbUw1SWGlWEDEJc23QPvRVfflegTS2diWNpjZgScZUmatBChvVroymfrt/TliDDBMHIpbNSdqvrynyvPXL0frEaQiSgLjgg0sZPggcuAitwJI0ZC4c6gcChDl+iHDqi+dxe3I4A1dpbIN5XnkwA2+6+rg/mIE3XH2Igxl409XHRs1mHLVefbT6H3U8nJtzZ/W2vFKm50rXraf+stlYF5lxRJ6u8niNI6buwUVOm6DdsRTE+CTi+vAvuUzxXFD4T+9AKOowYvosM9+P+6ZpxwSa+UMsNPxjP+6bppWWrzmeimJdwCScYqeSSUS+22X4SiQXbUoTOfvFO/KsDsfeHyLylsbwxP7EI2J18t1dhShT2NpWNkn5XpnK+ak68jc4uLZi","source_count":1489,"source_output_dir":"organized/mining_outputs/out_exp106a_affine_n9_micro_orbit_probe","target_bits_payload":"eNrtmT9u2zAUxm1k8Kgj6ByddJQeoHCzRYNRMECHbM0ReoKmU+WBUNUig+9QgVINj4YlBwVMBbL4laRix39Yty5EwEn0LSZIWj+8J/LxPUogqrAlzxPqZxps9P3CNU5F34GzuWnAEXAvTQPkA+5G3vIYyOs4uYgZM4z8WARxlolGTJlVFS1Tsylae4aShw6zoUdqoSlpRLGzBLjuuAdK5IcesPICQatWrVq1eqlyOsWq6XakllZp3c66eSZhl1ZhXufn+vxVps2t0nqPrnMUTVilbbiuK2HfrMLcpaMBPeVPbabz6NrG9R5dvSQVqM6XupZX5TPVK1FMHKCYuMIly1tcwYEriJ1t4I0kYwwNmlyTAnOMcbvOiFv9qz66UJWcKtw8MZIuVBrbor2J+0PG3sV93z+nsyxjjFLfz0Nu472RPp0FlGqQwoZ04PMsC3liw7TPEnHhcw1SWGlWljAJK23QvsxUfflVgTS2diVPBjZgUcBUmatBCpvUrkwGebt/TljTAMMKJJbNYTirryl8v/XL0fpEeQoRQZSg0xsZPgQqlEitwKIwZSUqnmcEglV5inSQk+dxe3I4A1dpbIN5nnswA2+6+jg7mIE3XH2Qgxl409XHRs1mHLVefbT6Hy0L3JlzZ/W2Clem50pXraf+stnYAoFxRJ6u8niNE6buwYnPm6CdsxDC+CRR5shvqEzxSnDkT+9A8OowYvos09uP+6ZpxwSa3kMsNPxjP+6bprmWrzmeimJdwESUY6eSiYi/22X4SiQXbcgjOfvFO/K+DsfFHyLylkYoyP7EI2J19LZchShT2NpWMAzpXplK6ak68jcTyLrF","target_count":61087}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
