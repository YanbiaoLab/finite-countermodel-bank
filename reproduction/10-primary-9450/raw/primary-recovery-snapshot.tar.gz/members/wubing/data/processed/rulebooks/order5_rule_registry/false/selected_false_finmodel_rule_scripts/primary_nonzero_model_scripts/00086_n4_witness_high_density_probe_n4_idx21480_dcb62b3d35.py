from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":4267,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":21480,"model_key":"n4_witness_high_density_probe|n=4|idx=21480","model_order":4,"model_table":[[0,0,0,0],[1,2,1,0],[2,2,2,2],[3,0,3,2]],"primary_rank":86,"primary_unique_false_pairs":4267,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx21480.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx21480","source_bits_payload":"eNprZGOAgzn1DHjBAQYGJiBlwrDtNh8DSSC+4f9/dSYsEhmeOdvvnuHBYlf9o////6czUAM0sDmERTIyDCFwAUrnsBOtpQZKV6J7dIEKmGKZ4OKAJiMPpVnQzTIAk1oMDAJ4rXQgIE9LYPEfHLP1/37+/3ze/n89wygYAqDhf30ckPrxHwrqn10/o08z2z78bwdRMMv+MwswKAyTgDwADDtGHoY//5GAvSDDMVplNpWJLi4t8MyWlnbmzIyZhsckmGlhm2q3yqSOjg1nzYzNt91Me3bsTM9MSWPjYxLJtLDswf/54UKCgv9ggTj/p+nn7DSgZTy0sG1O/byKR8qH7P//+f/z+fz/9v+N/6X/Of+jvoeRJpnt/3//Gpcf/1GA5P9+w9GCaBQMfwBpzh4Q/l9TW/lo/nr90RAZCsDhtJY2kEqZGuqzdM2mrpUiwZrLhEaDZRSMglEwCkbBKBjp4MEffP3OB/Pr//0fDaTBB/DHCsuPeAcqWnbgvzw+WeH/9bWMQzUgCYx2PmGlbmbDF04OQp4uLlS0bYrKJA8lJqwWMbIweCh1dnAICjIxubhwKFBuWcN/e3zSjCqC1BzfNuCzeIBdhgNsG4sCAzgDMNIhszE0DOFyBDL0Dwk19Fxdg5arH3TW79s3rHw/VEEDZKLxBBdRqm/wDSW/2UHSWj1R+UwB20AUCQWNgyeYUpnogF5fYikSmTyUsBWUxNe0P6AlJZZSiR9HSYYGTpAQkABWddva","source_count":1793,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNqr+/kfDpIb/uMF9v///wVSp/97qnz8TxJYUM/AcOMvFonp2yZ7KBl/xmJXgywDA8OM/9QA9T/3r1z27/8QAvpQevIPorU0Q+k2dI/G3wZTv/N370eTeQClf6ObdR5MXv3//z1eK/cTkKclOM4AjtkGRjYGHoMDDA3/R8EQAPUMDQuBFDsDFDRIahhfoJlt/AwVIApmGcOf9//vD5OAtAeG3b/P/5kZkMCBd/8taZXZbuft3l0Nz2wzZxobp6eds3z+hxa23Sq5nVte7m908swJT7WZkpbGxWnPzpyxfD6HFpbJMySsePvuHSMsEBPYTvFMmQm07DMtbEtuSGyXvWN7gIGZgU0igeEAwxnGGcwG7A3F/2iS2RgYNjTvZmdAAc8YCs6NFkSjYPgDSHPW/g1Dc1ObbELAhdEQGQpgv8nVK0BqdtaqzVHBvqVhr9dci3w7GiyjYBSMglEwCkbBSAfyzPj6nfIJDYwMo4E0+AD+WPnNvmA/FS2zZ3iAT/YNQ0PTv6EakARGO6V/UTez4Qun/W+37d5NRduyb+duv/sXq0X/fv/ffres/Pu7d3//7t79/T7lltUzHMAn/e/2O2qOb5//eFweu8x3sG2/7/8HZ4B/dMhs/+uHcDkCGfqHhBp6rm5Gy9XyZQ2OjsPK90MV1EMmGs2/EqVa/eNQ8ttBSFprICqf3cc2EEVCQbN/G5i6nbcfvb7EUiT+3X4XW0FJfE3LDi0psZRKH3CUZGjAnISABAD1/JVN","target_count":60783}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
