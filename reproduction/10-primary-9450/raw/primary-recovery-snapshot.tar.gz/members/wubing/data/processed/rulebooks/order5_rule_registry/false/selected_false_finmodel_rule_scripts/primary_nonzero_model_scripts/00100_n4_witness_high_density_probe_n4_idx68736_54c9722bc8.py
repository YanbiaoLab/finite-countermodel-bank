from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":3701,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":68736,"model_key":"n4_witness_high_density_probe|n=4|idx=68736","model_order":4,"model_table":[[2,2,2,3],[3,2,2,3],[0,1,2,3],[0,1,2,3]],"primary_rank":100,"primary_unique_false_pairs":3701,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx68736.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx68736","source_bits_payload":"eNrtWc1u2zAMpgQdmJ3kYA8gGx7Qx1ANHZKd+kja4INza4M9QB91JCVbceMEG5p2AWYih0Q2RZHi38co8I+wRL/ao4cm/+jBwN3Tk91pFeWr2xjQ79nrtX0J26o67pqm26I3wwAVWQNr+HZoj8MQQVsQAxlAsOABHrD9AT62R8Bno0E1jedn/LlEX/TeEbMi4zKv7CRkNTrS5FyFeEzP/Vap+ZMeiAdiegpKePG6krVIIEEaDPEIicg4veKv8UcHzjgPK6200korrbTSe+lhT71AiNxlUB9hxz7CLxVzd2ibRl4f0HLNt3o14EhfDTVozm8RjDSGVeWA+1gj3aE0a2Q1aXmS1fj1pY0KY6MNN0dxNe5KK72Bi4KV9iHsmsOAVdU0IWDdpxT1EkKfFnvbPQu0IvDkgxnAKo9qGGxVNx3WhoJNU8KrOdgCDOB6IBbokMEX/YBHa+IxTIL2bcWcvH3dWxHEqdOmRdshIRvtGcNR1HKKpDxqVZIBRUYIEQni9ZZTKOfamiEVOPr2dCyCWJkQZPve/mxtxDFHA/Fr9HIurQY41cNQoiGYRTIomRDWkrzjNIPIDhWJoAMICiP89307CZpbTSAnK1MgJ+E8BIKQVV50vCRqGpB3EiBUeWtBc0pSmU1JzO+bSdDcanI9GfkqRr6OP4pSJ6k1yRgg6QG2UhoCH28yBaDiA8WUYe21yuZnbkMbE6w8r2zlcMxIMjoUB6KjkBFr9hOALqno8HPd/9UJ5p8KjliNtHd8PVYKjtw+ndAujAhID5Rzq8JYqk5Pumc0z2MYl2czc19LVuPrGa2WKts82MRWLIO8EpMMOoI6qWwcbDoNB6TMmTW33Yj8Y2k8WgsoMSNRvOA26PIUy0/dBgebXE1h5GBLM6YUbOP86NOpjhzxafBER88ZQn/MgV7b1K7t3Nt2Te8ad2tpfdZIUai6OGZTzLOxvHSrOOHKtglLe6E7RJDS4HzoI6j+/dLymFEZW3radGG8lAaDuY7cgLqTXe3kIQaWdrfjLLJMFxcyuruX0EaVNJpiINttaR674EmsR7L/ZO44GmCMIFVc7HqwpaXEkUWqma0m74pzc8MkcqUPoPNgw4vBtuBJ5ZbTO/7tbabLw3+hmkc5/oJs+VtBz32NW1jqlKH048vaXByQbJLV2mqxuJwnhZ3bDBfu5E8rm2yas9ZpkMxVln6c2+TSj/+VrE+mXs5ffO1Clp3yDzupua/E+z+2kfuGu/xZP8DYtof5v5WOe3h7x0VzgX4DC6/elA==","source_count":1793,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWc1u2zAMftQ+wJD2Fh+MTY/U05KD4OoxCsyw9QBDrNPCgyBxJCVbceMEG5p2AWYih0Q2RZHi38dENC+4RF/ajcEu/6jR493Ts9uHqOSrPXoM79nroX3Uh2HY7LuuOYDxVYUDWQN6/LFtN1WlMDgUA3kEdGgQX6H9hka1G4QnHzB2neFn/LlEv8LOEnMk4zKv7CTkAljS5FwFtUnPzSHG+ZMaiQdVeopReOG6kr1IIEEBPfEIiUg1vWKu8SuL1luDK6200korrbTSe+l1R72AVtxlUB/hxj7CLBVzu227Tl6vwHHNd2E14Eg/PTVo1hwAvTSGw2CR+1gv3aE0a2Q1aXmS1fj1pY0KYxc8N0dqNe5KK72Bi4KVdlrvu20Fw9B1WkNfpxT1qHWdFmvXPAm0IvBktK/QRQOxqtzQdw30noItUMLrOdg0VmhrJBZsgMEX/cAX59VGT4J27cCcvH1fOxHEqdOlRdcAIZtgGMNR1HKKpDzqYpKBRYbWCgji1Y5TKOfaniEVWvr2vCmCWBmtZfvafW2dgjFHI/EHMHKuECs81cNToiGYRTIomRDWkrxjA4PIBiKJoAMICiP89/0wCZpbTSAnK1MgJ+E8QIKQQ160vCRqepR3EiCMeWtBc1FSmUtJzOy6SdDcanI9GflGRr6WP5FSJ6k1yagw6YFuiAE1H28yBULkA6mUYd21ymZmbkMbE6w8r2zlcMxIMhoQB6KjkBF79hPEJqlo4XPd/8EK5p8KjliNtLd8PU4Kjtw+ndAtjAhID5Bzx8JYqk5Numc0z2MYm2czc19LVuPrGa2WKts82MRWLIO8EpIMOkI8qWwcbCENB6TM+TW33YjMS2k8WocgMSNRvOA2YPMUy0zdBgebXE1h5GBLM6YUbOP86NOpVxzxafBER88ZInzMgR7a1K7t7dt2Lew7e2tpddYoUqhaNWZTyLOxvHSrOOHKdtRLe4HdKpTSYI2uFcb6/dLymDF6V3radGG8lAaDuY7cgJqTXd3kIR6XdnfjLLJMFxcyur2X0IaYNJpiINttaR674EmsR7L/ZG41GmCMoFhc7HqwpaXEkUXGma0m71Jzc+MkcqUPoPNgg4vBtuBJ5ZbTO+btbabLg3+hmgE5/oJs+VshzH2NW1jqlLH048vaXByQHJPV2mGxuJwnhb09Vhfu5E8rm2yas9ZpkMxVln6c2+TSj/+VrE+mWs5ffO1Clp3yDzupv6/E+z+2kbuOu/xZP8DYtsb5v5WWe3h3x0VzgX4DQNGSkw==","target_count":60783}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
