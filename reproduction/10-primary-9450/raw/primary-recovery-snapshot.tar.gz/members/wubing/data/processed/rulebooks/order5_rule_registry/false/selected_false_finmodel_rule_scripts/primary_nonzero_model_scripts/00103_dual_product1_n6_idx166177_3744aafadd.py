from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":3555,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":166177,"model_key":"dual_product1|n=6|idx=166177","model_order":6,"model_table":[[3,4,3,3,3,3],[3,3,3,3,3,3],[3,3,5,3,3,3],[3,3,3,3,3,3],[3,3,5,3,3,3],[3,4,3,3,3,3]],"primary_rank":103,"primary_unique_false_pairs":3555,"rule_id":"false.finmodel.primary.dual_product1.n6.idx166177.v1","rule_key":"false.finmodel.primary.dual_product1.n6.idx166177","source_bits_payload":"eNpjZBgFowAN/PiPDPInp5pGSm5co6atPO1qSuqRJK3eGVrK00ScZ/iyARUHnE3qEVIaDbRRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBgFo2CYgQP/R8EQBOvn153S/HfR1X6vzS/N5T/c9fsfybfacD2qf7Fofpzc3ynBfxZPd//Y7yTH+tG+5KK/fj9Y+enFP9wV+5t+yFcpfvF/8fSi+BPn/y2POI/ac82vefE08M/iCe6Of/hrHe1E7H4GCPx3dpzAz8r08f8CiJ3smKnnD1GOJS1FfsClqYEoy+RJs+0fLk0fiLKNmZzMxozLGQRAPWlei7AHpQNlLM4gKtmwkGYbANwp0FY=","source_count":5818,"source_output_dir":"organized/mining_outputs/out_exp119a_dual_product_followup_a","target_bits_payload":"eNr7938UjAI0wM6ADCbkzDq17Jlf8M0rdzK1Zs+ynnu1KP3qnczXe9I3/QQqXm80t/jt3dFAGwWjYBSMglEwCkbBKBgFo2AUjIJRMApGwSgYBaNgFIyCUTAKhhmwZxgFQxAEJDSaXmPU23XA6TDrtQj2HRcKZB9UHf4q2yAem7DwIVP2GuaYjB18BXsf/uI70K234UIBWLlJDPuOewW17A9a73FvEJfSeyG9h6Fa9pvVga8JzeJS65hj8nfsY/7QtO/g64Ns698z7NmX/+HXXz6GeIidPzBTDzNRjiUtRfLj0lRPlGUPSLONEZcmfqJs+0NOZvuDyxkEQANpXlt+AJQO7mBxBlHJ5jdptgEAcEig0Q==","target_count":56758}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
