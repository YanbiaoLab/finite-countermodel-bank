from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":3510,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n9_micro_orbit_probe","model_idx":118557,"model_key":"affine_n9_micro_orbit_probe|n=9|idx=118557","model_order":9,"model_table":[[0,0,0,0,0,0,0,0,0],[0,0,2,0,0,2,0,0,0],[0,1,0,0,1,0,0,0,0],[0,0,0,0,0,0,0,0,0],[0,0,2,0,0,0,0,0,0],[0,1,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0],[0,0,0,0,0,1,0,0,2],[0,0,0,0,2,0,0,1,0]],"primary_rank":106,"primary_unique_false_pairs":3510,"rule_id":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx118557.v1","rule_key":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx118557","source_bits_payload":"eNpjZGBgaGAgBJZ0gMgDBxgZRgE9wASzWxqLDJwxJRrmH1f9370Hi5Y/nUa/7HsEMCUSXn5w8HPgx6LFfvXJf/KGrJgSCzqgjAAnFgYGCQsGBSi/gIGPAWGSwwOBBsaE0dgaBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBgBIHNxr9ku6y0X3crbzbo0zly4u9DAObGtqZiPiQaWPXj+8f9/Y/t//+ufgUfDKow/////f7/hM2laeO3P/+Jf9msu/BefKvELaM1/5VYnub//+Zs0OWhgWQPQgkrX2h1v6ieLgyz7n3rk//+J4U4r9GnhtQ+fb73/PzP6f7158etN/93j5s60rv7+/7/EYx1a2Pbv//94EzeN5f+zOf6CvLbB6f//x5yshwVYaGDZgf//G+w55P40MV9oBgckI4Ncwx/uhgPstPDaD/Hab//lF/7/vkt9yuX/H1se8V+V/v1ffp+zAC1s+/9/jlGXpslFV+W2fyCvdSyc4K7Y1mTARYvMlvDyw2V/F/66X50vDjJbMtr+4BD4r/FP0OEFM20ym/7v/0ev/K88Gg7ObF+PvOr8+19/vgEXbTKbfaVrzY438hMhmc215e9sYGbrGBaZbfrfr59ebN/zSB6c2eqdvh55Ft/qb0eLzOZwK2NxxyEeTkwZLOlfMDckCKx8qgiXsYiTBscxBQXSMltlzKf9J7gZiPHJg/82SnYg5d3qSl9c/v0XdrIjcQ6rflHPP35l4kLtj30g50KQcpEgjSMX/v9XkGgiObMh5moI5OaG7hKFCrByOaYD3ByVLAy/SM1sa9R+1x8RYSCm2PhQH2Y4FaQ8RHKjUdL//92KPaSVNg3AxoFgq2RXxuJJTtKuImkrlgTMWCjg5GjAxogrpVCU2XY8qQfm6ueCHx9O+u8aZyO4UP3T//kCn8BptIHamc1F8q+824v/nV4cqV/qJRZOcFIElszsB2lTs1162DinQS5mCfPBZvYipqoPAgxxDieUGS6w4wpCghGFJzx+RPp++9+x8v/mrpUmN/8rLzvVMVXw9/94nkQRcManst8AYBJ0WA==","source_count":2942,"source_output_dir":"organized/mining_outputs/out_exp106a_affine_n9_micro_orbit_probe","target_bits_payload":"eNr79/////r/hEB0OYi0t//3fxTQA+SfVL0ee34PpkR9gsUthhJnLFqYy86yHih+jykxX4x//8b9H7BoORBixvjg3C9MifhyKGP93t///z8//v8+lN///+N/hEn75d/X/5s/GlujYBSMglEwCkbBKBgFo2AUjIJRMApGwSgYBSMATIspOul6xFtvZ0fFydLrxvpKcef3zKus7fn4lwaWyUvwMTCcOcDI0CAJHg1rP8PDwMDgcE7yCS28xszQw3ogWJ/hRdZzVqA1DHeq9j5kYvhQe+07DSyrB1rQtqvJXbgh5wXIMoZZ1gwMeSv2hl+ghdf4eVQFGNKWMDSc6BHxZdixMCntSAsHA8Nzmcu0sI2RgWHB6Z3XIximfGcCec1/LwODzLdfNu9/08AyewaG+gPfHzLX/tGvAQfkv/8P65m/1Nv/oIXX2F80cTI8iGPgcL2RrcPAVy37QesJC8MDxz3vaWEbA0Py2dJrp/V23alkBHmtPC5/x73K2vNfaZHZ5ovx62zY/aGRtUzc7s+xf4fYv79nuM74br/4H9pktgssDFbaDG1WK8CZjctatIyJ4ULC+a+0yWwH2nY1uws/yINktl3VTCnAzFY+LDJbBhMXr7iHs+wDcGZr2MtlLbmgasNBWmS2/arTY8ptP3/DlMGS/t9NWr0WrDzr9dczr/de/255/z5pma1tMa+D+Zf/xPhEnuHw3YMg5SU37nLvZmR4s/cgiXNYDbHFjB/uEBdqzAfWfYsDKX+99rq1PgPD/ee1JGc2xFwNgdxcX9J9vx2s/OFf+y/f237/ZyU1swXfZGmwfv2fmGKDv2HluSyQ8tXP/M7OZWAouVdMWmlTD2wcvKt6Vjo9Jnfvk12vZ4ZHr0+Pe7933/mf/3ClFIoym7t0AzBXS7zjk8tl2LXw8Lu4G7wMCe95wWm0ntqZbfczpgc7xRnKtn6fxd3wPC5/7z1gyfzDjjY1m65cXXL9w8XRf+xqfvT+beV//3/hfvM7//V/4ApCghGFJzzYl23iZCgPY/ApDTutxnAn0rQ86x0Lw4LP816DMz6V/QYA7F/8zw==","target_count":59634}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
