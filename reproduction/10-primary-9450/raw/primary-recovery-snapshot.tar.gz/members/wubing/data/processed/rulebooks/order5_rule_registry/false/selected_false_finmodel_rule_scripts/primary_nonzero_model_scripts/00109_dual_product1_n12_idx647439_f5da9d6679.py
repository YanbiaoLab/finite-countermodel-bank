from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":3457,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":647439,"model_key":"dual_product1|n=12|idx=647439","model_order":12,"model_table":[[4,4,4,4,4,4,1,4,4,4,4,4],[4,4,4,4,4,4,4,2,4,4,4,4],[4,4,4,4,4,4,4,4,3,4,4,4],[4,4,4,4,4,4,4,4,4,4,4,4],[4,4,4,4,4,4,4,4,4,4,4,4],[4,4,4,4,4,4,4,4,4,4,4,0],[4,4,4,4,4,4,4,4,4,4,4,0],[4,4,4,4,4,4,1,4,4,4,4,4],[4,4,4,4,4,4,4,2,4,4,4,4],[4,4,4,4,4,4,4,4,3,4,4,4],[4,4,4,4,4,4,4,4,4,4,4,4],[4,4,4,4,4,4,4,4,4,4,5,4]],"primary_rank":109,"primary_unique_false_pairs":3457,"rule_id":"false.finmodel.primary.dual_product1.n12.idx647439.v1","rule_key":"false.finmodel.primary.dual_product1.n12.idx647439","source_bits_payload":"eNrtlT1Lw1AUhhMsVLsI6iQF0c1fIC7mH4hapxbtoFBwEa0ipcR0cxB06dahg5sdRKR+IG26iFIoTh0USrvoIDbpZCK3ucd+LEJ6kRBuFTnPkAwnyZP78Z4rCoKQEH6iCWLrWigOCUg/aEAHeyHRLXh7LVEbyV6odV8R7RVF1akU7/EtE74Tnl1JBh5ODrd9sZ3F+cnj1cG7UV9szPO58LKcnF73tP5qZArXDEEQBEEQBEEQBEEQ5F8DLLwcZDWmjcfQmizZBAdZgjm0AQ62Bkum8JhIyrINc5AVmBMpcrCZLJmEYcOw/VLYLAAdgLbvbYuhU1BB9fY1bMhfxsoTeK8AKctEg4s9payVLNg8kjWw3vKyAU+36obxSmHmfs6A/d1q5/FwNh4FSK2lCUhKRgsF6xHpikI6FyrK9bPn3A1A6fzRKi9d5gPBaHqr5YmMH1jXTsJG3XYbJ2EruO42Tk420223cXSyue42JunsAzAy5KMCEZ2eVlIEqn7i73VU2LaNw27zBXmbd58=","source_count":9192,"source_output_dir":"organized/mining_outputs/out_exp119a_dual_product_followup_a","target_bits_payload":"eNr79/////r/hAAzwz8gaW/67f8ooAfgZwADTIl6iMQPbFEEAgcwJeQhWv5hyjQ4CDAeaMFiFjsDMlhwbFH2GvOYkt6vbd3rNt4rWPjd6s3Xtte/2dZLrc6+Nvs30FVv747G2SgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBsAYMuMAPGlgmj9M2WniNGZdlD2hgWT1Or/2hgW38uCxroEVAMuKy7QMNLLPHGZD/aGAbOy7LDoxmttHMNkCZjYmBQYCBgRFEg2zhEGBkcGBw+EHXzDYKBjNgcmRhEFZiYNFqYhFk8Olo0BI0YmKYUNgkyMAk6tjEwaDm4jCVQ5KR4YTFQQ6Gxi4FsPIFXi09DAwpcxJYGA40hAguWSo044AHI0OC0xLTJqEAVSc3BgYjPwMmrbWejmuW9iT0Ae2Z8bSCyZ2UzMZIaWlDSmazp7i0IaVmY6e0tCGpZqO4tGFnAacDBo4QFk4lhhkCjKFKKSwMCo9ZHmOrKjCSDYmlDQDS1vmI","target_count":53384}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
