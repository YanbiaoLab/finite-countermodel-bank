from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":3342,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n9_micro_orbit_probe","model_idx":108424,"model_key":"affine_n9_micro_orbit_probe|n=9|idx=108424","model_order":9,"model_table":[[0,1,2,6,7,8,3,4,5],[3,1,8,0,7,5,6,4,2],[6,1,5,3,7,2,0,4,8],[0,1,2,6,7,8,3,4,5],[3,1,8,0,7,5,6,4,2],[6,1,5,3,7,2,0,4,8],[0,1,2,6,7,8,3,4,5],[3,1,8,0,7,5,6,4,2],[6,1,5,3,7,2,0,4,8]],"primary_rank":111,"primary_unique_false_pairs":3342,"rule_id":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx108424.v1","rule_key":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx108424","source_bits_payload":"eNrtWdtuIyEMNYgHHvkE9k/QfhmV+uGLL9iEcaZNW6XSZqxuuoEZDMcX7NO3DirvUBrE1iokiHCUlhuEBClBHt/wiQyB32/wNckhDZ2QSocOsUAdK3Vcu+U6BmB8JJqFML4lKCdrlTi2N3aUxkMh1bHq2F8Zy/Xexv8SbTZUKDQ1lhxrp/FOXWaB5vDnV6UgEgOGhr8Cj9UvrlUR4QD4ORBFRARk+EPfCWeeFZBB/30gCbEDNErUbT5JciDXILDaje6Yd2c0T5IjljunQXBcTw5vYybzHPo+zKixEQ2Y1KF1fJxgaTM2LM5M+xpkEV5AOhlA0oY4WFfvJtTEFIIThabho9BZCLN9dkte8rPBZtmjSZLIZAwMNsq6nFXQEJh6Kdh4sMOSuzW9L8EWyF6F4yRqWmJFWd7AFVjRGJkbqODdD44Omc7kN53VZFYo2ZEVhblpnCFFeBjZQPKuKU+HQWHnCpwl3hdFVTeNM0fUSBFeyOc6FAo7V2WFvSyKkm46uKiRIrTmqQ6Dws6VWKFcWZmCc9YPQaN6ptWswbzVDuv1lmdi4JtlTY3lRYLNK4k+5TbTbHGaranZdv+3GsDxtc+5jaeDt3Lw/6dbTspZRI0yh+y6evUAJQECQM9hmcACQbBIa6j1X/DK+6WuWlMt4wGgJrWAXkqjGz9BV4pcNY+o5uJmxmUZn4EraMic/L0iWyK5rC/O0ihKrpp5YLYfThW1lOpcqFewfZ3r4P1RYVjFXJmri7wowsPYo4eewAXA06FQqKdQIsxSRn4SNQcAV8eEwkCkVBpqXRR9iJoDgKdDoTAQ0zd6k0suueSSSy55hNHiCoeuu5BuuJ8qBJAVoZMAOhXraI+0UDIarq5UjUcbdutRFk6ibZ3NNt1fw2wxcq+YFgYuArhDVIsoWkGgkzLkpiPcwQtXfPxwsN0jSJwh6he7RlOFhVQ23lmD7UD/3CdInCGHuHZ1TPpob39PCBJnyOHPXR0Kxdb+jp7NVr2ByEXtQLX5OiYUO/0Df5dVbyDyUDtSba4OhWKjf55OkFDvfmx+HerfGzrh+e9S/07v51D/ztAp7d9fKI8I9e8kdof6d4baAtpKC27+9//zg/KXUSdFeRzucegxflzYSCdrOdS/M/QYP/4P8Ki5AQ==","source_count":1489,"source_output_dir":"organized/mining_outputs/out_exp106a_affine_n9_micro_orbit_probe","target_bits_payload":"eNrtWdtuIyEM/fBK5ctW/MnyCTzygMCLL9iEcaZNW6XSZqxuuoEZDMcX7NP3ACpvkCO0GBNUaHCUWCL0CrVCGd/wiQKd34/wNSm9Dp1Qc4AALUMaKwVcO5Y0BmB8VJqFPr5VyCdr5Ta2N3ZUx0O9prHq2F8ey4UQx/8qbbYnyDQ1lhxr1/FOWmaB5vDnVyUjEgOGiL86j6UvrpUQ4Q74ORBFRARk+EvfCWeeFZBB/30gFbEDNErTbT5JSifXILDije5Wdmc0T5Ij5junQXBcT+7vY6bwHPo+zKixEQ2YGiAGfJxgiTM2LM5M+xpkDV5AAhlA0oY4WFDvJtTEFIIThabho9BZCLN9dkte8rPBZtkjSpIoZAwMNsq6nFXQEJh6Kdh4MMCSuzW9L8HWyV6Z46RpWmJFRd7AFVjRGJkbSODdD44OmS7kN4HVFFYo2ZEV9blpnCFFeBjZQPWuKU+HQWHn6pwl3hZFSTeNM0fUSBFeyOc6FAo7V2KFIS+Kqm66u6iRIrTmqQ6Dws5VWaFcWYWCc9YPXaN6ptWiwbzVDuv1VmZi4JtlTY35RYLNK4k+5TbTbG2aLarZdv+3GsDxtc+5jaeDt3Lw/6dbTspZRI0yh+w6efUAJQECQM9hmcACQbCoa6iFX/DK+6WuWlMt4wGgJrWAXkqjGz9BV2pcNY+o5uJmxmUen50raCic/L0iWyI5ry/O0qhJrpp5YLYfThW1lOpcqCewfZ3r4P1RYZjEXIWri7IowsPYo4eewAXA06FQqKdQIixSRn4SNQcAV8eEwkCkVNpTWhR9iJoDgKdDoTAQ6zd6k0suueSSSy55hNHiCoeuu15vuJ8kBJAVoZMAOhXraI+0UDUaLq1UjUcbButRFk4ibp3NNh1ew2ytca9YFwauAbhDVIsoWl2gkzLkpiPcwetXfPxwsN0jSJwh6heDRlOChVQ23lmD7UD/3CdInCGHuHZ1TPpob39PCBJnyOHPXR0Kxdb+jp7NVr2ByEXtQLX5OiYUO/0Df5ZVbyDyUDtSba4OhWKjf55OkFDvfmx+HerfGzrh+e9S/07v51D/ztAp7R9eKI8I9e8kdof6d4biAtpKC27+9//zg/KXUSdFeRzucegxflzYSCdrOdS/M/QYP/4PW8m4Jg==","target_count":61087}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
