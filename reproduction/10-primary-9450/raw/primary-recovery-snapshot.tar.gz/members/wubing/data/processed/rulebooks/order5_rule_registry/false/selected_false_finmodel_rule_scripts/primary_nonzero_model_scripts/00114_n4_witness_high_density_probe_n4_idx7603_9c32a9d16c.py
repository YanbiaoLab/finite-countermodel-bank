from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":3153,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":7603,"model_key":"n4_witness_high_density_probe|n=4|idx=7603","model_order":4,"model_table":[[3,0,0,0],[1,0,1,1],[2,2,2,2],[3,3,3,1]],"primary_rank":114,"primary_unique_false_pairs":3153,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx7603.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx7603","source_bits_payload":"eNrtmT1Lw0AYx++OA6+gkMSXte0ZB0XQ0fEsGRoV2kUUrCji4OLgJjj0hICpLrY6tFCkOvkJdC2C36O4uTkKgjWX+AL1WhEbbMr9hjzQK/0nz93z9O6fQwQ+qZqgIwwC8e0RcDMPfscGX8QJ2cCObRYtC38fqB/QwsQUBd2AI2aASJENAlpCf/+tmglFwBprHUnCIH5Lv+ZfyY95DVbFv2RozvbvIP9aqUAGFNGAN/OiEp/jkAAxgQmKQlR7ah6J8PJIxxH6Wtf9QD3fyMNBkKMc8gE8C55EdUOAQyq2jOjSjlly3VPL0HVKLct1tRSBYahNnHwKldKUpizHJbqeIskwxGq7Z8sfQmO291jXmp6knlgoqazOXOw/jKcMT2iVFlwy6qeSJJ1Qiu32fiWTs9JbhWOyNr2nX17dWc4xmXQ01YgU/U+wna0Pe8WmkhEZmE1jXhCbVi4mUNOhSopCoVAoFIqG2W5LIE42m/H1bbXh60EWkN1hFJfVpPUiNbMonJg2xcYMwt594K5wbgonRmIKMgNiQBJcuFwI4J/N6Z4ji9L0UHrb/oeipbHuqSEAO73N4RFekYH1L1kB0qO+3WdPH1V4W6df8m+Oy1hlrA3M9jMp6RWS1olI4m9qJOaHIdxqGjMQw1jayVpwf6H2BiylWzM=","source_count":765,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmT1Lw0AYxxUEx25u0u8hSFf9BE5aRNBBq4s2QqDXQXBzcHEQUayguLSgpkOoNzoqiA5Nr+3qSxJQ6AnH3ZlLfIF6bREbbMr9hjzQK/0nz93z9O6fDOVfzFm8LZBx8e0nPnnJf8cBOCc12cCOYS2bJvk5kNhA6fId4t0AUGjzSJEPAj2jf/+tpMVEIC5sHqmyIP5Iv+tfcce8BqviXzJ0Zfh3kB2cn2eQK6IBGMiKShyuM8zFBNYQDVEtNrAuwtAIqlD6va77gUQ2nmWvPIcAA2/kmsdEdTNOQiq2gujSupXStBXTdhyETFPT3BJmYaiVV7+EUkWESqauYccp4WoYYsntpdNPoQfDe6wp16kiTyyUVM7dzG6OVkq2J3SM0hp+9FOJq3ooxTYxdlLImcW99Bo+ut1yZqbHTX0N3+uuakSK/ifYziaevWJTyYgM0EANL4hNKxAT6DpMJUWhUCgUCkXcarUlECeb/frhrtrw9SAX1GgzShbUpPUiSWtZODEtig3aGH74wF1h0RJOjMQUhDYjHNeAcLkoJ53N6Z4jT4soI71t/0PR0mD31Chn7d7mgAivyMD6l6wA6VHf6LOnjyqgpdMv+TcnC0RlrAXQ8DMp6RWS1klx7W9quOGHF9JsGkPeIETayZrQfqH2Dh/bFgM=","target_count":61811}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
