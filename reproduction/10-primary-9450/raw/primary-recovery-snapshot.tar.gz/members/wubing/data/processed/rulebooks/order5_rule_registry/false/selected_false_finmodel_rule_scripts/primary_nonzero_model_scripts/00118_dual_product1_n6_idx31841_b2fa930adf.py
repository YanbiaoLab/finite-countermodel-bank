from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":3052,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":31841,"model_key":"dual_product1|n=6|idx=31841","model_order":6,"model_table":[[0,2,0,1,2,2],[2,1,1,2,1,2],[2,2,2,1,2,2],[4,5,5,3,5,3],[5,4,5,5,4,4],[4,5,5,5,5,5]],"primary_rank":118,"primary_unique_false_pairs":3052,"rule_id":"false.finmodel.primary.dual_product1.n6.idx31841.v1","rule_key":"false.finmodel.primary.dual_product1.n6.idx31841","source_bits_payload":"eNrdWbFKA0EQ3V1PPRHCmWCdi54kjY3Yu8gFohZaCXYWFpYW9m6hkKvEQ6wE/QArsbK6xsJG8gnBytIyRXCNySFKMpeLt3mFU1zYTJa3bzJvdjI5Y5KxiLMvW+0+ZffJrN8Lt7voLtvTbLA11zjhKQvCUdkjHHKL2pIj3mcNyqEoR0xygN2SnhLF0aZ2SBKeosiOqK1qitoaH9jqc7i9F68fhcd+kmsfMTfhY5HWmsGspfX5sIObsw61YssGgTU7aIX5ORBaW+uT10WBAVNaskdYjrzf2PsrMLSXwrbvoDIyCppBWaCoVTa8i6qP4rYUePf1Ogjs9uDiKT+HEtvD3f3mwgJKbFf+7l7VR4mtyID2UQCCRQGSGtkSjcWWZ4BgTSSzuJ0FmZpAojWggVxnHAcmmatwaDY0kBwJ5kKpXXohLpYq9PMc1vzvCBv4zXXE5jkwsdU6YsO1kdD8L/F/KzYLCaYcCURzmA2MpUAGUkJzBHuz6WSxvRkNND1n7CXss1Fq1zbwUlfhJLDONEJkncklAh0bFhvdj6sfY9Sxi81yzCufzDglzdcZehIe1sxPMk4pNClmLNPXHv07ozYGsdFNXa+VNctO0BXESjzMXyz+/0imU4bMWGoOaRXMppOmPbLY3FQ0pDtCjiWUdydVgDJPbqyRTpYxP78HJCJjjNLdbNCeK6YkeKpcF9nudfmzRA1PyYyNaCwV3n/AAWyFlbGF+AQ18le9","source_count":676,"source_output_dir":"organized/mining_outputs/out_exp119a_dual_product_followup_a","target_bits_payload":"eNrdWbFKA0EQXUmR0tJK8gnBxsImlZVY+QERrEQuWJ2gxdpbWFpY2AWstFADHrL2YmMT8dRLLUmOgHjqubvG5JDIZc6Lt3mFU1zYTJa3bzJvdjLZ1ELrktJfdtV7it5Thz8XXm/RW+Ze9XArXCrCcysJR71KOMQJtaVDvK+LlINTjojkECuTnkeKY0DtECQ8RVHvUlv5G7U1OnAYc3j9FzeOoiI/yTVGzEv4WIkxpmGWZ2z9t4Obsy61Rj4AgRW6aM2nNggtx9j29L3EgHEm9DwsRyaXg4NrGNpM89jxURlZsgv2rURRq5+5lXMHxe3Odhc3NkBg5f3KXKuNEtvC0uLpwwNKbKvOYfXcQYmtoYE20QSClWwkNbIlGovdvADBCkhmUTsLMv6BRCtCA3mhFQ5MaI/j0AJoIBUSzINSW3MtXCy55bQUrPk/kgHwm+uKzfVhYqt1xYZrI6H5/6j+rdhCJBj3BRDN1wEwlhIZSAHNEezNxpLFNmU00PScsZ+ws0aprQTAS51b78A6U7SQdaaTCLRjWGx0P84HxqhjF1vom1c+mXFcmK8z9CTcqpmfZGxRaEK+hKavPfp3Rm0MYqObun4ra5adpCtImHiYv1j0/5FIpwyRsdTs0Sp4TifNYGSxealoCG+EHEso736qAGWe3IQjnSxjfn4PSGTGGKW72aA9V0RJqlS5LrPd62KwRP2ekhkb0UgqKn7AIWxlmLGF+AQWjhl5","target_count":61900}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
