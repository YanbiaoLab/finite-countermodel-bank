from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":2970,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":51989,"model_key":"n4_witness_high_density_probe|n=4|idx=51989","model_order":4,"model_table":[[0,1,2,3],[0,1,2,2],[0,1,2,0],[0,0,0,3]],"primary_rank":121,"primary_unique_false_pairs":2970,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx51989.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx51989","source_bits_payload":"eNq9WUtu5CAQBcSCzApbOQBtOVKOgVpe2FnlSLTkkdy7xMoB5qjDx8bYFJ22/GGRqIXbryjqvXrQf5HESCI7Xu1fyey/n5KbDy/CfKCoNB+wdB8S419qAl1SE++NgCcGYGAQhOGJT1QTcEJxibCOOn5ji8w3JLCU8rvKs4zXhNhHlJ95u5d91ykXyXwppQ5MlePTgkxLUfpZqqOwE9x/5QM1aAiLzkCGR/IoMuVeymUeL8XOUxICuKXcErv25uJUKE4bCxc2fZpn0MU7xijRmeP9VLTLmWDDhp00fhA5D0ydWiVJQThkXLXG8JDERw7JxEMp3plsjZbDitJeDdJ2KFpSYY8h27dJYj+iKXYw2fTG2W5kcfChZMttl/BAx+7a0HTwORX5x7Wjl5PIZv+ZBn4K2cxGKc+BY0ngPMBXpTeOHN7EhasSD8QWs/uOV8tqywHbB7IsnC33rVQFrQgdpdFDZ2viMMrDOltoYk2x0GEXiW1F6tEuslVkC4AI0xVjBFPBr9m8hwx7oEUY9sSAAL+7LOkVlLlM/n9ONkCjKXTyWUU26oCY+D1rwMpWKsFP2ddFcc2bqqqLe8eyrCiqil1adCsFsvaBaQYKA6Vkzl0WaBBApten88BxtNwoOtVXHqgps+xSXKu202Bc1w7V0qm7uCtR7tItwV71LNn6CehemmV1Hc80GIkNkVUbiwasQwKEiPb0I/dAJmutS2XLryrBqy0ckE3hgUzD4S6V/Mp8kar9NNrZyNZ3tumEbHZzkTVTNmKeqwwVsqKcBFHI32wk0NnqQi3JJuIqE2SNjAU20pZA140zzehTqirU6EUCqpEJk/+cUtHymGxw1iyQXZbH/6JjwY/4QXAc2lgS2UjrV4XJGvVyjBGk0c7eznLliMhAbYtr+pO47fENB7nXj0ARn+YceIgR0/7DAd2HdhY8KqOycQlYYPjgYgwCXGm9DMbDlgDPcPCo8+os1Gjx6zpImgfv2AHFWcvhrNHnMVY04q8DbGX6npEkbNGW0SbFk+hV1wjveWJUPU10eVt+pjXg/dL5SVKx41LX9a0sdFV0e60teXErjNUqF2Wz9cyGU4dDqhVRbTFWSRsJvMjdx45iMjnLTZ07sJELspkYciPB9Bln+dRVVfom/IhzqbORhEQiA/nx7WSr/OHQohUPsrYH2aYWOjP4cbMDk6vWVEzyp4UB6HFfROs0bdCjOo6P19Fa4h81UFiwT9jIUaIwGLaYR9ZsPI+6q39xi45kgAjXImK1WpXI9G81kEbvcBuJEHT4hTRabeS7Cv3ACRckgR945oJEbUG7Tn5gnkqr/M8c41fojGwMDlTDXjqnSS633VhoG0lHiVqEkcdtjGy9/foP8UK9BQ==","source_count":1436,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNq9WUtu5CAQPeocIOpk15bGUnOkrGIvrBbHiBTk5gCRzWriBQKGj42xKTq2/GGRqIXbryjqvXrQfxWWCis7vu1f3Nl/L4SZDz/UfOCKmA8Suw+J8Sc1oR6pic+CwhM9MDCEkvDEuyoFOIEYVlJHHb8xV+YbGFgKea2atmWlEPYR5Ge+ruSSZchFMl0K0YEhMjxNxbgUpJ/lOgo7wfxXPlSh+rD4BKR/pIkiQ+6lDDfxUuw8FyGAW8otsWtfLk6k4rR14cLGT9MMuniHGLE6c3yeivY4E6zfsJPGixLngaFTqyQpCIeMu9YYFpL4yIE7+lSKdyZboeWw4vyCemk7FC2psMeQ7dUk8TKgoe5gsumNs93I4shDydbYLuGBjt21vunIcyryn2tHPyeRzf4zDfwUspmNQp4Dx5LAeYC3Sm+cOLyJU1clHqibze47vi2rLQdsH2jbcJbsW6kIWpE6SqP7zlbEYZDDOltoYk2x8H4XhW1F6NkudqvIFgCJTleMEUwEv2bzHnbSA83CsCcGBfjdeUmvoMxj9P9TsgEazaGTzyqycQfU0d+zBqxspRK8kEtZ1/emqKqyvmZd29Z1VXWPXN0IVdY+dJqB1EAh3DCXBR4E0Or16TwwGS03ig5dKg9UkLZ91PcqzzQY07XDtXTqLu5KlLl0Y7BXLSXbZQS6ErOsLGOtBhOxIbJqY9GAdWCAENGefjQeyGQtd6nM2R0leLWFA7ioPZBpOMylkt07X6RoP412NjL3nW08IZvdnGXNlA2d5qpVNa44E0EU+DcbCXS2skZzstG4yqhYI2OBjbQlkGXDTDH4lKoKNXqWgGpgwug/x1TkLCYbnDULZJfl8d/4UPADfhAcgzZWRDbS+lVqssa9HEsFabSzt5NcOSJ2oLbFNf0u3Pb4hqPc6wegiE9TDjzFiGn/4YCufTsLHsVR2bgEzDB8cDGGAK60fnrjYUuAtTJ41Hn1LtRo+us6RJoHn9IBxVlr4Kzx5RgrGvHbAbYyfc8oErZoy8iT4in0qksl9zwxogtPdHlbfqY1yP3S+S5SsUui6/pGal0V2V5rS17cUmO1yKxstp7ZZOpwyLUioi3GKmkjgRe5+9hBTEZnualzBzZyRjYTQ2MkmC9xlouuqtI34UecS52NFCISGciPbydb5Q+HFq1+krU9yDa20InBj5sdmFy0pmKSPy30QM/7olqnab0elXF8rIzWEv+oocKCXWAjB4mSYNh0Glmx8Tzqrv7pLTqSASJc0ojVaFUi07/VQBq9w22kUtDhF9JotJHvKPQDJ1yQBH5gyQUJ2oJ2H/3ANJVW+Zcc41foDC4MDlTDXjrHSYa33VhoG8kHiZqF0cRtTGy9/foPWy+0Ig==","target_count":61140}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
