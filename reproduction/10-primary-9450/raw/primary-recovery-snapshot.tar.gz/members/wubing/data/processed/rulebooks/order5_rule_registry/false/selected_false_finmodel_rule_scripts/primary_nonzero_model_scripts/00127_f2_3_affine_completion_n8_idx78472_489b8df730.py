from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":2828,"excluded_block_payloads":[],"law_count":62576,"model_family":"f2_3_affine_completion","model_idx":78472,"model_key":"f2_3_affine_completion|n=8|idx=78472","model_order":8,"model_table":[[0,7,0,7,5,2,5,2],[6,1,6,1,3,4,3,4],[2,5,2,5,7,0,7,0],[4,3,4,3,1,6,1,6],[1,6,1,6,4,3,4,3],[7,0,7,0,2,5,2,5],[3,4,3,4,6,1,6,1],[5,2,5,2,0,7,0,7]],"primary_rank":127,"primary_unique_false_pairs":2828,"rule_id":"false.finmodel.primary.f2_3_affine_completion.n8.idx78472.v1","rule_key":"false.finmodel.primary.f2_3_affine_completion.n8.idx78472","source_bits_payload":"eNq9Wc1uEzEQHjuGOgjRTZRjJMxqkXLk2BMyKIfkVvUJeIQ+ABIuEiLcoogH6KEPsieeI4/AkQNSGI83LartJSG2LXW3yez6y3g8P9/4C2iAFmg0dNWaboLRh8p9AGU/AIk+QmRsBzHJ4CwimG0iAn0Vm+spwDQoWONbLCQwCoQMviKEqoKCW1DDMDxjUgQFksvwXNrgS0HJZ5AaQrO92a+op0r3tKp9VdyNPxYop3pgBd45uYb+IZ3Z7fyq57F29xLKjV+7QUG03aeCYNvdeUG03ztWDsygZuUM95PBtpzhfrCLLZSyXNuyr+UcYLZc1N9WshDa6+GyGY0K7crbRb0cF1vIu9XkUvNSznZn+IgNyznbfQDL73Rv/wpg5wWc7f7/6YvszvZQEqn8W3P5oFp9ZVResA9gKGjRep7lVq2BCd1tKHGFoczneoZ1GuHlIvv235e6cxEpeZOO98Al7gyOxaoyIPKC6QrrZVtpsgqooBbdX5YhOaFZoCq7akgDmEIcW04T76ggYy5QCm4sBqZtg0iSCFy2HP6dyKNpNqtVgcy2IUut5+PRKD/aJTgyuOCgxwWcDX2NkbNJZTKDIde/IYbHDMiO4OXDnNklxJRjTSeyL6Qj6kj9gVfZS1clMXpo4tLI9nOjCUZs3l40cJu0TT6zmQoExkYNTLo8kHVUiooQUmrfNcmHyYWUHZBAs1k8nm0hNYZ7AV1SUxT6M5pNckqhzMLQReRMb/9o/aSt0bf9zNek7Wg8n/ZJp2bQJiTipu7ja6ZpXtUJS4b1pJca63lSrhpt3AIgqbpO7Gz4y5+ERSsJhqd2Nh1xZBujMZUnxYu2oKmytCVmygZJtBNueapK3F6INuRt6RqT/bezqViutjHa2CCdMERXqjtZ8e1p1aJmfLoIHT1aoHY/XdIln7aLywFRgAuHHjumcbpwt5B3P/NtvIrPcKCzuRJEPPZh7Zclga/MUc7YndVguSW93eP/slODijviC50MMWlC2+bUBglAsO9zfcA3xzdIaMx9F/By3unJgLsZOAsG5EeGxH3kBx11uOt3R7KBw8aAjYJBoDvHPTCzxfYarzw9uI91XPfmDyZBcE4=","source_count":883,"source_output_dir":"organized/mining_outputs/out_exp102a_f2_3_affine_completion","target_bits_payload":"eNq9Wc1uEzEQjsSBI4+Q5+CUB+mhD4Ci3FiERI3EA/QReIKqt+QQgcWpR46RWC1GyjFKtghRFxx7GI83LYrtJSG2LXW3yez6y3g8P9/4NXCAEdCo6co53ZShD637AMJ+ABK9g8gYbmOS7X1EsBhHBPwqNtcvgGVQMMG3TEjABCgZfEUp0QYF5yDuwvDGSBUUSC3Dc3GGLwUlb0ByCM32ebeinird06LxVXE3vS8QTvXACnx0cg79Qzqz2/lFz2OjwTcoN54OtgXRBm8Lgg0HtwXRngxMOTCGmpUz3DMDw3KGe25uhlDKcqOReVXOARbTWfOykoXQvtxN682m0K48nzXTdbGFPKtW11yXcrYzpjfmrpyzPQSw/E736a8AdlvA2R7+X37P7myPJZHIvzWnj6o1V0zkBXsPjIIWred9btVqWNHdhhJXGMp8rsdMpxFebrJv/12pO1eRkjfp+ABa4s7QWKwKBiovGG+xXraVpmmBCmrV/WUZUhOaBWqzq4Y0wAjEseU08Y4WMuYCIeDCYmDaZogkicBly+EviDyyelxVBTLbmCw1ma83m/xo1+DI4EwDXxdwNvQ1Q84mBcsMhlz/ghieYSA7gpcPc2GXEFOONZ3KvpCOqCP1B91mL12FxOjBiUsj28+NpgyxeXvhoG3SZvnMxlpQGBs5GOnyQNbRCipCSKld1yQfplZSdkAKzWbxdLaF5BjuFXRJTVDoz2g2qSmFGgtDF5Uzvf2j9ZO2Rh/2M1+WtqPxY9knXbLtKCERZ00fX2N1/bVJWDJMVr3UmM+TctVo4xYASdVlYmfDX/47LKokMJ3a2XjEkW2MxlSeFC/agqbK0paYKRsk0U645akicXsh2pC3pWtM9t/OJmK52sZoZoN0whDdiu5kxbenVYua8ekidPRogdr9dEmXfEZdXA6IAlw49NgxjdOZu4W8+6dv4yo+w4HO5koQte/D3C9LAl+xo5yxO6vBckt6u8f/ZacGFXfEFzoZMpKFts2pDRKAYN/n8oBvjm+Q0Jj7LuDlvNOTgXYzaBMMyHuGxH3kBx1xuOt3R7KBw8aAjYJBoDvHPTCzxfaabj09tI91XPfmDyY/AOg=","target_count":61693}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
