from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":2692,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_yield_principal_feedback","model_idx":101919,"model_key":"high_yield_principal_feedback|n=8|idx=101919","model_order":8,"model_table":[[3,3,3,3,2,3,2,3],[3,3,3,3,3,3,3,3],[3,3,3,3,3,3,1,3],[3,3,3,3,3,3,3,3],[3,3,3,3,3,3,3,2],[3,3,3,3,0,3,3,3],[3,3,3,3,3,3,3,3],[3,3,3,3,3,3,3,3]],"primary_rank":129,"primary_unique_false_pairs":2692,"rule_id":"false.finmodel.primary.high_yield_principal_feedback.n8.idx101919.v1","rule_key":"false.finmodel.primary.high_yield_principal_feedback.n8.idx101919","source_bits_payload":"eNpjZGBgaGAgBP78ZwSSBy6yMowCeoAP/8EAU6IBIsGOLYpAwB5T4gFECyOmzP/Ztf+2mzNjSvz4jwzsd9ks5L44Wb1EsepTi56Lv53SiW6FqiaBXydeGC1szXDycGAZjbFRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBSMgmEO/uMC7DSw7AFO22jhtT+4LJOngWUNOL3GTAPbPuCyrJ4WAfkPl238NLDsAM6AZKSBbT9wWWY/mtlGM9sIzmyjYDCD/G8/79878/9+TejN5/XVxqHxZ+79+Z/+xvjZ//x9q9583r935ir9tPx//42/SX7+bx4fClLuc1V8s/n//5K/e37+/2/8ePUpf03Vz8b//t+eHRivufRV983Z///31B5bMqVu0ZRfXMlvjIH2JEt8S55BisMYaZbZaFJG/yPBNna6ZjbKa7b74HTwf//PVZvO//+WtmrfjL0//5+/kY4l2bBRbBsABFNuoA==","source_count":9092,"source_output_dir":"organized/mining_outputs/out_exp128a_high_yield_principal_feedback","target_bits_payload":"eNr79/////r/hAAzwz8gaa/36/8ooAfgZwADTIl6iMQPbFEEAgcwJeQhWv5hyjCkNDF6nPiDKcHOgAwOuB6O+6KXc6P7Xitv9cXdGw7eNS+531r7ntVc/Gxc1fS92/f/Ho2xUTAKRsEoGAWjYBSMglEwCkbBKBgFo2AUjIJhDhhwgR80sEwep2208BozLsse0MCyepxe+0MD2/hxWdZAi4BkxGXbBxpYZo8zIP/RwDZ2XJYdGM1so5ltBGe2UTCYwQRONgVFYwaF5lVqEg0tZ1YtMFZkZpghfEaSYYJjqDCPg1Na6IWZExgZznA+42E4sWAVSPlmrRc+JxgYnrEUszEwnJEJMd1w7RbPGUYGlZR1C65FiZaopTAwFDdZRmc3xmazfp0jfAZoz5znnHPSSXHYP5plNpqU0Ywk2PaDrpmN8ppNAZwOGBzYQn0NGDhnhjqmO7ExGKjPwJJsflJsGwBILQKW","target_count":53484}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
