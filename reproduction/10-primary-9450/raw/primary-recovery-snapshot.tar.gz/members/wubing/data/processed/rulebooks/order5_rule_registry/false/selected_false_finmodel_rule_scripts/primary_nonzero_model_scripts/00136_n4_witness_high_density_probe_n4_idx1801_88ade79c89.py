from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":2366,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":1801,"model_key":"n4_witness_high_density_probe|n=4|idx=1801","model_order":4,"model_table":[[0,0,0,0],[0,3,0,0],[0,0,0,2],[0,0,1,0]],"primary_rank":136,"primary_unique_false_pairs":2366,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx1801.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx1801","source_bits_payload":"eNpjZBgFowANcMgwGTDwwHgak1QUOQUFMZU1eDABSQcPB5bRIBsFo2AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCoYdOPD/Yfv/h/J//h8+3Cz/r73+wweGfwf/1zP8Y6eFbRmzdAwlJ05cY6KotelIioubllJHp4Zym0ASBwMj9W3T7/cuE678GConKK930/fJUWHBKqXU8xyK82nhtQf5m8/+T0v7d3/ZqlNm/2fPXLkqKe3Zf/vkHkNa2LaGveQEZ9wBV34blguK6hWMLPwNci02TA+EaWFZw//D/P8P22ORoUWyuWASmWSkpIzFGdiSDaUgTm76G7VPTJgSH2iQbA7cT5v9/+wZLDK0SDYR/C8mCO/B5gxsyYbSoAQAQkB7nA==","source_count":1026,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNr7938UjAI08P3x3/P/P8N413Nv3/v27h2msvrtf4Hk/u37f48G2SgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBgFo2AUjIJRMOyAPYNcBYPcA2YGG5uaB4wVDfz8/xntGBr+M/6ghW3TUy+fe5aXF3z63lVf69m7d169W152/U7l+7nf//+jvm0XCrZ0vmnjW/Xw3YOLapukrd68a707y+D7vQRaeE1+go8Rw8yZjAqRoaYnGVLSwkLnzpRkODCn+BwtbAv+0W3+baH9rg+Hf+vfu9H+7/eH+ofVh//Kv6GFZfUMNh8YbA5gkaFFstE/vWzu2bt3sDgDW7KhFCx8mCF8k/cvpgQ/DZKNvcLMFAYjYywytEg2yz+I579xxuYMbMmG0qAEAApA9Ys=","target_count":61550}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
