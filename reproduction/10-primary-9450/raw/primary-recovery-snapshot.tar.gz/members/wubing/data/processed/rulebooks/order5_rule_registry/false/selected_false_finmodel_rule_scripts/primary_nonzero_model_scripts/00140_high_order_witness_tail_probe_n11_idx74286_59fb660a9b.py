from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":2311,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_order_witness_tail_probe","model_idx":74286,"model_key":"high_order_witness_tail_probe|n=11|idx=74286","model_order":11,"model_table":[[0,3,6,9,1,4,7,10,2,5,8],[9,1,4,7,10,2,5,8,0,3,6],[7,10,2,5,8,0,3,6,9,1,4],[5,8,0,3,6,9,1,4,7,10,2],[3,6,9,1,4,7,10,2,5,8,0],[1,4,7,10,2,5,8,0,3,6,9],[10,2,5,8,0,3,6,9,1,4,7],[8,0,3,6,9,1,4,7,10,2,5],[6,9,1,4,7,10,2,5,8,0,3],[4,7,10,2,5,8,0,3,6,9,1],[2,5,8,0,3,6,9,1,4,7,10]],"primary_rank":140,"primary_unique_false_pairs":2311,"rule_id":"false.finmodel.primary.high_order_witness_tail_probe.n11.idx74286.v1","rule_key":"false.finmodel.primary.high_order_witness_tail_probe.n11.idx74286","source_bits_payload":"eNqtWV2y6yAIjgwPPvpwFsBSWBr34e77nCZtagTUBJ3OpGmi+AEfP/b/xtvr8xq40aZv4LjZX+PjyXdw9f01IZ03UD/5/FxP3Ud+r/A3VWS7Lgyf9a+zYHNG8V4Sdyq+JZT2AdVTLSgJNJTv1HSBIvXFgoKNIs/9cDtNPtqAapO1ahG2Rv7bKqgVlvY9k6mZ7w8pH2rAVmIz2NiNYZlaBm6PR67kid46bZ55Hg3XfxtTf6UFoH1o9IIFMNRD3yrDcfB8R8ZzM8pzYTKG3sqB59LKIGqgcngOKBL6jiYKaECP+0bRdj9Z6owqtEkH+snqXOJkSzARZ8ij5Q2ynVpDLQiUR4lEyJbrSz8WStBo3wVS62vscCHAtYuENO3Dz8lW/FDf9eGHZJuHxmGy8T1qEoXIljs8BI0sEktokEHytnLgoGBM3ezzkGzs1DW0FFqpFYaDzBYOJtD3fVFqjWY2R2GiNgEUJltlIRhktrB/pgoWK0FNmo7Gf+oH9H9r/RPH0K83P4sy27CMPNS7qIw0BBl1yooyEm0VspKfg2RLZmtKvLRdm6IPLO1sUt8z2WjRY2TrCcLJvvE+2WgYkDGe2YpJhR1ZKgM73iQbeex59RQULa6mXVoUByRksrpnc3wkLVVk7kdnUj4SUm3qx0tFNgmSzTlnPIDmGmEKdtqn7soE9F1mySGyned7Oes0RJrg+aYvXJaUc+VkuB5egFuvWZxIU+FdhSjWzTfGyObAN9wvBzub7AZjtOuBLDGyFbvKZ8d7y/PCpD4g0Qc9qwduzgGJmaHRNDzfINvpmWVEGIhCK1RfLvaE1iP5bz/FMvx0CnL/WiArloHJWrpJNiOwGydd+k+NY5/YvdcHJFZgzzY1Ze61Tng3Ajtr9bBWrph5ozjudMlsWRlDllWQbx2TE9iT7QsRDtRku0YO97AYJoITdTObVXyXiX7gWc8GqbWR8CQsms8+fKyQ58rIvcNLDtSJJOSTzTktoWGI7iD9Bel2Pu8=","source_count":508,"source_output_dir":"organized/mining_outputs/out_exp109a_high_order_witness_tail_probe","target_bits_payload":"eNqtWV2y6yAI3vd5uCyNpbCA8+CjDwzmniZtagTUBJ3OpGmi+AEfP/Znw+31eQ3eaNM3ctzsr+Hx5Duw+v6aUM4bqZ98fq6n7iO/V/ibCrBdF5bP+tdZsjkjeS+BO5XfElL7gOqpFpQiGsp3arlAgfpiQeFGked+sJ0GH21ItclatSxbI/9tFdYKK/ueydTM94eSDzVwK7EZaOzGsEwtg7fHI1fyQG+dNs88j4brv42pv9IC0D40esESGeqhb5XhOHi+I8O5Gem5MBhDb+XIc2lpEDVYOTwGFCl9RwMFNKDHfaNsux8sdUYV2qAD/WR1TnGyFZmIM+TR8gbZTq2xFiTKowAiZMv1pR8LIWi07wKl9TV0uBDg2kVCmfbh52RLfqjv+vBDss1DwzDZ8B41iUJkyx0eikYWiSU0yCB5Wzl4UDCWbvZ5SDZ06hpaCi3VCuNBZgsHE+n7Pii1RjObozBQmxAKk62ykAwyW9g/SwULlaAmTUfjP/UD+r+1/slj6Neb30WZbVhGHupdVEYagow6ZUUZybYKUcnPQbIVszUlXNquTdFHlnY2pe+ZaLToMbL1BPFk33ifbDQMyBzPbMmkwo6spIEdb5KNPPa8egqKFlfTLg2KAxAyWd2zOT5Slioy96MzKR8Jqbb046UiGwTJ5pwzHkBzjbAEO+1Td2kC+i4z5RDZzvO9nHUaIk3wfNMXLkvCuXIxXI8vwK3XLE6UqfCuQhTq5ptjZHPgG+6Xg51NdoMx2/VAhhjZkl3lo+O96XlhUh+Q6IOe1YM354DEzNBsGh5vkO30zDQijEShJaovF3tK65H4t59kGX46Bbl/LZAVy8RkLd0kmxHYjZMu/afGsU/u3usDEiuwZ5uaMPdaJ7wbgR21elArF8y8kRx3umS2rIwByyrIt47JCezF9oUIB2qyXSOHe1gsE8GJupnNKr7TRD/wrGeT0toIcBIWzWcfPFbIc2Xk3uEVB+pEEvLJ5pyW0DBEd5D+B2L7Mkc=","target_count":62068}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
