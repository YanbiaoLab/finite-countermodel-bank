from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":2299,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_order_witness_tail_probe","model_idx":51634,"model_key":"high_order_witness_tail_probe|n=11|idx=51634","model_order":11,"model_table":[[0,9,7,5,3,1,10,8,6,4,2],[3,1,10,8,6,4,2,0,9,7,5],[6,4,2,0,9,7,5,3,1,10,8],[9,7,5,3,1,10,8,6,4,2,0],[1,10,8,6,4,2,0,9,7,5,3],[4,2,0,9,7,5,3,1,10,8,6],[7,5,3,1,10,8,6,4,2,0,9],[10,8,6,4,2,0,9,7,5,3,1],[2,0,9,7,5,3,1,10,8,6,4],[5,3,1,10,8,6,4,2,0,9,7],[8,6,4,2,0,9,7,5,3,1,10]],"primary_rank":142,"primary_unique_false_pairs":2299,"rule_id":"false.finmodel.primary.high_order_witness_tail_probe.n11.idx51634.v1","rule_key":"false.finmodel.primary.high_order_witness_tail_probe.n11.idx51634","source_bits_payload":"eNq1WUuS3CAMRRQL1axY5ABa5hg6Qo7EJvfIURN7bDcfycgWoaamy24h9Hv60L8Dh+0vQAgphPz9EIYHCtsDl+ubfZVQL/q8KBu/z6oeKNdf4L7r3F0trrem+ptYkTZ7snJiI2VD1DLuVDk5lBhaxnjZp1dFPLFRpT0wCltPKfnamjrGsd7aq5Jiz+7wSqolqW1EOy8M6sLPAcSjoCcVV1a/4VYbJYXXqw4ctlC7lhq/YfQFU4+Lh6uB0ahHGSTLntNS5UlWtQ62UJmtUm9HC7UjRPSEoFFncpwWBcTfaRbQYUh+ovq3eOAB23XeHyF6GqsxBDfYlAz7H4Ddyh5nB6S+TL0HG0/yjOrIR2DT1ALZDtEFNpZT1Ey8l2DDQw82MYppEdiyBYc+sH1iDIbo4cUYAAUKMmvwZWS6FxtG6rIAbAZZDmon2PBZGfOB7SGy2Ae202M4O6m48mPf+E9VTz47GtrehXa8VIqGPEPZaUiaSOwuncbKFoPcRgYf2M6PrxnxD6/XcmXIOM0z/+T5Ffxgi3JCliZLZxuJcjyU4d1uB/C3kWjG0c8VbaQZmslf2ciWTPKaypYMRX1hGwmGQpq9WSXrzQgN2SSBE9rxPh0Wuel0gA1UG5dx1HAtvGWWO0kWXJAk0XPc1CBSHOm4IIFRDWy03v5DNPiGp21kYRPY2Ae2KBZOaoybH8QJmCqbRJZWz2ykdN/DXI0NVXkHNkWPcnc97QebMLPx3eDhmtk69+z1PPWSubxG6k34l5IvYZZQON5UNrraSJ5gKn+sCdZI0KMZx4fc+3hZGwmCP+OLUQosM9u0+WZvwTlUYoENKg5J82E93V+QbDm9i+yEtjEHH9Q70EDLJL4qfYzlZ2AritAkSrbk6h9E1kkIG9Q7qFn4XJVtnGyyKJkXbCyDH/P6afic2YYf+MSGIfY5ejdI9wZoAjYpsbMNbPwgSR52gfHnISEe9ldFBjE2Vlbi9i9YCz/g","source_count":508,"source_output_dir":"organized/mining_outputs/out_exp109a_high_order_witness_tail_probe","target_bits_payload":"eNq1WUuS3CAMPWrukQ1HyhF0jCw5QBasprRQIRJ7bDcfycgWoaamy24h9Hv60D8LlO2vcClUSvp+KMNDLNsDhOubfYVSr/h5ETZ+n1U9xFR/gfuuc3e1oN5K9Te5Im32JOXERsqGqGXcqXJyCLm0jPGyT6+KeGKjSntgFraeUsK1lTrGud7aq0K5Z3d4hWpJahvFnRcWdeHngAijoCcVVFa/4VYbhcrrVQcOWKhdS43fMvoCYo+Lh6uB0ahHGCRLntOo8iSoWhdbqMxWqLejhdoRInpC0KhTdJyWBcTfaVbQYUh4ovq3eOwB23XeDyF6GqsBFzfYlAz7H4Ddyp5nB1Bfpt6DDSZ5RnXkI7BparFsh+wCG8gpaibeS7DhoQeYGGVaBLZkwaEPbJ8Y4yF6YDEGWIGCzJp9GTnei80jdVgANoMsB7UTbPisjPnA9hBZ4APb6TGcnRRc+bFv/Keqk8+OhrZ3oR0vlbIhz8TkNGScSOwuncbKlovcRhYf2M6PrxnxH6/XUmXIPM0z/+T5Vfxgy3JCliZLZxuJcjyE4d1uB/a3kWjG0e8VbaQZmuSvbNGWTNKaykaGor6wjWRDIU3erJL0ZiQO2YTYCe18nw6D3HQ6wMaqjcM4argW3jJLnSQLLkhI9Bw0NSgqjnRckPCoBjZab/85G3wD0zYygAls4ANbFgtnbIybHsQJmyqbREarZ7aodN/DXI0NVXgHNkWPcHc97QebMLPB3eDhmtk69+z1nHrJXF6L6k34l5IveZZQIN9Utni1kTDBVPpYk62RoEczjg+p9/GyNpIFf+YXoxRbZrZp8w3egnOoBAIbVBxC82Gd7i9ItpzeRTahbczBB/WONdBCFF+FPsbSM7AFRegoSrbk6p9F1iSEDeod1Cx8rso2TjZJlMwLNpDBj2n9NHzObMMPfGLDkPscvRuke8NxAjYpsYMNbPAgSR524fHnISEe9ldBBjE2Vlbi9i/0ZjFW","target_count":62068}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
