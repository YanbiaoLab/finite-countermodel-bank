from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":2166,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_yield_principal_feedback","model_idx":8630,"model_key":"high_yield_principal_feedback|n=4|idx=8630","model_order":4,"model_table":[[1,1,2,2],[1,1,2,3],[0,0,3,3],[0,1,3,3]],"primary_rank":148,"primary_unique_false_pairs":2166,"rule_id":"false.finmodel.primary.high_yield_principal_feedback.n4.idx8630.v1","rule_key":"false.finmodel.primary.high_yield_principal_feedback.n4.idx8630","source_bits_payload":"eNrtWUtugzAQtS1XsrpyUA/gIir1GFbFArrKkbzIguxS1AP0qPWPgGNDISabat6CgEx4Hr83YzRgtAYviOqjZAhhBHg8jr39IdGA6o0QiMuERL2WR5nTSzAgqL57kC144qtCZPgPnw64C+avGEbC3EXYLSe9nhHQDAAAAAAAAAAAAAAAAADgX+PtXPVdlxjgDyD7qb7q4nBIjMQtqnx8V31TlokGlzSHZl8y1ddFW9eJESYUQpjuynbUkZ271JoZIk1IbItvJw0/C3MU56osq6CNLOJ7L7LII5OtVUw7pT7d2CIOp29QmcX2jkxEqtKcFyNeWXqh1JWQ7GebJ0dkKEzPV9bU9+UtUbhwNnIcLDLdlKW+fUyY0DPXtmD6ZuGCmPNwRminCZE1vLUgWyDKMKfiEyLqwlLjJ45UsmX0uTkZiZQPiztZaLxqZHAKui/lPyZE3IdFRiK3anhqydnSGTp3IdkST0iUTt5EiyhQvSXZ2hl5ZKJ0EpacNd+YbFamKhiwYbSmTuoI1T4lcv5bTco2uXDJNvXaMI2EbfJ3tuWnRIqomTeKlTvb4lziPL7MvFGswrP1QTIzorVVdmez5lEdu6N6SWbl8eXxD1NrDYnNAa8kc1ZWqys2w8YH4w5CExUqSDbt3+sWgbfuCr9mcUUp","source_count":534,"source_output_dir":"organized/mining_outputs/out_exp128a_high_yield_principal_feedback","target_bits_payload":"eNrtWUtugzAQPWoPUFF2ySILHymrwgJVPkalIuoDVMSrylIt2/WPgGNDISabat6CgEx4Hr83YzRItQZfiusjZkpJBXg8zoX9EdEAKowQiuKERIWWB5nTMhggXN89yBY88RMpMfyHTgfcBfNXTCpi7hLslpNfzwRoBgAAAAAAAAAAAAAAAADwr/FxaIvjMTFAH0D21L40/eWSGIlbVPl4bou66xINLmwO9b5kqGj6qmkSI4wgpSTfle2sIzscU2tmiDShsC2+nTR87c2RHNqua4M2MonvLXGfR4Yrq5h2SnO6sUUcTlGrLovtXZmIUKs5SyNe13mh0JVQ7GebH0dkKEzPFzfc9+UtUbhwNnIZLDLflKW+fSwY0TPXtmD6ZuKCmPNwRminCZE1vLUgWyDKMCeiEyLuwkLjJ45UsmX0uakYiZAPizpZeLxqYnCKui/l3yZE1IclRiK3anJqydnSGTp3IdkST0iUTlpHi0hUsyXZqhl5cKJ0CpacNd2YbFamNhiwYVSmTuoI0T4lcv5bTco2uXDJNvXaMI2EbfJ3tuWnRIqgmTeKlTvb4lziPC5n3ihW4dv6IJkZ0doiu7NZ86Aju6N6YWbl8eXxD1NrDYXNAa8kc1ZGqys2k8YH4w7CExUqSDbt3+sWIbfuCr/mACwN","target_count":62042}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
