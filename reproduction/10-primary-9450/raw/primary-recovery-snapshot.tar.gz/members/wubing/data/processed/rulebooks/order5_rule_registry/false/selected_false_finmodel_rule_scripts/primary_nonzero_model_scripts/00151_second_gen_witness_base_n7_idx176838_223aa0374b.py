from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":2106,"excluded_block_payloads":[],"law_count":62576,"model_family":"second_gen_witness_base","model_idx":176838,"model_key":"second_gen_witness_base|n=7|idx=176838","model_order":7,"model_table":[[0,4,1,5,2,6,3],[1,5,2,6,3,0,4],[2,6,3,0,4,1,5],[3,0,4,1,5,2,6],[4,1,5,2,6,3,0],[5,2,6,3,0,4,1],[6,3,0,4,1,5,2]],"primary_rank":151,"primary_unique_false_pairs":2106,"rule_id":"false.finmodel.primary.second_gen_witness_base.n7.idx176838.v1","rule_key":"false.finmodel.primary.second_gen_witness_base.n7.idx176838","source_bits_payload":"eNrtmG0KwyAMhmNwIPuVI/TnjuHRPMqOumg/5hdbYd3A7n2giBgKSZr4poYUH4gs/SHqdIgLE8mn73L6GF1kfucTvxze44aHiIvbaTctK0fPAQAAADAI+b1dypYoVa6FKrzJUK7ZypmMi6qywpmBtNnJ8T19OW/iERdJYlvZAACOKLY0xhZzoEOxAQB6MpLTD7SkIIumkVSW8WunMZvOtDuEm0dgTwRbWdM7tdcQh/m74GwUeXXbML01AQcQVTdvhVxnYNJqd1kipB0jqTthOkQWAPAdtA95bVbSqgzHXeu2HxlBGH/NA8K7DbQ=","source_count":112,"source_output_dir":"organized/mining_outputs/out_exp20a_second_gen_witness_isotopes","target_bits_payload":"eNrtmG0KwyAMho+6o/RoHmM/e4T8GsIkZlHbzi+2wrqB3ftAETEUkjTxTb0oZhJx8oeo01NYWIQ+fZfVx+tC6Z1PzHJ4CRseIi52p928rBw8BwAAAMAg5Pd2KVuCVLkVqvBKQ7nmKmcy7qrKCmcG0mYnx/T0ZdqEIy6SxK6yAQAcUWxxjC3mQItiAwD0ZCTHH2hRQRZNI6osb9ZO4zed6XYIN4PAngh2tKZ3bq8hntJ3wdko8uq2YXlrAg4gqG7eCrnOwKzVbrNEUDtGSnfCtIgsAOA7aB8y2qyoVRmWu9ZtP/KEMP6aB4m2Y4I=","target_count":62464}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
