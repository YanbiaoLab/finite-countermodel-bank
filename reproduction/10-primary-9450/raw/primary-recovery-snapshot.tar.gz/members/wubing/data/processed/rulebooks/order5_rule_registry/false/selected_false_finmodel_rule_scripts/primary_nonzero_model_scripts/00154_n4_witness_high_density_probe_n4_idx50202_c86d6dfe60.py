from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":2099,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":50202,"model_key":"n4_witness_high_density_probe|n=4|idx=50202","model_order":4,"model_table":[[0,1,2,3],[0,1,2,3],[0,3,0,3],[0,0,0,0]],"primary_rank":154,"primary_unique_false_pairs":2099,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx50202.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx50202","source_bits_payload":"eNrtWcGSgyAMDUwOOfIJ+ZQc9rCflf3zFUQEgVZX27ozvOnYWosvCc0jQQMi0AICSHaCcHs4lz7yZK89cy/OTyg/MT/+zuoPVsLvCAIxEWu84KaDCWGjhyx2tRE1CzdET2oXVOP1maCcL/L0HtIyvIYJDJwz5pTasaGMEsPAwMDAwMDAaaRVfHeZkn5uR/TyiuhozRrruYGBgaPJdniE/J1MVeb2x8C2DdJKPZ14LgoWmpZEKpQqWvWVENgM1s2Oiw1f5tRiV5BjrKlM0eG1esJA5K1BF0fYeaydnQltpUtshsNJ7DWl4OC0MGDW9GGil4KosMoTWYLVGyBOE93yI3FIp41eVjZsR434yMqWWmut/gKfAHPaEVj+a9EHPz3rdoSD5haB5DEyfiDPb7jJLMz2ZjzR9DLZJQ4Diqi5ck7MZluAEwFWGaBD1q5E3GjDOv/tMvXb6q67i2XLtPo4TF88X5Fs76zgsBdhKSTumg1S1UV0G21BxnZNajpHnXAF1dLo1kVzaHvVAj8f8Kj9uUfP5haLZZeE8sGIbZLNZoTbZKM8J6nOTnxPlg5sY7zOhVbiycXMaF0hy2WF9wtWtu5C5L6nq9Y8+YrhK94IdwgbUZKonYJxRif6D0kYHgj1P+nZjj4yGrhFsmGzHnC7hJ1v7Nsv4HksWQ==","source_count":359,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWcGSgyAM/fPNZ+1hD/mUfALHHDKQFUQEgVZX27ozvOnYWosvCc0jQaeI2oKoYnYiensYkz7SZK89cy/KTzg/cV/+zuAPFsPvWAMxM0G8YKaDC2Hjhyx2tVEgC7dGT2oXAOL1maCcL/b0HtgyvIYLDJQz5pTQsaGMEunAwMDAwMDAaaRVfHeZkn5uR/TyiuhozRrruYGBgaPJdngE/p0MAOf2x+m2DYJKPQ16Lg4WupZEgpYqWvWVGtic1M2OiQ1f5tRiV5Bjqalc0eG1esJA5K0RE0fYeaydnQltpUlsjsJJ7DWx4KC0MEjW9Emix4KosMoTWdbVG2VKE93yI3Fgp41eVjZpR43pyMqWWmuo/gKfAFHaEVj+a9EHPz3rdoTR5hYB5jFyfiDNb7LJLMn2ZjzR9HLZJQoDiqiZck7cZluAEoFUGQBD1q5E3GiTOv/tMvXb6q67i2XLtPo4XF88X5Fs76zgpBdhLCTumg1SgEV0G21BxnZNahrDnXAF1YLo1kVzaHvVAj0f8Kj9uUfPZhaLcZeE0sGIbZLNZoTbZOM8J7nOTnlPlg5sY7zOBVTiScXMQF0h42WF9wtWtu5CZL6nq9Y9+Yr0J95Idggbc5KonYJxRif6D0lIHwj1P+nZjj4yGrhFskmzHjC7hJ1u7Nsva/hE3Q==","target_count":62217}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
