from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":2010,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_order_witness_tail_probe","model_idx":53514,"model_key":"high_order_witness_tail_probe|n=11|idx=53514","model_order":11,"model_table":[[0,4,8,1,5,9,2,6,10,3,7],[4,8,1,5,9,2,6,10,3,7,0],[8,1,5,9,2,6,10,3,7,0,4],[1,5,9,2,6,10,3,7,0,4,8],[5,9,2,6,10,3,7,0,4,8,1],[9,2,6,10,3,7,0,4,8,1,5],[2,6,10,3,7,0,4,8,1,5,9],[6,10,3,7,0,4,8,1,5,9,2],[10,3,7,0,4,8,1,5,9,2,6],[3,7,0,4,8,1,5,9,2,6,10],[7,0,4,8,1,5,9,2,6,10,3]],"primary_rank":159,"primary_unique_false_pairs":2010,"rule_id":"false.finmodel.primary.high_order_witness_tail_probe.n11.idx53514.v1","rule_key":"false.finmodel.primary.high_order_witness_tail_probe.n11.idx53514","source_bits_payload":"eNrtl1EOwiAMhguZCY89Qo/C0aonVzQzgwEbY4mi//ewZNBQ1vWH1tCDiQBY8s4IIXIkHIZseLevaU1tmfw8uQd+Pi/HN+iItOlzvIwSe/Et1iGS174/zU3W4iCPP8NFqs0IOaVLbCbjuTxkskbfe6zWxC1rsXU403ock7W16UAFAAAAooZh+8Kebx8+7kyzrUppSIfqcG390ueVdUcco2Jk2vTm69UL+EmU6jlmTxUbF1fOZSmPVPwvtePsDrGd0rOVtB1t4IY0BwAAAAAAH+AOf5MLHg==","source_count":94,"source_output_dir":"organized/mining_outputs/out_exp109a_high_order_witness_tail_probe","target_bits_payload":"eNrtl1EOwiAMhk+uPRpH6RH6SOICVTQzgwEbY4mi//ewZNBQ1vWH1uuDSQFY8s4IVrXKEoZceHevaUptRc08uQd5Pm/HN2hVqelzDI8SezYt1iGS174/LU3WbCGPP8NGqs0IOaVLbD7juTzks0bfe6zWxM1rsXU4o3ock7Wp6UAFAAAAooZh+8Kebx857oyyrUppiIbqcF390peVdUcco2Jk2vRm6tUL+ElI6znmThWbFFfOZamMVPwvtWPdDrGd0rOVtB1t4II0BwAAAAAAH+AOzN5mGA==","target_count":62482}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
