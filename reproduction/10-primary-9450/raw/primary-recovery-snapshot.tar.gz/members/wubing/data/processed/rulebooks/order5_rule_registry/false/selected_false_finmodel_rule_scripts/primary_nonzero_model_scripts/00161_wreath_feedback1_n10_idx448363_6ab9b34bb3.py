from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1980,"excluded_block_payloads":[],"law_count":62576,"model_family":"wreath_feedback1","model_idx":448363,"model_key":"wreath_feedback1|n=10|idx=448363","model_order":10,"model_table":[[0,0,5,5,8,8,3,3,6,6],[1,1,4,4,9,9,2,2,7,7],[9,9,2,2,7,7,0,0,5,5],[8,8,3,3,6,6,1,1,4,4],[6,6,1,1,4,4,9,9,2,2],[7,7,0,0,5,5,8,8,3,3],[5,5,8,8,3,3,6,6,1,1],[4,4,9,9,2,2,7,7,0,0],[2,2,7,7,0,0,5,5,8,8],[3,3,6,6,1,1,4,4,9,9]],"primary_rank":161,"primary_unique_false_pairs":1980,"rule_id":"false.finmodel.primary.wreath_feedback1.n10.idx448363.v1","rule_key":"false.finmodel.primary.wreath_feedback1.n10.idx448363","source_bits_payload":"eNrdWcFuwjAMdSIfslu2L4gmPsSaOPBZ3rRJHPsJ+9S1aaBFxKGD2AcsRBWF1jzH79lJf4Bg+ky2y99lgJeDlAc0D2KEmiXHXJ0A5119IsT85GujDxDMSxODNMHSRAFZgyLe4gQkEKQ7CBpQ6pNRupXLP07vAhT0ApQKVHcD6jWw1m9pjk2IUL7S7UffbwdIqURK0ctl/vK0HClmr17PWaKcseNlvDptaDtcWEXaznhesQwrBG1vw8wTv6atXrJ8QSBAmohGK3rpGDF8ngKqniJZAaYVGyP5a0A259KYJVMQS6HRJZvzJ8H16mSbEqQl/F3J9s3w6oKBp1mIycZRtjcD+ViRzRCZ3BKp2IszhGaI69zOGhmbQhtMvXlLZ2Qay2AaSEuuXZItanvDBaJBZeMFov4KxtL9mJEtmckl0ROT7XkrG1qqs21li6ax9JbqTKYJE1aInHoFd4AoKcwZOndCLZ8z5k0BH0smYR+yBWzwEEfoHWvedDLiRYXh85lan3o+xPbWeN9VXHxT0FLftoFkb8fQXdNCW6qpN9mk7FFovZLptgBRFM/Qic9bKptGpxJNtwXiCZNG4SmeiCvieaMOLjzZvLoHOWrX3koxuH95xZckFRiUHuyeUhcZuKuN1G5w2fQ04XRAskcLbwVS5SUnbdTN9G+yBdiWkrCRgG0ldJtgeHwoxwD+ALT1MCI=","source_count":345,"source_output_dir":"organized/mining_outputs/out_exp15a_wreath_feedback1","target_bits_payload":"eNrdWcFuwjAM/dR9Qo9ImzZ/Fgc0+UPQ5C/YclsOUeK1aaBFxKGD2AcsRBWF1jzH79lJXxl5+kx2zN9lEC4HlAc4D5zjmlECqE5wiqk+4V1+8rXhJwsWpYlBmgBpooCsQRFvSQIS9tIdyA0o9Ukn3QrlH9OXACVEAUoFaroB9RpY67c4x8Y7Ll90+9H3256JSqQUvVzmL0zLQS57jXrOCHPGjpfxmrShHcPCKtR2BvOKZVjea3sbZp7ENW31kuWdPXLAiWi4opeOIfDHKaDqKZIVYFqxMZIvBmRLicYsmYJYCo0u2VI8CW5UJ9uUIC3h70q2N+Cf5A08zUKMNo6yfRvIx4pshsjklkjFfpMhNENc53bWyMAU2mDqLVo6Q9NYetNAWnLtkmxO21tYIBpUNlgg6q+gK92PGdnITC4Rn5hsz1vZgqU621Y2ZxrLaKnOaJowfoUoqVfwxCFICnOGDp1Qy+eMeVMAu5JJoQ/ZfGjwMIzQO9a86WQkigoD5zO1PvV8cO2t8aGruMSmoFHftgFlbzvfXdN8W6qxN9mk7FFovch0WxCCKJ6+E5+3VDaNTsWZbgvEEyaNwlM8IVTE80YdXHiyeXX3ctSuvZVicP/yii9JKjCQHuyeqIsM3NVGaje4YHqacDogOQQLbwVS5SUnbtRN+jfZPG9LSd5IwLYSpk0wYngox5j/AJd8QRQ=","target_count":62231}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
