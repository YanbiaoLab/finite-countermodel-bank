from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1952,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":1859,"model_key":"n4_witness_high_density_probe|n=4|idx=1859","model_order":4,"model_table":[[0,0,0,0],[0,0,2,0],[0,0,0,1],[0,1,0,0]],"primary_rank":165,"primary_unique_false_pairs":1952,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx1859.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx1859","source_bits_payload":"eNrtmWFIE2EYx2dZqWm5XKgF6vSDs6AMQZGV00kT+5AWYoHkaJUrIhdoLTO5UaayikUkq7DIJikprDKRcuMsK6I0E5FU0EW1ZWoul5t56+7pblRQW9R9uD7E+/tw7O75w5/3fZ//nmPz4/F4Gt6faKhhrp1PA3mIf8HZ5GHRtcRM74IG78+C6g3zvCtfel0EPhrhXXhlPTRUHGf04SJpPEUtLfP3Llyt+fYhV0pXt6f6fS8c3LJZqPshS7fmnU/YTSs0y2LRmSEQCAQCgUAgEAgEAoFA/NfsM5xJvie+0ydTVydrRd0vRuoTM3dWHS9ZMo8Ds1f2GQC1jgKY6mN+DSPE9D1gB6cyuVjaF5h149QwWMyX3bQNpODPR0mQj4tDODDT0AYdIyZiHO7mMGbQOwhwW/noYo4fB24fsXuToM+Cd8thrBHeRJNhN+JdIDnmEHKxkfR5YbPKYhzszSSzNGI/gL2nzR6xiAOzTnrbLLJCsnZbd6NnI2UtV7aTrYonjVws7bOFdAK0AeaWtFtg1jaF9eAE4JR6BRduzHKM4AJQ2SlPjxiZq56Qz+cibFanBUvCKbfK9nJPxxnT0SQ1TFEj62wF3IQNCMzWD3iPiWAWpbpuk5MQ/fhYIEdhwwck7gloV3p65F0/ba/MJnX/Q9j0pMQxDiZFmidsKQrnQwrCM9MWcGCWPrzXUPMg2McZhXo/4h/I2+qR1wqCkgRSUcDjmBh2YRNXzGCDcX/XvXB5UxQjN+il01UULLqf5s8ybK1mypiy8C+7d6jgFiPP/7RvcgCgIa2Lbdh+91+Nj+41OrRzpYx8tGYgbHV5fvCcgGXY6tYQkrf831RjfunezUIdI+9bXH9ECnAiJprdaNfQLwf8k5HavYZz0pUbBUVNDbkX6kOlGYkLfYQtdrip4QUjX5UgKBJV5oaezmAZNjUxBjezwJ7nGDNAV5RZoE2ZAUmAS+hrVIhr13vka0++DiFh6fGKAJZhU5aTctUk9I5qPzgx861LObuMFMQ7I320zWdobVcw8hZb/2AzQHZFFbtvm85nE7dHZIUVzGR7dnhlmZOZbEM/JtvPpyK3Lv/0npGb+c3x+a6WCEcCy8mWumMGe2KAkqCy0j4Q6goDHoUREO0/F+orbHXSKI88XDpdSYctg23YvgI3N+63","source_count":3938,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNr79/////r/hEB0OYi0N/32fxTQA+SfVL0ee34PpkS9g84OhopDfzFlmA04WR0Un2NKyEt1qU28E4DFlgMRJYwf2n5jSsSXQxnr9wJllx/7B5PoX7fxXgFc2X6p1dnXZgNV1L+9Oxpno2AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAXDGkyLKTrpesRbb2dHxcnS68b6SnHn98yrrO35+JcGlskLcDMwdBQwMjAI6oFGw1iPAPkMDf2Ce2jhNWYGDhYHRlUGBackFqA1DCccDBWZGBaIHvlEA8vqgRa4KDmzijK4bQBZxmCgzsDgO8MqbcM/GtjG3+AqzJCxg0HiFYN4BIPMA6Y3oTc4GQ40896jRUAC46uBY8ZEBwaBECaQ11inMDAIGHkJPP9BA8vsgcGmsHMhU9YK4whwQO4MTlzO5DPXPIIWXmNXYOJiYPBiaGA54KHAwCEp2GDkwMrgwNjxlBa2gbwTwMDJwDBBgBGcRgJAZAbrgj+0yGxSXAoNZxwYWSZIasxyKXJuPdPBIMiodE5yCW0yGwNrg6QOg4ORMyvIUxMiJRcwMTywbP5Go8zmoHWARYTBYwY4jUjoAK2fsY2pYDhktgymA7yiDM5zD4Iz24m5XNaMDC/2HPxFA8v2q06PKbf9jCWO3mMKvZu0ei1Yedbrr2de773+3fL+fdIy25Em7gb1O8SlXoakrQ9BymMy9vJVMjL8sDv4m8TM5uPEGHDiJ5GpV22JH0j5Sp5pwloMDNEHbUjNbLjmarCk3gDeUrZukHLFcq03V1pWfmZ7TWJmS77IekD6HQ7Z+2ipd+O9ApByvS9x7XsZGGruPyCtaq8HNg7eVT0rnR6Tu/fJrtczw6PXp8e937vv/E8sme2uani0Pkj51WuvZ16vXv++eB+Jma2DVZzBfweDwGpe8RgGm4dOr0tPcDMc+M55D1tVcSTrMFj5hSrZT0wMH2qbvpOY2Wa0MC2YIMxgoFgqxNXg5Je6YU4AI8MNrmdYkg07g4/HXJDyYEkd9RAGhm1NlaSVNvYmIr5KOxc2gWo2k84nbVygmk0NXrOhxsoCqVc8YiDlTu9CbqzkDH7Oe43Emu3YIu4G8xiGnq9t3XoM9woWfrd6w8rw4Dfbe2yZLXnvQ7DyF3v5qoGZbR+pmQ0AFUmCcA==","target_count":58638}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
