from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1913,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_yield_cross_splice","model_idx":64778,"model_key":"high_yield_cross_splice|n=6|idx=64778","model_order":6,"model_table":[[4,4,4,4,4,4],[2,4,4,0,4,4],[4,4,4,4,4,4],[4,2,5,4,4,4],[4,4,4,4,4,4],[4,4,4,4,4,4]],"primary_rank":168,"primary_unique_false_pairs":1913,"rule_id":"false.finmodel.primary.high_yield_cross_splice.n6.idx64778.v1","rule_key":"false.finmodel.primary.high_yield_cross_splice.n6.idx64778","source_bits_payload":"eNpjZGBgaGAgBLacBJEH/sszjAJ6gA/6p1//r0rClGj4DwbsmDJ/wBL2mBIPIFoYMWUgEvyYEhvA0b0qsifQiYWB4cd/ZoTNyCYd+I8M7EejbRSMglEwCkbBKBgFo2AUjIJRMApGwSgYBaNg+IL/uAA7DSx7gNM2WnjtDy7LaDEY2oDTa8w0sO0DLsvqaRGQ/3DZxk8Dyw7gDEhGGtj2A5dl9qOZbTSzDf/Mtl9n/f/XnVhy1r/9b3oj4v5fF+7+afLp1f/6IPnE//Hf3MDKj9ZIVX79b7+y34CczFZPSp6nIABwavpBlG2M5GQ2RhLyPAWlDaEpIwKAtNKmoT4SlA5+/99knlT5N95f59nlE6v///esbflbf1N6455/69XFPmc+ufr//xK7Q9iSzf94n72Cv7sUdfZd+v+/KumlcQs8AW0wONXfZhCv1VbzCuguj0V1HN/+j4IhCAD8ImRQ","source_count":9035,"source_output_dir":"organized/mining_outputs/out_exp130a_high_yield_cross_splice","target_bits_payload":"eNr79/////r/hIC3GYi0Z3jwfxTQA/BfMBFhaJ2LKVHPAAY/MGWYwRIHMCXkIVr+YcpAJD5gSviDozt0WfG6vb///2dn+IOwGdkkewZkcGA02kbBKBgFo2AUjIJRMApGwSgYBaNgFIyCUTAKhi9gwAV+0MAyeZy20cJrzLgso8VgaD1Or/2hgW38uCxroEVAMuKy7QMNLLPHGZD/aGAbOy7LDoxmttHMNvwzm8PlAAaRMiw5i9FBuGj5QgaNNyVsp3lFGRrWPpjHsIBzJ1i5VfPTNi6GA2EF58nJbA2k5HkKAgCnJnaibPtHTmb7R0Kep6C0ITRlRACQVtrUNywDpQMWBt8Tc9uYFmy4LKljHsLAsK2pmqlB7YmfM2PAjZc806S1GBiiD9piSzYMCzY7vWMpvXfZUZeBoXWu2JlqeALyP29aUHl+wdXKZlGgu7bHNn7nZBgFQxAAAFBPDOY=","target_count":53541}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
