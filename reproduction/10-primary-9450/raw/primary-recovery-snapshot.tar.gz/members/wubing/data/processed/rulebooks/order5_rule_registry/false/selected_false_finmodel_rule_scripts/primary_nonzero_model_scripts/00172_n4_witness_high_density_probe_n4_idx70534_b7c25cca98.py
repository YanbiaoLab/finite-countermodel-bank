from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1832,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":70534,"model_key":"n4_witness_high_density_probe|n=4|idx=70534","model_order":4,"model_table":[[3,1,1,0],[3,1,1,0],[3,1,1,0],[3,1,3,0]],"primary_rank":172,"primary_unique_false_pairs":1832,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx70534.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx70534","source_bits_payload":"eNrtmUtuwzAMRClDC2WnI6g3MXoyFeiixw4pUb+aTYw2CNBg3iJxSJqyR6QD0I7OsxNtBJ5A3ELKrHZILLrzFCiSHP6G5CPnIPnMnFEzcXY2Vvz3U9jpA8lu85LpZnLsFQAAAAAAAAAAAAB4NImifMkscpeD0D3dnrupOF0LpTXejZRHp/I5jeFkKOd4AZnIWSb+semkTY3TuK3GRKLuLqeQOo8rvxjvrFe0JLJUk5Fl1X1o1WagQ+7mrkKr8zjPBGg2o9lynLL6OJWTYTLm5+Yao0jXouTDrk4RwN9SzTdZ02Iq5HUHVmfjzoua/I8rMtS7NVQb4o7772GTlJaC2w/avZVNN2qNaydwofR6TKZJ40OrTbmU2TkKc/THS6LNdg6j2YCyh1KM5/jzG0R9Ql/kb/pjTX3ha0nOil74mprsHlfZOjJd","source_count":411,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmUtuwzAMRI/dRYHqZIVvUh1Bu2ghWAwpUb+aTYw2CNBg3iJxSJqyR6QD0JnOsxHtBJ5A2KN3rHb0LHpOFCmQHP4GnwLnIPl0nFEzcXY2VtL3U9iZIslu85L+ZnLsFQAAAAAAAAAAAAB4NJ6CfMkscpOD2D3d7rqpOHMLpTU+j5RHp/I+jeFkKJd5AZnIWSb+seukTY3TuK3GBKLuLqeQOo8rvxifrFewJLJUk5Fl1X1o1WagQ+7mrkKr8zjPBGg2o9lcmLKmMJWTYTLm5+Yao0jXouTDrk4RIN1SLTVZ/WIquHUHVmfjzosa948rMta7NVQb4o7772GTlJaC+w/afZVNN2qNaydyofR69KZJ42OrTbmU2TkKc/THS6LNdg6j2YCyxVKM5/jzG0R9Ql/kb/pjTX3ha/HZil54m5rsHldzNz7Z","target_count":62165}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
