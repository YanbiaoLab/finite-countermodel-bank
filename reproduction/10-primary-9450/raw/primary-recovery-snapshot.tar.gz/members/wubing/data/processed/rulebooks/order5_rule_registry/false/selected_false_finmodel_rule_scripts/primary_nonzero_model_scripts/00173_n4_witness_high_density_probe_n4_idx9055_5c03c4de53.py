from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1825,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":9055,"model_key":"n4_witness_high_density_probe|n=4|idx=9055","model_order":4,"model_table":[[1,1,2,3],[0,3,2,3],[0,1,2,3],[0,1,2,0]],"primary_rank":173,"primary_unique_false_pairs":1825,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx9055.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx9055","source_bits_payload":"eNrtWEtu6yAUBeQn0Y7A6gIIolKWwYsY2G/UJVHJAzJLURfQpT5+xp/Y6ieu6kqcQRwL4+v7PxcIJARLeBVouHkAFdg9nkCDtnrXm3hRNaWo4UBOVx7PwhoT/k6lHYONtLAAXPw9f1/KPWiZu3gH+CvAWRWyIMBD2+gIWW+g5CH8Ml05OWS8EG/we/t1/BRQUFBQUFBQcCuObeIRxpBlElDwITwA2zOlQAwpTQvsrhinoGBLvArbcH6qW6UafjaYUs6VwoeOaTdIumlKuapGYzEjsoY3lTVtVRbUCkoP/KQ644SR6qLcWIKwG2GYm0x02nDTjPJkB0Fn4dVylZk6YWiYlUAW5Kr32uD0oRn6X50Feat10ZQdOa1tgDeoJlueBYWGE01JThj1VsPbxUjqbMDiudWGsOnHZvZ8FSEEjl26L7xFjULD8d9t8orvNcz7SOXovT4ikHlx2Eh7x7Jq+WwmWi08CsadrcqjucelShxiyAFjrmKHfS5IC76SbJDdOesK6EPAx3P2sO15ns7Zhnv3jNx2nfIMTZ7/OfyBs5TOSfsdySZeKrT84uaXs+XU2dYKvW8NcLscTZ1tSZagfRHBJXN3hkct0HqyIczmfAcWm/08iHOMXvQFFI6tOtYKPHX0xDVS2OTFqmeWereqyb9rlcLKEbVIdvA1ehq/7FME/djGq5ibUi6UznJ6so4uthxQ49mEFIKxYKfJ1oaxIRSTWbL5CXyaiAssie1Yt/+VUmBh","source_count":765,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWEtu6yAUXWoXUNHM4oGlx5I6evYA5bGMSEWEBVSGUYtUC3j8jD/B6ieu6kqcQRwL4+v7PxdtsDY53BM13jyb3uwej6ZVW73rjjygjnPVUoPnK09HAqrK/51LO3sbQQKMObh7+r6UF9Mwe3EOcFcjkyoiI8ABguAI3G2g5MX/MthbOWK6EG7ke/th+BRTUFBQUFBQcCvOTeQRVSXyJKDgQ3g2YGBKnhhyHhfYazFOQcGWuCegpfTUNQi19FhJzilFSF5qBu0gaacpZKsaD8VM4E7fVNYgQElQQzi/0BOqKytM9AdkxxIl7QjD7GQC44abZpRHMAo6EqeWrczcClPjrGSSIFu91wanD83Qf7skyFmtDqasxWltg75BNdzQJMg3nGBKcZJqsJrcLkZiZzNALq02hs0wNrM/VxEi9NSl+8Jd0Mg3HPfdVVpxvYY5H6EUvddHBDgtjhv54FjW589mgtX8o2ba2fo0mjsc+sghxhyoqqvYYZ8L0oKvJJtmr9a6RLsQcPGcPAwGngdTtsnBPRO3Xac8U7Pnfw5vepHSKWm/I9nIQ6/yL25/OVuOnW2t0LvWoLfL0djZcrIIH4qILJm7MzxBotaTTUm25Du62OznIaxjYNYXmli2almrcdTREddAYaMX+4FZwt2qhv+tVQqAJ9Qi2sHV6Hn8sk8R9HMTrmRpSpwpneX0ZB11aDmmk4sJyQdjwU6TrfFjgy8mi2RzE/g8ETMsie1Yt/+3HxDV","target_count":61811}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
