from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1816,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":166,"model_key":"n4_witness_high_density_probe|n=4|idx=166","model_order":4,"model_table":[[0,0,0,0],[0,0,0,2],[0,2,0,2],[0,2,3,0]],"primary_rank":175,"primary_unique_false_pairs":1816,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx166.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx166","source_bits_payload":"eNrtmV9IU3EUx89vm96LDnfHJCbI/rhoRpCFLwtGm9dpEEVGTz7YP/KhNynpH8G9praLGJli+hQp1lMv2kvQQ7dSzJ4SCnqIuJaBDxWXMFi27XR/05J0kYN+QfH7PGxj59ydnT/fs/G7BABU+B1jGn3UdWIDzl/ADPUsoCSvN6gdj0kEonkuSc9MLD3o9a43GPNtHdsDrjyX+AGygvXsWGu4qa28aJItmzfyw9AGZbD6SXFDUslREHm/OBwOh8PhcDgcDofD4XD+exC1bM3WRSVx7HIWLZwjkozYWVXC4sDQQIWeQ5XpxHhIgykALjAIGHYWqaUz9GDtJQ4Mur9+xLtndw427svggZ6gk0EwdWC66H5vNFWVHBaGFqo+vbkCUTIR1vtcLFIzrZpZxUNaNxXJ8nvoZzQjWXQ3lMvVo5osZmjbJDnYJYtFdZKDQTAd0dMyfzg6Pj2VpMGwveu1OOuRX4VZpJZyNywq4giGSoLls0jT6paW0O+ok9iI7cOWbbXXX5xpnaJiU/bfqj3dOtl/3Gn/98W2uT8Vs+nYr0HfvOJ2B2yJRBoFmclAqoiuXZOxe0ZySMjNyDuStvcJ8TQbsbkihmIDfAsOSOIciYMqWGILsBLbak2Xu/Zz6n9WbFerR7FeJBub3j10CVju3VJJcBFj4qUCS+CNVKp23e7MszbWfQMDKsFH3TsFMAF8ALsLzF6ZuJOtCRVvbHpjzRXj1H3ToZOTzxHHvI8KFNsv79Xkmd7wKfFczt0n6p7ABRt8KbBtF63FtdFlb8Zye87/fQORgsXmP5jApLQUG5Vkd8YvV3c1WQsTre1PGIz/jrYICKogGGDmRiBqiY0OgEmYiO1Ec+ZI43uceaq1flYqxof3hm5nMTwlFTMIps/M2Vrivui1er2ztJ2cN+NwA2Y98ERg8suWa/3ynwN9ZaekMDehpQDP1njnuxWoFRDtG2ukH2E=","source_count":2264,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmV9IU3EUx8+2bJDEpXoQsrxED0GBPWWi1e0h6CV96alEoydNNCORu9S8F6J/WPjWg9E/H3yKjCJI53WLQXuRMohcNPcHwRGO3cmUe3Xb73R/05J0kYN+QfH7PGxj59ydnT/fs/G7BBEV/B11Mn2UJJJFzl9ACHaUgK6tNyg9R4gffXkucVTUFB1vj603iKV9PR/CyTyXRBBtpvWcXms4J6+8GNIsW8z/w9CHc7j6SR5RV8gjNHi/OBwOh8PhcDgcDofD4XD+ewBk28SnYtX98IoNLFINugbQPbXA4sBQBJWeQ81JRDxGg6mISRQJihkWqTns9GBtH7Q0JzZtg1O33jUPv7TD845QikEwpaVy6US7zznlajSbSqa27r6MPlITkNqSLFITrJpZxQNaNwXI8nsQYTQjNkiMzGqT9bJm2GnbdC3UpRlLY3qaQTAJID5Q+sRXW1nlosGgt2uPUR7X9gZYpOZMjBSrRgMEF0Kz5UDT6tSLIJIe09mIbfvnj+MX9t/ur6JiU1+cHb/TX936IJX598X2pdXpzUrQKmNbqZpIhLNutwNMjclAKgDJt9Xek6KryczNyE7iyLSZHgcbsSX9oppF2IVpdEEZ8aBiWmILsxLbak2Xu/Zz6n9WbJcm62HUIBub3td0CVjunfpCqBi8xtUCSxDzTysZKZPKszbWfQMRpzFK3btNFBCjiG8KzF6tOW2bCC5ubHq9gzO11P3r03vVBwDqYkcLFNsv79Xkmd7AXeNmzj1qSPHw9SxuLrBt16zFtdFlL3hzey7yfQORgsUWeeYGl17krde1hD2iTXYNWQsTrO1PGIz/+z4/moppiijkRsBniY0OgECYiO3+oP3x8A6oOCT3b1FnahtfBc/YIFClLzIIJlWUZQc8Ud/FUal7vpfcEDx4HsvjeNhk8suWa/3ynwNpZac4ITeh84gH13jnuxUoFxDtG+DNUdU=","target_count":60312}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
