from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1733,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":52678,"model_key":"n4_witness_high_density_probe|n=4|idx=52678","model_order":4,"model_table":[[0,0,0,2],[1,1,3,1],[2,0,2,2],[1,3,3,3]],"primary_rank":182,"primary_unique_false_pairs":1733,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx52678.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx52678","source_bits_payload":"eNq9WUFs00gU/eNO26lQN3YqUSQq1TVOygEWgSq0hwpMd5AIRSoHDkiLBFQc9lJpJS67l40LRSTqJZtWhBsVJ46cVtxIKw6cEJyW22aRVssxaC8copqZsRPReAY16oy/VKfJt/387f/+f3/8YCgAaOaAW6fAt80L4sum2AZiC1Pgii/BEN8tegJSa0XTcgdE0ZRFZI7P0ak/KMVpRzMqrxeKnuSQ3wGwFKTdgFtjMkf4/6sJEsg8U9iW/g5bvqMIpVDF8lCOI7ClRwTEVZzLUvwO7aH482P/HuFLrDh0KnbgyVQoscN/R/s9KPZvj/Q7jkCRbbtREnG/Q7Ev2rvjLfZn955YbNMBZGCfE7TGi0oGaAkYtmxkHqwVg20o00ardQRYGTKxMA6t/KFMYImHeswyiNaO0VAnJ8qXomzosl0Bdv4hoyavKiHnl2UKMyHbf7UfIeSl1c65EMQcNUe2lUePKzWadxzPo7RSsRcIMke2lxyofsnzFuhahTjOApkxSLbG+6K3ky9R+rhiOzMeA8PmyBYdXrxCry9Xq2TCKXpX6JGZNYNk+3t5vUp+OnHauV3coWtVcmzNNkO2cpfLrTHjhWQ36qUeNg7WjFkt7qlCx2glW08SPeccMN3ZTjJWi3//vL7sWUbBWqPtMquKuzm3qz5sg2idwu7Np95OtHiNJsJQqic1kW06jsjNJCW7UvcEgwwLptHeTCzNf3L+GcOu5YYsONZuWJyGmk3ztw/V2XPe/CeMw1k7hLaDeBc1lCg/LM2vsrNjDsTUHZiVXKOrszYQBgRIzB0YDBaTFntWjM4CyHjRgk1f9Oo8Ml+OWcrXKe/VBDKxqyyyaoUgH2XB7sv5ku84M6uZyMig5FV9z/NrDIiPtTYyKSOPl3ph2OYf21eDet74KLWFa5Q9qDrJpLNtJsN5r+EYJRvLQmS0Un1ttkVcnvM4k1a6ABnKyCAjcdBdtcnSomj2Ww+1k9MpLNXrjOI2b0T/Uq0z291vlA+yta6zXLKZjXc2JZqPdI7cbTYcsilU6debqsqFWwi/ZxPdXxe1ysiblkoYh3yi01ueExkpu4VMWYYtvcpyFGH55TMggMkbejubciVcCL6NlTtU4wrspq/o1QGnxaWnXIeJeUBHeQvzAHI6MSAIV+acbr5o6mwKz/hcDW1tj5yBO/pupLLeiuX+s+/1zmzJ+6P00n886u+1j7JrGx5ggWQxrpSNZ5X+dRo+6u+jD74eiGyiUvKZba/jVwv1Z0bwC5IUmwEqdvKupp7mQClN+dKcIy1u+zacyJKUuYq0OegCiYCbTJ/7UOqnt8MHQ2s3YIDgDtoMvosz+l46ju1haY3ez0Up9c1Yr0T1meQVX/1nTyZEB5aR42dTcYwcTZ33/ng6x8JnA9zeLyR/RSA=","source_count":2586,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNq9WU1oG0cUXqNDLsE6JhQS9ZaeEnrKodjKrfTUo0/BvUXBVnUxUogTr3ppL4WCLz0EN4EUcughhjgKZOpugg8hmIT8HGJps16DC3bB2lVN8dge77zOzK5ErJ0xFp7ZB15Zerv77dt933vfm7154AAUO8At1+Lb4l/iy4TYOmIL6+CLL84B3836DqRWsNbkDrCs9QjLHKesN98jRNKOolWfajU9ySE/ABApSL4Ed3dkDvv0V1vYkXnWSSj9HcbdQBFKq0rkoXygEEqPcLCvOFek+B3yB/Hnmf497CtEceh67CCbqVBih3sR9Xto7B/d63dsQJNtu1Ficb9tsS89vONd9hf2nlhsaw5kYKcStNLXtQzQEjAShdQ8WCEGm1SmjVbLCbA6ZGJ2HFr9XB3DPA/1Y2QQLR+j0VxHlC9F2dBlQwLs2Q1GTV5VbM6vyBRmQrazlT/B5qU17PjgxBw1R7bZ69dqFdQOAs9DqFYLFzE1R7YrHKj8xPMW0XQNB8EiXjVIttKFpjfSbiB0rRYGqx4DI+bIZv2z8Ag9mKtW8VbQ9B6hjdVpg2T7fG6qin9//zr4rTmCpqv443Rohmz1LpcLO8YLyZDVSz1iHKwYs1rcU4WO0Uq2niT6lnPAdGd7x1gt/v3mwZwXGQUr7ObrrCoOdfyu+ggNouVaQ/eueiPWwh8oEYZSPamJbGtxRH4mKdmVuu8ZpN0yjfbl1vzScHB+h/iRb7PgWLthcRpqNsUfz1VXnntLw4TYK6EN+YDyLmooUV7ML82wsxMOxNQdmJVcuzMrIWAGBFTMHQQMFpMCe1aMzgLIeNGCCVf06jY1X45ZypcR79UYMrGHLLJqDVOXZsHux+2GGwSrM5nISKfhVV3PcysMiI+1ITUpIz80emGE5h/bJ4N62/goNU4qiD2oMs6ks00kw3mv4RglG8tCarRSfWphhH2e8ySTVroIGcpIJyNx0F21ydIsa+Woh5rr6BSW6nVGcZsnrc+Q1pnt5yPKBx6f0lku2czGO5sSzaU6R+48Gw7ZFKr0601V5cIt2G/ZRPfFU60y8l6kEsY2n+j0ludERspuIVOWdkGvstylRH75DAhg877ezqZcCReCb3L2DtK4AjvhKnq1w2nx5CrXYWIe0FHe7DaAnE4MCOzZ5aCbL5o6m8KzvVyh46N7r+COvhuprLdiuf/lBb0zW/L+KL30H4/6h+2M7Nr2B1ggWYgrZWms1r9Ow0f9Y/TBywORTVRKPrMddvwU0f7McH6hkmIzQMVO3tWU0xxopCnfWA6kxe3YRhJZkjJfkTYnXSARcJvpc/+X+unS/snQ8iUYILiTNoN/44y+nY5jdF9ao49zUUp9s9MrUX0mecVX/tWTCdGBZeT2y1Qce3+nzntrO51j9tgAt/d/KAEsFg==","target_count":59990}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
