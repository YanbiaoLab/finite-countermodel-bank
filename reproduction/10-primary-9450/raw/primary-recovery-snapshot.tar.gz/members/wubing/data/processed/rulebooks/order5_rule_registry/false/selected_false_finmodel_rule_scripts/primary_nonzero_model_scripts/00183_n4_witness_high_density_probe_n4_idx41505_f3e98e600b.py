from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1726,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":41505,"model_key":"n4_witness_high_density_probe|n=4|idx=41505","model_order":4,"model_table":[[3,0,2,2],[1,3,0,3],[0,1,2,3],[0,1,2,3]],"primary_rank":183,"primary_unique_false_pairs":1726,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx41505.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx41505","source_bits_payload":"eNrtWUtuxCAMNcgLlhzBix4E9WRe9OCt4xA+gWmSqaoo8ttMIgi2n8EfxkFKMAKCHw/cFjFujyTqv7MWYfUS6hEHsjLL40bQIjiED5YBL+8enBcOw0spvuiIDEfoZl4FelGk9ZcI0+E0UnwPNYWKCQDnWCPInxsMBoPBYHgLQWqBEwl4mc7nk/fjgThlbVwd/tRzVs0YDBfwhfH45FQOG18RxjGBw62JabugEge1DYqptELuSoiM60LYNzssXRN3ljmR5ebh2KnRU7Y+lxka2GMrrW7tqtWosrxTvCdm4Ahulq9j4T4xaegc8V59OO9jw5qqxrYHOpfZwp22P1HMrCWxsyjnCOLCGjaOzFcE0Hk1CLOkBNPyEe5zEm6CdK+57GEV1LBW6ZXdVim3ytAf7jYKW1j7SzQXbfFA4XHwFisYtY8B66keermO9XY0b9azTTI0v+zcfoP1cw9CrOom3hVxfRjY7aRZVYV3yGzmXYPhvw4b6Z99D6wHvgHLYiFL","source_count":245,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWUtuxCAMPXgXPlnFQbrwEViysMCtcRI+gWmSqaoo8ttMIgi2n8EfJrFzPAJxHA/cFt5vjyjqv7MWUvUS6pHEsjLI40ZQFhzCF8hAlPfIKQqH4aWUWHQk4CN0AywCoyjS+kuE6bAbKb6HmoLFBOZzrCGvnxsMBoPBYHgLQWqBEwk4T4fzyfvxIJqyNq4Of+o5q2YMhgv4IH98siuHDa4IA+840dbEtF1QiYPaBnlXWqF0JUT6ZSHqmx2Qrgk6y5LISvNwnNToKVufeYYGdt9Kq1u7ajWsLO8U74kZOAKa5etYuE9MGjpHvFcfzvvYsKSqse0Bz2W2cKftj+hX1pzYWZRLyD6zRo0j1ysC7rwahFlUgjF/RPucRJsg3Wtp9bAKalir9FrdVim3yNAf6DYKWFj7SzQXbf5A4XHwFisYtY8B6KkeermO9XY0b9azTTI0vOzcfoP1cw+Cr+om2BVxfRjY7aRZVUV3yGzmXYPhvw4b6p99D6wHvgGBD0/r","target_count":62331}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
