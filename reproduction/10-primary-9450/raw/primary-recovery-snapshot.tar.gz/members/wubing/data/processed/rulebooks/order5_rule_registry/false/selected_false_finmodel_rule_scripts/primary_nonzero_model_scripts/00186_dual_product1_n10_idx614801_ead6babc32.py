from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1705,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":614801,"model_key":"dual_product1|n=10|idx=614801","model_order":10,"model_table":[[0,1,7,7,3,3,9,8,5,4],[0,1,7,7,3,3,9,9,5,5],[6,7,2,3,9,9,4,5,1,1],[6,7,2,3,9,8,4,5,1,1],[3,2,9,9,4,5,1,1,7,6],[3,2,9,9,4,5,1,1,7,6],[9,9,4,5,1,1,6,7,2,3],[9,9,4,5,1,0,6,7,2,3],[5,4,1,0,7,7,3,3,8,9],[5,5,1,1,7,7,3,3,8,9]],"primary_rank":186,"primary_unique_false_pairs":1705,"rule_id":"false.finmodel.primary.dual_product1.n10.idx614801.v1","rule_key":"false.finmodel.primary.dual_product1.n10.idx614801","source_bits_payload":"eNrtWVuOwzAIDMgffHIEjsLR3I+9924fUtra4zq1zWq1japKKY3JYIaB5Gvz7fw5H+nyXT+xy4nvlsphyLARMggyOFyLkUGRIcO1XkFRQVC8uBMMxRF+vl5EEIpDKAygJH4OhEGo9GLXSmCt//oWeUioN4p0ZqHQUqSzHApNQ71xpLNfIVviSLJ5SEyDyZY0lGwclyofsn2U7aNs/0zZFtRoP2KlP0e2uIpsGGJaRjamqqniUAUHKXWSzYoUsErC1pPUu9MOk60ctsa3llm6E1Y2ytdf7G2yEbhadm+6B9dGBOTu3nMZKH9c+zRL2bjcQSpYoYMV3LYmtU9F2kxRNimidjbZXHXIN0d1ZuQeReB++VdtpZb+LEV3vmSwlN3IRiFy7rdltajA+kAPbgTLDpDtrhbyQ9rQjpkn6ShFdtDWX2cC2kiaTba4DloHoU+b2dIzsjyBbI0Y58nTpLRD6HO5ADMu+/wUNdiurZjBE1LoFT1zDh0LVD1wBoevFlbM4I73SDqpmQ6Tjfq8yeD2wpckFRheDiT5HbIFPbpJq+6sSbaQR3e6sGxAZeNyrvBOHbTDZJM+0fPBbgyTjbt+OtZCfAMSjyDb","source_count":289,"source_output_dir":"organized/mining_outputs/out_exp121a_dual_product_followup_c","target_bits_payload":"eNrtWVuOwzAIvPd+1EfjKByBTz4syG4fUtra4zq1zWq1japKKY3JYIaB5Guj7fw5H/nyXT/hywntlsrByLA5MigyEFzLkEGQIcG1XkERRVCouBMMhRB+u17kEApBKAagZHsOBEOo/mLXSmCt/9IWeWioN490xqHQcqSzFApNQr1ZpLNfIVu2SLJRSEyDyZYllGwWlyofsn2U7aNs/0zZFtRoOmL1P0e2uIrMGGJeRjbzqqniUBQHKXeSjYsU4ErC1pOUutMOk60ctsa31ky7E1Y3T9df+G2yObhad2+yB5dHBOTu3lMZKHpc+zRL2azcQS9YIYMVnLcmtU9F2kxRNi2idjbxXHVIN0d1ZqQeRbB++RdppZb8LOV3vnSwlN3I5iFyTrdlpajA8kAPawSLD5DtrhbaQ9r4jtkm6ahHdtDcX2cC2kifTba4DloGoU+b2fIzsjSBbI0Yp8nTpLZDSHO5ADMu0fwUZdiurZjBM1LoFT1zCh0LRChwBoevFlbM4IT3SDupmQ+Tzfu86eD2wpckFRhUDiTpHbIFPbrJq+6sSbaQR3eysGxAZbNyrqBOHeTDZNM+0aPBbgyTzbp+OtZCfAM58VBb","target_count":62287}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
