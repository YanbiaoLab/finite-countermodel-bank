from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1696,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":7472,"model_key":"n4_witness_high_density_probe|n=4|idx=7472","model_order":4,"model_table":[[0,0,2,0],[1,1,1,1],[0,2,2,3],[3,3,2,3]],"primary_rank":190,"primary_unique_false_pairs":1696,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx7472.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx7472","source_bits_payload":"eNrdmU2OozAQhQvLC7IzaA5ALEbqY1iRF9CrPhKRGIns0qgP0EedKvOTHly0hNqVxXgRJXKSR5n66pXNH+UycC3Q+KjplfvwC+iTy5yiGT02wI3P+t2X7Mzva10O3MRLi7/xOp5wrb3V1jI/eVVtzYq8jY3NuIludOVJczPfh1IUXCi3ehyGnVCAU3FtddNKHQplWsayUVEoQeHuyjiUMK/LOJSwKPXdRaGEieqqtyoGcnzNl8CA1qijK63+Wd8O6C/d1zBR5935rubTIOGg1dZ4UXgv7l5cbcrfu1dFNjaVkhWbcw+z2V7K1ntZtY96FWrsbchFxQKJAI29DkCpX9mLllOjgoBqbV0U5xuqec+Cm2gQzCZDBqxCBnSXQwEWehmxqaYssA1girNCTSMHm/f9DFtRWEtLaS55JgLbbRUKqen7IS+KS35+BmwYVnG2KKafAdu0lPm5l4HNr0KBgWkpz71IlryVwX2RARN8QHa8li3aWkUtArqu8AiwWYLNPcnZVtiUEVZbYAvOBuLOhkIAaKFV8AHJcjzBhjdvYgBTE9s5ufgeztbBTlOX2NmyxdnkYSNng9DEIgMQnE2BFoRNLbDlk7NhqykE2ylEhEJ5SE0AydWkNhKojcyykJq08cmeBdtz28j/ydnGhxAZztwk9EakmpCzzULBB6al7M1FBja7CpEPmGkpsbN7hrNVIAd27GzUkRtwcns2jGhi4OTI2UxViTqbWpyNwpLes2k9Oxt2dxY3Gp1U3aI2chEiw0HYAN8KhRiczczOFo48CuE2Eh5tpCkycE5KjZwNvjhbJZkjs7MxI5xU4T21qfds7AwdmLnEZyZ0Rsge+ThFDV91G5LC5ncuH4Wmhi8heLOzMTMnaviutVWJYWMnUIjOJ31a2OxOY1zfNXR6zFPDxpIczmPvTmVgnwKbIgbQV3Va2NiT8CCkTj4cFCcqL1MbqVjYNDJwXfYeeSLYTuxtQ6GZAfpaUmfbhQ03PbSUJs1SfgMb7a7uYRsHiTbE81Oipoq2GbT7YGr09poOJexLO6/athIyld+plvmHIxV7fUgS5Uh8N5sqKs7dQdj2ntUwlZ/S5ofONpeoLUzM8yrmKdFR2B79wKYgv0ddENXoHzrbTq518dM7NIMfw7b2A5uCTFt9pkbHVB6BTa0lagtbVDqpRsewHXK2nVwLmwKmRm+GPgTbX2jzIcU=","source_count":2264,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrdmU2OozAQhY86B2ilswNpIoUj9aphYUU+RkuDHA4wAu/CwjLVVeYnPbhoCbWLxXgRJXKSR5n66pXNb68H0CXQeKnplfvwF+iTHrSnGXeqgBu/6lfVsjN/rnWbcxMfJf5GuXhClyarjWF+8u7LmhV5O1Vm4CaKk24fjpv5PpSu40LJ6lOeb4QCnIoum8x5vyuUcRnbykehBIWzbuNQwrxr41DCotRnHYUSJpqrW6tY6PG1nwMDWqOCrrT5Z30LoL/UX8NEnVetippPg4SDVtvhReG9OCtxtTF/z8p3w6lqvKzYlHuYzebWlkrJqr3Ui1BlsrwXFQskAlTmmgOlfmNuTk6NCgKqlXXX3TNUU4oFN9EgmO2ADBiPDLiihw4MXGTExpoyw5aD7e4eNa0cbEpdJti6zhhaSnvrBxHYskUopKa65H3X3fr7EbBhWN3doJg7ArZxKfv7RQY2tQgFBsalvF9EsuStDe6LDNjgA7LjvS3R1hpqEdB1hUeAzRBs+iBnW2DzVlhthi04G4g7GwoBoIU2wQcky/EIG968kQFMTWzn5OJ7OlsBG01dYmcbZmeTh42cDUITiwxAcDYPThA2P8PWj86GraYQbI8QEQr1ITUBJFeT2kigNnIYQmrSxmc4CrZj28j/ydlOTyEynKlJuFiRakLONgkFHxiX8mJvMrCZRYh8wI5LiZ3dEc7WgBzYsbNRR25By+3ZMKKRgYcmZ7NNI+psfnY2Ckt6z+bc5GzY3RncaBRSdYvayFmIDAdhA3wrFGJwNjs5Wzjy6ITbSHi2kbYbQGspNXI2+OJsjWSOTM7GjHBShffUpN6zsTN0YKYTn5nQGSF75KM9NXxNlieFTW1cPgqNDV9C8CZnY2Ye1PBda+MTw8ZOoBCdT6q0sJmNxrg+OyjcqU8NG0tyOI89az+AOQQ2Twygr7q0sLEn4UHIP1Q4KE5UXsY20rOwOWTgOu89+kSwPdjbhkITA/S1pM62CRtuemgpbZql/AY22l2dwzYOEm2Ip6dEVRNtM2j3wdTo9TXtStiPclq1dSVkKr/2JfMPeyr28pAkypH4blZNVJyLnbBtPathKj+lzQ+dbSpRa5iY51XMU6K9sD37gVVBfo26IKrRP3S2jVwr4qd3aAY/hm3pB1YFmbb6TI2OqdwDm19K1Bq2qHRSjY5h2+VsG7kWNgVMjV4Ntwu2T+N+T3E=","target_count":60312}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
