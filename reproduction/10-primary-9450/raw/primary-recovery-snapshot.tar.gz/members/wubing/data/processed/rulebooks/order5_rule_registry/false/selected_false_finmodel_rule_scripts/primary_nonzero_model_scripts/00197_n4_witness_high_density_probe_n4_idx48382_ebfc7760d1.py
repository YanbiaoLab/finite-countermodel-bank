from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1625,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":48382,"model_key":"n4_witness_high_density_probe|n=4|idx=48382","model_order":4,"model_table":[[0,3,2,3],[0,1,2,2],[0,1,2,3],[2,1,2,3]],"primary_rank":197,"primary_unique_false_pairs":1625,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx48382.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx48382","source_bits_payload":"eNrtWUuOIyEMdSEW9A71CRgpB0GtXuRYtNSzz5GHwoTiY1egA9Es2otIiYsy/jz/8hesAguBvsOnBYNfhDKeaRwIkHDZOSo8KIEhw3I2xzDUJrWlGFEwQfijaRkaOf6NFcOhgipwi7MyvK3kRlX8tTY0gX+j52ow4cE//lr+28F1+zFxVyXjAh5LNkxciMfgI1w248ZjEDV4b0zjkHMDUSuJqjgpWq+E6zRWuati7j7NfaQKH6VvppaZOcXCK0ltr5TGxu8Kig57ESHOX0Suja6FxCaEJSSO3FKjaT7ZSpBeDDYmtS0hNsMuBBuR6NeBDQWZlO4XwcHpTJBMVWdRZtEPMD+XPthrLEidFgyL+bx7mAk28hoLwgbBRl1jQdiYvIMrC2xP2NhRsCWrVddoO0sibMYyAV/ZJNfCPjDAjyob4U3KAGMuZSubLjAAbJPduFTzpuArGwG24l6PZbTOVJWg8tFqJmAMwMlQTBvZbzU3IGNrwabHrKb7ZZj+ykZNN8TwlMB2HExBigMRMtEubGUjhiyitJMykI1HAJnRLuIQ5FLvY4Cc9QgDkDKOQe/QS8PpTEhYjTAAJSOZItdLwNloSlmNMAAlI5mict7JhNwXNpSMI4BK550N6n1hQ8k4Aqh03kkb2Rk2p0AonfcLtl+w/W9gY1uJW1Xp5sxsHOfdenFCTRUnudHTirek+qwNSgQbQVfzpbzbktNmSIxgI+jNCzKbNPCJTpdTFiSMpcyu8WXyzIZdCzFKXRzI2TMp20aGfezNRhjxvf5QxLJt5M0SYdP89DlpQbJPGvXY9GycsJXNHjPpCxYkxEa0b4x7DLY2sS/px9nKNjDGcTIkE73X1jf62tip/VNjN/xA4MTV/56iWhw2OZoqBmoYbOarB7IE2NxPwNa3sN7mgI2INW5188xe2+X9wJMrxe4FSegHulaSrv1HbXT1b8VG9AgnS8MsDgeqeWwjiRRFrA31vSGKCSC2yMPbyDZFUYbdBfn4TSViGy0I/wBX9rn4","source_count":1497,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWUuOIyEMPXL2M1JzrCxaLQ4SaThBi12zQJSbwoTiY1egA9Es2otIiYsy/jz/8gekAQmB/oZPCQq/OKM8UwlwYOG2c0x40AJDiuVsgmGYzWpJMaJggvBH1TI0cvwbK4ZABU3gFmdteFvJjar4a21oAv9Gz9WgwoP//LX8t4Mr9mPurkrGBTyWbJi4EI/BR7hsxo3HIGrw2ZhGIOcCrlYSVRHWtV4J12mscldF3X2a+8gUPkrfVC0zc4qEV5LZXimNjd8VFB32IkKcv4hEG10LiU0IS8gduaVG03ySlSC9GGxMaltCbIZdCDYi0a8DGwpSKd0vgoPQmSCbqs6izKIfYH4ufbDXWJA6JSgW83n3MBNs5DUWhA2CjbrGgrBReQdXFtiesJGjYEtWq67RdpZE2IxlAr6yWa6FfWCAH1U2wpuUAcZcylY2XWAA2Ca7canmTcFXNgJsxb0ey2idaSpB5aPVTMAYgJNhmDay32piQMbWgk2PWU33y1D9lY2abojhKYHtOJiCFAciZKJd2MpGDFlEaSdlIBuPADKjXdwhSKTeRwE56xEGIGUcg96hl4bTmZCwGmEASkYyRa6Xg7PRlLIaYQBKRjJF5byTCbkvbCgZRwCVzjsb1PvChpJxBFDpvJM2sjNsToFQOu8XbL9g+9/AxrYSl6rSzZnZOM6n9OKcmSrOcqOndF9J9VkblAg2gq7qzXi3JafNkBjBRtCXF6Q2q+AdnW6nLEgYS6ld49vkmQ27FmKUugmws2dSto0M+9iLjDDie/2hiGXbyIskwqb56X3SgmSfNOqx6dk4YSubPGbSFyxIiI1o3xj3GGxtYl/Sj7OVbWCM42RYJnqvrW/0tbFT+6fGbviBwImr/z1FtThscjRVDMww2NRbD2QJsImfgK1vYb3NARsRa9zq5pm9tsj7gSdXit0LktAPdK0kRfuP2ujqX7qN6BFOloZZHA5U89hGEimKWBvqe0MUE0BskYe3kW2Kogy7C/Lxm0rENloQvgH0e7cv","target_count":61079}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
