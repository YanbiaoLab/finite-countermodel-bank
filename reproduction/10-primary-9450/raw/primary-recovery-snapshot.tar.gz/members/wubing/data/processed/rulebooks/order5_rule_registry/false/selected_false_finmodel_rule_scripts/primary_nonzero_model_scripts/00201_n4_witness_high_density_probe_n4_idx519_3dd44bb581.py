from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1611,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":519,"model_key":"n4_witness_high_density_probe|n=4|idx=519","model_order":4,"model_table":[[0,0,0,0],[0,0,3,3],[1,0,0,1],[0,2,0,0]],"primary_rank":201,"primary_unique_false_pairs":1611,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx519.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx519","source_bits_payload":"eNpjZGBgaGAgDhw4wMgwCugBJjAwKCiRpqWGUeCHPAdJWuSbGf+xG2CRUIAxBPDqd3gg0MCYMBpbo2AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAWjgLog4SmceYDVstFmNESGBPj3H8788////3qaWnbgvzyM2QC07D8/TW2LEGcsEGRomANkTgj2+9gCEutQZ6GRbcCg+8TEUCAJDtP//+1BYsrraZXZXjCAR/05gGHKbMFgC2Q6DJME2fB/v94kDg6PR5wdDKA0Mp+D4aKwklIDAxMtbLuw6ZCCtgTDZF4DhoRNJ918GCUYDAySuBiYaZTZPP+Ehj409zzjA8ps/2cKKik9i+dcOmXoR1uEJfFqHyySYZIbLXoHQ2YDloaCjAwd4CkqF0jR2CDgNCz8to+B4w8/y4N6Rg4GhQ/2AqAJVaZ//5kbhoHXfkjwfLBvaPxvyKBhcOA/AxsXQwPjD2BtmkAT2wDkx18Z","source_count":755,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmbFKA0EQhiekuEpTioLmDbQQ7OT0AQLWgiAINiopUyjZgA+QJ5CzCwQbCUREJIdCtPIQAlp4XETwLCQXlGTV3O24F0kqkQRcMWG+6mfvhp+d3ZmFXYGIDHtD1wUSf0ES0bH7C9kVnlblfYVUd0Tkzfrmg9MR3o/xpbjHhEGrRRAEQRAEQRAEQRAEQfwuxkRX6h/l9DllZCCIQFdGASCj1EyHakcyaQZ1pW65J5GtIVuTMnlwOLodjqVuW4rcZOpGAsw+tnMKYIZjd0uqim0M27f+XObUv8AzKUtDsiEZLFxvcX402UxhuEdWOU4/2zbDQIXbTGLeqbi4+WKhkZg7LggXLWuvgb6iYitG8/mpy+JsISw2WK/Z9vh+c3lj8JctV+793/jKQ3BPrfc/FJvshjWBqfYT1clXa2Te6VDMbRF5tN6KZwRHJ2Z64YNqEAGfDcHUNPc1ZrI0XOGNpQO+N5AJTZ6mhhK3T2eqEh0=","target_count":61821}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
