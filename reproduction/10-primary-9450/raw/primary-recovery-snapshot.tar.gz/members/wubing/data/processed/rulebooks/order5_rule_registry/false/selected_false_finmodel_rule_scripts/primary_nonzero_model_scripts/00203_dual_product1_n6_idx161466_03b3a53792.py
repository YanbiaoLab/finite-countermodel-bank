from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1604,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":161466,"model_key":"dual_product1|n=6|idx=161466","model_order":6,"model_table":[[0,1,4,5,2,3],[0,1,4,5,2,3],[5,4,3,2,1,0],[5,4,3,2,1,0],[2,3,0,1,4,5],[2,3,0,1,4,5]],"primary_rank":203,"primary_unique_false_pairs":1604,"rule_id":"false.finmodel.primary.dual_product1.n6.idx161466.v1","rule_key":"false.finmodel.primary.dual_product1.n6.idx161466","source_bits_payload":"eNrtWVFyAyEIRccPPj0CR+Fo9uZVsrqroqZpkk4nvkmz6bKDgjwE9ytAgQNg+aRfClhk4BxgvNj4h2DCIXoMCOSTyqRMNMbfopEZTLpGaYhfaUBa6PLA6RF0UCxAURLCTXWSGkoq83wdeDFFhpIvsI+a8kx4L5ONc6E8r6X5IxCEsqTiZ5/NN8aJ3IEV5eEaCYMYUOCOdXor8Jyu70WtByrr7EypDnMZBWtK6O4oj0+jycKHIYTOUTCNbo7uviMQDWy8lGySpVNQK2RrWPN1IZuhMcvGZJO0FEZkc03Sn+0PYUk2OiRctoEyTdeqDLUi1LXNNhF3DoS9iHxj2TV/dCFexnATspljUthulYofL2Sz49yI8y3rPjyldthk+29key8OsqXpMnVe68N/RrbyPI9d+c768LCI+oXow2ZZ3Xq9jrouJqleE5HHPt5ICYkmSEcREgv/oKeo0nXUd6R+XazaMEciUhFzX5v1+T92J7wYa+zKXEZ2XpPVND8sI00ey87q/tzSNdtUEzZ9A6bvbAQbGxsbGxt/BDrrANYOVLA9U1jvWnZdRnaKuK4V3Wr3//QjC2sHBdJZwQ16zhnC5sOLyTYqI21pLvBaH9KSXjOyOa8X33I2wTVzTE82/xOyhRxiJr81mHUxoZTJsxjFYbbx50Ckzc5dTUgDNbZwb4eZki039gQ92Xy1FKx6jhb//90BiZileE1LGPhgXql7NqpzjdVbMt7paZynw+FLGy/4sZvg78G3kxhxId5e4OUoU1p95Va+wXeR7XZAYtJrU1OVOcoBiXJrfShyxTceCTXU","source_count":459,"source_output_dir":"organized/mining_outputs/out_exp119a_dual_product_followup_a","target_bits_payload":"eNrtWVFyAyEIvXk9GkfhCH7y4ShVsrqroiZpm0wnvkmz6bKDgjwE98twgWMG+aRfCkBk7BxTvPj4RxzMIXoOxGiTyqRMNMbfohGAQ7pGqYlfaUBc6LIM6RFyXCwgUWLMTXWSBkwq83wdWzFFhpIv9s+a8puwViYb54J5XkvzR0A2ZUnFzzabH4ITuWMvys01EgYxoMAd6/RS0Dld24taD1TW+ZlSHeEyCtWU0N1RHp9Gk+cPgzGdo3ga3RDdfUcgBt74U7JJlk5BrZCtYc3XhWwBxywbk03SkhmRzTVJf7Y/mCXZ8JBA2QbKNF2r0tSKSNc220TcORD1IrSNZdf80YV4GcNNyBaOSVG7VSp+vJDNj3Mjzbes+/ArtcMm238j22txkC1NF7DzWh/+M7KV52HsylfWh4dF2C9EHzbL6tbqddR1MVH1mogs9fGGSkg0QTqKkFj4Gz1Fla6jviP162LVhjmSCIsY+tqsz/+xO4HFWGNX5jKy85qsZniwjAx5LD+r+3NL12xTTdj0DZi+syFvbGxsbGy8CXjWAaAdqFB7prDetfy6jOwUQV0rutXu/+lHFt4PCqSzghv0nDOYzYc/JtuojPSluaBrfYhLes3I5qxefMvZBNTMCT3Z7CNkMznEQn5rMOtiTCmTZzFKw2xjz4FQm527mpAGamyB3o4wJVtu7JF7stlqKUD1HC7+f98BiZileE1LGPRkXql7NqxzjddbMtjpaZynzeFLHy/0sZvgzwG3kxhxId1e4OUoU1p95Va+AXeR7XZAEtJr01CVOcoBiXJrfShyxTcudzti","target_count":62117}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
