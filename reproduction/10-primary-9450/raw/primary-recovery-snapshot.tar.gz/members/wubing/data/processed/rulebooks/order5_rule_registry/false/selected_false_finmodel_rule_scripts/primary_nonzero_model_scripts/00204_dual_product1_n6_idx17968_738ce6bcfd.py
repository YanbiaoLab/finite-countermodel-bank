from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1581,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":17968,"model_key":"dual_product1|n=6|idx=17968","model_order":6,"model_table":[[0,0,4,4,2,2],[1,1,5,5,3,3],[5,5,2,2,0,0],[4,4,3,3,1,1],[3,3,0,0,4,4],[2,2,1,1,5,5]],"primary_rank":204,"primary_unique_false_pairs":1581,"rule_id":"false.finmodel.primary.dual_product1.n6.idx17968.v1","rule_key":"false.finmodel.primary.dual_product1.n6.idx17968","source_bits_payload":"eNrdWUFuGzEMpAgZoHOSDT9AXfjgZyjBHvboJ8lFC/jo9gV+akVK6xiWFqlhsYcKQZyNglAUOcMh9ycEhHAEXnvD30OUB0vy8JEfwPMDBnlYedmrll97wOaOQdo1N8gdXHMjGTamufMd3wLsGxsXG/zgGxvxGtHBurGTnFxyJYYxtHbezcrDtulKuLZdQb7A1toijrZ1Ypdvq3Y05ueGozleYN8qV0IJYbXWJu+PddRuf53MTHf/6yGs86nkTEf4nj4OYC4RdjlFYtvvDmtCYqt2QHS/0nEjONBbJX9P6Z52BMrLhyuHTAxJOLfBBdSytrfOcQQ3hs5k0p0iqNmakXgE9MZxbkyaF1kIgUZrQ8loAqNlrfASY8Be4Z0/1Gwlkg4nBhsnvaTmPnpNsHm3cWCSNQEbf+nBLTPsFWxAYZGLLtgE1T5VwIhGG9p7YxnauDHmPCWcBVBkk/hDUO38AIaoELaai24XuTowqoMhyUWvxyS/E4MkQ5yIkpr8M1g1sAGuMthicspLxVPLyiKJGNUuucROrfXCtjY2WYhSS88kUsEENbAdhBcZ1bMiC2pRK2CLDLGilyKo4e1eY5pDcLo8cid1/WC0FQlad0h3eBJdmCnEqhWbIiPlBovSjnosSW+sV7Owfddm/yQjgWt1RAD4BzKSOTE3bolJ3FIX0GdZuulVyhIy2qhX2QCThSC1NHdQEbwe2BznPBccOJ3FKdSz9h+DrchIO3xKA70cmRt1RjUeS9FWBFvkZHT02YI7PfVjSfRqbmjmfo0UwZYLDcDmGxStpQY2rtXAPduNrRR7tq3w4ywjH2cfvcH2cVcJBlSWCBOR20Rgdec2mK9QE2zUznZpCuY5lunj8/KcUYOjM9ha8VTg6Ji60Xa283Bx7j6mTmC/uLAAZU6beTBInYhscXD72ep3BNt2zoOqUT0T9S5ys4xsXKQcpi+BmaURXWRDJhR+7gW2pUm4nEGylaCXHrKrXWwOBXlSYkMZYvSqbGDqcfmtls5g60Wbl8Wj59cu45yffSrb0qsFQbVz9zHsISNhlpEP1mqctUnA/r2mmPKh62LSQnWTBOiJkBrMFFWtY5ujH8/0VFko72p8fZGO2mnz0oDEPnOy8bVkiddya+i/Pjge42uEcinScbRf+xjGV7UYZiM8JKxoq869Fns/4W15P0tNkqxyJDR++Yx8n2hJr2LlhR9s5dpzqugPp4KCXw==","source_count":1026,"source_output_dir":"organized/mining_outputs/out_exp119a_dual_product_followup_a","target_bits_payload":"eNrdWUFuGzEMfKpf0PpooEWsJ/m4h0WjZ/hgbPUAw9YpJmCBYkVK6xiWFqlhsYcKQZyNglAUOcMh9wdZJLsjXofI362RhwDy8Cs/kOMHtPJwdbJXLXdxhM2diHBsboDf++ZGMhxjc+cNPywdGhvrYN3kGhtmZdDTpbGTnFxyxdjRtnbe49XRqemKXbVdQb7A1johjqF1Yp9vq3bU5OeGozleFD4qV2wJYbUuMe+PddRuf53MDHf/6yGs86nkTDt6Sx97imtDx5wipu13hzUgsNUwIfrv6biGPOmtkr/bdE9HIOXl7IpDJoYknCfrLWpZOwTvOYLnCBuI6U6R1GzNSNwRuug5NwbNiyyEAGMItmQ0UNSyVniJMRBW9M4farYSSdstg42TXlLzYJwm2Jw/e4rJmoCNv/Tglhl2RcGisMhaF2yCapcqoMGoDe1DDAxtPMe4GRLOLCmyifkpqPZuoghQCFvNRX80XB0Y1TaC5KLTY5JviUGSIU5ESU3+mYIa2AivGWwmOeWk4qllZZFEjGqfXGKnLnphu8SQLBippRsQqRCtGtj2wouM6lmRWbWoFbAZhljRS4bU8HavMePeel0euZO6boraigSD36c73IouzBQS1IpNkZFyg0VpGz2WhA/Wq1nYvmuzf5KRxLXaIBH9AxnJnJgbt8QkfqkL6LMC3PQqZAlpgtGrbITJgpVamjsoQ04PbJ5zngsObTfiFOpZ+4/BVmRkmD6lgV6OzI06oxp3pWgrgs1wMnr4bMG9nvoJIHo1NzRzvwaKYMuFhuj8m4rWUgMb12rinu3GVoo920n4cZaRj7OP3mD7dVcJJlSWCAOAPxtidefPmK9QE2zQznZpCuY5Vuzj8/KcUYOjM9ha8VTgaJO60Xa283Bx7j6GTmBfe7sAZU6beTAInYhscXD72ep3BNtpzoOqUd0A9C5ys4xsXKQcpi+BxaURnWFD0RZ+7gW2pUm4nEGyFaiXHgrXo2kOBXlSEmwZYvSqbBTrcfmtls5g60Wb68Wj59cu45yffSrb0qsFQbX39zHsISNplpEP1mqctUkg/L2mGPKh62LSQnWTBOCJkEbMFFWtXZujH8/0VFko72pcfZEe2mnz0oAkPHOy8bVkMatya+i+PjjuzGuEsi7ScQxf+2jHV7UYZiM8JKxoq869Fns/4W15PwtNkqxyxDZ++Yx8H2BJr2LlhZtC5dpzqugPpO/uyA==","target_count":61550}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
