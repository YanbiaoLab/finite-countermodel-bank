from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1573,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":2361,"model_key":"n4_witness_high_density_probe|n=4|idx=2361","model_order":4,"model_table":[[0,1,2,3],[0,3,2,0],[0,2,0,0],[0,0,0,0]],"primary_rank":205,"primary_unique_false_pairs":1573,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2361.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2361","source_bits_payload":"eNrtmb12wjAMha90PDib4QnUczr0MTR0YOSR3E4Z+8i1ZScBCgVKBzjoG5LYjn8kK7FvQjhBCFA8LSJfYNBaIUC0LKqX5URhvmvPQbGVt1J+bPMjHMdxHMdxHMdxTsvF9QaiPCBsQBkrEtaihYJ8BPBrhuYRiaowYpNWXTzFmgmMsemrKqEE2iXWO/LUPpsC6+n8CS4J62gQJKtmmiXUjkKqzU41056i+SHMwtRHxlJnj22xjEYMr1hJuZ1LDWs+5XrM1iR3KagcERQUzY4mBgWzYsxmRB8VP5vYehvK9KBMT47mNZmsL2GjLWzSJKHN05LtuvvKTtpUt85uW1w6Q/44Oo7zeOTyYjy+HlguSV+j8r/0tj0zGJ+PC4l978A4+Ch8xIWtXObtxy+c+Ir8cu3wfEG8A9Iy6QdhQbtZaUnoJRvEcAem6SgcNV62kU0Rt/1ZitdE9M0/Ymhn2s4iHuaO82e+Ab4sIj8=","source_count":260,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmb12wjAMhR+5Y6bWj8TYoYMeowPnVE8A3qLBR761ZScBCgVKBzjoG5LYjn8kK7FvknGClEB4WphfoMgbAgNiWblellNO8117DpJW3kr1sc0XOI7jOI7jOI7jnJaLm3cw6Yj0jhywzaxUtFDitwRdB1AYEHMVRmrSqosnqZnAIE1fVQnFoC6xPhCm9tUUWE+HV2hJWEcjI1o10yypdpRibXaqGfcUzQ9hlqY+ApY6e6yKZXnAuMaWy+1aaljzMdRjsCa1S0FSQSJkMTuaGGTMijGYEX1U+mxi63Ms04MyPUHMazxZX8KGWtjESUKbpznYdfeVnaipbprdtrh0Jvvj6DjO4xHKi/H4emC5mfsaFf6lt9WZwfh8XIj0vYPi4KPwERe2cp63H79w4ivy17XD8wXxDojLpB+ERd7NikuCLtkgpjswjQZWIblsIxsFt/1Zkmsi+uYfMXln2s7CHuaO82e+AY5FTvc=","target_count":62316}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
