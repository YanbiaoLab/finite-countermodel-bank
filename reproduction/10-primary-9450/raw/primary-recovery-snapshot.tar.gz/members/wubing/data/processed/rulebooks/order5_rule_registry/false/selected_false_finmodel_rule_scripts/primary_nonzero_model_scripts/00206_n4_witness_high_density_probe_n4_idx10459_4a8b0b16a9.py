from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1571,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":10459,"model_key":"n4_witness_high_density_probe|n=4|idx=10459","model_order":4,"model_table":[[1,2,2,1],[2,2,2,0],[2,2,2,2],[2,2,2,2]],"primary_rank":206,"primary_unique_false_pairs":1571,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx10459.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx10459","source_bits_payload":"eNrt1DFIAmEUB/DvPEGKwHQSAsM6QhoicTVOIsIhsCCpFiEFp6LGikqHBiWDEiJdujE6orBBmlSCItBwCgyJHCqhCEQx0sqXXtDQuRy3xfsN3/C9B+/77v53FEHoj7O749juNT8TnBhWEmIMMYY2zQ7DGHpCG8zIyG+bz6ZorFabVYmPDCGEEEIIIYQQQgghhBD6d5Igi1faNGNurjcQiTCxQ/50i/F4eD4cMfSc69xj2tyk43ZUazY7HOl0p2Y2aOoLzPO80M73ezx+/+CljpY2jT1J1buXK16niRv48D7cdEVXXACbBq7GnoTte19s6XlreigKcLFt/+Km0gdC++jRfhbAdXUgbVgeyhl4W6hD4SXFQi5RrbngCVg3mAHKlUcOXu9X16LeMnBRiABUa6VmezyeTVQhk4UOadOC9GKS0icplYU0liVC1ERPLCRP5320njQWC/GphM0i1ehUk2Y7SdLC5rvEjPh+3rVKXPkUJ4KSm8jxmJCDFscQx6ZDdv7Xnc0ctIsLRXFsFPI/tkIzBy0qLWIj+2o6lZCDFscQx0b+j+Qbbi8dfQ==","source_count":2297,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNr7938UjAI04K4U6JllFLqseN3e3///X8+9fe/bu7zbt+/dza2+vXs3XFn99r9Acv/2/b9Hg2wUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBh2wJ6BItBAmm3XVSbfKUtLu+0ZFupbdHvmzNDQ9LR7d22fz9n8VmX1KrWdb8+cWbXK2Pj9u3nF526WTQoNBSsPvTpzZnn5ecvnf0iz7UCACeODNq6GhecSLrI0SGs98Wudy8BQci+B9UBA+oYMpgO8okXLD/kxMFjlb2BKWGEcAVa+MzhRnYFhrnkEaZbJM/AYMHBOYGSQEDE5wKDiwMY6l0GS4cAchjMMDDxcUgkMQgrNTX4NPAwJfgxpDAxsrLwg5Y6O6g5sDAbqDJ9Js634T7/9v4f2/34c/g8k2v////D/4f/D/+X/yNf/efgfSBz+X/8DLMj/D6jyw3+Q8v/2f8CC7CSmkXpIXP/AlGHGTBH/KE2R6z3B6QCLMzCTzWeK03/jQlA6+IopwY+ZbP5SntkkQOkAiwyWZEOx157/AKcDLM7ATDaUFyQA3kJTuQ==","target_count":60279}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
