from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1516,"excluded_block_payloads":[],"law_count":62576,"model_family":"prime_line_polynomial_affine","model_idx":0,"model_key":"prime_line_polynomial_affine|n=5|idx=0","model_order":5,"model_table":[[0,0,0,0,0],[0,0,1,3,1],[0,4,0,3,3],[0,2,2,0,1],[0,4,2,4,0]],"primary_rank":212,"primary_unique_false_pairs":1516,"rule_id":"false.finmodel.primary.prime_line_polynomial_affine.n5.idx0.v1","rule_key":"false.finmodel.primary.prime_line_polynomial_affine.n5.idx0","source_bits_payload":"eNrtmTFv00AUx59xkF2E6ouIRJCqOk6XsFVMHiLSHi0DU8snyMKesQOSj5CgNOrQDuwk6qfo5AompvINjq2jhTpEVeLH3bm4RQkigR4L9xusSHfO07v7/9+z7iwAYPA7jnvyGccWGP4Fh9V+bUjo9AB789EKoT7jlfH+k8vGAZkeaPIWLIM34xUfIHVmhf/Qu/qxQwsA5TAf+PmfNjhhVtPslsFgMBgMBoPBYDAYDAbDf8DjYa96LyjtbgWdar/W2XEHhAaddsW9oyEYz060lmOLn1onUN8D8IBbwG0dqWUHa2f44D35fI7rNOjS+xP02oErR93bDcaO1PleCA5zHnL4JrKqA3OAeTpSS8SaRQAo141hdriboK9JIykWt0u0NuxRd4ICqRDq3t0kBQ3BYkRYgdUVZsdvZTAEWIXYhtjRkdqouH0RuQNcEx74gjKtLrlEv7BJdERDzM2WiswirWZr3jRbqN1sYi19sXlSkDzKVm+Mjh5BMkRPmo0LsymNWDC2b5itcMtmc5XZnl2bzdJptus1lRrRWv03+srVS3NNzotAlwgR05rbriwWrRxKV8+U39T9FM+LgAOJLAHwdMHcouFB6q3NJ4VxY3dpIKeXXtY+nSFWyu0/Mtt86rVbsKemq8ImfDlaMLXXymxzqreh6pz/owItfBPIRL0qdom611ISyD4SRPXXcam43lIt1OGQKAmoJpqojqfDbFuPJv7zc9x/4b66iMqDQxq8S9E51dPZ4q+5qKUEkryz6Wg2I7X1Wb2Kr2rKCH+l0L/9GvoOUN/eGw==","source_count":1735,"source_output_dir":"organized/mining_outputs/out_exp103a_prime_line_polynomial_affine","target_bits_payload":"eNrtmTFv00AUx18SVRmqymM37hvQiQlUT3wKlLAz0KFKoyaEs8TQMTtLPgHtxEDLtUEZPKFueGkcV5VIpaDYFaJnEePH3bm4RQkigR4L9xusSHfO07v7/9+z7lJEpPg7HtXl07ZTNPwLNvo1rxKy6QH6/EHqYm/GK6Wt90vdzXB6oEPaeIHRjFcCxEI8K/zj+tWPPTZBHLr5wM//dERCmnbMbhkMBoPBYDAYDAaDwWAw/Ad8qNT7X/zR7oHf7Ne85h6vhsxvtgb8m4ZgJDvRurBTsp4+xN4OYoQkRZLoSC07WFuDT0/Ce6twzPwG+1yEqOVzOcpvNxh9qs73XIxpfE5wRWTVQxojjXSkZok1cxBBrhuF7HDXgkCTRgow3h8xr1JnvAgCqRDGvx6GEw3BbAA8w9MzmtjPZDBAPEU7QTvWkVp5vL/s8CqcCA/cBZlWI1yCYHIY6ogGkJutIDJztJqtc9NsrnazibUMxOZJQRInW70SxHoESQEiaTYizKY0kmIpuWG2yS2bjSuzvb02W6rTbNdrKjWitfof1ZSrL+eanBeBRihEzDzeGiwWbehKV8+U39T9FMmLQIyWLAH4bsHcnMpmITqZTwql7u5lVU4fvfLurwEMhq0/Mtt86k3auKOmq8ImfFleMLUXymxzqrer6lzwowItfBNIRb0aN0J1r6UkkH0kiOqv41LxuK1aaEzQUhJQTdRSHU+H2Q4+FoM3q7D1mr9cdobVDeZvFyBe19PZ7Du5qKUErLyz6Wg2ZbX1Wb2yr2pKGX6l0L/9GvoO+5KTDA==","target_count":60841}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
