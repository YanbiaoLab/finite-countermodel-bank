from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1487,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_order_witness_tail_probe","model_idx":46755,"model_key":"high_order_witness_tail_probe|n=11|idx=46755","model_order":11,"model_table":[[0,2,4,6,8,10,1,3,5,7,9],[10,1,3,5,7,9,0,2,4,6,8],[9,0,2,4,6,8,10,1,3,5,7],[8,10,1,3,5,7,9,0,2,4,6],[7,9,0,2,4,6,8,10,1,3,5],[6,8,10,1,3,5,7,9,0,2,4],[5,7,9,0,2,4,6,8,10,1,3],[4,6,8,10,1,3,5,7,9,0,2],[3,5,7,9,0,2,4,6,8,10,1],[2,4,6,8,10,1,3,5,7,9,0],[1,3,5,7,9,0,2,4,6,8,10]],"primary_rank":213,"primary_unique_false_pairs":1487,"rule_id":"false.finmodel.primary.high_order_witness_tail_probe.n11.idx46755.v1","rule_key":"false.finmodel.primary.high_order_witness_tail_probe.n11.idx46755","source_bits_payload":"eNq9WUuOIyEMBeQFs3P6BFbUB/GMssix6NGMlGUfeQhQqQ+YqgowXiSqoNjYvOcP9VexUayCfIZPduELbHj4FR8UPR8Mx4coRk1/TEI6fmNcXIheP85iUVhIhguSmZ3k2+/gWlpwpAwqXVgBi7aoixZ+rkVrTQqLrqTIZa74sJV1fRhzAyosTPozR11SlDsaz0tBFmni5fpSfui4flPS8QS5JwMpLMtYTLta7lUIHVQfT8t91uPk+PWypqsBWmOIsNEYcW11AzLbau2zHpvVibtGW0EByoY2FOUsj5wTMSFIgOAW334ryzLQtgu6LZAeBV/1MIuH+IZYecMmU29aDYoZVjofaCNbldy6ZxrxFRb4iCExkZ0i2x+nLtqq/yO4Bcx6yR0s4gflY6n+shM2znZ0mmwzs2gLbtc5kIuMjh5x0DNHKaEHiOh+WB6LEUowt/MZ8THmvUm2FxhjHXDjXJsqG/XY+eHKRnKF6yhmWQH0AdS3FG3GoDtOGpRUDUti1pDSGA3x8ED6SvPEyFfWMw4hGztO7Sh7sxGcMMoayOevs37gZyvZFujzwxXVB7fWSGP0YY1EGpX/TdDN6xwIg7IX80y2V9M1jmzJI2rNEWfaSJ1jZAzZXkN2+ECF46yBfc6I7umb9YE0Ibajji1dOWCXSeJoZbMBldCrFZDbSEOTodhGshqWI59XWlMu1FeDzQ1+/YLEWry45JlR2g3tf3R9vudsGm05UvmeMW7i0XVmA1uve3rlS2Nac9XAbKaPZux8Yz2n3bpm6crMB90zC5sNDmZ52P4zW2wjhb7Ij1Vdq502UNYXGj7NIcyuU2ohkUPNFz2lcAG4IkrYlwTonC092QRyP2fwiWyuE1q+FQrkDsjxZIt5sY+P4quFyGpMJ9gHl7z8wr3mm3fnh53KJjcFdqcYvDERxNvBQiSZjvx0jobT1X/+HyRhZy0XJCDVLH24GNjjZBMrJHa9QJjayCA32LeWmNdS2aIVo4sJeRuwEutOTObpNrLw4qfw4igVgy0Bj1913OMBv/rV2hnRFbJf4RS3/wEgw01P","source_count":619,"source_output_dir":"organized/mining_outputs/out_exp109a_high_order_witness_tail_probe","target_bits_payload":"eNq9WUuOIyEMPXKWkWY0zbGyiGZ8kFbLJ+iwGxYWZghQqQ+YqgowXiSqoNjYvOcP9cOBdeCCfIZPUOGLTHj4HR8cPh8sxIco1k1/TIIcv3VcXAivH2cxWlhIhguSmZ3k4nfwVVpQ6Kx2XFgho01RFy78XAszo9NFV1LkMld82Mq6vq29ExYWJv2Zoyopyh2N5+UoizTCcn0pfzmu3510PEFuyUAKyzIW066WexVCR9XH03Kb9Sg5fr2scTVAawyhbjSGUFvdgMy0Wvusx2Z14qrRVlCgZUMbikKWR86JmBAkQECLb7+cARlo2wVuC6RHwUc9zOIhviFG3rDN1NtWg2KGlc6H2shWJTf3TCO+whIcMSQmslNk+6ncg437P6K3gFkvqYNF/KB8L9U/dsIG2Y5Ok21mFm7BrToHcpHRtUcc9cxRTugBIrqvBsZiBBPMzXxGcIx5b5LtBcZYB9Q416bKhj12friyoVzhOopdVgA+gPqWog066I6TBiZVw5KYsehYR0MwPJC+0jwx8pH1jEPIBgpSOwrebAQnjbJG8vlz1g/8aSXbAn1+uML64NYaaR19WCMRR+V/G3TDOgfSoOwFMJPt1XSNI1vyCFtzxJk2knOMjCHba8gOH9rpcdbIPGdE9fTN+EDaENtRx5auHHSXSeJoZTMBldSrFZDbSIuTodhGghuWI59XWlMu5C+rmxv8+gWJMfqhkmfWsRra/3B9vodsGm05UvmeMW7i2nVmI1Ove7zypTGtqWpgNtNHM3Yuup7T7l2zdGXmo+6ZBewGB7NcTf+ZLbaRQl/kx6qu1Y4tlfWFho8hhFl1Si0ocqj5oqcULiJVRAn4kkCds6Unm0Du5ww+kU11QsvFaYHcATmebDEv9vFRfLUQWa3TCfbBJSy/9F7zDbvzw05lk5sCs1MM3pgI4u1gIZKAR346R8Pp6j//j0ZhZy0XJCTVLD5cDMxxsokVUne9QJjayCB32reWmNdS2aIVy8WEvA1YiXUnJvN0G1l48VN4cZSKwZaAx686bvGAX/1q7Yzwi7Jf6RS3/wErvSPn","target_count":61957}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
