from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1472,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_order_witness_tail_probe","model_idx":66678,"model_key":"high_order_witness_tail_probe|n=11|idx=66678","model_order":11,"model_table":[[0,10,9,8,7,6,5,4,3,2,1],[2,1,0,10,9,8,7,6,5,4,3],[4,3,2,1,0,10,9,8,7,6,5],[6,5,4,3,2,1,0,10,9,8,7],[8,7,6,5,4,3,2,1,0,10,9],[10,9,8,7,6,5,4,3,2,1,0],[1,0,10,9,8,7,6,5,4,3,2],[3,2,1,0,10,9,8,7,6,5,4],[5,4,3,2,1,0,10,9,8,7,6],[7,6,5,4,3,2,1,0,10,9,8],[9,8,7,6,5,4,3,2,1,0,10]],"primary_rank":215,"primary_unique_false_pairs":1472,"rule_id":"false.finmodel.primary.high_order_witness_tail_probe.n11.idx66678.v1","rule_key":"false.finmodel.primary.high_order_witness_tail_probe.n11.idx66678","source_bits_payload":"eNqtWUuy7CAIVcoBQ5bAUlwad/D2/ZKYj0aIpI11q/vGJPzOAdH+JzmEnIOEENLy3/a3/rf8YblYrxOH9SKXi/VOgLA+EWV7YLvBZZbC+d4xYpldB2F9A8uNtF1AmZNwF0D1BQDqN2h/KZ0foTwpUlnC9UvpZuQ5+LKgd6W2Xr9o3sm7Z7y7Vrmy2xLDbRCVYOb1K54mFQEYzuiHxpUNObjL4hPSK8S5UsuhH6mODZZHk/Hs6WYhEW9W0m5c6uN0wSB3FKNqiDowHJRtSbBr41sEQhV7MJWgpc3kb2bDZNLZ0/IV1PkdMGpMAh0raZRgeD/MFFDQoDA5lkwEXTPrGOflI401RyPARkFQaYVq/PwhhcozaXDvOZCfyf0YlfBcHq3xNwEbVvQfxifWycaPQsdgYuc0qEB78BlHOPb2Ra+gB3zqZONDBPZ5iH5Bnhop+63syRn+uYC0S5ZhjfQhbHsHV0I3Ak5tNOBD9ggcgbkoYnJD/WeW/DGgR7KRJ2uGyTZCNGrwXCClF8km43LGl/ujLCo9xOTKZvRwYjiVx/TLnpXNNyYoSaYdaCmK7tplJpvCB9D185gSYLeR78o4L0bBr4FEfGngbWl/jTjZNZLwpzZy1DuIDgP8uLLZyYY6Ba1kw59zrW3lUyc7fuVUU/DIILR0GOOMNriimNRlyL9H8rWR0QRBlDjIhGvHyga9QnjV2bwpr7n3PxsOw++1+jgvEAeRv9uzUa/QoN8EJaX6iiOQvkg2q0VIqurJZKMnq8lFmzdtZHOG0yqCr5qDA/H80K7l73qR8n5c7d84Ug6tmnrRTj0SUhwmcbDOGaGRzeppkJqk4GsjWYlhvNOTycOEaLofD9Fcx0qZmq3HLTeSp/7mmWSzDm63Do4Vb9BfnhRD46mIPA3RA+GGQcbaM6glpacDoMFi6VmMGkGSw+eDzV0U1MbwuNlwJpsuKFuCXGc/cQxrGgSf3OsbW8kmh2weW4cez+JwZesfYfMYYWJlK0f/5aCFm/6+jyR0P2ropYYeMkNOm1O3p+A+j9jKLXJRh9SfEJSjf2VKXh2ac92vUhMa1tEXvycvOrfo30K420jZY7mWx3bvR75Dpjed3rENzL03ZtswtWdjdUutFmRQgXfvdXLdQaamkmXfHvrNKoFmgQB9Ks1s4f4DjYpOEA==","source_count":619,"source_output_dir":"organized/mining_outputs/out_exp109a_high_order_witness_tail_probe","target_bits_payload":"eNqtWUuy7CAI3fcbXJbmUlgCQwYW+pKYj0aIpI11q/vGJPzOAdH+ByHnEDLknOPy3/a3/rf8cblYryPm9SKUi/VOlrw+kWB7YLuBZZby+d4xUpldB3F9g8uNuF1ImYN8F0D1hQjrN2h/KZ4fuTwJUFmC9UvxZuQ58LKgd6W2Xr9o3gm7Z7i7Vrmy25LybRCVYIb1K50mFQGcz+jnxpUNObnLwhPSK8ShUou5H7GODZdHo/Hs6WYhEW5W0m5c7ON0wQB3FJNqiDo4H5RtSbBrw1sEchV7MZWwpc3kb0DDZNLZ0/JV1PkdMGpMEh0raJRwfj/MFFDQoDw5lkwUXTPqGIflI441JyPARkFQacVq/PwhlcozaHDvORCeyf0YlfxcHq3xNwEbV/QfxifVyYaPQsdgcue0qEB78BlHOPX2Ja+gB3zqZMNDBPd5yH5BnhoJ+63gyRn8uYC0S5ZhDfQhbHsHV0I3Ak5tNOBD8AgcgbkoQnJD/WeW/DGgR7KRJ2uGyTZCNGnwXCDFF8kG43KGl/ujLCo9xOTKZvRwYDgVxvQLnpXNNyYoSaYdbClK7tplJpvCB9H145gSYreR78o4LkbJr4FkfmngbWl/jTjZNZL4pzZy1DuADoP8uLLZycY6Ba1k459zrW3lYyc7feVUU/DIIDR0GPOMNrmiGNVlyL9H8rWRyQQBlDjAhGvHyia9QnnV2bwpr6H3PxgOy++1+jgvAAeRv9uzUa/QoN8EJaH6SiOQvkg2q0WIqurJZKMnq8lFmzdtZHOG0yqSr5qDA/Hw0K6F73qR8n5a7d84Ug6tmnrRTj0SEhwmYbbOGaWRjeppkJqk4msjUYlhutMTycOEZLqfDtFYx0qZmq3HLTeip/6GmWSzDm63Dg4Vb9hfnhRD06mIPA3RA+GGQebaM6klxacDoMFi6VmMGkEQ8ucDzV2U1MbguNlwJpsuKFiCXGc/aQxrHASf3OsbWskGh2wcW8cez9JwZesfQfMYYWJlK0f/5aAFm/6+j6R0P2ropYYeMgNOm2O3p8A+j9DKLXJRh9SfEJSjf2UKXh2aY92vUhMa1NEHvycvOrfk30K420jYY7mWx3bvR75Dpjed3rENDL03ZtswtWdDdUutFmRRgXfvdULdQcamkgXfHvrNKsFmgRB9Ks5s4f4DvucjJg==","target_count":61957}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
