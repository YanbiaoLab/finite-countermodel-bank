from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1409,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":404291,"model_key":"dual_product1|n=9|idx=404291","model_order":9,"model_table":[[0,0,0,0,0,0,0,0,0],[2,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0],[0,1,0,0,0,0,0,0,0],[0,0,0,0,0,0,1,0,0],[0,0,0,0,0,0,0,0,0],[5,3,5,0,0,0,0,0,0],[5,5,5,0,0,0,0,0,0],[5,5,5,0,0,0,0,0,0]],"primary_rank":228,"primary_unique_false_pairs":1409,"rule_id":"false.finmodel.primary.dual_product1.n9.idx404291.v1","rule_key":"false.finmodel.primary.dual_product1.n9.idx404291","source_bits_payload":"eNpjZGBgaGAgDhy4yMowCugBJjAwKCiRpqWGUeCHPAcWiQdvP5/NS8vHIvN/999/+83ZMSUUYAwB/OnhhdHC1gwnDweW0RgbBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBgF1AMPXjPBmAeE/wvbMo4GyVAA//4zpLAyJBgBmX/+//9fDxJz86FR5B34Lw9jNgAt+89PU6/9YIr5Zg+06DMTQ8OB/w5AkSvCv2lmJ9A7rAYgiwKAYfr/v70I0IdAO5lpk9n+fr9v/73+38/378/X7767//fv4v/n/vUW/7emhW1/1IE+qj8G9NX5C0/rKwW/5YN8aP5fmhaeAyeM+39///+/ux7E/P/+Hog8v/M9LRLlB6D5//9X////vf492GKgrd/////73oY2mQ0H4B/y5YjFLhJSL2dsx7zRoncQgAYWBgZBRoYO8BSVC2TGqEHACc5RgtTpDhyKQ89v+xg4/vCzPKhn5GBQ+GAvAJpQZfr3n7mB4cN+BhYG8LwcsHxm/P+f0YEKNdvt57PvnrlXs9X/6vT8MuPqz6FH7/ncND52I33freWvTpvvnrn356qk/GVvJJPfGFNes91/+/3/3p3/9/9eve3+/+/PXu2bu/f3//t30u8AS87Q2+//VxeX3j937+///HfGfBTbBgDfdv3r","source_count":2015,"source_output_dir":"organized/mining_outputs/out_exp119a_dual_product_followup_a","target_bits_payload":"eNr79/////r/xAF7vV//RwE9QP7///fvkqal+d979gffsUjIC/EYTZw5AYsMgwsTo8OJH5gS92GM9/jTg/jZuKrpe7fv/z0aY6NgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBgFo4B6QF7kL4xp/4bhzaF/o0EyFAAjw//Zv/7PPwtkMjMwMDSAxHZuplHk2TM8gDHrgZYxfKCp19j/LuY8ALSI5+//enuG/UAR7TcsNLMT6J1f50EWrQeGKQPDgddAHwLt/EObzMbEoXCAo4GRTUDAoMFFyYGFpYfBkLGoh+EILWxjvgH0UYMl0FcG+lINbe84J4B8eILhCS08B04YCkwsDAwuDSAmg4AiiDRwE6BFouQHms/A0MLAwNEgALYYaCsHAwOTwGHaZDYc4MOQL0eOu5KQer8tKk8cLXoHAaj//f//u3//y8FTVLshM0b17/fCOXchdfr+7/eGnt8c/39n/vBbvuHf9//3+Q+8B02o/mVk+FP/n9/h/+//4Hk5YPn8j4Hh334q1GwqEilKxorNXhu0MiZ0nmnhWWWluFntjKX6DEfVCFGTEy5pTmyhcydECj+bI3yG8ppNQYiDwcmNwYElxFOBgUNS1DHJiYVBQXmGMrDkXKUiwNDS06VgqMjEMEHwzEeKbQMAbPtzPA==","target_count":60561}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
