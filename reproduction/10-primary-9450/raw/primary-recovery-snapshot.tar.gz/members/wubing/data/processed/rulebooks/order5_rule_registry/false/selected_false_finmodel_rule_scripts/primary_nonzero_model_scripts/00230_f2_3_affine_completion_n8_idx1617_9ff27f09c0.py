from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1385,"excluded_block_payloads":[],"law_count":62576,"model_family":"f2_3_affine_completion","model_idx":1617,"model_key":"f2_3_affine_completion|n=8|idx=1617","model_order":8,"model_table":[[7,5,1,3,4,6,2,0],[3,1,5,7,0,2,6,4],[3,1,5,7,0,2,6,4],[7,5,1,3,4,6,2,0],[7,5,1,3,4,6,2,0],[3,1,5,7,0,2,6,4],[3,1,5,7,0,2,6,4],[7,5,1,3,4,6,2,0]],"primary_rank":230,"primary_unique_false_pairs":1385,"rule_id":"false.finmodel.primary.f2_3_affine_completion.n8.idx1617.v1","rule_key":"false.finmodel.primary.f2_3_affine_completion.n8.idx1617","source_bits_payload":"eNrtWUGOwyAMNIiDjzyB/Qnal7FSH74JTsCEIU1bpVpt40OUGIRhwIPt/FCVW35GCoQlciTjyJHPn6Y8yNKTwsb5iG2F9OCwXrpPI24aEmUTvM63rs9lE23rXxAvc5Lni5MKM8KG5ueEKE9jB5pfib7yd8ZZWqdu0+vxoR2FmGc7w/he7FjMOZ9ga+jUkwavbF4xU9y1ZpKcI1ksqZFC+Yz1uK3d1AF2TSvVLtvXfy1JIOHicKGFwJNW1m4VIIDo0oXoL3nwvxJhaWGPuJAEn3Zov5QhXrjKPH/FHGJHMWRkWeEOGzwvN2UoFL7lk5zNK0Ou0P5JHrJeWa76JlfCSxvnhbFDQm5sW/r4FGdDIdEZx0acbXSFnn9sTpRbRa0LBbZskklgA8CpTPCis41D3W43EQCPbamtUbPrIxirYx8cZO+EPrY/5a2htmts7/tmXvdt9JvJG0Nt1zYnGAEwssGDMPI4aukBG91mho2hu6j54zbCFRNdcskll1zydglujdlgUmg53g/4jovUCOs96qm/tsuFqG7sqxLRhZG8IhU22ZyjrgZmQQRlhlHjJec526hAAlQ5X0ylPhRIFZVr3bmUj6LsaW4U5xoWSIAKFK6hjbV8xLRMaPnYKZAAFaifQxsFCr0uk3O2OmoDEUStK7VhGysUel3Zub7VqA1ECLW+1AZtFCio3by3F0gGyS9gfqQSQI8m9pKzgdyvJlV2R7WbK6YP4pG0rrsj9gCQAH8D+uuhrS58iix/RgFF5YBoPvCLFzNULf2tcgTdqIgkUqlGAtaaR52IozCFgSpgQzcqIpnPxC/P4WER","source_count":789,"source_output_dir":"organized/mining_outputs/out_exp102a_f2_3_affine_completion","target_bits_payload":"eNrtWUGOwyAMfHil5WUrfrI8gaMPCLwJTsCEIU1bpVpt40OUGIRhwIPtfHGVW35adozFkuUUOLDPn6k8OPKTQil4i2058+CwXrpPI24aDGcTtM63ri9kE23rXxAvc5Lni5NyM8KJ5+eEKE1jO55fmX/yd8ZZWqdu0+vxoQM7m2c7w/he7EjMBW9gq+vUkwavbF4xsd21loycI1ksq5Fc+bT1uK3d1AEOTSvXLtvXfy1GIKHicK6FwLNW1m4VIIDo0oX5L3nwvxJhaWEPu5AEnXZof5QhWrgqPX/FHGJHMZRkWe4OGzwvN2XIFb6lk5zNK0Oh0P5JHrJeWaH6JlXCMxvnhbGDQW4cW/r4FGdDIdEZx0acbXSFnn9sTpRbRa0LBbZskklgA8CpTPCis41D3W43EQCPbWmsUXPoI5ioYx8cZO+EPrE/5a2htqtt7/tmXvdt9JtJG0Nt1zYnGAEwskGDMPI4auYBG91muo2hu6j54zbcFRNdcskll1zydnFhjdlgUhjJ3g/4jovUCOs96rm/tsuFqG7sqxLRhZG0IuU22VzgrgYWQQSVhlHjJec526hAAlQ5XzSlPuRYFZVr3bmUj6zsaW4U5xoWSIAKFK6hjbV8RLxMaPnYKZAAFaifQxsFCr2ulHO2OmoDEUStK7VhGysUel3Zub7VqA1ECLW+1AZtFCi43by3F0gGyS9gfqQSQI8m9pKzgdyvJlVxR7WbK5oP4hGzrrsjdgeQAH8D+uuhrS58iix/RgFF5YBoPvCLFxNULf2jcgTdqIjEcqlGAtaaR52IozBFgipgQzcqIpnPxC98kBAl","target_count":61787}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
