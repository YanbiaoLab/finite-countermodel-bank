from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1347,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":32562,"model_key":"n4_witness_high_density_probe|n=4|idx=32562","model_order":4,"model_table":[[0,1,2,1],[2,1,2,3],[0,1,2,3],[1,2,2,3]],"primary_rank":233,"primary_unique_false_pairs":1347,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx32562.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx32562","source_bits_payload":"eNrVWUtuxCAMDcgLuuMI9CZWVz0Wi/beDQkTSGzzmRCkoqpShgnGz37+ze+CS/gLC7b/6cGsD8btD27bwfQ1ZjlpY1HSxirCshtRMLO0dJaVNrx4E9hOQ1YVjPfD8zuf/kBJm/x0swHjcwwPVfwqByzuu+meX9vR7gWqJ6qgqApBIVoF9BWIqApjtV0V2WrJRnULsyg+uMxUaWqmMDcVyx+ZUOOXn2o1O1WaJlx8cGGKGnPIZqOK9nnXFCPsM2SzyXhqAtnWvLZmFNgD2KMCvcUjUqqWQP8/ybZMINvkzDYRy8+ZIbnHA+/fC2Z6rxfLEniObGpOgi1nNk3rMnWLbKXMhrQuc3dMaiTUcIBT0TIy1f/nvoOJ0VWkuzJbpZrtAEDG5aXEpXMLZ8PJGDaldt5ZoHKFmNk2tBScvmqDQJ0Hm5hxw/3sm2RLTu2JReJVjitTAI7LQUvXsvaEK1p7x3gWyLWcRZdU1bh7tPfLtTXNdLaZWZy/hDlGBkieZqJ5ckxMenCn96nbdDZne2azwSIXsgUlLpGDug2jpmkiG9I3zxGNGxH0kk0T1LIHS8OgkXpnXc0dgWyhXt1QC665bHMMtcSJhg68ih9Gsl0A0LvnMx5CRVqdBPn4Zjj+JSi/MtKEU5Rh28nW5jbZ5agM3U62DrcRZFAHMuosqIoatMswvQOSsRV0rYwcOxuC98LP+2UkfyC6XPUxKlptShgrcCNLSl3E2I2tY7GIsR/cTRqx7AQyM4m1yJgy8qIZjndRJ07Cn+jBf9IkJlZR+rke3OdBF56LIDSznQUqniz14kcVy0g+sBdj/ZsARON8M0qbRmpCN9k+oOna5maCUFLKQSFGqxuBzPU4uhpFttGjm/I8Z8roTvwBTXK0WwknqqRpYMfGPOi6yOZ5H+Zm88gI7ImlexnJ+Zpu+qhvXvIH8R5MPg==","source_count":580,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrVWUtuxCAMvXe74FhdVb5JOQK7srAgDQkTSGzzmRCkoqpShgnGz37+zccCS/gLC7f/6cGuD1bvD3rbgfQ1ZmlpY/HSxirCsBtRMLOcdJaRNpR4E9xOA1YViPeD8zs/6kDJ2fx0uwGjcgwPVdQqBw3su+me39vR+gWqIqqAqApBIVoF3RWIqApjtV0V2WrJRnULsyg+uOxUaX6mMD0Vy0+ZUOOXmmo1M1WaI1x8cEGKGnPIZqKK5nnXFCPsM2QzyXh+AtnWvLZmFNwD2KMClYEjUvqWQP8/ybZMINvkzDYRy5+ZIbnHA+/fC2d6rxLLEnyObH5Ogi1nNkfrMn+LbKXMBrQu03dMaiXUYIBT0TIy1f/nvoOJ0VWkuzJbpZrtAEDG5aXEpXMLZ+PJGCaldt5ZsHKFmNk2tDyevmqCQJcHm5hxw/3Mm2RLTq2IReJVjitTAI7LYUvXsvaEK1p7x3gWyLWcRZf01bh7tPfLtTXNdDaZWbS6hDlGBkqeZqN5ckxsetCn96nbdDZne2YzwSIXsgUlLpGDug2jpm0iG9A3zxGNGxH0ks0R1LIHQ8OglXpnV80dgWyhXt1QC665bHMMv8SJhgu8ih9Gsl0AcLvnMx5CRRqXBKn4Zjj+JSi/MtCEU5Rh2snW5jbZ5agM1062DrcRZFAHsv4sqIoatsuwvQOSsRV0rYwcOxvC98LP+2UkfyDoXPUxKhpnSxh71CNLSlfEWI+tY6GIsRrcTVqx7EQyM4m1yJgy8qIZjHdRLU7Cn+jBP9MkJlZR7rkeXOVBF5+LIDSznQV6niz14scXy0g+sBdj/ZsARON8MUrbRmpiN9l+sena9maC8FLKASFG+xuBTPc4uh9FttGjm/I8Z8roTvwBTXK0WwknquRoYIfGPKi7yKZ4H+Zm88AI7ImlexnJ+Zpr+qhvXvIHW1Mk+A==","target_count":61996}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
