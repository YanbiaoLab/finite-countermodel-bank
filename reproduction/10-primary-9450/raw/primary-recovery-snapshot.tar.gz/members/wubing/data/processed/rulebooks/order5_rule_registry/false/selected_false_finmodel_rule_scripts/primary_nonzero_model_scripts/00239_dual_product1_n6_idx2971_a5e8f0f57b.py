from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1289,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":2971,"model_key":"dual_product1|n=6|idx=2971","model_order":6,"model_table":[[0,0,4,4,0,1],[1,1,4,4,1,1],[2,2,2,2,2,2],[2,2,3,3,2,2],[4,5,0,0,4,4],[5,5,0,0,5,5]],"primary_rank":239,"primary_unique_false_pairs":1289,"rule_id":"false.finmodel.primary.dual_product1.n6.idx2971.v1","rule_key":"false.finmodel.primary.dual_product1.n6.idx2971","source_bits_payload":"eNq9WUFrE0EUfrO7TTaQJmsoWFF0KSnkVvHkobSL5JB48g+I8eBNSb0Ub9ki3iUUSm85emuhUA+KrhQEQe+BHrIXbznk2EPoGGdT0e68kMXp9w4bZl7YL9+b92a+eXkjAqIoT79tXT0j9aQl9QySQZHuqoEajqUgrcWyrHdQ5zrjODtlHNEpA0IbzDyNOEf4kvMUOUevysGvco4a967A5TwWS2UKMkxRSVaKWjZDJZd6Zy/50BBKZnxyLjtc9cusPyPn4ts+8RZJZTZB7EyBdTBglFArY8DiBE1g0MYKbBMDFkq5Jk9AKUIjOfjZuXENhHYuPwzvrVkYsGjwbE/ugJhNiq199ON7EVZsL47390HpH7ePvkkPFciPB9v9p7dBYOH7k9ITUYAVW55wdi6BYNFgAYjGSqIrsTZy1WJ7tIlDW6dPFgwsLCNXbYQEo68ifwuGGN2PQxtGbRmZ/mQDmVELmiO71W5jZQVUb2G3XmnW6yBqj7oNv+CiAvmwUqh6IPFDQdPfqcJypNZEZuSqAIL16K2DQ1tCxjH0AhIwcp7l+jhuD5CBDAjIjFwkNZrdibkzNqqO4pmdmNZrs3eD8eNZ3uGh0SM9/Lw4y7t4bHRTG23P8h5+yRkN5Aav+UpEW4ZlJL8s/UkgSygZmVuOaLKBmpWRLOnAvPDjO+FXIfh2uYMmqDQd04dQyP76hvKYVUYeiyYcj0wfsSyYavf7Zjte0/+PdLt8P509Q90rMtzDXiWLd6Bx3dRsmZp1f5e52La4Yvv36Ekf8GFGGZlUlqbY0lP/raadqSzRKBVXmzYmGiQtyI37ol3xHKJ+puekLTSRnG/7rmWQkeKvLerStjXXFGW5OE8TQaQz20qztRaYHJvXfgGJ8p3W","source_count":1257,"source_output_dir":"organized/mining_outputs/out_exp124a_dual_product_exhaustion_f","target_bits_payload":"eNq9WUFrE0EUnpJDjznk5mVzKOSuIAjFVfRgodDePOZWhBK8i3Rzk15s0JsHI/4BTyaHINvSgydpb4GGsopihRI3aSCbdHfnGWe3ot15IcHp9w4bZl7YL9+b92a+eXkiXSJ7RL9tXz1t9aRT9XSTwYAO1EANc0KS1izR0zuo+oNxLC4xDnuJAaE9Zp7ynMN5znkGnKPc4eCPOEebe5cbcJ6YpZKCFDJUkpWiesRQGWfeWU4+NISSGY/Cy45A/bL4zyi8+LZHvNlCWUQQW1RgVQwYJdR6GDArQZMYtJwC28WAOUIcimVQilBeFK9Vv/8EoS2I+4VPhzEGzC6+eiS2QMwmxVZbvX5jACu2FysbG6D0t2qrN4WPCuS99e3S6y8gMOfBcv+NHMKKbUQ4WxBAMLt4DkRjJdGVWA25alaU38Wh7dPdGAbm9JCrlkeC0S05+gpDtD9aTgSjdoJMf4qAzKgOzZHNTqV5fAyqN6fS6jZaLRC1d5WmNwxQgXzfHXZ8kPght+FtdWA50m4gM/JIAsHK9DjEoZ0i4+j4LkkYOT8OPBy3D8hAugRkRgGSGk3vxHzOGVVH1tROTP2p2btB7u00b2HN6JHu3Dmb5j1bMbqp5benedduj40Gco/XfH2iHcMykl+W0iSQfZSMHJ/YNNlAzcpIlrRrXvjxnfCrEHyb3EHjdhuh6UPIYX99U3nMKiOfRZOhT6aPWBZMtfs9sx2v9P8j3S5fymZPQfeKOe5hz5LFW9e4vmm2TM26P5y72Ha4Yvv36Mke8M6cMjKpLE2xZaf+W02HqSzRKJVAmzYmGiR1yI37ol3xEqJ+0nMykppIzrZ9t+eQkfKvLerStjXTFM1zcU4TQWYzO86yjc+ZHJvVfgHCf9NR","target_count":61319}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
