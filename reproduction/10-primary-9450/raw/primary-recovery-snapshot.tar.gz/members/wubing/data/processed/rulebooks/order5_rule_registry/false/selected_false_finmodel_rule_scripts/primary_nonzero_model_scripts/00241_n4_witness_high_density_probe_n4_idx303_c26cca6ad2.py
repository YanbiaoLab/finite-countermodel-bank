from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1267,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":303,"model_key":"n4_witness_high_density_probe|n=4|idx=303","model_order":4,"model_table":[[0,1,3,1],[0,1,2,3],[0,1,2,3],[1,1,1,3]],"primary_rank":241,"primary_unique_false_pairs":1267,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx303.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx303","source_bits_payload":"eNrdWUuS4yAMNRQL9Y4j6ChazrHoRd+728GxLUsyYAKLoVKpckjQB72nT34WWtbXusLr/XiA9QHzA8b1gY6vKQutjcVZG38iorpB5mneOitaG8nUhFl8MYU2/Yj/xqX9Nx6kKUmeuPtw240nU9ajMZ13mSkvKU4zxV8dsd1K8FfxmynKrWVTuHKKLDiUsm9Y9eLABVOluZnCcKovgw2oz6809dbiVGleYHHgolmCGEv/mRjHh6bJsAPB5ufAPIONdgJzY8GWBeEmCP9PsC2zwLbMBdukzDaTkrEpevvBNjF600fU6FY3DQZbKEGxm9buMxvJugw7wab7lEbcprMuD6oE+Sdg87oaWAobagbb++pBnh2YzZGldmfaToXM9jLChSsyErfZv3s4eIjyre9xiqNEQUSKA052QA3YnNGUKS0ndobkuzWNojVVOt/l3as+5XazjCR2QjDCprE5u2vUBQZk2Cgy4EkZKcNGHRE8ABtJvyvxEGXgQVPuSJd6FRlMxUTjXN5yb6DktqSALQsKV2MOQZ6DTchIloxYD7adooiPQVzJjmiztQ02D6rXsF4GKWDLFnnpNZGmbyZQqgxoHZDItA0drIVlnuHf7ioRQgv9fHcWk8n0JUc7fKSyjDalHbGXTPx9rmdb0S69Fju6f7r1cX+9U1lGKvPY6qrVNZeRiUT4k0wJpJFzKbMp9cCIHjwcKZRXUSNmJhvYQMJ8RD0eLxkklLg+FtnX2Yxo/rWgJTuWucsygoGdfyiuJ4JE1iu1Xm8xpOpGdtPtS9+C8kdNfx44K+XkiAwFsLU15FjgodCQc+vBZghKZ5rRGpJnAxLfR+xtAxISDg1PBydYzGxeEjtV5sGGCoWysmAkPV/8aFeqpn7IZaTGWl63rOzum/LoF2tWRcE=","source_count":537,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrdWUmy4yAMvXcvmmP1UkfREdh9LShwx8GxLUsyYAKLT6VS5ZCgAb2nIX8WWNbXusL7/Xig9QHzA/r1AY6vKQutjSVZGy8RXt0A87RoneWtDWdqwiy+mAKbfsB/k9z+m0jSFCdP3H247fqTKevR6M67zJS3lKSZEq+O2G4lxKv4zRTl1rIpXDlFFh1K2TesenHgoqnS0kxhONWXwQbU95ebemt+qrQosDhwwSxBjKVfJvrxoWky7ECwxTkwz2CDncDSWLBlQbgJwt8JtmUW2Ja5YJuU2WZSMjZFbz/YJkav+4oa3eq6wWALJSh209p9ZgNZl2En2HSfwojbTNblUZWg+ARsUVcDS2EDzWD7XD3JswOz2bPUnkzboZDZ3kakcEWG4zbHTw9HD1G+9T1JcZQoiEBxwMkOqgFbMpoypeXEzpD8tKZetKZK57t8etWn3G6WkcBOCEbYNDZnd426wIAMG0UGPSkjZdioI4IHYAPpdyUevAw8asod7lKvIoOpmGicy1vuDZTc5hSwZUHhaswhKHKwCRnOkuHrwbZTFPAxSCrZ4W22tsEWSfUa1ssABWzZoii9JtL0zQRKlUGtAxKZtqmDtbDMM/zbXSVCaKGfv53FpDN9ydFOX6ksvU1pR+w5E3/f69lWtEuv+Y7uH2593F/vVJaRyjy2umpNzWWkAxH+IFMCaORcymxKPTCiBw9HCuVV1IiZyQY2kjAfUY/7SwYJJa73RfZNNiOafy1oyY5l7rKMYGDnH4rr8SSR9U6t11sMrrqR3XT70beo/FHTnwfJSjk5IkMBbG0NORZ4KDTk3HqwGYLcmWa0huTZgCT2EXvbgASEQ8PTwQkWM1uUxA6VebChQoGsLBlJLxY/2pWqqR9yGamxVtQtK7v7pjz6D+EbK3U=","target_count":62039}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
