from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1243,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":510455,"model_key":"dual_product1|n=10|idx=510455","model_order":10,"model_table":[[6,6,6,6,6,6,6,6,6,6],[6,6,6,6,6,6,6,6,6,6],[7,6,6,5,8,7,6,6,5,8],[6,6,6,6,6,6,6,6,6,6],[6,6,6,6,6,6,6,6,6,6],[6,6,6,6,6,6,6,6,6,6],[6,6,6,6,6,6,6,6,6,6],[7,6,6,5,8,7,6,6,5,8],[6,6,6,6,6,6,6,6,6,6],[6,6,6,6,6,6,6,6,6,6]],"primary_rank":242,"primary_unique_false_pairs":1243,"rule_id":"false.finmodel.primary.dual_product1.n10.idx510455.v1","rule_key":"false.finmodel.primary.dual_product1.n10.idx510455","source_bits_payload":"eNrtmU9oFFccx9d/NIGKhoWqtCVooXsoWGooUfyzatPiRZYeylZoupDQpqSYRRKNuq5vD6ldaIoHKSEUN9ZjI9mubQzJtjtLaWNtEmMOakwcJ6DJBjUzzaZmdpx579t5c+glK2UJ04O8z2GZx/vNfPnO+/7ewL4VHo8n5vkvfrrGf7NjazyC/4MbVyabLlc1L52I6QpJy9KqpTMWzZh4/OrSiSlr4ezWxXARFZTXso4NK5ZO/OAs9/eH2t/fv3qlZ/uAo+xr2Xwy37a1JvBvWXZ223dffLb/wN7VYsUEAoFAIBAIBAKBQCAQCJ5z8CxecEFsiuoKAZipwfk3zEQrVCabiLhhzaIMUBVAoaaKH1uJbo9BrkfXuSAWWxj1w4KR64Ifs3WYwVn6slmtQnPD2l/2qwMi3E5YgjYig49BtV1uqDGYlBANGlMpl0mTBo3Br593IyNZ+/l2RKikUMkJItHu3QV0WXfDWuGE7Wg4CXQZR+/gteS9Ye6QtBsvudRsetq2AgIeRSi2wwYtYSqr3Gg2i0eSMCOHUf/AuGSgHoPsaxM7XWk2P3d0lbsqTBNjA8J8XA3ihrUYUGmvkoEOW8HhS+sr4CGSrjQbCnAEgfsdmA5Z9qu0187CWneaDf75in220LsWj+KJCtiX8Tfb3BDbO9mUvnZ9uMhJwuWJnp6JY+fOd3Z3H/u0p/3D5vYjhw4Hg4d5+c0PdlYF37u0Y3B7aWrHQfsmaZH4ZYOgUTPcZ7YSRVW+2f25StRusAwvT0thXfsz8bbuL3G3IZLG/JEiNxWINBBWKFlUkxO/9AMjqVEqheQ+Xq4H5/huMzOeK7nZnnFWE7AWnkxX1j5WTkVT5J2/21Lo9DHjaZ6XZzLj0uaTv47jxRKbzddihD4ucngzBd+eLbN56eeyi76aAIM3Xz4Pb2WFUz7mvegDyo0SkxS7IvMcDDWmBxonD9ph6Jno7N9WN/LW4Ce9tbW9c6/bYQjODX+0KTWz8f7ym405OQhRXZ+TZFWh0TQJLl7qR3+Smeai0qRrLCNLb0Ru3cUry2+2004OQB9mojrupKVGfYah+uoeHaePKvxcTg71RpqBb+u7lr2RZY0cz8Gu+dHbHaQlRRae/M7WjnkHWUOikHs05OzRT+twZra8HlXL/7IFeA7i6CrELwwhvyWeWL/bQOAP328InKq5MW1vLDWBeMKC74F3paesyBPKSlD7B5PNe1w=","source_count":5083,"source_output_dir":"organized/mining_outputs/out_exp119a_dual_product_followup_a","target_bits_payload":"eNrtmU9oFFccx7/vzTg7sdk4EyvZpELGMTG2hxiTaE1L2Vm7CTHW7Qbj0TYrJQTxII2wtjnsc11tNKFspKGxJLBNwS49lKWX0sY/6x9qKLEoeNhCldCW1sKSikJS6p913hy8ZEWWMD2U9zks83i/mS/fed/fG9j3uFAoxArPY+dW/utv/Lcg+C/YtKNudNfsyNKJmGqwoGk9XDoj0YCM1b8unaiVyg/eKEsWUcHCFOm/83jpxNvOcu85M/D1uQePClfbHeXc8O1j3sEb05mnZf6qa+98+Om5by88ECsmEAgEAoFAIBAIBAKBQPA/B8/iHxfEaqlqMIDIGpx/w2QMQSemjIQb1iRKAN0ADCrreGuIqfYYbHP8rgtisfKmLCQovl5kUTWJahykv8szOjQ3rK2yXx2Q4HaSFrRmE3wMql12Q41Apoxp0IhOuUyQjWsEWXWfGxnx28+3I0Itg1pOEJm2bj2gmqob1jzHbUctYaBXObkBv4TXtXCHbED5y6VmU4O2FTDwKMKwHY5rEdl46EazSTySjCg+NGXbGywFE2gj78u44kqzZbmjbdyVp4Ypd5Dk4xkwN6zFgDl7lRT02woOh6VDwBqEXWk2eOAIAmv7UZOS7Fdpr52Ee+40G7IV8+dtoe8lHsXj87Avo9cH3RC7UDca3Lq5pchJwq767u76Ewf29fX0nDjdPfDlyMDHZ06l06d4+StfXZlNf7f7h7arpal9BNpZR4vEz58GjcvJTnmIGbqx/9InOtN7QAK8PGglVW1L5Ec1W+JuwyyNZBNFbvIwqz1pUFamh+u3dwDNoSZqpcxOXq6mK/luU93gK7nZnnFWk5HKV9bMTa02jsZD7OwLgyH05YiywsvLA4EG6/axNxpwv8Rmyw0rqc+LHN7UInfxVpXXenNxb246Q5D3LlQgPzfvlDfm9+aABaXEJMV2mDwHrWPB9rG6b+wwdNf3dVybbP6p7bOuqamuyp/tMKQrW774I1T959rlNxtxcpCiqlppmbpB40GWLtvdgY4wkeUyY1TVSMC0biZeXo/flt9sR5wcgK4JxFVsCFpjajXBzLaLKo6cNPi5nJnqSowA7030Lnsj8ys+noPLFU0b+9lwiJWvfI3ca8y3kfGIx/diq7NHr5jEB1ULE5hd/pctw3MQRa8n+m4rvLeikb8vKci8mnsdmaPTm2rsjWU6E41IyL2Uf1RYLPKExRLUngC4pPXL","target_count":57493}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
