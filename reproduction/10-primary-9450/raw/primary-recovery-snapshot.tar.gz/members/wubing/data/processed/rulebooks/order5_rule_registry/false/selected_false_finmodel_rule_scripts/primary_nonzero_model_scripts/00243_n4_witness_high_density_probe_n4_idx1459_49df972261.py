from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1241,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":1459,"model_key":"n4_witness_high_density_probe|n=4|idx=1459","model_order":4,"model_table":[[0,0,0,0],[3,0,3,0],[3,0,0,2],[0,0,0,0]],"primary_rank":243,"primary_unique_false_pairs":1241,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx1459.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx1459","source_bits_payload":"eNpjZGBgaGAgDhy4yMowCgYpqGEU+CHPgUXiwZvPvXpp+Vhk/nPG/psuzogpoQBjCOBPDy+MFrZmOHk4sIwG/ygYBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBgFIxz8+w9n/vn//389TS078F+eCUQLMDA0AC37z0/8MDcZ4AcDwwd7oEWMYJuhYiA7aQKA3mE1YGg48D8AGKb//9uLAH3owMDATBPLFqhuPGtmbLztZlpam8rkzg4D4+S0Y2d6DI9J0MK2P/YgHx0HxdiPp/U/xf/ng/jm/+tp4TlgsMn/v17/8//07eYgG/8/b//T/f+/19/1tPDah/8/noMs/P/5/+Pp/5/G/9m/sf7z//t//vPSJrP9t/8o6Ai0yBWc2SoF/wOZHfotQ78csfhPvNoHnfX79o0WvaOApmAfA8cffpYH9YwcDAof7AVANQ3Tv//MDQwf9jOwMIDn5YDlM+P//4wOVKjZbj6Xjj1zz2aj/9Xp+SWG1Z9Dj97juSh87Eb6vBvLX5023zVj789VSfltLziT3xhTXrP5v/i0f0/H//k/Ohac/v9JqWOegO3P//4n1I/8969xufAUWLC4+HfM+/Nf/YkwEwO2+UcOEmwDANCX0qY=","source_count":1653,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNr79/////r/xAF7vV//R8EgBc3/3rM/+I5FQl6Yp+jizAlYZBi+LWLMePEPU+I+jPEef3oQPxtXNX3v9v2/R4N/FIyCUTAKRsEoGAWjYBSMglEwCkbBKBgFo2AUjIIRDhgZ4ExmBgaGBppaZs/w4C+Ifv//fz3QMoYPxA9zkwHY///nPwC06B/YZqgYyE6aAKB3fp3/X2/PsB4YpgwMB14Dfbj///8/NLEs/paf0ckzZzzVZs6svJ1TVn7+zJyZlsbF5yyf08I25gMgH1mAYoxdqoHtBcMEEP8EQwMtPAcMtgcMGg1sDBkeJ0A2MkhUMJcwMGxlCqCF1/gZ2CVAFjLwMMhkMEgtYHbwa+BhUGBm+ESbzMZwgO/dPqBFu8CZre0dA5BZfqF66JcjxxmIVytf1uDoOFr0jgKaAsf/35k//JZv+Pf9/33+A+9BNc1fRoY/9f/5Hf7//g+elwOWz/8YGP7tp0LNpibxZJGx4mG/DVoZE7rPtfCsslL8rPfGUn1GonqEqMkJ13QnttC5EyrFv80RPkN5zbZBnNfBuZwhgb083oSB92554vtDbAwbzG9YM2xo3q0vBSxYdm8oT2RmuCH95u9/bPOP30mwDQB72p6B","target_count":60923}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
