from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1237,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":2915,"model_key":"n4_witness_high_density_probe|n=4|idx=2915","model_order":4,"model_table":[[2,2,2,0],[1,2,2,2],[0,1,2,3],[2,3,2,2]],"primary_rank":245,"primary_unique_false_pairs":1237,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2915.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2915","source_bits_payload":"eNrtWd1rXEUUP3ccZLYPMnfJgxEf5t7cQpQ+JNvqiy/T9SZsioWkamjwybSmVZoXhTzfhBVvZJXtpoofCE2pgk0Eu5Qg+CbSmtBAfBAk0dc+iP4PnnPm7ma3SYslxkS4hyS7986ZOXPOnK/fxANrE9iFrsiihTB7uLUKh5+0bn81IEHsZa2r0eVYaK9RMcYKZaVS4JM1AghmQShIQGhgA0lQoMECKBUlgLYsgtIo3BNgaYx+HkRie48yoTVatPH81lvN0rmdM5KPq9HCfKotCugeuT5fer+/VmdDtFZSD1eyABAKthXIlu14R9/ycd+YqI2V5cMWMNnv3mydU0455ZRTTjlBfwH7iPif8Zp5KQSxJwloD8uwzivxdkslhQVjsQuSCrwEurvD7obL9T7WdTP3k0evqUniD1woyY2bU05dcDFqVMKwXByJ40o4m4LnhSKWYKSZj8IwumzjJFUaX2KKqsfC9wg82RhSzFtWeWmqPRNS/PmeEQicAmlCoGFTZSyHmEsF9IDwRiaNmAWZWQWFSPsYuTJRFKVRHQVFRVrVIP5KHBoSjOESimRBoIhSJcpA/kyGhJgW8KGqGcwoQnpQdRBqtIgaJTASac35No5TgnygE6kTVUckiGpZZlW2WLCyAl6Ka7EeHieNJKWkEVPi8IFm4XwjGETyPNaLUreGMk7BQRxDRgvZpiU4yEnKbENOCx6axWQcbIBshgTmMZyq3LAGTngepzLtkpgdMQlVkDpOi4pK0QxegbEtWQ22rUaCDOojHiQjpmVDWkDxeTE4TJxmul3ZWFDLarRrS1aTshJ6zm3Auc2Oyqb9IKTLCkLdfN64PYunh7IV2kHy4ZWdikb9t+5vjMP82wXHVQ0yGWhXcMgU7Db4t31FkLkNf+C+vY6JHVUHMj+hZ3zt7mYsAnjytQSt1mL1UJC7hgDnyRRsngu2Dlt1yrDdlU1mnuhlZU7mue1fImvbjQe7QHfjwW7TfbeS3WLt6Db4ZDn82w500LpNf//XytILK7/PXLiz8vmfd39b//L4OxfuNd5+4rF9EHb16M31mVLfytbU5Bzdhg2UJqfu3X06uK33Q7Vb3zTXnv1w4/zCF3rzUnPw5eC94Zc++OTID8F+GD2rbPW46PtcUONqqny/rAJlsAYVIs83xhWS6t6lbTR+CpdStXAaBTVWsa6lenBw8pQK5H6E/eb5107PDB9bWv8jfeO5id6b350699VaevSOfvx/H9oVf6hnTC2m4ZGgZywOqmX1rsav8uT2fazIMjgVbaqlHNXC2ZkyvItyV9rbeaELhLTPZLpZI0E/o6DmZ8u1s2pRvxhU54wS90/K6fBQXaT9IfZ/Q3iMcym5hAp6yuQSWcPnDphPP6H+SbOnsEuA691ad/66A6d2Bqo4oEpgty4tra7VCjtHmpvLy7+OL3zUu/T1iakbtbNnaq9PTI+PM/svrzx1/NXhY8/cHng0aRdHKqVP010UteOUOs+XfJ9S2RW/r6rDJUQfzB6GcbyWYib1Hk3am9cw2Pp2SYfpxWvFcu9Qz3D/9dF0UZdPDsihE2OFRWLvOdP/46haNE/OHWaPjFCJXf3F8P/9EFcxscncQ4s9qObxfGBt5AiDsP3oBw6c/gZoLw1x","source_count":2131,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWc1rXUUU/x8UF91qguDCQEpii7gTJJRUMK+ClqYgfqDN60Mf5oqP9K4DuknRNqZxJSlRm0CleSTX19m40TbJomigN/fOQoyL8O7gom+Qce7xnDP3fTVpscSYCPeQ5L1758ycOWfO12+SghA+7ELnTF1AlD2cGITDT0q1vkowYPey1tnwfGBVWqxKKawWRmtIyBoxxBfAavDBKmADGdCgQABoHfqAtqyDVig8tSBojH4eRLa9R+PTGk3q+7Hns+HVKztn+O9WwrFxTwkU0D1yenz1w41yiQ3RXEk/XMkGQGTZVmCatuMdvczHfWquvFAzD1tAZr97s3VOOeWUU0455QQbDewjgn/GK8eNtcTu+6BSLMMqr8TtlspYAVJgF2Q0pD50d4fdDZfrfYTrZu6nlF5Tk8QfuJCfGzennLrgYlisRlGtvhQE1eiCB2ka2cCANHI8jKLwvAh8Tyt8iSmqFNgkJfAkAvAwbwmdep5KZUTxl6TSInCKjYyAhmWFsRxiLh3TA8Ib4xcDFiQvaGiEKsHINb6mKA1LKCis06oS8Zfv0JBlDOdTJFsCRZQqUQbyZzIMBLRAAhXFYEYT0oOKg1CLddTIh6VQKc63QeAR5APlG+XrEiJBVEswqxb1hjBVSD1ci/VIOWn4HiWNgBJHAjQL50vLIJLnsV6UuhXUcAoO4hgyCsg2bcBBTlKmDTkFpGgWmXGwAbIZBphHcqpywwo44aWcypRLYmJJ+lRBSjgtrGtNM3gFxrZkNWhbjQRJ1Mc+SEZAy0a0gObzYnDoO81Uq7KxoKbVaNeCrGZMNUqd24Bzmx2VTSVxRJcVhLr5vHF7Ak8PZWu0g+HDqzkVpf5v3V9Kh/nbBcdVDTIZKFdwyBTsNvi3dUWQuQ1/4L7TjokdVQcyP6FnfO3uZgQCePI1H63WZE1RkLuGAOfJFGypC7YOW3XKEN2VzWSemGZlzuS57V8iIVqNB7tAd+PBbtN9t5LdYu3oNvhkOfxbDnTQuk29+NhQ4YehJycvHxt68/GjT/W/fvuTy0eKn/7x1z4IO3v3ZP/k6uZQz/TsBN2Gra/OTh85+mt8XO2HaideGR74+f2+mbE3VO/F4bVv44+Wv/vgnXsvxPth9KyylYJ6knBBDSqeTpKajrXEGtQI00RKV0gqe5fWV3wuKnh67DoKKg5iXfPU2trsDR2b/Qj73pmvrk8u3yn0P+F98dPc1smXblx5bcC7e0z9+b8P7Wqysr2gR73oXry9EMSVmv5Y4Vdzs30fa7MMTkWbailHtXV2pgzvotyV9lZe6AIhrTOZGi6ToGdR0PBbI+WrelR9H1cmpLb3T8rp8FDJehsR9n8reIwTHrmEjrdr5BJZw+cOmE/fp/5JsaewS4Dr3Zp3/qoDp3YGqj2gSiB6LhYGB8qNnSPDvSMjT8+PvbdVePXW9Kny1WvlL+em5ueZ/Zlvfrv99fKdX46vP5q0S0vV1be9XRQV85Q6Z1aThFLZuWSzoqICog9mj6IgGPAwk6aPJu3zMxhsm7ukQ+/SmXpta2V7eeP0ojeqajfXzcqthcYosW9f23h+UY/K3ycOs0eGqMSu/iL5/36Iq5jYZO6hyR5X8ng+sDZyiUHYfvQDB05/A+RCY8U=","target_count":60445}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
