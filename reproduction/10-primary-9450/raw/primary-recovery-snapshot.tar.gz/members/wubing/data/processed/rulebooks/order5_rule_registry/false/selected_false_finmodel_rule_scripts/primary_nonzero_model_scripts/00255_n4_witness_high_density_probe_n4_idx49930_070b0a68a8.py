from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1206,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":49930,"model_key":"n4_witness_high_density_probe|n=4|idx=49930","model_order":4,"model_table":[[0,0,0,0],[0,0,3,0],[0,0,0,1],[0,2,0,0]],"primary_rank":255,"primary_unique_false_pairs":1206,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx49930.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx49930","source_bits_payload":"eNrtWW1oU1cYTmddq8Ot9QOZSLvaH7V/FEUoxdrrgiPgwGx0rA5mAn5C/0QoUtqanvxYwS8WxwodWBZ0P+oXu2NFwtbVK6OdH1uJIqVIiZHYmmqaxNQkt839eHbOHQykF8b9cfdDzgM5nHDe3CfPyfO8J3BKHA5HwPFfuD7Axlv3Vjg4/g+8RDGFxdalC4H8Q3fjmOBcuqJmCgoeb1y68CQ5P4o9bmNe+toKkTK60F229COXB85s7z1HJ584Sx0l+xsP9LXcqWULxz/dVxP8t2z3zGd99YfpMwOrNznK+a/GwcHBwcHBwcHBwcHBwcHB8QYDFCHkAUHS2XxqmI3BxdhbNpA9AYgnG9qiYGaC0ZDOPMj0RAU+tkOammGKHtNXbCqD7nYZ7D3BzvdsIAuIfwJrdi2CXKpzq+7cdO3vTGH5xaAd0l6yZ4c7AC9SbIpWhQ6Sv9BoBxvdtsQ6PP8ZXo/GyPpbAZdnVVYqtYHsFmNIEEoUEQ1phTQbD+lhO6QtgHk/DKIQ2WAj41IRNAob7Anbb7ooFnDE98wI21/iN3Qr+4t7l9kTNsBHMyDpU4Y0Skz1KXPtdkg7eUBHaPYuy0BnnGagupIpdJX77fBIgMlRsZigbcuQhggV1pBGxp6wRZIotsFbOGpYMaJuYH3rirjDnrAx76cQ02NG2OB9JeoQIb1tS9iSYSS8GiYjgzE9RPKF6/oj4KA+aOre/KvnrHxk1zVSgPQd6q2x7Re0vhb1h7M9XZ25ln3ZoKdqTFjZuXYUFSbuvRTyVBnl/a5s0Fm1PCtYdBKGNV1qkNFBJtgFy5fR8BBtmBeUcyZhUxH13mDlrXJqLgo8a35qMWz/3NXok72zd9ewc+DUB1vjEJyztWbuPVHTZZQ3b7pzdgHBiqLFOxhVu6mAfk9lwq+kMUQVpsc1+L72v2vm3p4TMaPce6O7nW7AodAyi2Gb9CFCu6IYckuagBepL7QhYEx1l5i5N5l4yMq7uj/HHMg2tFiT9lNPsX5wwbVey83PDg7Eq0eazpC185tPocbEvR8JI01G+dZgvLq3aWWcWNxIvUPRiI/2Df1qSsbIL7/6jtGG2SC/X2Z2VAxLbaz8x/TUI/ovadz/R4m1sE3OnMbp71XxnQff1ul1XfOVH3pGQb667zJzb9KZm2blJ/ecX59FdU2u0uLJpvhl0O8pX1MKUVBZV6MXFMQ2KmY3jdBe3DTKpTaZHk0Nt5vLrLH9DU/kgMk=","source_count":5135,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWV9oU1cc/u6ftDeJjUkabWwNxlCkFJmh2/zTMrx23QjSsSvq1geVjAoWOraI/6A+5DS2pUhheSn4b5AozI6VmYKDMIm7taMUxoZ7qX2otUUcMrV1Y66ddc3OuQNBekHuw/VBzgc5nHB+uV++k+/7ncBZKhaLyeLLsLuVjdvf/rvI8SqwEg4/SgaWLyRdG3Oj9Xph+YrkdcpYf3f5wrpAWQOu5Yz54gsrRPUKetfC8o983Hrs544jdHKlsFhcujx6sX1wyyRb+OLboanE87IfKr9pHz9Pn5l8dLs4z381Dg4ODg4ODg4ODg4ODg4OjtcYoIjDBeiqwObVTWxMlIT/tYFsHUCynvivMiprGQ3pcYFU1c7hqh3SJC9TtJ6+wtVedPUpYO8JfnxsA1lSewt4eKMEZP9ETsq5qybfYQrnDyTskLaSPTvWC2TgZ1MMyHRQU85RO9jotgV/x+oPkMmKjKxtAMhn//SoizaQbWcMQUKJopohzelj4wUhZoe0UjDvx0BkohhspE51gEbhnj1he1fQNCfOpdcYYXtT+4xuZZvju2f2hA1I0wyoQrUhjRJTfXJ5nx3STl0UEK/YzDLQE6IZmJ5lCvPzKTs8kmRyJJQEadsypCFKhY354LUnbNEAHP3IOM8aVoxK91jf+kj7yZ6wMe/7ERbCRtiQWaEJ0KD+Y0vYAjEEMyJqoi1hIU5czt3CBuBLocXUva4Vq1l54409xAn1EMatsV3WxfZBad/Rzu4e9+CQJ5Gdqdef9DxowJyJe/fHszNGeVvekyjMPPXoFp2EJlFQxxT0klp2wXIpEmumDfOgfMQkbBIimZ2sfEDxl0eANcNrLYbt/7saoaajYvNDdg6cuHMzBL1QMWnm3tNT3Ub58O0tR0uRmHNYvIORxB0y6PeUa1OyD81Uoa9ORPpw6g8z93aeDhvlmZ1dfXQDLsSfWQxbTRpR2hW1eE4VdazyfyU2A/VSbsnMvYHgRlbe3fU1ykF+waA1aR92OsZbSvP3RXdZRUtraLpx5Bh5UHbrBKZM3Pu93jhilN9MhKY7Rp6EiMWNFHplkaRp3xD2+hU0vv9e+gxtmGPKbwtmR0WT2s/Kd/mqN9B/SXWpbUvWwlZTeRzHP5G0v974dEKY6C6bvZ5tADm5KW/m3kDBXcXKT137/L4H01PuWYsnm5xSQL+nskd2RkBl7Y0clBG+K5vdNEJctcMoV/sVejSNbR1esMb2H/yN8F4=","target_count":57441}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
