from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1201,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":56912,"model_key":"n4_witness_high_density_probe|n=4|idx=56912","model_order":4,"model_table":[[2,3,0,3],[0,3,0,1],[2,1,0,1],[2,3,2,1]],"primary_rank":256,"primary_unique_false_pairs":1201,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx56912.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx56912","source_bits_payload":"eNrtWcGOgyAQBcIBb+gXsIZN+hmk8aC3fhJNerC3tukH7KcuoFtBodpUTLPhpbGJUp4zwwzD6xEMuJurAAz4ITLzhcF62DWYCi8XYRKgl+Y6dMPVjKMHEhgKwiAA6mPZd8LIWKyf6gsEn4HegqJe4aV+eC7UHJ6ofSkPE/+PyJKZpZlTaB+irT202zRUUIKEFaAyEWULV1fCx2DX8GtVnXS1uOhaglQ1IYBGYvs+81vbdkSEqeosgeGMAqb3nz8i2JnFgIhk2t0iYr1ZOFY6SGoR4c4sGW2Po+GcT1inJSqaqlp72QR7gI2WTUT07WwBx60POyv/8auw7l+qiYFtG7MSvIcDqssj8bW6fBJNnwPK/SshRUPXjJ2EpkK3frXuoCWxGke3ycbTSkCtucevOyJyhwq3OXXea55jGkyS4YsQEhT9eHeoeyZgut/FEw4hAhwk0EZSx5hnXpOzdriucIPMO6KasbHXOKUer9HlHCyV6YSEhISEzfETVCCLukQCNdWabDh09DRSRq1FxRyU/b54HHZsmAI1biMz/qR18BwgSXiqhK2SjV+rIs+NboHiCyT8VpflHk0Ekl6cWTWvwgIJ8ZWBN1fhAQ1E8iGhsUgrfG8R0YeEhv+DHtNL/xnP4ew5xGwGbwklQem/O1TxVI0WJpu9Tc9lVnBHSACiKQP/jJrS6YrYKvWR0Q37AvByKhBo1MiuPNrB8onYiAh9/0H/cqn+BcACThA=","source_count":647,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWcGOgyAQ/dT9gKbtrT00KZ/Umx5Mw2c0WeLyBcpNDgRZQLaCQtVUTLPhpbGJUp4zwwzD61X02OkrFFj4ARv9xcR6eGSMQC8XxUDwRXPduuFyxsEDIDQFxa0Q8mPZd2FcW6yeqksrPgPGgipf4aW+UA3lHJ6o/UgPU/+P6JyZgZ4TKh/yrT302DRULRAJK0BmIm9mrq6Ej8EjQ4eiuKhqcVS1hMtqQgWJxPZ9QvvzuSOiWFZnIDRnFGC1//wRtZ1ZWMBIpu0sImzMYrHSARCLiHVmgWh7HAnnfMI6LVGVFcXayybYA2y0bCLCtLNVO2x98En6Dx2gdf9YjAw8n2NWgvdw43l5pb5WF42i6XNAeV8SUt53zcxJaAJV65erDhpQq3F0m2w2rgTEmnv4ugMidyh0m1PnvaY5xsGkDTtCCERlxrtD3TMBVv0uG3FAGOCggTaSOMa88hqYtMN1hRtk1BHlGA+9hgjxeI3M58CpTCckJCQkbI6voAJZ5SWHPCvWZGOho6eWMnIlKtaiNPvitd+x2xSoYRvZoBetg+cAScNTJWyVbOhQVHWtdQseXyBB+7ws73wkkBhxZtW8Cgsk1FcG3lyFN94TgaeEhiOt8LtFRJ4SGvsPeoyR/htUt5PnEL0ZvCWUBKX/7lCFUjWamWz2Nj2VWcEdIUHArAz8M6pLpytiy9TnWjc0BWBxKtBWq5FdebSD5ROxOYXq/pN+can+BYxvIyY=","target_count":61929}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
