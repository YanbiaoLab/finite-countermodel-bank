from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1192,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":4114,"model_key":"n4_witness_high_density_probe|n=4|idx=4114","model_order":4,"model_table":[[0,0,0,0],[0,0,2,0],[0,0,0,3],[0,1,0,0]],"primary_rank":258,"primary_unique_false_pairs":1192,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx4114.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx4114","source_bits_payload":"eNrtWcFrI1UcTrtlxcOq6MVC0cWDHvYga5Faiq2IeJPFwxoLWwILa6DYBglkFkKc/AHBy56W6uYobtdEt7YhO6Svp0qxaTwYtU0ns7AQYTczI0jmrfP63ud7g+hhIm4O40HmgzxI3m9+3/xmvu8byIwlEoli4t/wzd6EXHc6ZxIx/gt8v9VZvT2dHQ9tFImlodw4FT7kxPUYulPhjbucWqvUHcKCGhFV/XR446s9td5cLL375sR44qoxppiruXN5r716pfVX2Y6d2/zyw/eal0tPvxDfsxgxYsSIESNGjBgxYsSIESNGjP81Vgx7yzBqZk6jW2v9/WOzMZ1N925kD56JgOyuSwENAnCCf8OYIb8DWScfxWgnoAyiC4ubTNFoOOhy6M7ckxGQFSUBM8EcEF2RwbWADa3F3bEI2H5VDH5GLp4TsJ34ctG/wKtRXEh5v3SqZQhclysylpfjNRvup49FQLYDGIDgxOIkGE13u8cANWkUoz201EQN+SE1C7TnIJhQaM9FwRbMM6M03xZqMl5TP3RQOhWF2Ti1pBQFc2HphkmYNIAjpBUiMht8NQrhJDAbSC/FkYJ+JiKzKaIHQCYgk8Tw0zZakZhNVxOlFU2/igdlriuzLXCcj8hs8rLZgNUNpFhOqfXlATkdAdkbnVVj72D/8fDO7aNK5Sh37bPr6+u5Dyql97OljxZXkskVVd6+ODedfPvW7O5rZxNv/dloovgIZmMFisO5YZ5n7YKMzg1NbztNjswnBWnE+9uq3CDLtCcw8+38iGkDgwsyM+Sgh5A9GdczFadzKLOmWdjlMFObqjxJ7b4J9ObvjW624e9qUpxSm5iOxQuGnvRu1VGvCsY8VS62TXIu/+MxpkY0myV8IiaHnIZUzQ0+0PlG+cJvVYGXBgseMpmWKj9sff57ErjmPz9a2hS3TKWD75aNO8udd6QYKkfX669cbp7fvbK5tLRpvyjFkLT3L01+3Xv23hDZjGg2GugArrwTBlpdftGQgUlmvTroOvNMpF1x01xjsKbYcVg2T/zd6VGiQGhKBw5kT5uiUb+Tke1lQk9SyJ7qvdwlsybPBmusxMKykRTjIzzZmKt0UBhYVg05Q5e6EEuHGz3xy7bvup0go1kOlf5iFtmwbGbPjvZkI4EOoOfz3k8YtD6ebxIf5R/wM0jjdRmdfnqhrDL6wn29H5bNsLR56p/Z/gByrfLm","source_count":6027,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWcFrI1Uc/t7rG/dNEJyZ7IKBhZ1M06rxYJpKsae+htmQ1q4mblc8ZrXsaS+SPyBjCDiBIGmlEBcWQhdq3IMs3kTEVkotUhcPe9CD7EqhXhR1D+LSbeN7g+hhIm4O40HmgzxI3m9+3/xmvu8byJwMBoP64N/w4syRXOcy9wcx/gs8t5BZvbDfPg5t1IXto1p4GD5kzNAZ0gfhjXOU26vcGMKCkiBl70F44+UZtV7arH346dHx4G33RDGXW3eaenb1Wu6vsjmrtfjKux/kr9d++i6+ZzFixIgRI0aMGDFixIgRI0aMGP9rrLnWguuWnJbPF1aS0+NOYb/dTV1uT/0YAdk5gwM+CGAG/4YxV34H2mYzitHGwBlIGjZ1mKLxMZWm8MydXyIgq0sC5oCZEJ4ig2EDS36OGicRsD2hGLSOXHQzYBvT5OK9ii+juJDyfnnc7wgYBlVkrCnHyxeMN36PgGwOcAFChU1FMJpnpMcB7vAoRjtlq4kK8iNKNnjKRDAh8b+Pgi2YZ09pPkvUZLSkfsig9jAKs1FuSykSZsD2XEcwaQCTSCtEZDZoahRBRWA2iFSPogfvfkRmU0SngU5AJomhdS3kIjGbpybqKppkGaer1FNm26K4HZHZ5GWzADsdSLHaU+vXCfEgArLPMqvuzNT0b+GdCxOVykTr6utXlpdb71Vq77dr72yu9ftrqjx7c2e///HF3dkv7g4++bPRUf0RzMYaHJM7wzzPsg0ZnUu+lzXzFJ03G9KIZ+ZVuSvWeYpg74XtEdMGLiVib8hBpyB7Mup1KmZmUmZNvjFL4fQWVXmfW0kHSG2fHd1sw9/V9CjnlnBMmzZcr69fLKJYJozpqpzMO+JO85lxHIxoNptoghwOOQ2pmss04dGl6q3HywTfJLZ0dDo5VT6Ze+2xPnBVuzda2tQXHKWD59fd8+uZj6QYKhNXil9dz9+evba4sbFofSvF0Lembxy+lPrh7BDZjGg2HugAhrwTLnJpetOVgSl29SL4MtMddA1yyVlhsA/YeFg2v/7d6VGigPhKByZkT4ujUDzfke1lQh9yyJ7qvdwNpyTPBiusxsKykRTHIzzZmKF00EjYdgkt15O6IBuTSyny5LxmGJkgo1kLleRmG+2wbHbvjvZkE4EO4DWb+tNI5N7azgsN1WfxFEThcxmdWnerqjL61hkvGZbNsLT5+Z/Z/gDZxH5B","target_count":56549}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
