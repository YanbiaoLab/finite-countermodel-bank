from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1191,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":10944,"model_key":"n4_witness_high_density_probe|n=4|idx=10944","model_order":4,"model_table":[[0,0,0,0],[1,1,3,1],[2,0,2,0],[3,2,3,3]],"primary_rank":259,"primary_unique_false_pairs":1191,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx10944.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx10944","source_bits_payload":"eNq9WTFr20AUfiedaiWEWDEu7RCKakQxNLTQKVN8LR7iZsnYJSQ/oRkDgVxoC22yFFPo6h/Qwf+gmrp38lgtgY4eM5ioqaQEgu45Nj59DyNb92R9/u7ue+/p+ZNQRHGN/ttGdoyzIzWzo8pPVijMTrLTSSrIaElaNzto/xHjuOwzjvjMZzxbzDgNOYc+5DwrnGMQMRzJ4xxt7l6KY0IO5xgXIEmJisd9taAiS45B/mYglI+EZXj/zu19kjcfQ+ItTjNzCWKXGdgJBoxyanUMWJKjCQzaJAPrYMB02pHpB9Ci0TgdXZwcrYHQrtLNvw5oi1A8uqA9ekIose20vnz2QWj73/9ET1+BwJKdxmkkJQjtx/mzs/bHACS2h7/dNS+Aia1GOLtKgWDxyAOisSVRJfa8BQRL3HEHh7ZBLxwYmK4jV22IBKNforY+holtk7QLo/YYGbTIBTKjA+ge+Rb1t1stkN50v9vodbsgart9FS6hih962/BDAtX+pF6H1w93qCjZ7iF3pCeAYAP6KnFoTeQ86kCRgJELnKlNBsv2BjmRCsmMfCQ1uqcTM7FaHSXTOzH6p1Vqx3vT5WE1peuXS1P9kdWgNrwnYdtV/RbvWiXb2oh5Zvr6tYoqI2Wgb7vo1spIlpmyr2y+E15Fwdfktpxq9Mh2EtLsr9+uoCQK2HsKab9Jw4JVkYOK/49MUd6QhpIFQ827fPHOZ0t6/oK5MRfbe1M6Lw+FpmAzVxmZK2umixeupiXHo4ptc9sggTxxD/lFqsAeFJoTs2wSozTnmF4l2BClZhqaa1IKqRhygLNcHvIXLCH+AZFDgJA=","source_count":1039,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNq9Wb9r20AUVvCQ0WMhizp6yt5J/Q885A/wGigmS35AW3qBQsf0T2jI0rFL6gymOWfKVGhJwRThitKhpcaRQ0jk6qR7SSU1UHTPsfHpexjZuifr83d333tPz0+1JPIm9NfOsqOXHWmYHWV+cklBdpKd1hxNRnOdsdlB+78Yx3KbcXhbEeM5YcapyTnEHue55Bwtn+FIMefoc/eSHBNKOUe9AHFLVGLuqwUVVXK08jcDoXwkKMNH/90+IvXvY0C8eU5mCUFsOQPbxYBRTm2MAXNzNI1Bq2VgPQyYcHrKeQ5aNKo7jZXdV+cgtCXn9EEK2iLkNVbogL4TSmyHg+2dCIS2v/7Q//YRBOYejl74SoHQ1ja/bvWfhSCx/V5NzuMQJrYJ4WzJAYJ5jRiIxpZEldiXARDMTeo9HNoZfU5hYGKMXLUmEowe6cmPOkxspyQSGLWfyKBFCZAZvYHukSd++2gwAOlNtLujTrcLovauLYNrVPFD70dRQKDan+RxcPtwh4qS/Q5yR8YaCNaiDYVDGyLnUYSSNIxcmE5tMli2D8iJlEhmFCGp0T2dmJrV6sid3okRj61Se3kwXR5WU7r4dD3V71sNas17ErZd1Z/wrguyrQ2PZyZuXxeoMlKF4q6Lbq2MZJlJ+8rmO+FVFHxDbsvJUYdsJyHB/vqjCkqikL2nVvabNCxYFTmo+P/IFOUNachdMNS8zRdvc7akFy2YG3OxvTal8/JQYAo2c5WRubJmunjhalpxPKrYNncNEsgTd5NfpArsT6E5PcsmMUpzjumVmg1RcqahuSalkIohB6RX5aFowRLiBrsu8Jc=","target_count":61537}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
