from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1180,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":7450,"model_key":"n4_witness_high_density_probe|n=4|idx=7450","model_order":4,"model_table":[[0,3,0,1],[3,1,1,0],[2,2,2,2],[1,0,3,3]],"primary_rank":260,"primary_unique_false_pairs":1180,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx7450.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx7450","source_bits_payload":"eNrdWUuOIjEMTayUFFgFxAEyiAXHMCMWLDlSaPVILHv6BBx1YieFmIpLGkTMYrJoVB0pLn/e83Pql0EweDa0dpb+YuIH5/nhZ3kwkR4A+WGIvNesuIgGxB0LfiNu+LAP4kY2bK248wFLFDe+HMattJFuCYKRTnN+M+dKQifuHOwQTRBdwZvsyhqNfNYa4OiisBFKtFpH064c2Tpa8mXcsnGlHCI4urBl/9hm7fF9T5x8/tfkXceQcsXkIvrIP/v832TkbHdcJ/Bk1W3BhN/axsb6vYAYx84r4g3HhLXp7L12LgTK4Mr6q7dJ11hBojlTwQUqKNVgVkLwR2dGBCraY15yjAF3084aJrwQ2IiIuDSze8npgS2GjHWbrb0BbIVhb8YhxDeAjVEdcwdMYNXBZh1BG1bWXk/axtInozpkDFjvJ5TdfYVNou5AqEbr9WqxrG8D2RqjOoZV0AabgaGALeUWGHWtVUlEqA7ZP+VALqwj6uBeevWoDLa9OdCPJ7CVpKE22BJxftVLit2tdjbGgN2jckXWzkYYiFurTZLgwj7H8MJtxj5IPhWwFRnJERzGeULNQ7/cU1sbKG2H/1JGUmfDzCSB5bsam9RJivSqr0lzajWSPg1kG8i99MiEnDTBxsMjgc1cxrTFd4JNLW0TsAVdsFUZ6bYUPniPjGRUw1m7aQszm2ILcP6uVwlswEnzumAjGWlWP7SzJsxsiqL1bxlZ9Yga2MqVVmSJsK36R61KTt6HVTKk7sIKSgiTIti8DGgWRHkw3vUE2+w9Y+Hoa+oPNimfI0d3LM+UxYF8HF0u9p4+vgLO6G8qG/Fi8NULEmndGH99+QvXuQ7kQfXqy1DQX0ZKgSSOxr4EZmGYARsZsshDVepELfM34Tx9cLX6bnrIDZskzoSYpxxXxirbD2x25n71cdRPnWizykgpn2Qtg6041ydts58WGNVhNNIH3/X7kTD1CqiWSeCJpnuCe9Sm+WytiSTgnwIbU1T70ucocnTzTs/JyPLTNhwaCiZreDV5uxJ0aM9pP73NNYN/DmUqsTm3pwhlA+cUXwRbebujk8A2sX+EFzEHNZBD09lQCBgIgXxiMq/fZ4XvpkLZ1GYwOeGJW7dTSfBdrz443XgRt65x7Tkx/QdlH3jE","source_count":970,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrdWUuOIjEMPSonmOkl0rSaHIklCzT4GCwQkwMgyAoiVeSkYyeFmIpLGkTMYrJoVB0pLn/e83PqVwJMsE60DpH+guGH4Pnhd3lIlh4Q+GGwvNcse7MJxZ2I/iRueLd34kY2HKO484VXEDc+AtijtGEWBl2STgv+NOeKgSDu7OJgkxNdgYXsyhmSfNYZcRussOFKtFpHzaEc2Tpa8pXCtXGlHCI4eotlf9tm7fF9N5x8/tfkXceQcsXkIvrKP/v8X5PkbHdcG/RkNRwxuZ/axsb6XaEYx87LwgLGhLXp7L0OwTnK4CX6pY9G11hBYlpTwTkqKNVgVkLw25BGBCraY14KjIGw0M4aGFgR2IiIuDSzeybogc26jPWYrb0BbIVhFykA2jeAjVFtcwc0GNXBFgNBGy8xLjfaxswno9plDETvJ5TdfbmToe5AqIbo9WqxrB8JszVGtXUXpw22hEMBm8kt0Opaq5KIUO2yf8qBvMVA1MG9dOlBGWz7tKMfT2ArSQNtsBni/KqXFLtb7WyMgbgH5YqsnY0wYI9RmyQxuH2O4YrbTHyQfCpgKzKSIziM84Sah/66p7Y2UNp2/6WMpM4GmUkcy3c1NqmTFOlVX5MW1GrEfCbMNoB76ZYJ2WiCjYdHAltajWmz7wSbWtomYHO6YKsyMhwpfPgeGcmoxrV20xZmNsUWEPxdrxLYkJPmdcFGMjJd/mhnTZjZFEXr3zKy6hE1sJUrLcsS4Vj1j1qVbLx3F5NI3bkLlhAaRbB5GdAsiPJgfOgJttl7xsLRS9MfbFI+R47uWJ4miwP5OLpc7D19fDiY0d9UNuLF4KsXJNJaMP768heccx3Ig+rSl6Ggv4yUAkkcDX0JLOIwAzYyFIGHKtOJWuZvwnn64Gr13fRQGE5GnAkhTzmhjFWxH9jizP3q46hvOtFmlZFSPslaBltxrk/aZj8tMKrdaKQPvuv3I2HqFVAtk8ATTXeD96hN89laE0nAPwU2pqj2pddW5OjmnZ6TkeWnbTg0FEzW8GryDiXo2J7Tfnqbawb/HEpTYrNuTxHKBtfGvgi28nbbIIFtYn+LL2IOayCHprOBEDAUAvnEZF6/zwrfTYWyqc1gcsITt26bkuC7Xn1wuvHCHkPj2nNi+hvnUvhj","target_count":61606}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
