from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1178,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":2681,"model_key":"n4_witness_high_density_probe|n=4|idx=2681","model_order":4,"model_table":[[1,1,1,3],[1,1,3,3],[1,1,3,3],[1,1,3,3]],"primary_rank":261,"primary_unique_false_pairs":1178,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2681.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2681","source_bits_payload":"eNrtWcFugzAMNYhDjgHtA1LEpH1GQBzGTvskNnGgt63aB+xTZydgstWbKlXsUPkdaGMHGTvPpnrN4BJMUFgPfshB8R+wuXEjAF7BQ1aAAQv0FcZTXw19Lx4R7R7xCnhUGeQQb4PP5r2vylK45f7YnOZZcGDowuBnTiHdw8AOd2zqetvWtHXftE3V+uouL/XYFAqFQqFQKBQKhUKhUChuF4dEeAqi1QhBg5JMQdrKiqhoBSOsCte6pwBgd7gFFictVkXr9FjXHalh82zLQ92ZQ7FHalMiwzl+PnwiwYSLPEilch6LIpeUIs2LFLdF33usj7MZmpLS6qfZHCa7R2rPpy0QKXtLKSe7i87bxUM/L5FUNYE2qwaalDshUCzsugA/1JQRMqWfSOW0sZS2M3ukZrL4+Gfiq2CSaPN3IyR52Rtvto+GAwVqliWxEvm/R7BbbranigOFHoilRP7vEcyb0MIC15CROTKS+WhE07I/X7np4ZszISZ1wsNAGV1GP381k2KzCSMKe81gytzFTjQlecfplcE359Zw5Pn9vxoBVzMpNttlN7lrmTTaMPiwjjZSgI96G508hbDcBdq52NSQcf/IJbVc0p8zy3GznU+t8DJ4oyIvdevMi2DiJLf3BjtbnH1YbHLiwhatjW+2QOpAAT5qYSALBUjyiFbPvxF+8n/kN5swtYQZLZi2POJZom1zbnnhgnJbmu2ca8KMFprNCzHY6Sb7iqHQRgvz6swXE8/hBw==","source_count":1835,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWcFugzAM/dR9wNTtVg5o45N2GjsgyGdMGqL5gAlyzAGBZydgstWbKlXsUPkdaGMHGTvPpnqd4RLkMDoDppxA8R9wk7cFAF7BwDyCBwf0FYpD1ZdVJR4R7S7wCnhUM0wQb4O79qHqh0G45ePYHrJMcGDo0ePnRCHte8kOe2y7btvWNl3VNm3fmP5zGvTYFAqFQqFQKBQKhUKhUChuF6dEeAqiVQFBg5JMQdqax6hoBSOsCte6ZwRgd7gFFictVkXr8NZ1NalhWeaGU1f707hHankiw1l+PnwiwYSLKUilch6LIpeUIs2LFLdF33vrjpkv24HSqvLMn3K3R2ovhy0QKXtLKXO3i85bx0M/L5FUNYE2qwaalDshUCzsugBTdpQRMqXKSeV0sZSu9nuk5uf4+Gfiq2CSaPN3IyR5uRtvtvuWAwVqDgOxEvm/R7BbbrbXngOFHoilRP7vEcz40MIC15CREzKS+ehF07J/Wrlp4JszISZ1wntJGV1GP3M1k2KzCSMKe81jytzFVjQlecfpNcM359Zw5Pn9vxoBVzMpNttlN9lrmVS4MPiwji5SgI96G508hbDcI9q52NSQcX/BJXVc0p8zy3KznU+t8DJ4pCIvdav9s2DiJLf3BjsbnH1YbHLiwo2Ni2+2QOpAAT5qYSALBUjyiFbDvxF+8r/gN5swtYQZLZi2POJZom1zbnnhgnJbmu2ca8KMFprNCDHYaXP3hKHQRgv/ZP0XOLGQIA==","target_count":60741}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
