from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1173,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":12287,"model_key":"n4_witness_high_density_probe|n=4|idx=12287","model_order":4,"model_table":[[2,0,0,2],[3,1,1,2],[2,2,2,2],[2,3,3,2]],"primary_rank":264,"primary_unique_false_pairs":1173,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx12287.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx12287","source_bits_payload":"eNrtmb1OwzAQgM/GRW4rRFohBJsVBQkW1JHRSBmK2LojdWBgrsTuSAzNxs+OMrDzCjwCYmLkEXgAJGorbUhpkwCKq6bct9xJjnzxXe7OdgIGCYxDLjIWHsCw4MnvnAIbUDpn4ILzzq6aZ6sng6FiUAZmmhaBCnE9lv7PHeCN5cxChYiDqybxS8h0iZgoToFRUTyXJY5aieoEh4IBUgHU45fe+Nj07Fp7v0y+yrfwM7xfIUc+9STRixOR1msD2taiW5itf2b/RJi5uc4yEXqua3R7Gb9XZ7dKGwIK3o3v68IFRNu0s7roQB2bQrajP056R+pa74O1anK1sWU6J2sAvALtrJnepKwl20Ow3gR47utINX12bvoK6RCsQsi/ILWd5bqWUPRIFZDpOLkYNARBEARB4sO8zBsVcAYcnbR8bOdu5pgsdxv5kjsKjr3bEuvUF2ksEpARmdiB5d4nMOZ0MyI2Za2UGxqlFulIJ31dbp0VPjjxX2Su0K0Am8EyoFb4F00bMkqhjQIjZbr8TmeGhWSLRW2mnihKyn+BEQurLhU=","source_count":369,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmb1OwzAQgJF4AB6BkQnxCLwCO0PEzs/WDkjxjtSZgaESezdEh0h4ZKxYQCKKvIEQaoNQG4sa+2orbUhpkwCKq6bct9xJjnzxXe7OdlwBCYJDLjQWPkC94MnvXIFoSDln4JzzzhOZZ6tF3ToRUAZmmp6CCnEylt7PHeCP5cxCGYuDSybxS8h0CZsoYYFRVjyXJW57iRq6d0wAUgHI3pc+WH/z7VrbOEu+ys3aWu1ghRy526JKL445Wh82ZFeLdmG2/pmHa2bm5jrLWM0PAqPby/jHSBwRbQgk+MeepwsXKG3Tzuqce3JjCtmz/jjloYq03gRr1eT0/dV0TjEA2ALZ+TS9iVhLtn33ow+w09SR6nviwvQV1VFYhZB/QWo7y3UtkeiRKkDTcQowaAiCIAiCxId5mjfK4BI4Omn5eMndzAla7jZyO3cUQnu3JdaJFmnMYZARmdiB5d4nCBG2MyI2Za2UGxpCFunIMH1dbp0VPjjxX2Qu060Am8EyQFb4F00XMkqhjQJDabr8TmeGhWSLxXCmnhCpyn+BEUDVQyE=","target_count":62207}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
