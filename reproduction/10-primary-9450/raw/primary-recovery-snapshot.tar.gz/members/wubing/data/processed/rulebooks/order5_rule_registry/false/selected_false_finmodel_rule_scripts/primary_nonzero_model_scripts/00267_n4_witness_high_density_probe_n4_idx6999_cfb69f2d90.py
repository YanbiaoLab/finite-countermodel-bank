from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1166,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":6999,"model_key":"n4_witness_high_density_probe|n=4|idx=6999","model_order":4,"model_table":[[0,0,0,0],[0,0,3,0],[0,1,0,0],[0,0,0,0]],"primary_rank":267,"primary_unique_false_pairs":1166,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx6999.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx6999","source_bits_payload":"eNpjZGBgaGAgBLacBJEHTnEyjAJ6gAvbbudtMi7GlGj4DwbsmDJ/wBL2mBIJf78E+33sx2ILxCx+TIkN4OheFdkT6MTCxBBhyQiyubuIq7Ik0E8RYZLD05ApmiksQDkhJQaO0VgbBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBjGIHf32227d2+/W1b+fdvsN2fu3N1rXJz+bF7xOWYaWPbgPy5AC6/9wWWZPA0sa8DpNVoE5AdcltXTIiD/4bKNnwaWHcAZkIw0sO0HLsvsaRGQOL3GTgPLEv5+uez/v7/u18v/F/0tj9r/qhf5r/Ev8Md/59HMNprZIMDhdt7uk+fOYJkd2nRr3bpbZZPnzly9uixtXU9EcU9hZG54eC5I+dVQa+NwtzWWxywUGFygBrE0EJvZ6knJ8xQEAE5NP4iyjZHUzIZjrkb875dPL5bPeSS/16arXuSTRsf/hd11VZVg5XFyR+25KkWO/BcgJ7PZk1LBkl/aNGy7C0oHp7N278q67QtMDOtuzdxplHTW8BgjUcmGdpntAMWlDSmZ7Qelpc2BXy9B6SD2y+XTi+cXddV/+QQsjk8sVvjXLkBMslFUAAovQFUF4jZQXrM9oDizAQBxIe67","source_count":5976,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNr79/////r/hIC3GYi0N/32fxTQA+h7qkz0PdODKVHPAAY/MGWYwRIHMCXmM3Gv2chXgMUWiFkfMCX8wdEduqx43d7ff/8vP/YPZHNJ79e27nUb7yFM2i+1Ovva7N9Aubd3/38fjbVRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBSMgmEMJrkIebq4eCh1dnB4pggbKys5nemZIZnYY/iHBpbJM+ACtPAaMy7LHtDAsnqcXqNFQPLjsqyBFgHJiMu2DzSwzB5nQP6jgW3suCw7QIuAxOm1HzSwbD4Tt84GhoJGVjEGvQ3HrA6wNrxmuM64jp1hz2hmG81sELBfZaKLmaExltkhX9XAQNXOnKS0kJDOmYHFy3uK+5ZNWrFiEki51qojZ1bsDD5mefz+/91Qg37XE5vZGkjJ8xQEAE5N7ETZ9o/UzIZjruYFEzeveESy7AOnw6UNr3mvlzPElTS2toGVL3xodeBr22trhvfkZLYDpFSw5Jc29Z5KoHRgMtXFdarKJmBiCFRNczs71+ic5T+ikg3tMps9xaUNKZmNndLSxp5VDJQOFnHrmMQk9JY2cPMCi2PzmPuMFe+JSTb37gOF41FVgbj1lNds8hRnNgDbUIJs","target_count":56600}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
