from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1147,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":437,"model_key":"n4_witness_high_density_probe|n=4|idx=437","model_order":4,"model_table":[[0,2,0,2],[3,1,1,1],[2,3,2,2],[3,2,3,3]],"primary_rank":270,"primary_unique_false_pairs":1147,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx437.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx437","source_bits_payload":"eNq9WMFu2kAQnbWtYCoUXNpDDhwsi4gcopw5VIlT+QC5tD9QqZ/gfAF7iQSntIhjlPApPvU7rH4BueWA4tprhJSw4xqxvDkYrZ/tx5vdmZ2dOxESJQ0qrKuuibrSZ3UNy0GLfDVQw1UmSGtp1tYDlDUZ4GXEAMmUAeiSA2IOkLcc0uKARY/RSKfcK2ccELocYnHAcs2ebkmxuVfXUpwtYFH+aASVd/zQeQ+4bz7v0uYBn3hLMmU2QexFkY0xZFRKa2PI0pJNYNhWiuwKQyYLXQ5o0miZs03vXRDba/bty/NH0Kwl479NlLAi2Pq/owg1b9n0fDaZgMjSXJkjUI586AcTH+VH+ena+UC4YGsQzl4zIFkytoBsbEl0EOsjpaX28grH1qVHHJlsI2ctRpLRH9HoLmHBNkiB0k6QSYtsaePIfkLXyLw3GwYBKJnIWdQZRRFI2vdcmYQ58qYjHA9FFjZ9gpXjdAbd2U6RZAv6hfPjujeD2tm8kHBnNs9ygdq+Ih0ZVrZPTBvSjfmZrboTszJaHaXVnRjxw6i0Vb86PIxu6fKpOtJ6Ro+qcVCNm436Sx46JtOxkfCOyvdyeYEqIx1PbrroxspIVllBJMyy8Z3wQxR8czZ5dszvQZL990OrWCZml6THsqmC79qsPJZM0+7fP9gabJYfaNL3nqmm/KTUpeVmvX3Q3TnYYt12vn3L1yWbncrIMrJqOWjvatrhdBxi2WwaJJATd8xP0gHsaB1zos4i0YbmDqkmFJsUVYNtSLUe+18ZKYI6Mqx9S4h/YmCBEQ==","source_count":1032,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNq9WLFO40AQNUpBR77g5O+g8qeE05UoQJVINJsvwJ9w0v3A0RwpLDCIghpREBFZLlJQQHBOiDjI9g72OooE2TGOsnlTOFo/2y9vdmd2do6lT+TMqLCRujrqSk/q6peDVwrVQA0bliSt2dZED5A1ZYDtMwZwOgxAVxzgcoA44ZBXDmgNGY30wL1yzwF+zCEZBzTn7PaSlJR7dS4lWQJa5Y9GUHkn9JOvQPzp8zEtHgiJN8dSlhLEthVZD0NGpbQJhswu2SSGraHILjFkotCVgCaNmjlb5ygGsW1Zp9c7L6BZc3o/pihhRbANDjwPNW9W567d7YLI7FxZIlGO/DUIuiHKj+L5InkjXLDNCGdbFpDM6WVANrYk2ogNkNLstHmJYxvRTxyZmCBnzUWS0a6cjZqwYLuxgdIekUmLUpHiyH5D18j+sN0PAlAyEW1vfOZ5IGl/c2UC5sh/Y5lEKDJ/GhKsHKd76M72gCRr0SHOj/PeDGpni3zCndmiLAZqO0c60q9sn5g2pBvzM1t1J6ZhtDqyqzsx8o9RaY1BdXgY3dLFXnWkDY0eVd2gGjcb9Vc89J9Mx4bDOyrfy8UtqoxMIrHoohsrI1llBZE0y8Z3wjdR8O2zyXNsfg8S7L/vZ8UyMbskI5ZNFXwXZuWxZJp2//rBNmOz/I0mfa+ZaspPCl1antbbB+OVg83VbefLt0JdslmpjCwjq5aD1q6mE07HJpbNokECOXG7/CRtwN7nMSfrLBJtaK6Qany5SFE12PpU67HvykgZ1JGRrVtCfADqEfAW","target_count":61544}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
