from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1146,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":1127,"model_key":"n4_witness_high_density_probe|n=4|idx=1127","model_order":4,"model_table":[[0,0,0,0],[0,0,0,2],[0,2,0,0],[0,0,1,0]],"primary_rank":271,"primary_unique_false_pairs":1146,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx1127.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx1127","source_bits_payload":"eNrtmV1IU2EYx98zZzvZh7MpGsRcGpwiyOzGIt2mfVg3HSFIoXJpH6OrQoiaRTt9QVrhKqIIayWFgcJaXVTW2CE1FKsVIVYXNtZMU4O1tTX3cZ7OWdCNixjxdtP7uxjjvM/Ln2f7/58XzkshhDj0JzpbpU+epxDhX+ALdE3C+erpC9yl7vRVx0qTbIm5QhHncN70BfeEvwfWskm2GKh0QTEvycKd1uYVp86KX6oq5AjlrVzApfFp0sJ+NBdl/irTu5UctYP8WwQCgUAgEAgEAoFAIBAI/wEAA4LZFDTXfrUKIKKzN9aLzxirDIOYG4CtLc5fFjV6eyUxc3Ed7PFeUn6ahaO1GHyPOoX38MFxLSqplThfDsfBML56DgYxzjZwEFRlU2ZdG8PG2G/ewqeORwD0zRYcrfm+H/ZAx0yYqC/xPAbX8LtzltyvYFi5W45DTTTGaHZgrA0q1XHph8xdA7BGnV6nxaHGw+/A8Q47DIYQDHRAoBm+JUSaBlVRMGinsvGErfNox9LQ0C7js0TYnt/O2hx0XWjISMMSNnM/FBUJrkKhO9EaU8F6QTflVeFo7cj2ZVErz4OJyjnkMbcxOWi8KQ4KejkOMU7sxjmoi07AA2OitdE3ABHjxngLDo/4wPURwhlg8Nd7JLGWJ0qTGLbTNkxh6ypdSOkvM4vEASaOSA21lvWuQwVYpj/vmrgHlbVxa/Xz9gEh3xRc33n9LUB9X3sy947mBD5L5Y6sDiYEzjz/ktTUalZts6j6TpxpoA/tL9+kyVTTvIo2ydFUMve2LZCpE+UKmU9eoab02lTDdt8h2EpCYNzXK12w1Lxot1cDXIzMTkt2VLzbapfKtwT2Tg4C3NJ2pxi2n3c1wtCpsX6VdA6c1hR5QFcxVpjMvQcWNibKtQV9Z8LQoozQKYYtPTucv4GHDKW8yi06RE5x8hgoUFYy9zplckoqR+VIQ4lTVJ+ibTnr0G7R8xGd7Qp7Oa7zj5+rKbMD9FpYHGG72/BQw1gUuSNKn/t4q15dquQYpZ9Gfiw3mILxcNywb1I8QZu/BM0O+1V2p00AJjh/Bo6wDY00QdP1mG3W64uMwDT6s8pre8B88lUljtbCGYt9OgsHORr6Bg96GS1DM8OQ+ZtBQv+l2g+j8c7F","source_count":3691,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmV1IU2EYx5+zD+fW1iA1rTWWF5VI1CpJMuOM9XlRa6CQFNZMoohqUmrQ11mkMwKpq1gf2qxAg6DTTdmHbtMobzKFqANZcwQpupx92FnOnbdzFnTjIka83fT+LsY47/Py59n+/+eF8woIIQb9iZJK6ZOmBUT4F+i16zPgUNv0BWZ/8eTTU91JtsjNaqUld2j6gilTtxoesUm2eIVJKvoxycK2yprnx46IX+50xBAaevaemaKnpIXz6BMa/1XmM0UY4Rr5twgEAoFAIBAIBAKBQCAQ/gMACiiXW+NqmemgQMRvq28Sn3GOOAYxEwDb0jvYr/AYiiQxV28zXDLsj8z5iqM1OaQrLNQCmG/drZDUeizLcmXgzXryGYMYYy84C+GuNJe/nGPl7AzDwBrrBgB+ZxWO1vTpdUYo/QaZTT3GdWDOXXjYOTwTvM8ux3CoicbIGdVml0N7SCb9kMOPAR6HJpsDONRo+B043mGrwKuGglLQ1sCMhEhtflgB3kDaKJ6wlZwufanOu+JZlQjbiu1jtzXmg40TU1jC5loJfX2UeYAqTrTGdbAG8KcZwjhaO3O9X+GgaXALIw1GVzk3grJqZRDlX+AQY8RuLPl+RSZs8iRay1kMoPTck1Xh8IgezPNANQFeXZNREqtaG3GLYTtqxxS29d3vBN8+7o04wMQRGRQesYaH6C2W6U+bM7dAe4vM0bairIAadGselFQsAmgqLEvm3pwR7Wyp3DpWyqnBMqR7lZpa69MbznDhiepGvuF8593geIinw7w7htKSubf8fTyUKI/G9bGOkOALpBq2zVbK3qMGz4Ui6YKldXmZrQ3ggPLLVLKjYuFNm1R+S3sxIx9gR6A4xbD9vKuh8o5lrwxL58DRYJ8R/B3ZA8nce+5dfaI88LawWgVVESWfYtgmR1WD92mYiMTumESHxAQmJocoGkvmXks8JkjlqBMFBXGK+lK0LePIuyx6Xum372X3yfy6rMOtXTaAIieLI2xbGzcGOWd0eG5EbzpZ6Qt1RxguouORDssNJuWpk3kvZIgnaM0sjctq28NetVPAaT58xxG2vLm1UFsht39dcoCjuHrdWGfLanAdX9qOozXVxGu938nASJDfRYMvzsfRNxWM/2aQ8H+p9gOogKJi","target_count":58885}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
