from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1083,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":2892,"model_key":"n4_witness_high_density_probe|n=4|idx=2892","model_order":4,"model_table":[[2,2,2,1],[3,2,2,2],[0,1,2,3],[2,0,2,2]],"primary_rank":279,"primary_unique_false_pairs":1083,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2892.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2892","source_bits_payload":"eNrtWT1vE0EQnV0t0jqkWAcXlHvHIRmJggBKvT4uyEFCSkIaOihAIMF/WCxHuqAUJkBFk5h0iAbxCxCKAFHQ0MCfYWZ3zznn01ESEtCNHF/s/bp5t/Nm3pqBMRZ2sIbgBnT4sJ7D6TelBv9qEMAPM9dq8iLjwFbaoA2XRkiAOsQ0MXtGM1t6CwBJcAtLmVhALCdAKmxlHIzANnrtZpzX3FXgC8eSD77hx9SvRx+u3Ng+wr6yov5MKoMLDLesL1193lzuOSBM+E7u7eQlkDFn/hkX2DnUVovHPZuKvSbQ4a+yyiqrrLLKKjukNWWoBUYwXcM6R7iygzI4h8NVPf+Xic0KVgKzsG91WCp4d613BJZ+YCtwK6usbK+SlXYcpxMzWdaOWY5qSXNDukYvJXGcvIDM5qSLiKJ6GVdswkCMHXJQzADLc2BaU4SFgUzgxwyboUvyyMVrRB8osO1KRgvhOAxs7bSL8GLHcyH3esaTKKoh7jQcRi3DJurHvOgC18l6CeYpVJViPYT5rGpzpI+ZhCnHt1lmneRTFt9lz2k9pA6n9QzUQDi2YeiHE3ZEGtaRhluj7gYWbK2CSusGFxWk7s60paFDosxSb3JmU685B6UOUlAOvioE8YDOOGzRcWFm09KkQBOUjTZRJFwLYiQuRNRI1g6Uph5Qpy1PVIzAx+UuAYpCIKotmS0s5BVyQG1CImrao+bl8A6ZTdX9CIIgSGs/Hu+PyfBEeXi68u9uf629R4QakDPgXdFuf2pGzhQ7zG2bLQCU/SgGDqAIIBYu6nA2ExYaQo1tQ60nBve19xohs5VADIFR2dGYMS56hItlH2xDhYffsvsEW5kRdgi2k7Kn795Pnb328efDi4tTb558X5hZm7zzYKNzb/w46tHVi1Er0zy+pbVNXi7llCl0V/nkcOTmD9Zms3Ov1bdm/0oaLabji2qsEx0HxdiO4ZhBenS+x9ucgpYyJAWto0fKQUR+R1OE9vgX3VdQv604dHLMhAomVSolP5bNNJ+dm26kzf5yKqcbc3JNpfe7qTzTUv8+xbTrzqM8Hosac1mEbuEOiRqitcN5bEjatlSFbIIthhLXluApcLrUHywUP292ZwnKqNvRkm+uUtlpsx6Xuo/1XwtCsOEGoGDDCxV6tszxNmybXQu77ZuivMX+emb7/ejt10/jtZE63326MO+6v26MXVu4eVluHJBr2rW2qo/4g5TuC85ddyzRRSqZOShAj/vL8diF0Sgquz5XW6PujfnmZwxLfb5zmnfkOuhcitHOjNQcFYuuO4qoqFv97nNiZWTL1YW+8Hf1wP9zKPUH4mavfQ==","source_count":1422,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWTtvE0EQ/jPQ0FAgQBHiFyAaRBecNFQJwUVETopl9j8ECQQFdDQhiYRELDjOW0c8UiDFEsfdlhQm3iLEK7HaHWZ295xzXhglgYBu5Phi7+vmu51v5ltb4JzBPtbVhoMIH8YjOP0m5eBfARrMUeaaTO/GBuxMCwQ3imsF0IOMJrb3aWZGbwEgBW5hpVIGiOUmKImt1gDX2Eavg8yYvrtqfOFY8sE3nF87++j6+tu9I9g00737SnJcYLhlfO7Dvc5s3QHBw3fqcCc3QGXG+mdcYOdQmywe90qiD5tAhL/KKqusssoqq+yI1lGhFhjBRB/rHO3KDsrgBo5W9fxfpncqWAWWwS+rw1LBe2C9o7H0A1aBW1llZZtOZ1pZlmyuxnErsxGqJWE46Roxl2ZZehdiFpEuIoqqx0baTQ4ZdohAWg42isAKQREWBlqNH2NshgbJIxevOX2gwGYzMS2E4zCwhdMu2osdz4XG6xlPoqiGjNNwGLUWm6if9aILXCfmJZinUFmK9RDmK7JlkD5WUysd38Yxc5JPMnxXdaf1kDqc1uPQB+3YxqIfTtgRaTBHGm6NnhtYsLUMKq0RXJSQuDsTjIYOiTJGvcmZHb3mHFQiSEE1+KoQxAM6M7BLx4WZeVuQAk1RNrJUknAtiJG4EFEjWTtQmmJAnaw8UTECH5e7BCgKgSh3ZbawkFfIAbVNhagJj5qXw/tkNtnzIwiCIK39eLw/q8ITNeHpqj+7/YXwHhFqQM6Ad0W4/SksOVPsMLdtdgFQ9qMYOIAigFi4KMLZTFhoCDW7B7W6HtzX4WuEzFYCMQRGZcdjnLvo0S6WfbANFR5+y/4i2MqMsE+w/S1buHlj7fv7a+cef55fu/3gwuLqxMcXT8aaz7ZOoh6d/Jy3Y2GyV0Kw9M5cRJlCNKRPDsdu/mBtJf42JS92autJPp9szcvtZn4SFMOa3GAGqdP5nmkZClrKkBS0jh4pBxH5HU8RWjeXRU1C76U00IwwE0r4KBOlzIlspqX425tu0qnNJupNd1lNyORpI1E/2vLfp5hWz3kUZdt5dznO0S3cIXlXt/c5jw1Jm5WqkB2w9VDi2hU8BU4btcFC2b1OY4WgzBtNoczOKpWdNqsbJWpY/7UhBBtuAAo2vFChx8ocz8K2ObCw27spylvsj2e2M49uXbq61R+p8/OFxSXXfaq7/X7x9Sc19ptc0+q3ZG/EH6RETRvjumOJrhNl+e8C9LA2m21/GY2i4nfL/Qnq3l3qXMGwFF+bp3lHjoOIlB7tzEguU7HouqOIyhvV7z5/rYxsu7rQF/6uHvh/DqV+AmoLwao=","target_count":61154}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
