from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1080,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":1493,"model_key":"n4_witness_high_density_probe|n=4|idx=1493","model_order":4,"model_table":[[3,1,1,1],[1,1,1,1],[2,1,1,1],[1,1,3,1]],"primary_rank":280,"primary_unique_false_pairs":1080,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx1493.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx1493","source_bits_payload":"eNpjZBgFowAN7Li7btvUs6siewKdWBgYNCapKHIKTlRRUVSa1KLi4gJX1uDBBCQdPBxYRoNsFIyCUTAKRsEoGAWjYBSMglEwCkbBKBgFo2AUjIJRMApGwSgYduDAf4pAPWm2/fj/5/P+v7P////569P5/9/y9+27sf/n//M3/p/5/7+m9ufz+t/m8fFv7v/5n/6m/tn/+n37wMrX63/L//ff+Js9MwNDAwm2vV48t6jLvOSiu35r2SnNewEnF29wV+xv+sGz68Xi6U7WT0XyVzwJvLF4grtjDVvsl4veC0HKQz5pvAk8sVjBrhloAiPxlj34//X2/8/r//1//fxy/v/z+6uqw/6/+V9v+D/4//+vn19u//88fq/t6vpv//fP+L/y//9fP7+AlN+bd9X+9//4M/9FSLNtjnrJRde4I8L+NS4XXMUrBV38O+YJ2Co+EX7UqW6n9GJR9x6ORepgwU+cH48IywuClLNcFAYJcvxsIS3WGiBxzY4p8wczRTBSmiI//AenA6zOQE82PBSn/2vuoHTAgenqAsxkw0R5ZnsNSgdYgghLsqHYaxb+4HTAgekMzGTDxMCBLeJJsA0A1PlCqA==","source_count":2560,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNr7938UjAI04K4U6JllFLqseN3e3///X8+9fe/bu7zbt+/dza2+vXs3XFn99r9Acv/2/b9Hg2wUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBh2wJ6BItBAmm3sDMw8DkwpDAxsrLwGDJwTHB3VHdgYDNQZjBkYmpvYJBpYTixYIKzAzDBDuEGSocHREaw84ALnBEaGM5wH/vz/X0+CbSIxSb2lJ7r1dlyo6jS9prjeLMZ/x72CWvbPruIxGXuPSL2eEC69Tj0mf8e+5p+LuPW2xIGUr+a9LrzOPOb+wRqgCf+It0yegUuFgSeAkUFEQmcCg4FDa8tKBmGGhnMMaxgYuHjEPBgkFjgdCmngZHBIZwhjYGBl4wYpV0zUOsDCsMCY4TVptiXf6NbbtdD6zYbm3fq7XrS9272hPPH9oXvSb2TLbhy8Kx5b4vw99gZYkPcbn/WbB+9Ayn/rvQEJfmerJi3W6iFx/QNThhkzRfyjNEXyM4DTAVZnoCebzxSnf80doHTwHdPV/ZjJ5i/lmU0ElA6wBBGWZEOx145vAKeD75jOwEw2f/9/xxbxJNgGAHd4Lo4=","target_count":60016}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
