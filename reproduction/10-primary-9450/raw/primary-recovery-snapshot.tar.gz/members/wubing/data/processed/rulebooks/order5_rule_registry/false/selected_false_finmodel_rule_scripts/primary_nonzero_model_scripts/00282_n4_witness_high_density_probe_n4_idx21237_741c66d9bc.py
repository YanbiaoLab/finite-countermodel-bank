from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1072,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":21237,"model_key":"n4_witness_high_density_probe|n=4|idx=21237","model_order":4,"model_table":[[2,2,2,2],[2,2,2,1],[2,2,2,2],[2,0,2,2]],"primary_rank":282,"primary_unique_false_pairs":1072,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx21237.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx21237","source_bits_payload":"eNpjZGBgaGAgBNbMAZEHLrIyjAJ6gA//wQBTomH9aeH/wraMmDJ/wDrsMSUeQMzCouU/Z+y/6eJYJFbM6TJq7QEyApxYGBgtdtks5L4oDHZXi56LP1zZgRdGC1sznDwcWBgYGEcjbRSMglEwCkbBKBgFo2AUjIJRMApGwSgYBaNgOIP/uAA7DSx7gNM2WnjtDy7L5GlgWQNOrzHTwLYP/68/ra8U/G//UfAhyA5hW8WqT//nT/DnoEVA/sPlNX4aWHYAZ0DSYqTyBy7L7Ecz22hmg2U2HKCeRpkNmKsdp/9/6goKU1AuBzI79FsYBjqzURwAP3bZfLS/OPl/KbCwOvLfxd9O6UT3j//9Ar84MGchHtTHdswDK+/n+KT0779yix0TQ8MCzKTQRI3M9ofS0oaUzNZAcWnzR73kZ3zckf/+NS4XQPWAi3/HvD//1Z8IM2FLvcLygiDlLBeFF6n//8/5s4VamY0WZfSH0spH9UB3vnb68qTzf+e8GpcJ4h//yyt+mYgt2dCsZqNFGX2AlICkvGbzf/Fp/56O//N/dCw4/f+TUsc8Aduf//1PqGNNNtiC8gTDDKJtAwB6+O2E","source_count":5976,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNr79/////r/hEBwMoi01/v1fxTQA/AzgAGmRH2AyRuGN4f+Ycowg3UcwJSQh5iFRQvDt0WMGS+wSIQnl56tKgYy1u/9/f/fcdfDcV/03oDdVX1x9wa4Mnvxs3FV0/du3//7//9/o5E2CkbBKBgFo2AUjIJRMApGwSgYBaNgFIyCUTCcAQMu8IMGlsnjtI0WXmPGZdkDGlhWj9Nrf2hgGz+DhlRD2zuGA3zv5EB2vDl0r5WXISF/w3daBCQjLq99oIFl9jgDkhYjley4LDswmtlGMxsss+EADTTKbMBcvS+DQWoXKExBuRzILL9Q/X+gMxvFAcDuepjvgF4OQxewsLJm2L3h4F3zEnaGgves3zFnIeQbFpUngpUXfOe9y8hwp/rg3//18ZhJoZYamY2Z0tKGlMxWT3Fpw3yjm23BQmuGDc279UH1wO4N5YnMDDek3/zFlnrfPHgHUv5b703sDQaGb2zV1MpstCij+bvaZBuA7hTZyy1dxlCW2Lw7/wUfw4N73HnYkg3NajZalNH2pAQk5TXbBnFeB+dyhgT28ngTBt675YnvD7ExbDC/gTXZYAtK8//pRNsGANF5g6M=","target_count":56600}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
