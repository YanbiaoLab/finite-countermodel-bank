from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1066,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":168376,"model_key":"dual_product1|n=6|idx=168376","model_order":6,"model_table":[[0,1,2,2,2,0],[0,1,2,1,2,2],[0,1,2,1,2,0],[0,1,2,1,2,2],[0,1,2,1,2,0],[0,1,2,2,2,0]],"primary_rank":284,"primary_unique_false_pairs":1066,"rule_id":"false.finmodel.primary.dual_product1.n6.idx168376.v1","rule_key":"false.finmodel.primary.dual_product1.n6.idx168376","source_bits_payload":"eNrtWUuOwzAIxZYXXvoI7k2sOZkXPfgAsTEZk6azmcWUJ7VK/AnweLgVCfAOnpBKg5YbOP4CJebaAfAbGoQEGQrQJfTC94UWRfw0lSJa3fEbaA3OHtugJr5PuKbzs2XLg1eToTXLwKuU2QI+v+aQYW4MqdJlONYl2RE9Zw6Hw+FwOBwOh8PhcDgc/xoP1XjiplUH7kFZQ9zaCunoaPEgzA7XXJMAZJq3wJjkRtPoaO3dsdUSy+IZtaoqXUizqsvcaoVJ/6ptoT2VoSr+ZbCG8CZyq9SOY3TkFBU6LvJ59PcMivIpGJgR9ds4zlScMNqMbKiLf2QAfdhYi7D6jsNGv7ZRNyK/lKETRRZrhmwky4tuJaCD2HkDLaunxqzScMFau43DEJBwHJahU/PVGLJk87oQVFzlg4tN1cCRmVM2h436TiFM3z602HbW4OfbhPcKQXw7is0gEk1HTKk4kM2hsT5ObTY4TSphNik2Q2taIKIDNIRZFtWGewaL8ctmEMlPRbFOiVZzSMUtDujJVXA0c/2uRoUqOiBD9EJmeJXuj6tmFJuhNRChLBfIEA5N1fbNRtjYy0axGUeUATaUipBdfvt/ZL5A248o4VYxhYaQhaJ0+FIh2S4249QywIa4BkTrv8Mstv2IkiSq0raK7YVCqv3LZhxRVuaMYktGbq5j+waDnW38","source_count":879,"source_output_dir":"organized/mining_outputs/out_exp119a_dual_product_followup_a","target_bits_payload":"eNrtWUuOwzAIPXgXPtnIN6mP4CULy2YwsTEZk6azmcWUJ7VK/AnweLgVafgOHlhyxAgRHX+BXCEFRPrGiK0gYMZ+iSHzfe6LKn2iSlFfHegb+xqaPbZhKnxfaE3gZ8uWJ6/uhtYsg64KsAV6foIGODe2kvplO9YV2VE9Zw6Hw+FwOBwOh8PhcDgc/xpP1XjiplVA7kFZQ9zaauXoaPEgzg7XXFMQZZq34JjkRtPoaO3dsdUSA/Gst6pSv5BmVZC51QqT/lXcQnsoQ0n8A7SG6KZyq9SOY3TkFBU6ru7z6O8ZFMEpGJwRhds4zlScMNqMbCiIf90A+bCxVnH1HYeNcG0jbUR+KUMniizWDNlIlhfdSkAHsfMGI6inVlBpuGAt3sZhCEg4bsvQqflqDFmyeV0IKq78wcWmauDIzCmbw0Z6pxCmbx9abDtr+PNtwnuFIL4dxWYQSaYrpVQcAHNorK9TmxFPk0qYUYrN0JoWiOiADFGWRbXtnsFs/LIZRPJTSaxToskcUnGLA3pyFVyfuX5Xo0IVHXRD/YXM8KrcH1fRKDZDayhCWS50QzQ0VRs2G21jD4xiM44oA2yoZCE7//b/yHyBth9Rwq1iigwRC1np8KVCwC4249QywIa4BkTrv8Mstv2IkiSq0raK7YVCkv3LZhxRVuaMYitGbq5j+wbI1AM6","target_count":61697}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
