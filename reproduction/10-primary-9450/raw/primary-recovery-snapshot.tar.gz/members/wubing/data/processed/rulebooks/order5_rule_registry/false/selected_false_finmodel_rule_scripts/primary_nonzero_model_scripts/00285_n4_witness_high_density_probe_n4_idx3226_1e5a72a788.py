from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1066,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":3226,"model_key":"n4_witness_high_density_probe|n=4|idx=3226","model_order":4,"model_table":[[2,2,2,0],[0,2,2,2],[2,2,2,2],[1,2,2,2]],"primary_rank":285,"primary_unique_false_pairs":1066,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx3226.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx3226","source_bits_payload":"eNrtmW1IU2EUx5/laht+2GSFWeHmJJcULR1E0dp0LLUiFlQDiayU3iTLUsqpsGWrZtO0RJSK2cwMeyE0LHKVI3vRKbkFElLRNE3DRTpHzLHd065EXzRy2O1DPL8PD8/lHPhznuf8771waAghLfoTdXpytdjnIsy/wLb6XWZTfMbUgPZ6J7eFs542NeIzHPfKjJypAcfgsY4jAtE0KoCWEOcY0wSu6X9utsrpCK1p+RUY1a1UKH89WYbjTWcOylMS6HPwlWEwGAwGg8FgMBgMBoPB/N9kmb+uNq972HPi5NsHV5xd7z80i3P2vbyccyGEAjGHf7z76PejhHdopFNm7m2d8KZDPRGRAWIqSvMZCNAYbQDAsX6BPPneMiKwZ3+OZlIgpq16JWvteOwZqSlmVzljXP0dev8V7wFdtZKK0kZF9kGNGoFsjMYvgy/FaD0/3wW8cjYlPUIeG6icACOlfnI7sYlcb3bPn0eBmAWAtavEKDGF9lSQMrAgMY1u5z63JVNRmgd2u8FggpzzIjcpNsJ6wfUCT7qXQ4Ua/A4GNWb7KBuXERPfhl6RZlMX5MBrojQOFlNiNqHLK5M+g6onelugNcMEoqQ0P4T3h9KoMFvgyFqqn6j74ZZo8vxuW0FTKyxp7KbEbPDICeFhMLSA11cDXz/auA3C71BTKGdSZLble8ISTsENui9QmSaWBnCKjmLoVIglvDt8u8NawppRcmqWSjWZ3rN9kXhH0orYl6uCU1vTEnC1nTtNhD6lSxysXXryJWCvKGO6BHojXycNclYBtVeJMuHMjs2nsYeayPT5rmUDdgC+tChIs/12VjNN995z6T3ZZLpRb+PGFiQxJ4K8XF9ItocXOdPupbHRZLolRMsAoHmCNduDXlVFZURn5v2m9J1bVPvv1L+pbohP3xh3dl9zamrj3ZjlYtW2Q13bIxrrFrbNuiOzc9Xy8FqhcljuHiBboFBRHp7opke5Lwpzo/Jd5BhLKmg38POLON7Z+4/YsNbPUw6DIY056NZITOXJUYGfBMZYmBs2iHTkXG5r+/XyZIDTHuasR2WWzk+XPijSCiuTn5/bfIKrHlPojCm9Ynm78Kk1ur9tqbn4cZ5ArqxzRkQNcGf/ZWM4RmUSLbDzkLYNRhGKRBIPsC0MCzAkyNKnyUOIjSJ9wHD8hV+9H8XZuFo=","source_count":3486,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmW1IU2EUx8/dmEPmNJqkabaokBDaDN/TWC8aGSXRG5m6HBmKWJouZy3dwJxFlmX0SlpKCKugEZWaTDcXiTBtkdgM5yaViQ63D+JWsz3tSvRFI4fdPsTz+/DwXM6BP+d5zv/eC8eNEJKhP5EhIVcB7xvC/Av4PWuv7+69Ozcgy4y2pti63HMjdPElhkZkmxvghlyOvWoyzKMC6CNR5pwncETyc/NE7UKoO+VXIED6tl3160kQ1Cs8c1Pd0un6jq8Mg8FgMBgMBoPBYDAYDOb/pi55aU/yqx0RF86vS83hRK1ZvVNfcyfhWM3JGQrEuDS/yCu+VwhGcGC0Jjl8sw+jHtKJ0bugp6I0upgAuYgPALaYZVCtbigiPHv78iEHBWKyvHjN5thtzMDsUnseZ5AdFiuh5TBuSXNVVJQWYOCFyBUINP5ucxEsK0Vd5io2WArtlPQIeWyg5AAEFtPIrc9zcj0UOfGVAjEBwHRTiUgnnIooIGVgvKPRxbMm8lupKI0J91kgFkLNKQOLFAuc3mhlgEXbYKNCDX6HkxqzrdL4aQifJcHxpNkU52pgA1HcB58oMZuRzdBoN0HeVgnf05qTJkNbIw3GwqbcVJjNc2QpuVsVYXDAMHt++2NAnmUsSYukxGywnQNjkxA8blmZDUtX8a0Hjb6QXal2UGS2/nuTnRVw2EX3VCYfcANUuNCgiwqxzrXX9sfGlEwvKLm5TqmcTY949Fn/sO3dQMIb79S6Uzyu5lnnibjmdAl3uklCvgR4BUUOtkkiMku1Xs4qIOsoUWRc2LHR5bwpIZk+wX4fygMwa8u9NNtvZzXzdO8etoRZS6aLJHzrwLk2h4+Xl0ufqWVaRhbavW47mk0XzMicAG6mt2ZLDVcW5I9GX9+1u/7BU+Xtfenrcw/21r/oO31nZ3Nz2t7Bfr3y8Y2oR6NpGV+SFt2RtRcV6rEsoypIzQolW6CyvXCsg+UaZp0wXhyuYpNjLK0pTmyuKrcxFu8/4uVrmkUVBOJGRwhLrhMWtg57fhKc/pMseGmQknO5J3GZha0AZ5mORY/KBNErjq9ub6zMb00se3bBqvBvl4pawvXqOOOWmKGwpA/JpduqTWpVBmd0ONS6+C+bkxug0cnAXo1kSRCA0AjSMcEucArAqUOClfJqhOxohA5O7l/41fsBhpi4zQ==","target_count":59090}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
