from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1033,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_yield_clone_derivative","model_idx":113573,"model_key":"high_yield_clone_derivative|n=6|idx=113573","model_order":6,"model_table":[[0,0,0,0,0,0],[1,1,1,1,1,1],[3,2,2,2,2,2],[3,2,3,3,3,3],[4,0,5,4,4,4],[1,5,5,4,5,5]],"primary_rank":290,"primary_unique_false_pairs":1033,"rule_id":"false.finmodel.primary.high_yield_clone_derivative.n6.idx113573.v1","rule_key":"false.finmodel.primary.high_yield_clone_derivative.n6.idx113573","source_bits_payload":"eNq9Wb1r20AUf7JUf0Bcu6ZDwA01wQGPGYopNCSieLA79U9QO6e4XUqn5oopXYPpH+ApdItJIBlS2vPSrbtKKFa3Di549OBWlU5yBt89EZHze2AJ8eT76ff0vu7pvWED8ByEsiOOXBzhrjja0cUabIsL2wxOc98ApXh+Sa2AgxyimF0ia/FL5B+wiymmmIK9wjRrmGJQR54LtjBFA1vLzmOaDEolBplIVGJDOiZCJVuVqESn+g8JJQIZjLLLirx4sszVlRWeiuG9S+Sd4FdevDFfiAkkMhNgBzRgEFEr0YB5EZpBgzYXYHs0YCwwIpWHBFHkj39ReQjAP//RZJsKjo+ffdggozbzu6fff26QBdufs4uLW0TB1j0fvSYz5OfjpusdEYGx85FcDVYYbDkAwmAjBONjgxANbYlWIl2TEMwzp3t0aDvwJUMGxkqEdsRb3ZXINyN3jwyRP/QYnU+uUyYtMAmZid6cTj7W++3NTaJ4Y/1WpdNqEVF72m/XCmSGfFIp1Mt3iMDsTu2dRUat0aH0yC3KMjqAQzo7xrMZqspWtsEgI1fO5Gt03B5TGtIGQmaQJ03/yZOY+3Ot3ZGXOIlxen+1Upsn7nsnQ60lnX1NQmPFM61JbdpM0g7lweCNZBfv+W4DvHW1UuP4a3FDQL0bY7yNzK5zcB29bR+6Gg+Bqvt6Kxs6CQ8bvue9F3rbSKzQ2JWCZe0PtfoIQ9vV9okRBFtTc2XDNMUHh4buYEPBxLi/6erds0Xur8ryiqieqJZIsQ97E728Y4WqqkiZitt+pw62l0iwLZUe2T/Z4jPLNdvIKLIUwSZHdUflnywFNStuS+Rg6xWVbqNjQOLIb1pRQm9aDBbjCkUubF7HbdJJbBrZaky2GlcWg0aKNtK4SlFLovjE11cVgzQb57iNlHMhk2fLCrcBi31KgfYfL761bA==","source_count":1417,"source_output_dir":"organized/mining_outputs/out_exp129a_high_yield_clone_derivative","target_bits_payload":"eNq9Wb1r20AUV+vBo6EeulWmhGrvlsXX0gwJtDhb6eQ/oJisoZheOpUurWnmVn9Cp9qDKUpIoIgOGQ0xwSU1ZCiuXQf8Ucl6lU5yBt89E5Hze2AJ8eT76ff0vu7pVeAAsAlEciSOTBzhtzg68cUlnIgLxw9PGSMApZjGQK2AvQmiyK4ha7E15B9wiClymIK/xzSXmKLcRp4LTjFFC1vLGWOaGUolAclLVBJD2j5CZdqVqMSn9gMJJQYpF6eLirF4stnVlRedhtG9C+Tt8NefvzFDiA8kkhVgezRgEFMb0ICZMVpAg5YRYAc0YDw0IpWHhFFkFO5ReQjALeM4f0IFxwqfd8/JqGWN2tOH98/Jgu3O1sbGP6Jgq20W35EZ8sm2a5kviMD4ZlGuBisMtgkAYbARgrFCQIiGtkQrkZpPCGb6uQM6tCN4PCMD4wNCO+Kt7kpkPZj8IkNk301O55MXlEkLfEJmojenk5ftSuPsjCjeeKXZqzebRNS+VBqdEZkhv/ZG7f4fIjCn3nntkVFr1Sk98pSyjJZhh86OyWyGqrL1HQjIyPVn4w4dt2+UhnSAkBmMSdP/8knMz4zW7shcOomxq7e1Usss3ffmS1pLOn+0DI0Pt7QmtZy7TFuSB4M3kkO85/sL8MbSSo3hr8WKAPVujPE2cnrBwLL1tn3oaiwC6u7rrWzoJDxq+D5VP+ptI7FC4/RGnrdf0uojHG1XG8+CMNhczZUN0wx/7AS6gw0FE+N+19K7Z4vdX5XlFVGdVy2RYh/2Nn552wpVV5EyFbfdTR1sH5BgWyg9sn/y+WeWa7aRcWQpgk2O6rrKP3kKal7SlsjBVh0q3UbHgMSW37SihN60GMzHFYpc6F7HbdJJYhrZaly2GlMWg1aKNjK4SlELovjEV1EVgzQb56SNlHMhl2fLCrcBjz9PgfYfHMK7uw==","target_count":61159}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
