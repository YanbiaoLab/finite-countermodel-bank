from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1015,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":14256,"model_key":"n4_witness_high_density_probe|n=4|idx=14256","model_order":4,"model_table":[[0,0,0,0],[0,0,2,3],[0,3,0,3],[0,0,0,0]],"primary_rank":291,"primary_unique_false_pairs":1015,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx14256.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx14256","source_bits_payload":"eNpjZGBgaGAgBJZ0sADJA6c4GUYBPcAEpS6NRQJOTBgSDVMvu1q22mBKMPw5uenX/h4JTImEv1+C/T72Y7HlPxjwY0os6IAyApyA8R5hyQhig1JAQaCfIsIkh6chUzRTgOINQkqjcTYKRsEoGAWjYBSMglEwCkbBKBgFo2AUjIJRMKyB5qIOJS5FkUAXxRalLo2WAI6FAk6KLU0KHEI0sCzhaQloHErvlOaTi6DRsCpFEX+NJ4ECT5xp4TXwwFrfjf+T5wqefvXfKMlwupvP3//+pxR5aGBZw9fL/pZH7Xe9WD7d3f6pyP8XTwP/LJ7g7viHn5EGtn34jwPU0yIg//2f7FuWpLV6zSOtvyBLrJJSj5zqEHWXYKWBZQf+/9/0Pz7u7/zwP8vBXvJfM+/G//+fTi6nhdd+TAb6SHbj///7ladd/Z965JEeyIfz5zhL0MI2XLH2n50Wme3vl8v+//vrfr38fxGUNH/Vi/zX+Bf44z9tMhsur8nTIrPhDEjmYZDZcAB+Gljm0KWxqMOJA8vskIADkECdrRB0FXECK28VANYYThocTQoKDA5QSRYibIuwjJ0SfEIZiwzIIgcUkQeL5jjJgZQvFnf62OIkx+pox0Ka3+o3rfmnr8yGTQqjSP5jHym5EaRcLDjzyJX//5dIHCI5s+GYq+HATL3ddVWVYOVxckftuSpFjvwXICez2ZObekkrbRqAjQPBVgHwvBY4CUAaCY4CLIoNGBEPbkOAlINTSEuAAIsjaV7bULRLY/kEd/GnIp9egJLAXoEudZFPGhyfFEEWNaBWFaA2BFi5fssjzlYbrqYaDg7ckYwts6VE/o13e/P/5KmO1K/1khtneCkv+/df/agAGwPGTN2P+k1GSSDlOssudaz8/9/TsIWRgYGJhJrt18vlcx7Jx365fHrx/KKu+i+fgMXxicUK/9qxRL/43y+fXoCU77XpqgcGQMd/RQXSajZc5QiWZPOA4tIGAA309Xo=","source_count":3980,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmU9I21Acx39tKcJK3WHMQqV4FLbOk1WwDEXwWHdwjIrt5uZhbgo6tpLRII0MhTFktx2U4p+DDia1bmxUZ9oOWW+KMjQe2lR3sG5BIwzNtLNZXiYMScNWR3aQ9zmEkN+PfPm93+/33uO9nCiKAfFPtBBZ6Vnr2Bcx/4OulI/x8vSRwhC4b59N+OeVBtFQ5TLWPcwoDcN60+R0cXceFZDZVRpuEccvU7SU94lEDr2jCngemmZ//ylmfdWxOiR9D2yncM4wGAwGg8FgMBgMBoPBYM40q14itcdyofcsmfIx5JRwk6dZsictbGsgNmx9hs6hlh2rpRXoNKyP5cJMaYgvndMiNPlg7UE5dN7ZqbwIC8HF9pk3egg72G8aiAXO2cOJmniDxd0eiVs5sFhDBk9XJGrYzWmgdh5UoLQYSB10vn4aXLneZFvRI5GPwUGng/gayRxqIFYL4IKRUX3rS4NbDincdLscwFzl1iK0ok4pos+NAHXJe5dg0GlbRhG2ts1ltFBTyxp816LZ9CZ7GLp7jSVQgUrTSHHA6EJFoE2zqYW2rkWzqQ7kjzPQbCrsaiAW8zFeghby3A7xMelx8rZiZ5ajZXc/L60YNCP0pNNi7NiY/Qu1icRYx2R1Mo8FCcVOfCnzttEbyN2zRReT9MZh9EO2sNgoV5NuKXmQz6SYkg3x8c1G5P5l8oXzMkBL5mrBzaZyVyMoq/dRb1+/7D66URPf6+ecwJ+m2eKnrd7CZpuAtDnY8fPyvZZcAr82CVE+ywYUiZf3EMhdrhByis9GCwvt2kAD4+6KbFk5swWVQD3vW+PMjGBmkVDg5FKB9hCy+xJp2/fP7/U8EQT1JOdrtqFx/cjMBahyEIPnqM3Gu2+TzTpYq+EPRMVNXRHlWggi90/NV4gbAO8WyZwoHhWwshlL3G229TGTvdLTOuCjTGZpOq72pHWP86R/S28yW5B7/byPkgaAADZd2MqmNo/kKZuyf55tfgI+jHut","target_count":58596}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
