from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1012,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":178264,"model_key":"dual_product1|n=6|idx=178264","model_order":6,"model_table":[[0,2,1,3,4,5],[0,1,2,3,5,4],[0,1,2,3,4,5],[0,1,2,3,5,4],[0,1,2,3,4,5],[0,2,1,3,4,5]],"primary_rank":292,"primary_unique_false_pairs":1012,"rule_id":"false.finmodel.primary.dual_product1.n6.idx178264.v1","rule_key":"false.finmodel.primary.dual_product1.n6.idx178264","source_bits_payload":"eNrtWUuOHSsMNYgBQ5bg7ARlZUTK2/cDY8CAoaoyyiCou2/f4mNsH3/rvxQ9xAi/AOA3QCw/CK58sR4hekxgwTkMecbnachfgs8f1gB4MKk8sjSBeZsFPsQ4GCOvyvtpKe3tc964ENt3W5/RMibMe+S0pc9yR4tB0IBQb5FP7BR8PTDF/sUgBOxbHN2cZzM/BngrlmuZKoLCis93QFr4I18rfxuzqWyzjRUxC3Vbl2GfBd4GP+myYpa3QQgRq1iR5FzuTrdOgf7PO0KTx8QKOFbAEDKzMom4LqisYFub5GH5N/EOb/J+T1pAWGi2kc9lECEpOpC0sa4oKo/5gSNV2qYGWk7cdpjU80O7IIKDw/CmQ4PYk1P5BwUzIJAkZLBsER/7OOK3QsfJU6soA7MV16PkxaxKjBUWpivZ8aURN3TaBrePo9p5s44q9YmTYYAa6r+NlJipLFA/6Rb3m0vYtEcqST/r/9khgCanDTYTwJ+HJUOt1pQgjpPI+wR4gE1cwTjsQUERO2kFa/RfuUqaD/z1RAOVyclLq1jz2+WMRDkqGIAHYzt62AiH08JqTUnTz83YFEe/G9v1oHlNvBlbJYTd3XvV2HosndUFm2Td4WopCEKuRx2jS22EyCuNdOKRQ5amoRwMagS2jcKeO3wcP+vldruvwSDO4jLNCewu/81gY1OcRtWQ59PwYGzLYQ+DU6IecMTOHTZPxtbYTHdjU6ZfwkaHxmEgEg4orVlMB1fpKrCJ9Gng4O53Y+uZ6Cx0ygfwCTbDE0i1xc+RrQSDFTY9rxN2jdA8upDsIZ6fU92iTdhh02RmGShdpW98pKUgIQLOFI7tHljq8rZ0AYitGLIHijHOCWnYjM3N3pAqAQWECo1ded4LQpnPeanfveEc2sMuuSgApKeRoXm9ZekutSW0SxoyY8Ul+CD/Ferx69KuTTo/TdqkpZNKjfCmbvE07h7ZtOpGKZ66sY2NHaSulwSG5XKMbEqRpYR2lUadrltawVXlYgeh1HMfVJNvTQAqjSYKyVeAa02oSE0RgEaji0LyZeFWmmpSUwSg0eiiWJR3qZDfwUajMQA0K+9WqL+DjUZjAGhW3iWNfAmbqyHMyvtnbP+M7W8zNmNK40lmd6lKWHk0ciQU8dqPXNbOhalSs536jLTT+ijiYBatepJ9kfjIxhoRRBnz49wzcS3x5xXm3GoAOOWwbGxxyuc5+TWemGGFIGgtvW+DjW20AEdxXggZ16HuRDJm4c/GsXGrPOoNIPXa/Qp4rDpixVMvpYY4M8cuva/L8A1rxzRS6ceS6rlWvnR/ZFMrvkwjRZ+7cTiyaVHCXNsJS956jmxWnoA9GcTH1ot96kYqLkrJx6/mdeiawLsGidfcwGZs9hNijpENzGSCc1fr3h88kzxGNqXdH+Zm05eGU6vZascDRyXPIFNa//tLDRhvG+LoaYSH1r+pFTBKGOw93BIM/Nd2/25sOPfn7KGHuxtbeof72diKi8pq60oLajdy6v2EP3DI3PovhOiFEuPfat1I7S3R19Z/UTq5x+ClqjU57C+RvkY2OjxLc20vOr2FTAK4ouISCGqDBMYLgLmrqgSvuFTW+J41TiMnQKRBza59LUs2wFjy8lJv5MrdyN1FaWguhChP4RBhVBoXqP4PyMoAAA==","source_count":2042,"source_output_dir":"organized/mining_outputs/out_exp120a_dual_product_followup_b","target_bits_payload":"eNrtWUuOHSsM3feLFFYWsZPnJTBkgMABY8CAoaoyyiCou2/f4mNsH3/rP2M9Wos/EfEHoi0/gKF8iR7QejAYMQRwecbnacxfnM8fMSF6TKY8ijQBeVtEPiQFHCOvyvtpKe3tcz4FZ9v3WJ/RMibMe+R0pM9yxwhO0EBXb5FP7BR8PdDY/iUBOuhbAt2cZzM/CXkrlGulKoLCis93AFr4f75W/jZmTdkWGytiFuu2LsM+i7wNf9FlxSxvQ+csVLECybncnW5tHP2fd7gmj4kVDKyAIWRmZRJxXVBZgbbWyMPyr+EdPuX9nrQAuNBsI5/LIAJStCNpQ11RVG7zg0CqjE0NtJy47TCp57t2QcCAh+FThwaxJ6fyDwhmUCBJyGDZIj72ccRvhU6Qp1ZROmbLrkfJi0WVGCvMTVeK40sjnui0DW4fR7XzZh1V6hMnwwA11H8bxjBTWaB+0i3sN5ewaY9Ukn7W/7NDQE1OG2wmgD+PSIZarcmgHSeR93H4ABu7gnHYg4IidtIK1ui/chUzH/jziQYok5OXVrHmt8sliXJQMIAPxnb0sBYPp7nVmoymn5uxKY5+N7brQfMaezO2Sgi6u/eqsfVYOqsLN8mGw9WME4RCjzpJl9oIkVca5sQjhyxNQzkY1AgcG4U9d/g4ftXL7XZfg4GdxZWaE9hd/pvBxqY4jaohz6fBwdiWwx4Gp0Q94IidO2yejK2xae7Gpky/hI0OjcMAIBxQWrOYDqzSVWBj6TPhwd3vxtYz0VnolA/AE2yGJ5Bqs58jWwkGK2x6XifsGrB5dCHZQzw/p7pFm7jDpsksMlC6St/4yEhBQgScKRzHPbDU5W3pApBYMRQPFK2dE1K3GVuYvSFVAgoIFRq78rwXhDKf81K/e8M5tLtdclYASE8jXfN6y9JdaktolzRkxgpL8AH+K9Tj16Vdm3S+mbRJSyeVJuFNw+Jpwj2yadWNUjx1YxsbO0hDLwkSy+UY2ZQiSwntKo06Xbe0gqvKJQ5Cpuc+oCbfmgBUGk0Uki+H15pQkZoiAI1GF4XkK+KtNNWkpghAo9FFsSjvUiG/g41GYwBoVt6tUH8HG43GANCsvEsa+RI2V0OYlffP2P4Z299mbCmVxpPM7kyVsPJo5Egg4rUfuWycC1OlZjv1GWln9FbEwSxa9aT4IvGRjTUiCDLm27lnElrizyvSudWAeMph2djslM9z8ps8McMKAdRaet8GG9toAY7ivBBKoUM9iGQs4p+NY+NWedQbQOq1+xXgWHXYiqdeSg1xZo6DeV+XwRvWjmmk0o8l1XOtfOn+yKaWfZlGij5343Bk06KEubYTlrz1HNmiPAF6MgiPrZf41I1UXJSSj1/N69A1wXcNEq+5gc3Y4ifEHCMbpskE567WvT94JnmMbEq7383Npi8Np1az1Y4HjEqeQaa0/veXGjjeNtjR03APrf9UK2CQMNh7uCUY+K/t/t3YYO7PxUMPdzc28w73s7EVF5XV1pXm1G7k1Ptxf+CQufVfCNELJcZ/1LqR2luir63/onRyj85LVWty2F8ifY1sdHiW5tpeDHoLmQRwRcUlENQGCY4XAHNXVQledqms4T1rnEZOgDCDWlz7WpFsgLHk5aXeyJW7kbuL0tBcCFGewiEiqTQuUP0Ng6dxNg==","target_count":60534}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
