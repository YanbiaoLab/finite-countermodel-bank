from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":1008,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_order_witness_tail_probe","model_idx":81734,"model_key":"high_order_witness_tail_probe|n=12|idx=81734","model_order":12,"model_table":[[0,2,1,0,6,9,4,10,0,1,7,0],[2,1,0,7,11,1,1,3,9,8,1,4],[1,0,2,10,2,8,11,2,5,2,3,6],[3,7,10,3,5,4,9,1,3,6,2,3],[6,3,4,5,4,3,0,4,10,4,8,1],[9,5,8,4,3,5,5,11,2,0,5,7],[4,6,11,9,0,6,6,8,7,3,6,2],[10,3,7,1,7,11,8,7,6,7,0,5],[8,9,5,8,10,2,7,6,8,1,4,8],[5,8,9,6,9,0,3,9,1,9,11,10],[7,10,3,2,8,10,10,0,4,11,10,9],[11,4,6,11,1,7,2,5,11,10,9,11]],"primary_rank":294,"primary_unique_false_pairs":1008,"rule_id":"false.finmodel.primary.high_order_witness_tail_probe.n12.idx81734.v1","rule_key":"false.finmodel.primary.high_order_witness_tail_probe.n12.idx81734","source_bits_payload":"eNrdWUGu4jAMtSMjmb8KqAeIUBccw4xmwZIjGTQjsezMCXrU32Ty9f+IplNE4sVYiFJF6avt9xwn/AQBkAtE6zF+S/oNBH/dhHSTbmkTGOYsbAO42RF03M0OsD/62QH5BoizI7d5CICBCgMKJSvNmNxVmR9BLEzi0rOkCF/yBHxXmKp9aWp+K3p7dKXkKn4dLxs/PGvezQvcpssRcFDo/lBECRrZ2XFMKx2c878m5xQ8tLPM3+sU9Y6hsQUZY94TUErnXry4Vmg9eR8lskO+M2pkVjMs0FGdh+0FXEAfuXFuGciBJBwC8HciyfxnwFZoN/cm0CcN0AineGmGBaJyjWKLpE/U7DW0FFvwOw84oSWxxU87uZ1wE2A/AolLVWRoK7ak6jCtgOqwtbR7pChtt0O8nyedCTSsJvojqdqHAyBzrvjNXPSdBjCz31MFMQMTBbcxQyu2RE1si0RmYOEIhtajIZiOlq4NZInmPtvo9riS+3UbDbBlHMGSkP/u66sagecc0PYxVU2clOU9XLWVLWcuBvRqIbYPIAOxyafYyEBswXBlK27U/wexWa5sX1xsX8B8jqWNi84ykGLKEduV7YS8EMu0Ma4otuI5Y7LrXauKjcPFbFHXaTeKZnVm8CJ2debmloBCXcLKfqmgaWV58HIIpW7dLD5NpX6BLp+Ep3QmtnI1YhL5UvFkIKkrODUtnt50W+AsO5X8/5Gsi6S8WGrOrhg1XpdKflpsYZUbMj7BsYXkhFXv/DJt6Pk3q3BAYtJzfRyQ2PRc2aWZQ0JZKc0nwitlDss6sT0TFC5yzT364ejFFuIdGTZC1g==","source_count":525,"source_output_dir":"organized/mining_outputs/out_exp109a_high_order_witness_tail_probe","target_bits_payload":"eNrdWUGu4jAMPWpPMNMl0ozAR2LJYjT4GCwqlANUkNXHElbs32Ty9f+IplNE4sVYiFJF6avt9xwn/FBUxb1GGyR+Y/qtrH/duHSTbvnuSOfM3ZyG2REJNM4OkD/52QH8rSKzI9t5CNWeCwOgJSvNmNwFnB8RKUyi0rOwCF/yRP1YmApDaWp+K357dKXkqnwdLxs9PGvezb1up8tJpQcd/1AEWBvZIVBMK59D8N8n50C9trPM390U9ZG0sTnsYt4TUErnBT2GVmgDex8lchXakEBkVjMshQ6C19tegxMfuXFoGcie0Z2d0i9mzPwnlVZo2/CGOiQNcKfHeGmGpQi4i2KLpE/UHMC1FJvzV68yoSWxxU87uR3l7vTSKWNIVaRvK7akajetgBCktbQH4SjtcBXZHCadoTasJvAzqdq7swpRrvjNXPQjODWzb1MFMQND0HA3Qyu2RE3sJsxmYO6khjaIIRh0lq71bIkWPtvo9riY+3UbDZBlHNWSkP/u66saq6cc0PYxBUicxOU9XLWVLWcuBnRnIbYPIAOx4afY2EBsznBlK27U/wexWa5sX1xsX8B8jqWNi8EykGjKEduV7Si0EMu0Ma4otuI5Y7LdBqqKjdzebFGHaTcqZnWm94h2dWYbloBcXcLiZamgQWV50HIIsW7dLD4NsH6BLp+Ep3QmtlI1YjL7UvEkZawrODAtnt50WxAsO5X8/xGuiyS+WGoOoRg1WpdKelpsbpUb2D3BsYXkuFXv/DJt+Pk3q3BAYtJzfRyQ2PRc2aWZQ0JcKc0nwotlDuM6sT0TFCpyLTz6EfjFFuIdM0ouYA==","target_count":62051}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
