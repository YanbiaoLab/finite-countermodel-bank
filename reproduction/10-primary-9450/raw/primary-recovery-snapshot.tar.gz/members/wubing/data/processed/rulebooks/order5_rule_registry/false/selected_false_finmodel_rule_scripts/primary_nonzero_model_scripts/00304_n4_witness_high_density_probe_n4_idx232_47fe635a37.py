from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":952,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":232,"model_key":"n4_witness_high_density_probe|n=4|idx=232","model_order":4,"model_table":[[0,0,0,0],[0,0,0,1],[0,2,0,2],[0,2,0,0]],"primary_rank":304,"primary_unique_false_pairs":952,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx232.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx232","source_bits_payload":"eNrtmc1rE0EYxmezlQ1UTEIK9iBZUw/xpCAIEbbZWlpyTMFzW/EvaIVCGgqz2ghNIyRQjyHSehEsePfiKIUGcgpYvG60BcFLNgZZa9zX2YmB2u2iEacHnd8hCTNDHt6P552FlRBCBvoV2xX3kxApgASnQAsY3g3jeT0K0XHJu9Mt3j3Uq2Hvhvl+gQAKnaCiIuQo9Hvo+MbTyvq1Bw/pj5lJujeavGDIRHZPLaBzR/5pwgwb0m1RLYFAIBAIBAKBQCAQCASC/wDwQ+EgZvqq8Qit6yemchAzfEOTOai14O0BXo6AbkWarkZ0PJ5rw+NyJsgjkY5faCEOYgQAz25XNevl3gYTud4EvRHdeZPmEZoN85+h/gw+rUOHqRX2ol9hPvVlhI/Z6ldy8Ue35qy8m1OsbebuWPnXiWDgHzDboq3GCCgazamrEUKxLigmj+5nZktOaEkT31NYRDcJYENBazwakppNMTEtnvwjpzJb4zFEemb7aYDh46H/bbP5IP3OVYEHNNsLzdIbG7BEh9UOTGVSY7WiDaXwYRB55Ew8u1Zlx0vB9pgDl/KpwGDRw1bFKSU6MH01775gmak9KacBVm1qNo9aFzeGN93jI+3L+w2Ai6n7dFUawGy9dzXOrmS+kkDWsgiFTNAR7f+z3u5dRFl2PIaIbNMparvLAzhlheZSpcXrJarfLO6NbZzxdK/OUq/2ayj9idlO8WZbWn6HtxLwcbKzX4BCdWWqfN4CNd6JIA5D0pm+8U3NfIDiXPCgQ8dxOR0vOaBYkSEOamS3aYAU65Zksio7SraFEB2YGBEFjXK42VjpDVZvAv3bjg3IYe/pk54bagOofQf/pvaG","source_count":3980,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmc1rE0EYxt811kViNhdBaDV7lQo5BVIoOl68CxW82GLI0UICpimY6g6UNFCw/QvEtmehOYaW2k0XDAiCnszBxg0eKjQkEQtZ7GbH2YkB2+2iEacHnd8hCTNDHt6P552FdQghGvkVE0n3EyGnSwSnQBgY3g3tdqwBjR3HuxPIPB3SEy3vhnp5GQFpn6BiEiJZ9Pvw+Mbd5MybRw/pj/UturdX+aTZyHZPLZMvP/3TttrSnOeiWgKBQCAQCAQCgUAgEAgE/wHgh8VBTPVV4xFawE/M5CCm+YZmc1ALw9VhvNAEXWlGXI3GTi0fgvupYodHIiW/0NocxBAAXptIGMrN0Wkm8joCerQxfq3EIzQZVs5D7A5cmIEgU8uONs7CSvncPh+zxd7law9erCo5N6fYmMo/U3LXq53uP2C2JdmsI7AMmlNXo03qAbBUHt3PzFbZNioqfmKxiF4iwJpFZnk0JDWbpWJaPPtHTm22xmOI9Mx2ZIDh46H/bbP54PzOVYEHNNstQ9Gj07BIh9U4bBbLu/GMDOnWUId45FS8Nptgx9Od0K4EH3Ll7mDRw2RSSleDsPE2575gWY/fS5UA5mRqNo9aAEcPptzj+6H3I1GAj+XHdNUZwGy9dzXSmKPecMA2CoS0VdAJ7f+v3u5dIgV2vE6QLdMpKrvLAzhlnubSpMXrJarfLO6NrX3zdK/OUm/2a+j8idlO8WZbXLiCJ6twcSs4koVsYn4z9VkBsxZsEg5DUtp4dcYsXoLMamc4SMdxqlRLS2ApzUMOamgsooFTD6RtNGdLViFMCB2YmCCL7HG42VjpNVZvBP3bjg3IA+/pk54b4gOofQdMy3qh","target_count":58596}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
