from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":941,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":32546,"model_key":"n4_witness_high_density_probe|n=4|idx=32546","model_order":4,"model_table":[[0,1,1,1],[0,1,2,3],[0,3,2,0],[0,1,1,3]],"primary_rank":306,"primary_unique_false_pairs":941,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx32546.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx32546","source_bits_payload":"eNrdWUFywyAMBA0HjjxB/Ykmpz5Lh/bfDeDYcUAUClanZTLJ2NiIFVppIZ+GTPzE5tL3+cJjvsDUQ0dPpaHUYazU4aWOzXClgfRKkDpYnJdLo9EQFBZm4pNjuAqF78+6QLn3mOctOQZ5cyoXUEiEAiWU/AMClMqqvXEbarlGrWfJaDavas1qGkNVaB8yodY3VoUWVK2BpjEy2EzFf5psrOhTzFECamS71zUy1mWfXppXOKSUnAqpvTyv/Guy/d/K9qaZknUrm9M0xuLiuevIZnUK7G+Qrc9rdg3ZWInz9tD/533HXgywFTYwSDapspXFYN4BymQjRZEZBmKNFpENu0KgpSG4b7q7Ie4q4vjnyEY9ZOtzmO8iG50ftcVqriBb69jCfafLxhRGlJFRr8ZjCuuCifqVE658ogHe7Dc3efviADBJ7lZyW+mKAIch3t6Mwz8MPXOgoqNxH7Rio3TF7dnQ6VGK8/YPWFlHc5mj98mVNqByDpReCgXZ7sgiGGP8fvOOrAwbmwet2ChjwduMCEzhtSJzCCdQJNnwo4V4LcHx5zy9QEYu3cPxJPTByga+Zcg6XFlOoenjxXsDavp4tUTw7eihtRFjpVrNtD5iUHVb4I5R/eUSgV9L1aV78OfKds4rV5wCiX8tnAXfGomwLc57HzNocv/gZa91LuUIOiuxoAKDcHIzMkTW6bAZOfrHebJpniaE0bQxVRE2SGC7Yh3m3EtiDO97nZdbM2osy8harEHXrbFzgS/AiT3l","source_count":447,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrdWUFywyAM/Hd70LN6yugn1RM4cmAEDeDYcUAUClanZTLJ2NiIFVppIW8BQ/zE5tL3+cJSvqDUg0dPpZHUEbzUYaWOzXClsfSKkTpAnJdLo+EQFBBmYpNjoAoF7s86g7n3mOctOYZgcyoUUFCEwiWU/MMClMqqfUIbarlGrWcxaDaras1rGiNVaO8yodY3UIVmVK2xpjEM1EzFf5psoOhTylHCamS71zUM3mWfXppXwKSUnAqpvzyv/Guy/d/K9qmZknUrm9M0BuLiuevI5nUK7G+Qrc9rfg3ZQInz/tD/533HXgyoFTY8SDapspXFYN4BymRDRZFpBmINF5GNukKgpSGgb7q7Iegq4vTnyIY9ZOtzmO0iG54f9cVqriBb69jCfafLxhRGlJFRr8ZjCu9MiPoVEq58osE27Dc3efviAA5J7lZyW+kKw4ch2N6Mwz8MPXOgoqNpH7Rio3TF7dnQ6VGM87YPWFlHQ5mj98mVNrhyDpReMgXZ7sgimBDsfvOOrAwbnwet2ChjwfqMiEPhtSJzCCdQKNmwo4V4LcHp5zy9QEYu3cPBJPTBysa2Zcg7WllOuenjxXsDbPp4tUSw7ejBtRHjpVoNuD5iSHVb4I5R7eUSAV5L1aV78OfKds4rV5wCiX8tnAXfGomwLc5HHzNwcv9gZa91LuUIOi+xoAIDaXIzMkTW6bAZOfqnebJpniaY0bQxVRE2SOy7Yp3n3ItiDO97nZdbM2osy8harHHXrbFzgS+L6DNR","target_count":62129}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
