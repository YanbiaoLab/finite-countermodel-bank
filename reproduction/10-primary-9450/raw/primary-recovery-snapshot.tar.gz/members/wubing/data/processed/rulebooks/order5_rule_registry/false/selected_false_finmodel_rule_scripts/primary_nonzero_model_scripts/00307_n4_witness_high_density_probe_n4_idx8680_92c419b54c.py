from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":939,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":8680,"model_key":"n4_witness_high_density_probe|n=4|idx=8680","model_order":4,"model_table":[[1,1,2,3],[1,1,2,3],[0,0,2,3],[2,2,1,3]],"primary_rank":307,"primary_unique_false_pairs":939,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx8680.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx8680","source_bits_payload":"eNrtWUuOwzAINRYLLzmCj8LROPr4MyaOQz5VM6vhVUork/oZeBCJQHgCDLlcuXwgOP4eRO0rcov7BOkGCZEOKdIv2RlyTVwxUPtbX+N2hXZjFrXa2U3TXrLYsufK4XA4HA6Hw+FwOBwOh+NfAACjaRAOOseSQK+QZTTmXw0x5XrhOrSiyvnCuBIxsjnn4kKCqU7RoNpRZ3BfQIgDmNuU9RSKexBi4UmvTN6oxEtMSyMCzIVWahTxBbYYz/JZtl9sVBa+yh2nU/XIwZsS9PiVa2k++V49YZ3HNir+ZMtDsVlEYRDRIpvDXvyEY0qO7sFrsYXthUCXY5WuKop2Hk/U8VxOQwigW+rEGpoqQyuAkUhrcG25B0uMtp8wbsPZ3Il2S8b8XP3gXYpzMMNNnUg922KgUcNx5EZEbHMkjewWCkNkOyKZ5b9GrROlWw7eNL2IrFv42JPoKDG7m6I8Lzb4jRod2z8/WMLmHT9kgy2neFJGV8VmuRVvi+3Zyexi++DJ9kHXu31LdPtkk6vGLqM8XgLFq8ZOL7/HjKeN3VCEeaIPnubcRWW0KK3jiYYNwlHmeCVSbQRot6it/ZOeXgNAu+ffwmEYB34AW8Mv6Q==","source_count":361,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWUuOwzAIPTpH4yg+AksvkPH4MyaOQz5VM6vhVUork/oZeBCJSH4CzqFcsXwkO/4eRO0rYYv7BOgGyIkOKdIv2BlCTVwxUPtbX8N2lXZjALXa2Y3TXrDYgufK4XA4HA6Hw+FwOBwOh+NfQISTaQDMOseCTK+QBTbmXw0phnrBOrSiyvnCuJI5oTnnwkLCsU7RpNpZZ3BfAAizmNuU9ZiLe5JT4YmvTN6oxAtMSyMSDoUWahT5BbaUzvJZtl9sVBa+yh3GU/XAwZsS9PSVa3E++V49eZ3HNir8ZMtDsVlEeRDRIpvDXviEY0qO7oFrseXthUCXY5WuKop2Hk/U6VxOQwiiW+rEWpoqcyuAkUhrcG25J0uMtp8ybuPZ3Il2S8b8XP3AXYpDNsNNnUg922KgUeNx5EZEaHNEjewWCkNkOyKY5b9GrRPFWw7cNL2IrFvw2JPoKDG7mzI8Lzb5jRod2z8+WOLmHT5kky2nfFJGV8VmuZVui+3Zyexi++DJ9kHXu31LdPtkg6vGDqM8XgKlq8ZOL7/HTKeN3VCEeaIPnubYRWW0KK3jiQYNwlHmfCVSbQRst6it/ZOeXgNAu+ffwmEYB34A8K5BTQ==","target_count":62215}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
