from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":895,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":320575,"model_key":"dual_product1|n=8|idx=320575","model_order":8,"model_table":[[5,5,7,7,5,5,5,5],[5,5,7,7,5,5,5,5],[5,5,5,5,5,5,0,0],[5,5,5,5,5,5,0,1],[5,5,5,5,5,5,5,5],[5,5,5,5,5,5,5,5],[5,5,5,5,5,5,5,5],[5,5,5,4,5,5,5,5]],"primary_rank":313,"primary_unique_false_pairs":895,"rule_id":"false.finmodel.primary.dual_product1.n8.idx320575.v1","rule_key":"false.finmodel.primary.dual_product1.n8.idx320575","source_bits_payload":"eNpjZGBgaGAgBNbMAZEHDjAyjAJ6gA//wQBTouHrZX/Lo/ZMmDJ/wDrsMSUevP505L+LPxZb4qer/1OvwmLWijldRq09QEaAEwsDg4SFTAPzAWaQRAEDHwM/XJnDA4EGxoTR2BoFo2AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAHgPy7ATgPLHuC0jRZe+4PLMnkaWNaw/vT//8K2P//XL1L3/+P/5YnyIZBVHAv7aeG1D7i8Vk8L2/7hso2fBpYdwJlGaDGG/QOXZfajmY0kUBP77//8FydBeaDyETAPyAuCUo07Ry0LLTIbTq8x0ySzXX9aXyn43/6j4EOQHcK2ilWf/s+f4M8xsjIbxaVNhP3fKcF/FnfXVVV+Cfb72B8nd9Seq1LkyH8BLKl30fw4ObDy6e4f+53kWD/as9Aus/2htLSBztX8u9764qQwqB7oUNB/9N/e6YUyttRbCkxAIOV2Sie6f/zvF/jFQWpmm/cDlNl2CcAy2xPXPzgy24f9ei7+YOXuLMBE/F/QSZ5xEGe2DXW/NJf/cBf/++XTi+VzHsnvtemqF/mk0fFfcehntutPO/93zvuznvviZND83SdBx7gj/+tbLrjTwms/dtl8tL84meK0RhwAAMnTa8E=","source_count":4976,"source_output_dir":"organized/mining_outputs/out_exp121a_dual_product_followup_c","target_bits_payload":"eNr79/////r/hEBwMoi0t//3fxTQA/AzgAGmRD2XzoZjVgf+Ysowg3UcwJSQF+G1Zti9AYstCzJuMN5oxWJWeHLp2apiIGP93t///z8//rj+j/0fkET//4//P8CV7Zd/X/9v/mhsjYJRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBSMAMCAC/yggWXyOG2jhdeYcVn2gAaW1QeYMDC8OcTG0BB7YwPzBm7pO7Ygq77HFdDCa/y4vNZAC9sYcdn2gQaW2eNMI7QYw2bHZdmB0cxGEmhexMiQIG4GygNtssA88OAdKNXs+N70mxaZDafX/tAks2lINbS9YzjA904OZMebQ/daeRkS8jd8H1mZjeLSZvkBpuw1zDElja1t3Gs28hUsfGh14Gvba2uG91hSb2zCwodg5Rk7+Ar2PvzFd+A37TIbM6WlDXSuhlGjStzsDageKL9/QZbhwF7xO9hSbxcwAYGUH7xrXsLOUPCe9TupmS2RHZTZXN/DMpv0LmYcmY3f4eLuDWDlO34DEzHDu70P/g3izObfyHotgn3HCyZuXvGIZNkHTodLG17zXi9nuDf0M5uGVBlDWSJzwBe9HND8He+7fQutGRqq9XfQwmvsrof5DujlUJzWiAMAgp4FdQ==","target_count":57600}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
