from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":885,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":510360,"model_key":"dual_product1|n=10|idx=510360","model_order":10,"model_table":[[0,0,9,9,6,6,4,5,2,3],[1,1,8,8,7,7,4,5,2,3],[4,4,2,2,0,0,8,8,7,6],[5,5,3,3,1,1,9,9,7,6],[8,8,6,6,4,4,2,2,0,0],[9,9,7,7,5,5,3,3,1,1],[3,2,0,0,8,8,6,6,4,4],[3,2,1,1,9,9,7,7,5,5],[6,7,4,5,2,2,1,1,8,8],[6,7,4,5,3,3,0,0,9,9]],"primary_rank":316,"primary_unique_false_pairs":885,"rule_id":"false.finmodel.primary.dual_product1.n10.idx510360.v1","rule_key":"false.finmodel.primary.dual_product1.n10.idx510360","source_bits_payload":"eNrtWUFywyAMFBoddNQTeAr5GZf+u4BJ4mmR44xhO+1Uk3hiiC1W7Epy8kGJKJV3MWnH7fPXk9hO2qkIKY2sfCfwcCZQsOGEchpPlOHxrYidcTJnnLI30UGOoSRyoDim3kRy3XtIyMy5NLuXdijCAygO1LCf902/3WsMM7XVxVhXaf0qoUWmlPLGRX/f59mdv9WbrnYWlW6VA7nGUF9R5apJiPeNMp/ckyznJt+8lhvPhNASG8v9oLRw85itKVYLKfOB6KdYuT2HruGwXAAlbtbljxAbN2rUUiIAsTX6N7FJWCm0jfIts4sSLUdGOVKhZGiqtuNCNENs9rqSTBQbGc5b7XsE5s1tiZbYDUDEp9iADCHglm2VDWiGdLZPiQIQG9IU6i0gnUG1VomhsJjmfUAFJDY9fpScJ7bHkxNEbAEDq0fQ/sX26yobNKY/VtkQbeQfrmzhKJacpgokur8zroAuJAmWZ8ozmwRYnjHJwDzDfOQowsSW6yuAxCYLlO+uPS9IMdFdPu8XE2eJDZg8MzR5GrRTYWSn0v8/SucimS6mGvWjpue2Ut8WWzwFI8U3OHawOfFaGljRRl6mzeMHEkjPZdCeq0PicIrrfC28yedwOie2d4Lii41PDb3XQnwCWoEiwA==","source_count":305,"source_output_dir":"organized/mining_outputs/out_exp123a_dual_product_exhaustion_e","target_bits_payload":"eNrtWUFywyAM/Hcv/Cw8hSfoqINGqIBJ4mmR44xhO+1Uk3hiiC1W7Epy8mHRLJZ3MWnH7fPXk9RO2qmIsY2sfCfrcCZbpuEEaxxPlOHxrUydcSNn3II30UGOoURzoDjG3kR03XtIjMi5NLiXdiiiAygO1Lyf942/3WsMM7bVpVRXSf0qsUXGFsPGRX/f59mdv9Ubr3aW2G6VA6HGkF9R5apJTveNIp/ckyyEJt+wlhvPhNASm8r9wLZw81SpKZYLKcOB6KdYub3mruG8XAAlbtTljxCbNmrUUiIAsTX6N7FJXim0jfItswubLUdmIVmhZG6qpuNCNENs9LqSTBSbEc5b7XsE5s1tiZbYDUDEp9iADDHglm2VDWiEdLZPiQIQG9IY6i0jnUG1VonBsJiGfUAFJDY+fpScJ7bHkxNEbBkDq0eQ/sX26yobNKY/VtkQbeQfrmz5KJYapwokub8zroAuJhGWZ8ozm2RYniEJwDyjeuQowcQW6iuDxCYLlO+uPSxIMcldvu4Xk2aJDZg8AzR5ErRTUWSn0v8/iuciGS+mGvajxue2kt8WWzoFI6Y3OHawOelaGljRRl6mzeMHEkjPRdCeq0PSfIrrei280edwPCe2d4Lii01PDb3XQnwC8fBOdg==","target_count":62271}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
