from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":876,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_order_witness_tail_probe","model_idx":115696,"model_key":"high_order_witness_tail_probe|n=12|idx=115696","model_order":12,"model_table":[[0,1,10,11,2,3,6,7,10,11,2,3],[0,1,10,11,2,3,6,7,10,11,2,3],[4,5,2,3,0,1,4,11,8,9,0,1],[4,5,2,3,0,1,4,5,8,9,0,1],[2,3,6,7,4,5,2,3,6,7,10,11],[2,3,6,7,4,5,2,3,6,7,10,11],[0,1,4,5,8,9,6,7,4,5,8,3],[0,1,4,5,8,9,6,7,4,5,8,9],[10,4,2,3,6,7,10,11,8,9,6,7],[10,11,2,3,6,7,10,11,8,9,6,7],[8,9,0,7,4,5,8,9,0,1,10,11],[8,9,0,1,4,5,8,9,0,1,10,11]],"primary_rank":318,"primary_unique_false_pairs":876,"rule_id":"false.finmodel.primary.high_order_witness_tail_probe.n12.idx115696.v1","rule_key":"false.finmodel.primary.high_order_witness_tail_probe.n12.idx115696","source_bits_payload":"eNrFWUmSwyAMNCoOHHmCnqKnkcP8e2xW2wiMwxJqKlUODtBStyQ0fxttx98xpP2MD1rtD7QJ+4B2htJrzMDShF2DHWpDzU74jZkBpbV0acKcznddVB4n4M6HmyFvDLpBETIuqa5Q3Lf7MczlN+Q2OoCaGxTYwmLIQqESlNwK3isS7obwUBivOShlryVgzx5mzjp1qKW7iZWb4Y0/c4eUet1mZqnX9NLdIEGU0zejFGyWiM1Fab1kw2KEnSM257lDcTBd5jJtND+AGeMCFy4Jlz8R25qxOrPhQls6sS3LbO2zZoTYmme7LW6q1YKZJzacL8WHzKaG1mWVzKa+INWLMpJaKNmlFlEEw15NusVGrcj6A6q7LlpYNzd9TgIQGF1rX6dabQ1UyWwQYWVCNvuHShD3ZdDBUzlebBRbyKOfbOpWq3endkgbXZHZjSBnlJIZp0UwOZysXrhlR7HlAZH2pWSy1r6MjpFM50yiZ7HZzCYhOUCaaLXABEjdCJmztl0WPrNRoMCtD4Ae4gkDPCpXP9zZogbsuxDWZjKbow3kZFENpCyXkR8mckA418W9EHDJNrG1WY0X250aVBMb2XpVJml7PjO0YaKNY+1LsYX2TNVqhJ2NAN/S4rimkth0jJTa435Bw/OSKqr6cLZIURicTc3JFaYWCqEhJYmVFTQ+xpnBd7Z1vSFTvIVa+nnoNAii1lRBfQRbGGhOqNp4cPVPVRubwbdJdQoaDHtorBbEdip/shJhMEXLnfAZd3DfjYRM5jPu4GZL7f9rFTWjXaLTRvjsHmCjvGj2a/FfC3jJIFAxLr4VGzFnUjlR6JsomztHtEV+1ZkgRMkWVIjRoiOQvWr9i0FiG5Jz2xskS1p3uho2zNfcq2Y2ph6nxjz4wrzkqnzVlvSosxpTCgtcg6av3tn2H7tgQis=","source_count":525,"source_output_dir":"organized/mining_outputs/out_exp109a_high_order_witness_tail_probe","target_bits_payload":"eNrFWUmSwyAM/PccwtP0FD2BIwdKeGxW2wiMwxJqKlUODtBStyQ0fxtsx98xtP2MD1LtD7AZ+4B2BtJrzMDShF2DHWpDyU74jZlBpbVkaUKcznddVB8n4M6HmwBvDLhBMTouqa5Q3Lf7McTlN+A2OoCKGxTawmLIQoESlNwK3iua7obwUBivOShlryVgzx5mzjp1qKW7mZWb4Y0/c4fWct1mYqnX5NLdKEHU0zeDFGyWiM1Fablkw2KEnSM257lDcTRd5jptND+ACeECFy4Jlz8R25qxOrPhQls6sS3LbO2zYoTYmme7LS6q1YKYJzacL8WHzKaG1mWVzKa+INWLMhJaKNmlFlMEw15NusUGrcj6A6q7LlpYNzd9TgIwGF1rX4dabU1QyWwUYWVCFvuHShD3ZdDBUzlebBRbyKOfbOpWq3endkobXZHZjShnlNIZp00wOZ2sXrhlR7HlARH2pXSy1r6MjJFM5kyCZ7HZzKYpOUCLaLXABErdCJ2ztl0WPrNBoMCtD4Ae4gkDPSpXPtzZogbsuxTWZjKbow3lZFENpCyXkR8mclA418W9FHDpNrG1WY0X250aUBMb2HpVJ2l7PjO0YaKNY+1LsYX2TNVqgJ2NAN/S4rimkthkjJTS435Bw/OSKqr6cLZJUZicTcXJFaIWCqkhJZmVFTQ+xpnBd7Z1vSFRvIVa+nnoMAiilFBBfQRbGmhOqtp4cPUPVRuLwbdJdQoaDHtgrBbMdip/shJhMEXLnfAZd3DfjaRM5jPu4GJL7f9rFTWjXSLTRvjsHmKjvGn2a/FfC3jJIFQxLr4VGzBnUjlR4JsomzvHtEV+1ZkgTMkWUIjRpiOQvWr9m0FiG5Jz2xskS1p3sho2xNfcq2Y2ph6Hxjz4wrzgqnzVlvSgsxpTCgtco6av3tn2H5ERLws=","target_count":62051}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
