from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":861,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":2211,"model_key":"n4_witness_high_density_probe|n=4|idx=2211","model_order":4,"model_table":[[0,1,1,3],[0,1,2,0],[0,1,2,0],[0,0,0,3]],"primary_rank":322,"primary_unique_false_pairs":861,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2211.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2211","source_bits_payload":"eNrtWUuO5CAMBeQFtUNzAnqUg6BRLfpYbmlammUfefgkIYCtopoEjUqDSi0lNPiD37NxPoUT4RcGxL/lg7bpYTFhxuUZYlhuQkhuQnMTq2BiKG6J4SaQ1Qvibu4ZU96QNQVoWd4U9HLAuDSb9fwVHWM3p2Jtyo93v1rJ1pQvp2pHpFNB8G+NI0wBzpSkXKW6hu1ZecP0phTvFtKLFw49VZqcKcxONe03D6jzB041zUyVpmYKc5k1Xg5sbzgVbGbi4Xmw+bzmhITk00t5BVMe2AXZ/2D7LtheN7NNBtvMATOFIXt4cB3Y5JwE+/KZDSdhXub6v7x3EBwNo+fAZ7ausHH/MtjMTEo2E3K1ON4JwdCXsgvApsvLp3khsKXM5iNF1mDzzj27ILIVqnUBtpLRzgBbf9vCjFYYAWyhXo1eC6EpYh/D25U6GkqL/eVa3lYOCJGsSW5rXWFUFoTryrD9JujIaGV5WzmAkGH6wdYXNgflWhmqH2xPhg0ho40FLZMgwmvN7aPU67EM3d8giZ2q0MfK4936/77BCNi4kRpmt+Or2zIIdFbRKCgakzX7CAsGWJSn++S15dSc68HGzNwWI+0H/BR38WfTrImks8pIL0jEBvMxbMJpDlyFeEZdvho3q9EcxCpK9GMDswg9EpKSy9W71xzgHjZhAQhhdwvvm7rYU9TYqdcCtht5Rc8Ea9K9tB4/ZrZyw85khymXVkmCOST20wKV7JgLiXiUWiuwEcRuWkJuP2r4re8pYN19i0nka1HNE7uuCTnK1swOXfQiOWJPOF5Kjl7BRhO66gUbdOUieQ7YSGKHGCiQaWb4QoLHeuDyHtfxA1pXOscBIlwdF4O6InbXyZtPpAPHBm/MM+rRq5wIeuqHVEZSrKW6LHuuRvkL16hYVQ==","source_count":689,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWUuO5CAMPXIvR5qR2sfqRWnEQaJpTjBiVywsYPgkIYCtopoEtUqDSi0lNPiD37Nxfjrhwi8MjH/LBy3Tw6LCjMgzxJDchLPchOYmVsHEMNwSxU0AqxfG3cQzpnwCawrSsrwp4OWgEmk26/k7OkZuToXalL8ffrWxrSlvwtSOSKcC6N8qQZiCnClJuUp1jduz8YbpTSneLaQXLxx6qjQ7U5icatovHlDnD5hqmpoqzcwUJjJrvBzYPmEq2NTEw/Ng83lNOIvJp5fyCqQ8sAuS/8H2VbC9bmabDLaZA2cKA/bw8Dqw2TkJ9uUzG0zCvM31f3nvIDgaR8+Bz2xdYSO+M9jUTEpWE3K1O94JUdGXsgvApsvLp3ohsKXM5iPF1mDzzj27IJIVqnUBtpLRzgBbf9tCjVYYAWyhXo1eC6HpYh/D25U6Gka7/eVa3lYOCJGsSW5rXaFMFgTryrD9JujIaGV5WzmAkKH6wdYXNgflWhmmH2xPhg0ho40FbZMgwmvN7aPU67EM3d8giZ2q0MfK40P6/77jCNi4kRpm9+Or+zIIdFbRKCgakzV7DwsGWJSn++S15dSc68HGzNwXZeU7/nE392PTrImks8pIL8jFBvMxbMJpDlyFeEZd3ho3m9EcxCpK9GMDszg9EpKWy9W71wTCHjZhATondwtvm7rQU9TIqdcCtht5Rc8EatK9tB4/ZrZyw85kBymXVkmCOST20wKV7JgLiXuUWiuwEcSuWkJuP2r4rW8pYMVti0nga1HNE7uuCTnK1swOXfRiOWJPOF5Kjl7BRhO66QUbduUiew7YSGLHGCiYaWb4QgLHeuDyHtfxA1pXOocBIlwdF4O6InbRyZtPpAPBBm/MM+bRq5wIeuqHVEZSrGW6LHuuRvkHdMkY4Q==","target_count":61887}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
