from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":835,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":3804,"model_key":"n4_witness_high_density_probe|n=4|idx=3804","model_order":4,"model_table":[[0,0,0,0],[0,0,2,0],[0,0,0,0],[0,0,1,0]],"primary_rank":326,"primary_unique_false_pairs":835,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx3804.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx3804","source_bits_payload":"eNrtmU9IFFEcx8fMIgosoiw8iJe8WbkHDakRjeoSS4fYhGxJqQ1Bt9gwEvXtwSDR8BARIjlEByFlNzVXcmlHIgVJHTuI5iYbhGvUTobTbM06M7/eG6HL7mKbTQd5n8Nj4Pdjvvz+vfeYSWMYxs2sx/Nxso68zWAo/4NpX7C23+KKN7glgR2e49PiLSrftIr0ffGGDyAJEHUmUAGDzHjDM6PcT8vbzpVuZZiiYUM572Zu/Upz/knrb7eRTwWP71wrPVOCndJo0SgUCoVCoVAoFAqFQqFQNjM1ftHn9w8t1N364euMTLxfeGlxOcJdrql0E8SML1qAdFgCgYUgr0AVhIFfhWIzQlN5HWvNAoAaE0GxOZd1/MyG0U4TxNwkIgAFOGBBdeKw2rVOgK+wbEZo3yAJyAw1kjawi3iZ1MijYierFx5sM0FsBKAF+IDqbSX5IwUru/QakDxjMyO0n0RB8AIum2yoGRGigLLfDLVkVYPtpgwbzh0eAAUHuKYiQUi/Z9aw5eEuQWMkm9OL6PaeqJN0TSFkp5sybMlI3xzDlohME8RKgrX+8amJHfGW/nmPZ77u/qOOnp66q562C662G+U1NlsNcZ85X2yxneo9NlaE35CCWhGoT1q17AQzvxcaGpXTWauFdnsktPv45QgKt6BAgLh3eg9HnXe7jkTZFGsL3pDOoYxEM+/lrLzGwmexXBsAGFWtGswK3cRdjvbq7wAq9e6/ONmS/KuR5EUOxFBDYx+SgOuDDryDxlaIeyAwh89AYQ52pThsaxtj4plfn9R2G7dvgfTBm2r/cHXwLG4Gz3zHi4LKyaNjVwYrKgbFQ7gZbOLExYN94QMfN9yR13WjD6wqzlpORcTIWtn3Zpy1PB1nrT1/LWu59a9SzlqiYbMbfQB80wktCmrPkEMWdMiSWBnsLEf+y80EB2IOgFaF27Lxk22J9IEKwuxDpA8hSR7VJ/GeqTvwhejLG+NCFKvENwe2Ciz/5mT7Q3I2rPYL37mygQ==","source_count":5531,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmU9IFFEcx38z407tNJLNFrkStNia4iHHPwga4Wys4ZraLhp4iBhDJKKDpBjkYZ+KkbTUKkhbaGwGtnSIpUtFiVNIelgrb3YRD1IWUUIRZeb03ghddhfbbDrI+xweA78f8+X3773HzKqu6359PY6WkrXiwLJO+R8UeJz9tbFAvMEvylplrrIab+GUrjTEvI837AVRBmswgQoYLMUbjhnlPj7adm/sh65PVhrKs5fnetM7Zx5Hf7tV7J4+eeHa2INx7LRKi0ahUCgUCoVCoVAoFAqFspkZcEset7squ+/SVk+zrXhf9uFYIGRvChSumCBmfNECxEAmyBo4FR6GwA5KGkyYERqnMFgrDwA4iwR8JJjB4GfNjr6YIOYnEQHwoIIGXBCH1co2A+yADDNC2w5JQGaokbRBWMJLEUse+TBZvXDmuwliFQAdoLg4bzvJHynYk1sHAQn5ETNC20IUZC/gsgmGmhEhcvHvzFBLVjX4Zsqw4dzhAeBxgGsqIjiYc2YN2yzuElRGslmQhS5+tAZJ10zBwoopw5aMlc0xbIlYMkFs3NnvLi0s/hpvqc3x+XL6zp5qaWjou+5ruxNouzI6EIkMEPf8uxOxyKP652WT+A0pqE0Cd6KdXUgw8x+gp5t/uJg2FQ7bHJ+e3bQhewdyuYh7s/eVNXi+6aVVS7G24HUwKlpONPNeNaqwGuySRtkagHIuykKe3EjcBWs9sx9gmGn8i5Mtyb8aUchSQXL0dNchEdQ6aME7qCWduLtcufgMlHPhc4rDtrYxJp759Ultt/F7skkflAy6Kwed93Ez+HJajkwPF70ou1E9MlItvcbNEJGKb7+ps7/ds+GOvMoYfRDlcNbmR2xG1p5s68RZm2Vw1lpn1rI213so5awlGraw0QegdD1lrcA1VIUEmYFFURMgrKnkv1y+s8YSAmjn1Z8bP9kySR9wIOedRkwVEoVypgjvmUwIX4h2lhgXIsswvjloQxD7NyfbHzK/YbVfbLi+pg==","target_count":57045}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
