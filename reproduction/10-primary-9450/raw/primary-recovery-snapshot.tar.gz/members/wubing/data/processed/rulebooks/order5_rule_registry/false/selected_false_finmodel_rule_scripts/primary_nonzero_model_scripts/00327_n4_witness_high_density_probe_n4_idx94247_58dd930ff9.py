from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":834,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":94247,"model_key":"n4_witness_high_density_probe|n=4|idx=94247","model_order":4,"model_table":[[0,1,0,3],[0,1,2,3],[3,1,1,3],[0,1,2,3]],"primary_rank":327,"primary_unique_false_pairs":834,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx94247.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx94247","source_bits_payload":"eNrtWUtugzAQtREL0pVBPYCxXCnHQMiL0FWOhCoWsEtRD5Cj1h5jzMckacmvlV8kgu3A2DPzxjMORhlGLnzx1jZC+Xl67NEuuNa7jvxTJHHc7hjLE9muazPy1vDWtgbYIi41WXJ5e1DaYuyslBdUuAeI/povp9RdJEumIxUKIjmuRxFGF6gihSst0S/VBsJQhjw8PDw8PDzWYlvoPEJmGZfmER4uvCKVwUKmBIlhHHcDdCMvoOQ68mry8FgPWS5CrVQIsWNNHcUxY0JEaUUbzpispkSlOyuSH6C0UtwUpqysaxKnLI/S0LKUmbJEPjIpPFrRCyp4rJ5Ur08rAoJU6CS6k+TrGb5vrSC1GCHg9RX5mNd6rmjTr0MIM/8+7sj5Tcrv96QXNNbaLayWFawXNNZaHzqdte6Vd7YMrDnWGsxrFKPt5OyDvQNJ4z/S/Y/aDxxaK8yGY63vcJsBEcyDVhUVCVxnMy6tzXc2O6+TMpbJ5nEtsmFrHg7+bKh/C7LdF3hpgNyEbEsIrncC2EMfrLnsCXGHlidW/2Oonc09EtFGBhO1NQyYvBJkUVuYkxUHgwvGAT1RdTueP11wmwANTxefOVWPcEgyVCpPIRnMPNTzLWExo/NY2QiN23S/swpQTaLa5QkGpWAYh4p0V0SnWsNoLMM4m0NGgDxuAxJoo4czg6ouINvA+rOYo9zrsmP9B+xsiwzt2HCmyzrsJYFta0IUvsfaNNl01AKO/x9UXRQI/CnIX0ojC7Zxk83xb6Uj/aJPvLZvHJ+BYQ==","source_count":1016,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWc2OgyAQftQ+wMbtTQ9m4yP1tPZAjI/RZAnyAJvKaevBAAtDEa3Ydlf7sxu+JlagOjAz3zBDhSyF9OEFR67Rqs/TYyO3fKl3rfAr2td1tCWk2Kt2ktiRjxhHrtXDTmKlyQyr27XWFiEXpXzJ3D/AzNd4OZnpYuX+dCSVvFHjZlQKeYUqKrjSTP5SbSBMljIgICAgICBgLna5ySNUlnFtHhHgw6fUGSxkSpAY1vVxgB7UBZScNEFNAQHzocpFqJVyhLYkTpq6JgShpkppjAlR1RRKTWfKijWUVpqbyJaVScLqihRN1TqWEluWqEdOCo8IdYJyXOsn9eurlIEgHTqZ6WTFfIZvIidILwYheH3K3sa1ni/adOtAyM6/iztqfifl9/u+EzTU2i2sVuakEzTUWhc6vbXuwjtbCdYcag3mNYjRbnLuwc6BlPEf6f4r4wcereV2w3HW97hNjwj2QaeKlHHf2YxPa+Odzc3rrIxpsgUsRTbhzIPBny31b0G2+0JMDbCbkG0KfLkTwA7mYM1nT4g7NDuz+h9D72z+kYbGKpjoraHH5Jlgk9oSmM04GJwwDuiJ6tvh/OmE23DZP1185lS9ES0rZaY9hZUw89bMN4PFDM5jVaO1bnP8nVOAbjLdzs4wqALDeFRkuhp6qjUhhzKss3lkcBlwGzBujN6ODKq7gGw9649ijnav6471H7CzTTL0yIYLXc5hrwlsOxuixD3WZshmohZw/P8gPUYBHk5B/lIamZODn2yefys96Rd94rV9Ay/h78Y=","target_count":61560}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
