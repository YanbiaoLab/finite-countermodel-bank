from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":810,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":40455,"model_key":"n4_witness_high_density_probe|n=4|idx=40455","model_order":4,"model_table":[[2,1,2,3],[0,2,2,3],[3,0,2,1],[0,1,2,2]],"primary_rank":336,"primary_unique_false_pairs":810,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx40455.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx40455","source_bits_payload":"eNrtmLFOwzAQhu3ISKZiuEIGRrssZkNVH8A1QWJBavsWvEUUBRSiDizsNPRJEBMbb4STtCRtQ9VIrWjKfVKGOE6iu/x/zmdKCPHJr+j86jQiSA4lxKl3xyyHDNIT52dsHc+dWCVg6rxl+tSN1Ri2EuPr/HMPDFs3T8wOBEEQBEEQBEGQXeHnfdhBYhtE23OJrCeHYgypi6yRNwZ64978n5qNZ40+K8YqdzQcTgpv5lsDtLitnFlY3UrYI7NBEcw8nvxkMQGlR9FCbXo1gYfOZRJ1W7I39GTYiVU44BMw8jEQ/LTxoeUbawPv7AU+VXJl5IM5eYBWIHnjQwMn891M7Lqk/wWxb6nWjrz2nWvUW2T4jTvMFBK+86M+sMYn8radRRR1WtJNPWC4VYh0WR92Y7Zx+qKvktmuZWjNhusEZF7FClMx61+6VGgXa5LeZI25pkLrWCXW1RW/iQr9W6uYbHpmEaN4IPY5kfep2S7YcrmvxOsNjyfpdHekPqwtxXmASvybygYlcXPCDig0rQVltlwL6hMqCFj3eKmf/SqzQbNi+wamz0YW","source_count":556,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmLFOwzAQht+IjQnxJCVlZ2GoQkSjKG/BW7SVWJAIrh+gqtjwQu2RIdAbULGEFRsnaUlKQ9VIrWjKfVKGOE6iu/x/zmdtjAnNr9D8asszSI42Jql3xzyHCtKT5HtsHZcTlzlA6ryldTV2WQe2EuP54nMPiFo3T8wPBEEQBEEQBEGQXRHmfdhBYhtE23OJrCeHYgypC6+RNwV04978n5pNZo2+KsYqdzQSaQpv5lsDuritnFlY3UrYI7NBEcwinvxkOQGlR+lCbXQ1gYfOk+ONZ3zUj7g/cZk/kG0g/DoQ8q3xoeUba4Po9QKOmfNIeJe8d2EWcNn40CDJfDcXOy3pf0nsW6q1vWh6GxN25hF5H/czhfin8nMIqvGJvJtmEXmTGY9TDxBpFcJjNYTdmK2TvuioZLYH7luz4ToBWVSxwlTK+lf/KLTLNYlussZcU6Gpyxzr6orfRIX+rVVINj2zCGEyEPucyJvUbM/qZ7mvJBr1P9rp9LjHTqwtxUuASvybygYlcUujDig0SoVWtlwLHRotDFj3RKmfwyqzQbNi+wKloisg","target_count":62020}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
