from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":810,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":48278,"model_key":"n4_witness_high_density_probe|n=4|idx=48278","model_order":4,"model_table":[[0,0,0,2],[2,1,1,1],[2,2,2,2],[3,2,3,3]],"primary_rank":337,"primary_unique_false_pairs":810,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx48278.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx48278","source_bits_payload":"eNrtWTFr20AUfrKMpUCEnJDBJaUOQoWMpQTTKRLFlKhT/kFMZwfaPeCDEEi2ELK1g39CyNBZWfob0k3dMqqbBhFVOokMunuOlJwfHfLAEvKz7rv39L7T984nmg8QGlDYET+G/Agb/OiXF6vwjl/4en5KMw2kFmW23AHZDHEkmS53hNkQuWUX+R5iZFrAvmG3rGKOuYsN9nYFcWxjY/km5uk8FkpanwWrMjzRkVB6nhBKeXJ/d+uecvD5Ta/uMPnMOg9X/E6r+G1tPpP806/GCjNuOpBYwsFmNGBQhmbTgEUlmkaDlnIwjwaMlaEZNGhxiUZUI/ccbEgD9kK2F7L9b2QjAqrIRggWUrF6sSRaDtlmhGCRHnt0aEdwT1eSzCbMIy51l2K/NON1TEa2DxHT31ChDSgXLdAZIbUnlJHBpXux5zgdIrJdjNeD8ZgotP08srNTkwjt83rgrq0R8dsPnDPXcYhC2w4oKxJt1Jdhczjv0qFtUOaR9X3QyILrd8wtRhbbR8pE+rBFiGZShvaIjMyyA7U9m724o/NUrmjpwuYw/atUQbCFzSE7/PmKrme7EjcGn2W7uOYbFh2d0iYrxCO75dsnSpUYLiN7gxCSP8ZAqYxEg47yeXip2jcbuhNeCL4v3w8/qdRhly62eBaCb3qtVIcxVK7uXa8UZFOqwvoomrVzruVke68SDQXj2/2jW1gC2VLJspyIxZrK0tpiqUmqlVIyzKb4jC3Jc79rTbavCNlqLVcsRNtOy8wrZknINhWeaDCSZKANXreSJSLZji1p2ajYIInEIomNJmXzpA2SqegaNSmbdlal5lh4g7Ebu0HZFK0RNA7Y1x6WqJpJ/uKTlA3AGLqN9Xy13FpC1lhvs0HZgMvu2I/GifwHySDnvg==","source_count":1836,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWTFr20AUVtCgrRqzVVvyG7JEc4fQn+Ch3ULIlkIJnCF7A/Ec3H/QqQrBFClTMKFkDFSIuDTUQ0gsFIhkLOtVOokMunuO1J4fHfLAEvKz7rv39L7T984fMxfATqCwA360+RFu+dEtLx7gkl+4aX7StQykZmmh3AFaF3EYWip32NoIueUM+R5MZFrAPmG3PGCOjo8N9uMRcVxhY7kx5pk/F4penwWrMtxPkVCmnhBKefLXZnVPOXhnc1p3xHxm86crfmdU/LY2n37+mVRj2Rq3FEjM4GBdGjAoQwtpwKwSLaNB0zmYRwPGytASGjSzRCOqkRUONqIBeyHbC9n+N7IRAVVkIwSzqVi9WBIth2xdQjArNT06tANYoStJFhLmEZe6S7GNLPllkpHt3GLpTyq0MeWiBSkjpHafMjLY9ndOgmBORLadwZ0zGBCF9iWPbO9DTIT29c7x7++J+O06wZ4fBEShXTmUFYk26suwDuzO6NBuKfPIJi5kZMFN5vE1I4vtG2UiXbgmRIspQ3tGRmraZ7U9W7i4o/NUrmj6wuZQf6VUQbCFzSE7evObrmd7K24M/pOd4ZpvVHR0SpssG49snW+fKFViuIycjm0wXidjpTISDdrK5+Hpat9s6E54IfiO3x+dqtRh2z62eBaCr7elVIcxVK6ebD0WZFOqwiYoWnSxm+Vk+64SDQXj2/3DdVgC2XTJsmyIxarL0tpiqTGqlVIyzI34jCPJc19tTbZDhGy1lssUom2nZToVsyRk6wlP1BlKMtAGb1bJEpFs+5G0bFRskFhikZhJk7L5qw2SnugaNimbdlalZl94g7HNsEHZFK0RNA7YzZ6WqJpJ/uKTlA3AAGaN9Xy13EZC1tj0pkHZgM9W2bvGifwDg1GJaQ==","target_count":60740}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
