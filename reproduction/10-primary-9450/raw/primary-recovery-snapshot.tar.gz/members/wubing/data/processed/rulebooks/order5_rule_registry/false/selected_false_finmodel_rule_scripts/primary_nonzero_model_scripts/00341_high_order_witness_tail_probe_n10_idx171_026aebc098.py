from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":807,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_order_witness_tail_probe","model_idx":171,"model_key":"high_order_witness_tail_probe|n=10|idx=171","model_order":10,"model_table":[[0,0,0,4,0,8,0,2,0,6],[1,1,5,1,9,1,3,1,7,1],[2,8,2,2,2,6,2,0,2,4],[9,3,3,3,7,3,1,3,5,3],[4,6,4,0,4,4,4,8,4,2],[7,5,1,5,5,5,9,5,3,5],[6,4,6,8,6,2,6,6,6,0],[5,7,9,7,3,7,7,7,1,7],[8,2,8,6,8,0,8,4,8,8],[3,9,7,9,1,9,5,9,9,9]],"primary_rank":341,"primary_unique_false_pairs":807,"rule_id":"false.finmodel.primary.high_order_witness_tail_probe.n10.idx171.v1","rule_key":"false.finmodel.primary.high_order_witness_tail_probe.n10.idx171","source_bits_payload":"eNrdWc1O20AQnt042FgI7CiHHqp2a7lSrr1xKtvKUu2eaF6gfQR6R8qChBq4NEV9AMSThEufI4+QI4cId3+cFOJ1hMHjQ/dgEybx59ndb+ab2TPCKUxdUONYX6dC3/qeuvKh/rADTH2gnMjbIg/BOmb5nt0A+YjYDbd5x26Y5q8rnvVeAlkNcwIsshnEd6AB2N5gx2P71mddxUTEVsvbbcIgsBgGQXpq/QW/8KBrtVxSP3GY3RUzoyVXihkuO7qj1wsct+QK17f4QwklI8aeAH1o8B78I4XEWT7r4fdI8e7CrJgenQDaGLcabAT9VtCMaz9bwZI00oN4raAtNNhBO64J49oPs8mwx9yg+e34dqfBvrYDtiSbIiBpjWxbLZJtr1WyvYP/lmxuO2jz/NM9ZIJOtnvIB+hkW7FawBEMsMm2kkSBiB0HmWyj1Z/9sZcik61j1kqHfiO8DvHQjuFO731/pZcE3mQqYaY9kpBVmrZBshVSVwqz2Qid2n+I+3Ju8gwHKUvYUvKhkG1/JjqvgCsAqY2p3i5oWuGFy4AE4MkrTNETaedUJmymp07XHahS+RuHG2KAptJFg4VGgN/xZRpFVG2SSdILQ9zMdpn0siQxNZSGxRyHEuJ87BkZmRX1F8NC+9zL4jDUxZomm6Yd1rLxLDqPo4gzU8wFGhSNbIMM2LacQukf4T1ssplCnSn/KAeGC3bFJzJTO2ruRGwmEJHcfU9V8xoopbQo1rGWTfS/JOFZoEH8AUMOkpPoYnAdfDRkK7omeJjDRKk5TrqxXK9lzEIj25BFXc8sVjeiyH2S1B8EodBAwS/qEOXWBFFGbpy1RaPV3Gxzcdhw9bHIuxusjujwBuHExuJQQPymyUA231gcXvGEN5lZKxu3ALtQaPXmZKQLYmw3jT1Z0aHISNv+CES120+VkdTbte8PBeRymcObS0DVnXCtvCpsT5eRjihefy14KsFXYXsy2ehJbM+aqpMvYlaohmZqnUlEKyJFty8DM0+WRX8jaJVHC7rdHw0F0271miJbVZS3zK+VDd0aDZLqKF9u9VqDQFqLbOp6BM66LrDsRH5kCdn1ZKRZPFH+XTm/ZoE1RTx+xHrSeeIHziPerHRKVL9BAkWDZN1U6pc8OxksD9CSsmelavH5yWDLoJyW+z43pU26D9QykTWyOj9Zhaj19bQc8XHLPq0TQ1O/Qq8KGq6fUP2Tt/f1UR3B8hccIv8Y","source_count":2038,"source_output_dir":"organized/mining_outputs/out_exp109a_high_order_witness_tail_probe","target_bits_payload":"eNrdWc1O20AQNsqBYx4hz9ELeZKKB6hoeoFUSLCRuJdHaF8gcKpdyWqXnrj1GqmWu6166CGKDULGwc7udH+cFOJ1hMHjQ/dgEybx59ndb+ab2UNBOfTnoMaJvvaJvk1TdaVj/eEGmPrAqZC3jhOBdfScK7sBnJGwG7adhd3Qd35WPOurBLIaugJYaDOQd8BjsL3BTcourc/aDQQJrJbvt4JBbDFMYu/I+gu6n0JmtezxxM+Z3RUzoyVXihkuO3qj1wvyeckVqm/BlxKKK4zdB/7QkD74hwd+vnzWw++J4t2JWTE9FjG0MbY12AimraAZ1960giVppIdIW0HraLCLdlwjxrW3ZpNhj65BS9rxbUuDfWgHbEk2RUDRGtnuWiTbVatk+wb/Ldnm7aB1nU/3kAU62e4hX6CTbcVqAqcwwSbbShLFJMhzZLKNVn9Oh6mHTLaFWSsd+o3wOsdDO4EtvfeTlV4ieJOphJn2SEJWadoGyVZIXSnMeiN0ar8Q899dk2coSFnClpIPhWyXPbL4BVQBSG3M9XZB0wp/5gxEDKm8Qh89kS6OZMJmeup03YEqld9T2BEGqC9dNFhoBHgV7HlhyNUmGfizKMLNbHv+zPV9U0NpWMxxLiEOhqmRkW5RfzEstI8zN4giXaxpsmnaYS0bdcODIAwpM8VcrEHRyDZxgd3KKZT+CTrDJpsp1Jnyj1NguGC7dCAzda7mjgRmAhHJPU1VNa+BPM6LYh1r2cj0zI8OYw2STBhykByE+5OX8WdDtqJrgoc59pWaoyIL5HotYxYa2cYszFKzWFnIkfskXjKJI6KB4tc8F8qtAaKM3DhrnUarud7m4rDh6qPjZBusOVnQBuHIxuKQQPCjyUDW3Vgc7lKfNplZKxu3ANdQaPXmZOQcyNBuGqayokORkbb9EZNqt58qI3l6bd8fCmhOZQ5vLgFVd8K18qqwPV1G5qR4/bXgqQRfhe3JZOPHgT1rqk4+CVihGpqpdQYhr4gU2VQGZuovi/5G0CqPFnS7PxwTpt2aNUW2qihvmV8rG7IaDZLqKF9u9VqDgFeLbOp6Cvm6LrDsRHpqCdn1ZKRZPFL+XTm/urE1RTx+BHrSqZ/E+SPerHRKVL9BAkWDZN1U6pc8OxksD9D8smelavH5yeDOoByV+z47pU16CdwykTWyOj1ehaj19bQc8VHLPq0TQ72kQq8SHq2fUP2Tt/f1UR3B8hcwXnIP","target_count":60538}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
