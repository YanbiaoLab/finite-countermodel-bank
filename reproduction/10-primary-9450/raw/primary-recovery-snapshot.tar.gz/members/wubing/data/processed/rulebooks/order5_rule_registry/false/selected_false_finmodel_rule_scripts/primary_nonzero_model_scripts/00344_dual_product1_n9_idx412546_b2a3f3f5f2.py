from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":799,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":412546,"model_key":"dual_product1|n=9|idx=412546","model_order":9,"model_table":[[8,6,6,2,0,0,2,0,0],[7,6,7,1,0,1,1,0,1],[8,8,7,2,2,1,2,2,1],[5,3,3,8,6,6,5,3,3],[4,3,4,7,6,7,4,3,4],[5,5,4,8,8,7,5,5,4],[5,6,6,8,6,6,8,6,6],[7,3,7,7,6,7,7,6,7],[8,8,4,8,8,7,8,8,7]],"primary_rank":344,"primary_unique_false_pairs":799,"rule_id":"false.finmodel.primary.dual_product1.n9.idx412546.v1","rule_key":"false.finmodel.primary.dual_product1.n9.idx412546","source_bits_payload":"eNrtmL9OwzAQxs/GgyuWJEIsDDhWKnXgIUyVIeGPxIgEA2JnZHelDAkTVB3aiT4DQ2fEk7CyMSKxYLulEpAEIhopqfwb6sFRv953vqtzAwxLRgGUIgD001sw24dqHMpNwvI2enFwF4YkRyvmWZdzWAUSCw9axcliPcL//y42zypxxPcdtFh/2O+YT9pkh3qxyezVbDJBAiztQN6bSnzbRRR0AhnHNaq9Xg/08v6CmWlci3O9Djx6z1x5eM4AyQ3VWl91c0ZA6io23aWTYJimt6HnupyHYZo6fYrqUOtmS6FhxHk/TFLqun3q1yE2VZF9Cm3HJizX50qsFitHgRHylNApz3RY2krqJ7UU20OohaLL7Iae7bkqrCdtpZ84thFZ1p/5dVboGrBmtAaBWEctgfprkTqBjousKRaLxWKxWKZB2ZXgYufYXviayEHprIeMbdKaCCsdhAhMxUrf2cCLcmeCAhAByqSecmEgzR5O5+Kon5+/Y2JBJsiV8ctcVbb4RM5H/zknIPdVv7Nm0bcVWWnSPybWsaKWG1VpA0U956/Q4irqFD79hbSC2gend0iS","source_count":593,"source_output_dir":"organized/mining_outputs/out_exp123a_dual_product_exhaustion_e","target_bits_payload":"eNrtmL9OwzAQxhckxm6sPAli7sAzlKkdKmAiGSLVOyM7YgCJEYk/yRAVPwRDpUaOGVgQSrKgejDxYbulEuAEIhopqfwb6sFRv953vqtzoxyWDCMoBQOop1+h+wDVuENvnJo2Jn50GIbcoOUTZ0oIrAKU4wRaxfVivc3//110nlWe4e87YrH+sD/Tn6zJDk18ndnTbr8vMFjaAdrXlbj5JBioBFKS16jWORmpZWMrp7pxLc71OrCbbBPp4QUFgd5la+2o5iyA11Vsqkt70YHrHoVJmhIShq6bjZmoQ23qLIUOAkLGoeeyNB2zuA6xnozsU+jF12GlMZFitVg5jLRQIoWuiKPCUlay2Kul2PZCJRScOcfs8jGVYe0oK2Mvs43Isv7Mr7NY1YA1ozVgQWdyieRfC1IJzFJhTbFYLBaLxdKLyq4E58839sLXRO5LZz18YJPWRGjpIATnDK/0nQ2SwDgTxCA4MIrUlCsH3uzhtJFM/nzzjo5F6CBXxi9zVdTiEzkf/RtOgPFVf7Zm0bcVVGnSP+DWsaKWG1RpA0U956+w4iqaFT79BbeC2gek+iik","target_count":61983}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
