from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":794,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":11786,"model_key":"n4_witness_high_density_probe|n=4|idx=11786","model_order":4,"model_table":[[0,0,1,2],[1,1,1,1],[2,2,2,2],[2,3,1,3]],"primary_rank":347,"primary_unique_false_pairs":794,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx11786.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx11786","source_bits_payload":"eNrtWb9PwlAQvpYK9QekwMCAiU10YHBwYuXFuJq4ujE6SOJ/wAvqP0DcHORPcHSzbk6uOhInNhkZCM/SYCSUK214fInEGyDl8vq97959d+1xS4LIM2hsVvApaN6FG1yIlP813KD51q0ZjCfD/E4XKcYhuBWU4xwO55DsvSzO0WE9HEWyKTEVk3NccUslu3SyYas863AnDo+h0nlJU6RNEevMsK9Phd1TtRbBbKC++jg0pVTpCQXWVeq9mM+D0IZKNT/3TQyYfCag9R+QaG97TRyYZyCpVc4PHRxa476RtlFgnSwykDfZKg5MElRsJSTaqEjrKjb2kWglBqXWhWakhQST0FNzoIE8RmaJgFKzaW3F5kKp3R0UcLGU7ZOCAZP3mQkVm7m5rmKrGP9i+4OdzUFmCbazQZW9zp2tGam2rZ7WQPNzxlVQ30XWGVlF1plFYtNbZ3KRQKNBBiQ2/73YS5dBYgtCWNf7csBmnBwDlS+1gvGT8LbtZ6N5qrWsWdHnKfWKjT9PH0hqntXwYgtGUF4a09mCcX/1QyvYZEAi4ilDLFlq7Kmozdh2PGm+JhabG4uGeDTi51hEeZ+TKs5OeGdHiXJ6ufK+8F+ihWJL8Zlp0HJh48UmYrVQR4/YWuGUDEdNzm0GCfq6+C1Rs+fphXdWX/JB9EdsoVoowy1UXIcDYMleArRvCfBSQQ==","source_count":645,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWb9PwlAQfoSBETcmw6irk5t1c/RPwMHN8A+o5PEfmODgyOZq4mrMY2VycGDQBBMZGIAG/FGwtCc0GEnbK214fInEGyDl8vq97959d+1xSorIcGlqtvepKOyi6V2o8eQr/UXhlq+5jGfI/E5XY8ahuBXU5xwm55DsvWzOUWA9HEWyKDEVh3NccEslu3S2YbvldzRnDoOhUtgbUaTNESv42Ffnwm6IWolglhEbWRyaEKJ9gALLC7Hd6fVAaGkhypvPDgZM7hPQskdItJ2XMg7McJHUGtePJg6tclwZWSiwwgAZyLNBHQcmCSq2NhIt1aF1FRv7SLQSg1LLQzPSRoJJ6KmZ0EDeI7NEQalZtLZia0KpnTx1cbGUxbuuC5P3jQMVm/O5rmJruP9i+4OdzURmCbazQZW9zp2tHKm2j5zWQPNzxlVQf0XWGVlH1plFYtNbZ/qRQKnMECS2yXuxMWqBxOaFsKr35YDNODkFal1qBeMn4UVrko3OrdayZkefp9QrNv48J0BS86yGF5s3gjJGmM7mjfvrW1rBZgMSFU8ZaslSY81FzWfv8aS5m1hszVg01KEbP8ciyntIqphvwZ09JMrp5cr7wn+JFoptzGemS8uFjRebitVCTT1iKwVTMhg1GdoMEvR19Vui/OdpBHdWXfJB9EdsgVoogy1UnQcDYMtcArRvQpAe9Q==","target_count":61931}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
