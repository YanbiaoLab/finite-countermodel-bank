from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":790,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":88296,"model_key":"n4_witness_high_density_probe|n=4|idx=88296","model_order":4,"model_table":[[0,2,2,3],[0,1,2,2],[0,1,2,3],[2,1,2,3]],"primary_rank":351,"primary_unique_false_pairs":790,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx88296.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx88296","source_bits_payload":"eNrtWc2O4yAMdhAH5kb7BMyoD4JGOfSxqLQrzbGPvIAJf7Fb0jbVHoZD1caBD3/Yxnb/glVgIY4/8dOCwR9CGS80DgRIOGkvURYm8D+YYVjJ5BiBmqS2lCABEwMfmrVAo8Sv2AkcKqiitJkr42qtNKmig66RAr+il2ow8cVPvy3/q0hdmCYWVSop4LTMYZZCmgbfcbOVNE2DpMHx7GeLqVYFJVcrDmGpaqAqToogjTTJRpXASscoqmLCTjL8ci4SwCW61aRMfAXw3RrTlEOx8M6hpneisfa7x0gH9qaBfv6mkWhU70FjA8IuQ5TYIouqOw3bAemdnY0JbbsMNsLu6GxEoN/P2RDI5HC/kzs4XQHJfOvsFFn0HZ9/7fhmt7FD6LRgWJ+vs4dXOhu5jR3MBp2N2sYOZmPqDK69YEfMxm51tsxat411ZkmYzbZIwN9skkth7xDw0M1GnCZFwLYjZW823fgAsEn26kg1TwV/sxHO1uzrPsb6MFUH1L7a1QQMARyGYtLIcdbcBoxp7Wx6G2t6HMOM32xUdUMUT9nZysRspFgQoRB5YW82osgirnYSA8U4BVCYeBEFyOXcxwBZ6xEEkBil0Ct6abhZExKsEQRQGJmKWi8Bt0pTijWCAAojU9Ed3o0KecxsKIxiQO3h3SrUx8yGwigG1B7ejTRy0GxuOkJ7eL/O9uts/5uzsanE1QrsY5VxNv7tD/lMzcZJjmcjrPiYq0cfJz2ZZ2oQyZWeHigpc4CvtLOL/zhpeDhhTs5GjLO5KFRGWOkUfALV0tvaIFEMNRHoIr9ghh/wXyUCZUt6rEHCNG49ELLWm02TQf3kTOgwoLPFuUQpdbp6/toVotm0B5YbDkMlAJtGEv3Y2NA9GxojV3XFgPQqb2XTyAgUWLM5R41AwdmChjjmjKEKRtXIVYMNEhGBWtbkqkf8ogZJBMqPljJu3bh+TYMkdkRbP8zOVnO1HOlIk4O92RbWRH36dIrQFaaVAfU7YG+2xFpjYTbfQTVGcQTZG2nX7bFsYNfnFCdrZ+v/1PBLzzIi23nZleMbSqn1TwT2YJExTtYxeoZVfztpp+hwRDkbEdht0Fadajsozpa5ckTZL+ydbiQR2AmLfJGzUYF9kgaXznbwvLOxgd1cQ5w8bmgpDjdIiMAeuI1/n60aJ3qoecU3SIjA7oK2wQfqdl2J2Wpk8fXNFr2aMAi9ROXmkfCPcgAoKTLdNOG6kesQFVeN3FYBER/lADWNYZTxD/se5S4=","source_count":1836,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWc2O4yAMfuQeR9qVymP1EI14kGqGJ5hyKwdEvIAJf7Fb0jbVHoZD1caBD3/Yxnb/gDQgIY6/8VOCwh/OKC9UAhxYOGsvMRJm8D+YoVjJLBiBma2WlCABEwMfqrVAo8Sv2AkEKmiitJlr42qtNKmig66RAr+il2pQ8cVvvy3/q0hFmOYWVSop4LTMYZZCmgafcbOVNE2DpMHPyc92c60KSg7SXcJS1UBVhHVBGmmyjSqBlY5RVEWFnWT45VwsgEh0m9mo+ArguzWmKoci4Z3DzO9EY+13j5EO7E0D/fxNI9Fo3oPGBoRdhiuxxRZVdxqyA9I7OxsT2nYZbITd0dmIQL+fsyGQyuF+J3cQugKy+dbZKbLoOz7/2vHJbmOH0ClBsT5fZw+vdDZyGzuYDTobtY0dzEbVGVx7wY6YjdzqbJm1bhvrzJIwm22RgL/ZLJfC3iHgoZuNOE2KgG1Hyt5suvEBYJPs1ZFqngr+ZiOcrdnXfYz1YZoOqH21qwkYAjgMw6SR46yJDRjz2tn0Ntb0OIYav9mo6oYonrKzlYnZSLEgQiHywt5sRJFFXO0kBopxCqAw8eIKkMi5jwKy1iMIIDFKoVf00nCzJiRYIwigMDIVtV4ObpWmFGsEARRGpqI7vBsV8pjZUBjFgNrDu1Woj5kNhVEMqD28G2nkoNncdIT28H6d7dfZ/jdnY1OJg3TYxyrjpPzbV/tMzcZJfk7KSXedqkfXs57VMzWI5UpPD5SUucBX2tnRf5w1PJwwJ2cjxkkdDSrjpBUGvoFq6W1tkBiGmgh0tF8wwQf4rxaBsiU91iBhGrceCFnrzabJoD5yJnQZ0FniXKKUOh88f+0K0WzaA8sNh6ESgE0jiX5sbOieFI2Rq7piQHqVt7JpZAQKrMmco0ag4GxBQxxTxjAFo2rkmsEGiYtALWt21SN+UYMkAuVHSxm3bly/pkESO6KtH2Znq7lajnSkycHebAtrrj59OkXoCtPKgPodsDdbYq2xMJnvoBqjOILtjbTr9kg2sOtTipO1s/V/avilJxuR5bTsSvANpdT6JwJ7sMgYJ+sYPcGqv520M3Q4opyNCOwyaGvOtR0UZ8tcCaLsd/JON5II7IRFvsjZqMA+W4VLZzt43tnYwK4OIU7+bGgpDjdIiMAeuI1/n60aJ3qoecU3SIjALoK2wQfqdl2J2WZk8fXNFr2aMAi9ROXmkfOPcgAoKTLdNOG6kesQFVeN3FYBER/lADWPYZTxD1FTi/k=","target_count":60740}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
