from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":781,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":1954,"model_key":"n4_witness_high_density_probe|n=4|idx=1954","model_order":4,"model_table":[[3,1,2,3],[0,1,2,3],[1,3,3,1],[0,1,2,3]],"primary_rank":358,"primary_unique_false_pairs":781,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx1954.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx1954","source_bits_payload":"eNrtWE2u4jAMdiIvzC7lBKHiIBnUBccKEguWHHk+2yktj76Zkd5o9BjFKirNj+04ie3PgUqhLbryvtBIb0QpPf5mYopf4ZWP9xKHsD/nsUQpfBMaYA050OFCUahSTGQGYhJKBBuKHCuVSnuSBOEhUtE+fT6j2HRkPJXKeikla//LjFq9XwU897BJ8u6Zk/x6kcEk5Oocm0orWR8bXq3Ufp06derUqVOnL5LskEdMf5imVI5RhyMvSAGxOsVuwEdGxJ4LCbFQqPScHT4nXJ7qlO1sJmiz5mj2qnNm1KlTpwUuGlbaTXzOlxsNYYwTy4HzhccINDVVb7ym6NAK4KlMdIPfKhJukgZMB74aQo4ATpg4knbnK2EKnUTBFz7oR+J6LxSYTNDuiJmYUYUORCaI92BnbCpgTSq42Irhqt7kqKAoNRm0yJiUwQBR6kILxoAZhGUdvTdB4ZiS+VsmsE+ZUuVU5Q4kiGUVwnxIMQNQuK3WEQHubgqzJnUcA+ks4K0cFURGQ2lQAB9wLolOMXDS0fiE6k1pJoecupgFcsIKQrsMnt6YtclmGBoEG3NVobE2hxfMlSV3YuXsgu5FgauIamUcDNt+sJpkCjlwG7HIwDo8+Eyq3kjNFLYuFxMdX3pks+2ZraZaFym0Yz82AY1gnHkjskHUqHpChu/3SUrB7kEVgR1YN49OvsQs//b453w3zI8I0gKORw01GSUPOGoKPY8bJYJipwB6h9XEVdRx8znKR7PXZmC1FtkwNLahEDRbzeweU4nBL9vKVtDKZAz4lefIxg3zH1qY4+7b/hK1QhtblSitizOPY/NcW3mpYvmW+suuv73kt4WeTu9CiGzqdLdgQb5U8/W4uRZIrt1a3wezIVZbhKa5+Mp+J82FptJ8qjggCTSXTaNf+UwLphBaytjxCYR0V/zWlDSBIs1b582et1qbrArPc9PGSWpJV2O14NT1oYg9EnTq9J+nkWcDYRv5QNpyOq9Q5Ruv7Sc9F30/","source_count":987,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWE2u4jAMPjJLFkjkWCwqJgdBJSeg2eGFlXg+2yktj76Zkd5o9BjFKirNj+04ie3PVWKULTrwLcoob0Q5P/4mYSlf4ZUuu1imejulMRaKvCeZYA26yvUohSRIyWIGYiHJAhsSXYLEIDehDOG1SNQ+fT6j0nRkPEHieikxaf/LjBC8XwU897BJ8u6ZE/16kdUkpOAcm0orWR8bXq3Ufp06derUqVOnLxLdkUcMf5imBC5FhyMvyBWxOpduwEdGxJ4LkTBJDfKcHT4nXJ7qxO1spmqz5mj2CnNm1KlTpwUuGla6D3xKx71MdSwD05XTkccCNDUEbzzk4tAK4CkOsoffilT3lCdMB76aaioATpg4inang2CKnEnBFz7kR+awi1JZTND9gpmYEUiuIiaIb2BnbAJgTY642Irhgt7koqAoNxmyyBiUwQRR6kIjxoAZhCUdfTNB9ZKz+VsWsM9JcuAcaAckiGVFwXxIMQNI3a/WUQDu9gqzBnUck+gs4K1UFEQWQ2lQAB9wLlnOpXLW0fiE6k1pFoecupgFcsIKJPcEnt6YtMlmGBoEG3NVtbE2h1fNlWV3YvHkgnZRgSuRamUcDNt+sBolqalyG7HIwDo8+Ayq3ijNFLYuF1McX3pks+2ZraZaR4pyZz82FY1gnHgjskHUqHpChu/3mWLE7kEVgh1YN0/OvsRE//b4p7QzzI8I0gKORw01mWQPOGoKPY8bJYJopwB619XEVdRx8znKR7PXZmC1FtkwtLShEDRbzexecizVL9vKVtDKZEz4xefIxg3zX1uY4+7b/hK1QhtblSivizOPY/NcW3mpYvmW+suuv73ot4WeTu9CiGzqdLdgQToG8/W4uRZIDt1a3wezIVZbhJa5+Mp+J82F5th8KjkgqTKXTYtf+SQLpiBZytjlCYR0V/zWlDWBEs1b582et1qbrArPc9PGSWpJV2O14NT1oSg9EnTq9J+nkScDYRv5QN5yOq9Q5Ruv7ScPafPo","target_count":61589}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
