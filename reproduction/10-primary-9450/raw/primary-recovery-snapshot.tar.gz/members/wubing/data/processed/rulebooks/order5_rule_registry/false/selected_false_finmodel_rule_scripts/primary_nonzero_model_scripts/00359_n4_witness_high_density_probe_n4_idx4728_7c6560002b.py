from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":781,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":4728,"model_key":"n4_witness_high_density_probe|n=4|idx=4728","model_order":4,"model_table":[[1,1,1,0],[2,1,1,2],[2,1,1,1],[3,1,1,1]],"primary_rank":359,"primary_unique_false_pairs":781,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx4728.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx4728","source_bits_payload":"eNpjZGBgaGAgBNbMYRgFdAQfPu96839iOKZEw/rTwv+FbRkxZZZ0GnVp9AhQxfoVc7qMWnuAjAAnFnzqFKB4FIyCUTAKRsEoGAWjYBSMglEwCkbBKBgFo2AUDHfw///pf/WVX+vjPs7/9x8I7DdWJQHF1Ocz0cCyB///H/kfH//v+tF/Z0GW/Z+vqP/o//5fr7Rp4bU//z//2r/v1v/pe2f+BllmvN8t7u//+FfavDSwrOH//9T/+/f8sl//wx/itQjbjf//P53sz0gD2z78v/60vlLwv/1HwYcgy4RtFas+/Z8/wZ+DFgEZ5mf/VOTzi0Xz3eRipwSfWCzu/LHfSY410Y6FBpYduPhUPrZjns1H/ouT1UuA3hI8+I/3onDLBXdaeM1D0FckkGNhhxGXokigi2KLE0erIJDJ4ihAC9s0F3WocSlOAVmk1KXREsCxUMApsaVJgYNptCAaBQMADpx/vem/e9zf+eFnlp/+J1/51W3NvBv//yedWM6AmQH+Pxf9/BKkfK/gavVv//dLfNIEipKQdH/ssvlof3Hy/1Jgrj7y38XfTulE94///QK/OBgwCskH9eBCAKi8n+OT0r//yi12TMRMeCFA5qIeJS5lkYsuqi2gCZYAj4UCzootTQnAzIZhm4tJIOdCsPIgjSPAbKkg0TSaOEYBdYGDo0KDCgOTBxNjAwOjCqOAAgMDS0MHByhRcwx1vwEAPrjc0A==","source_count":1767,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNr79/////r/hEBw8v9RQEfAz+MqzJC3AlOiPsDkDcObQ/8wZaLLzpZeL35PFevDk0vPVhUDGev3/san7j4Uj4JRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBSMguEOGBhMGBvauBoW8iUwMgDBAb/WuUCxGwl/aWCZPAODNcOCBYwaVoxGIMsYEu5dkGVwYBW9QguvMTPwsDo4qjJkOKWxgCw747BzIRPDAtErn2hgWT0DwywGB2fWAwHsGyBeW37Ij4FBKmfDPxrYxs+gIdXQ9o7hAN87OZBlbw7da+VlSMjf8J0WAbly4wGp1zzisQk7Hy7KXmMe82IPX8Heh7/mHfxNA8vs9aQeLCpPPMz3QS/nRjfQW+/sGD/pvanW30ELr21/t+n1uu9x5We/3nu9bve96r3fq94Bmb/3vaeFbddiy29+vZcNsuhu6fXq9d/j3u+dV117//vf0YJoFAwAsDcQ8WXYsZApYYVxhAnjgzauncGJ6gwMc80j/mNmAAaJVzxiIOVO70JucDI4POe9BhQlIemyux7mO6CXw9AFzNXWDLs3HLxrXsLOUPCe9ft/jEJSvgFcCACVF3znvcvIcKf64F9iJrwQYFps8d2vd17r7b5VDZpgWb897v2ee9W184GZDcO23afXfYsDK1973RqYLe8/rx1NHKOAumD/vvv1t///3f73X/3/f7f/vb/////v+vLvoET9faj7DQANyJRX","target_count":60809}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
