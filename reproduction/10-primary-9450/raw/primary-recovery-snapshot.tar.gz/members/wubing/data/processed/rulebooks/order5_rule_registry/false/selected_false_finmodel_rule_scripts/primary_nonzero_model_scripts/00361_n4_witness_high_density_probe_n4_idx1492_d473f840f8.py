from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":779,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":1492,"model_key":"n4_witness_high_density_probe|n=4|idx=1492","model_order":4,"model_table":[[2,1,2,2],[2,2,2,2],[2,0,2,0],[2,3,2,2]],"primary_rank":361,"primary_unique_false_pairs":779,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx1492.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx1492","source_bits_payload":"eNpjZGBgaGAgBLacZBgFdAQXtt3O22RcjCnRsPm8+a4ZexkxZZZ0GnVp9AhQxfoN4OheFdkT6MSCT50CFI+CUTAKRsEoGAWjYBSMglEwCkbBKBgFo2AUjILhDnJ3v922e/f2u2Xl37fNfnPmzt29xsXpz+YVn2OmgWUP/n8++7+8/t/95+/O2/+/vf/n7uT8Z//3F7+zpoXX/uz/97v+3/X////++fX2/8/w/Pfv7v/9b/+snpsGljX8B/ro//+f/+f/t///J///s//9f2f////u/3taeC1gm6dSZwfHJA8lpSRpzzNnOjoEBBWVnDgUWWhh262U275lbjqr377qSDWNlNy4wyv92akO1eMCbDSw7MDFp5yxHfNsFnJfnKxeolj1SdAxjuWicMsFd1p4zUPQVSSQY2GHEpeiSKCLYosTR6sAkMniKEAL2zQXwS1S6tJoCeBYKOCk2NKkwME0WhCNggEADrfzdp88d4YTU2bTrXXrbpVNnjtz9eqytHU9EcU9hZG54eG5IOVXQ62Nw93WWB6zIM02i981i7tvSmPJ88K/Q2p/uolvNo8PfXNWwDaxp/ZZZ+2qfSDls9drfUvrmGdwzI7EGilzUY8SlzKWArEjY5GQk6SriJvGkoAOYA50NGBxNQnkXAhSLhKkcQSYLRUkmkYTxyigcmbzVGBkUWDiUGhsYOBUYRRUUGBwAU3htgwDvwEAIYnOXg==","source_count":1647,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNr79/////r/hIC32f9RQEeg76ky0fdMD6ZEvY/BCdd0p3+YMtFlZ0uvF7+nivX+4OgOXVa8bu9vfOruQ/EoGAWjYBSMglEwCkbBKBgFo2AUjIJRMApGwSgY7mCSi5Cni4uHUmcHh2eKsLGyktOZnhmSiT2Gf2hgmTwDjxFDRwOjgoSgwQEGFQc2lzkTJBkcegSP0MJrzA6MLA2MGgwMTMysQgxsKyYICCowMRyQbPhCA8vqGYA+YmBgY0hgOMDAPIFBkqGAKYWBQZBBgBZeW++57W5Z+ffc7Xfvzn2yzdi4vPz9u3t3936/95sWtqnOVtnUufNyiJBo+axTy575uW+dIWlafsvi/U8aWGavJ/VtUXni4bgvejk3uu+18r7bt/C33ptq/R208Nr2d7ter/seV373673X63bfq977veo9kPl733ta2HYtFm7R3dLr1eu/x73fe6+69v73v6MF0SgYALBfZaKLmaHxN0wZX9XAQNXOnKS0kJDOmYHFy3uK+5ZNWrFiEki51qojZ1bsDD5meZw0246zNMeUqD3BkuffsKxuYtv5wufEglXCRu8PzStukixrCnUEKU8JuMo5szzxvOVBEmukabHFd7/ewVIglk+Pfbv32a7XO69Hry8H5sB953/vOr3uWxxI+eu1162B2fL+89rRxDEKqJzZtt3/9/v+3+/36+r/f7v97939+/93g6Zwq4eB3wAq96LJ","target_count":60929}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
