from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":774,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":93461,"model_key":"n4_witness_high_density_probe|n=4|idx=93461","model_order":4,"model_table":[[0,1,2,3],[0,3,2,2],[0,1,0,0],[0,1,2,3]],"primary_rank":363,"primary_unique_false_pairs":774,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx93461.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx93461","source_bits_payload":"eNrtWMFuwyAMNYgDvVn9Ah/2IT7us7w/nzEQkoZ0W1NVq+SnVlFDauMHNn4JwAwzpITwXsAxYYIE8YwtIjGT+5HwVSzb6JXNUXssZ4IycIWM+kgoHP7gJcZQudaPAM8dbiBSQ+XqYL1eOoM2L+wrmu8bUwsayjbSP7FG7etwOBwOh+Mkah/x2wNY+xx7XJy4fQc7OIVwS1BruBwOxzOSDQ/kQ3i+MxEuZi1/LwRobnNXJKJTyVv9dSrTseqp8AHYdWVeNNcNOF4g8TbuuFdi+a4mTE2UFUqlGIpLhbepLJLTWGgEpGqUF9dZb9Myk7SiIS1yj7k6kmIei3DtK4gWTLahdjN3WzyJI6w14UGQ7WSbsAbK2ieFEezByUaPqNRXoL0viAzEGvgqxEBj27Tdu39FwMaW/g52oRKpXdL0JUJNNmOtn2y3rI3dWxzhJgmGD/TC9TpossE82XTbgG2bPBJppIqs1nL5R19NHnlGAL6gbw6Rw9pG7Qw6e5w5HI7XQyu+pfD+PB8NnzVtVvLjKs1bYyfTLutfnGzHXe2+VGH2veBwPN5G1jJATVyMJMNZ0XkrfAMdfyc+","source_count":341,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWMFuwyAM/fP5s3b0h+zgL6h8KwcEnjEQkoZ0W1NVq+SnVlFDauMHNn7JgigzxMjyXuAxYZIo6YwtIjCT+5H8USzb6AXNUXssBJIycJHA+kguHP7gJaVcudYPCM4dbgBQQ8XqYL1eOoM2L+4rGu4bUwsayjbSP7FG7etwOBwOh+Mkah/x2wNY+xx7HJy4fQc7OJV8S1BruBwOxzOSjQ/kQ36+MwAsZi1/ryRsbkNXJKBTCVv9dSrTueqp/CXcdWVYNNcNMF0l4jbutFdi4a4mjE2UFUqhGEpLhbepLJLTWGgExGoUF9dBb9Myk7iiIS5yD7E6gmKei3DtK8gWTLChdjN0WziJI6814UGQ7WSbsCbK2iflEezByUaPqNRXoL0vSCiEGvgqxExj27Tdu39FgMaW/s52oRKpXeL0JUJNNmOtn2y3rI3dWxzxJgmGD/bC9Tpossk82XTbiG2bMBJppAqs1nL5R19NHHlGIr6gbw6Aw9pG7Qw6e5w5HI7XQyu+pfD+PB8NnzVtVvLTKs1bYwfTLutfnGzHXe2+VHHwveBwPN5G1jJATVyMJONZ0XkrfAMvAUn4","target_count":62235}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
