from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":771,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":60339,"model_key":"n4_witness_high_density_probe|n=4|idx=60339","model_order":4,"model_table":[[0,1,2,3],[0,1,2,3],[0,0,0,3],[0,2,0,0]],"primary_rank":364,"primary_unique_false_pairs":771,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx60339.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx60339","source_bits_payload":"eNrtWEuSGyEMFRQLvFN8Ai3mIFpk4WMxu1n6yEHi2xhmUrHLEye8qnGPu908JNDnYYAZZnAO2wMHLwDE+i/FGdt7xiIKHAfACwBbr/ZjGtG8yzXIx5mVyIMSe09BHpzBy0+Nus1/ymJtda8L0K0Drt4IIT9PBP16gZClx2Wkz9llhDgBCj1j57Uw3rj1Uv7b2NjY2NjYuBOpj/jNNkX6HP15+KpW/39wrWv1YEafHhuu1Orw7mY2Nv4s2EQrgT0BXCgFm03x9R7D8O2ags1ofF2jtDIqnjjmLTRQNU1SJZZdymY/FwomBBbxwhQ/TqRvZqlF1/jUoQS83pRxOWu4oGO3WC/4yIP6pa5UIvMGWHRllnyRCK5FiqnNLA7QyfV25EQk1sIPaO/PNaFxWZTJ8G3SKjlVk1fJqUSeMoevHKZwUPFomgIn0eeq3GNORCpcUYRrNfrWa0okkztyQOXgVJI69UmzyubOzWsuO+YE7kLJa+nmvLKVwaM9IZv7AaMS/g4Q6fJIBWHw2SzKWx7bcQRC9XRR8D4tjFc7jF5I3tWLG85eXHc2o14rlc0OXqvaXYl023DW/NA4+uVyMJbIsNPaI5EP2mqwHRoPaNumnq3cnGJhDQRblo2/POV5Csxzg+2ple2ZHg5BS+hMFlBOJiXJPwCInpbK4uG9sB3T2D+k2XJFLRX6mEKPtZ5bbZh7AmceG4LNNsLZZBZfNr4R2BqoIXxbw1caKm0mjsf4renqt8/fEUq83Gvo4UZmy3d7R8HwfmW5XSezeyqbnbualrngVTTbTg+v2UZKwpj0A/jytv0CFwxBEg==","source_count":532,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWEuSGyEMPbKXsxuO5UUWOsgsdAJHO7OgQEHi2xhmUrHLEye8qnGPu908JNDnERiAZ3CO2gPHLwCi+i/GGft7xkI0EAegMzN4q/ZTGjG8y9XIxwWUyLISW4tGHlzYyk+Dus1+yuJ9da8z3K0Drd4wJj9PBP16sZClx2Wkz9llhDgBND1j5zUz3rj1Uv7b2NjY2NjYuBOpj/jNNkX6HP25+apW/39wrWu1HEafHhuu1OrA7mY2Nv4s2EQrsb8ynzEFm0/x9R7D8OOUgi1ofJ2itAoqniDmLQpcNU1SJR5cymY/FgrGGBDxAhg/rqhvZqmFp/jUkQS83pRxIWs4o2O3WC94y4Papa5UovDBVHRllnyRiE9FiqnNIA7QyfV25EQk1vJPbu/PNWFwWZTJ8G3SKjlVk1fJqUQWM4etHKFwYPFomgIk0eeq3ANIRCpcSYRrNfrWa0okkztycOWAVJI69YmzyuYuzWsuO+bK7ozJa+nmvLKVwaM9Jpv7xqMS/g4g6vJIBQG22SzMW57acQRx9XRR8DYtjFU7gl5Q3tWLG85eXHc2o14rlc0PXqvaXYl020DW/Nw4+uVyPJZIs9PaI5EP2mqwHRoPbtumnq3cnGJRDQRflg2+POV5CsJzg+2ple2ZHjZGS+hMFmBOJiXJPwBEFpfK4uG9sB/T2D+k2XJFLRX6mEKPtR5abZh7gmYeG4LNN8LZZBZfNr4R1BqoIXxbw1caKm0mjsf4renqt8/fEUqw3Gtk+UZmy3d/R8GwdmW5Xyezeyqbn7sal7ngVTTbTg+v2UZKwpj0A/Tytv0CNXQwJA==","target_count":62044}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
