from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":757,"excluded_block_payloads":[],"law_count":62576,"model_family":"witness_residual_coset_splice","model_idx":121135,"model_key":"witness_residual_coset_splice|n=9|idx=121135","model_order":9,"model_table":[[0,3,6,0,3,6,0,3,6],[7,1,1,7,1,7,7,1,4],[5,5,2,5,8,2,5,2,2],[3,6,0,3,6,0,3,6,0],[1,4,4,1,4,1,1,4,7],[8,8,5,8,2,5,8,5,5],[6,0,3,6,0,3,6,0,3],[4,7,7,4,7,4,4,7,1],[2,2,8,2,5,8,2,8,8]],"primary_rank":369,"primary_unique_false_pairs":757,"rule_id":"false.finmodel.primary.witness_residual_coset_splice.n9.idx121135.v1","rule_key":"false.finmodel.primary.witness_residual_coset_splice.n9.idx121135","source_bits_payload":"eNrtWTFu2zAU/aLkii2CRgk8dCgaQVABH6FTwgQerE49Qo+Q7gFMBCjQbEaQA/go6tJz6AgeMxhRKVK1pZBUZZT86JAPWLJFiE/P/u//R/p7wADKGJq4kcdSHmEqj4zL0xGkzQdggTht6wCMUdXH5gGol5aBxzo0D5T1meWWc8t12FgeC/g32y1HYtA4sM5tk318bRmYiZfxJkYBqPEWEiWzQSqVRuXPN0wMVJqIYo2KOuWXGkogJ1kzbYD2pqcQPZtrF+l+LvGLyQgBJR4l2BIHDBS1YxywSqEFOGhbCXaBA8YVtRgHbaPQkHLkSYKd4YC9iO1FbP+b2JCAWrEhgpVYqh62RH7EtkQEq8LNBR7aDTzhpSTv1qvKu9iCnj/zHL+C+P0GTWyfKh5+wEJ7182QyDdayPfS5r7BvraMuHFV4Doe8vtFlhEksd3PT4v5HClHvghmdz8oEtrn0yI/OUHyI6zI7vIsQ6I2Kzo/Ye4brbtQ9y62Naz21SPxjTZtGQmgVeQ7VXjCIGjJibeeJZ4QmnK0znbVbGoBEMr0vQ33YuOpYKQ40alvNJqwdQtk2OFBtpFbp6u5anhxyN2u5rbD03Gnbp3/ZXGYO6U2vGZLhH1waYnO7UNvwbVXL+3T8WZF59FG9iJKuPP1QNjdeO0xa4AcWz37Trg0fI77+INtOiYNn9s+zomtVy9u3TuUhICleU6mK9WHHIb1rwXZDAhXXyVhxKHYTFXe0MKNapgcsEFir/JvRj0ALA4Tm4hrQ0YaLl2bis1BNlIpy1RItCtFYi5uoyOiikcywrH+s4fYbZDEnltob4PE8NSpe/fzSp1udR4/DUlqklw63lezYFeinpuDy1FZ2lwb3depSo0J0YunTo3oKs55ysebiN9Svcug","source_count":1580,"source_output_dir":"organized/mining_outputs/out_exp113a_witness_residual_coset_splice","target_bits_payload":"eNrtWTFu2zAUVeAho4+gc3SpjuIDBIG3FAgQ0ED25gg9QqfKg9EwmXoEAxUEpejQwUiYImipWqJ+JVK1pZBUZZT86JAPWLJFiE/P/u//R/q8ogBRDk1cymMkj7CRR0rk6Qmy5gPQqj5NggqMEQaP5gEIFpaB46A0D0TBneWWW8t1mFoeC8hb2y1P9aBxYJbYJvv80zKwrl/GmygH4MZbRMHWg1RCjcqfb1gYqDRR5BoVdUquNZRKTjKj2gDvTc+heDbXLrL9XPUvJqMElDiWYAscMFDUHnHAQoVW4aBNJNgNDhhR1HIctKlCQ8qRIwl2hwP2IrYXsf1vYkMCasWGCBZhqXrYEvkR2wIRLCynN3hol3CEl5KkW69C72Krev7Mc7yq8q9TNLF9Ckn5BQvtWzdDCt9oJdlLm/gGe9cyIsZVges4SU6XaSqQxHa6uo9XK6QceV8zO3vDkdA+3MfJwwOSH6FxepakKRK1ddz5CRPfaN2FunexzWC+rx7MN9qmZVQDzQvfqUIYhaolV7/1LHEmeEbQOtvHZlMLQHCq7224FxvJakaKE9/4RuOMzlogww4Pso2cOF3NhcOLQ+J2NTcZno44devkL4vDxCm14TUbq+2DS0t0ax/6Dq69emSfjjQrOo82shcFI87XA2V347XHrAFybPXsO+HS8Dnu4ye26ag0fG77OBG2Xr28cO9QmABL89xu5qoPOQzrXwuyGQiivkpBhUOxmaq8oYUb1bA9YIPEXuV/jHoAWB4mtjquDBlpuHRlKjYH2UilLFMh0a7EzFzcRkfBFQ82wrH+s4fYbZDknltob4PE8NSZe/fzS50udB6vDUlqklw23lfTaleinpuD61FZ2lwb3de5So2t0IunTk3oKk5IRsabiN/5tKWH","target_count":60996}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
