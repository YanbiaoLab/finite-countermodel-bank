from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":742,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":286348,"model_key":"dual_product1|n=8|idx=286348","model_order":8,"model_table":[[0,0,5,0,0,4,5,0],[1,1,1,4,5,1,1,4],[3,2,2,2,3,2,2,6],[3,2,3,3,3,2,7,3],[4,0,1,4,4,4,1,4],[1,5,5,0,5,5,5,0],[7,6,6,2,7,6,6,6],[7,6,3,7,7,6,7,7]],"primary_rank":375,"primary_unique_false_pairs":742,"rule_id":"false.finmodel.primary.dual_product1.n8.idx286348.v1","rule_key":"false.finmodel.primary.dual_product1.n8.idx286348","source_bits_payload":"eNq9Wb9v00AUfj6u4EAH263aBQnHckqHRkgMrFwjDwnhRwaGVCxRBFIHBv6EqxokR13SUBkGVGVkLF0YiVBn1LFjxV/AyBAR7s5JG8V3JVV8foMT52x/ee/e99535/eIAPRzwO2gwI9kU5y0xJGIIyyDK04IYh8DiEBq5w9s+QDc31lEpmxgu7KxHwQ4OUC2mnsFz5Pc8hwAS0FqETQM2QBFxJGiwzIeezhlPWwpXMlTLHfFNEB+DxHBkxlS/A7vRiPb01fQY6y4dTkewM70gDsa6CQ8jYPlGolwxn6MvYw/aXzttGuX1h8OeRoNbAIZ2J/hLf6nitGXMAO04fAum/QjjMDQD3Y+/B44tu2YbhaBHAy/1ZteCTIxeo84LIL1X6smVNl5w0Ma0X5/NBssJY23EDMQa/Xt5+oL3zLcXUZNbBHOF4N/1QPWrzR2WTa+7mwC5aXVwi6QmKMabH3LZ1W6VYw+hR2emp4XBGFolUwtbCju+d0wPOJA3bLnlYJWaNp2yczrAOsVvnKg6MzzfjgV4Zad9xiYlok7KHbrDGil+jSoN9ttc8leY6E08y0tZDs+WakGwVlzLzRfbdjcLR7KfMvSQrYb9TGXGzntheSvc5F6WDtYvyJYLWK6iHSjTUgixgFLM9qbdjEK4xb6qK69s8VzdSg6m/ZOelDgwSNO9WUwFob6Jo8uTXikPSUnpS5d0I32xKlw7ZdjPcalzDkTNGYlMVxePvx9DNRnOJatM1HWwd8ZKd4O1k7tBeFKR8hI7Sq5507ku6mdbD7HIsjQX45ZyncDDmRCJlZDcb3yM5GRJeaZBe5OJjKSmALIZ2tDsaxlwDpl5GVyWPqnbWKh7mjPlNEiG2XT2VoThNa+SKQWyaSCjBNDAPFMyYBsKMOePa74OJtAZjRfI3tMC1dN6gCl2VvV+4wizB+enQQpon3GD6/YiTF7uTTLJY1O+CpUieanWlxq0VmzHaozJd1UVW7cAl1jgu80SJVsW0gljNl80ZvpNqCxjJSHkPJt8xTr9IJqp1kAQTldGancCe8yWhCWrWmWmhYotj0JbwllplbAMBCko/2operVXBZxso3zJcXOJjG+3hG78CkyQFlv4+3+dCXe6P2RZElzKJnNbTRfqVmvXkRtKkfEUn+GPhhej2xylVVGxnQUiWtIis31ZaSEcUaShoY/ZxFTxtxVpc2cGyQiRkuzXH06J1otAlVKSqk5n92OMxrlVJovUaNniLh6zXZZoqYekkRDZRdm+FP/lZG55GPQncRzJS9G8bXI9g9+kahD","source_count":1374,"source_output_dir":"organized/mining_outputs/out_exp122a_dual_product_followup_d","target_bits_payload":"eNq9Wb9v00AUDsrAyF+AOnasmCsURpbSkTGqGMAqaZYqlkjV+xMYGCqBoiyoGRjCj5AMVnqsDEgoHUpjOUZiadXaHgox9Dg/7s5JG8V3JVV8foMT52x/ee/e995352cUAxSGwG29z494T5xUxRGLI5yAK04wZR95MEBqC199+QB82z6joWxgp72/YVkkOYB3a5t9x5Hc8g6ASEGaBtQj2QCi2JOiwwkZezhlRRIoXBkgIncljEB+DxbBkxlV/A7PRyM701egFaK49SQeIN70gDsaKCc8jYPlRolwxn6MvYw/UXzttGuXVsjleBrlfQwZ2M3cb/6nesZDMwO0XO4Hm/RVQiHSD7aQu2d5vu+FbhaBzOfuN2pOFzIx9B17LIKN20chtNh53aEa0W49CessJaMXEDOQaPXtztFbO4jcLUZNEmDOl4h/1QNWaNe3WDa+Ku8B4qU1IC7gmKMa7GDXZlW62jMem2Wemo5jWaYZdEMtbOht2iXTXOVApY7jdK2qGfp+NxzoACv2H3AgY9Fx7npt4ZY/cBiYlolb75UaDOi49cFq1CqV8NQ/ZKEMB1UtZFtZPm5Z1mJt0wxf7/vcLR7KQTXQQra/jTGX60PtheSGd5F6RDtYoS1YLWJ6RnWjTUgixoFAM9rLSs8w4xb6uaG9s8VztSY6m/ZOut7nwcNe6401Fob6Jg+dTnikPSUnpS4614320Wtz7TdkPcZFzLkQNGYljlxePuwNAshmOIGvM1EOwN4eKd4y0U7tc+FKWchI7Sq56E7ke6idbDbHwjTSX45ZypcsDhRCJtakcb2yM5GRXeZZAO52JjIShwLIZmtDsaxlwDpl5GVyBPqnbWKh7mnPlNEim2bT2aoThNa+SEQBzqSCjBNDAPFMyYBsNMOePa74JJtAZjRfI/uE+ldNap6m2VvV+4wizE/fL1spoj0iX67YiQmLwzTLJTKW+SpUiWanWlyaxmKtYqozJd1UVW7cAjpkgm/JSpVsu1QljNl8oT/pNqCxjJSHEPFt8xTr9Llqp1kAQSddGancCS8xWmCWrWmWmiootj0xbwkdplYgiiiko/1QoOrVXBZxso3zJcXOJjG+3hG78CkyQFlv4+3+dCXe6P2RZEmzJpnNHTpfqTloXURtKkfEUn+GPmhej2xyldWh0XQUsRtJis31ZaSEcVGShpE9ZxFTxtxVpc2cGyQiRqezXL00J1rTAFVKSqk5n/2KM5oOVZovUaNniLh6zXZZoqYekkSjHRdm+FP/lZHD5GPoz8RzJS9GybXI9g/N4Mjk","target_count":61202}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
