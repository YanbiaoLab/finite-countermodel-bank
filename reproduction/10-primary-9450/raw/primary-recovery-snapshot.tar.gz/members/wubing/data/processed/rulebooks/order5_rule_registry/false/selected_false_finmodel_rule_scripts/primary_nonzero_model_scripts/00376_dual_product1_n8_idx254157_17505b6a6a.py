from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":741,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":254157,"model_key":"dual_product1|n=8|idx=254157","model_order":8,"model_table":[[0,0,7,7,6,6,0,0],[1,1,6,6,7,7,1,1],[6,6,2,2,3,3,2,2],[7,7,3,3,2,2,3,3],[3,3,4,4,4,4,5,5],[2,2,5,5,5,5,4,4],[6,6,7,7,7,7,6,6],[7,7,6,6,6,6,7,7]],"primary_rank":376,"primary_unique_false_pairs":741,"rule_id":"false.finmodel.primary.dual_product1.n8.idx254157.v1","rule_key":"false.finmodel.primary.dual_product1.n8.idx254157","source_bits_payload":"eNq9WctOwkAUvdM2UgwRRBcuWDQEoyvXLoyMpgtwo5/gJ9QvYGJioisfcWmUT+nK72j8AtyxINQyRRLDXCxhOHdRaE/aw7lzXx3uhCSKSzSxhj7G+ki7+ijzkwoF+kSfjlJBRkvSqhmgtMwAw0sGiLk76JQDIg5QNxxS4YB+i9FI+9wthxwgfQ5xOGAwZU/mpLjcrVMp3hzQzz8MgvIrgZwD/D+P98n7/RoQb3GqzSWIDTVZD0NGubQqhizJ2QSGbaTJ2hgylVGVTkCLRoOM7eHRB7GNMy9+b4NWLe59lQlmWbJ9hKGHS7aP4T2ILGk/hyRQjnw7ePcDFJnakbgQyZKtBGQbp0CyuOcA2diRaC12gCRL3EEbx9agdxyZqiIdGSHJ6FOUGgNYsh0nQGl7yKJFrnJxZNfQGHltvXSaTVCdVC9hvRuGIGlXmTIFc+RFvevVUGSyHABj5LCLjMh9JFmfnjwc2y5SmqpJEjBxNccHajtHOlISMtmQbsze2RbvxIysTkfJ4p2Y2/TMJtto8Yhst6WrdHGmtay+qkb/9Gu7WX/KQ1tkOzdi3lFZL1dHqDHSq6nZLrq1MZJVNiGyvJnB74SvY+B7ZYtn3X4PUuyv7zg6TCx3Ng4Rk4HPcoywZIEk6zb9/8hU5Q1tKFmx1Bzni2cqy5vF+mBn6WSLTO18/lJgKjZLjZF5ZhVy0MrTtMfpWEfYzDZIIG/cEb9Ia7CNac6JIkFiTM0lup8UsxJVJCSp2LV/xkjhFJHhrDpC/ADA5IWN","source_count":1062,"source_output_dir":"organized/mining_outputs/out_exp121a_dual_product_followup_c","target_bits_payload":"eNq9WU1OwkAUrmHBTk5geg5XPQoalwZ1pYmJGU5gj+ARdCMsGh2MC9euIBLTBQsXimCMFNN2nmWKJIZ5WMLwvUWh/dJ+fG/eX4dTJYm8MU2sp4+ePtKrPsr85JNCfaJPS44io7nO0AyQM2KA8hUDeNwddMcBPgeIcw755IBql9FIT9wtbQ6QEYekHFCZsrtzUhLu1qmUeA6o5h8GQfmVUM4B0Z/HRxT/fg2JN8/RlhDEypqsjiGjXNoQQ+bmbArDVtJkLQyZyKjG96BFo0rGdnwUgdg2Mi9uvoNWzatvjQhmWbLtBEGMS7ad8gmIzG0dBKRQjtzr7EYhiky8SVyIZMk2BrJtOEAyr54C2diRaC3WQZK5SaWFY+vRLo5MDJGO9JFktK3GvQos2R5coLQXZNGiRCQ4sgtojOx3a83nZ1CdFLWg3wgCkLTLTJmAOfK634gHKDI5CoEx0m4gI/IJSValwxjH9oqUJgaSFEzcII2A2m6QjpSETDakG7N3tsU7MSWr05G7eCfmzLm1yVZaPCLbbenCWZxpXauvqv4//dpu1t/x0AfZzg2Pd1TWy8UjaoyMB2K2i25tjGSVTYgsb2bwO+HrGPj22eLZt9+DBPvrm6kOE8udjUPUZOCzHCMsWSjJuk3/PzJVeUMbclcsNQ/54pnK8lexPthcOtl8UzufvxSais1SY2SeWYUctPI0HXM61hE2sw0SyBu3zy/SGux7mnOqSJAYU3OJ7ifVrEQVCUkqdu2fMVKlRWSkq44QP4uN65o=","target_count":61514}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
