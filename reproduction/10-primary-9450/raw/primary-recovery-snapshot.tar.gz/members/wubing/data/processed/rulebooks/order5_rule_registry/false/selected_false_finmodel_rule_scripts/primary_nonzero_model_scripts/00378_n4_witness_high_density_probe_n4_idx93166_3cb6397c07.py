from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":741,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":93166,"model_key":"n4_witness_high_density_probe|n=4|idx=93166","model_order":4,"model_table":[[3,3,3,3],[3,2,2,2],[1,1,1,1],[0,0,1,0]],"primary_rank":378,"primary_unique_false_pairs":741,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx93166.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx93166","source_bits_payload":"eNrtmLFOwzAQhi9NKEGqoIQObERWpK48ACJRlSFFgvYFELwAO2wZG7G0ATEjHoLZAzMvwBImGINYGKqaOGEAWhdVdSxa3bc48ik63dl3/m0NPPgJXcuHxve5Gvwf9sGdbEivBH+E7w+gzxbCrTMQWFYkhtISGdJVUShasUanugT3RSg2rfw2mMCnKoAgCIIgf5Gy/Mxi7ESFtxF7yg70RE1olO0oTOQHaw5831Dk7SVy416vr8Zdoqdcu63znHIhc16qt6Ez6hCCKmZuHrc6e2+bz1GzCrVdyjWoDtWy7gT0goSZ9DTqHmSjCXWwgX8isxabkfKqrph2ccUzS/V27cQBIS1LSWhh7Ftt31eUyG6cp443LJt/lNsrDyyFe8Rrk8ghBItlsWhgCuTQAs2oF1WtoNhMO1zWRxXGdHXOErahMLRhfoRO5Bjg9e5SphAKp0YWnt1rJdzZkMVieqnhks4gIwWWILuDwOFNH2x5/bobiyz8DFpoaPE+MnS9sfZExxtWMqe37WLxdNzAUmSkZ2Em5uRI3GLk672vGguWUUl+AvwWTRE=","source_count":593,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmL1OwzAQx111YEFkhIksvAAzg2ceAjEjSLugdswGOy8A4gVakGiHqEoQD8BaKbLCxlBCQZUIJR9HnDAArYuqOBat7rc48ik63dl3/tsJ2PAT+pYNg+9zI/g/3IIz3aAdCf4wV3cgmi+EfbcmsHxIDKUnMmjvolCSfI3OIwnu81A8Gv82BMCnYkAQBEGQv9BIdmYRcqHCW4VspQe6riY0Sh4UJnKF9GuWFSryttFwjGazrsadHmlcu73ynHIhc1qqt6pbaTOGKqYw20/tu7XnzUZ/DKN7yjVoBOOy7gT0hJmp9AyHNqRjAEPwgH8i8xZbqPGqjgMvv+IFpXo7dI0uYz1fSWimYfkdy1KUyJaRpY43LI9/lNsrb3yFe8TusIbLGBbLYjHAFMihB0k4zKtaQbEFnrmsjyqEROqc6eRFYWjV7AidyiXA+t6xTCFkzozMPNtNSrizIYvF7FLDJZ1DRgos3fQOAtcHdfDk9euWIbLwM2ihofn7SNWxJ9oTnWxYekFvj/niRbiBpchI28dMFORK3GLk672vGusuo5L8BFBbJCU=","target_count":61983}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
