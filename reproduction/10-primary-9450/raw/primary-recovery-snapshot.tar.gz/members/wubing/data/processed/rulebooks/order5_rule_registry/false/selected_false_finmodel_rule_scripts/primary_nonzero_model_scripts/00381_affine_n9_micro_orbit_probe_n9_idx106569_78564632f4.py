from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":731,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n9_micro_orbit_probe","model_idx":106569,"model_key":"affine_n9_micro_orbit_probe|n=9|idx=106569","model_order":9,"model_table":[[0,3,6,0,3,6,0,3,6],[2,8,8,2,5,8,2,5,8],[4,7,7,4,7,1,4,7,1],[6,0,3,6,0,3,6,0,3],[8,2,5,8,5,5,8,2,5],[1,4,7,1,4,4,1,4,7],[3,6,0,3,6,0,3,6,0],[5,8,2,5,8,2,5,2,2],[7,1,4,7,1,4,7,1,1]],"primary_rank":381,"primary_unique_false_pairs":731,"rule_id":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx106569.v1","rule_key":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx106569","source_bits_payload":"eNpjZHBgQAVQvgiyGA/D4AFsuCQ+MOKQaBAg2ZIFKrgMY6SiV5hI9wqMwUwF6yGWKGBKcIBdxsQwCkbBKBgFo2AUEAIfGOlpG13rpgP/5elo24//zHS0ja6xlsBQQEfbahj+sY/mSyoAJwZGFgF6WeYwGt7UAQp0DdMpKpM8lJToVCw3THIR8nRxoVNACtA5s9EROHgqdaooKY1mlqEFREaDYAg2Ix2wDbUME/C/no6WPfjPT0fbWOjZgm7AmyIbcrdR1bYP/0cbyEMQ4O8fjkYp0ZkNpwwHLZqROLM2HXtXtAEHIGnuD5Zi+QBmgfWAQts4CETeKCCpZhvtcNOwGdlIg2YkJEd5TBqGAQkAcikhPg==","source_count":262,"source_output_dir":"organized/mining_outputs/out_exp106a_affine_n9_micro_orbit_probe","target_bits_payload":"eNrtmEEKgkAUhidatPQIHsV1p+gA4bZlBh0g6ALdQhcSHkQG20sYtLBQZ4IsKHQ0afzJeN9KfeDvvDfvzXsKGch3Hvfx67Oz/B2uKoMhFAYn6SwyC1UvExqXUnRfyvMi1yBfikRVQ3r/skISBEEQRBuGQKpBzyaLHYBqE5YD1aBR28kNUG0tRxfKSw3spcgSlFhA/tZDBPXpPLQ9zkFl2bH9o+v7IEcm4GQDErh8EXJOyTIsYnLBANvIoO5Xy5/AVkAxk52Aahmyg3Yad6SznWpVMxg1yAOkeT6kkH6cbEpL2kcbqUxt4HTVD1a558Y1ZdmqFizzS7W0JXhEp5ONBu4e28hlD21kmVGe/YeOvAHaSE/4","target_count":62314}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
