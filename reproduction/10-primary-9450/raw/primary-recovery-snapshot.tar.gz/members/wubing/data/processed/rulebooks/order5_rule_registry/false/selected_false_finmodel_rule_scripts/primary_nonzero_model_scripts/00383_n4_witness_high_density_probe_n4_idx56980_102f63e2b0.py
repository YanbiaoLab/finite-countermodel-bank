from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":725,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":56980,"model_key":"n4_witness_high_density_probe|n=4|idx=56980","model_order":4,"model_table":[[0,3,2,3],[2,1,2,3],[0,1,2,1],[0,1,0,3]],"primary_rank":383,"primary_unique_false_pairs":725,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx56980.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx56980","source_bits_payload":"eNq9WU2O2yAUxogF3mFOwFiuNMdAkRfOrHokp0olZ5dGc4AetY8HBttAbHfiQVU6CSYf7/97L7+JLokmuD7xVXcK3zSSK9hUPaGEkUbATokPMpJZf7M7b5fMxvu5ETq14YATi5KyIUTFGz9pV184OTOx2OjvmpSMcVUQAv8mZ6/MQOAFuHkpvCjNn1ZWlewU1bRgsCvgmHnwx615DAN8Y0GoURDpzTE6igKX5sTuUnvM63Dctd8Ex8gHXlbd/C5+E2jRSSA7OE2LqSgS/7trWS20Y0Xpg0CjnUAUc52EbX7gdZyBCd5oXJyF9+8F6sZcaq71Hr9TG0g6gn7Xei++Ey3rv0csZ7BvWp/oxt+0enDn0sXa8SubEA5ZJ1o0QigTFMtoev1ySdoDHSshpLY/bXtlcnCpjbjUdsjKZtgDgw2BMNHzMdEfF2wACEDKp/uDwqGXWgJQVxsg5qvOQZnFeQPW5gubxfwB6wNf1Y3VBAw4gbu3rxfQBVtz123PoACLQjlvpJ1SgT28LNgMF7AxQCtS05YMRFCi5bltO3Sb4mVuYznAvQWghyE7rOekIidyiNsoSB+WLLg6ACIoNRKvVbfRe4MNJbIxAHWgqoCSAQu0hGvVbYZhTybIVzaWorDR2qfePNVt6PIKqICFHerTHpP6ygb6u2sNJytkt1SgNQ1JJb2DTZBsFptU5FUBwRaAJKZjav7UDmgWbB5oG0ZsTF46IPf8/NF5T5Ao7eaM1hkMnqGRHmjxaKy1flUOnncg1YhMikJrxloT2zFiwvjZPLq6PmGKqm8Dr6q6blv+doWork3qtImlJlfTvUC2kbPSHvorXxJD3rENkd20enm0HujcVNVbfWqvA4AJBDI8xeRo+BPOSV9xn2PYbVQFXmh8Q34+AtCtMWJBaqgA7FdMiBCom5X2gNFOMEKjF+RCA3xID4Sky6ryKk4JQmQ5xCxHsxTG2G/O5EIPPNceyBQcYVUpTlyOhGjwWisNUO9lNV/DUxheFQvj5WlkghBZt5k3xQI8WZsLhIM6ONDceE9oZEJrTdybh/Y96aRz4z2hkQh0MVdm3jLxiMBjBHX7Iq+ImBnPz2Y8H6j8o2hNI0zvtWaA8HEdy1F5davgQHQRbHJinrmvJbT25WCjSDzOsa8h0KrbPA+EKNisRMgHKj3xZ+QDrw62MgCZMg3B5h59oDVnwZZQwMB3BVsRgOZak7HWEhMof7kJRj7YslQCCZ+ZY4XVGYpQsi/0bNmzsquppud28lHZVMWX5ht2sJZqCwzh69RlwLpm62Io8P9HmKGy0SIpHgAB4TOlgUIbwsnbk0HsdhqJfpBYqLVLUxPsPQrFxkBPs9dNKzu4ReLfxOMEmelwqg1XMMFmKkgVcb7m3rIdzcUm38nSyMQ8dkr0NjI6vZFG3jVxfMdLGOZE/rl2hdHx5YAkMwk/YiLjaCSNUpQrKuSV8wsXbAiE5MYXQQuEuX6k+9vauPVgK6LEnvgoEWzay76Jj2d/WkiM+3MNSQ6DZWInkdhF5/LkNEcvf9SAr45Csl8d/acSOye21Z/k6HMbN2J7Jic22BKJ3TZVzdRGiWDbN/3K/1aT0PyXA8FOI5OJ3ToKC+1n8leifaP/CR/gKwOSZQf/H5Ut8IG1AYn9XEuxNrx6NiAho1PPEruAzwq6yOBGARoZQ7hJvWMaea5NO5GQIqRO331A/FHsE+zQZqTIK4qfBZtJHz4XhjMJGgmOpIlWpS8RRRLjiZ7/AQ7UQa4=","source_count":2586,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNq9WU2O2yAUPmoPMEqzi6VGjY/U1cQLK+IYI9XycALMziwQpo8HBttAbHfiQVU6CSYf7/97L7806TXRuN7wlVQU3zRMUNikpVZa6obDTo8PSp1ZP7I7n7fMxse94SS14YATS+m+0ZrGG39U1d6Evku+2CjPRPdSCjpoDf8mZ6/SQOAFhHkZvCjNz5p1HauoImqQsMvhmHnw76U5FQV846CVUZAuzTE1igKXFtruKnvM63Dctd8Ex/Q7XpZe/C5+E2jRScAqOK2GqSgM/zsT1i20Y0Upg0CjnUAUc52Ebf7idZyBNd5oXEKG9x8D6sZcaq71Er+TGEg1gn7X+hi+Ey3rv0csZ7BvWm/oxt+0SnDn3sXa8SubEA5ZDzU0nFMTFMtoev1ySdoDHSshpLafdX2VrHCpTbvUdsjKZtgDgw2BMNGLMdEfF2wACEDUp/uDwqFkhAFQ1Rog6avOQZnFeQPW5pucxfwB6x1f6UW2Ggw4gTvXrxfQBVtzJnUpoQDzgTpvVBWlgT28LNgMF7AxoDrdqloXmitN2L2uK3Sb4WVuYznAuQagkyE7shS60w99iNtQSB+WLLg6ACJQOhKvVbche4MNJbIxAHWg64CSAQu0hGvVbYpiTybIVzaZorDR2qfePNVt1PIKqICFHdrHHpP6ygb6OxMCJztkt4qjNQ1J1aWDTZBsGZuU51UBwRaAGKZjZf4kDmgWbB5oG0ZsTNE7IPf8/NF5T5Ao7eYMIRkMkaGRHmjxaKy1clUOkXcg2vBMikJrxlrj2zFiwvjWnKq2fWCKai+F6Lq2rWvxeYWobk3qtIml1VfTvUC2YbPSHvorXxJD3rENkd20ejnVHujedN1n+6ivBYBxBDI8xeRo+BPOMV9xn2PYbVQFXmh8o/+cAtClMWJBaugA7HdMiBCompX2gFFPMEKjF+RCA7wzD4Sky6ryyh8JQmQ5xCxHyxTG2G/O5EIPvLceyBQcblXJH4KNhKjwWusNUOllNV8jUhheFQvj5WlkghBZt5k3xRw8mZgLhIMkONDceE9oZEJrTdybh/Y96aRz4z2hkQh0M1eW3jLxiMBjBHX7Ik81nxnPz2Y8H+j8o2hNI0zptWaA8HESy9F5ddPgQGoRbGxinrmvJbT25WBTSDzusa8h0KrbPA+EKNisRMgHOjLxZ+QDrw62PgCZMg3B5h49oTVnwZZQQCF2BdsQgOZaY7HWEhMof7kJRj7YslQCCZ+ZY4VVGYrQyy/0bNmzrGoVUfd68lHfdMOX5ht2sJZqCwzhq+itwLpm62Io8P9HmKGyqSEpHgAB4TOlQUEbIvTnk0HsdhqJfpBYqLVb02rsPQYqx0BPs9dNKzu4ReLfxOMElulwug1XMMFmKkgXcb7mXMsdzcUm38nSyMQ8dkr0NjI6spFGnol2fMdLGOZE/rl6hdGJ5YAkMwk/YiLjaKSKUpQrKvqV8wsXbAiE5MYXQQuEuX6k+9vauPVgG6LEnvgoEWzEy76Jj2d/WkiM+3MNSQ5DZmInkdh55fLkNEcvf9SAr45Cslwd/acSu9C21Z/k6HsdN2J7Jic22BKJ3TZVzdRGiWDbN/3K/1aT0PyXA8FOI5OJ3TqKDO1n8leifaP/CR8QKwOSZQf/H5Ut8IG1AYn9nDC+Nrx6NiDRo1PPEjuHzwa1yOBGAQQZQ7hJu2MaeW9NO5GQIqRO331A/CnsE+zQZqTIK4qfBZtJHz4XhjMJGgmORDShvS8RQxLjiZ7/AT2sL4g=","target_count":59990}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
