from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":721,"excluded_block_payloads":[],"law_count":62576,"model_family":"second_gen_witness_base","model_idx":169996,"model_key":"second_gen_witness_base|n=5|idx=169996","model_order":5,"model_table":[[1,4,2,0,3],[4,2,0,3,1],[2,0,3,1,4],[0,3,1,4,2],[3,1,4,2,0]],"primary_rank":385,"primary_unique_false_pairs":721,"rule_id":"false.finmodel.primary.second_gen_witness_base.n5.idx169996.v1","rule_key":"false.finmodel.primary.second_gen_witness_base.n5.idx169996","source_bits_payload":"eNrtmEFuAyEMRQ0iEs2KRQ6AuuoxvOgiyx6J9Aa9QY5ajM1omIyqJGyi6j+NGM0Alm2Q+MZRJdAjBDq1l6sNS0PRt45MhaWjNfIr1QF/2zrrTBmZftZ+cGI16ZKaf8zHWTLn5lbsofgeyJu6wp9E7/4uW8zkapoiuUJRgzK+KXK15qJ1vA6WbRZfI+VkacikIYdi40ofmwgAAAD4XywaRk7x09DVzr/j+s8xrA54MKoqUwtNPQxZo48mh9aI6rtOaphi0qSMMtTLQpbRM29q70lKj0jsbLSqWxRy56tO8BOhJYuI5QnbHHeV1vNQvxhbcpeoZUZb+HFFWla1vFk46D4FAAAAAAB34U097agoqZkG8V2y6uaZmk1UftO9wW+l+ua+1efJms1kpFyMX28i28hI/Zi5L3VahV5uKojC+yk7eOw+AAAAL8wvAyYZ2w==","source_count":219,"source_output_dir":"organized/mining_outputs/out_exp20a_second_gen_witness_isotopes","target_bits_payload":"eNrtmEFuAyEMRY+aG/QGDUfqsosufIyuKg6QBasEKQhcjM1omIyqJGyi6j+NGM0Alm2Q+KZwJfEjJD61V6kNScMxtw7PjqSjNfIr1AF/2/rUmTIyvK39oEBqsgQ1/5iPs3jyza3YQ8k9kIu6Ql/MP/kuW0RcapoiF8dRgzLeOVK1VqJ1vA6WbRJfI/tgafCsISdn41wfGxgAAAD4XywaRk7x09DVzr/z+s85rQ54MKoqUwtNPQxZ4+8mh9aI6jtMahhn0sSNMjTLQrrRs2xq70lcj0jsbLRqWRRy56NOyBOhBYuI5EnbHHeV1vNQvwhbcpeoZUZb+HFFWla1vFm46j4FAAAAAAB3kU097agoqZkG8e286uaZmk1UftO9KW+l+ua+NfvJms1kpFyMH24i28hI/Zi5Ly1ahR5vKghH+ym7Zuw+AAAAL8wvSVpXWw==","target_count":62357}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
