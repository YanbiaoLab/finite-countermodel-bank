from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":718,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_yield_cross_splice","model_idx":45412,"model_key":"high_yield_cross_splice|n=6|idx=45412","model_order":6,"model_table":[[0,0,0,0,2,2],[1,1,1,1,2,2],[2,2,2,2,0,0],[3,3,3,3,3,0],[4,4,4,4,4,4],[4,5,4,1,5,5]],"primary_rank":388,"primary_unique_false_pairs":718,"rule_id":"false.finmodel.primary.high_yield_cross_splice.n6.idx45412.v1","rule_key":"false.finmodel.primary.high_yield_cross_splice.n6.idx45412","source_bits_payload":"eNq9WbFu01AUPc9xiBFVY6IOHUCyqggxVLAyNQ+UoWHq2C18AoxIiD4qIRV1QRESaz6AIR/A4Ilf6GpmlowZIkz6bLVA3k0c5flcRY7sk/jk2Pfce/3yUWkgbeE6Du02tVvs2a0udnaQ2B27O88VnJHlbTeAYUsAZl8FID0XABxJwEQCzBsJ2ZGAcVfQiKYEPJbOpSMJCSRgWpJkS1Ka0ldLKeESMC7eHIKKIwnC/4Hon9NHtx9IIEea22iAEjNLdsYhQyGtzSHLCjbFYZtbsh6HzOS9kJUhCxflVz9ZGQL8zvNfCSlFkF4pPKRJm+XDR58uIp7Znr69T0r/bBh86NIu5LfL9+fL5bYusy1aVQye2VoA0WxEsmuz8UIciWqJewGRLGtMezy2QzzhiTNt5l2bMMnwQ7UeTGlmewZDmxCwzyxaaBCV4RU1R750R8cHByS/mVG/M+j3SdJORjq5S7uQLzuDBKx+o5+DNo4snpAHzIxsMpv2GJ9517Fcm2F1tlhD0cTFwcpFBs/xgnkhNVMZIqY0rFmJmXudjrLVKzHmu1dp71Y/Z/tt6eZsdafpei1qkzUJ6df1RzK0C9/eSOVRxCxeu6wxMozNzSq6tzFSVKaLOuO1s4kpV8fAtyelnO5E3icVI/76Y4v4TclYZFNh7N1sIllSw8BX/n/kqvKONpQ5p7XqbKfFzbt0rWZU64MXG5vttaudLx9KXMVmozGycFalWrz1NB2iernYOm1uFkgoT9wT+SbVEHdKz6kqSeK05galRqu/StT6lES1Y2vGSJVUkRFsO0L8ATAJf9E=","source_count":1031,"source_output_dir":"organized/mining_outputs/out_exp130a_high_yield_cross_splice","target_bits_payload":"eNq9WbFu01AUNcqQMQszXvsLTB74gAx8QFYkFLFUVEIqrwiJET6h2RiZSIeIvnRiBXVAKKoswcBQBacqqkMcv0P6bBVo3k0c5flcRY7sk/jk2Pfce/3yzGggmuI6Tu02sluc260udi4R2x272wgMnBEGEzeA3lQAmo8EINoXAJxIQFsC1GsJuZSAzkjQiJkEfJHOpVMJySWgVZKES1Jm0ldLKdkS0CneHIKKIzGy20D63+nTvx+IIUcU2JiDEk1LdsAhQyFtwiELCzbDYWtYsiGHTAXDjJUhCxcFO/dYGQLcCYK7MSlFEO0YfKNJawa9r0/3Up7ZPr36SUr/sJc/H9Eu5MPdF/vL5bYusy1aVQKe2aYA0WxEsmuz8UIciWqJXzmRLJy3hjy2U3zmiVMT5l1rM8lw30y/t2hm+whFmxDwg1m0MCcqwyE1Rx6PukdnZyS/qe5g3B8MSNLedXV8RbuQ78f9GKx+o49BG0cWT8h9ZkbOmE27gye861iuzbA6W6JhaOKSfOUig+f4wLyQmqkMKVMa1qzENLxOR+HqlRj1wKu0l6ufs/22dHWwutOMvBa19pqE9Ov6Exm6gG9vRPIoohavC9YYmSXqZhXd2xgpKtNFnfHa2cSUq2PgO5dSTo9T75OKEn/9kUX8pmQispks8W42kSyuYeAr/z9yVXlHGwqd01p1trfFzdt1rWZU64N7G5vtjaudLx+KXcVmozGycFalWrz1NJ2hernYOm1uFkgoT9xt+SbVEL9Lz5kqSeK05galRpt/StT6lES1Y2vGSBNXkZFvO0L8ARx38VY=","target_count":61545}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
