from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":702,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n8_boolean_micro_probe","model_idx":8320,"model_key":"affine_n8_boolean_micro_probe|n=8|idx=8320","model_order":8,"model_table":[[0,3,6,1,4,7,2,5],[4,5,6,7,0,1,2,3],[0,7,6,5,4,3,2,1],[4,1,6,3,0,5,2,7],[0,3,6,1,4,7,2,5],[4,5,6,7,0,1,2,3],[0,7,6,5,4,3,2,1],[4,1,6,3,0,5,2,7]],"primary_rank":392,"primary_unique_false_pairs":702,"rule_id":"false.finmodel.primary.affine_n8_boolean_micro_probe.n8.idx8320.v1","rule_key":"false.finmodel.primary.affine_n8_boolean_micro_probe.n8.idx8320","source_bits_payload":"eNrtWFtu5SAMBYsPPlmCl+KlMTsf3rbBSaSq01bTuFKbXm4wHHyMff5ktyy4RM4R1SfLqPz4MhhSLP9BeYzOt/eB3MesTJSq5/IrO+if5e4L6x/MY7Q4hoe5Ul9eW7wPc/o6YR5PZdRjczh3HFzdcRkNbXTA8O2WEmGHFRvOdfn4wbmwbnCDuB9XP7sFcdYQhB4Z8DT591jkdSc9AnGeu1pk+3o2dgQzTsL2mjDvq5dMHFOTEnhETMGNeFHEn4roFq5/lRUmwoyxqFDDFoCpoYsM6KDmUyx499o/JVuPZzDJRhP+kVXCIJvOD+sUs3siW+bZoqRMcxRbYpzTXdwPWVwKFtlgz479Ay8X3Rz5uew2dF5TvA+RPQXtnXy9fhvUzviNhVqcS26OEtk+0kJ2QZH3hJI3R3wWBmrNUT3NWx+0kE37HseVVVmNY5/XvPyU2uH/JpsRay38t7iyyIb7zaZvHYNsRqw5vtnI3ZEt3JFuzxdfab2cbajNFCXgxCyZmRYHSPNyJ/TPCNbrUnedpjj9EwAdEd5ZpRF/AWAFQ8gaARhFqryLM0egFXZwX/uM9sOqouisB5CzzR5yqfqghxOLsa+xlZEgzt3sCQwAjpCghrq3YmiUkd0RSfQN1AwAYEwetyoUzaIcURyPInXvgYKAa1RewClI78MrWu00e+2111577bWvMOR6lc52dF52s31BUSGLkge2ouTyGusaYdct8Lj3Zxcz7kE/pAzn7A407h3hLzKAJfloiI4KbtRIadQh11jhTWfz2ieRbckIdKP94NmOGtILPZJNKDEo32XtZ1HXEq5VOW6SLevH1VIHOay0nyH0nPq5IYsY5TgtOLQSE84mXgg9sx83fCyFSEBx8AC0o3xqP0LooXWatz6IK/5vbOun9N+PJ8jlntJ/75fw+CzN+MAnb71nQ27JZlAa0n8nSnBmF800+JWK15D+jcR+If2/diGQ9KAyUtTisYg2MqQWWtr1jUyzqBLsFMXpPynBkXTqv1UHj7P+C3fxXR0=","source_count":718,"source_output_dir":"organized/mining_outputs/out_exp108a_affine_n8_boolean_micro_probe","target_bits_payload":"eNrtWFtu5SAM3fmwNC/FS+CTD2QYwDxscBKp6rTVNK7UppcbDAcfY58/Lk+L2UPOAPXJMig/qQxGH8p/VB5DTu19gvwxKxP56rn8cpn4M8e+sP5B10eLY3qYy/Py2uJTHNPXCV1/KqMJm8Ox45jrjstobKMdhm837wEZVmw41+XjB+fCusENYj4uPrsJsdMQRI4Mepr8eyysdXs9QmGcu1pk+7ozdkQjTuL2mrCUqhcHK6YGJfCImIIbrEXB+lREt3D9q6wwkUaMBYUatgD0DV1cgHZqPsVCyq/9U7JxPJNJNhjw96wSO9l0fpin6PIT2dyaLUjKNEehJcYx3cX94MSlYJGN9uzIHyS56OYojWW3ofOaWvsQ2VPQPsvX67dJ7Wy9MVELY8nNkQfbh5/ITijcnlDc5midhYFac1RP89YHTGT9vsd+ZVVWY9/nNS8/pXb4v8lmxFoL/y2uLLLhfrPpW8cgmxFred1skO/IFu9It+eLrzQuZxtqI0UJONFJZvrJAdC83An9M4L1utSdpylO/wRAR0TKVmm0vkA0gyE6jQD1IlXexW5FoBV2dF/79PbDqqLgrAdwZZs95Hz1AQ8nFgKvsZWRJM7d7AkMAI6QgIZ6smKol5HsCCT6BmoGANQnD1sVimZRjiiOR5Gae6Ao4OqVF60UpPeRFK12mr322muvvfbaVxiuehXOdnRcdqN9QVEhi5KHtqLk8hpjjZB1Czzu/dHF9HswdSkjZ7sDDXtH+IuMaEo+GqKjgus1ku91yDVWeNPZvPZJZJsyAtxoP3i2o4b0Ao9kE0oMyneX9jOpawnXqhw3yeb042ypoxxW2k8Xek793JBFjHIcJhxaiYlnEy+EntGPGz6mQiSgOHhA2pE7tR8h9MA8zVsfsCr+b2zrh/TPxxPlck/pn/slPD7zIz7wyRv3bLhashGUhvTPRInZ7KIXDX6l4tWlfyOxX0j/r10IJBxURoqaPBbRBobUAlO7vpFpJlWinaJW+vdKcASd+m/VweOs/wLUgBQZ","target_count":61858}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
