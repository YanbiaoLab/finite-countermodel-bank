from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":694,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":7360,"model_key":"dual_product1|n=6|idx=7360","model_order":6,"model_table":[[2,2,2,2,2,2],[2,2,2,5,2,2],[2,2,2,2,2,2],[2,4,2,2,3,2],[2,2,2,2,2,2],[2,2,2,2,2,2]],"primary_rank":396,"primary_unique_false_pairs":694,"rule_id":"false.finmodel.primary.dual_product1.n6.idx7360.v1","rule_key":"false.finmodel.primary.dual_product1.n6.idx7360","source_bits_payload":"eNrtmV9oU1ccx+OsrAGdKwFFywi6h8tArJtCfLC96qpsT2H64PqgYc1D3R6WByvYP/HkIWqkHX0ZlFFInPjifMgylbHG5QSZf9ualSFtpjGCNg1tNDaxSW5z7/3untvhS28Zodw9yPlAwg3nx/nm9zu/7+8+nFUWi8Vn+S+u3WPf8fE1Fs7/waumkVl0ty9d8JUTYjRJVy1dkZVYFbkPli48lYsD20seAxVYj6qDGw32+lk/7p/a+r/YX2ex7B7WlYXOLd0F//ZW55uwePaTH88c3//Z3jp+YhwOh8PhcDgcDofD4XA4bzlYjndNEHuq7etBXl0AHi2qlEDVtipOmJGazARepIAJUtXFHqpMP+R9zwQxXzEhVh9DyoSoiGw7MvkBpfGq44GSNyO1V5RltEn7iG6K/FiSStpzWvasNUNNXa5H1psgFgeigKrQtEJ1EZJ/8hgop8pmpFbpUoDRMBCSTibxYfjJqMIk+6UNJpmtHNVSAYFe07SWYUc+WE2vNslsxphiNpFldIdtX5ki0kZ42G8HiBmp+QC7dkoSBjUFnXNyHzCDsClmQwW6IPBsEFMu+V+zYZ1JZhPnGvZpQgfYACNdDdAeA01+M8TidFsYs+cNbhJUmvvuy2OYsPVJuwozIIfsX8FVOqiH3+rd3DUP8fLAjtrUTkG+OqQ0GvyNI+j1Sh2OqsPlyqW/b3bnSOYKicVY+FC4qeS5H/y4JNbYSYTmVbHH4DVWIXTYk1ZI6WX4799/A8YiCYW6Ur+y8PKRF2zaZCanazTbsnc1Trk4P2U/mkv3eiPk09f+CH4QVGmhwMJjsUm6pfvmJGoc27LQKbmO1Rl5XmjZmi3QG/UXhVanClvBOgebvUEPH7ddFACrVGMn+Ugb64MqfnG0dyku57bMX3evAJ97/QpJNkZuqGFhQ/Hr5w+BSy03V242dbEPFK1qodRi1Q6X+rWqhVnVEt8uVu2jnts1V83IbKf1PoAyE/OWkYzSb8oZFY47LWWcPplm93Ip1/WeE8CQO7TiQRaXplkf7JlLTAySzggpzt9S143bbqsdwcr07Ig4PEmlhXaczVrd2LnyN5uT9UEAoUrgwggKWwPB95slOO8Kf8DZ2/rnlDZYWp2BoAzhue0dS73BDvU1qP0DpFqCqA==","source_count":5139,"source_output_dir":"organized/mining_outputs/out_exp122a_dual_product_followup_d","target_bits_payload":"eNrtmV9oU1ccx7/33vQm6ZKamZY2cWBMt7QUqVE7/yI5ma2MrcvyoHsZnQkUKfhSrCxqHnJM2wjWh+xB7UM7og+dDzryNHGd2617WGCbVgS5D7OEUcVCqFqhHas2u+dWfOktEsr1YZwPJNxwfpxvfr/z+/7uw1kql8up8pv4dAf7DrX+W+a8DdZNttVicHTlQsoWVNoDZGnliiSGLXD/vXJho+TovWvPGqhg/rLQ89hgr8/14z401vf9zcVy+bcOXVkdmhp0Ju+O51+Hher//OrUxZvXf1nkJ8bhcDgcDofD4XA4HA6H8z8Hq/GPCWIbtX2zcAlVwPvLKnYQYcyCc2akJjGB9X6gmVp0sRaB6cfSz0wQSzmCiqURsidGFNSPwuPqFac7C1tFlxmprSMso0faRxkhcG0LEFl79knZ52aoCav1yFMTxEJAOyCIxCcSXYS6NjUCNr/NjNSsGRHYHgVi8tkA/opu2i4yyT55xiSz2dq1VECh19SnZTjsilt8L0wymzGmmE1hGe1i21u9VH6MLPtdADUjtRRQ1E5JRo+moHNCOg7UIWqK2WCFLgi81wNvTnplNsyZZDalZvZnTehHNsBoZhbaY2IyaYZYiNyLovZrg5sEgbiPfXcJzaXj8u/OOtBrxW+Rs9/Qw/f0P8xUQ/mi905lamcgdXaL0wZ/4wr60/JwwVLI5dy+o7dG3NRzkIbDLLw7OmnPfhi/bVcq7CRKXIIyYPAas1LSkfWJ1P5u9IOPDgDbIkGR5Pwfs3DblfVs2niaGio026p3NXnJUe0tXnb7+tMR+tM7yQiOqIJc5WTh4XATmRrc14QKx7akDsm5S4tGnlcnHtQ7yf6FLnU8L6DknK9BqTirh7eWulRgXq6wk1J0jPWBBZ8VRjNiLn/Ps3nnQeCHdFKkgenIfiGqzjgubGgBvpzYt3azCct9IGpVi/mXq3bV3qdVLcqqFvxmuWr3B3ZXXDUjs53W+wBiXThtQ6CdnLd5BBR2Tdhw+qyP3cv5c58MnAO6R2JrHmQhuYH1wa81weYeOhShjuo9wlxrabcwHLc21LYpHU1ErhrFyfr5Efyx9jdbnvVBAjFr4nAbnA8S8Se3ZOR3qnuR7x/f4tUGy3g+EZegbii9LC8Y7LBQgdp/qBfufw==","target_count":57437}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
