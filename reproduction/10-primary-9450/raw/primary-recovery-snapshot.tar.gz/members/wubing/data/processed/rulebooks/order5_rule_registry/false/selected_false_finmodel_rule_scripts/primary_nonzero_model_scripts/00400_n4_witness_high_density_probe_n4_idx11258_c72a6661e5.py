from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":682,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":11258,"model_key":"n4_witness_high_density_probe|n=4|idx=11258","model_order":4,"model_table":[[0,1,2,3],[0,1,0,0],[0,0,2,3],[0,2,2,0]],"primary_rank":400,"primary_unique_false_pairs":682,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx11258.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx11258","source_bits_payload":"eNrtWU1u4yAUBsSCzuph9QDYolKOgSIW9qxyJEbywtl1rB6gRx3AAduxUdrYGTUSXyTLCYH3+Hi/NkYKozV8SBi/UPv58Tihmuy11qf8qwvOoSYEuUVNHHk7y77r/O1c2gFJy6SR9vbdsSVuK/MLNesDF+qXK5jhJ1DF9Ug7jE9m30Tpr8KgO2kbSFEoIyMjIyMjYysOjXC51VUZJlEFZHwFr6h35YmrlHxhyPl0VOLMUEbGTviQfV1Vx6LRuq7OHeO8qrRmZYv+SIFsN6Upsx4oXNNgVAFDk0InrQS3gY7Z5iX6JZn3GdPGo9dRUCM5L6ujbjsrDGwzQ40EwxC282lohTb1KKd+FHSWbltdB9wKIzQoJ8J/fbTx0lb2MWrB0GIw4HcRBTnW2oHKFo4p9bbEMdVUUZBLODBQCUcGQTmzovTdmW3okENmix2ycqc5Z004vTytXZzPUaU0BTLS/WOaz8+h548Jp4tauw5fvNiL1sF6l48I7LYud+PEMV21sHS2BGsv9GKMcZl3HZ4IBPkTGePCI6W53ngQFPZ2EJ8SAccTxr3ZMPake0sGIXiIs6VA6v2Nt02e5y5B8Tqz0cQOmE1tyKUGvF/UOxEmEucpYXgwSO0OdzpDkrIS8X/M5oFgmIJaC50+z9khPK0CMB3M5t7MXZpIEVmy5s70qtLAM5Lpsq4ClPFoAPEubC1l4Wx05mwikYTNtlrvkZktWSBCvTRStRIAvhPRDiFE4a9Gky0ox0VvvwMTT2WR4ZURYdk7n6iMbAhedzbXgRMy80R4Lhv9B7muYpI=","source_count":779,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWU1u4yAUPmoPULndxQtLw5GyGnuBIo4RaZDNASrzVlMWCCjggO3YKJ3YGTUSXyTLCYH3+Hi/tjZEmzW8Uhi/SPv58TiaRu211gt9wz3n0Chl3KIojvw50KIs/e1c2tlQyySi9vbdscVuK/PX1OsDF+qXK6DhJyD99Ug1jE9m30TnrwyZO2kbSCEmIyMjIyMjYyvONXO51VUZKFEFZHwHH6Zw5YmrlHxhyPl0lOrMUEbGTnilRdO2p77GuGkPpeC8bTEWXWV+UWZsN4WlsB7IXNOASA9DkyInrQS3gU7Y5iX6pZr3GdPGo8BRUE0579oTrkorDGwzIxEFJIy282VohTb1KMdiFHSgbltlCdwKUzIox8J/fbTx0lb2MWohzGIw4HcfBTnWqoHKCk4p9bbEMVK3UZBLODBQCScBQTm0ovTdmW3okENmix0ycac5Z405vTytZZzPTUuwBDXS/WOaz5eh548Jp4xauw6ffdoLxsF6l48I7LYud+PEMV1VsHS2BGuf8mKMcZl3HJ4IBPkTGePCI6W53ngQiPZ2EJ8SAdcTxr3ZCPGke0sGIXiIs6Wgmv2Nt0qe5y5B8TqzycQOhE1txqUGvV/UOyrBEudJYXgwKO0OdzpDlbIS9n/M5oEQWgJZC50+z9khPa0CtBzM5t7M3aFIkVqy5s70qtLQM5Llsq4Ck/FogPIubC1l4Wxy5mwskYTRtlrvkZktWSBCszRSshIA/iWinUOI0t+NJlvQjYvefgfGnsoiwysjJbJ3PlEZWSu97myuA1dq5onwXDb6BZLDDqQ=","target_count":61797}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
