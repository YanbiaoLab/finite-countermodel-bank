from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":680,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":13120,"model_key":"n4_witness_high_density_probe|n=4|idx=13120","model_order":4,"model_table":[[0,0,0,0],[0,0,3,2],[0,0,0,0],[0,0,0,2]],"primary_rank":404,"primary_unique_false_pairs":680,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx13120.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx13120","source_bits_payload":"eNrt2T1IAmEYwPGEirul7mxwaMi7bhOEpob8yMvIm9yqRQPXopYoK+pEbriwQIWoKWmukIYIM9LBIIiGhloqjHCQIPvANLru3jq30iXeLZ7f8MLxHDx3x387QxMAv1CCfhKkXLsKpg3fZyg5Y1lo/XFb9nFmf3di+DywYmThowEAAAAAAAAAAAAAAAAA/0x/jCMFWW4wiUcl2WOMU/SybGbDMsETDPa2IFIPrtW++kF2BKmLytSBMivmS/k1+3hJbMPe5kyeaV1zLfWDd2dyw7uuOl8fVkftewidRL0G3GV3tq2I9bXRzxSv7YV2mXyFQcrOzPNlKeolsF/tE+mcDR4D1WnHXRZiBb0DgTeyrODh3ZyeA8sSjMQxJB3jOIY10i53M01LFI+dzbNW62BMrVYfM7elvLqYFkcqOymUSmqKUslPVp+049uMZeHqBt1gZ7Pkr3WAjgIOXwWdbvcG3nIaMg043kR/T8KqiIXLzr35AEIRJvGBm012jtc7sL3khpp90zGTqywVyYsO3sFsBu+7w9bD04hZL6RIMgkKO5t3hOWP2XwB3pIXUg==","source_count":2297,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrt2T1IAmEYwPH3ros06UMhGiQSa6mhIQKhBo1MokGkmsOmIlChpBuO6IrUoqWoVUiXanO6Ijvzo6EpENquOxsaHPKuljsqsDq30iXeLZ7f8MLxHDx3x3+76icAvyicfmoqXbuKuavf54Zv93777cdtTsvu9Mzh2XB8tSLCRwMAAAAAAAAAAAAAAAAA/pnroKByNN1gEggx9HkloMhrdElcpzVek7C3xRA51U/e1A+cp4jcovanqB3WZrYt54/M7Cv2tqxvhHiMvtcPWrK+xdQSmW3rWjnJexEaDaWquMt6C/PhYlujnympQrucKSetl0peivAmJpTSsF+tCemyDR4D1XnBXbYhcnoHHF8RRe6cTwt6DqKoSYwgqXJQECSxImfSH7LMKDx2Nh1ErYNj0mCwuOxmG7nlZk+Nsx7k8REUZbQdGDqJcbvrfnugD/VhZ7OZqHWAJuK5pBE55m7jrWMEKl/lWtnEnb9IsdbBJ28kjlBY8jfjZuOM8noHhfaxi4/kXrCcMTHd6tAzn5MWYj0P68VJR7ikF9KtSn4FO5sWhOWP2XwBbd9Z5A==","target_count":60279}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
