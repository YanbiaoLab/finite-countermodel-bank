from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":680,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":2890,"model_key":"n4_witness_high_density_probe|n=4|idx=2890","model_order":4,"model_table":[[2,2,2,0],[3,2,2,2],[0,1,2,3],[2,0,2,2]],"primary_rank":405,"primary_unique_false_pairs":680,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2890.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2890","source_bits_payload":"eNrtWT1P20AYfu90lS4pwzlk6Hg2rpRKHSiqmB3XoNApIDp07IBEpfY/HFGQAmKwKCztAhFbt6q/oKoq9WPoT+rde2c7HxCCCIVWfkUsnPt+/H48j0MgihScY3VGI5Du5qwHd9+EyP+VwIBeZ66T0IsokEMNQUR5xDgAgcBMTHbMzMpcHEAccGHOQwUayxpwoVsJhYjpNvN3kdFij0yPLRp+L73f/iSejY9QR4p5O3aB4ZazvaX9xkGKQGQz8cmHrAAE1D3jDDvc0Un2uNsxmzSBdJ/SSiuttNJKK+2a1uDDXGBiAa5onsOQdpgKTuF6rOf/MlYwWA5EwaXscIDwXsh3mKZ+oEpwSytt0I7Cw1YQxDUOrBWQnlYn0ugfYHIvDAKW2hRFjOKhaUIFqUUQ6A49/WUEpGdHGH0FkgIOlJDoZuiaO4xXYm5QKx0mtbUk0eN0YEvULsyKHZsLqdUzNolqNURRwykzA8V+BEegRTaaMa5FoYPMZlyYt0WL6vRRCUHYfAsKJZ9Q+spT1Ho6daDWi7SoYphtinOYXWHSwDU8HJhla+FUWtcdUUCMO5NmbTYkypTpbQ5T6DU8IJdOCvL8q0wQ5+mMwoiOczNHTewR6lulL1wM50JqBSQpIHGpU41OVKxBwUEBY+LQVja3kFXIDjXjNlxa1MCiNl7ZhGdHGAictLbj9f4Id0/U+cll0nfWJqU9kXlfAOYwkPuz9k9ELfcwdJsRAAbPUQQCZA4EmZ8wBNW+m3ELDaFGxlBLWb6vyWu4yjYAoguM0mZjUZQTD3SBycTjvGAbZyyDwXab9vbj3vL9J59frPq7yx/e/NqsnC7GW986cu4m+OjJQ7+ZSBo8l1KF7/Z6plLIrrDFYeZmX6y1k/lj8aPRX4z93XhuV1Q7/k2ArjoR1RUkNS8faYuaoDUV0gQtpseQiBmS0JS2ZF+XpDXtSJ0eVkJPxPyGvGkjmV+px43+QcxX6uv8VMSvujG/1xT/foppeXiiXlD16+uJr4+lPcSvs+Y572Nd0XaPjw2XSTYUyiPBk+H0qJ8vFOw3um0Dpd/tSF6KvztsKQUZ6AAz7MQEG3pGjGzUED01SKiUc5sLid24Uwy62F+vbD+3+9/jucpUnV9u1Tew+7GoLmyuPuZf5BWDrdIS3pQ/SMk+oxS7a4rOYk6iqwL0un8QVBemS1HJ0/XKqele32h81WEpH3TuskeGurhMC4fwzDXr7nfLeL41GtlEXmiJ/2z5wK3bH89Lowc=","source_count":1316,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWT1P20AY/kkd+iFVVX9B1a0bCiztAkUeEIlEFO4/tFKRGDp2KIJMJQLX8YwqylCpkWrsGzuE+AaanNTT3du79852PiCACIVWfkUsnPt+/H48j6MgDAmcYV0hQ6DuZq4Gd98Yy/+lIEBeZ66FKA0lqGUNQSh5KDiAgthMrNbNzMRcHEAccGHOIwIayx5wpluVhFDoNvN3nslij0KPLRruHb7aeM4+T44gS0Sk63aB0Za56uFqZ8VDILKZ+PRDDgBi6Z5xhh3uaCF73M1ATJuAuk9ppZVWWmmllXZN6/BRLjC1AA80zxFIO0wFl3A91vN/mSgYLAdF4EJ2OER4z+U7QlM/ICW4pZU2bEvRciuOgx4H0YpVTasTavQPCFqN4lh4NkUpo3ik50umeiHEukNNfxmCqtkRRl8BlYADKfi6GermDuNVmRvUSst+b9f39Tgd2BS1i7Bix+ZCafWMTaJaDUnUcMTMILGfwhFooY1mjGtW6CCzGRfmTdaSOn0MImA23wJByceIvnIPtZ5OHaj1Qi2qBGab4hxmV5g0cI0UB2bZmjmVVndHZBDgzqhZW4yIMmJ6m8MUeg0PyKmTgjz/KhPEeTqTMKbj3MxhG3tE+pboC2ejuVBaAakKSFzqJOMTFWtIcFDAhDi0lc0tZBWyQ824DacWNbCoTVY2ltoRBgInre14vT/F3RN1fnKR9J21UWpPZN4XgDkM5P6s/RNRyz0M3WYMgOFzFIEAmQNB5icCQbXvZtxCI6ipCdQ8ke9r+hqusg2B6AKjtNlYGObEA11gOvE4K9gmGctwsN2mvXlRPfj19dnHvWTt4OXb+1uD+aNg83GDnt4EH134kbR9KuNPlJLodbVmKgWtM1scZm72xVrTP1lkDzuVoyBZC07XWL+R3ATopBFKXUE88/JRtqQJWlMhTdBieowUmyEJ9WSLVnRJ2tWO1KhhJUxZwG/Im7b9k/1u0KmsBHy/u8PnWfC+HvDfbfbvp5hWiieqxf2ku+Mn+ljaQ5KuaJ/xPtYVbff4xGiZFCOhPBY8GU7fK/lC8Wqn3jRQJvUG5aX4u8PmSaCxDjDDTkywoWcEyEYN0SPDhIo4tzmX2E06xbCL/fXK9mCj8ig4HVyq84fN7jZ2X2T94629b/wpvWKwDVosveQPUrQipMTumqKLgKvwqgC9q6zE/ePLpSj/y85g3nTvbnee6LCkPxt32SMjXVwuCwdLzTXrntTLeL41GtlGXmiJ/2z5wK3bH30mziA=","target_count":61260}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
