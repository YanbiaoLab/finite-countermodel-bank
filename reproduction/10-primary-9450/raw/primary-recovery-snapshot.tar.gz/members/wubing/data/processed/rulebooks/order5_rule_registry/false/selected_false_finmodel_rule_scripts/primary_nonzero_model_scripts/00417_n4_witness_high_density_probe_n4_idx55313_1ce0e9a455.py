from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":648,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":55313,"model_key":"n4_witness_high_density_probe|n=4|idx=55313","model_order":4,"model_table":[[0,0,3,0],[1,1,3,0],[3,0,2,2],[3,0,3,3]],"primary_rank":417,"primary_unique_false_pairs":648,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx55313.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx55313","source_bits_payload":"eNq9WcFu00AQHS8uspGQ7KQnLjhmUfoRSFlFlrA5lN75AY78Aa5kJOcW0h4Rzaf0wJlviDhxLLciVZjdtZNGyU6bKLszB7fRxn1+43mzb6dfmAC4DkHFJVdX4ekPlb4KfYVjSPQHweSPOz4DYyxGsXkBhuWQBaaFk4J/zTJ/e0EU6YSnqeGWUwQDzpDHgpKJnnnlGPtbcz9CVgYlmKkEHnKH0MkzBcPgP3Ur+eY3ypmP3NpR8V9sLiTtHXwqNlfaB07Ot9Lfcl+ybH+W+rveJrX7uG6aiXysN7EAgrhthrJwKj6rawK0pmku6nrqUzCDRdP86L+MWZBQoN01zedfr8YkzKC8ypQSb0eTOihUPaXMIdrNlS7dZvQnHmhtOOX2s/9eNo2F0oAfCaUXT/3qBuw6XCzFplvrjWQoWo06iLZLa7FNs14cp2mW1XU0RlveQfF6sgKa5Wk6zqo6iONxMHABNpfMlkC9QtOKB6kEc/LiLvkKKE8nipZKZTConIhtlq2ACh4rWiqVgypyIraLnAFZ/Ot7dGCd2IgCtUTgTmxEYIuW1Xeana2zs0oDBDtbHwgDtbpO4l1P79UhCZjwNBCX+i7VC4xil0o/0UBUcaSvRDZyTlkiUmzKrwrwKMipnU0CBURia897hXR3iXsbOZYplEAliY0UwRqQpKkYOrSRnk9YkehB3UV0h2yiM1tFqewyEuvTAMcRtUCqKROIjQFh9+/mIkQaCChrBEYT/tBL/c1s2md8zujC8H172K/atUXdmQ19qYnVgj2b6cMhum63VE9x1rJ4+N+3VsVWoBUnt7fy6YecxkaqOXIpngBY3BiOUGYKKPpo10aik3BZPEyJDSweHytsCxUs9CFPzgFibYdstLcSHYRooJBbHZRE6DOHvJvCW2xbaPVrID61PCBZ3+DWw9Q6jXOiPVrNSdFmbaswjZ3flPR6b7EZatJAQ8w9Q7PZ30Ya6s7bluHB9YnmPEHKxsaAxPCvOEOODj0jLwckYkdpHhbPOs09xzzfZo/eJeP4me2+RT2K1ssT2OFrj9rIcNvesdDQow01Vu+R3v9M2KQ5","source_count":1296,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNq9WcFu00AQNapEb/TICeUbOHPop6SIYxtyiyUs1fwBR36Ae+kBG8mKNhIfkYrFMRdOTWwJCVvUrIfdtZNGyU6bKLszB7fRxn1+43mzb6fvBAM4LUHFOVdX1ugPgb4yfYVbyPQHJuSPIz4AY/QmuXkBbsIbUZkWphF/myT19gKL0hFPU8Mt1wgGXCGPBaFgC/PKLfa3+nWBrMxCMFOpGuQOppNnCoHBf+hW4s1vhIMaubWjUv/aXMjaO/iQba60D5xdbqW/5b5k2f4M9XebTWr3cep5I/lY33IGBHHs3cjCCfjA9wnQPM+78P1hTcEMep73av4zF1VGgXbkee9f/BiTMIPwLFFKPJ6M/CpS9ZQKh2gnZ7p0vcmzfKa14ZTby/ln2TR6SgN1wZReGvWrG7DTsrcUm26tJ5IhazXqINourcU2TBZ5nqZJ4vvFGG15B8X30QpoEKfpOAn8Ks/H1cwFWF8yWwItIk0rn6USzMmLO+croDgdKVoqldUscCK2QbICiniuaKlUzoLCidguYgFk8WTe0IF1YiMK1BKBO7ERgfVaVq9pdrbOzioNEOxscyAM1Oo6iS8LvVeXJGCs0UBc6jtUL7DIXSp9qoGo4k5fiWxkn7JEpNiUX2XQUJBTO5sEqojE1p73IunuMvc2cixTKIFCEhvJqjUgSVMxdGgjm5qwItGDuovoDtlEZ7aAUtlhwdanAY6jaIFUUyYQmwDC7t/NRYg0UFHWCExG/KGX+lzYtM/4nNGF4XvzsF+1a4u6Mxv6UjOrBXs10IdDdN1uqV7jrGXx8KdfrYotQitObm/h308xjY1Uc+SQ/QOwuDHcocwUUPHRro1EJ+GyeIQSG1g8PgbYFspEWUOcXQLk2g7ZaG8hOgjRQCW3Oigp0GcueTeFt9i20OrXQHxoeUCyvsGth6l1GudEe7SaadRmbaswjZ3flHR/b7EZatJAg/UbQ7PZ30Ya6q7ZluHB9YnmPEPKxsaAxPCvOEOODj0jLwckbEdpHhZ/Os39xjzfZo/eJeP4me2+RT2Ktogz2OFrj9rIctveidLQow015u+R3v//mczu","target_count":61280}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
