from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":647,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":163,"model_key":"n4_witness_high_density_probe|n=4|idx=163","model_order":4,"model_table":[[0,0,0,0],[0,0,0,2],[0,2,0,0],[0,3,3,0]],"primary_rank":418,"primary_unique_false_pairs":647,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx163.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx163","source_bits_payload":"eNrtmc9P02AYx5+XDrtBcBs/Mg9kP9RkGA6LnDBptjFZ5kmWeMCDYfgfgFyGIWkjEAgz2UxMuBBwcNCDJ0+GhKyIhnlSgn9AFQwDL92yQ7Nse3xbLyY06g71oO/n0Lzp+7bfPk+f79MmLwEACX7HyzX9KMsEGH8DdWa7hLnE+Qkpu0eQE0wuqWce1CLrrvMTytGUjOA0uSRF2pt8t8nEi7WVocXHdJCM2QAuDfdLnMzpE1Nw8ac7RRWXRCbZ22IwGAwGg8FgMBgMBoPB+A9AzDTF2ap4u5xtIiWST8cQ94K+NgvEFBRlvOBs7pOzXV0M28CpYGRS4awIrY4ztcL6R/TsuGu62PVszNtA59kVuwViEiLBTkHz8cu8EZoDBHpOkpxWhKbiuCJeIzg46VZ0sZ4u6FbR54pbUiO0ME768PQVpiYautrqOGJioqtcsFkgJlMBYTN8r1J4nzESOfQFC8XOwCePFaFpmKpiJo8zK6GqLvbN8a6nhr7wfZc1ZsPQw8DTQywv6GYThTzS4Zug/V8wW5+W6pCx4y7NKSXKSbY68qOWbDxQY+Hs6NzrY/GJxwgt/hbpMLYcssxsDsBBPzHMxjl+mI1YZLZtIUCiq8GrNKe0RvxkdOw4DpctEZM/nG7iTW9j405xK9N0zlZjA7Rhor+4BOcNgCe9lZK+fMe1EqxixF4JtGi24X41Is/jNKSNnQ0vyJyGTtDMqlfsB6+xnAeVJoWDcKtm21xrZulzxkML+gZLsriVSyDOa2Zmq4sHnXl9eW9l4PiAJiD8qEWz/diroWZTdvV9njQYZgMzs0l/lIBfMdfeq/luUbO5bEmFVoiNGGYDt1n1FtpsRF8OI+An9CsVbbFrSxuHcVwSapHnuYSn4auUFpN63xrJOa0wgDo9rIgSj0egKhISrwAST80GKgELmmQzfqPhGythZsL+tUrbcS4RoL9BfNltyZdt/7MeUT3LyfNck0+rAF4ZRZB5sOCPROsYUCM5Cfv89mcyRtto2Tv0WqONxOS9mT2A1ILad9f9n6M=","source_count":3307,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmc9P02AYx59uWXpYtl6EGUH7B0jQkyOKdCEhnjx50ANMCBcSE7fEEQhg2oTILgj/gYx4kIPJ8OQyHNuyRE6YHYgsUfcjHFz4tUpgq6x7H9+OiwmNukM96Ps5NG/6vu23z9Pn+7TJSxBRxt9xb9Q4ShJBxt9AmB/wQCB2fkIO9hLQMyaX2EPPHamRyvkJsXNRAlRNLomQU047MJm4Pzq+OfWEDqKJOuLXjR1Zl3RjYhG//XSnpFiRyRJ7WwwGg8FgMBgMBoPBYDAY/wEAIU6Zcypv3EEOKCl/OAHQmys2LBATQZHgu8r1kLY+QwwaqIqQWhJ1K0Kzw7zDN3INyv2HDkPsQzBRsoHa9rlmgZgMQOA4wxe1Ca0ZWhUz9Jwsq1aEJsCKqHwksLV0KBpi+0d4IECxErekRmhhXNyF9rsQWbYZamMrALHlI7evboGYRAUyQ+mXLt+NUDORm5fB5z3OXy1bERoPESeE/DA/nnUaYheqN/cdUEy/qFhjNsg+yz/qAve0YTYl4wc6vJ2r/Qtm2+UjJxKcvKI5pSR1uW4Hbc2SjQdqLJhbm73ToTwuN0OL3wI6TExkLTNbFWGrQJpm06tnZiMWmW0gkyfJsdwnmlNaIwWyttoRxy+WiEnX24fgXck2/No7GOLUOWdimzZMKHgn8bwB4OKey2Ms76+M55yQqrnyLZptY0dISTOwgOHmzkYJJZ0HFXmz6lV2sNRcrqFAk6JjulWzDY1yQfqc8ey0scES9Q4GYgAzvJnZ7Er3sd9Yvufa7uimCUg/bdFsZ3s11Gxin7HPE8am2dDMbPIfJeBXzJ7u8cW31GyVelSkFVInTbPhoVn1+hp1YizHdSwQ+pVKtti15eGuOExmHKkHgVjZVnR5pqJG31oPqFYYQFjYEBVZg04URBlIKYOyRs2GAkELmiQXf28rrnogtFy75KTtOBDL098gzX1oyZet54oRkT2oSzM6p4UFxJIECkoaWvBHwp9sC6mADLuF2kMJkg1a9lWj1mgjMXlvZg8gt6D2A3R00YQ=","target_count":59269}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
