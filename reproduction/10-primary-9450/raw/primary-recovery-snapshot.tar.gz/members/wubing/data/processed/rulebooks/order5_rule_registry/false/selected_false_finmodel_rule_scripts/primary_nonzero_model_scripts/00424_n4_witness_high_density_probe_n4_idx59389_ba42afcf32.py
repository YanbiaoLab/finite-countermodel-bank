from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":639,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":59389,"model_key":"n4_witness_high_density_probe|n=4|idx=59389","model_order":4,"model_table":[[0,0,0,2],[2,1,1,1],[1,3,2,0],[3,2,3,3]],"primary_rank":424,"primary_unique_false_pairs":639,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx59389.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx59389","source_bits_payload":"eNq9Wb2O2zAMpmRdoAAZHDdDgi5CLjh06JBHUIugcIEMvT6Bhz6I2qLADR083lz0QTIWfarqz75cLQYxTjQHG7YA0aT4kR/pH6A5aPCy81d98jcx9w/vwwPs3QPX4QERxbAVViALskIW9GdsLw5wTC609gtuUwtGwWwNqY8TC5BpU6wxaTsZYzsok6boNm0KB2SvivODUImFbv+BoSZuNDTUmuJkxgem1ICc2ty7ROkDcMTRXupouHfLc190X+XN7MJoEqlhSkHjl0LUpLbtbiZU5gLl9WTaLByb28m0fYN1g+fGzGKT9Pfpjk1Cjef2/GDDMiwN2NQ7Ph3YYPVpOrD9NnzJ5ETazg5MFQtqbWe04bha0oOt9+nNnadClGCrzhLYTBNnlI9PuL77KxtisIHx6h7d5ZV/1ZCCzd83rONLhg7pprcIgD5VnlFdtSXXxoG7LOJRHQ5QB8pHArZSmy4uFnur2wGALJ9I3hhmU5fFdElPX1kRvedrKnVla7wi37jBOmJhRqVNRBRUoeEhrmwmosB2VrYnVeSVzbGfSjrLumPb0oFNKndi7Kmh5mS0Umv46pspZqAjXYYsMqVTFOYMLZCTrkgjnUJeU8eIqk3fuoXJCSWDFXOnyGuUmnMOlAkljhx0agBAU9m20Zh+akJWUKsINqvo0NNIMrCFWZoslxZsW07c4dTSK3LGlEseXGjowHZxdZOX5V3uRZtfD3nBdpF8vN0zkzE8zUXbjNhnLTzt6tLq/v4D5Jx7oYNbOAnI3VVZDmJ+ppf+yOxA6GjkUBzhys0sWYFUz5NTxJo4iF1n6tmwSThFBRdCtMk5srYlIXditmCLtXrIVFyy3IVyZ/JESxtLaDp5lveHWHry1AX010IY95dZzzAeWCrLPw5fHTGcXFvZwi01t94MHJxMAm/GgS3Ne07DMG1Uci4whkZi1JGPrbnXDEgwQGnz8D/Y0L9EYwYk3kfX7MJfDrYgX67IGfrw4soWordgGDKepZYiMYYawavjX0aJI+M8Rmo9/IQx9tZBT4KvJozYisHbcTn7Hzi7V04=","source_count":742,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNq9Wb2O2zAMfqqiYx6k6Hyjhw4HFG31IB38BL0OAWoUQatHyNChOOQMLUUypI6HABFyssTqz7lcLQYxTjQHG7YA0aT4kR/p98A1cPCy8lc+8zd18A8/wgMs3YPm4QERYbAV0yELskEW+BdsLw0wTy4U9gseUgtMwHEDqY9Te5BpU6wxaTuNMStok6bwIm2KBmSvRuuFEomFfv+BoSxuNDTUmuLkqAemVICc2sG7RPAFaMTRXqpouHfLc1/0X+XN7MNoEqlgSkHjl0LEpLatHidU5gLlz2TaLBzLh8m0fYRNiefGzGKT9Ifpjk1Chef2/GDDMiwN2MRPPR3YYPt1OrC9YXpn5ETazg5MdHtqbWe0Yb7d0YPt5NPHe0+FKMHWnCWwIyfOKN+ecH3/SpbEYAPm1d24y1//qiQFm7+vTc+XGB3S2ckiAPpUeUZ1RU2uTYN2WcSjOhwgD5SPBGwtZ31c7JdWtwMAWT6RumTGpi6L6Zaevpoues/XVOrKVnpFvnGDTcTCkUqbiihoQsNDXNlYRIHtrGxPKsgrm2M/jXSW9cdW04FNCndi5qmh1mS0knP45Jspw6AnXYwsMqVTFOYMBZCTrkgjnUJdUceIqNipdQuTE0oGqw5OkdcoudYaKBNKHDnw1ACAprLV0ZjT1ISsoDYRbFbR4kQjycAWZmmy3Vmw1Zq4w6mkV+SMaXc6uJDRge3i6jovy7vci5Zvb/OC7SL5+LU0LGN4sou2MbXMWniK7aXV5d13yDn3Qge3MFOQu6uyHIS9Sy+9ltmB0NPIoTjClZtZmg6pnjOnyJRxELvJ1LNhk3CKCq6UKpJzZG5LQu7EbMEWa/WQqbhkuQrljuWJliKW0HTybO8WsfTkqQvor4Uw7m+znmE8sFSWvxm+mmM4ubayhVtqbr0eODiZBH6PA1ua98yGYVqK5FxgDI3EqKMeW3OvGZBggOLs9n+woX+JxgxIvI+u2UW/HGxBPl+RM/jixZUtRG9nMGQ8Sy1dYgw1glfHv4wSR8Z5jFR8+Alj7K2CngRfTRhRq8HbcTn7HxPFGeg=","target_count":61834}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
