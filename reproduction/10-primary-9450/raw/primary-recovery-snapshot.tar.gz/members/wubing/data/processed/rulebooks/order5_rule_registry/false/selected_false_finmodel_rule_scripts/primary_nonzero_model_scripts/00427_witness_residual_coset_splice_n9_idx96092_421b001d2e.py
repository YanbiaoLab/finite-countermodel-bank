from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":633,"excluded_block_payloads":[],"law_count":62576,"model_family":"witness_residual_coset_splice","model_idx":96092,"model_key":"witness_residual_coset_splice|n=9|idx=96092","model_order":9,"model_table":[[0,8,7,6,5,4,3,2,1],[0,5,7,6,2,4,3,8,1],[0,8,1,6,5,7,3,2,4],[0,8,7,6,5,4,3,2,1],[0,2,7,6,8,4,3,5,1],[0,8,1,6,5,7,3,2,4],[0,8,7,6,5,4,3,2,1],[0,2,7,6,8,4,3,5,1],[0,8,4,6,5,1,3,2,7]],"primary_rank":427,"primary_unique_false_pairs":633,"rule_id":"false.finmodel.primary.witness_residual_coset_splice.n9.idx96092.v1","rule_key":"false.finmodel.primary.witness_residual_coset_splice.n9.idx96092","source_bits_payload":"eNrtmEFuAyEMRW3khZccwUfhaCxy8Boow8CEKq0aKU3/WyQZwsjIwP8YpsGNIr0KSS1TIMrloQ0r/H4UEUoei5SEiHsjgQfTd/wKSAYAb4qyxORSHJT8m323i0tmN4uEBD3KzVNonjD2/Lm/Hals5mM1173vcD6Zmmg44qS8eQ2W4ymQRCqBc4t0x1XTCN6NsA2INkPAvD9ps42Mr1PK9y147WbXbvlfbra2Snk90NWT5ZykKmvzii4CZ0cTFjv4W5hVcQ+pLHU9SwNb0X45WUn2Tx1eoG3Ba1UcXoRHtkUAAAAA8FRnk/zV4Tlomksk8BKEelaw3d/x+qC7ugfXjW+KfE7tZcZrfaZG7c6kl3H+QqR+qXGp1BT5BACAH9Ou/rdnrSa83dPLycuF+rg54+9G+wA8NRdO","source_count":190,"source_output_dir":"organized/mining_outputs/out_exp113a_witness_residual_coset_splice","target_bits_payload":"eNrtmEFuAyEMRQ+eBUfjKD4CSy8s7Boow8CEKq0aKU3/WyQZwsjIwP8YtcHNkr0KkSlYNgvloQ0r/34UEYsey9jETHujgQfTd/zKSAYAbwqrpOhSnNn8W323i0tmN4uIBD3KzVNInjD1/Lm/Hals5kM1173vcD6Zmmw44qS8YQ0W0imQJCuBQ4t0x1XjCN6NsA3INkPAvD9ps42Mr1Oq9y147UbXbuFfbra2SnU90NWT5ZykKmvzii4CR0cTFjv4WxBVcc+xLHU+S4NS0X45WUnwTx5ewG3Bc1UcXYRHtkUAAAAA8FRnk/DV4TlznEsk8BLkelag3d/p+sC7ugfXjW+KfE7tZcZrfcZk7c6kl3H+QrJ+qXGp1Bj5BACAH9Ou/rdnrSa83dPLycuF+rg50+9G+wAQS1no","target_count":62386}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
