from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":632,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":113845,"model_key":"dual_product1|n=6|idx=113845","model_order":6,"model_table":[[0,1,2,3,4,5],[0,1,2,3,4,5],[0,1,4,5,1,0],[0,1,4,5,1,0],[0,1,4,5,4,5],[0,1,4,5,4,5]],"primary_rank":428,"primary_unique_false_pairs":632,"rule_id":"false.finmodel.primary.dual_product1.n6.idx113845.v1","rule_key":"false.finmodel.primary.dual_product1.n6.idx113845","source_bits_payload":"eNrtmM1uwyAMgA1iEr051R6AoBz2GKzKobntkei0Q3bboj3AHnVgGjra9W9dpE71d0qIjI0B/0TAHu4Vbg85DbfCZ/OuJIrBgQUZ3n1e+t2qQbhCR7xAtMrHRzxRpPYgR5lfofKTBIZhGIZhGIZhboaPZlhau5h3bbuUooeqMtIpqJV5baxtVtD6XqMw0qN8i60VNSntKN4HidBq6RpQjGN2fAgipTI/tFlRZ6AyVirowXggRQ16jZWQYXp0ly/taUiKmqqqZ8rItg3dIAarqP+h7skUjZArm7Bs/MYWfSWNk3s0MwUyeM352NaS11y29I+Ne9DRT6TIF/O7eQcq6Rx3n+wit+b2NBhnk3Ebd7ufmlGGYZh/iH/eF3QpdoqG8qZjRx3NbF2oBmQsCSD95ZwULVSoNJIit85GOicv3K0CdDRMjFnLFEns6O/bmmbDopIQu4o230UxlBOlv/XLFvZMqOR+oaa+WCjTpgdFdDTjCcGsm4aAhvaVXn57Iw+x+KaIjmaQlVPVSG67qi0/lWvByy9bOvHqlJmk5mDJTMzijO4jZQS3vhR47UtLmY0CT4xeh9cZL1sIqSmuuXPC1ZovUp04mw==","source_count":461,"source_output_dir":"organized/mining_outputs/out_exp121a_dual_product_followup_c","target_bits_payload":"eNrtmM1uwyAMgB91DzBluy2HaeWRdksPUcdj7IASHmBqfCvSEHhgGjra9W9dpE71d0qIjI0B/8TjHj4sbA9Jg7fCnXqwDnwlsUMX3kVe+udMAV6hI54xWiXiI5wo0gt0o8yvsPnJIcMwDMMwDMMwN8O9quZdt1g2bTt3vsZh0E5a7K1+Ul2nZtiK2oDXToB7jK0VNSntKF4HidBqmR7Bj2Pd+BBESmWiarOiRuOgO2exRi2QFCkQBgbvwvQgL1/aa5UUqWHoV1a7tg3dIASrqP+h7kkXjZAsm7Bs/MYWcyWNk3zTK4sueE2K2NaS12S29I+NezfRT6RIFPPLZYM26Rx3n+wit+b2NBjXJeM27pY/NaMMwzD/EPGyL+hS7PSK8qZkRx3NbE2oBlwsCTD95ZwU422oNJIiuc5GJicv2K0CTDTMj1lLF0ns6O/bnmaDopLwu4o2330xlBOluPXLFvbM2+R+b6e+WODSpgdFdDTjCYGsm4aQhvaVXmJ7Iw+x+KaIjmaQdVPVSHK7qi0/lWuByy9bOvH2lJmc4WDJTMzijO4jZQS5vhRw7UtLmY0CT4xeh9cZL1sIqSmuyXPC1Zov+dQ4mw==","target_count":62115}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
