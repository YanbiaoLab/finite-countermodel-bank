from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":630,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n8_boolean_micro_probe","model_idx":117124,"model_key":"affine_n8_boolean_micro_probe|n=8|idx=117124","model_order":8,"model_table":[[0,0,0,4,4,4,4,0],[1,1,5,1,5,5,1,5],[2,6,2,2,6,2,6,6],[7,3,3,3,3,7,7,7],[0,0,0,4,4,4,4,0],[1,1,5,1,5,5,1,5],[2,6,2,2,6,2,6,6],[7,3,3,3,3,7,7,7]],"primary_rank":430,"primary_unique_false_pairs":630,"rule_id":"false.finmodel.primary.affine_n8_boolean_micro_probe.n8.idx117124.v1","rule_key":"false.finmodel.primary.affine_n8_boolean_micro_probe.n8.idx117124","source_bits_payload":"eNrtmcFu4yAQhgfEwbnZaB+AIFfqYyDLB7unPhKRvFJy81p9gD5qGaBe1YxXiQrdi1EUJRBnYJhvfnv4zQ0DMwK2txbfzciTL78AvxlmJI6IZQDfvWnv7Z9eAtWebkJeqYHn0V3Ti3TAjPrWak1c8sLHtq6Jgddl0LdrlQ7YpZdj3xOXvLXuGs13ltI05FLa5XrNtBQ5tk3DiKUEN8pBJ0vxBubUz2G/bOrn99YbICb3dMJ3lU6uBvTipyefYXAesvj/6vRlMmDcgPEv4ZapbkI5O8bYVlr8NQcBhRp6W7hJub2IziA3OFML8TtjSMjBL6tyTjJljMXYw8jsduI2YwsIeEM7+GRsdjHyJMSgWQVjC0zpDl2pyliLCWF0ALggxwghwc3UAszni9DQzkbYChrQMJUxFnOKN4ShWTPF3ce6HGx9P0XYmkZrdGXdVawMbKshH5r9dK2apqvOPwGbW1Zz1s6Y+AnYgiur81QGtn415EMzuPI8FYmSVxmprmuvAy5vVU6mbTnYWJAurwOYt0iJzQSbpxoZ8LDVSjmRI++BDtj+Cdvcc8aWwfkPdcAti7mPhfL/D8MWle1iAwNO2awFVib+V2VzVCMDMW9NNS8FWzTkQzO4cqq7ksr2yUAd8paL/wO2Q9n+i7IdsB2wHbAdsB2w7cN2CSWfpM1GMpAD1wZJYPlgI0eWgYMJ/GWEzZd8iP3kpx58tDIIJaFssBEjKxYsO2zEyIpFTtj2Crfq0nJwjwaANZMmT9Fwv+ga64YAyB/PCRsxb1+cmQ3HUlAP7tExh8HdErQ3hNEay09dLtjISngJsdstyJsCYncHbBnF7g7YMord7tGCKiB28fxoULc0RtT24T491HDP/0Y8Alv0GqNiJOki9v2RKnc8JMECEBEjmy512f6zRdHj92rD/lkNsZvfFoN4ZJQmE+JISH1XDOzy935gm5CN2XbNCZVCVJix74ZtvR/YTCNdrRcDIkLuX++LXO8HNgk5TZ0+R39tj9UT45EsEX5E6iS6HrsRXGHbxhoNW9L12FPXB2Q+izU=","source_count":3152,"source_output_dir":"organized/mining_outputs/out_exp108a_affine_n8_boolean_micro_probe","target_bits_payload":"eNrtmcFu4yAQhh+1D1B5fUuktRQeqafaB8viMSrVIjzACvsWHxDQGaBe1YxXiQrdi1EUJRBnYJhvfnv4bbh1vHXYnkd8561Jvvxx+I1brnBEV53z3Zv2NP7qlaPa+0mrMzXw1sI1vU4HeCtOoxDEJa+mHeeZGHipOnE6L+kAq3rV9j1xyfMI1wizs5RpIpcyVudzpqWodpwmSywluFF1IlmKN1Cnfg77xVI/P43eADG59xu+y3Rys0MvfnryzXXgIYb/L29fJuM4DHD/0rBMedIS7HDORsXw18ZpV6ihtzVMCvYiOoPc4EwtxG+NIaE6v6wFnMTLGIuxh5E57MRtxhYQ8IZ28MnYWMXVTetO2MW1o7NSDOhKWcZaTAgtAABBjhFCgpupBZivFy3cWHPNFjc54ZoyxmJO8YYwNGcrDXycy8HW902EbZqEQFfOw2LLwLYa8qHZN+dlmobl+hOwwbKmqwBj+idgC65crk0Z2PrVkA/N4MprUyRKXlSkep69DkDeWkCmWTnYbJAurwOYt0iJzQSbpxoZ8LDNUoLIkfdAB2z/hK3ujbVVB/5DHYBlWfhYKP//MGxR2S4sMADKxpizZeJ/VTagGhmIeauZTSnYoiEfmsGVzTyUVLZPBuaQtyD+D9gOZfsvynbAdsB2wHbAdsC2D9sllHySVnNlneqM4EiCzQcbOVJ1xvHAX0bYfMmH2E9z652PVutCSSgbbMTIioXNDhsxsmKRE7a9wq28jMbBo4HDmsmUp2i4X3SNdUPnkD+TEzZi3r44U3ODpaDewaNjDoO7JWhvCKM1lp+GXLCRlfASYrdbkOcFxO4O2DKK3R2wZRS73aMFWUDs4vlRJ09pjMjtw316qAHP/1w/Alv0mqViJOki9v2RKnc8JMECEBEjmy552f4zQ9Ez92rD/lkNsZvfFoN4ZJQmE+JISH5XDFj1935gm5A533bVCZVaL5ix74ZtvR/YTCNdrRcDIkLuX++rWu8HNgk5TZ0+R39tj9UT45EsEX5E6iS6HrsRXGHbxhoNW9L12FPXB+gz5fI=","target_count":59424}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
