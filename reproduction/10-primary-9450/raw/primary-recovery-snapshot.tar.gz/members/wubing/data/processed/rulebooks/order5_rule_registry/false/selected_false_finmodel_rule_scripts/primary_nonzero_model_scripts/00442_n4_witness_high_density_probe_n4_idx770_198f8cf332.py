from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":604,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":770,"model_key":"n4_witness_high_density_probe|n=4|idx=770","model_order":4,"model_table":[[0,0,0,3],[1,1,2,2],[2,1,2,2],[0,0,0,3]],"primary_rank":442,"primary_unique_false_pairs":604,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx770.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx770","source_bits_payload":"eNrtWcGOozAMDVEO6Z4AzQcAYqR+RoRygD31kxipK9EbU+0H7Kdu4qQtndhaMZPksBofSquoPOz42S/mF1MFUwzsBT6VhMvvHn5M3F4Es79UoTj8IOwPtcBaauE4EQseGDHOCnzhxEb8P3OpWIE+9Zlx2aCu9O+6ripk5fXSX5cFdcX8RwvMle7Sdx3yl5/11FcV4k7pLrUKXHEerqoOXYF1UcvAFQDo1+Bmrwf72byJMGzbmxzZePvaPD3rDIlzu61iOe2YFa3NCeY3LJM5nmeyOWuWkAUhiQ2mxpS5wJRsZpbNObK0JTGywqYhG1Xo05DtOnZdpn2br7qetM7kmk/9TKXrh2tHh0xkg4soVR6yweZl4oDTAGseDjQuS/hNLcikaC/saoGsUoI+kNTDeeNRAa5m6GzTjQNpWe46GzQcy4HZesiZSEW2DRCXJmMaBphJTBYPIOXdkixVG283QNK7VaRq443YABXOrSaZ/nKdbbANZ+wui6yqrtNatueEnQ2A7Amq7QZ9XgxYko07XR9A9iCn9bKUlQFLsnHuTAhAVnSdXSjP5ZCEbO5oCkC24ZQulOWQpDI7GQlA0HB8KAeZRDQ4GQlAkJoulINMcpbzMvLOAR9K2Ypvsn2T7f8nG3nT9aH24pGNXKnvsiiekaRS/CBsa5VRyUYVjLF5M57h48LPk41aOfRGLBBTy88aObht7HC2X4338UKpCupw2K+CzcJ4XsaLpJOR2H7aeeyqeMG6eMrSyUiMbBaoHo3KE9GUJT0gAaD6oNkS77xDDkiAbIYDklVepKcckADZgAM8Itmgs1Fks1N47UV6tM6GZDgA2ZcBhmyxjnE+9ceQ4OUYpo1C5gJqx2Mcb1ELvZvCtMGawZ7BSvuIGup0kDYf5wL7yEa9qyHS5otku5eof58msbdE+wYkGz3wZMjW918975+2euDpMXqkRodtcF95GR4l6kP6q4ASUKMRBuyQkZzINaR02hodkm2XjCRyTYWlEwmA2dxlR9P7C7j1yfQ=","source_count":1625,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWcGOozAM/dT9gFWXW5Gm0vBJPS0cIpTPqDQR8AEj4LTNIQrZxKEtndhaMZPksBofSquoPOz42S/mxfDFcAP2Dp9cwuWngB+1dhdl3C++cA0/CPtBLZieWrjUxMIKjJg2C75wNg3+n2rmZkGf+mS0HFBXxC82ThOy8nYUh7JEXbH/YQpzpTuKrkP+8nusxTQh7sz+MvLAFe9hwcfQFVhXowxcAQBRBDd7u7rP4VWFYdve5GKa29fh6VkrSJzbbbnJaZesaH1OsHXDMpnneSarsmYJWRCSWGtrzJwLjMuhMtmcI0tbEiMrbBqyUYU+DdkOTddl2rfqwMaasUyuramfqXT98e3omolscFEzz0M22LxMHPAaoMjDgcFnib6pBZkU7d0cHJBTStAHknpYbTxawNUMna2+cSAty31ng4bjOFA5D7VRqci2AdLSZsxgADOJyeUBxFe3pEnVxvsNkFzdWlK18UFtgBbv1pBMf/nO1rqG03THUk5T1zEm+1PCzgZA7gTVdy07lRYsycadDw8gd5BjrCznyYIl2Th/JgQgJ7pOPpSnuU1CNn80BSDXcGYfyrlNUpm9jAQgaDhrKFuZRDR4GQlAkJo+lK1McpZbZeSdA2soZa++yfZNtv+fbORNi4fai0c2cmW8y6J4RpKK66tyrVVGJRtVMJrh1XqGjws/TzZq5SqsWCCmlp81cnA7uOGsKKz38ULJF+pwKAplKmU9n+NF0stIbD/dPLbgejFdPGXpZSRGNgc0NlblqWjKkh6QANB4ZaaMd94hByRANssBaaZVpKcckADZgAM6Itmgs1Fkc1N4tor0aJ0NyXAAci8DLNliHePW1G9Cgs9NmDYcmQvwHY9xuUUt9K4O0wZrBnsGK/0jaqjTQdp8nAvsIxv1roZImy+S7V6i/n2axN4S7RuQbPTAkyFbL7563j9v9cDTYwikRodtcF95aR8l6kP684ASUKMRBuyQkZrINaR0uhodkm2XjCRyjYelEwmA3dxyR9P7C5N8pzM=","target_count":60951}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
