from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":603,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_order_witness_tail_probe","model_idx":84697,"model_key":"high_order_witness_tail_probe|n=12|idx=84697","model_order":12,"model_table":[[0,0,2,2,10,10,0,0,2,2,10,10],[1,1,3,3,11,11,1,1,3,3,11,11],[0,0,2,2,4,4,0,0,2,2,4,4],[1,1,3,3,5,5,1,1,3,3,5,5],[6,6,2,2,4,4,6,6,2,2,4,4],[7,7,3,3,5,5,7,7,3,3,5,5],[6,6,8,8,4,4,6,6,8,8,4,4],[7,7,9,9,5,5,7,7,9,9,5,5],[6,6,8,8,10,10,6,6,8,8,10,10],[7,7,9,9,11,11,7,7,9,9,11,11],[0,0,8,8,10,10,0,0,8,8,10,10],[1,1,9,9,11,11,1,1,9,9,11,11]],"primary_rank":443,"primary_unique_false_pairs":603,"rule_id":"false.finmodel.primary.high_order_witness_tail_probe.n12.idx84697.v1","rule_key":"false.finmodel.primary.high_order_witness_tail_probe.n12.idx84697","source_bits_payload":"eNrtWcGOmzAQHSwfzA1QPwCQV8pnWJEPYU/9JK+USuSWRfsB/dTOjNlUi0036TJSpYIiEnDgecZ+b8bjH8oV4AYFeLxZOi8u6AzfwBZ4UTjFLdOp7/lPH4+f9tU3dZ02wNPFTuOYaTgM+IzXaYMb+ovt+8wjz81g67pIG75jty6jSRvC5JvB+8y7yJSMIX9rytVlLEFT2otWOZhnNVjIWIKm8Ffq5zAxwjXtXByvYKfUFEbIdO6JG9oXu+xbBSc8G/oENIyvAr2/pSfMu4sDODLv44jReJ7JRVXd9Ud/ro4GBI44cRiIndH33iPm0RQSaHHQGYjGBM0aTV0fTScBNs89BqJ5O7vSdFoCLbKZgZg+0ZWmO0uAzUxkIGJxF13ZnSsJtFkQGIim5uzKc6Uk0KIudTcORFfi/JcA28m2k20n2062nWz/KNlEBmuVbKJg/wXZOKcGoBki50gi25y807rD0cInu8jYjGxxDYEc4LRecFbukW0n251k080IV6dq6MHDCDJuvEU2AmpOrXI6GKjhKEY2AmIOqNLjGrmq2tZBIUQ2tog50L4YXK+3tAyXAQuTa0qtT/1LgMGiWf1RhwBFkIlszW8gqpog2QB/ggizuQDDQC3YV9AByYaulLEs1oEIyLlgm0By3DocNpn5fyjZItsYc/WK3OelDPtTVUwis1wvzklklqvlTicQ7NZLlRLBbrViChLBbrVw277HIL0l2dbqx7dgt3lky3Q/SGSWMY3Mk23mwHauXCcbxyAKdqjQBf7cImdYJxsBcbCLecMWq2EkG701RzYCYg5gXA3bRNY5smWO0taxCo+uHCmWbxTZst1mIHvVPtB4qY3Ipm4SlQqy+vTWYyWOw3CTqCIVZPj01mOB6KmcJSoryMtb5fJfJDNtr+4m29peTUY6S1st/VUUSmlt7pxBbwwS9GQSQU72qzK7RJTfYsZU3Eu2tZ2rjHR+ORisb6Clyh++HAyem3muZbOfjEYnpOzVw2QjifqUWaTRS6woaXcCHsqbRC2ZhYuCpUYPyaBpeMS1vwBimYlM","source_count":3152,"source_output_dir":"organized/mining_outputs/out_exp109a_high_order_witness_tail_probe","target_bits_payload":"eNrtWcGOmzAQ/dR+wIrNLUiNtP6knpYcrMifEWkt4AMq4IYPlpnOjNlUi0036TJSpYIiEnDgecZ+b8bj78FMYKoAeDxZOi8u6Aw/wU54MZnALcW5rvlPH49v9ll3fZ82wNvRFmWZabhW+Iz2aYOp6qOt68wjr11l+35KG35gt46lSxtUobtK68y7yJSMIX9rysFkLEFT2qMPOZjXUFnIWIKm8FfqZ1UwwiHtXBwvZYvUFEbIdO6NG9oXu+zbAGc8O/ooNIyvFL2/pSfcu4sVGDLv44jReJ7IRUPf1Bd9Gi4OBI44cRiInVHXWiPmxU0SaHHQGYjGBM0qXd9fXCMBNs89BqJ5O7vSNV4CLbKZgZg+0ZWuOUmAzUxkIGJxE13ZnAYJtFkQGIim5uzK0xAk0KIuNTcORFfi/JcA28m2k20n2062nWz/KNlEBmuVbKJg/wXZOKcGoBki50gi25y807rD0MInu8jYjGxxDYEc4LRecFbukW0n251k810JBxN6qEFDCTJuvEU2AurObTBeOejhIkY2AmIOhFHjGnkY2tbAJEQ2tog50L44XK+3tAyXAVOF6Ubvz/WLgsqiWfXFKwWTkols3W8gqpog2QB/ggizuQDDQC3YZ/AKyYaulLEs1oEIyBhlO0Vy3BocNpn5fx3ZIts5d9CB3KelDPtTVUwis1wvzklklqvlTiMQ7NZLlRLBbrViChLBbrVw277HIL8l2dbqx7dgt3lky3RfSWSWMY3Mk23mwHauXCcbxyAKdqjQE/7cImdYJxsBcbCLecMWq2EkG701RzYCYg5gXFXbRNY5smWO0faxCo+uLCmWbxTZst1mIHvwWtF4hY3IFm4SlQpy+PTWYyWOa3WTqCkVZPj01mOB6G2cJSoryMtb4/JfJDNtHe4m29peTUY6Rzss/TVNIXjv7pxBTwyifOESQU72qzK7RJTfYsY03Uu2tZ2rjHR+ORisb6Clyq++HAxeu3muZbOfjEYnpKzDw2QjifqUWaTRS6woaXcCXsebRC2ZhYuCpUZXyaB5eMS1vwDp2Ofb","target_count":59424}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
