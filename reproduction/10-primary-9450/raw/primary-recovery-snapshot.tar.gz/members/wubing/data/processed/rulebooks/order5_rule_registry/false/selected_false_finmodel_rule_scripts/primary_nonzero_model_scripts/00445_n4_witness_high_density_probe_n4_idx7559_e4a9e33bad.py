from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":603,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":7559,"model_key":"n4_witness_high_density_probe|n=4|idx=7559","model_order":4,"model_table":[[3,3,3,3],[3,0,3,3],[2,0,3,3],[3,3,3,3]],"primary_rank":445,"primary_unique_false_pairs":603,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx7559.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx7559","source_bits_payload":"eNrt2T9IAlEcB3CzBl3CkIigIW04KCiooSA9SoxquimczCGIIMhFKDU5CYMjG2poiMDLRguiSbRSh4ggolqCqLiICoeytPAPevcr3apb5G3x+wwPHu/g+36P73Y1CoR+0YyqvleVmqvs+qLl1Us5dC7lj88Sye7g4pRpZKAOnwwhhBBCCCGEEEIIIYQQ+ncSUFH790SCP4jT5kAM34j9MtewgOgp2sPFWVZICWvG6RRbT5zG8nap1y0zWp7lQ11CyZ593l46XAdY3jsnDrs3BP2dGb3MCWNINww2WR+HNEady/TpW2FUxGklylGwjcv8vLkHitYnM/ED1RZlZiTQZtQ1pGFeqAJx2rtU6YFNzOVe43cpQfTss5bsTgQiu1KxmBVmcm9S7C7e4b66hRbih5ToSg/AE4rNf8SvN3bbs5MS9BzTH0CP2WIF4eXM0ujuAWie4IlHSzhN5R4Y0kfDdVbHatPgpy+pvtSaaF1g7qFtoTN64m8tNySp1vEa4tHyTLkHHPB5bvMUMnouoDEWgDmhjoCZN188sc4GM8MFSkA9apUKuU5W09Mvb4v3Vg==","source_count":2004,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNr7938UjAI08H7bdyD5/Vs5mHfcFUTW3+i+1/oXRZm9+Nm4qul7t+//PRpko2AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBsAP2DGDwB1OGkQEDUGxbOwOThwrTESzOWMHA1MQywYOlo0FBUCHr0BTBho8U29aQMIHxRAsWr7E3JIReUGCewCkZUuqUxsBQ7GdAsWXyh+NKLvLexSKz4TDfu30vFknven/oXute7ur8Dd8pto35RjfbgoVYJm/kGW4cvCvO6+D8PfbG7g2MDG94v/2j1LJ6BhIAxbbxM4LTwQImDg4hByVBBaYml4YVnMFuDG4BjCwsnAoTOQQYHZUcrrRoKjM8pjggGQ+C0wFDU6hjM4+DWkrAVc6ZjAxnLA/yMBxctcCRTUHYaMWrljMMDM/mJFDsNfu2vaB0cJjPesfvRd15L/ZxV4t/03uz9+C9xHbZO7UXXc1L7oNSiPi3ewnvKfYa+wZQOihnSGAvjzdh4L1bnvj+EBvDBvMb1gwbmnfrSzW0vdu9oTyRmeGG9Ju//7GlSVLSKQDc5nnR","target_count":60572}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
