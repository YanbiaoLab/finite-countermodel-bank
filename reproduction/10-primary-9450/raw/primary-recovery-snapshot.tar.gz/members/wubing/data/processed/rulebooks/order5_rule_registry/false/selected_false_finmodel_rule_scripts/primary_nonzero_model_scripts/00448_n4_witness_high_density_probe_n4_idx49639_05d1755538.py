from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":599,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":49639,"model_key":"n4_witness_high_density_probe|n=4|idx=49639","model_order":4,"model_table":[[0,3,0,0],[0,1,1,1],[2,2,2,2],[3,3,3,3]],"primary_rank":448,"primary_unique_false_pairs":599,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx49639.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx49639","source_bits_payload":"eNq9Wb9r21AQPr0qReoPkJRQmk6yIhcPod3a9WHUIsdLhg4JZAiBmg4JtHToqoACClkSE0zBi8eObQom0K2EDIXuKZnaP6B/Q98PhxbrvcbGeneDbHOSPt3Tffe+O+8RCkBd4HZc50dqiR+5OFJxhAUIxQ9K+GnQBaUNln21A+rZDnFUjkZr+ShJ7LKDrm/1648ixSUrGgxY7WkcGaGB2rOgu1doexpPLbPVoTiW5goqFk9lRBvKyJOOn5Gd2JpLR6HYD8qhiI/4kI575AOHVmn5ZexXUcrPTJ47Hto/392Qp1HsU0CwRps/dRb3PhQIaDJ/D22MyGAQf0oC3ydOiIF2XB+u/4qaKJFBFggmXnT6i9Di+RQRg2irPZG6l9tvny4JbhiNbQVarGhs9hk1bY9yvlj8qxkw6m4esLtvf/5+R6Tm63dLQCVHTZCtFbMqndd774tDnppRlCRF4TW1JW82su3H3aL4yIG6aRQ1k7xwfL/p1AySbfij0zkPWklyWnh+LWJgthmyddei6OuT9kaytrV/4Mz7D6ON5H4tN0K2k7N7DIiR7cvi5fIb/+fv82f5gfM494yQjaQE0OxbYOGBMbL1AS04rSQyYi/3d3qnBRLYQEbVxdrZxMsL2i8SjJ0NEE0rdY3YLblXuzhks6SMPLKZuuNa1DfJ9AbEiIVkThyxZCRmirB2kYh+wMIILvMoYUAOTmie7Pfc2LNC8zKyyZbQg3AXR0Y6Aoj1hrZoaz0/NCgjHctGzEhto27CRk02Us+WYzI7k10+FtkkEM8UBLIRwJSRowkNDpqDmSNQF3u19qWmpEr5rJ8zimWeb51VKfiOYej+h9XVyqKse8a7UO1LDStN2NXeRYd1oVp/tam6oo+aJU988bxSsq0TfUGD7OZliiMj+Rw5ozcAKtwY5rSRcSB4VfHOphsXBCkTC8RNoML2MYdAvYUyIBvScNcB3+JyqIrylmkHIQyIkS02sbMpjJcXMYWvsGxps1+O+6uVeKP/j9LyXVWtvnJONEWpabTlqpUfQ9Xqqxa9mJpsipxUhEEHlqLYTC8jFWaVacgaktlemxYs1KVNBQMSOtGgZNYe+WpAQiek5qwDEsm5uzrNV6rRE6y4vmf7W6KuReM1eoLTrpWRCgVEbpdrtKPIsWnI9gf3kZdq","source_count":1256,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNq9Wb9r21AQ/hv6B7RTaPZCh2C6FUKgaceOXgzFBCdLiKCCaO1QWkiG4kLIEHCGDlkci1aYt7ZbSwYTK7KmppREEvSHRKM+Xd8Ph5bovcbGeneDbHOSPt3Tffe+Oz+lBICkwG1lyI+kED9scSTiCGcQih+E8tOgBUqrH8VqBwydLZqpHIPe0arn5WUH6ew0hp8CxSWHGgw4aGocDiWR2nOmu1eYJxrPyMnVoWSF5goiFk9lVBvK2ONePcNZzjWXjkPJP5dDER/+GrnqkQ8cFqXll7FfRik/HXnu1dD++Z6GPI38mACCDbr8qR2/+dhCQJP5u5ZjRAZ1/6EXxTHNQgy0leFS52bQR4kMnEgwcb7dOIUez6eAGkQ7aIrUndt+/v5EcMNobIfQY0Vjt8GomSeE86XgX82AkXR3nd19+8Gd7yI1Xz47ASI5aoJsPZ9VaXvYfGKt8dQMAs+zrKSvLXmzkW3Db1nWIw7UcoOg79lWFsf9bGSQbEu32+2FqOd5i1YSjwIGlpshW2s/CO596O55+zsb69l5fBzseV9GthGyLde+MiBGtvunc0cv4ls3Ft7Z69lHOzFCNupSQLO7UYEHxsjWALTgtJLIiL3e2GouWkhgdRlVC2tnEy8v6r7xMHY2QDSt1DViP+VeneKQrZAycjVn6o5r0dgk0wfgIxaSC3HEkpGYKcLaRSr6gQIjOCchlAFlOKElst9L/aQIzcvIPlvCBMJNHBmZCSDWG+airU3i0KCMzIocMSO1jboJGzfZSD2bjclsR3b5WGSTQDxTEMhGAVNGjic0OGgZZo7AUOzV2pfq0irls37OKJb5vFerUvCtwFL6H1ZXK4ucVo13odqXGlaasAfN+TbrQrX+alP1UB81Sx5//m2lZOtQfUED59eciyMj+RzZIb8BKtwYLrSRcSB4VfHOphsXRC4TCzT1oML20YZIvYUyoBzccDODuOByqIry5mgHIQyIkc03sbMpjJcXMYWvsGxps1+O+6uVeOP/j9zyXVWtvnJONEWpGXTlqpUfQ9XqqxbdmppsipxUhEHqhaLYTC8jFVaUacgaktlemxYs1KVNBQMSMtGgZNYe+XJAQiak5qwDEsm5bzrNV6rRE6y4vmf7W6KuReM1eoLTrpWRCgVEf5RrdKbIsWnI9gdU4Nm9","target_count":61320}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
