from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":598,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n8_boolean_micro_probe","model_idx":21396,"model_key":"affine_n8_boolean_micro_probe|n=8|idx=21396","model_order":8,"model_table":[[0,0,0,0,0,0,4,4],[1,1,3,1,1,1,5,5],[2,2,2,2,2,2,2,2],[3,3,7,3,3,3,7,3],[4,4,4,4,4,4,4,4],[5,5,5,5,3,5,5,5],[2,2,6,6,6,6,6,6],[7,3,3,7,3,7,3,7]],"primary_rank":450,"primary_unique_false_pairs":598,"rule_id":"false.finmodel.primary.affine_n8_boolean_micro_probe.n8.idx21396.v1","rule_key":"false.finmodel.primary.affine_n8_boolean_micro_probe.n8.idx21396","source_bits_payload":"eNq9mU9q20AUxp+kSeWQUCvGlC4MNUKpcoKSVTwpCthd5QbJEdQTdAgUskzcLkvrM+QEKpTS3kJH8NILU0WWTKiteUIi4+8tJKSH9PM3M++Pxp8tSZS4tLJBcUyKI/WLoywvDmlYXEgrPy0zi7SWZl29gzLmPi0mjCP5azOeM+5dMedQHznPIeeYBYxGOuYeOeEcssN5OIk0X9PTihSHe3QtRbgVKeUpOK9QSshMim1HZ+P1HRJb73qy4f8zlhXmEMQWBewTBkaltC4GlpY0C0NbFrARBqZyFMFsnmVvcLR/mTuYo2DJKFUDG0VbZOF9FAlYsAXT21sQLA3vf707OgLRvoUPf/y3oHlTXy5eTaIIFmwuIYMNCEtGQBjfEu3EwgMgLHXmwKEc0HccTHWRsxYjYfTbQla20xQo7TUyaZGjHBzsGrpGvgbTse+jKts06uEq2+V0bOMG8kPPEh4KJveHSsDEnUAr2zESNqM7gaP1kdKUJ8mCifPsDlDbe+RAyo3tkl0bchjzb7b6nZil0e4ord+JUVdGpS3ra7bZkq5+1EdaYHRXKH6o95uN+jPe9TL/ojPbiSX8QCnzX3R8Gyk8pdnGfWYbySpbgVxptrKxS65o+FRgto1kk2dvVYOU2crGdj7jm9wbmE3XHkvb69/lAs0GGwsrtvt9s2tk/f+RLstrylD6zFRzWk5eqHEdNKuD49bBFuvKefVWrEs2rdrIMrIaDdDE0ye3xiY4HdyyMbJB4u64hG7Ml0bcDpqwF+Xppqrjp9UsNFv8KGk9pajt5uC80SqlNsG/Dp89v5o8q5vmdlWtaBUAj2rxjyo=","source_count":1100,"source_output_dir":"organized/mining_outputs/out_exp108a_affine_n8_boolean_micro_probe","target_bits_payload":"eNq9mU9q20AUxlW88NJH0C0aSqE6Qc7gli4bJ8tAIUxPUB2hvUFXsSEiGWcVeoKoEcIFL0oxjlwSaiUj6VWWTKiteUIi4+8tJKSH9PM3M++Pxh8zSeTEtLJpcXSKI82Koywv7mhSXMgsP3WsjLRmWwu9gyzmPnWHjMN5mTKeS+5dLucQnznPHefoB4xGuuEeueYccsl5OInUW9PtipSEe3QtRcUVKeUpuKhQSkhfqm3HcuP1S1Jb73qyyf8zZhWWEMS6BewTBkaltAUGZpe0DEPrFLAxBiZyFMGsZ1k/cbQXVjztoWDO2BbTFEXrWv6h5ylYsAWD42MQzPYPX3+/vQXR3vv7e+EP0LyJg7PfQ8+DBVtMyGADwpwxEMa3RDsx/x4Is5MecCin9A4HEwvkrLlIGL3KkJXtygZK+4VMWpSIBAf7Al0jH4LBKAxRlW3gzXGV7dtglOIG8nSeqQgFk38nQsHEXUMr2w0S1qcjhaPNkNJEJCmDiYvSJVDbOXIg5cZ2ya4NOYz5N1v9TkzHaHdk1+/EiK9GpXXqa7bZki7e1kdaYHRXyN2v95uN+kve9Sf/ojPbiTn8QAnzX3R8G6kiodnGfWYbySpbgWJptrKxS65o+ERgto1kk+d8VYOE2crGdj6jk9wbmE3XEUt7nB3lAs0GGwsrtvtDs2tk/f+RLstrypD9zFRzVU6er3HdN6uDo9bB5urKefWWq0s2rdrIMrIaDdAw0ie3xqY4HdyyMbJBEu+4hG7Ml0bcDpqwh/J0UtXxJmsWmi1+lMyeUtR2c3DRaJVSm+Bfh89jWE2e1U3ztKpWtQqAf+GA4f0=","target_count":61476}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
