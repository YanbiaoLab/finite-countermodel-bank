from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":598,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n9_micro_orbit_probe","model_idx":119018,"model_key":"affine_n9_micro_orbit_probe|n=9|idx=119018","model_order":9,"model_table":[[0,6,3,0,6,0,0,6,3],[4,1,5,4,1,7,4,1,1],[8,8,2,8,1,2,8,2,2],[3,3,6,3,0,6,0,0,6],[7,4,1,4,4,4,7,4,2],[5,2,5,2,5,5,2,2,5],[6,3,6,6,3,0,6,6,0],[1,7,7,1,7,4,1,7,4],[5,0,8,5,5,8,8,5,8]],"primary_rank":451,"primary_unique_false_pairs":598,"rule_id":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx119018.v1","rule_key":"false.finmodel.primary.affine_n9_micro_orbit_probe.n9.idx119018","source_bits_payload":"eNrtmTFOw0AQRccbY20BwhUtLihScoQVSNS0VKTMIShWiFwAcQAfgIIj+Cg5AiVdkKwIIcXfsWX7SVhMEWnztf76s/NnJ87GgllldaT1Z2hcFPWiXj6ZiFWikIUC1goICrBMAbkConxWqoBSbpEafX8pTgHXamuUW/dS0gOgkFKT37gOf/Csxqh2l8bF124Bsj2SZNtbkMzePUgWz0lpHySZ3aUgWYVKWz6QbGcJSFaSZPZyQpoNrZFPNJEXNluzrVE29NRWqDSyH1tEE5mjibwhyQIqzc/XbAUq7e2KNNszKe2eNZubrdmW/2b7izcbetmwNxvptVnfbEde/WzHHSMTUvop2WdiRvaZY2Ybt89krUQFZrY4/k9j357CkZ0vKy5O0GJKibySN9sUzTOizTNHJxVHTiqVPiPf8SjT3mZLurH5gccr/yRpkBGKHjXWcjj5sDYwxRg5uGx+XpAgM1eOzlx7SS7pVOtuWHqDruHQzWx9kqLN5jp91W+E+AZt6CV9","source_count":275,"source_output_dir":"organized/mining_outputs/out_exp106a_affine_n9_micro_orbit_probe","target_bits_payload":"eNrtmTFOw0AQRdNRcoQcxUeg4AA+AOICILQFh0gZKlpqJNAegTIFhWmpHEGxMs56kKwIIcXfsWX7SVhMEWnztf76s/NnJ86VebPE6ijrT9+4yOpFvbw1EetKITsFrBTgFWCFAnIFOPmsUgGp3CI1hv5SogJe1FYnt+6llAdAJqVWv3Ed4eBZjZEs3oyLk8UOZLsjyZZPIJmdB5DMbUlpZySZPZYgWYJK29yTbB8VSJaSZHb9RZoNrZFTNJHvNluzrVA29NTWqDSyH5tDE5mjiXwmyTwqLczXbBkq7eKVNNsNKe2BNVucrdk2/2b7izcbetmwNxvptVnfbEde/SzHHSMrUvon2WdcQfaZY2Ybt88UrUQZZjY3/k/j0J7CkZ0vK85N0GJSiVySN9sUzdOhzTNHJ5VITiqJPqPQ8SjL3marurGFgccr/yRpkOGzHjXWcjj5sDYwxRg5uGx+XpAgM1eOzlx7SbHqVOtxWHq9rmHfzWx9kqLNFjt91W+E+AbeiUu5","target_count":62301}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
