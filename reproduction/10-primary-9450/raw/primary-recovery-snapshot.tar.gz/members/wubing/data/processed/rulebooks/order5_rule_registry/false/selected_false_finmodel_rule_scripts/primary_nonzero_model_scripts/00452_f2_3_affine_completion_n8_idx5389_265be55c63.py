from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":598,"excluded_block_payloads":[],"law_count":62576,"model_family":"f2_3_affine_completion","model_idx":5389,"model_key":"f2_3_affine_completion|n=8|idx=5389","model_order":8,"model_table":[[0,1,2,3,6,7,4,5],[4,5,6,7,2,3,0,1],[0,1,2,3,6,7,4,5],[4,5,6,7,2,3,0,1],[2,3,0,1,4,5,6,7],[6,7,4,5,0,1,2,3],[2,3,0,1,4,5,6,7],[6,7,4,5,0,1,2,3]],"primary_rank":452,"primary_unique_false_pairs":598,"rule_id":"false.finmodel.primary.f2_3_affine_completion.n8.idx5389.v1","rule_key":"false.finmodel.primary.f2_3_affine_completion.n8.idx5389","source_bits_payload":"eNrtWFtuxCAMxBYffHIEjsLRfPRqSWJsMGkrNau2eLQi2bwQ49dgCB0xhNp+r7M1YsjtCDwEDD+NGko70mvID00iVsxL+WTxfw9FmhQvdh0Oh+NLSGcKxisVq1tDMgFO20fyGUH9ze0QWwKuvHxQpeikhinmZwVXECZmRb1CTbSeqAw20FW1P3s7B8kS7Xgw2LIi+zJM+l6wXc/TlsF2uChMrkoTWVl7NBh6dF+nx5OtOGtjHGV5Up5I9tceUvO/HtAczfA1g7WoakEdKUta4Y+K/xzZPEneApXSc7cTio/XKc0stkcxOBwOh8PxDhS5FYVZW6hil2YdQkvhfSMjcaq0VdfGyH+yIS0tLbCdjExMVJ70Shksg6ZFyrKd4Pg/DRLZr8CxPQFWFwOstkSygo30KW+po7xtXDL652h7YbF3jg7HxqAjXjLHbJXxQnOap0UYecJ/J1LXNUXv9rk7ne8uGY3jvG4dfABylxx+","source_count":218,"source_output_dir":"organized/mining_outputs/out_exp102a_f2_3_affine_completion","target_bits_payload":"eNrtWFtuxCAMPLqPxlE4Ap98IJtqSWJsMGkrNau2eLQi2bwQ49dgqh2l1tB+r7M1Sk3tSDxUrD+NUGM7wmtID00iVsxL+WTxfw9RmhQvdh0Oh+NLyGcKxisVq1tDMiFO20fyGQH9ze1QWgIOvHxSpeikhinmZwVXVCdmRb1CTbSeKA420FW1P3s7B8gS7Xgw2JIi+zJM/l6wXc/DlsF2uChNrgoTWUl7NBl6dF+nx5OtMmtjHGV5Vp4I9tceUvO/HtQczfA1g7WiakEYKcta4Y+K/xzZPFneIpXSU7cTio+HKc0stkelOhwOh8PxDkS5FaVZW6hil2cdAkvhfSMjcaq0QdfGwn+SIS0tLbCdjMxMVJr0Shwsg6ZF4rKd4Pg/DRLZr8CxPUFWF4OstkS2gg30KW+pi7xtXDL652h7YbR3jg7HxoAjXhLHbJDxAnOah0UYecJ/J3LXNVHv9rk7ne4uGY3jtG4dfADZ2lS4","target_count":62358}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
