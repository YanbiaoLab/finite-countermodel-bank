from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":598,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":6442,"model_key":"n4_witness_high_density_probe|n=4|idx=6442","model_order":4,"model_table":[[0,3,2,1],[3,1,2,0],[0,1,2,3],[1,0,2,3]],"primary_rank":453,"primary_unique_false_pairs":598,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx6442.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx6442","source_bits_payload":"eNq9WUuS4yAMFRQLLTkCR+FoZDH3HvM1AslA3N1UdyUBI9DniSf8L3gA7yEAgLm+pb/4zYDFNKLib+MgjsSx6wdcI6CvfwQVJ+ZJ4HJvmgekXTIs3KN3Q3BxwOgyGluSWBaO00KeW5vWWEQCHbDg4w7QQNYgiU8CQxYdR5XrJ2UlQasmsTQHwRe9RlWUqXuEQZXcG3dM5hSDOlundapAFebIgLXZmD5+qLql8iiyljRlIT1YpaqSraLvLVVVXNoc3ZhpFizrqTx3eOx+GFoQOcgeQ6Bu0NSK0Q2hOU5sRhoo1p7VTUPeUQu0sIJpJ6OmbBPjNy2kGGkWekuzzc476R2WF0KyaTe6ICmVw00/7P+hGWOrikg14RCmQdmFWk+tINHPvnWMa1IewfScfZarBAMLCYHmm3s1hBet5KUUlYEYyGcoDz0PwT1YhWmXgA/knDIax3PZNz/+bcN7IQZsg9U+Pdjck1DJmVKG5aw2nw+if0QL15DUJIzQsGCTBE3+EdJZXQjnITeAbQE0v8iRF9iS691sbMvZMYFNVHGFjXJkJbFqsnyYfUG5wxagiQDHWm0vR581+QBnqE7a1+c4Mn4LbCu3/SDYwjqduSwWueSbiIjupEUO4TfVeADbzAeS1ebw73yjjt0nc8xqNRxXexGS5WSb+QAXNj271d+spu+gNrAAG5JIDKfpuNFIJkVthc3pyYYtaQ2u1TOimKP9rP0sjVQr7iCVMEzYcISIYyJOBlvjq8sUZWvqTBsT1dD+nEZy9WIsorSQRNwW2O5z9DMNBT+B7R2NlMCWFtJzDKBZpWMl00gRbJQPzDXbCxo5F/u0APcNAOYbd9GTjSHfNUcvqo8jPsLUbFYC2w/UbCKN3MrR63pq72RjrPYIth0OxNRs8Is125/SSN/SiFDpjmBTe1WicLI1VA8XDYV8jyHp3hhSqcby86VVjTGmiytIjiAn3zNqQhYdX8ZxOUx/QSM93acBIZL4+FdS0o6obuzu1qfvqrES4FU+vmq2doS6Ic7MTayw08+/AZt0cZsWcsQzYZv1h+0Lko6UMuXoUP1/RSNTVMY7soHGDXc/uGNHfEJGzIWN3Q0Ugbn9eZO1ZBpJrOYkZglnYDOWJ9+c1dT2SSaCDZBlUQgC+9dbFnuikUw+UsAednaph3oCm/BqwZH7VN3ykf2KGxMa6aGnCCjUbHp6qXF4ypWrf2q1tuZQ6nNdN7bsVuhY9hUCwweYrnBCtSrYaNYyArLIta79Atr16r/LWkZCFveW6KiV28i8EJIAZkp9puuI6dWazc+Jfa7ZBLAd08iZj7M1G8fHDyxbTjYEuLNWaEN+ftofX0HOJ5uaI5u5IGG6ztjrf23Qd34=","source_count":970,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNq9WUuS4yAMvfcswtE4CkdgqQUFGvM1AslA3N1UdyUBI9DniSf8T2lErVEhoru+pb/4zaGFNBLib2cwjsSx6wdeI+ivf8AQJ+ZJaHJvmoekXTIs3qN3AzRxwPkyGluSWBaO01SeW5v3UEQiHbCo4w7AYdYgiU8CVRYdR4PpJ2Ul0YcmsTSDShe9RlWCq3vEQZXcG3dM5hSDGlundapgFWbIgLXZmDp+hLql8iiwlnRlIT9YpaqSreLvLVVVTNoc3ZhrFizrhTx3eOx+GFsQGcweA6Ru8NSK0Q2qOU5sThoo1p7VTUPaUAu0sMJpJ6OmbBPjNy0UGGkWe0uzzc476R2WFwKyaTO6ICmVw80/7P+hOWerikA14RDmMdiFWk+tIFHPvjWMa1IegfScfZYbBAMLCYHmm3s1wBet5KUUlYoYSGcoDz0PwT1YhWmXgA/mnDIaR3PZNz/+bYN7IQZsg9U+PdjMk1DJmVKG5aw2nw+if0QL15D0JIzAsWCTBE3+EdJZXQjmITOAbQE0vciRF9iS681sbMvZMYFNVHGFjXJkJbFhsryafUG5wxagiQDDWm0vR581+QBnqE7a1+c4Mn4LbCu3/SDY1DqdmSwWuOSbiIjvpEUOoTfVeADbzAeS1ebw73wTjt0nc8xqNRhXexGS5WSb+QAXNj279d+s5u+gdrgAG5BIVKfpuNFIJkVthc3pyQYtaQ2u9TOimKP9rP0sjQwr7iCVMEzYcISIYyJGBlvjq8sUZWvqTBsT1fD6nEZy9WIsoryQRMwW2O5z9DMNKT2B7R2NlMCWFvJzDIBbpeMg00gRbJQPzDXbCxo5F/u0ANcNAO4bd9GTjSHfNUcvqo8jPsLUbFYC2w/UbCKN3MrR63pq72RjrPYIth0OxNRs+Is125/SSN3SiFDpjmALe1WicLI1VA8XDYV8jyFp3hgyhMby86VVjTGmiytIjiAn3zN6QhYNX8ZxOcx/QSM13adDIZL4+A9S0o6obuzu1qfvqrGi8FU+vmq2doSaIc7cTayg00+/AZt0cZsWMsQzapv1q+0Lko6UMuXoUP1/RSNTVMY7soHGDXc/sGNHeEJGzIWN3Q0Ugbn9eZO1ZBpJrGYkZolnYHOWJ9+c1cL2SSaCDYFlUYAC+/dbFnuikUw+CsgednapR3gCm/BqwZD7VN/ykf2KGxMaqbGnCCDUbH56qXF4ypWrf2q1tuZQ6nNdN7bsVuhY9hUCwweYLnVCtSrYaNZyArLIta79Atr16r/LWk5CFveW6KiV28i8EJAAZkp9puuI6dWaTc+Jfa7ZBLAd08iZj7M1G8fHDyxbTjZAvLOWakN6flofX0HOJ1uYI5u5IGG6ztjrf96h+ak=","target_count":61606}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
