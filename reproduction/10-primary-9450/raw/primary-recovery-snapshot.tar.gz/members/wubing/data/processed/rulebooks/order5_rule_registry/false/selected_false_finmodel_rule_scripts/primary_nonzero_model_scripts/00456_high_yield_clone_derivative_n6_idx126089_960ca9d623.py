from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":592,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_yield_clone_derivative","model_idx":126089,"model_key":"high_yield_clone_derivative|n=6|idx=126089","model_order":6,"model_table":[[0,4,4,0,0,3],[5,1,1,5,2,1],[1,2,2,2,5,2],[3,0,3,3,3,4],[4,3,0,4,4,0],[2,5,5,1,1,5]],"primary_rank":456,"primary_unique_false_pairs":592,"rule_id":"false.finmodel.primary.high_yield_clone_derivative.n6.idx126089.v1","rule_key":"false.finmodel.primary.high_yield_clone_derivative.n6.idx126089","source_bits_payload":"eNrtWLFu2zAQPUpyxQZBLQceOhSNKqiAP6FTyhQerE75hH5CugcIYbRAswVBPsCf4i79Dn2CxgxGXIk0nNq6sy2EPHTIDTSkM3k86t7dO/4UCmAeQyNXZpybEYaiGZV9OIbUPKjm5WIpAJVy2ccVsLwmFA/LEFfMl6fElDMAiSoqYlugv0OEa46JGTDLPxCaj68lvtgoIGYoqYidUTPWrpQtV/rU1JUrUdxyxZ5Wft6yYo3MVEshN5aXT6c32/pjuvHFjITAIg/G2DWPMbCu9XmMldaa4LG2MMY+8xjT1rWYx1plrTHFyKMxdspj7AVsL2D738AW769rDsH2VHcZwPYPqiP/YAu3KrRXsHGh2oAtrEzszwVHkFzBownJhAVsfeuR4gGbYPxq8EfE7yoOVJvY+FTq8H3NLMWK53sF3NtYMR5kqA20f7N8vW+cIQL3+d0ky6Y5T2W7G58U43HC49pF7dnNLwmTgAPdX0+KfDAQDdhkqj0bU0V2k2eZKTTSe2UbFevGXfs/SLJR9yEzefujzlRIk+1DhpzpXycKRAQXPNaSwEZ9zeqUfy+/wBHfQSp7XTLiSVuSNf3voZELp91cubs51G67ucXu5bTTHlzvbg6jXLhkYdWe5tBt/jyjg/INrLi6OxpJL6ebjo6LRkaJRq5xn0kjSc8aQ477ffomvCF8gXbL+O7zFE+PqiF8jmmDzijNZFprHXPZJKBKaG94C3DuFnBkmjDX/Y5buRXYsCyPIB5FQ6/DBQmd5Y8Oq4OTzmC7xMp5+9Ullmw60UiLrEQfkIuLBE9uB0tE+UGFzXMvSIzEnkvoxgUJsuvUPft5ZX+mbT+wVh8DX4dNqcE6RW0J1n0oOOzdHhrZa21aB23XgjaKI93lvP8Cfp7Iag==","source_count":1584,"source_output_dir":"organized/mining_outputs/out_exp129a_high_yield_clone_derivative","target_bits_payload":"eNrtWLFu2zAQdeAhoz5B39Gl/hR/QBBkS4EWBgNkbz6hn5Cp8mA0bKZ+goEKqlJ06GDEchGkVC2JV4k0nNq6sy2EPHTIDTSkM3k86t7dO77VEmCQQyOXZhyYEWa6GaV9eIDUPMjmZb+nAZWwt8AV0LsgFMe9ElcMenfElFsAhSoCYlsg3kOBax6IGTCMvxGar78Vvti0ImZIJYmdUTPWroQtVxbU1JUrRd5yxZ5WfNOyYo0MZUuhNpZXT6c33PpjuvHFjJTAIsfG2AWPMbCuLXiMhdaa5rHWN8Y+8xgT1rWcx1pgrTHFyJExdsdj7AVsL2D738CW769rDsH2VHcZwPYPqgv/YCu3KrRXsHGh2oCtDEzsDzRHkFzCkQnJjAVsC+uR5AGbZvxq8ErnPwIOVJvY+BKK8nvNLPWK53sF3M9cMh5kKQy0X7N8vQ+cIQIn8ek4SUYxT2U7ndxHk0nG49p17dn5GwXjigPdH++jeD7XDdhUKjwbk1FyHieJKTTKe2WbRuvGXfg/SLJR9yFDdfauzlRIk+1DZpzpX2QSdAHXPNayykZ9zeqkfy8/wSPfQUp7XTLlSVuKNf3voZF9p91cuLs5FG67uf7u5YTTHlzsbg6LWLtkYcGe5tBt/rylg/IXrLi6OxpJLyeajo6LRhaZQK5xn0kjSc8aQ477ffomvCF8lXDL+E7iFE+PsiF8jmmDSCjNeFRrHXPZrKJK6HJ2BnDjFnBkmjDX/Y5buRXYsCyPIB5Fw7LDBQmd5R8Pq4PjzmC7wsp5+9UVlmw60UiLrEwckIujDE9uB0tB+UGFzXMvSIzknkvoxgUJsuvUPfv5Y39GbT+wVh8DX4dNyfk6RW0J1n1IOOzdHhq5bG1aVG3XqjaKC9HlvP8CzdOovQ==","target_count":60992}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
