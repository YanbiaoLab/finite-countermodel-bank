from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":591,"excluded_block_payloads":[],"law_count":62576,"model_family":"witness_residual_coset_splice","model_idx":44335,"model_key":"witness_residual_coset_splice|n=4|idx=44335","model_order":4,"model_table":[[0,1,1,3],[0,1,2,0],[1,1,2,1],[0,0,0,3]],"primary_rank":459,"primary_unique_false_pairs":591,"rule_id":"false.finmodel.primary.witness_residual_coset_splice.n4.idx44335.v1","rule_key":"false.finmodel.primary.witness_residual_coset_splice.n4.idx44335","source_bits_payload":"eNq9WUuOozAQtS0W9KwA9QEAuaUcw0IsIKscyZEYKdmlUR+gjzr+gIG4nIkFthcdIafzXLbrvVfFX8QwYkiNT/WXperjh6qHj1J+JEg+Mcz0g2P8uiZQ5Zo49Y6JCRgYBGF44oI6Ak7wjCEMrnpA8j8YEAr9bos8B/7l607H2w0MhYqFcQqFwgVOIlbB5XNmZs6oTzJUzpvKzcT0laKzQtERPlhhh6LmE7IG0KFgx6l9KUC1uOeRrgNbnrZnotc77x5DMccpKloVE2w6sEjjB5F4YDzqLXESQpDRCI7JYoGxtHxJxQcnWy/osI0E5mbYMMn2LeMaoyWbODilRopTgyY6L1ixBiqDhjZd/UjU9UfL0UekZFMfUsCjJJs6vEg5oD3AoxUHR4KLeKlviQFKg6J9qqxWTknpAGjnDlY2IKIQtDkpm22eAft5lLKtTay8LEmoZFsBkRRJf8xW1vjYkWID9LQMR8Wwz0Yu/n+bbABHJ1Dl45Vs2o1owdlcTQzcXvscPJWNjl1dN0Xftl19v6V5Xtdtm1ZDkGQbWwPU0zyv6qYdbgIsiP+6jAvQncqwbrcsF2BBzOW5MEDSdA16K4esCZJsfW2ApOBkeiuzJggzaxs52MrG5GmGsZGAsnU1P9wQrWykEpwlwn72KSZCqEXgZ65Fss27tlU2wBA97F/2MxbCRiq/WspdSwwdYwRxNMg2UitSkNts3rkQfTxGcJD++QmImZ/L1h4C2w0KAMNmh7MGulvKNgFtOLrkNkebxdkYBOgDSSCaCyAqg8mreddsQ2SAXsZB3Gx9wgvQ9quFVX24O1Awhs0OTtv/YATqY+1LNudMIdKBkf5QNKeCMSKyrSuvR3IlH11E0MncltJwYIV1Ia61f9Acl1daoxYdVoU4G7flVQS9JcXHbmXDruKQCkbke4yV00ZC56n6sWwd+f7qf2Ujn5NN5oCk4IS/4SzfMtXuTngI+6NtJIHs6PF+XNrIuTh8Os8APRORbIuEbgy+LXYH2EjXq4UJ6LUuelbmbKYo60ZnHcDRQF/Ax/+cZorC/182LAY+0VUTRVklGYM42spqv8LV/a4GGLuFQLf+geIXWAH4lsivQbL4gRgNEuMH3muQ7GowNNNdw89Xa8v8L3jTI+dZTxx3GKDOzCa30qu0P2natV9tADYSiszvcP8BGTSlZA==","source_count":1296,"source_output_dir":"organized/mining_outputs/out_exp113a_witness_residual_coset_splice","target_bits_payload":"eNq9WUuOozAQPeocoJXOLkiNFB8pq8ACIR8jUlvAAVrAapoFsj3+gIG4nIkFthcdIafzXLbrvVfFF8eMY67Gj/qLB/XxQdTDbyM/Ri6fMMP6wTH+uCZ47Zp4ZI6JCRgYlDN44sZzCk6gHnMGrjrl8j8wEAr5LNquA/7l+0JOSQKGQsTCEIFCQQJnFKtA8rk3M3eejT1v5k1FZmL6SptboegIz7i1Q1HzI10D6FCY49S+FaBa3PMY1oEtT9sz0euddw/zmOMRFa2OCTYdWKTxwWk8MBT1ljgJIcgoBcf0scDw0Lyk4oOTLRN0WEQCczNsmGT7lHGdoiWbODilRopTgyY6anG7BmqChjZd/UjU9VfL0W+kZFMfUsCjJJs6vEg5oD3AuRAHR4OLeKNviQEagqL9qKxWTknpAGjnDlY2IKIQtDkpm22eAft5lLKtTay8LGOoZFsB0YFLf4xX1vjYMTAD9LQMR8Wwz0Yu/n+bbABHj1Dl45Vs2o1owdlcTQbcXvscPJWNnPKqKtusKPLqkgxdV1VFMdRpkGQ7FQYoI11XV2WRJgIsiP+6nRagC5FhJUnfCbAg5vLeGiBpulK9lWlfBkm2rDJAUnB6vZV9GYSZtY1MbWXD8jTD2EhA2fIKHW6IVjZSCc4SYTb7FBMh1CLwM9ci2eZd2yobYIjO9i/7GQthI5VfbeSujYaOGYc4GmQbqRUDyG0279yoPh4jOFz//ASEzc/1aw/B7AYFgGGzw10DXSxlm4A2HN0gm6PN4mwMCvSBJBDpBBCRwXT1vGu2ITJAL+OgbrZ+sAVo+9XWqj7cHSgYw2YHp+0/Ywr1sfYlm3OmFemAaXYomlPBMBXZljfXI7kSnVxEkMvcltJwYIV1o661/5KONVdS8YIfVoU4G7fNVQS9JcXzbmVjruKQCEZEe4yV00ZC56n6sXgd+f7qf2Ujn5NN5oCk4BG94SzfMtXuTngI+6NtJIXs6PF+XNrIuTh8Os8APRORbIuEbgy+LXYH2EjXq4UJ6LUuelbmeKYo60b3OcDRQF/Ax/88Zopi/182LAY+0dUTRVklGYY42spqv8LV/a4GGLuFQLf+geIXWAH4lsivQbL4gRgNEuMH3muQ7GowlNNdY89Xa8v8L3jTI+dxRh13GKDO3ia3xqu0f2jatV9tADYSiszvcP8BM0zLww==","target_count":61280}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
