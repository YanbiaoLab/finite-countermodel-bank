from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":584,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":10580,"model_key":"n4_witness_high_density_probe|n=4|idx=10580","model_order":4,"model_table":[[0,0,0,0],[0,0,0,2],[0,1,0,1],[0,1,0,0]],"primary_rank":460,"primary_unique_false_pairs":584,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx10580.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx10580","source_bits_payload":"eNrtmT9oE1Ecx3/v7uCuLTQXKLRDuFxapJEOXRwi1F48EsXJOrm1Xdzrn6EW5c40lZAOqbgWaYOos5OLcsEObqaj22ktBHR4lg4xpPfz3VVapCkm4HPQ9xmOC+/37sfv937f33vkEQBw4Xc8LYVPzyMg+BusjZbTVd0+OeBW3hKUpzpMaa/eallP9JMD8w0Kg9lYhylJQgK1wwzYKP18mbEVgJHM0cACDMLxl7K+7pJ5sVoCgUAgEAgEAoFAIBAIBP8BZ6ul0f7U0LVcqjhaThdntE3dThULpiZxcObvUESIBZj0a+G/YYvAfqMFvswjtDbebllv6jj8eqTF3OBYxTYOMPZpQuPgzMXT4BEbjdd3HSBoET3rIlF0MJf2MAlZLjUSIM7tX0o/xy99B2FETRtxp2/lva5wcOYhupg02hW5vRzlLwaGhw6tqTxCa562ahYPb4jrL8sT5z7kxx8GoZN3m2uXx54VFvp5iG2+Qd3BXMyoP2jU5AxcaGowCQ2SbXAS25nvc7ktvJLLRTnN5UqlNo4XdYmT2O7m77/66jwejlbrxhbio+v2i0n4B8QmJUwAVTFZThEdk/nxCUhcnGXL6WrJ1vpOjuhhdL86jeeH7Mh8RWc7hp3WCqZ5lIRuWkEzk6CW1135+U4CjNB8WQXKkiLDdK9iq64HlfHuWlTb2R7YDM2H9tKftxHN6ULPYjvlrqZD9cp3zMXI3JC8AVgEaPUY2j1FaSa7LD9qSUAicwIm60AEeuzaLjscxFf06F4rKoHDQ8JFXeFxqUhvZnzHVXEHqM/EZkyBq1ImNsrlBjPInz9IXm3g6qy2u+9MsXacqgSofotz2dnqH0nCNRIbcm1ZXYAlqsMsMDnU+exsmkYt18U4aKaHILFDD2myzdQ8FP4f9vYDNvVGxw==","source_count":2575,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmTFoE1EYx79riBlKfYNCoFZvc2zcHCo5dHFyVpG0SFexGRqCTeMdSu1gtbtL283JOonmOHO1YAaXDsUUaXM5MrRQyKXQ9g7u7n2+XKUiTTEBn4O+33BceN+7j+973/97jzyKiCr+jnv59lNRKAr+BhNbuWrGMU4OqNlrFILVDlNiky/i5n3n5MBCkuBeudVhSp1SyeswA8fyP16WDR9xu3I8MI97+PNLZdlR6YJYLYFAIBAIBAKBQCAQCASC/4CvmfzWQW33jV4rbOWqhWV31DFqhaLlhhycyUMEAFsS1OV0+9+wWWS/wUQ54BFaDObi5vUU7NzYjjM3sJk17D5oXVx3OThT4TR4xEaaqUENKZjUKatAfQetmQGoY5lLjUgAi/0fqnfg/GFfO6KEATB0OHXF8Tk4UwBUqNuxbBCbjvLXQlsBjaQ9HqElTls1k4c3gPFbufUvl0sbj6S2k6ujE+837xbnD3iIbSFJ1D29ZaceJ9NBBT8lXFzDJC0nOYnt25lFfQTe6XqUU13P52OwUXBCTmJ7Vnpy85z2YCdarVcjAA9fG7fX8B8QW9iwED3fYjkF0CzmR6YYcnFWzlUzecM9PDnitKP71WmztGtE5lMO2zGMqlu0rOMkdNMKEpUGMZXuyk/WGmi3zac9JCwpAa70KrbMuJTd6K5FxbTh/dG2+e5A9cIwgLVS7Flsp9zVdKje4Lk1G5nbobKPs4jxHkN76vuJepflR8wQaWRO0WIdiGKPXVtlh4PmlBPda0UlcHRI+Oj4PC4VycuKrKkeDCGRmdjsVVQ9wsRGuNxgSqXPffW3SZhccgf7tVXWjmtZCbyzTS47W+oSbah2YyxIT3vzOEMcXEImhxSfnc11iamq0ETXUgBDduihCbaZWkfC/8PevgMViypv","target_count":60001}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
