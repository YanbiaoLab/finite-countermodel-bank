from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":583,"excluded_block_payloads":[],"law_count":62576,"model_family":"dual_product1","model_idx":2305,"model_key":"dual_product1|n=6|idx=2305","model_order":6,"model_table":[[4,3,4,4,4,4],[4,4,4,4,4,4],[3,3,4,4,4,4],[5,3,4,4,4,4],[4,4,4,4,4,4],[4,4,4,4,4,4]],"primary_rank":461,"primary_unique_false_pairs":583,"rule_id":"false.finmodel.primary.dual_product1.n6.idx2305.v1","rule_key":"false.finmodel.primary.dual_product1.n6.idx2305","source_bits_payload":"eNrtmD1uwzAMhZ/AQZ2qHiCwr9HBqHuUHsGjhwARkCHXEpCLyDfQ6MEwSyVLgFjtUvUH5TcYsCj7QSIfBcgA8PiMhY08QzBQvoPEF+4D/hqwWynK9PeBeP1kI3WM3Xra+BVmvqV93nkKRxowDniEaxAIo8x6jU/evGm2FEVRFEVRFEVRFEVR/gFcwlYQi0W1GktbSmJtBTFfXBpVUEslsUONjVxLaq6CWChuZI077Lkk1qvZ1Gw/ZLY2ASeeTN7TwyhVMxlfw2ofmU35zdAwt01g2yFMUiFwaBa2kSJTg5j6Dt7CrUzJJDYOeToCeStddM5ND9EEaTpJyu1MEI/K+1GG91IUL9IWZYAudkqkJ9vfPNlsrgPPboQ/s3SUBt3MLmf94evV3gGCzeIK","source_count":7947,"source_output_dir":"organized/mining_outputs/out_exp121a_dual_product_followup_c","target_bits_payload":"eNrtmD1uwzAMhWl48KgbWBcJoGtlCKAAHTz6CD1KHXjoNWzkAFWnaiD0SiVLgVjpUvUH5TcYsCj7QSIfBSgB8PiMlpI8nUtQvgNDF24D/hqIWynKTLcBe/1kI3WEc7Pf+BU6+sjyfPbsDjxiGPGKsMIxBpn1ZF98etRsKYqiKIqiKIqiKIqi/AOoRKwgZotqNZbWlsSWCmK+uDSuoGZKYscaG9mU1EIFMVfcyBp32F1JbFKzqdl+yGyLAfbUp7ynx0Gqpk++htXumU35zfDYLaujOMP1UiEIWFuKli3xCmumGT4iNMQmGUoBeToc+yhdtMtNDzY5aTpGym3HEI/K+0GGH6QoTtIWZYAvdjKsJ9vfPNlirgNPYYDfkXSUFXNHIWf97evV3gHJpI8d","target_count":54629}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
