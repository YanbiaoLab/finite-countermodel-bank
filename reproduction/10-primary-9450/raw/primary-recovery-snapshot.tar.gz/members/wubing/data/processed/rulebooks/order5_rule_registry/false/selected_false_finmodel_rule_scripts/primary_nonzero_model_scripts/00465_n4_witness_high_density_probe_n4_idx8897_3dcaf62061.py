from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":574,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":8897,"model_key":"n4_witness_high_density_probe|n=4|idx=8897","model_order":4,"model_table":[[0,0,0,0],[0,0,0,2],[0,0,0,2],[0,3,0,0]],"primary_rank":465,"primary_unique_false_pairs":574,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx8897.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx8897","source_bits_payload":"eNrtmUFIU3Ecx9+c0aQix6sMOgznYQehkV46uFm2rNsLgtbFPRCGdeqih5nydpjwZoKKhxnIzAgWJAyFLmO1ESsGT1gjxtKDmWwqzYPbfOLm9n6995AOvTfamK+D/D+Hx4PfD77/3///+/5/h78KwzAn9i8W54RvOH6mAUP8B/ZARBpw+hkccJNKGikxuWLIe1Ua2NgeWoU2v4wKNPVxnhYV1vh34O3ceMfYBP/zoIeP3Qx0LZyL4+K6XNctxJ+08E7HwtiTnvu3+CQVOjQEAoFAIBAIBAKBQCAQiNMMVOKsAmIbFdWUKK1USUyngJizYmlqBdT2IJmmHFrozmp/Chq4qXU4B/NThEaJjeQqlXZRAbEwANW3+6MrC0mPKMKmoTuOf+EGlCjtEMgDYN5Bfhz2RTV3Aj8C0ly4pJDZjM87PUlgE8KeUqPv+fIiawMT6lNgtnwx9HENPB9eHgkanaFeWxnIX+0XFDKb4zMV2AWPVawonQCYtt4pGVWKmI3aBL8RMv2wJarFplqyQI6ylxUyG+/q2x5I3xUuMMHl/C9tdB2XftJmq4CqmlFB1Wi2QFe2Oz4DQ/xlFQELYdZHXxzCZHNRI32F2KD6aK+YPqnJ6Tloc5kbaqseloOc33AA9mcR4YHl8Ypvmm+WmaJGLVUrUavXloT0K/mnKb6X3pg/YTU9jRy/1XCx9q1vdpgMDrc9InaBupF6iGmk3ZsfLwwK6eu0eNucF2+bGtRKhsECaYsAMWL5KswBC0F7S2BI4Q1y3YvrtEJ6Yxx/bQBoKrhOarJV1zY1mm3IsUnx68z07Kfc4PaOWASz6Vr3p+Xapm6z2R1lkj8oZp1Os5RpaZbgzxAMrFa2beo1WyyzDPds5Xnrio/hdA62d9H7HaA/6pNrm7onG7GTCwVpmD+kXzGQ09PeZlMBiKhBtm3ktjKKzVat9hscWYy+","source_count":5179,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmTFIG2EUx98lJmJM4hCLNcGmDloJJRU8CG0oSSsuBSVgoYFS6yHUGyQGbDwwQw6tGeLSqRVBSFxqodDbWpvammTooiUFhwwqGYTa9oilLabUeNe7Qzo0dzQhXgf5fsNx8B78v/d97/+94eN4no/w/2JwRPx6nL+OeMR/oAkkygMRH84Cm+bKI1rcpPMSH8sD9rOxTtjyyajAwRJG7nH84d+BWyOhjakJ4ef5qhB715cZ+uFkpXWFPySZP2melo2hqcerL94KSRw6NAQCgUAgEAgEAoFAIBCI0wwo8VMFMbuimhqlaZXE8iqIRRRLK6mg1gRdVjpagDVz4ZyowaZ3Zk0wPM4U1dhITKm0ryqIeQDoJcv5jBm6SEnEYIU1J3sZm1ejtHqINwB+E4whaJTUJh1sHcRT+i8qmS37YJ3sAoND3FN6+oZQnrtjfqJ0Csxm1HmvdQB5/V6dqLHuXUloIH5m85tKZoteofssQC5LFVkdAIHl19osp4rZ6DbwZaF5EVolte7xPTPEpw2fVTKb4Oo3JFhfiReY6HLhl8qGj0s/abMpwFUyKugqzdaXMa85xyAmXFZuSDKpbdf9egju64rlrxB2eokipPRg0bSNwVY4dVRd9dDfi/lyDbDw0C0+sDzp8QeEZhnTFUvlalq6c3dATP9kfGQTeul26ipf1dPI8VsN1r3ZenEBgr2zW08ZC9Dvbc/4Ynn3GkP6OTG9nZJum+/SbVOFmjY3p48n3MDMJC+JcyDJUIQWcjb2SK572XxBTD90sndyAAf68ElNtsrapkqzxaJttLDO5tVG2yRMEjNJ0Wz5ncaAXNvUbLaFqCYuHBTeTlkNdHpglBHOEHKGgmzb1Gq27uZ+eJnQDC/3+HEsHzWsDBIXABZdfrm2qXmyMS0mby8Fw/XUXRxM2xSxn9YD48rJto3cVrr40YrVfgMwJ+Rp","target_count":57397}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
