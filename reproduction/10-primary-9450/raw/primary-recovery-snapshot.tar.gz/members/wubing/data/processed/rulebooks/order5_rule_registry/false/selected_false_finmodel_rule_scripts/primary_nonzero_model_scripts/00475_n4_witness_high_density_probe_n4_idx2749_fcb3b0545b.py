from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":565,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":2749,"model_key":"n4_witness_high_density_probe|n=4|idx=2749","model_order":4,"model_table":[[0,0,0,0],[1,0,3,0],[2,2,0,0],[3,3,0,0]],"primary_rank":475,"primary_unique_false_pairs":565,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2749.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2749","source_bits_payload":"eNrtmT9vEzEYxh/7HJ0vQsklgESlQK6nFDqVst2AFIve0A02xnbowNgRJEScAZFWSATEB8jnqBDcygbf4AbYM2aoYmzyp6GcWlBzogn+LfdKjvye39iPz4/bDJAYcaWGM0kSYh4NoMPxV+yADV2a0fCE880VmZXrsWirNsM8kLqbCsEC0QWCUD/jPy/Ac+IP6jxjoL3VINkDZRLi9L9CCkO3mtFXMAn8M1OK1Jdk999U6EY0DffbJZRhWQCkak5jpannmq2v3EmYmmzO8hQyUTtEL/SgBybN0PT83z5ntV6A6Flg+uZajfYPNsK7JkZugrrmsXcSwQEoGm/jWAsXSBjmNLpUvdkyiheZmmr0jOmD5TW01/VrkVbhUlFgQNyBK/TelDg55ZPq04aeF1++e95ksX29+pRYFbL8F8x8zkZwpWsrsgiIw+nZQnbC4iqzJbFYLBaLxQLspifnYBLh/qkTHW7ili3S5WOopuGxPo62fm1lYq7JkhNvaWKQzLb+Pm0WCNUqGNdeUlNTZSy1gIi8kqXf2qZvYwAla0edDyYeGRYjQ2a+fsL7hr9NqWxQjm5crVRAwTodCIifPnXgjX4Wx/NIJlWzpF9fGjkZGySJk5uJtvniUaqrFa2DpG4treu4inJept1QHekJLl7dmS62+GFaWAodmbH+z5+9qNnN4FIwvoQb3RyO77Wk/2ApxvYR/LjM0hbhCPpN31yo0qFyZC7JxJaQn8H2XmpVJLcdX6szFyv3jBLz+WcbFNf7za5U1wPeS5SgnMIb6N00zFT+i77AD3twnc0=","source_count":1292,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmT9vEzEYxh11uDE7DPcNYGM9EOrnyAdAECREgxjiICQYOzJ0aEc22DpckSMx3EbpVGh0vZRIRQKSS4RyPsVnP9jkT0OJWlBzogn+LfdKjvye39iPz4+rAqAY8r2FM/E8ZR4NoMLxV2xBFFI5o+EF57vHdFaul6xKqgLzgOpuOgoLRBmIQv30/7wAT1XsNPmMgZYOI28DUlCw0/+KGhTS9oy+onEQn5mSuTFVm/+mQp+DSbhe7aELywJASX0SE00z12xFko5D12TLlqeQHtlSeqFHJQhqhqbn//Y5q/UCBM8i0zfXarS+the+NzFyE9SDRNyliNYg0bjn+1q4oMIwp9G55P6OUbzA1FSjZ0wRIq+hPWh+DbQK9/oMjkqdlOm9yctyykfJzT09L65fSZLxYrv27bmyKmT5L5j6nA2Q0tRWZBFgDydnC1oJ+4fClsRisVgsFguw6Z6cg1WAt6dOdPiEI1uky0eBTMIVfRyt/doq2FyTeSfe0tggmW79fdosEKQ2MK49laamxFhqkWJ5JXOvVk3fxgDyDlYrt008NCyGhsx8/YQ7jXhbStqQHGW/3elAQlQqYGA/feooGf7M9+eRjJJ6T78+NXIyMki8LDcTbffJK1dXK9iHctOW29RxG928TLsCWdUTnD36MFls/mt3sBQ6MmX9nz970bKbwaVgdAk3vDkc3WvR+M1SjO0W+EpXuDXFERXrsblQlQWS0VySsR1Gb0BsPNaqqD5msVZnzo7fGSXm88/m9PeL9TIlXyJe8giTXCJx9G4azlT+i77AD9EB01o=","target_count":61284}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
