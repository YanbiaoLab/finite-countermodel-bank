from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":560,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":96955,"model_key":"n4_witness_high_density_probe|n=4|idx=96955","model_order":4,"model_table":[[2,3,2,1],[2,1,2,3],[2,1,2,3],[2,1,2,3]],"primary_rank":476,"primary_unique_false_pairs":560,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx96955.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx96955","source_bits_payload":"eNrtWcGO4yAMNYgDRxLtB5AoK/UzSJXDZk77SWyVQ3qbqfYD5lPXNoS2EzK7VZU5rHhSG8dAHIyfQY6Af4FS1gC4UULBV8AYZ/EiHViQAiUNQArwF0WX16GuqvshE0htweM/GAcCJCgchav23r2tezO+n7vLPGfXm36eRQmH8Ud7nvW6l+/6duj6ru5d/U1WZdkKCgoKCgoKCgoKCgoKCgoK/l8IoSSAdxCLVihT7Smr0iA8aCoxWdJFoJb7U/fwSLtl7L0Ti+jqcRjuWz+oxq6qxDNTC4U1/HPgQFBJzaJAb7tWWU91N+NoGqEE9yD8ZVjPiME1OJpM0x6HadbNZJ5etZ+Xjcoee605d207DPNsKjT2fOlXSlxSY9EpUnlw6CLDay3hF8WCuQZBDBtDb6aWCInRQ3pYXka61Aj37nBjS6/fvQ3DRFVOE/xmjnqP8NciLPqq+JpR4Q1KNkUIl3ZjxMQ+gRcxgHhIbAyTbG6eqtNY9ElGFQwp8zcbsZmHJGJKSOVjjJT2SKEZXakbtYcjf3fJEIdmVVEIYrDvYSySbQ9mbZNtD2Zl8FInQ8yB4EqM/z2MOccU5m8WxHGSgYlGFCZRXWkrVx814ErzGOm3bF/hMCbR0vwyeRI+2R8eRCAbUshSdl+44yFkfuTawmKbJdtjiGT7oqwVyHYiQ/xBKcbkUYs9yOZ50TPnAdoMgI4PS6oLmwG1aj4khEyjblJ8OBvw9uGWMUkTyLYRAn7jk9frxjeyKz7xzpEXPXMeyCRkdIMh/bIf8EYX+vNeSFqeEw+4y8WapbizZbJWJkdnVGkefcgKqLs24lMw2qgRb3qj+sNIwajWWSuTo11GlbGRGu1kTmgKdXSjT1b/Aba0vuo=","source_count":1533,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWcGO4yAM/dT5gFVnbs0h6vBJe9rsIUr4jEobpXzAquHIAYHXNoS0EzK7VZU5rHhSG8dAHIyfQY6Hf4G1SgPIxkHBV0BrqfDiJChwHiUDQAoQB0uXt/Y6TfdDanBGgcB/0BI8OLA4ClftZXhd92b8Og6HqsquN/0Eiw7Ozc/xWJl1LzH0Yzv0w7WX199uKstWUFBQUFBQUFBQUFBQUFBQ8P/Ce+sAhIRYtEKZak9ZlQEvwFCJSZEuArXcn7qHR6otYy+Dn0V5bdr2vvWDqhmmyT8ztVBYwz8JEjyV1BQK9LZrlRJUd9OSphFKcA9CHNr1jBhcg6PJXMaurStzqfXTq/b9sFHZY69djsM4tm1V6QmNPV/6dQ6XVCt0irMCJLpI81o7eKdY0EsQxLDR9GZ2jpAYPaSH+WWcTI1w7w7ZjPT6w2vb1lTl1MFvujN7hL/xYdFXxdeMCm9QUilCuLQbIyb2CbyIAcRDYmOY5OXmqSaNRZ9kVMGQ1X+zEZt5SCKmg1Q+xkgZOwrN6EpzsXs48tuQDHFoThOFIAb7HsYi2fZg1jbZ9mBWBj+uyRBzILgS438PY1IyhfmbBXGcZGCiEYVJtAtt3eqjBiw0j5F+y/YVzk0SFc0vkyfhk/3hQQSyIYUUZfeZOwJC5keuzSxWWbI9hki2L8pagWwnMsQflGJMdsbvQTbBi545D9BmAHR8mFNd2Ayo1fAhIWQae5Piw9mAtw85j0maQLaNEBAbn7zeNr6RLfjEOx0veuY8kEnI6AZN+nk/4I0u9Oe9kLQ8Jx5wl4sNS3Fny2StTI7OqNI8+pAVULc04lMw2qgRb3pt+3NDwWjXWSuTo2VGlbGRGlWtT2gKdXRjTsr8AZW9sj0=","target_count":61043}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
