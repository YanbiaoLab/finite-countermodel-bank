from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":556,"excluded_block_payloads":[],"law_count":62576,"model_family":"affine_n8_boolean_micro_probe","model_idx":71020,"model_key":"affine_n8_boolean_micro_probe|n=8|idx=71020","model_order":8,"model_table":[[1,1,0,5,0,0,5,0],[0,0,4,1,1,1,1,4],[2,7,3,3,7,2,2,2],[6,3,2,2,3,6,3,3],[4,4,1,4,5,5,4,1],[5,5,5,0,4,4,0,5],[3,6,6,6,6,3,7,7],[7,2,7,7,2,7,6,6]],"primary_rank":479,"primary_unique_false_pairs":556,"rule_id":"false.finmodel.primary.affine_n8_boolean_micro_probe.n8.idx71020.v1","rule_key":"false.finmodel.primary.affine_n8_boolean_micro_probe.n8.idx71020","source_bits_payload":"eNrtWEtOwzAQnXEt5EpIJF1XwqqyYMmyK2RFWbDkCNwEL7uMIg7AUXqUHoEDIEE7cZtC7CBXMSowT2rdeqKMPDNvPkYwAj7BGFokHu1JyOBccAEw9wpqAL3wCawGkQHGKHkBPfVLEFGPZY2ZEJXUHsGtW3sHtbJd/QeNxJRMok0F4rQX7E1qgcFgMBj/Fa9dfd08Jdd21/18u0qtbG26+jvRqVuhm64Y11KaxGebdm5blKDTKnt0ncJy99WaMaHGwqnI8dCqCObpCShbuyG1qmTIhFFpwNh9XKiMZo/2w4iD1uSmjGyqnAmTEeC5oPRYNKtV+qPZhk5TV7M8T6/toY3Ghv4otynSkU2Rx1D+QNbazvqWDoX2QDIe5s4eEndBQo5SxoWHYrPEY+bItkUlj280kpCtbB2V5X+PYteD0vfJqMo2g68be/q4HGw+5pQ6x6tsg/d6ttCjFoN6cJTJcpGUD4wTgRiIAkpkuJ9QuSJ8RzYdSviK+iB3NT8Sv+vg1IRENvi9c84agrP8MhClXxGR1u5dE+QR5X13+h7THPt0QRIKN2NXPHJHQAgINI/Gk1p8DUNErjbh7N7fQ+Vh2/m69gNPwis5","source_count":352,"source_output_dir":"organized/mining_outputs/out_exp108a_affine_n8_boolean_micro_probe","target_bits_payload":"eNrtWEtOwzAQReIAHKFH6VE4AKqy7NLchCOwZBFVFqsuWbKIKiN13QQJKRZyPUM7cZpC7CBXGVTAT2rdeqKMPDNvPgaUFj9BSloMHO0ZrPBc8I649goyRLXyCYRCWyHEKLlGVfslAKDGssbG2twoj+DJrb2DCtOs/oNGoiaTKJmjPe0FrUkFJiQkJCT8V1x19XVyy67tsft5+cqtbCq7+rtV3K3Qc1eMM2Mk89nqzm2rBSpeZXeuU1juvxozMmosnIoSDq2KTTw9AYvGbkCtKhmSMSolStHGha5o9mg+CXFQitxUkU21MyEbAW4KSo/FbD7nP5qY0WmyfFOW/Nrum2ic0R/tNi0f2TR5DMwPZK3drC/oUCAOJEvD3NnDwD5IyFFauvDQySzx2Diy7ZCb4xsNFrItGkdV5d+j2Mug9GI7qrLJ4OvGnj7eBpuPNaXO8Srb4L2eKNSoxSAbHGWq0rLyIeFEAASigBIZtBNqqgjfkU2FEr6mPshdzY/E7yw4NQGRDX/vnDPF4Cy/DETpV0SktQfXBHlEZd+dvsdUin26IAmFmxTzNHJHwFoMNI/Sk1p8DUNErpbh7N7fA+1h2/m69gP8r0X9","target_count":62224}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
