from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":543,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":100621,"model_key":"n4_witness_high_density_probe|n=4|idx=100621","model_order":4,"model_table":[[1,0,3,0],[1,1,1,1],[1,2,1,1],[3,3,1,1]],"primary_rank":483,"primary_unique_false_pairs":543,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx100621.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx100621","source_bits_payload":"eNrtmc9rE0EUx99MNmRTpNkNehCCnawr7al6bKGQIQySnHr0qIgHj4KXQAu7kUJm20saBD0ULfhfBJS1eKh/gR6X4k0P8ZZDyDizqWkbQ1HMYrfO57BvYJZ9+77zY/e9aRoAPozYK8G5hCFSxgU4NOGPuA/GMIendDyu10jAp/nyHgbijQGzwJePsRGkiDYAcaR99PsCbCKrvyCH5fpkoPsuaboEG22gk6OCssNcccqzyM+Gda5LGlk+evBvFFpZHTefvK+QAmhSgC+8u9K8VNuHkCwk6q0nWrGV3iLlLXN5hAyF8NAVGLSUppICklFaiS22DXeXsS3jKpi9j8tPb0tJzeRiu7XjdjgngetA7Jabtu04W8lEF4nX94q23Wk4zoESMienTXKh7XmvGkc3q/OrDA7LrT7+DkfoQ8bMJrTYhFjfZJ+/BjumCk04B59eNFBZb0Oa/4FTv7MNp+XntCJpgG4vqT9fpvIS7syVDS2JRqPRaDQambN9OcmDs11/baL3mUdvaJEuHkMxbg5kNuqd7TVmm9+HJ7WlUYHkbC/agLXUCik8FFftsdJUiIoq2NLEFtu3Zmzl8ISLXf4WTpWHJXi23p67nZqDfbfDoc2Ktk0wY5xDFWhRxlwjAQCSThmbhTNfVObjEGFcjQyTqxHeWV6J5MurC8mVojwgmZIWkiraDUVXTnDaWhwvNrYeZS/FPnJc+p9WgfxlNkZBCeuPwUXg+BCOx8PGRlm9b1Wn35yypP8dmIOCEXnIBNKrWOpAFQ9Fxk/EGa1TXKeGu0sp5F1kS8PBtsFEJAFv/bmlXqXti2vE3A8FxSaGfF9+TZ14I57kb08FfgAJ27sL","source_count":1494,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmc9rE0EUxyfkkJs56E3KHvUvsAepi0L+C6FKDwqS5lJ3A8XsQgu5CB49iOjRY08JMoQJFNpj7anFdTKVgAcluynSbMhm5jmzqWkbl6KYxabO57BvYJZ9+77zY/e9qUQADoxYasO5mKZQxgOYD+GPeAtRps8TOl7W6syyk3y5ry10P4Jp4MjH+AJmiBIAo9K++n0B1kSQO5DD8mUy0EWPVTzGoxKQyVERg0y/k/As9rMRnOuSGIEj3vwbhba3xs0Xd5qsC5oZwEHue2keqe0DSQ5S9ZZH5dhKb4byNrw8QpoIueI7ZMtKU0lXyCiD1BbbureM8Wr0DcL8rd3nH6SkYXqxfVzxirbNLI9C7NYOfZ/S1XSiM9CDdx3fL1YpXVBC9uW0SS+0Jfdhde5T43ALw3yrnONXYE7cHoaDlBYbQhtr+MY1ayVUoSG6cPNxVbT0NqT5Hzj1O1ulZaevFZkFyNM99eeLVV5i06NWpCXRaDQajUYjc7brJ3nwoOBsTvQ+c8lnLdLFI4PGzazMRt2zvdF083vzpLY0KpCc7RXrsDmzQiJXxFV7rjRFqKkKtiS1xXa1Els5POZ+wb4Hp8rDEj5db0+8Yp1yxyvaUMId32ccY9uGBpCOjLnOLAAhnWI8DWcOah7GIcK4GmmmVyPc2d025MurC+u3jR4ImZJ20yraZVBBTnBS3h8vNrxhDC7FPnJc+k+qQP4yGw2rzfXH4CJwfAhnx8OGR1m9EzSSb56xpP8uhNluZLgiBJZvBupAlWfQ0EnFGakRXiORt0wI9DzhS2OD70MoWAreckd7+WbJQV9ZuGgiwkMOvZz8mtJ4I57kb08FfgBCpbYc","target_count":61082}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
