from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":540,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":94201,"model_key":"n4_witness_high_density_probe|n=4|idx=94201","model_order":4,"model_table":[[0,1,2,3],[0,0,2,0],[0,1,0,0],[0,2,0,0]],"primary_rank":487,"primary_unique_false_pairs":540,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx94201.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx94201","source_bits_payload":"eNrtWM1uGzcQHhIsMGv4wFV06JG73QJqT25T+Ewr20I+GJCNvkAKFGgOfQdKkIuN4QKKmtxtOY/QJwiKIgh66TVP0+GQu5IsRWngOHGLHdhaafk7H+fvowBrHWyQp0paMPHH8wruvmjdfDWgQN5kroviSSlT0RkYYwFBIUAKuZ84cyAR6ENDx/IiCLwwYuGAsOwAanovJFhFbf7vTSJlg7CisYuG6f7r3nzvwfoIN3Nq5lBbWmC15fnjr89651MGop4JtyuZAORxB6rGjlG7qI972FfbJjDxv5VWWmmllVZauaH0ktVaYGsCfqykVFx2+CJEws2qnv+XKK5gY/kmHLy1OlwqeN9Y7ygq/cC14LbSygpdLGaDPO93DstykI8qSNNclgozZUZFLosntnT0UlC00nJaSiGCb0IFmoiMQNTCUy1DtMZIIk6gyNlKaiZn8xyEOBdkAJPAlWYlL2RGCEmhUz/CoW9XxH2YoGmayrKj0htpJfo5afLg9/6pqAetETpRsGAe5xriZBo3H3ZIIweHhdYcb8uyQvoK2tEAnDLXI22Y61lIVIg2Xg+Ieijngh7O00g/sI7WOrK0SaReGvogiIwZ53fIysTNBsrplYGwVev3LggAE3tgo47w/QMGLrK6hscJH8Mg0j17aBxpVExpWNGhQ/Dg8xg+HkItDqnDXwydiwC44NySjosfEQpYI4chs9FCVUSt7mo7HjUz8qjlEFBbz2x8ztbnxoZaswEBGxBAsJO4X/yw5m9M4PyLhOMNwAMgyFCMINT49DWf/tIVQW02gI0e9cCQbtiAoLYTxaA+jZktgcbWYldeaAW1ZWfbukbMbEsgBsdoY9t7EmsNY+2vcXzkCC8XhQcu3apsdralUqV+LDnbx5RHV7/uf3n/97+/+/F0/6z31/Docu/Bw1/GP+zeRj168TknldnA5E79NkKTA2UXNJNbUS1crA3Le8/0q958r5+d9ndP9c44uw3QfWZLSjW1nVRwQvWKaWFRoCFHT4o0Nea9FaFT+dLMKSUdkSGNKw78X+k+4u24/Ul576jb712d9/Hb7jFe6v7DyQv85ED/90PMIGWNqnwn6x6X2aSPZCFZVx1suI/lH2hinlLX0ySue3lDaOLzi3mzUH7Wmww9lNlkbJD7S4RW7qBMpQ9UkB7Qd+9s3gDI2fwjFHzhgLmgco3ZyBWziRaiNxjFBvP5cJnt9U9X1YvdZL1Fr79Kf/7+hLs/6+7cp3iAf5p3vSAZmKTaRtKvXZBwdyrRVVWBfVeAHs3P853P/l2IKr85Ti599+5J7w9yS/Pp+C5bZEHVM24+pPWDTP1nFdHLJq0/f7Qy8pDrQi78k0Kk1y6l5Nv87y7LP1Gguzg=","source_count":1494,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWM1uGzcQfppceymKoijyBH2EWPY9iSKghrOoBYnv0EMKFEheoLAF+GCh3cg8G03rUyug210ee1C0PBjeAUqQ0+GQu5IsRWngOHGLHdhaafk7H+fvo0MpBW6QR8ZKVPHHgwTvvmjdfFVo0N5krr3sSWpLNx8rJRHQAGKJuZ+4EGgB6UPjXPIigLwwQCaQsJwjaHrvLEpDbf7vTWJtg7ChsYuG3vm9aefi5foI0RWmK0BLWmC15cHTXw6m+z0Gop4JtitZIeZxB6bGjlHbq497NDHbJlDxv5VWWmmllVZauaFMq9VaYGsCfmqsNVx2+CLE4s2qnv+XGK5gY/nmBL61OlwqeN9Y7xgq/VC04LbSygpdzLrjPJ/MT9N0nA8TLMvcpgYKo4ZZbrMnMhX00lG00raXWueCb2KCmoiMA9DOUy1FtEZZIk5oyNlSaiZn8xyEOBcWiP3AlbopL6SGgFWmSz9CgG83xH2YoGmaSrKj0hsrLfg5afLg9/5pqAetETpRsGAeJxripBo3H81JI4GnmdYcb9M0AfqKWtAA6DHXI22Y60msTIg2Xg+Mehghgh7C00g/sI7WOrK0fqReGifoiIwp4XfIysTNBsrplcGwVen37ggAFXtAo47z/QMGIrK6hsc5H8Mw0j15qgRplPVoWDanQ/Dg8xg+HkItDqnDXwydiwC44NyWjosfEQpcI4chs9FCSUSt7irnHjU19KjlGFBbz2x8ztLnxoZaswEhGxBisJO4X/iw5q9U4PyLhOMNwAPgyFCUI9T49DWf/tIVQW02CI0e9cCQbtiAsLYTw6A+ipmtwsbWYldeaAW1ZWfbukbMbEsgBsdoY9t7EikVY+2vcXzkCC8XhQcs3apsdralUqV+LDnbx5RnO1+f//bqq09+/P7w/GD66ehk9+Lli28Gzy9vox7d+4OTSnescmEeD0HlSNkFVP9WVAsXa6P09UP92bRzMSkOJ5eH+mpQ3AboPrNVqenJeek4oXrFtJPgQJGjV1lZKvXeitCe/Vx1KCWdkCENEg78v+oJwO24/VH6+mQ2me7sT+Cn2THs6smL/n34+0z/90PMuGSNkvyqmB2nRX8CZCHFzJxtuI/lH6BinjLX0ySse3lDaOLz906zUH4w7Y88lEV/oID7W8BW7qD0rA9UWJ7Rd+9s3gDI2fwjFHzhgLmgEo3Z2BWziRaiNxjFBvP5cJnt3nc7yf3Lar1Fr78qv/3hiLs/nF29ongAX6h3vSAZqyrZRtKvXZBwdyrRTZKgfFeAnnX286s//12ISn8+rnZ999nR9EtyS/XX4C5bZEbVM2w+pPWDLP1nEtEr+q0/f7Qy8pTrQi78q8yV1y6l7Nv87y7LP/rRte8=","target_count":61082}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
