from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":536,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":10914,"model_key":"n4_witness_high_density_probe|n=4|idx=10914","model_order":4,"model_table":[[0,3,0,0],[1,1,3,1],[2,0,2,0],[3,2,3,3]],"primary_rank":490,"primary_unique_false_pairs":536,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx10914.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx10914","source_bits_payload":"eNq9WLFOwlAUvY8WW5IGKnFw0OSlMjAyOsHTMICTG6N+gu4mdjFhcDDED+BTOvkLrl3cGRmIFdqiMe2FNryeCyn0Xcrpee+de2/vi1BEgUUbc+JjEB/pJD4qSj0yPolPV5GgXAujVr6D7pgraMmMUzDlPH3O0eMc/iPncTjHvMPdcZ27pMs5lM15apxjkaKHGSqCuzSlYmYc8+Qjh1AyIrPw9r+/t8ncfpXEWxDFZhDEljHYMwaMEmotDFiYoAkM2ioGG2DA/GhggnhtVBR9fjUaKLTvyO4SilwwCcmGTeQSpeo0WTg4sNBw/8Jb5fZqeFOJgvOPr8hdv1Bis4B75DsCggUTIBhfElViFzVCim0xwKE51MSB+S3kqvWge+RDWGcLmNgukdROkUGLDB+YR++he+S9Mxt5HiiY+LNhezwcgqjdzpTETeRNG7hqSkhg9dMdI3dkHQk2pzfcPKa9GVRmcxUJGDkXWY/QNRJMETCMAJ8ON7anE7PSWh2Fezox51qpPe0OJHpT+r4ysqO1wdDzdkpRc2ro864m6dZGsGOO12/NTwZ8GWm6/m8XXVsZyTJT+pXNd8KrKPjYzKba+ltrPnv3owqyEJ/ZhKm/ScOCya0GdIrNYqN8ThoKc3VSQmx83LWL5UG7tNge8tJ5dkjmBZtSZWSirEI/PriaNjke7LbRkdkgT9w9fpEqsKNUc6LIJsmVZonpVYINUarQUKlJSaUiCtGoHaTrtf0AuG5uLg==","source_count":891,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNq9WLFOwlAULWFgZHfp6i849VP4AEMcHEhcnom7foKObE7iQPTB5NiRAZsmOjgYLKQJrRTeFdqiMe2FNryeCyn0Xcrpee+de2/vhZJEVkgb8+OjFR/pMz5KSj1ufBKf1g1FuWYa03wH3TFXUIMZJ6vDeYacw+Yc4prz+JyjNebueMFdMuIcMuA8K87RTNHNDBXFXZpSiTKOVvKRQygZcbPwwb+/DyjafnWJN8uIbUkQa8RglxgwSqhNMWBmgqYwaPUYbIABE8YgAvHaqMg4PprPUWg1IxgRipzVNSmATWQDpeo0Wfg4MHPp/YW3yu186XRcFJz4eiZv/UKJLQTukZoBBLO6QDC+JKrEXleEFFtzgEPzaYYDE1PkqtnQPXKiwvcmTGwvSGofyKBFSwHMo7fQPXI6bj86DiiYiHZ/0uv3QdTu29LFTeTDBLhqUrnA6mfUQ+7IBRKsRWe4eUx7M6jM5klSMHIesh6hJySYJGAYAT4dbmxPJ6autToy93Ri3rRSu9odSPSm9H1l5Fhrg8F2dkpRc2oY8q4Z6daGtWOO12/NTwZ8GRl54reLrq2MZJlJ/crmO+FVFHxsZpMT/a01wd79YwVZiM9sKtLfpGHB3K0GdIotZKN8Thoyc3VSQmx83A2K5cGgtNhu8tJ5dsjNCzalyshEWYV+fHA1HXE82G2jI7NBnrhtfpEqsO9Uc6rIJsmVZonplYoNUbLQUKlJSaWiCtFYHaTrtf0AlAMDCA==","target_count":61685}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
