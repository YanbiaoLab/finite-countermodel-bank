from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":536,"excluded_block_payloads":[],"law_count":62576,"model_family":"top_witness_associator_feedback","model_idx":37699,"model_key":"top_witness_associator_feedback|n=4|idx=37699","model_order":4,"model_table":[[3,2,3,0],[2,2,1,0],[3,2,1,1],[3,0,1,0]],"primary_rank":491,"primary_unique_false_pairs":536,"rule_id":"false.finmodel.primary.top_witness_associator_feedback.n4.idx37699.v1","rule_key":"false.finmodel.primary.top_witness_associator_feedback.n4.idx37699","source_bits_payload":"eNrtWcGOwiAQBdID3rBfwBo28TOI6aG9+UmYeKg3Nf2A/dQdoFa0sLta6GrCS1qTigyd4c08xh26ojN3iUKQC/NRoHhYNyFblCtEHpprGxqumHknyuGG4eLDN3tjQqJXA7t4IcJcXwIHovYBHqYTZlZmTlmAD8ncHlrjOa1hlBEDyu5omj3xVlg34lRVe030owQyEMgm6WL4eRDntlXzvBqf1ZFdUUIVAheC/6C+pXWlLnuDoYIhbVgly2Us0ySxJEqCqRrghdGhsyZbie+lDz8A7cTSFVfHasSLtrWUeUVsSb0CKjfFPeuUSBDNjUkfXpUOFzG6Olq6ljYlF5c5r4YHqU5vdBm/UbfKk5AICsppCm+msyJ4zRwSnKEmdSKbo+22Ue66frcxDgQ2RxpriPZDk0lLbn1iw3O7jPG2GQv4tIvLyMjIyMh4GF8/dyBJE1W0BY1JskCo5m6N5DsYLfJRyB+Xu+ZrxluQTZyqcrkstV4lWhMjljCGnTjXqxUhnmMB7hsl8TRp+MxiWL0Q7iNx1A3vCX3ubVkPnRjV933SuXLjGGJ934dE/evm/xokD+wAObkY5CNQfLKxvxXYXEe9W7ohgZ1pUqfnB2VTVc9asw2SSzJxguVrYhMq9XOb1+QT3PkGmnw52w==","source_count":464,"source_output_dir":"organized/mining_outputs/out_exp135a_top_witness_associator_feedback","target_bits_payload":"eNrtWcGOwiAQ/VQ/oFFv9mAin+StPTQbPsNkicsXVG5yaIAdoFa0sLta6GrCS1qTigyd4c08xp26ojB3rELAZ/PRqXg4VCFbnCIlHpprHxqOmHknTuEm4aLDN1tjAqtXA7t4IcJcCyIDUfsCD/MJMyMzJ+7Ah2JuDx3knNakyogBZHc0z554KxwqsmqarSb6GgMZBGSTdDH83JBlWaJ5Xo3O6siia6EKgQvBf1Df0rpSl73BUMeUNoyS5TKWaZJYEiXBVA3wwijUUpOtlffSh26AduTkiqt1M+JFWVrKvCL2oj4ClavunnWIJIjmh0kfXpUOlzC6Olq6xjYld5c5r4YHqc5vdBm9UbfIk5CECsppDm+msyJ4zRwSnKEmdSqbo+22Qe66frcxDoQ0RxpriPdDk0lLan1iw3O7jPG2GQv4tIvLyMjIyMh4GIufO5CiiiragsawOCtVU7dG0h2MJvko5I/LXfM14y3IRlZNezq1Wq8KrYkVSxjDgizr41EIz7FA9o2SeJo0fGYxrD4T9xFZ64b3hD73vq2HTgzq+z7pXPnhGGJ930dE/evm/xokD+wAPLkY5CNQfLKxvxXYXEe9W7oSgZ1pUqfnB23VNM9asw2SSzJxguVrYguO9XOb1/AT3PkGsfU3Ww==","target_count":62112}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
