from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":535,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":3307,"model_key":"n4_witness_high_density_probe|n=4|idx=3307","model_order":4,"model_table":[[0,0,0,0],[0,0,3,3],[0,0,0,3],[0,1,1,0]],"primary_rank":492,"primary_unique_false_pairs":535,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx3307.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx3307","source_bits_payload":"eNrtmU1rE0EYx59JVnar0EykUA8hu0kOiXcPEUJ3u6b02PoFbD9C1EsPwo55gZAW0oNHqSaI3r0LKyp4tHjytjYVPG5LD0tI9nF2WwRJwEQ6HnR+h7C7M7tPnpf/zDBDAIDB73jRVviv6xKQ/A32851Sn9qJiQbWfUcwWZnyymj3wdA8oJMN214NFiE15RWdkFClU9L/vH1xsWnzvN8o/2z49UuWRxnZltmSSCQSiUQikUgkEolEIvkPuNlv56/mlu5Wc818p9Tc1HrUzjXrhnZdgDFv4CNCKkTdexvthu0Av0cTvKQI10b4cGgefMLlN3TIzWCua2fHmDoqaAKMMW6gbFXKnvNYjYzhqosOU6GdEuGan94/doBgkVCLIVEoGPlT1MECUC7fWoi4dWaXXuFgYRy5tmMjv2xtUAG2wEVkz5TsqJl834gDqUDWGhUsVxURyGB5fIZmD51h8clnPGke6R/MIerhOhVhDXHvdadw60u12OQxRedjj94pvKzXtHi/OHG5xi62jxddwsVWBi42SIFHhIntSrBluahZShBlrQqMP1MVIXH8t8WWyBgAqmLw+PEaMbgdnrWECM/A6pT6bVtbmGyh1kRFpteW7Lh7i/IZwy5pdSP6c+fMEomgnPFNd7by85wMZKPuDRV8HpQkrMwrtv7TsFucLUMj5/BaL+q+dFo6PkQ0Vup/JLbZqjdZg524exZ4NLgugzlde6QogW7NNmL4ZgJI3J2AwUcgMm/RMr44SLdofK4Vl8D5ImGVKiIOFf37XNVMxQH4HhdbtgJM9bnYfCEnmOHa7bG+8R1372nfzpxKb3891w1RPUkLmdncrxAVNUu6jagEfIC4AFx1yiA55ZEx38ymab7JGKZBM1yEBF/0kABTc35lVn4A2JAjDg==","source_count":2299,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtmc9rE0EUx98mhD2Edo+CTd2bJ6lHQcUF796Vkmjx6CEBGwJN4ix46EXtn9D6D9geS+N2twTMwbvJIcluyMFCMZOCdhc3mefstgiSgIl0POh8DmF3Z3Zf3o/vzDDDEJHg71gthfzXMBhK/gb5TrGZpdZ4ooEU7jIY1ae8klx/nXLW6GTDtr6Fpzic8orHmBLQKel/XLq42LV43j83fjb8+iVbp4Rty2xJJBKJRCKRSCQSiUQikfwHfMqWOt+6J+9q3XKn2Czv+jlqdctV1/8iwJie0QBwqICn34t2wzaR34OD+kiEa0l4lXLWbsLxfZriZqBbsHoJGC63fQHGCDfQsOsN3XwRRMbg0ACTBFgainBNG+SXTGTQYtQmwEKKbmcBPLQRw8u3pgDspK3mQ8icJSLXNi3glxt7VIAtNADIk7CXLI/uVOJAhtizk23bCEQEUj1OpMHJgZlqPbsBi+Vl77aTAk/ZpyKsATx/UGx/vF5rlXlMwbyVo+/bj6pbfrxfPL5cYxfbx6cG42JrIBcbDlFnwsT2Xd2xDfDtUI2yVkPCnwWhkDj+22Ib913EIHR5/HiNuNwOz9pYhGdoF5vZkuWfTbZQe6IiBwcnVtx9g/IZw2r6VTf6c+fMEgm10dccY7by080+9qLulQA1HpQRHs0rtuxTpdCaLUNJc+VrLup+stBcWgFwj6p/JLbZqne0hZtx9x7yaHBdqnO69jIMVc+ebcTQnDGyuDtDl49AbN6iJXxxMNig8blWXALni4RDGoo4VNTecFWTADKo6VxsvTqSQONi04ScYCoHHxLe3hVYf+tfTZv1XH6/W1AgWBwImdmMaxgVNRkZlagENMS4AIxgyiA55ZE738zm+5pDCAzQdw3AMV/0MBWGc35lVn4Ac+FOKA==","target_count":60277}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
