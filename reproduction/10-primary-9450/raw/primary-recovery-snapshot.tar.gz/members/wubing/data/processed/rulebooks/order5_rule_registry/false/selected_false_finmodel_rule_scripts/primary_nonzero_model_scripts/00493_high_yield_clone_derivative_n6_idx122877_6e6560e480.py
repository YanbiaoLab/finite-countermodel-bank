from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":534,"excluded_block_payloads":[],"law_count":62576,"model_family":"high_yield_clone_derivative","model_idx":122877,"model_key":"high_yield_clone_derivative|n=6|idx=122877","model_order":6,"model_table":[[0,0,0,0,0,0],[1,0,0,1,1,2],[2,4,3,2,1,2],[3,3,3,3,3,3],[4,4,5,4,3,3],[5,4,5,5,0,0]],"primary_rank":493,"primary_unique_false_pairs":534,"rule_id":"false.finmodel.primary.high_yield_clone_derivative.n6.idx122877.v1","rule_key":"false.finmodel.primary.high_yield_clone_derivative.n6.idx122877","source_bits_payload":"eNprZGOAgzk2DHjBAQYGJiBlwrBpFg8DSSC+Yc0/diYsEhmeORNDz7BgsctfqfO/shIDNUADm0NYJCPDEAIXoLQPG9FaaqC0ILpHFVTAFMsEBwc0GXkojRH8BmBSi4FBAK+VDgTkaQksKsExq/6p40dBp56SPsMoGAKg4X99GJC6wcXIwfAfCOyXCdHQtg//20GU/xPBjw9BtjEDM8MwCcgD/+21gWGYwgoKUyCQD+ZkoF1utKhXmeji0qIyqaPjg7vcR3klJReXjg4BJw6aFKqq3SCLNviKGQpuuqG2zOlMywwOY+NDHIq0sOzB//nhQoKCkyqUlA6BArK/Q+CjopIThyILLWybYzsPaJGTXKWLS4VS/wp+QcFHykfcORRbaJTZhDxdXDyUOjs4wJlNycmlpQNomcBoQTQKhj+ANGcPCFe61AAzWwf/aIgMBeBwWksbSIFrtjWbulaKgGq2UTAKRsEoGAWjYBSMdPDgCb5+5wOhWJe40UAafODff3yyLDN8qGnZgf/y+GQZLRhshmxA/q/HK+1C1aGLhD+4ZEDDCA5MHA7UtG4KA5MH1kF/ByFGFgYOhU4GBkYGJgYXFw4qWNbw3x6fNKMKVUfUDBgsHmCXAfsF6D0GBzCDDpmNoWEIlyOQoX8GzBQA7uqjVQadNkp2w8r3QxU0QKayTnARpXoGz1DyGySFPagnSrEChZOaDh6Q+hJzPg8LYPJQUKDIth/QkhJLqcSJoyRDAx0k2AYAijqQRg==","source_count":1179,"source_output_dir":"organized/mining_outputs/out_exp129a_high_yield_clone_derivative","target_bits_payload":"eNrtmc9r1EAUx6d46MntH1A0xx49VPAgZf+CxUNB6U0psgdp7cFmCgtmobA9evDgwYM/DmLFQ7HQLQxhVvewB0troQV1O5vtUTTZQmnHNSbPSbJ42E3jliZi1vkc8gIv4ct7yXuTvLnfht9MVyGSLIAjzHvI3T6EU/FUmxz67oQ4Hq09nH01bodorTAV7TGIA61Nl1+4kCIudexqu+9bFjvW6g7UqPvGvktpl6fZsT3p3/KPuwCtSEn6B3+S1Er+k/14Hg8/ULfZB5CkAA0Vl4UZO3I5IEFlykxQbQQteGZl1Mpc9NR+imIYkERmUWVH5PDxDy+ngubrY0iuGmvF+iwhhfoMxiPr+5kmY4Rg3NJ5Ik318z1P6NqbL5tWbuzTlD5eyPONjQneSEJMQTdfmpY1s8TYhJfIOdzKNJjOG3YSatPvbgkhfb9EyBKbu3FgWRf2rq7zRiGhYjPXCCkzFXO/2JhOCliItWQjkgw+weds9luJLIpiwwcyI2mAXt7dEcZf2SZz89e/eiubRCKRSCSS/x1lNOq/UzGfk2cySf8eQyjKa+dX4xTLomaU161BNbWJRMVIN4l1dPHk3Ekeb4xAHU7jlLsDTjl06E9N1wZuqAAuOEAIj0FMQ5Uot1uPdaK2BTUl3OPHIsID6p/8hWIDLcV9JBj9Q+8b4P/qdy0GapW9Hajo04oWbGVdOerr6vxhmmIL3jCl2NfFxhk3NWk5WC979/NCcMqGcSa14U6nDOlKxyd0si7wKdR+AcI34OE=","target_count":61397}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
