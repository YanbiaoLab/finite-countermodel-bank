from __future__ import annotations

import argparse
import base64
import json
import zlib

RULE = json.loads('{"coverage_count":531,"excluded_block_payloads":[],"law_count":62576,"model_family":"n4_witness_high_density_probe","model_idx":2221,"model_key":"n4_witness_high_density_probe|n=4|idx=2221","model_order":4,"model_table":[[0,1,1,3],[0,1,2,0],[0,1,2,1],[0,0,0,3]],"primary_rank":496,"primary_unique_false_pairs":531,"rule_id":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2221.v1","rule_key":"false.finmodel.primary.n4_witness_high_density_probe.n4.idx2221","source_bits_payload":"eNrtWUuOwyAMBcSC7lBPQKUcBM0qx6JSZ98jT/iohGC3yQDWKBo0qpRx0heDn/3sfjPL/J9fMnyWF8rEiylYbLYAy2AGxjGDwgwJGFgCe0RjBoe+lwzfZo+4cnOoKxLGWlxxC47UNlrze34xLhNW+Wy65WoRV7QVtSvBLsV2I8zaDrhi3IdzUfkK3xZwFwcuRYrGKcEMqWsPnFD9lyN1TZOiCUowm7PG6ch2c6Rk04SHt5BtqWvWp301PK+4peBwloHMP9l+S7bzVjZislEuSQnm0MOT48jGaQrs6SubI+I8z/q/7DuAHC1bz8FAQPvDxv5lsmnKlKwJajUrekLNYsc4XDGH1nTVfOoTkS1WtqCBNmTzPncWRFuyqYJsZUbrQTYACCmwulVhBBkp06750GRhjrH4FScaQrHXP5O83WyAj2QF5rZ6K7TIQC496b8+Adm0yYoVG8DrDQAw9FuyaZbc2h82q5erMcRbsontrQfCBsCoA0jx6FE4nvLWqvt4Ae3EUPsHJE9swjZERorZf15oZKQVi9dz37qAp/swD71MfSubwFIB90B3aXpWIFS+GD8FnTZhM6xnk8/Kp2aBi2bUOI+15ZvxxiaPY7X66YGuaq+ydI1kGzMgwc6zv/5yUAlldVHpRrZcQou8wgcIPfSnhVLw9ZEIKdyAXKjnKlDqHzW8epCHycYn2GTKN7s0jliiS+ZeVQIgw8ymCptjx2qONFO8D9ncLiIb10y2lR4g6NlWemBPOW9yT2Q9oD6XIXEoy2JkA2IY6Io1SLYjlS0kp5iiProhWucCPyiwSJU=","source_count":535,"source_output_dir":"organized/mining_outputs/out_exp107a_n4_witness_high_density_probe","target_bits_payload":"eNrtWUuOwyAMPXL3M1I5VlYjDhKpnKBiVxYImPBRCcFukwLWKBo0qpRx0heDn/3sfjnu/J9fOnyWF0rEizlYeLYAS2AGZzGDwgwJGFgGe0RiBoa+lw7fxo+4cmOoKxrGWlxhC46WPFrze/44qxNW+Wy65c4RVyQ3tSvBrs12I8TaDrgi2JtzUfkK3xZwFwcuRYpmKcEEqWvfOKH6L0bqmiRFM5RgPGeN05HtxkjJJgkPbyHbUte4T/tqeF5hS8GxLgOJf7J9SrbzVjZislEuTQnG0MPT48hmaQrs6SsbI+K8zfq/7DuAHK1bz0FAQPvDhv9lsknKlCwJarUrekLpYsc4XDGH1nTVfMoTkS1WtqCBNmTzPncWRFuyqYJsZUbrQTYACCmwslVhBBmp06750HRhjrH4FScaRrnnP5O83WyAj2QF5rZ6K6TJQCw96b8+AfG0ycoVG2DrDQAw5EuySZfc2h82q5erMcxLspntrQfCBsCoA0jZ6FE4nvLWqvt4Au3EUPsHJBdswjZERprJfz5oZCQ3i9dT37qAp/swD33MfSubwVKB9UBXLXpWIFS+CD8FnTdhM6xn05fKp2aBi2bUOI/l5ZvZxibPYrX64oHuaq+yZI1kGzMgwc6zv/5iUAl1dVHpRrZcQou8YgcIPfSnhVLw9ZEIKdyAXCinKlDqHzW8etCHyWZn2CTKN3s0jliiS+JaVQIgw0yiCptjxyqONFO2D9nYLiIL1ky2lR4g6NlWemBPOW9yz2Q9oN6XIXMoy2JkA2IY6IolSLYjlS0kp5ii3rphWucCvyPQKKE=","target_count":62041}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]

def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))

_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple((
    _bitset_from_zlib_payload(source_payload),
    _bitset_from_zlib_payload(target_payload),
) for source_payload, target_payload in RULE.get("excluded_block_payloads", []))

def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))

def rule_record() -> dict:
    hidden = {"source_bits_payload", "target_bits_payload", "excluded_block_payloads"}
    return {key: value for key, value in RULE.items() if key not in hidden}

def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(excluded_targets, target_id):
            return False
    return True

def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem", "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000", "set_option maxHeartbeats 0", "",
        "def submission : Goal := by", f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>", "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend([f"      | _, _ => (0 : Fin {order})", "  }", f"  refine ⟨Fin {order}, m, ?_⟩", "  decideFin!", ""])
    return "\n".join(lines)

def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])

def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {"verdict": "false", "source_id": source_id, "target_id": target_id, "rule_id": RULE_ID, "rule": rule_record(), "code": render_lean_certificate()}

def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone finite-model false Lean certificate for one primary witness model.")
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True)); return 0
    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False)); return 0
    print(render_lean_certificate()); return 0

if __name__ == "__main__":
    raise SystemExit(_main())
