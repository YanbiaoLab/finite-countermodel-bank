from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_paircheck_bank","certificate_generator":"finmodel_false_judge","certificate_mode":"finite_model_paircheck","coverage_kind":"explicit_pairs","model_family":null,"model_table":null,"priority":400,"rule_id":"false.finmodel.paircheck.bank.v1","rule_key":"false.finmodel.paircheck.bank","rule_version":1,"verdict":false,"verification_mode":"python_verified_remote_smoke"}')
_PAIR_INDEX_DELTAS_PAYLOAD = 'eNoBJgHZ/um8vYIBlr+1As+EkgK/97mHCbCASZPaU6m5hTTVzNgy0o2fGZWnsQSYtZgDxpu0FuOG3xaHzLIa67eiGs725huTwt03wdKpCvrXcviI1wHOzQOk4DDalZYS/IqcC+mimAHz/uQJmNm1BMOpkAPckLYGspk5xqj9CLi/Etb66AGmspUJsOjEApiOU/71lwTljdcE8uqNAYLNxQmrs1/w2KIC/a3gB5SM+QH8vrcKtNXWAZnc7QKq474J3ec5y6JX3caeCtfhFuTh/QTYh/IOz9/wA8nttwa7/coH7+Ew+NUXtPpH9YniAZv+tAKug80Cp5L5BsP2qAO75HHlsPADirnUArOrmgLf13KC0wfP++ABo//cBePcqwuMsYoBwvG3BJeYNZbGC2+lqig='


def _iter_pair_indexes_from_delta_payload(payload: str):
    raw = zlib.decompress(base64.b64decode(payload.encode("ascii")))
    value = 0
    current = 0
    shift = 0
    first = True
    for byte in raw:
        current |= (byte & 0x7F) << shift
        if byte & 0x80:
            shift += 7
            continue
        value = current if first else value + current
        first = False
        yield value
        current = 0
        shift = 0
    if shift:
        raise ValueError("truncated pair-index delta payload")


_PAIR_INDEXES = frozenset(
    _iter_pair_indexes_from_delta_payload(_PAIR_INDEX_DELTAS_PAYLOAD)
)


def _ids_to_pair_index(source_id: int, target_id: int, law_count: int) -> int:
    column_slot = target_id - 1
    if target_id > source_id:
        column_slot -= 1
    return (source_id - 1) * (law_count - 1) + column_slot


def false_finmodel_paircheck_bank_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    pair_index = _ids_to_pair_index(source_id, target_id, _LAW_COUNT)
    if pair_index not in _PAIR_INDEXES:
        return None
    return json.loads(json.dumps(_METADATA))
