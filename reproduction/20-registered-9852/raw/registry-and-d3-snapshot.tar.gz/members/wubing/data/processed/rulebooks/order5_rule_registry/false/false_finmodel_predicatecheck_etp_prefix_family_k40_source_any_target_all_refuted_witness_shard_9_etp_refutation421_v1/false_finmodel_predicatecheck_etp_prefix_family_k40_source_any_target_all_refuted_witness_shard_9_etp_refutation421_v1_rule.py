from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_etp_refutation421","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[2,1,2,3],[2,1,2,3],[2,1,2,3],[1,1,2,3]],"priority":404,"rule_id":"false.finmodel.predicatecheck.etp_prefix_family.k40.source_any_target_all_refuted.witness_shard_9_etp_refutation421.v1","rule_key":"false.finmodel.predicatecheck.etp_prefix_family.k40.source_any_target_all_refuted.witness_shard_9_etp_refutation421","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWUuuwyAMnCAWLHMEjpKjcfQHGAgGQ1spr5t6pEZpIJ74q2gCvInziof4s1B8Dc7HkB8WDifSaUsGcMDk1ZBP60KIV1Oa0iW6rcKeeW+1FNqCR9p7NkslwdEMmfVktx5Q97n856KnQbqmUCgUCoVCoVAoFAqFQqH4QVyTUuV8OrNNhzqAqnB1GtQtU5ksRtHirXSJMJgEs0wUmhy25ChqWb4FtNgJbgvP4jbfzDkUIqaliRwtFL1fbstGUQOLWiYy7hVHC0Xv116uy0RD1BIRUxZljhoK8ORtIERNKhuJ4y4gnrwNxKjNZSNx3AXEk7eGGLW5bPaNwJO3QSbC15rNyc2Gf2s2N0RNm+2RZhO+JjzVbO8jlHJLzFf/kYH5ti4S/zZT9oZzFGdH39wiXaLXfuUWedVx0CNMOTs2oRGcEAdA4zCVoyRtzJl/IGU0qRkH1c00SOwT7xEzB9XmOEjCxobkhDgAGgcqR6n/cZCsJ7Kb83VhU1GMw9ZG4EVpNkNk/wBjGBjHp82GD5rt9vt1s/0BGztbxg=='
_TARGET_BITS_PAYLOAD = 'eNrtWU2IHEUU7kXCChKDp1yUvQRRD15UggTZ3ARRFAQPuUTwEGKcnUhiOmHM1ILEgIR4iOBFZS+C5BIPZkdtZiv+sDkY4gpCIJOeiuSQQJiuhCRTy1aqnu9VVXdP784miNkkxn0Ms9NdP1/V+6uv3jY1n2HgZdcFid9cCXrY0elxSEPLQ9EnksN4NDVvNXTgcqzwpYX8CwzcWqZAj8wP6/R5/8hEttH9lJWG8W/HPoy+0IKVTQb0LUGO9Vpp0+9F7NGmhGOXOWQL+JYe3Bw8tGhtOD0p0EpY5ndDPbZ2JpJeltVaacqN4ho3nKE2VBfO7unU4piBkeAUpHGwpAnPqA4Dzjo1UHVtwKaGUxt9lpMbZlrgYNQpdJpuGUEJ6yIn5qE5fGs9hCAQ5hsujU1aaxS9YmQDQyYi2QzRdUBTWactN9+YH7IwOsVx1flMpCffMDceYV9ZzISLGY2qMvnKhidfLR/PbdwtDuy/uGZjpdMJuJtycdb9UbjaT2eudq+sLJoFtKjTGZjcdySsyj8V5r0kVtZ73/kVRVsXzTsfgRAENx8cRY5H5y3qEPODdSnhCmWxFfPIkx936pyzX7bH8bqZq6evpJCouC+NT218mKFv4QO3QzvbhJoCMa0F/FbXCaOUlaZsZbY2Fr39PSbr1w6kYpwUuTOGR/GE82fFHZddF/46idn36olNelTs3TZ/GJ5Y2HRT3fTnqMi9tdST5OFAklXVlaY2+Ri2NNiihSsaRk/s3OZT/Tz/uXnQflXMXTm6eQlu8xlKJegh1qvaXQ71AxhcfnUkr2KtSpAz050JnjBiGfXEZDZNE62U5Ir3kAkgxUEqkhmjkbEgz+mkKVKHhMVK0uEtDQz1XbZ8sOmeAgSyttdC1+TEAizO0jLIhxwVFPl4RxI0UQiZU4j7Wd65UGsJwXt9rQ+me9l8liFb00j1HDt0hKv0Xo4KoO7lK9ymxeG4fUuMCb1Yi7StGbJE9v/yyLbpa2SNaPpFPLHuiCaqqNSkIsZuXQItSHagr4E/mZAO+ED6GVA7/+AM0lRIdiBQnN7oXi7oqnHeaH2yEWVuYVDJm54OL05fqmy9d2Kb9F0PNLKiNTtwBAzsTIKqpvpFmVcVG1qyLyHQqXOgvleQ92+Llw60ZsjMsgQyAUN5DD+5XYShF2UYfzTs6NBdqd2bTpJWuidWGGxpkqhuw6eoiSRpxJi3UtOQpo5XK0uXJ55AjFHGlY1jmYmU4/0qs4IuTl0MNqBm0QAcAm1Fly98gBmpWS0pgKY7WdZN2zg9gslOPUmY7mE2zGgaJt0RatwdLvgtbkcGDCgxEs3oiteQlEI59ukCIJjAX8dqJRBtJklotQi2X0um6ngTpLse4HhEwXXpFti4sg/NEIMhFC4hAxpFHmzoEmmcmnEBzIWUhOO9AshrzamyIdvuykmbKa+cnIzTFzinfykgvxBqCEHHII9W6f3GOotJHzZ8Oi2A6MCRXpWyrZx53M230BqGnxVWC1NixGEf4A6fhJaXQlCF2xfCSOdU0p9sqAQ62Qqt0aq501pwG3yJEwvt3Ya6MwgnGy2O0+KABiJGWzkHwqUo1IMm40Hbb1GouxvZWwXuCGyNgg3PU6oX0KmBH7rhi74Gk5ADkj8OKRFwPOJ9sMVxPjDLhDOVFuSUISp98PnajNcaHdPka74rAeVac3p3wZa57jzXFWEIj+FPNjSqwPGMnAIncEmgmx/6q4zsDgmf8eZpUpWI8m2GPMtF8RK3ccEGrnvJs+JgUpAU725gmvo0nQfbPStKRMvJJaII9GOqqFR5iqCLOpStUoTALcoyVUiRkD/kFa0hYlqpcK3XA0cNQKzImstihGpZJUVyX/tcRqaQFrnWySzUAUE0YTFHGopRqGJwXwqK+t4QuS6azLXOCU7hbRsBqFLSG4oRaofVfdmyzLhUJonwudYfPQ+GAFSpLA7HMEEVUDUewMhyaHNknhFXvSy05oAqBc6hGKUDVY0H48sqcsFVssk1K8yyWmcdjjHAYyvGW1IwLWQzac21DmiNgAS7LUbhQFXj3T/BhlrLgw1WPNjo8uuCzTGNhBbJVjDYmG+dK7W2csFm82BbKLX2gATbqjzg8udLc129Nh2JNuyWU6q5vv/se1HU+Kgt9v20/+Ia9eX6c/QPo2trz8X/EujwuyPRU0e/e2PLkcee3vbWqUPPz2555uivp7754c3ZF19+5OsXth86/tn7p/+Y3ff6c4//fu3hVcv8F+VvIMUHaQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_etp_prefix_family_k40_source_any_target_all_refuted_witness_shard_9_etp_refutation421_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
