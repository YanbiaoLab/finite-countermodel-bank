from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_enum_order3_3682","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,1,2],[0,0,1],[1,0,0]],"priority":732,"rule_id":"false.finmodel.predicatecheck.manifest_broad_selector.top1_micro_20260606.witness_shard_1_enum_order3_3682.v1","rule_key":"false.finmodel.predicatecheck.manifest_broad_selector.top1_micro_20260606.witness_shard_1_enum_order3_3682","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2DtuwzAQBNAhscUm1SbIAWjBB1kELnIsFi5U+shZiqHkwohipDGMeYUtS/yJBGgME9wrnoLZelkgyP9pq5T10qHR2uqA1nJFNmQfPbcP1WONwu1pPEKKW7LTS97GKEvd4RIjmG7VqLVG6zo6uHJMNqvWnyF3+nv3L8CUUbZXAPqsrS9vO7M0ymYQERERERHRnT6RxFBqz5FN6vFqiZzm8UMi2FkLeY6kI61JT3se5aKG9PS2pdjrKCq7wY7uPi9YInl2lOW8QNsilLY2qcCW4whpK2Nj6m8k+BHZR8X2JfuHCET0JOrFs7qY55TeHZM75rYjaBq7Az2gL5w+3lDnKf6p/dTunO31wJ2biIjoL74Bjb4Wzw=='
_TARGET_BITS_PAYLOAD = 'eNq9WX1sE2UYf7o5qxtbSfwoYc5qooEQM/ArECbrAiF+RAn+R6KDIYksYaMzQEsY4Q6Hw0QSDH+ogQTBf/QPE2qIY3CU62wiGsXAP9LYtdcFohC2uxPNbuN67+v7vnfttWuL3db2SdP07v143ud5n9/z1X0pUeS8KqZUG1XItxexhx1YETEmH6xjvG6bREe8l1J0GnThguSBZOEBDAAprdCAE8I7BUGnPxVsYJQZ8JIl0ZG4hM0hk9i8g/Zqc2GaXPaxJDLVyDxxD7WNy4jJQodMYseJ6OZb8hDQEGfvtSW2Uycb9IrYEA1N1DmNnI0t/cMfm9CwDxvkvKI1W6Hnvj4Z4+huhi2KeTxRk4qoxbDPqHNYzBLlyHo3+Iax25ixgoNVCFKRXF2Zl/dSY13H1u06j3FmJyajZ9EnrZDoi7UKM9mT23JM4S3t01kqZgxf3fb2lX27yOozISLCX5dvcCnvfnYu9DdWM+tFz1EOfamwVYjdGKWkiKtATotblzNQBW4WM3qf8VD60ivFzGMy6ylqNmWlWsaMx1UhDmwKUlFHjQpyc9nMwhn3UTFyWKwIGHTiOokzQfRnZZh5sxRJXauLSMh4VhpsPmFCluNxQQgElJCGKgg2yqj3XDweEvoDmiyHtEQFwcZofEgQnAFFTsQJM71yYCO2PyAcbvH3aUl5JD4gOBP9hbBi+ti5e5tssEG4SX4SYLi/Twv3K+beuVuKmYBx/02Lg403cNXIAah6zLwmqqtEVkpE7Y+bEUrzZM7Nc+y3swJbySFUtzMEjOcS5T1TLp4I4VCrE9miDr5ldA0FWxUiWxJXkVxd1eT2/HgwQtzHZHXANtjiJ4l/pKltuD9KRZUrifTLwUgVHYl6gElkpZHSfaFdstsvdn5PApfstLiAQn2/kV03zI52xFisniAh9JyBNFISSabDkPyxeDx2gBQ4AbKtRFn4dFI8kRTJwAKmM4krCQSIqHEqDF0o6lSqOBnm2CaKkZbUDD9cr8AYsZdSdmQijASSfpHfMtue6G+CMiI1nJmRxalw2Salp90Zl69t8/kMkcwf0IZispygGBAy7kSf4Mgyg3rctDs0NLoXVUDmfmkSqGV4IFPBCsrUW7na/n6CMfLnpZEcTmuNbqdg0WJk8cnlYVXU0kwx078tScWhOLseEnD6Y+ToJPepYBp5fSjmI3LE2GUZViihpxYnEBPGsmZmNpPkW+Kse2Vmo8jpu7bVbas0S0Lz2SzUldxghTLWnWM2Ov1mZpOZnQ0d7T7BVbL6BT7BQKj3nCSJZLquYbNfIFH7VFiY1i0LU3B+tyOHVXohNhFUIBHdUU3vzxGbQ/pcfMJcSDE0eutIt4y3sjVbiN2BVCyzLZDjFM1c/t9Ti9WQqKDNVqNBstHBDzbw3zX1sTo4vPlwCOCVaJLBSKlVy5k+k5rNC7rqWIrc7WbJja96ICx6UlRqsRsWX5hxIfNpSdGarWPrEuheKz9Amf3Wdf50DQQfG/3HRP6/ZW6QfAMrBur4Te8PM9FeOLNuM0D7dnWSGs9kDKG01ytXg6RPg5RVB6fYO5rJIuZ99bK2uohhLLqzwN0Jw2M1lNutiwAXx+6dHNG5a3S0rD0oUrPxXzWfijTBqr1MkQ3NEG4dDzmiVHd0tJxFgRP4eti9GY7sudpAmT06uXq8DpIjJ300qPg8alYoNgttqfgN2to2ioFt4bVDv3YvPVi/jIKN//CNQ0fq2579YlePR8WYr0Uz3QAqxeeIxcDGM7CtssGmmmBjCV/PsROCXT7SYDfPBsmbdR0fLIGe9yywdZ8/S8D2cuIsS/g6/bQVZCVUkhm0Z+pKLNkF0gbJj6vD693QbYJtcSuAb/hSrTrU6cfcsdf/LG83km/hO6OwMERMkV6b4LvVBMlEg3z3Fx/a0j59BZ/A2VeviHkZAsoPQ3oxsOU4MBtbrN3/85K5BYwiRutd8XgngXJN17cr393tUAcbQte3LgeQVu51BMlJjRwxYOHtRjedvlbZE22AsNZIG3v3ZgE2/oYr7N0P4HQe9QJWx7A35QQVO72s1M+J0B7+Bh5j06ewiyglhUfI25WziWxvrXNsjD4Mxz9to3+wfP3ipp3fAPTUaYeMAtb71M0NdPrtBZ81LwN4Z2TN7By19V+NY8Xvza0XYG/ko8SdoBt4pfnikK7kWe/HNwfZ9NMa8zb6gwqeVWAYILpMEl9oKiotwlTBJMcF9F8iZzLtgWZdNXNdz1GJ6vjXfMO3apKN7n1nIiSyXfKpqEAIXX5vvmC77OG5KXgCuzwcoLEI5qZoZHOhQsLNN745jg/WnAo+AvB0YHE9/8OG7cHRjQ6I1svT7XltIc6j4kJpZckJUhpsHc/MBBv9i49VH/bk3s/jBT19yUmok+gyTGztJxZT09GOiMBN38zySMzpivvv5q2PcW5uW8mK/A+vu0uE'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_manifest_broad_selector_top1_micro_20260606_witness_shard_1_enum_order3_3682_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
