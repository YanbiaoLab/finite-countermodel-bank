from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_opnorm_09.0123/0200/0030/0001","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,1,2,3],[0,2,0,0],[0,0,3,0],[0,0,0,1]],"priority":621,"rule_id":"false.finmodel.predicatecheck.model_family.beam_after_k40.post_frontier_z3.batch01.witness_shard_2_opnorm_09.0123/0200/0030/0001.v1","rule_key":"false.finmodel.predicatecheck.model_family.beam_after_k40.post_frontier_z3.batch01.witness_shard_2_opnorm_09.0123/0200/0030/0001","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWc1uwjAMdqxMCjdT7QGiqpP2GNnUA9z2SNkNbqzaA+xRF7s/FEq2SmPTAH9CKMVO3NhOnC8AZHAPFADSByzcHj6qN4sATQAEdAGiAwOeJXfGEsBOtEKvbq5s+u7ggXJqARQKhUKhUCgUCsUN4r1qVmX5XKzreoXGARnfMke/rcqyegUbN4lV+ESqYGeRmF0i1MCaiUZsNkBQMpHijsEyoyqTOMoghD3LitKITS2G5EffvYGIkqEaLKX2UoZP1KUYOByPUDK3WY74mu2pTBIfE532+aVZsf110vSL1KjroW8RU7ck9AMVQsdjsQOgfzFMNtxgw7T8ikwvPCRb14xH8Ik3x0qChe3kZfahMOK1jklL2izY3bGLq6QNLftY7929d+nomqJ9fpD40ZSou26MUdpY/pa0GbQxQ4f90aS8rv3LBY5CGGfdb2TDTepNxY8RUSrICTjOPFOZYdc7AwhyV5dGdl+ruT0Pbl/NDzeNOHVfaKMZ4fudBGdYnvTEqdzMucIPGsZfRXeIlXNKPFpsNKkrSZnCZHGaaRmyX1W2E8s3W+zmHEMzSRu2HtfBuUxW4Xn/HnHE9MCcSmqnB7J/W9mKJ9vEv6ok5B2zPnX7ZeETy6Ixag=='
_TARGET_BITS_PAYLOAD = 'eNrtWV9MW1UYP4WxqjirWSIJRhof9AHNeBFIwFlissSYsWg0cWb8cZopyviTbFCyKQezyIjE+CYJ/oHxsPAw6RbjgHXdraLyMrf5QsFS7pBI50q51Upv4XLP5zmn/4C2k8beKKNfCL33nu+c735/zved33fbFQAMIfLPQYw8IAkA9A8oxyEze2QyEfbjBDDLkBL1g6ILqgkGhmWHRHCCAdOg0I7aFUgHYbrMIklpSq2zUaHv2yCACqosAJaBgMhGVogiATRxLiHCTiC91PTTEUe1dBmsGw2Aa55ZHYfvEkzJLqnMqTjmjle0L7976MJMs4JjrxvxClnRBb2JtDeHLyw2+gLu8ejAJ/AH+KJ3glHCpA/+E0r6Uhn6HxNG9ug1onRTU2kGFIxcGpm01bvHkKaY6TBTzXcXbbYVmncBxABPhOEE6HJpJMyImnlYjDObUqIRY9BONT9hgqgJWe0IiiFXrmq22Sp+pq4qKgiQyGbbs3CaQIYytB1ozXF2HII4mLHIViChJYotsNm1NKNkTLIVqN7ZMOxy2bwXrdZhlcggEZEjRxBbnS6Xsx0UzECjqPKirkoMXapgBcZJcYnZDBK4GJBiEwWFISoXHcZ8EUmNoKwQVMQNVi6IPxQj0cKxaTudpEj0epEvT6GaN4rh2AouKnEdRgrHFx+WNigVurc0DDP5F5XwocRqjc71YjqNDopRbKXKbC1mAIi8mEplyFEZXDTTOjII8naJEQeIFDdjJ3eWGlKeay94CbdaGEnzsAkwc+OwX3nYSIsRX8fMHTMpxBJF6P4X7j8pHqjL4TXWhI3C/vOwiXKv7Vas9ZC4QSkxs/e3LqlrXIgT1KL4R0ndLW1rQ05UtU79dq1+aPTaiakWR7llvua67cuT78/4VQ2E9eUZTD6r74Oi9rxnWTdML8MN0BEhjyMpozoHs2mUlp21K6fipcdR3Rtv7XgI7e+6+vzomSzUXzzxpxaY7Z6nRuzPjeVMHNSP2PM9KO91y1iNfqTgqC/AIo84STTrpaNBQoryOwCQnVVWxJYWP9zFOwuEZ18lrbGtQz/23h7sqTx+wZ/F8Gjj5Znm0a9XCjxaHPE4mE9ITE0TGYexNErTdw7ci0pfQfe37Ox+Ak2/+Ji5cGEH6vfvrI83H08qspjcg9KG9BRHCGVNfX+1rrDro0IdVahj4IX9Xb3lRz4/tsAnrUtRvHQRTzJZ8h2T3T9vtnRTdjKv9Xu51QIhttgR7N81SND5zjL7vt0H60a4kPyh7KrGwSvZPi2aJIauzkc7qifRg7bcR1pR6+FT1qZbD6CbM7mL7IuCGF+ZJCHuuwKJL0NKss22jwa40DYZsind5dbzxpU7FbvNHEOTBK3wdE91ic0fSDBkYbqsU2Ox1/NVT7XZ5n9XWpr22Bzy3hSPUO4fxvBq0SpREuuwbjUj/CrPMvb32sCg0rqAv03RbR2VL+tuTC9vLnrtZ+cPMPbfz31a/iRCh9x7U6xsoW81m4ve4x8vdXL2M3LZwlKnR9mZYp4+RRPXZjvwBt64j7CHsmhqm+2dPdajJ9wtjqom28IlzxevnrS4ayTbFWlZi812vfs0BGuDwTzBYCRzeHZMwbdYYzdXk/an7rOzWf2ju1FJsbn3vo75A29/M/2aDk2WScsaCDMVP1z9pm12oP5caRULgVyb47CltEosbdNCNf2Sw2Bvwui2KNeakKDKKgT0yMew+l+byyGlKUj7G3ZHvsI='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_beam_after_k40_post_frontier_z3_batch01_witness_shard_2_opnorm_09_0123_0200_0030_0001_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
