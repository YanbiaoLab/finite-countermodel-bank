from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_etp_refutation478","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[3,3,3,3],[3,3,1,3],[3,3,3,3]],"priority":436,"rule_id":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.batch01.witness_shard_3_etp_refutation478.v1","rule_key":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.batch01.witness_shard_3_etp_refutation478","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt0k9Ik3Ecx/EJEYugZkI7FOQcuINgdHF02J5tGTvFczSQTdi1UTfTyfotMZioKEStU8MuHcoeJP8wJs6DgTKCPBSVyhMyYQSb9jCfh/b0PJ/wObl5/NElvq/b78cPvvx+v7fNRkgTe6RzwXHHdi5trYbyycX+b++lwa6Rsw3HApXBxbn45Y+xyUsd9GiEEEIIIYQQQgghhBBCyH8m9Xx/HOMva9L5race05NQWoPRdbCxT+F45snGZhvafL/T7df3IITKbu5pgSVjedvIv/5e11X5vnZgru4Wuka+7OBq71Lupv5gWX/I5Kr8zHevyi5wTxOkonlt+IhFb2S7dVb6fGU+EQMmXNm6IL0QM4ag/Jy665sHPsyILbzDfgizRSgdJttzj3ajONGeCNVKEFxZB4RfrcEM9m87fK6EguyMaOe+2hCOMVQ0oIATZAYDjS5yT5srWh0MOF95xD9ireQeXUkD9tnpr+9OZVMPPy5zZXNoWh0MGJpWKexWZSOZZ33q2xxykqk3ZbPTByPJlc2jqNUBVmL+iIqNN97Y0boJ5y3/v8gm1RM47mBB7g2fiZgZZ7A2Vt4EC/ldce9aS6oxm4p3iy+bQ9X6fkU/aAqiAFXXm/aggS+bv18/eKw='
_TARGET_BITS_PAYLOAD = 'eNqlWXtsFMcZn7NJeYU4JEK0IGSURKGN+lJlgVKaHKgopWmKrKZSFKngq9QaWjCHGriTOPCcKI/mj6pt0v7Rug4QRUoqNcQK5M5hZc9BpVZJnDoNRMas94YqEqDC7ZJAvA57M9OZ2fft3p0v+SQO9jXfY36/7zHs3YeqMDnMIGOsXTUQY8kkYxZj288RkzH0KuYP2IeWyn+TXz1dpfw1sLHArwj/YzIqPuTviZ9OsEveda99AaDrHWzfNczgg7ngwk5FsSyDcQucb+WKSVDKXPhAw+JCPGXUfXyGsOXu50ZwrQ5a1KaYNJ5RS96ydcE7UeUKXwBz46kqPnLNu3kTHxFXJv9IPJUiPu1Rd659S9dJUcPIX0jIxczFH2a3yhWI6ZnLZcI42cevVP6TVritmvsZ2jPBbtvLwrDRPyenBixVKhbxhZ6WDp2JuJN7CRaeS5EbAVOW1Hr0XVYjv/7YmHuJ+zHjW2RLz0B5tapp6gnkhxg5uyKkO6mMEHsDXFXfe3HyBy+//kFmj4Ew6zmy4cDjLz34RPez5w8+HVo6ec+zj//o+b99a/CZiqbzHZMyJd00nIgFtyEoFPNXYNwuhsWq92CurS2f6O3Vw2AjEW0ychJJUiOpq8usp81WdiOKXxSzDBR3jdoXYMyy8ZZ02tp0FHSmjtEwpMRkrUu7VFaSZBf7b9jhihXDtQSxzybQdg1collW4JDHGrH8PYqBjU3NpkJj73Y42u4eBJ9WX5f2mzXOhGFjss8hCdszYa4NgRBIamCDG4I7jNw4cch27On+1f3g7XHasegNi43KFYUiQiMs6q8TMoqbu+aQTe3LZtNKRdc1TVGyWWPEpB5sfBiK1IthxAGrRbKlhKK+oqaNKLmsqesjZlkqMmVidJeLqQ9hshmxZCO1ZNshFB0/zN16ytDLGldmSUXUCoYrWqZ8P2AIhSg+2jbZ8pWCohzRMlnzfzKUZjnnR810TZaKREGO0+Gz1AsFrM0SDtmGVmT2mKB0l75l8yPDuT3m+zkjJmqGm20a6kDBnI1qyDaDHfRhCChpwMu43qFlspmucVZHqUlGbmTJbCRps1r4DGd+y46En6KYktVffzHUnGwzhuwjONlyk4poJdyo00iKiiUbDkW5bvVxyOZh7doasxjgpZ+iXJPjyWY1Il04y3ZOdeTF3/8SP/+0YcPiWOsVg89V2dTEMN+866cURTaGug4/tf3IMD9q1DdTcgDFowU12T64y/GI919gJtoPxPTFs4FkndaogyIsGi3FYp35UKvr7WZg96mfo0lcsCmLa438Fx6uzvyD71O/hZmSpkWOjFHxlPCA8UJD+A3fLRMLVquOr7BuGsYExde55OEVmZn/soF+hqD6LiOGTk1WlF8WxZrTAnDuclT0ENASi/oI0b30RYQNKFxtwlG/cgNDyoE2zqiRrAYeOo0HDYE8WtqjkEDSFBq7vdV91XGG09xcKuYO2w3q5UIcjHxMG0mcxc0aQuDYruHoUfZolY8hRxhO0ityJWRvjGy+Pd4afudFAmwL+UEbtOT29XZV1mpR2Vb9+We9l3W3smGoEqLyIS8HOQMJnzSIgSrU6RzctXnVo5jDCPuqsBfYSJ8E+xShqChK6APPj41N2U1COWdYaQVBUccM+T0M9qtmo/6qQS/2Wp+tSNX1cuY5u/cZH5vKGftlhQ7xBrGCZZmh7Zd2wJhMSWL5/UalwBW9kLk4qQ3sPH0yl53Wr2uTufGRmJEz0KIEGBhNMAGAhIOAClqGz4YDm/j2iLGW9z6DIydzvLPzGjvTt9GvNREdRnwowxyYKFjj0wwWvn/5so4qwah5u6nzsdmyc7SYWfs5DTwDOEIIUnI8S/sfWqxugbiYETjHYvYVKSoQNdcyHMqzTmMXJFONm2bN48Dm9aA0z8VWH38l+dY0Y1n+1H61IJ3hdiruF3FHBIrrCG+rnaDpuhNKnKu1Z/u5yYJQJKNWNYnOjbekddNel+qiMm05sPHJls36bpHg+BXePccOeO2Eou81PhH/vjWBaXijYTS7o6YotOoPxWltz8RmY+SWfN85NZEHJDA0gPpJ0Zy9jijZXlXoBM+U9LbKo6Y71dOKn3RjYGPNdt6wzf07Pn/bJCpfA17USIVXNudJn3gq3s96YZt2/VY8Hd6uGZ67mqsERfBf/OScoafhbaFoJ7Hofosnx0ZRs5r5gVh9soE8q7ioQ06E5BJSJWm/gWtWbd7Q1W+POkHKInYQampxpUhYZwr85c1wSsKwmTJSvwC0A+pSB+FI3f8QVnnfECZOg/Mss4l70B4O/UnX+0jcgs+p/x6rNhyeW5IOMCSSrldG/PGOqjrrSSoClNlG/rQ2sx1eJlzssudgPglMdTvw+4iRROpkKLXyHsnzslGnDOvObP3POIldnt35vOUkSwLS2lDWRJw2khmu5X6KMCCDnWGs0dkobLDDoJ5sE4quFjESy1PDO2marnHWrNXRYIc723aIk3C1V1HWljY8uE4XxyOKaBFkw9f3PrKglxRD46hRb/htQLbt6i/WaIP71R3Z7NYBedL0pn3SNCpocbMHIlmzJAG8cbTe0Uss2WD0NDIqpzaLHK1Kr0yneQue/aB6xyIx7TiqOY2MSP7jd9IMP8obAkV0WxXZqogWFjk6zLAOvyMLlm8YdxoZI92C1ZNfgxim2T6RtANnP010BPrx8N4mv7wsAzI/be++9fUd7yUuHFqkjx5fC/K5bwwnwN6lq6+D62e/kMXvrQClkaVTlaUEeweU2F36xuzJNhe0bXygbQMAc+bMX/mHeXcn1t+37vzBr9wP7n8FtB2Y8/uNc36TX7l45S/P/nFxfvFusH59ZIU1LaS0UndX4tLhBeD4WOrMnPyXHrq06eAgAN8sp+7Id/cOpdpKdy7ZtersJgC+mB4a/R2fVU3sQRTLbmKaRzkrKiGmPJ/yrq7Cx7CimE7Ff/hoslnkF6zMyZbf0gUWaQmw4if7/wO6duNDIwuXg1I5ZYgDvNFtYNlp42z50CKQSg+ZhWsxZIMtZK12MHuRsImSrYWj/+4uiYNjVzdfGGofWrh8av93swCYW3ZJ2FwIw2ZlBDatVjaJg2Nt8+bds+6+xSvbDmzIvzL/ycfAY92JCGxABDYftVjZjnMczF8C1v3pzIH5YNWPNw4ueDgBrn7nzAJw7G0Bm3sfemnTob8CsPuF1B2l7q1D29pKi5b86mUBm2+nh6hgAJn9aeSgwEE7WDtsvZjYdnV0YW7papAfOVNO5FdMPSJgM+HDJn/XiRrYyHnUatKG1x79f1a5ocKnbGVxrWWkDPwf4JJv1A=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_beam_after_k40_top80_min25k_batch01_witness_shard_3_etp_refutation478_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
