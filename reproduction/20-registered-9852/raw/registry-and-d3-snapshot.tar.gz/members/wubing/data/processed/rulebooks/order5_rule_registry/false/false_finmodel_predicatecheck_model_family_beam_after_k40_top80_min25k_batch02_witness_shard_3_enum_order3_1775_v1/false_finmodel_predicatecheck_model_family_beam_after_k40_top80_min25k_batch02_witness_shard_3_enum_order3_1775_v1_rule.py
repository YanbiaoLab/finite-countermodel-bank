from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_enum_order3_1775","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,2],[1,0,2],[2,0,1]],"priority":452,"rule_id":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.batch02.witness_shard_3_enum_order3_1775.v1","rule_key":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.batch02.witness_shard_3_enum_order3_1775","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt17ENgDAMBMAPSpExMgqjZXREGio6QJG4a+z6ZVl28oWS9MBjWpul5pysmk0i/Mh+tcNqBbg5FUQAAACrGSJYUfddAdY7bzsAtxYCbA=='
_TARGET_BITS_PAYLOAD = 'eNrtWVtsFFUYPtsKBUmFaJAEYooVQ4KmROQSaEg3ER5UrEYfEIFCjYZGLisiDLDSswmKRsSgD5C0gIUHfODSTYg0dNkOIImSgGBC3DXL7pCoFNzdmZDaPYFh5vecMzO7s5dZu27biOF/2N2Zc/nP/53/vjqIIgaDVMI+ReMhflcTQTJHlgqqIkJD3V0+DcBaMVDSIb1VNhGH90XoFkClav5W7ANK5kmih9TSTzgug6yXxGRFpLHhV7iX7AJJpIdkyMgQZRundDVpApAGiDMmJIJBxHSUKJS5roGo0qVAnLls04hIT8qOpmILeEaeC0+Hll8+rRGJvtXZNgqwn4DfnJlYIJ+TGYPsvSpnvzLCvWEVaHQuXUMnGMugBnEqID9KHXK13IxhiqZqYcdRWyysj3cBtGqdwQis+GFhesVY788Bf/qpYcKupq17gyeonNk3MQxEDFjVvMseEtJ1JiC/7MxFafCAHlCatByHlyHR8HR5pP57ZjZfgUt3of9t0gvL+X8g1VFhhoCYX9etWB1QC0TMwaSxmWurKRhtBtfY7qRVpQ/rDUPLThTLstWSI1t2LlCMeOhj0zG/Wa10perh0EmMX9KDydCKNryOanufazPT/n6Aquv3sJa2P6eEwZbwOp5fZTsWSH9xrtMvFh3uM892LCB3x4NkeJiJGkdGYjALUQ14Gvu/imwDd8G4LGNLcR1TBTJAXSsrNKyOrO2KRoNaCtSp7Yl1sqxLGqsLVKmVGlvEQ12UAIquMRflEVl5JHKvw15SYASi6JLELEwHayENWnSYgsCslpY1EAPwGin42kDyZCAwvT0hy6lvzIP38jKKMVI1QxoxLRav4Wx2qNvtUDAiM+bVkpIPv6J0STqGVAQUw99aUzH9JB5e6zGlZbWeyAAgQKdn5KCLMDbkwKyMZAstb62YmaHXPBqrHNlJmfrnFGWYfSmi/bLELK9Kct2Kkh7ScuOXubN4MropEo3Cq2z7S3wH0eYLtZxa3e46dYfsRgMTCqfIxitkjloU7KhxkGXDx7Lbz4tsirm5yL5UzBcyBWJH0YnJXzOPNsw+Q5KMml/M9At0MPRZyqgNZNTGahGYAPAvUw5rYQYK475Ipt5VbYwMXSuCWsbYivIwI5sNRFxmkXIf1GyGYbTane2QJSmiaPMsil1DHRKPf25sFDG24aU9yz64sPD8y3WnPtt8YWPo+em1TZdPH9iy7YvbSd6L4n0sDLwtBYQ5N101Olr8JVgdLmuOCpAe5kvAHOR41FSMmufr6HBNmeea4VtQ635oZWz3E663R4y/aqBGBhWPyhkuhNZPRWiyPGU8urTvyxb6jPzPxU7wzpzUCuluG3Pb9JciOshhduRsUNjlYofGyIn+ooaOv34x9keRJLTkms397ETfDhmdeUQ+4EbjZsjnYp9Uo5UeP9EjZgyyqWzSFn7M0GkVDGQgyYMLvfPon7smLHo9eLuCSZQIts2de/Buz28RjponC7UCamP1QG1w2xTICvjGAzQgtAAhV4V7coWb4+cb9+RTCI2qHWWcXBnUSrjK6dbc+f1Yo6ErYQc5ChiCTS5+aLpv+PzFlmno82lMFX2HXkKorf7dfRsSjNHNXyRlMI3NUSNtWUc6wS03WlQ6MeuAFBNGt6UaUlbj2sp4NIeMp1B6XcTYhqBB4sTMp0fouVtNsZR8YyPFjC1HTJI2NmbVPS1oYjfDlFk5/Slc8Q6F92+YvHeZML+v4kqerilzUhqwfzlMXaPHQ7uPHOPT34v3X4wHQ2SuZM7XLN0UwTY/y0EySD5d+H3j73Vr4DKEcu5Ty0tKa64eEpr59PdJdXRWc8x7tsQOiW/RG64r15ZgLQnxTlGjOpeilxMA6BT1FPSHJN18GaXae+bwjUY2/dbRPfXPILS0d745n2apHmBTWf6fhAh0MU1lNxrlKSxT21ix/2oGpL1nSjS28M6RHQfrIankOHbQ+zBEcLb2Jq7LbLpal1geRig10ptTqcq5RUfOcVfXBeStvRtDyzzBRHd8/2JvZ2+TEuxR7nSvPt7VtCna/9ORYGhDJ2mSyEflG9vOHft/XB7ueDw4ZtKmWqF5e8Bz8/jovtiYda/tpDGu/quA/2x0zoehj7coI4hqZX9SnhnZ6pxCg5axtR+u6Dj1GJo9S2h72HejcdV315a4UHieMhq1t9Wz/+W+PfGWfBShNfvJvbKNDZVAilU+4gJNODW/z5B3d1X+CdXuFwS0skpYMRNVR4Vm5dxI5J8Trkf+7YHpLH0I+IXmShSelNAK5l2l5GJ/A34+vyg='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_beam_after_k40_top80_min25k_batch02_witness_shard_3_enum_order3_1775_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
