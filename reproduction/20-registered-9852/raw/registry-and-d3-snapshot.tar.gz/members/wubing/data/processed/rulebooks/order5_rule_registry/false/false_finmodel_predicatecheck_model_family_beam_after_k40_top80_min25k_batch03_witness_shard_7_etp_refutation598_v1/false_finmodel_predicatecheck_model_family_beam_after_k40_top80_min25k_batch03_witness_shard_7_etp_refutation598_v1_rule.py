from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_etp_refutation598","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[1,2,3,3],[2,2,2,2],[3,3,3,3],[3,3,3,3]],"priority":472,"rule_id":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.batch03.witness_shard_7_etp_refutation598.v1","rule_key":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.batch03.witness_shard_7_etp_refutation598","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt0KENgDAQBdBLSACHYYCOwCiM1E1hAjSuDQLRIBig75m7/Hz1I+Bjfp/0W01rpDFvNgMAAAAAAKADZ8Q1tdEeUYY2uo/lObmUvteq/+oIvg=='
_TARGET_BITS_PAYLOAD = 'eNq9WV9oFEcY3zTgvRTvoVChkJ4P1r4UoaWYh2AuQqEIbfGpPlhNoK226OWE1ltwiXNtQJ+koA8iwbbQ19oKsRd1uOyJDyEYFbHlkmz2NiBNC+Z2gmgmzdzs9Ju5v3u3kYTc5nvY3GV29zffzPf7vt83d6ZkllB8SUjrnJbX+Fn15cRjDlfzmvryRFhy5J3bJXmb1jcugiymzYtg0zRtOh80ENFygxiz1oG4fOSOHfDIdwAUCBIdGLODHhDo1Z5FIjzhyC8Ky6yMPKHORPUup/GRfmuwZ9J1+ZjtqHtpbWQ2Nfuxfly9gftQ8u5oArAsuCQZDNWmYp7Oo1X4S1om9iW/McIscbaKXkOJLqo//DXe7Iqm5k9+ut/8ruFlEpmniKUb3Cu7MnI0Zdm2tQcH7ArYwd5bWe6f3ETmEVz/WtaJnNcYkRuE4KPT7/n26PULR89cvvCLefg/9EDtmLR5U2yBRSpo2rZjXviAFSy2FZ4BjZSdpM5WoHUqsPSWeAbhW7fr4F5sjoe4ptE6WI5ngPokTN86KlCQFhgxgS+QcbgIyb14w0Jq0xNeVEsz00MsXLINRPQkLrqubWOs6yRLvRDJJoESkNGz2NCp62ZpIUSyKfv5HMaRQ8Qt2ADGwiMbxP4wPt+VOkXn3Tv2MI4UjLDJpuW2u29q2k3jFM0ZJByypXkd2Qs5kXQ0IERzIYPFy6xWnpV+EOfDrmxSEhlWQteThoUxD7uyAavVx6c6HQu5sq1E05AVO3KyspWFVzTEyjbdke6a2yfJpoSh61byo7McAtnmKx6twJqWwq6j0QHhSH0JwiwWful+d/H6XUgfKeYITDwKQnBcljcQjaascdQnOFtFtvBpX169rXG4QenEz3WlQPgPb++5aUzbgkddQFTCmKur53udBELCr9C91rey+rA/M01cv+t5RIDU8kQ87KQlVoamQURH5aRV3xGqHomZotcrA8XBRaJ2JDS1dcJStbqYwfjtK18cWyiLBFowHGRxbsmMhoCBnDPCiVn0PO6LECqI50Cr5QTvXjPZElgCjdkpne66NDU1VxYJBYOwJDaRjBSiIgxVW7A1Zv0SjLr9nigDWa5bSF0sa5+HU3MGGaqFYi1HmyLDGJVO+PxAyIeBakxojYA/ihkA+jE1O2OPDN4eNfRld9GeMR5m15reZqLWzNiyNxz5BLZHtrWgfa5mRw1QdrXtoe2LkXyGQepFmQMLC65ZbFy12m661bbZUT3rWcEQrS4SRAg3sQFJp/4gqwdQs0GjblOi3sNNEXIv1Y+TmHksAYkkPrnMBFRUUobMKGcYF7i63UFHBLUjEF2vbqjrVgOoRR2eeDwzDqyelKvGS5S7MqJotbLVc6K0JKuEWp0Duv7SVNlMtqe/YfcMeeHAO188djxR45Vscyq7WEvnQeGykS4oaZ/OHyHZ50wSeLU8HSe0xHwNe3nwx1u1YG8q6x1WEyXMX50/Vym3wBs0a/Micat+JarpAFFfPHv+bQuocHzN+B97kSduUqxKoEHOoDeE5BiijJwOLmbqv6RzqZ0qNqYNME6CgoKMcREb0N642d6ebWnt7PGk/3m8jXIPerZFYPUaiR5dtB5MlUTbqrg8IIEuNAjLckV/HJtcleZ29Wzn3pQuvl/ug0G3zh2seP1IjrZVyMa1eaQ39MFL9SGdyo4ujduIBjLS9QhqyLMVxQmsQwLFlkhjAfI2TbY17KsYuJnuLJhyDh5ZP+BLdjj2ykl5Ej65B1/pyX2wu29woSDVFkgEJfhOXhzBejtl5Nfd9tUh1fz6TprGpUQYPZLqpiAiG/V8uw5IfHbjSArIdmDBUZkVtfs00m/pZ/eSXn/vrftiRJKt6MjyXe+qKr6aDdMg6yHbGnaw95bJJ99CjkiKIVFsD9l2jixn9G865dE/bZrG4UPdxQRZ+FR3ZoZ0mtULZAdv/ukE1MPSRg5IRkEqprS+bXrLOc3w98cgbBZv424dtKzxsOtbbf/+ljd0b6RnU1ONMtacdc+3ljQzutISYxuUkWU9oDvNz2VaD68z99yAmN4A2uFVtWr473+Yv0NykGh2rl+GzabI1rdXxoFn/ts8Yh193hK9O1c3Sba+4zIORMBPizZvKRWbLXD7Ge1cYjEtR6G7zxF1ONKhlZDkPAMOzFO5vp6meab4MJYWvPmEKKIpgQQJaR0ycu9VmQsvffQeZrJVHK+djx/YfcXeJ1NnvtYP77psmy09r7kBBRHR1m/pz57R5sW10A70+boX8n9p6Y9x'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_beam_after_k40_top80_min25k_batch03_witness_shard_7_etp_refutation598_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
