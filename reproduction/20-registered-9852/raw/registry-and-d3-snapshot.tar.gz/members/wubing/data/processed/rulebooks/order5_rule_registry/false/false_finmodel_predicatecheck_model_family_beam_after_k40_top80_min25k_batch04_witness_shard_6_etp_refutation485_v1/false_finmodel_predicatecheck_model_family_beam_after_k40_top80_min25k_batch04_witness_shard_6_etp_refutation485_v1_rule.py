from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_etp_refutation485","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,1,3,1],[3,1,1,1],[3,1,0,1],[3,1,1,1]],"priority":487,"rule_id":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.batch04.witness_shard_6_etp_refutation485.v1","rule_key":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.batch04.witness_shard_6_etp_refutation485","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2bENgDAMRNFPRJHSI2SUjBY2BwdRgUSN+K+IzpLdpD2QbtbosB2hMV538wn/TJIkSZIkSZIkfcugBNEprFSCTk4LpbYjDzI+X577g2spsivJozyoWbDMhqXMJP3ZDpirBnM='
_TARGET_BITS_PAYLOAD = 'eNrtWV9sFEUY3+M0jQRpQnwikgqJmvggxqAkGnM8mChRDIkmxofaEhRMtJwm0iUcvTkRQeMbLyQSQtUHTFTAAFdhc25VBB40FE0pZd2bmmigtLdrUrlJu539/Gb2z+3dbbWtXBObfg/d251v5pvv73y/aZYDEPBoswEVGpmw9fAlAw6+pdaUuRiB9d/AzKibrDFo3MCBvLFN05z6gVTO7LzSb8ZMGQZIOjOSToaPlix3RlPajOcyg/Zkhw4mcKYDYeCC1KCchRIwAGEJz0AM/Aclvi2JHOWVsSmoC3DpOF1Wc0ZbcYUTJspwHVzGRum6WFn3BCDZ4k84Ozkx3NTbg5KRF+egdG8aqmKJcUO4U3KHlsg9vTHRt2eQ4FfHjop/ir010gNqlts65W3M15NX5HncqeWfP3P5IHqPlEwb5pbO56UdcoktW1wdFuj/QUTJlfDRNOSqkMd0oiZ3GietWdkhHspdh5Rxng/Ddj5QSlFy7hh8OpjtzCpXL7rNd55yMLEbZMzzx0WVzhgdqprWSpZlmpqmqnaBuY2QdvXtUFBHj2kWtIzKLKvAio0Q1qK0fxYI+ngvqvWibRVNFNYQU27Obdq34tdCKa9p+8xOld2QpmTFTGOSTVGOv6v1rOjczpTepdbLrU98ndnOfs40JA2a3YhNFbfB8c/HITjKxoibcmGBZkdeJ0fFEVpKEzafVEv+ktgBJDV6UtOahrhsX5wFh8+CvtSsMyOFOYoN/eShsmhXs1jAnjc52DdctuCCWRAty4ejzon5XjfkESpOtvtPj26xLIty3YGiQzsN00RvakRltks5sXna4baLcISDJiCK6N9VFSyEWnjGIw/oopfBV00AHYQXtpe9bgBVSYcmBWkoKH8YUBRybXURfxkEBRk2QVFyeZQiBUkMBxIWSXNQvxZQsbwMO/EIDkbd4/DpWKmHi37VsGxadijXNCKAFbGJQE2IuBCbcd3DenqJgYPwi0k9pAzqIbFAhmzSVCFK4imEa4F/+NzHiJ43pXvaQCfwEzDcVUFoL60Wwlf/dGU0BIAkXKHSS4Tbj8Cxasw/UDYEQhbuqbVa3nHQyARcD7iK6EVLo0Odiq1syxVwGHcYTgxMir+pE+5i3ncDI+I2xrOzLrV1fcdQF/+KawjPQzxwkPSmHviSRbxHI54iNY4k875Gci/YslFt6cLRMXMqRi6eGIWw2MZ9YiJAXce70ZIfIbjhCngcgHBYTgF/UAZny/IbQZymzpzb+f3NqmrUMvTJwdOV0GVB1OvVn6DqKozGDPqU8bcvruFouD8GcZ+ouPkTyRmvh38jFzFFVC8hmbTqaEdvE5M60Mq+egTj/vXFP5DVWw8q9ThGD6c+i+si266xQoVcw68jFTQJJb+OVE4PIOHd5zQwZULJj6E1sqhAEqGpIgR3gRNYbeuJqNViwia4A42YOxJAnmGDF0gpveKn4eNgZSjUN8ZqdhBO0zzX6pQ9cn33h0dtsvmDfkh/8dXSDOeP/779ygjwmPvYuLD550SI6CUlo+kSf0JzDr8lULWcYFaUSd9q1y9T+1Ym27Jt4iZGJtvkOfc7VmUF7Hd05xYmm99GxnQqpXJ9stVdXIueIvDav2M9DIxLr6nq2rs7VSZiZJ3KHhx9z8zYhUrzw6s2/V+SbfWGey+9cK3wxv4LhQMbHj19Yue1H368cKif7aJlw08LPfAwJpsfNuFG/P9BQJAIdaJrky23qFtZptyzcuUioVt795KNCaVv8brxBhztqTdpV77Akn11sWavLWPzXY4238pJ4Hp1P+7z8yA2dagajASmcMy+vWewwSZjF2GgOtZSowgKfNP4fmtpXVX4zfXsRqHeSzFpXtOIF7vAZLSN8BKMHNM5xlwZK6GGsEB3y3BzgLr+RxN3QrHxx6IVhKjYusevAqRBsCLMwVcDekSkivJpCjQgw7YotjhViZKvpDpp4vrxuHIVybKqhHPk6iko2TWFHdwxCaWimSVa8anDBges2payhmNYB2sCPDTq/8eP2CLTjfrzZ/BVAf1Gy3K1w5n0jCPS9rOX+R1y5YDyMRv4Z0mVaeksq1aC/5UcMlpyE4wPNPem8VTTeUKZJIzqWi1vU7e7C24m+4wUJWmsQJzOEPchZgv6AZDtfqiHKJ1cqEzCbZcEaONTFKbpVK2mJ3cvzt33rPL+2T13PKB89NA7/Q+/crvSPnLbEV52HAz4qrv0VY9skuztp5a8lFCuPPbtuI91p0l/A5Oczfk='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_beam_after_k40_top80_min25k_batch04_witness_shard_6_etp_refutation485_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
