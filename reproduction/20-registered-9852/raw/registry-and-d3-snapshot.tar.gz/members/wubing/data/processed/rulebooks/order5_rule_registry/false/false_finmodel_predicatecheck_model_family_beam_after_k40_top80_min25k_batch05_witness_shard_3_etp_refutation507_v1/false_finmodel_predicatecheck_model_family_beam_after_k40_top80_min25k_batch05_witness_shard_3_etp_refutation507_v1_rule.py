from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_etp_refutation507","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,3,1,3],[3,3,3,3],[2,1,3,3],[3,3,3,3]],"priority":500,"rule_id":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.batch05.witness_shard_3_etp_refutation507.v1","rule_key":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.batch05.witness_shard_3_etp_refutation507","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjYGBgaGAgBBZ0gMiGC6wMo4AeoEFplsYiAWcsMqqnhXcL2jJiSvw5uenX/h4JTAmH2//+AwEWLfc4Yv9NF2fEFd0MjAwBTiwMDBa74BIfWvRc/BEmvzBa2JrB5OHAMhpjo2AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAXDHGgs6lWbZbnloptxu1qXxpELMxcaOCe2NRnyMdHCtptpB2r94/5dPvrvbP3uu/t/z1fUf/Rv7q9X2rSw7M/Jf///9934//++4OlX/42SCqeDxtP8zyny0MK23N1vt+3e/R8TMNPAsgW6k4+WFQr+t/8omLj///uzgraKVZ/+z5/gz0ELry35O+mpaNGLTWuc+P6CfCTslHrELY7VUYYWw4cH/v8HhuK/v/vv/90PDr/69/fu/P///e53Wnjtx38cwJ4Wtt2qv61qbTz96v/Sq39APovd+v9/6pFZyT20SCMOt/N2v333DovfaOG1jNu52+/e/YtpmTwNLGvAFWu0yWx/t98t+/7/H4Zl9TQptf7/k/4o6Dj9/1NXcBqpFPwPZHbot9Ck+O/KWNThxMNIlFpGVZGgjAVA5VMFuJRFnDQ4DimQmCI32WyUvihMlNoHmiId80DKJ/dzfFI6NU+xxY7EGql+05p/+spsxAW6faTkRpByseDMI1f+/18icYg0yx5AUgQjmamXxNKmQr3kZ3wccaXvh//C8oJg5ReFF6n//8/5k9SUNOWii2CrRJfG4glOwq4iSStaAiQWCjg5CrA5Tgn0WNipxGUY4qTRE8CxUIGjmeIE+aGkMsl8kXr8S6cvTzrvdsyrcZkgHviNR/HLxPUlwDruSJ6Lv53SiW6N6jaBX5RXdv9SIv/Gu735f/JUR+rXesmNM7yUl/37r35U4Nv/lNQjoHm5CJ+lgsH//09O4qC4aGnYdhcU19vv16NHP6jo3AtifKdeGf3B7cWn/Xs6Ps1+0bHg9P9PSh3zBGx//vc/od7y363C4cJTYMHi4t8x789/9SfClLf1AJ5a+H8='
_TARGET_BITS_PAYLOAD = 'eNqtWQ+MFFcZf8sVKFbYRlJrIHgXbEpSDbQESsJ53hJQW6RIUlOilbvDQIH2jtUc7LQs3KzBQrShUYwSTtEDa62hlg3QW2FYHgVTIFBLa83dsew+khr+lNsZKHJj+3jzfO/N/52Z3TvxSyA7M++97//3/d53GzZCQ27OUplSOv+8BiltPkoppvS5AtEphRRR/qWzwP5vnn74tkFpHUj0sifC/unU4Bv5Okb1oE28tZ9dAhsbTveZbzXd+2Fszz/WKgrGGmUSWHvFic1g17r+fxYRf+BfqWF//jHh4pmkec+Kr8kRgwrhqWEuMXnJn20c5L8Q+2oU+CZbvA8x/wnZOiy+CuJbWwtrlbKqklwRQfcgTudThQ5JEicQ3RGXUZ8htCh0UJpUmKxFexvUkX2s7Bf6Fu1FpliU21d2uMTPruxbph0hEwnimgsSh8iPPTy4QD1uwDKtoLqZT4xOdF7GV1yJTKoHgs5Ph66JTf1Bak9s9ZWWr31CqOkAm9U3Zw5cy2E9tX5fvkBbT34dsw8yEwDFN7ynZJ2Tm+/f1rJhx18OQMyVajb5gIucj2ZZzOsGLxmILZHDvOgnHPVhrMUt9o1nVH+wkQA3YTkRSYIjieSlR3GzmCmB+IUhx8j8rVa5QA45NlwSy2HtOeRRJkJo2cdEpyOnOsEsYya7wQVHkWs1WxJI/zeSGasFOnNeRqJZFvL1Fwh2fRQSNmZq1iQj9G2cBeNt7rydYOD2flFH9Apl/GGj0zugGLNiHKPnMcumJISyWbIwDSt7EFUNbn/khhFPtus3aN3jX320C5w6acTH/QrDozK2goAYgSzqijCZgWqrxvy1cP+B9PY1q6QkL4vFoqJIkpbXDSds3DDkpRfJAQXw8JOt7di8sdK3OaOOXLGYV9KSrqp5vSQYiWLqtICQ/uBPNi002Ygn2RI9V1V1zbSBYtPuLUytpZpaKjJmWDAysNdcwTbl6iH7ohCGW3s+mDd6yoWmqwcPKFt3pVL6R+oAM6VeSrtW022RBSPekMN4uFnqmEKurBI82Xo2K9OmrFuvg2MT1JZlTX9Nr9ffT2shVtPshlaVB/TWbFiRbBm74yG2nFTJyzDsMOJkG0LhgQVHUiGGR81AZLVwDA4UYhjSsrqiD6uprQmJ0hxlJLmhiBvPRqBEhSYb8lk5svsI+vm699dIUkisUbdE2SKHJxuulnT+KlvfH8+wvbHrKNQjsv+BV+s76Wzzz8/747Ji02sH9yoCGKqqJTVKUddqhiumMAAMjxZYw31ym2cXDuKBEFw8nJCMgEbxNWbRDUJdp3J4vG+4NZqEGdugYdDIXfDIYPbEBPWLKcYIJ4UKdoWAzK4kR5Grlo54VhcsXeXIMowIDO9zzVumpPopPTEBQ7mfody4alhmY4zYjyGK3eMYmmeOFNXGjRDVKV/ERPe+buO3+snsiS5LPo2dYnj8LYCH4fMotr1ZJaOhEMUIde9/uvoZozjmjKBXILMWIq/lQ2AksQ7XKxIChaKGeiSMTcQVzpfUAnw7Qaq5yIt4ss2nh1EFkpvPzxVEry73KkqumOINu2h2NiQXCCnwiiazDCQEa0SDZcNCDvbZrOsZCHFRDVcLGHUJkDsUh1FvQeUNm4OEUlrDSYUhL6KL5gWdnggjagiqfdGgdF+HyyhVsLCPyphtosSDiS0/9WKs+9wv5JBDKiUJze83yw4jYTXTlGktH3Ll9EAUTwYGC4wnQPxGgL1FhxFvOJppSobsHGCnuzK6vSbAQws3pT8H+npNANWh6xVWc8OGXZuxWaO5XF0sDRwBWIQQyISDno2YRjaI813YjrEKq9mSIV+dtYCdN5kq1NQrPnuc18oCjy3qYB5hwU2p5CztFcowORV7R9iIQLEVYT6wjMbalWWKdKU81mzGtJqhi4pnLh1yUKpt3yS2DOAmmyS5ahHv9cvvPUsOmRncwGFWC5lohCSbUSXZgrBEI05Qo+DSymTzerM2j2Cy5V2NcHApCeaVMXweQaBooCG2o2DwEOBLVVvsDv6Vr5ccsw1Z8yoRNiYPx2uao27RZgID8a9XuKem1XAtPSCNTjYAlpxe+fa3ph86+/zA7L7JM55peffIyy9s+vsNrhot110vVpxaG9BFw6N6ABozPT2xr8yNzcwsmJq4q610bkrsB6Pv+6CcI7S+berkQ/6ShORazEh0A6h7mN3sfzQNgAZ11n3gnV0vr2bPIPtI6YDQo/XfcmXZqzLP0muoJ4MoOsJ38NZgVL08j4jiiQe+AMZc4pfD3yXAvTPfON7y4njQlszqRoHVFDFOYKVM+78wY3e2ByZ9tO3+J57M3xjFNRrMdzce2v3p0Q8L8nuUxBr2+0orx0j6MJCyHDkgWQBAbFSiYVTCnHDdG/sSAHdPvZvvaO4pj+xSVnNAEkHHsCZTuZ54qwYxhsOwiofZuaf+dnb1Q+BnD/FQzOxZCED33JW/7WznjK78AXmOF5OmoQpl9UoeVTxcHxmRAvC1b/89dpud7zqqRV1+qyVbFLOeMgNWuVYG1hl0NBPAuY5GjV5Ck00eTrIdXNZF5e1nfIMe7+wHRo1FQuA4dKeR4ZT5+EzSaOVT+N9QE7hSE8JCi4fu5+EiMm/7lgPTSJ7Vq8Gkw8KmW1TAfkrn0owRpaen+QY90IEIVXl48Ljft80Nv/zOo7M7R11kK4aQ9VFIHWt4eumccod26SkJDWyS9LxUGvzc1W07lqXyN5/Vbl04k+/TmxDyALnatPWuzYtWPLhiyeNPSe6kmPNsfu2VvXtXKWV18LAyR0D0d6d8sEdafmLxv6a3/1AfX5y9vJR+i6kzZwQlLbPoydi5C+PSpEyvzYB5VhOHaJmwrrw1bwzRW33IgES8ZB2uLvPqpcV8+dXXf934ZQCevtxkrud4MEn5Uo7Vyux+nOO3U/4Hn6IAi+yBlpxkWyQwkOZFGQI612oVx6oMesKSrf+nY3p2N9KybsEP28NIDqCXOLhyUX2JLU9PH/x+PwBDY9IjHP0nHvxz+7OXVux4LHlkcP+1XUvT+y63qPmj2ifdC1/JtaTeufX23nxf576bLUjfiKd9eoedbdyYnacWner5fP6eyamp0vLNSvLKG+Nulu5Zu+Sl0ovjG3+hZN8qzlnX95MXtNE61UZmt2Bn2/nqqJ5DE8Gs2VL3ZzKXFq9688J3Y6B/rjYOdHc38r/L/enA99TXAWjfpW+sJyMZ9IeP/odNHTtQJRJFTprjGj1UdLbsxPGJ+RJIjJVaZ4Hxxc7ll4+PAdk5/Y18tjxjUmaLuje7dHkd6J88mN/4sRVCmmf6JUVD5EDS/xcMzKE4'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_beam_after_k40_top80_min25k_batch05_witness_shard_3_etp_refutation507_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
