from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_etp_refutation59","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,1,2],[0,0,2],[1,1,0]],"priority":518,"rule_id":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.batch06.witness_shard_5_etp_refutation59.v1","rule_key":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.batch06.witness_shard_5_etp_refutation59","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWEGOwjAMtC0f0lvaFwTEQ6wVB54VJA4cefI6DqXtUrogdhFIHiHaQtqpJ3HiCYAIzOHAET4LcXjhBAz0zLPS5iTU4owEqz1QgGyERTkuJ+UqhKTfGToIUcnx/N8SiNCO2o4zSP+kJeSsbUKUSvD3oBfe5XA4HA6Ho0do0v1lSmYia55duCVNAX8KdC64HA7H8zhwt0troWbLu7Q/Qotr2nJY8X/4lHwSQAYjajaxTSScA6yK8SupHTXZ7/Ffd/rKzohwE6PNtwzHoKfqw3jeCcmv5ijcZvsiVOedst7GajAtEipMM5ZTSpRmO0uLAD03Vo5Y5RikOL8YX3ym7CrRSUSNa1DjqlIakzVQo1tp6fLSOIlviAMH630zyPPKdq2aQMN12Fiwt1e29K5+M6Wqk0ASDXwUIupAmW5HzGwRiKml12iHVCK1A88O4ro3Y6r1KxsN+x5T1aIQYoRxtw0c0Seu10Ek9YVH3cQZxrGUTx02OB7qPE2AOJpT5HLndeY5PhYnnXSFLWk7gbUI2KQYMCRNdF2DWu1nL1zfLbW1AGkBjok0W7ele3KkFbswjkfAVrTN/LhQZb0FugfaYuPTl8PxBPDKPy3b5Y8J7BskPzWQ'
_TARGET_BITS_PAYLOAD = 'eNrtWU2MFEUU7nUPe9K9mHgie9ObJxIOhIwkJoaDaOLBk6yGCAd+NiayTZwwNZEETl7kwIEg/ly8CCTgjFIOtTdOAtEALk1PzcHIz253mRC6ArVVz6rqn+me7llmgcGIvGzS013V/d776v1vQxKCIKbtHvRp1wPWv6mDYARqrz+Q+mYJtpyHtdHXaL1HqxaOtry9GIvyQq3pz/9xxa945TbApKj6FusLTEGAzO7Q7ZNBqNYk8Ky3tbYYrrDyytUGBBwsZBoSACOK3ca50RBBAJxp5ipZW40OyIiYTeYPAUm/BHBKcqpZyDO+fqoEcL1AzQaEavonnyOagd2bsZhUwdQCRyC5kUtpCeLXtCoX5z3f94y0dneGhGPpMjLsU00tam/BJ0ttuNKQjFCY5VayZCnmF++uvfLFts+Ods4QIYHB06ULLXuyzYkdOxSB5/TfIOQ0A32Z6ikXWtpdqC/F+LhNO/utmb983LkvW33vegao5jhNdRe+W2zMN5zrl9T0iz8K7dhjAvPCaROl694e153DQRj6PsauyzpcjYPb9U8zRnvavt/BdZeHYYd3x8Fsxvnw+5TRN4e0Wu+zsOtrZmOBcnvzo8PrbnSCFsaH/XmX37FQ8m59PM7mOKcP4va6+X3cWXgp3PbBpp/q+/hv9bG4wbTKYeqoMdu/vA9pKruLVE3Bs0M8oiPvpUhIabejR+QWV3LUpNBgDvFnKdlM/j6xH1Bt+SzGU70VJIsFWVJwPaeH0w84PLfUeUq2Qc4ej/TFa2ibfs/XheUdxZ8fwSMQjWI7d58KfLs8m0JlhMVrx3bvCEPlSyxMGh1DbEZ7sEmhllF0jIVUEoFuqq5p/IzKDMFI/ddoxII2bbgQeYzZeCvA5fqnriYrvm+iDCk/Gozxw7l1pNLNmO7+pO25rSaml6tqOU2fB7btjLu9lLeKebAYjj4UiWAiq4RJyze9oXjHDAF+5bpxpR3LM96ge8mYrcyEVgX9+nqofus9VMkks5VRIxAJYUG2yg7PbHQ4pP+ys9EYJ2JSKc+rqLShDIwjyiMCYtHS98peTGcUX0SlEddtu25R46D6JxTPPYqoMSKVYpA/tj4P9j+PkdJ6FjTyiNFxMSOEpoUHMkMc1rdjYv5is1F5MUTRAVguppDsTRi34CNQNzd44mZSlcStqkd2tGWDXPoQ0glXLtxly/YVSBYtYjNeWAi1vADQTO/bYz+jYhR6nKhVT8Q3Yziayceh6lFF2M7rkUzkclDk9TKc0dtEciJuGqddJuCfIGCDIldtqhD6csvFP8FPVembSIUeoh9uhhoIG0AhF7U8q0w+5+qoFaefXNhOGwY+SiSZcA49MJltvYRJM3gEuPGuhShGbeeZPGoVZpPOQHNw5wwoBja9gZqzkKJg+mCnV0ShiBpLzana1WDQ1UrKtlfw0klArn8P5gg+r9+ps3vdJfPB0jy2ymxWd4ScXpazM4xuGUa3rlL2JJ3thd1mErO4F+ONC2+++sZfZjyC66zDbQ4KtLU+QWeLy8hN5UnT+SAqO1t+cJ0cDJXpqT28+ENDgfwlE06uYjZrc7bpYcyaurIEanKQLpjjE847W1bYaWcbKOxWdbYh9Dc8zrhgyDSyZ1148nLJ1tiGSGoXyOxRq+KcJYOPkv0ytU0ChcWcYRpILjjWq/kluFa0tdqyc/BzRfNeOzPf3Lw5OTIK5VNiVVW6LGe2WSQDWDpFpLa5SB8OBjhFVAT3rlGVPPSta3NTj6cmakSP9+sgPgdmK+jUFYAHbWOpJnzq1/SiMdtuVpFV2FocyYpOU1UiVIUrPqTxEPbrNQjYQGAHdReBV7AR3VKJVcxGL4SZC1bvCGzgqyCvnH/ETpyEziwwrbFnS7yXp01SdtImYBhjTXJJAVr6iFFrAqLJnphp6tOn0wvM2vKEs4K0z2MBbKpn/4WmHEcRYCcuD2a2NZaRrePLuvk9shVj0fLC8Cu8cUM8Hzeh88Dix64763fO1V3erbPAdIcHhgSmUaLWlDM69Sr7WncNXcY/KieNMA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_beam_after_k40_top80_min25k_batch06_witness_shard_5_etp_refutation59_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
