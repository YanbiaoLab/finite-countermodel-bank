from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_etp_refutation492","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[3,3,3,3],[2,2,3,3],[3,3,3,3]],"priority":601,"rule_id":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.combined_mutated_structured.batch03.witness_shard_2_etp_refutation492.v1","rule_key":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.combined_mutated_structured.batch03.witness_shard_2_etp_refutation492","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmD9Lw0AYxi9WURCsm4vYyVUnQRCxH6ODLS4uTqVSKy21Ab+Dgp9BW3HTGJtREHUzCDZxc4j0hFIvGHvn5dqqmAZ1OFF8f5CQ5P48vPfe8x4Eoa+QyCn8bhhKHwJ+gKXzZTOJj4MNKhMM9kjR2nnWXJ0ONty2hyjBlhhC1J+pP5ju9hhW0T3GYrPjasTYjKTRehqNoOgEMiJoHSE3boyqShyyBQAAAAAAAAAAAAAA8A+4WszUmhfO1KGVv86ac5XH1OWxVSjajQEJYp0/Wj2QEVoi4/9Yq2j3K3jSTPKw8nojj5tFa0yCmBoaWkTGQtaYzafG/LJbpEqEUItfJRkLuavVDxzdXMzp5MgpkxTWrcI8eTrBwxLEjNCFVCSo7ddFRLla03LKmlXQCd8hluOdTEsxW3LVF5riQrWsWajwpRRmI3/fbM9hYrE/b7aHMDEpZnv2Xh9dRtmG1Oqvzmwnc3qDBmPDwU/1HWdPdF/BzRteD8i8zX4xW77Zbjz/0fusr3ZWfkz53Z09fgaSlH1X/M2h8Y3nxnilFDYvdQ042H15WGh/or4d2i9ux4aiiros+roD6Jtl1A+VoWOnHz7Z3jZelZF3mZNiNhoWWlSG2ao29ViL2LTEqM0wd4/GSjwyKSebK1KvirkN1i0oIq4ex/ZQjxlOv6H2AvVBgVQ='
_TARGET_BITS_PAYLOAD = 'eNrtWT9v00AUv6pDJuSRieYbwNgFySwVn4IKxAp0gbgi0PPUbHTsSNUvAAsNwooc0aETEpUqtcJynKoDHcCXSrQ2Pfse5wtunD9X4tQubZSfosTO+e7lvXu/9969LFEADG0crEMH/HtTvKLRacT4u3r7NOQfFoDmQSqsAZ3ywwEDqxtVuzRoNbUOi2iGpRFCiBlfOvznd8Rhros7cCmaUg8Ovk6YbsZfG1IS3YRn30H3Qjg5RUECoUF71sLtAb9fyrQYqPcrWmxPOcVg9owgOJha9MVWd6OAkmhuHeBAfRWsQGUFjqC1D2oAFf6UevPL/MvVWtWkcOnYmusYq7xtvIcJrgEw0g3BT5t7X+RaYHqN3KQpHZ4IEgTjY0gVIZ1RcJQ6FSGhRYuoTvoYnhXZlq1nhkE3LNd9U9q2vxqGphG3USZhHtK+laynmuaULNuOxJY1z3Vtu0xqeQgrooc8MTF6n5pqZMhDcG6EJuRkycd7R5VbDG9vqcGdT4fLrgJFNvscmjmRDaHj7/CuqO+2yfZBRbrDMBsD/w9TeJ4HDF8j1TzPilL1UDlV1DnR4xgDEfVECBOclbMkvqzUDh/sdVuN9tdDnPfOP8zNZ+KeWi0u3xhcXn4h47tr5otdW6joAtbs4wZPcuX81E3U/8ScUGZ08HBVHfbZhcQRiNs9fT7C7XPYiBt9xTObsKWDkzSfBPURwIBZk6iaQRnZJpsXpUZGk82KQR0NDzrcdOKGSVzMmAk6kr7U+n/JRrvItiBqKa/T84kjiNVlgC53C8/KCNpnwHEHksHP5cwmgxg9WdceZShtWiasmUNewVLVfnXRJBufUmTCdE/I+J30/wtjSiatlUMoVqWGFJ3sH3Pkc4bn4IJM2L1zjhJDhacrTrasISXb2k+ee0znxBOR1jCySBhysuVxkpOTTeaIQx1IqJRsO2/BXELzwqaiBbREOaOdAfHDHKbGdEYh2wRXGDoPXE2+eYLmekxAP75R6rErBfFNoRlHIBYFvVbC3YIEq3qjVXAu2T4KF7bbDpjR/wHKOTr3F7jkgmlcmtl4/KdACk0vohjjVsugxyAn25Oqbb8WvXO7FrXNGxk0Tgp+UalvYtSqAL6LFIB92OQbr/oqam2COqNXAFqwz92mGAyuhmZTSPsDb2UZVA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_beam_after_k40_top80_min25k_combined_mutated_structured_batch03_witness_shard_2_etp_refutation492_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
