from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_etp_refutation392","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[2,0,0,1],[2,2,1,3],[2,2,2,2],[3,2,3,2]],"priority":602,"rule_id":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.combined_mutated_structured.batch03.witness_shard_3_etp_refutation392.v1","rule_key":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.combined_mutated_structured.batch03.witness_shard_3_etp_refutation392","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmb9v1DAUx7++s0jaoY1Boh2qXmIFtRLSsXYouuhkpCsLrB0qGBnb7TrFrSKRgwlmBOK/QF3wyMifkPIXREwdKkzck26g5aSK5MS177PYzg+/+Ks8W+89zTFhbQ/TERcPx0Du41q8AP/lta648WpnIEdXzWZ6eG1PGepAV58t6plqxih+7Vf+tlCukfxxqcAatPcPuvoyyvz+IOGzV2brZNIts656BmIO0DZVrg0lYCs6SPyoMWulnfzchbPWvjlCGmtTxhGWPa7d0pZ5YXvBJQ+vy9kO43dK8Z1YiINRVz5SKs8DEWVBqwlrD0bx+zwPR7GUzmyW+0JImQX9JowV9lN1MDH+hSfGCbmC8GerkrEZJT9sLA1/MN3dMu3vT1YORYmCfXuLTkPOZu3iKp4X6ebY2Z4am4ZMM9qHiFvA6u6ku9+/LzdIkXkgebMpXRsI6FwuRtUhlwUkC0EQBEEQUyO6hb38I8lATMHcOwkeUxw8T2HBXcaRhAs+wNBSCiFpMh378CWSI/t5PHIpoCOOO6QL8Z8xLnLJcS65yXrA7Cm/giM46/gun8ysZUmT1o4HUh5f5M5l36XNozoSJ14BbANLQ+g2SmDdjWA8Y/k2zGk6BJaxfm69oobyym/6w4DQ'
_TARGET_BITS_PAYLOAD = 'eNrtWT9v00AUv6pDJuSRieYbwNgFySwVn4IKxAp0gbgi0PPUbHTsSNUvAAsNwooc0aETEpUqtcJynKoDHcCXSrQ2Pfse5wtunD9X4tQubZSfosTO+e7lvXu/9969LFEADG0crEMH/HtTvKLRacT4u3r7NOQfFoDmQSqsAZ3ywwEDqxtVuzRoNbUOi2iGpRFCiBlfOvznd8Rhros7cCmaUg8Ovk6YbsZfG1IS3YRn30H3Qjg5RUECoUF71sLtAb9fyrQYqPcrWmxPOcVg9owgOJha9MVWd6OAkmhuHeBAfRWsQGUFjqC1D2oAFf6UevPL/MvVWtWkcOnYmusYq7xtvIcJrgEw0g3BT5t7X+RaYHqN3KQpHZ4IEgTjY0gVIZ1RcJQ6FSGhRYuoTvoYnhXZlq1nhkE3LNd9U9q2vxqGphG3USZhHtK+laynmuaULNuOxJY1z3Vtu0xqeQgrooc8MTF6n5pqZMhDcG6EJuRkycd7R5VbDG9vqcGdT4fLrgJFNvscmjmRDaHj7/CuqO+2yfZBRbrDMBsD/w9TeJ4HDF8j1TzPilL1UDlV1DnR4xgDEfVECBOclbMkvqzUDh/sdVuN9tdDnPfOP8zNZ+KeWi0u3xhcXn4h47tr5otdW6joAtbs4wZPcuX81E3U/8ScUGZ08HBVHfbZhcQRiNs9fT7C7XPYiBt9xTObsKWDkzSfBPURwIBZk6iaQRnZJpsXpUZGk82KQR0NDzrcdOKGSVzMmAk6kr7U+n/JRrvItiBqKa/T84kjiNVlgC53C8/KCNpnwHEHksHP5cwmgxg9WdceZShtWiasmUNewVLVfnXRJBufUmTCdE/I+J30/wtjSiatlUMoVqWGFJ3sH3Pkc4bn4IJM2L1zjhJDhacrTrasISXb2k+ee0znxBOR1jCySBhysuVxkpOTTeaIQx1IqJRsO2/BXELzwqaiBbREOaOdAfHDHKbGdEYh2wRXGDoPXE2+eYLmekxAP75R6rErBfFNoRlHIBYFvVbC3YIEq3qjVXAu2T4KF7bbDpjR/wHKOTr3F7jkgmlcmtl4/KdACk0vohjjVsugxyAn25Oqbb8WvXO7FrXNGxk0Tgp+UalvYtSqAL6LFIB92OQbr/oqam2COqNXAFqwz92mGAyuhmZTSPsDb2UZVA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_beam_after_k40_top80_min25k_combined_mutated_structured_batch03_witness_shard_3_etp_refutation392_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
