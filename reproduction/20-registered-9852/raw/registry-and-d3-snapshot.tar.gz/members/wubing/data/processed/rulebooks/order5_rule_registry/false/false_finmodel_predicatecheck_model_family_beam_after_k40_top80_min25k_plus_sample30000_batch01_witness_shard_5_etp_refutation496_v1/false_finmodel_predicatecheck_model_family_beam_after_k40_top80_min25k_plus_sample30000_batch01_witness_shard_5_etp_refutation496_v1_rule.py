from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_etp_refutation496","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,1,1],[3,0,3,2],[2,2,2,2],[2,0,0,1]],"priority":534,"rule_id":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.plus_sample30000.batch01.witness_shard_5_etp_refutation496.v1","rule_key":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.plus_sample30000.batch01.witness_shard_5_etp_refutation496","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2L0JgDAQgNHzp0ip4gBi6xIK1lYimcMNxNLOCRzREQRtDSLIofK9IilCuHCXFBeRr2mcK7ngRHh7R7SPhtQBAC6tgZSJWjSbSqYWrDTZKP4/y1YMU29ipWDLMc28FgAAAACAKDb27o5fPP6/X6tyVa2zdat2Cq4H8KwNnCIIdw=='
_TARGET_BITS_PAYLOAD = 'eNrtWc1rG0cUf1vFFUWxBKXQkrTZa0mLKSXgQmi3t14D6bH5ED42QSpxbKhdzUJwTENT/wMttQMtlB7snmwikpUjiCAQSCBQQyKtjA92iKKVcd1dsh+vM7ORNvpyvfGuGox+l92dGe3b9+b93m9mlDERCbrYWsNWKG7vyRH2IEmOTS8PEcd19IVZNAXD7tCxqC+qDunQIRlIwOn0rj+7GdHuKvVbFU30zBHqY9XBYEDfY/v7xfMYmhp7sBttOyEBHHbWbOkgJ45VoHKrgzOR0asDuaTW7qj4zowEWDNJm9EyomCwL2t91xcj39z99sI24vwNOtnrhTViSRYbNYObWPPm6M3HxPll/uOfLzwtathbrBcat80f1ccrDAK5xj1L8HKo1hJgNEjArFn7J5CSGzqVx5Qi3Pxfv80vOi0BM5lNNWSyPcuY56lrY7T0mCmTFa2qUyyGZEyENE+LAospBc2YRHiubaHJ6tamziTBYDJAULLCI5tN5UZR7AbZCM+YcMhmofK0Z/n/6+Pde6JjxxWGDwHX1Um/ov/y0PWHTKrN3Yzl6xw2nBDU+OLC72c+yIxe1as9cu2MeznfG2tba41FSQENYjRHrcN6yFb+I6lUtlYi3oK5j+ChXGzsLch4cbtk9kPSR6uyufuwfQmb78dUXmI0r62PPv5XsulMGh3Ta+t4omHr6HFTrR+Y1BczygtrMq1NWl8lsmmeM3V/3IfmALzwKsdjqdIewP0O6AYjlD1bN/BeXMPVAK1Fuhkre1kR4J6tG8LYJSbg/UPy5Srk4tUjzEblVmlqEM6mFvSmZA9Ia4VurnU4T9jzcSLdzMvXTibz8c+PnuNG7hyB3FDl+AdLvNcqYD7AQEZh9g049iUcvAgxbm3saOUAzC6//iQcsn10f6r09Ydz8QkWUzl/euqn+MSnK7rdc7IFjQj8EM2tSrCRpzFlNmrKagQM0XLPFtR/3GHZbFBkKyj5gihnDO7RTQlkuk8crylc8YIm24Yo08l75J1G2onQTkAF4Bx2HLeAyUzOiCe0zZqk7GaNqe5Iti6o7kYqZJ9kO5CP54bOwRVarI5DdmG5ODwahbQ2sPj7b9k/WrJXvjae5MPT+mBRgEcTy7Y/RYZTI0J6JQbX7018P5BLzg9/lVoCmIzq2+1lMSIP/X2aDX8y+NfhIQB1+Tt/1VN8l/9XI3ziiJ85YOWnEWsi5FC0cKs9e3/EaT58ldazKK2iUdbsQycu0ViW6eS5gaoTkCk2edaWvfzgPlquz6HzMmTrobJdufyefGoF3roROzwGY8lL2dRGHMqlWLU90dnR2d64Lly//Vp54W0YndMPxWg5Ti2V0gIY8aoZwtatTrYTljRpCcZ0AnGO1i2UjK4CuxeyPf+Zwy3X22o7cb5F2od9WPsXlXnS9w=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_beam_after_k40_top80_min25k_plus_sample30000_batch01_witness_shard_5_etp_refutation496_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
