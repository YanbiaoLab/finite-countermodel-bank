from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_etp_refutation506","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,0,3,3],[3,3,0,3],[3,1,3,3],[3,0,3,3]],"priority":548,"rule_id":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.plus_sample30000.batch02.witness_shard_3_etp_refutation506.v1","rule_key":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.plus_sample30000.batch02.witness_shard_3_etp_refutation506","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjYGBgaGAgBDacZBgFdAQHls3222RcjEXm/f//3///Z8eUWNBp0KXRI0AV6xeAU4RSAEugEws+dQpQPApGwSgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCoY7yNn1csvu3eZzy8q/b5n95sydu3uNi9OfzSs+x0wDyw78/v//7/////eD0D8gBw5o4bUf//8CLYJYeB9IvIdZJk8L296DfbQfbMF9qEXfQQQtAvLB3+/362EWgcOxHmJjPS28diPltm+ZG8/ql686XFUjJTfu8Ep/dqpD9bgAGw0sa/j+/x/IU+/3w6MMGpyMNLDNQdhRJJBDsUOJS7El0CWxxYGjVYBLUYTFUYAWAamhBLKIJdBFsUWhS6NFgGOhgJNiS5MCB9NoQTQKBgJwcRk1uDlwYkooMGmxCaUw9jYwKYc56LAEGLIEROqGh+fuPHHuzNVQa+NwtzWWxyyAGYgEyy4s2xxbVl6GJc+/XbZ7dfrs3Hdvdu02L3//7l71+b9/v++HlJ9wwE+a1zKUepS4lLFMg3RkLBJyEnQUcdNYEtABzIGOBiysIoGcC0HKRYI0jgRwLFSQaBpNG6OA2pUNAyOLAhODQmMDA6cCg6CCAoMLaAq3hYG4ykaBJMsUPBQaWVxYPFQEBRk7VZSUHFw6OgQEFVsEaFLXAAB9pPlQ'
_TARGET_BITS_PAYLOAD = 'eNrdWWtsVUUenz6AVjFCkUTWD3QLu2T5oNiIGsluCzZofZTqugnJKtYPirFBiLjcDd12roixJCTi7n7wVUWy4fGFbXi069Z6ip98oO5GAuLl3vEDQRLSezSsPVlnZ/47Z+bMOXPumXMf4icnpOXeefxfv//8f//p9gHHw44DQwDQ/z04IP4RoAADwDwCjkcwMLi3nbhixhPTAB9Td+NlAMYBPODY/4rJCSK2MQB1CKcQjWOYnmBMLnU98SOcOzN2dPo9HHxm6ju5zBkbGcrlgw+uOc3kb19HRlxDBrhKC07dUIKnDux3oMhBmCNmc+AScIItVGouP3lE2MMh2EqoK0xQLvBN8YQOalsBUyY+RbPY3yZ08ri/x5gFtU37UM4C0yf5hk3CjFDWmA22wU3dS1++/+RudpQS6WffECJNQXL8EZir/RGM32/7ZOWZrS49zwODtJNJ7jOHckY3+18He9SCglSH6LU4POuutge6n2r/3f6thycpgxe7dtzzt1/e17vr1M7u5a+/tipc1tGy654H/3KofWTrtIhUACI/JljY6AVBCkLuiC+oDKVUgRPxv6FAchhFTiAIt1KQAIWUceZYCI117WeHzxlTnh9MbHwhHRyZx5KnebFfycF9i8CCXwUdap6qXOkGZjmlR5mKMauwAHtuTCUWfdDCuTwtAbcah8rz4GyuvB6zJEpAG+prG3iLc8iXtfgkBvSFPDZwEElqbsJGf2UV6Sm9E+Pa4d/oC2Fxdl/mMR824UE2DMRhY8a5isFkoqpswuBEJ2FHCywHG6cUjFE+WFDUMb04/70HuZeKLn72kkgm2hGskoJ8VXD8wKFKMohlMrylc09PTAyMnb1QfHoVK3Ifa18rSV5COW6inFgwABWS7cttuU2ZzGe35s7l8xtz1MEY+Lm8uPAcSDnNLc0mbIuPVdijwrLpYvHDbcRxpscmJkQKBfUhmWxlD4qvcewr+nObxvP5X7P/HIXxkaEMFOEsHBWVw5ZsYS2NhwsSnqUpquFNE75FB8g2D8ZyxWKBORMDHhTsXnMiOeVk4DQbXdch9pz3i4HMAVklQeMzzh1qHJNKuWTeyysqUo3rn4oVJK/8akbAiCyXhoqQF5xGUpKt5LAKQ/EICAuOsdMnIiRkCV4VyabNxGnSFAewTCtBNCQrPC3ZaLmkK6lsROKAOQlVJR+oBBtH/uaQct0nkk3RWSa8Nj7JB0v4AKkEm4jymWFLCx/GuhRhdbFH/sGJTdIBjMfvDiJdSePVJ6Wep1NdP5qQhI32GQuAEoa0mjtyUrBmn6b66ilUcu01xqVAo7AEJFu5DmuAuCFAJH0XpwVpz0qR6xwneX+TWwScYaYHlKAZoBHN8S3z9WLUALpWTsjQVtEQQCVGex6NcM2AG+WYm5wI7KXdTXrOMQBkp5GuvvVKlvqVmIR+stBIU4bJWElJ8SHBT8mWmJe4orim1lTbEDog4pkxrsCN25SW3DTUoJGWK8rS3diapzDZoo0hSGnYEvDAL24kaCZ2RUUtWNhkWXo4qww1rbbohkv5hSmLcrpVi5Ymez2WdIBVhnaFaZcLUU84VJXXkne0VUboCtMuWbuM1tTiNRb3Gk06wCZDuwJKgqc7ZIvXhM0wXhE2NhkRgOLBK9Ooj1u8luzNrTIiAMWDp3u26STWZmg1sCmfCPHgRck2U0Wybf4xk62y16482aLwVPbalScb/+kmWy4t2aq6o2tLtj93tXR3dd3dtmu4qXvpggVL2tbct3t40WO7b/6TQfiwbhk1RyIGafQiLsvijWliLEZpw9/51vkjt/03qoPCtdaTWBXER46GNGF7428mVBP/gBXw9KcGgDQOi1NNexe4J40JAqIlxp/0ahvXpgnLSkGchlCnBvdn8MPGL15demTXO58/1LLwD699tP9Cz13HX1m0MvPl7e7Z5Ftu+ABkZb+hCiS16+hIdaToeGgHHHNpdX0Zqca08fP/vHTY25DJf1foP/zOm9snve3ud4VL9D2XRk08NUIf9MplXn/MR60S3U4/kvlEnH54ojCQX3lm4O/eBneysH2QeINRE6/d4oTPu0YLU/Y5oYS3pr+EM/MEEpJBUvHppQyA+mF6PM86cv+7DJm3NrmCkDO6NeM5QRsnbmrgQpkJsFDwtN43PdlUZbPwAQvwLMnGakKMppGJix2id8Pkq1b598F0kal/WrA897vxx6ZaHpwqJVtVIyskUwyxDg2nB3aO2tVb19jY3Ppy07y61W2dp3b+aglaUpW0byo/95sj27ui7qudV2Xf/rTv343ZG5af73lhBKFnC32zsr2Pj/bVTzUv7D2wpgehO9aN1ncebF8vlx9a8PNlCI0sW4+rw31Y2eauQE176tD1826ZQks7ZzeOoEVoajc6idDcq37Wh1pan9/Rk52L+nrQEwjNnnXNCtS8Z/XqZZ2z0Ypl6HJtF3JDLTG6cfRfW55bebruxlsenvOPwpbBOV/VVgd0Zdt78ZEv9jaMXn3DG4N3ZhDyNmypTo0aK1td4567G4f31jc1tXS2zW+t39GVPdj827VorQU2B1H9Drk82zq/9an3/zo/+21theC5t5+sn7pmIVozcmJfM7rtoQ9GmlbVoYvvnrDBZqp346hc/syB933YbB7lVVYZnWzX96F5rQ3ojtvpvronL7559cCCW1F2cnVBwOY6BZtZEjZvSNg0Sdg0KNisRRfMv35WHnOuLLW/obbynTr+DyVthqI='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_beam_after_k40_top80_min25k_plus_sample30000_batch02_witness_shard_3_etp_refutation506_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
