from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_etp_refutation492","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[3,3,3,3],[2,2,3,3],[3,3,3,3]],"priority":562,"rule_id":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.plus_sample30000.batch03.witness_shard_1_etp_refutation492.v1","rule_key":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.plus_sample30000.batch03.witness_shard_1_etp_refutation492","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmT8KwjAUxl+MUEGwHkDMNdzqUTxCx24NeLGMHqNH6JihGNOUQG0axCFV8fsNhfDSfLy/GcKISNIrOsPsVym2IrAArXGEBjkYsrkU9RShoRl+YaFFEN37k9ZTgzZjxOkgubrykqqSdpQfSXGq7K5zs5fsgmwBAAAAAAAAAAAA/AEmRpZArImqpXCti4mJBGIy6hpPoNbGxOoUgbzH1PIEYioaSJZATcfECjQbmu0zzfYU06mGXKjZwBdji0ILmzzX5rUvlswv2sKXEvcLLfwEYv3Qy0flxkddNZ1WHDfbz95sLvVyeP81/rZzfm3D3ZuZE25vqD0AocTBLw=='
_TARGET_BITS_PAYLOAD = 'eNrtWUtvXDUUvlEW2TE/AKEs+wMQzQKJ2SF+Bit2VReRSEQgngVqdnTBDiRaiT+AVKkppMERrwqJR1lVZZI4TSWKRDKeqDAe4bEPflxf+17bd27SLhDiaDSje/0453zn4XM872xghjCGTQBYPQYM6kOAA2yAYAQwIwgELBaHFKC/8qVQ04acrjEAIQEYSKTegMD6m6hleoLZRHLwdBPxhakwU6laCtXYg8mtH2+j8lnYd2Za/7MbV4o73D7QcFiYXy2jIDTgAdRKITmtODC74QaGkbQPkgAl1RJuJMd2qtJHQrmUcKpUsBBoVZiSgZiJh4gL9eRHkV6mZGJSrwlGwS5zGJpREG4nrdguTJSwwWi5DHqFIbHDicFZy26kRnZgHQR1eJS0aAb2+IksFXIgL9slfyP9ulxjJ+xtThbGI2Nt7nA3tFSEdPTdp2i28u7sOmxdhzMYP4L+DLbULPwiRfKGs03pRNomSOnISiOVJsfqBTemFM4MZrp+WVlRWstQJyABDhl68k3lGr3+2RfjYEhx04h7MgB79US8G6v9xCS1RpDwX+s6PNzVQklLtXBzq1AwkWRW+h6tiST8g2MuzW6Ru52TbJyXe0uLek0TH4Aprz8foWLP6EH2ERjX8krHkodu414lWTIrd0S94o5LCCYIZh5OmvSButuEdu5AwgSqAY+rWPM7IewYtrkNbjqjj4eEF/WLgd5tePV3mxKOOGJ2lmGkRUH1DTfn8SCJwZLuXRvq9HT74W+jDy7/sn9f+RpjkpZzG8LJ0MtJwgdgTrD9+ja/sgY/Xx7uHzx86+OdHYRA7h+ohIchsxttRhNK2SfJbLl4864S+fvXP9x5VQM5prRHOE4GW+tG9Tk4PWN1enqPQP/sZHVy6ZP19+UP8Dl/efZEpIKtOkvr5oIIWZ4RTTnGbMrh0kdv/DTSqg2e9r9C1+BuGjXs+bTxQDkdKcUkHfP6MDAxYE5JcP5Zrx3OSbtWuDjuTYryokn3bauCOOV3obIiSiQNayFW7kYywdbYbA7ZOgKqAydYqQsRUlUJrEOwOTVRjtuhOUESw5YRr4oVmQs23hZ0jZONGD8QOBLV1APz3AabXwmZdB8F23FViW7h6XvTej1A5rmNL/lCs+XMh5A7ipBN7B4fFC0yAAhZzx0EXCEWIJs5z/OlrrYmxG7jMBOlo1Qm7ZIjhTkkEnWiOY5FfLDY6W5qw0GE9SGR4YhfeWAW0RGgtYO/Dv+Igo3Xs6HpBBJOmOARG48x7v1a6RlMlWFNBOmjncbI4cCB0mUkdVmvMTVGrVFGhjzCipU0Dh9SflvzsChFOdTK6jwEwNeZNZPKIJvyRqbhQRmZSFGJ7ibVPFXB5hdWTsqrlkCWuFDPaFJLUb4Fq5qsRA+X5GGH7RLXcFlchNVo6Fo1PzXu9UQMQJKHgyLUi4LvCTc7oRbn6CSPCopQLxNOQWuaQE3UUeMxACkeDgpoGM91yAnUlM6wPddtUjy8A9WN19KobydQi3vzJA/vQHXjuZ7tNPa1Ce/iNu2BUDeeD7ZJh2C7+jyDbT5qzx5s3jzzUXv2YJP/3WAb5oKtU44+X7AVOVoPCj4EtF4jkeC8Zr6WFfXGNNGz5UivXJ4d9x/5c1BBm9xJdCh8gou1BN2s35lwV/iXVYHMXzUA5GpYlFVNdanMKFMaxHGsX+mdj3o5ZgPDSPLK1cOLWAEXo4Uct/vxXW51AZSsfisRSLbr6GeBVB0P78tv6dfd+jLSRbWlHLM97stjHpi+7JVbbn/CS62GbO3BZndwsFhGvN7CtF4nNOrW9mCrdiBVMUjmXr1cKNhOQZ/cE8VQcdzZSZTgud73AsH2Zzw5EWziXB6TDzZ/bxjfarXfD+ZZLhTjxyqHrz/etZhSeAFeklxWXQw0uhjRnQfvHmz/07+ZQCztKeNRBGh5YE/8xWIqYHmgTdzbs86xoC/OzQNfOrJuUxRSJ71x4G6zIKqa2WrWGmyzRAjFfyI9r5ONp6+Qkf5HrfVikFzgZBvjzOGFG5016a5aPtjkdpSUVE0nVAlYlW4sTCVdcF2a3OoN1lBxwhh5rSDiKYORNvwhiDhJakZY1yllFWsq0pUYgSz9AykVjiw='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_beam_after_k40_top80_min25k_plus_sample30000_batch03_witness_shard_1_etp_refutation492_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
