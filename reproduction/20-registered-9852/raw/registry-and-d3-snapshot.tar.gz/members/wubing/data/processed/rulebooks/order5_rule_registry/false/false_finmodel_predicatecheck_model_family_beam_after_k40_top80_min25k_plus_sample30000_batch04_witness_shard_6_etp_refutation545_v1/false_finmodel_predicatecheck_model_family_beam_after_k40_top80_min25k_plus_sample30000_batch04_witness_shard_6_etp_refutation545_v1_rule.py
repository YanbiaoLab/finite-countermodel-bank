from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_etp_refutation545","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,0,3,3],[3,3,3,3],[2,2,3,3],[3,3,3,3]],"priority":583,"rule_id":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.plus_sample30000.batch04.witness_shard_6_etp_refutation545.v1","rule_key":"false.finmodel.predicatecheck.model_family.beam_after_k40.top80_min25k.plus_sample30000.batch04.witness_shard_6_etp_refutation545","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmU9IVEEcx3/zdlbfqtU810Ii8u1LWBPpD4QaWb21l0gUFhhoh9yDWEGheKnM2HHb4iESSxAZhP8ugadqL0bhPqHIm3QJO1QkBR2Wyj24bptOs8+OGyjbRsh8DsP8mGGG32++v5nH+wGsBuIDwX+BjqtgOphppBwjXccZBkpBAivjYrIPCEGZjrs8RHyVrQP2mBpUPbIS3tHu6QmGVEPPuBQSRyMQCAQCgUAgEAgEAoFAIBD8b6hb4ZYM1sZdUtqaDrbc3AD6RRWvB9+oVqxaElTItlUgAa2S9yKSm81GXIAxFG3+/SPUqIhhUClIufKNmqoMkrbS5x5KGib16+HUivItHkK/w2FbFgyO8t62nG3XUKtTJ1xZUcV2rvurZM6h5mYvqwxMGUp3q7YqZLNrcRPo4MlVspE+BW0B46htnFIA2n3mztC/Pc2vCcaiLMFSjLFvbIm3LPtFDUviqQz9sxQK4I5KH5B9CPRp5wu20Ht9/lUgVdPWFvvwk52LBfKoVq3a01UvPsFj0o3WWqlwrRRJioliF1gUonF5yCg0wcaHj0WShzvHY61vI4y97G1AFBs4Pd2HQzJPynrw2Eus/hYo7SuEuAq1cw6pEhpvQE/9dy4PTxlJRObnP95LfW6rOzgaiC8Ph5kLbi9Smp5Oh0hdOgD5a1WStxnpZzA09RonnXBBMZrMIf4kfHLPBbRD2pfu6HN5zGs0LTN33IUsd5nShfSz+LV7zMsDkPxrSppIi4O9s8XBoon3vM2+mmTyrG4lUPIY8Rxo98F+z3n+AIQLzdRS8kd8hi10Tk7ORpNsZpYVZe9CcRBUntXlqiZL/DrW7CoZkWQEpw/c7XD43zTfjzzpAOh/OpD9i7AHnDCCwE8dUAI0Dx6BPx2vajj+cGrK57p0pKalBZ75L9fANUf2rjXaHkGYmpB+cExKeAbpMv9E0HWDYECKoZuUywaTP7k2uOrNfgGBc9Nf'
_TARGET_BITS_PAYLOAD = 'eNrdWV1sXEcVPutN1jj4R9RCJKlThyhypD5Qq02TggHbSkSFaKogtRUgkq4FKlEFBMlRtnSF71LTRFUlFIkHIlWAm4cSUanalzZtFnM34SF5gHTzUNXtxnsjgUKqbPaCCHsR45nDzNw793fu7rrhiVGyf3dmzjnf+c6Zc8bPF03HMKdxARG/cwZN5P8sJIhFpI6FpmMZSHHfDstGnJ44T/m0OrELDiJliA4yg/+C1BSvFl8mJshNGMFgLBkk828qp9p8KfrPLr31iwO7C477nbq/yWnT1fHnYIy5X+zwYyrfhY7UskMy0Ha1YMT2JTjuhkUTWwy5OfxpHW0LTW8JkZrLb47F7WHoLbWIzU1wIRCmOFwHd1nDIJR/C54aYhnXyWFiTegpussUhvIpUrWTMGwZ21zZ0FNvGY6AHLRCLImzMMSSpsBkFXbOLCC1FR7eyB58aUPps7dIk3kGKZDHYXg3DNaIgaYUj6gmwPEzmfzNhphIFO5yPLrj61999sEnX5t/Y5lQvLR/8fCdie+vvNx4cah4tVL2p02P/vnw879cPmcSoaRpShIJnxjcRsdzkudyk/9ApCul2szinxY8LX0vMgs9d7sKWkgwZVza71NjZOrq+XLokSOcaYR+kAAH5tHkbk7kLTmYsAg1/HWpQ8K7ulDanllmfKuwYlQrzOOeHVGJBl+UcCZ3S9BtncONc29v5qIesSQIQB3r1zcMKFVkrF0zUBD8Og+Ohmt0UvMwbdRPWpGOq3dijMDbKiGMC2lrAZy2lgNR2oT93MO4IAPVEvtURqo81hSQhqkEdqKNGSdjEA8aFk1zc/5DMAtVYkggyThUfyvmSUFCFSO64UI3GZbmoQq2E/UfVirFtz640fr5nqvXau9U5gt/a10p2hSdhHIszHJLwwHsEmwfHq//oFB4d0/92uoHz7xSmSoUWq1rqz+2l01M2c2OR5Ohmakn6zjk36aMffRo3Zx2Gfnu0CpPZaYm2DpuFJ1j6mdk//6Pk9vY9NXq1Fr/fXBybRi3sIeOOdd1weafpVF3YQJZkqKaIMadv2A/wFeYPE7K3MIr7MtMi5oZyOkkw0iz0bZNSx/z4jCQMSBPSVT8jNYO6xzLrnLJuJcpKlCNqVe3Kkim/F6GVxFpkobrIcfbzUoJtthmXYbD6kdN91Q0YitFIWL5VYLTQ7ApM400aY0FvO3oHruCiF+ssLRgI52CLnayWZIH1EyoKuuBbrQx5TvDlHQfH6qc5aidXL55aCVaD1jdaBOUfGG3pbnPMNRRZKATOTZE4RWnjQCAsmjusFAVYiFkU87z9FJXVXgx2ijMqEcU36W95EgqDwkrWSfK45gmDxZ3upoaIwh1OURTJJoPv78qFtktNAqr/2rcQqvoUU6eNW0kQZkjLLMMXn6SENGZUs7yZZDAeVGjHYcEvOZ2ho5jFq6J/PByy2hMlBGxc5xpMwwL6kK/7wimJlGLlZFhGeGK1YodPpb3aptUoebEpwrUvOo8DEBQZ0ZcykLZlMQyDQmVkZoUpeludM2TH2zBQp+kxG8JmIeLHQhqR1JU0IL5TZamh9PKcB+7S1TD5eJCXYvqqlULpiZ7PZoEQCtDQRG2y8agJ1zoCbVkjtbK8KEI2yXjNtSaalCjUdRIEgCdDAUFxpynOmQNatxmPNeVNjoZAYGizuvQqJ/ToJbszbUyAgJFnad6tttJrrVJL7TpHAhR5wXB1u4h2I7+L4OtO2p3H2yBe7qjdvfBxv5/g62eFmw95ej1BRukjSNCmTUTf6OOs3CNZIWKCSeoZWm0MdX0bGlDrBw/dubhueAc5NBqd6I9FD5uz5YmbCl6Z0JU4e9VBSz9qgExrYY1Uk37PTJHGuM5RElUqn+cLsq9ZrzB/1fHxKedMzn+uj176p9SECM+1Umo9qf48UYmzbSauIdd3ZVoIOyUHi24BbJSuw7RzJdmZ7OD0PddKYRbONP31033n60bSKab+29dZD31ZVYvpvULCZMHAfKwSUp7sE/Kz31EgvKYhFzv9codbn/Cl1ox3fjWMxuf+tpOGPymxHTfUwCD3/j85Td/EjTxChZXEIm2MB2vE2J1a+dgQ9pWrZ2y0ep69dIt2Kpf4i/HJKaDNWHhdbjzh9tMlAhtDguPgEqFi9FkrbQWPz3YSouL/Vshd9ON6CngH8eO1eSNKNYjbZydCDaqv0awOgTbjxxuXm2bpIu0sLTYIMxvLpK3Wp3vB9NFctiqw61fH4HN5yWmJ1rAP87XiqqLwVgXQ3uXQXTBdhej5GkU7tCM9KvsfsgOzoiozm0cmoSBU7Ozu3jemtwFDwEsvpDbDBsuLy2Nbs/C6dHSFihlZuX0g7WBUxn400B1DbGwjisgeGJHJn95E5ytPiv+wPL6xGMHTnN25uY3whP5N/f3VU89+anXJh4D+MLiO31wf/lbYvrvBkZHJwB+deHb4Xvy7onT+1tNBsY2f7EGu2dO/mwZ7oXqFWgCDA/fdwS2Lv3x4uHSEOSPwnGA/v6R3TBUm5t7oJqD8l4QjlnrPSFnV17KlV6dgqVs5YGtpROtV8p757KwsqW5DVYurH5maGafc2jl9XIGmkPtYWheb72cW3q1+LnmoRWAdq643qv/dYxG8o9I6z3ZcptLGy7zBPKJrXm4Z/viC4+XBiH/ODyTpM28d3Fid2ZFh4Mgc1bw4NNw8Kfv3TPA0/GB06cnM3Bz8IaGNrej17psHaeMCrYxHtVLWXjkkeeWMkdKw58sZvZAaTmzwmkz5tLmRUmbBjTtc1wcdfwc6YRTSS+49pdHh2BfAfL9hac511bn5+yLgmsrU1BedGlTKRcEbe5tUiHIFHWKV8XKinQvfi9+fKeO/wJfxCvB'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_beam_after_k40_top80_min25k_plus_sample30000_batch04_witness_shard_6_etp_refutation545_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
