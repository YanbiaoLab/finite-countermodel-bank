from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_enum_order3_345","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[1,1,0],[2,0,2]],"priority":738,"rule_id":"false.finmodel.predicatecheck.model_family.e3_345_1521_425_296.micro_20260606.witness_shard_1_enum_order3_345.v1","rule_key":"false.finmodel.predicatecheck.model_family.e3_345_1521_425_296.micro_20260606.witness_shard_1_enum_order3_345","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WTFr20AUPtlKrFBcS87QlgZsK2qdqUMJoUOID3MlcRf3J3TI0CV7CiE6WhesKa5j6FKI6Y/orJQMnUq7dUwDhYwOXTwYq3cnJSnWXbDJ3T2IHPN0evqk97373vP7LAQgLABqoyo9hgb70mNHyI5gCZTZF5ilp0VHgGunUYnvAFEUZS2eYxjVPiBkph0hWVLdcDlL9gUxwEBwWwD/PVnke5ZE1+p7jsDzKPAyXCgrhmAFtMoCT0YIJRt/nk+egSNTsDSBYvopKPEK7yea9MQ33D+en3TcB4/J8RKlBegVMDt3AuMr8mcn16JvjFoJAg02TKIdDdsaoiXBTB3ICI2YHQrTRqqNWDBfCzKSvtfWpFCXMwqjDa6D1Rg3lGIbJ6EINU0bUr4Y9F81wcL/HiQtrQOCEMYcVUu2Dio6jusi1G7bdctQSDYaqLvlunXUaluOU7cqCsnGbLGB0LBtOxWXBDPVkY3k/h7aPQsOrJKz4e6hYaWlmmxR7cL5HUWbrQOr1rLVkM3PAG02jgx9wcKY1ZpMKIlU7Wx6tlBGttzAJ1VxXNCzs1XH/tnyV0o2DTtbCWg0odRVYt8Xm+ukfCzoIdubs4AI//WLk80W7UcGjkqmP2uuaywkOcwQaZKROlME9Dy2VxcNHeBwFxXJXm3pgfaSIAvaVsNznIp6GfmiyAIFWmQkbLiB57oe2XBatK0l2kehjFxpmBozUtioq7C+2UHkRXX19Gw9nczGJAsJqzU9SjtjlWnOmzYbOSkmWx1orP5QB6Irs3TmCJGR1Zte6qggUz6L54zsMX+M/jyX27PdpFf7dyT3bLQLFb5Uz5CZsHRAQrpQoV9uqu6LUT+hHZ3UGVQo7kYx6+h8mU2BWEaaNgb4tJBUM0kyUojstACAP5Ja08STcCb4Dne2kcT2kchI/hYKqeDb+hzQURCVQzLKGy6KPCQQwDtfHkje2QSe/GrH6B/PPwXb8qIJs5+N+9d+ye3Zkt+P0qN/Xqt/zru3uRkGJM24UqbmFiGv1ec99G8zk43Ts+2mYcBBjlNsZpKRMbPSHGiYqaldY9XhFrepzUxkScrKgrSRMSCB96bZQn/M3S7a5YBkOnC3HYjejT/e1lKe4xK3RnNuamqBBBeuStSEcX7i6752eUJ0+p09oU9+LYVj/mHquu/yqfUePsefpn6Q/wC+e157'
_TARGET_BITS_PAYLOAD = 'eNq9Wb1vI0UU38gSbtAZieKqXDquQ6KiOBHT5i+gOhzpJChywSeBbAkD4wjp6K9BKAX0FGeEcE6swhilQKfjpKOKYbPeSCCOIt4NAXkSJjOPN7OfXu+GD2XnFSt73s6+eR+/t++9ffecAjTvgKLaE3VtSv1nQ1+pvsItcAIKVNJzZNasV7+BIlqxDqGYLMsa7xcx6tborQc2X2Q0cctoyy3YslUiAxrrJQzy7I2jYs7PZc9qOX4J56eOI1gRY1+W7KDMK+GIUlXOmUeQ/7yLHpAcGATgKWcQy1b8NsWtUzwG5QRiFwmUQ3gf78U9+OxwW6yK86KNXNwWyPg4E33i1uoZcoOs+DfZj5zhbqFEeiz4EncQPsV7ZegqXx+d0E+RcV8vSe0xRYcUDFA9kmY984asXmAki5vQDGGk6XZp2Fwq1bSwvhHNMHxTGqB6KweiQps2UmEjMQTgQZW6LUWimAC70QfE5USDsBJqWlkayYbV/4POCK8WbOv1btue+r7r2na3G+wyWSHYlKDNHdfdtXtd5vu7bFIh2DR9dte2668F/sRFYbw6sKGkml1fttZnI3/LxZ8HvarBhvT9Nbz01lm/F1QDtr4AY7RkSXPCFNjAmHKqJLJtbkhaiGpDwlZOMTFKWDo282YbL/WXD16xBh/aBt5sh2CQSkvdSuilo8HeFf/azAzY7i53xt+6e1duPOiNlap+lUj/brBnMJGcEq2RoTLSZIjAhqPf1VNpQjmyaU+Hts3MqHYfNet02dDxfV2CVKvhV1MtqKNqR2zkCES9XCVEh27HcV0HXzg91dZi7QNaZiW0P+QGI7K0Ua+CWrxto6M2zfRsGyaRTYJoBGGEAqEnH5KrgUflYNsFg9mfmtAoIWYyRrCMHIt48MQ8SPJWuHRUe7KbLmUcHC1CPOHKpLuErbdAxNRleDRnFBDNJ1NV1UhsZd16btCFuMmZ4bO8D/CHHd9HWOz1dBTmxm6hDHIxgT3bsReN4bzkfGr2ppda72SWkJ9P21k9oolcxhRZvVjYsx3FbzZ1jDSd7KifM0dKT8TzLjW0y430Uj14nMVTU0zywacGJJ07RV38zFFWy96t539tOhfQnLC8jAto62yonL5oIo/8ILCj65OM1RYjKZmBZsydCaDQsPEf7NncGGzaEOn5nLbu6Pqfp1bTk1Qhs3r4ccOXmjsNoCA/usUy0ldHEfnhK1qtC+2VY197JvL+QiT9AxAyeunjjTOC5kyEgiT0axO4RLC1sDiY+n4B2HTBd/vetq2t5l0K2KIysiB5qoJv52ZHjYLwyJxF8Tk/uEYZIifjojfbNNUoB7abHSD31n6FSwTbfYFlJCt64Zw8asvW6tlj2L48sAmQTnGlosb9D69nl5KvCf+7ZzvWqK6NmvlYWxqgQwRL4hGFBFdFfgnv/4vocAtjk8IcMxOYyiT1gUa1mlvMx1pTtfrUkyqeky9Hw9i7Gfe+fBHMsQSBjOVDsDV6C1nrIyEZwitBMT6eNk7zSxm9w+wlYY6ZAk5xVtB4vwOsPfXysTbcxiOrgKcQT2uGj/y4nEgr9lZBukqDbh5wb4PXlLy5GGshstoLYVPeGaAMPw/z/IBEJ76A/pbPWs7rf3K0bWJZVJRf/zrKpkli+q8DEq38dGchsfPH6sOVUCa382BLk0YKhsRcXnlp9YWOevr+KJ/YyephoBK1SANb5+h5A+iH/+v5YnPoqu+WKkWF+Tbx+NoLn7hCzJSbgujYmx+7eQPoKORzlWhq3wXfPZ1Rcs7g5GEQJvb0GGe/cL7jZdMZfe8kqlNScshVcmtexgXZ62+NPpd7'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_e3_345_1521_425_296_micro_20260606_witness_shard_1_enum_order3_345_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
