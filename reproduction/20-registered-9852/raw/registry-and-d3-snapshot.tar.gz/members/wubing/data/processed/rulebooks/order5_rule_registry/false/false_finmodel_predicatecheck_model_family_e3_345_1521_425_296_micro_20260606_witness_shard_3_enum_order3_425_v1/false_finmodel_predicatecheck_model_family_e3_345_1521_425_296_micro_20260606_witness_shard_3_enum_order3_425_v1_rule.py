from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_enum_order3_425","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[1,2,0],[2,0,1]],"priority":740,"rule_id":"false.finmodel.predicatecheck.model_family.e3_345_1521_425_296.micro_20260606.witness_shard_3_enum_order3_425.v1","rule_key":"false.finmodel.predicatecheck.model_family.e3_345_1521_425_296.micro_20260606.witness_shard_3_enum_order3_425","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2LEKwjAQgOFLK1gcyo0ODsEXMU/lnNFHcuyj+CAOXnQSKa2Ypgb+bwiFlB40d5emIkl8jtLJGtqxiX0QrOI9EXTsNtYH+KydcDulK18o4n37itvx8iuh0bbcszpvLdT23mb5iEN/tPFqvZymDQAAAGBBruSvIjt17zgJ/6PNxHzMGWzyYcqCzNXMK7s8Qo5UAiqUcr//oSy+cxE/OCqpMmljOxSLpi7Ettjn1AMO3w2n'
_TARGET_BITS_PAYLOAD = 'eNq9Wb1vI0UU38gSbtAZieKqXDquQ6KiOBHT5i+gOhzpJChywSeBbAkD4wjp6K9BKAX0FGeEcE6swhilQKfjpKOKYbPeSCCOIt4NAXkSJjOPN7OfXu+GD2XnFSt73s6+eR+/t++9ffecAjTvgKLaE3VtSv1nQ1+pvsItcAIKVNJzZNasV7+BIlqxDqGYLMsa7xcx6tborQc2X2Q0cctoyy3YslUiAxrrJQzy7I2jYs7PZc9qOX4J56eOI1gRY1+W7KDMK+GIUlXOmUeQ/7yLHpAcGATgKWcQy1b8NsWtUzwG5QRiFwmUQ3gf78U9+OxwW6yK86KNXNwWyPg4E33i1uoZcoOs+DfZj5zhbqFEeiz4EncQPsV7ZegqXx+d0E+RcV8vSe0xRYcUDFA9kmY984asXmAki5vQDGGk6XZp2Fwq1bSwvhHNMHxTGqB6KweiQps2UmEjMQTgQZW6LUWimAC70QfE5USDsBJqWlkayYbV/4POCK8WbOv1btue+r7r2na3G+wyWSHYlKDNHdfdtXtd5vu7bFIh2DR9dte2668F/sRFYbw6sKGkml1fttZnI3/LxZ8HvarBhvT9Nbz01lm/F1QDtr4AY7RkSXPCFNjAmHKqJLJtbkhaiGpDwlZOMTFKWDo282YbL/WXD16xBh/aBt5sh2CQSkvdSuilo8HeFf/azAzY7i53xt+6e1duPOiNlap+lUj/brBnMJGcEq2RoTLSZIjAhqPf1VNpQjmyaU+Hts3MqHYfNet02dDxfV2CVKvhV1MtqKNqR2zkCES9XCVEh27HcV0HXzg91dZi7QNaZiW0P+QGI7K0Ua+CWrxto6M2zfRsGyaRTYJoBGGEAqEnH5KrgUflYNsFg9mfmtAoIWYyRrCMHIt48MQ8SPJWuHRUe7KbLmUcHC1CPOHKpLuErbdAxNRleDRnFBDNJ1NV1UhsZd16btCFuMmZ4bO8D/CHHd9HWOz1dBTmxm6hDHIxgT3bsReN4bzkfGr2ppda72SWkJ9P21k9oolcxhRZvVjYsx3FbzZ1jDSd7KifM0dKT8TzLjW0y430Uj14nMVTU0zywacGJJ07RV38zFFWy96t539tOhfQnLC8jAto62yonL5oIo/8ILCj65OM1RYjKZmBZsydCaDQsPEf7NncGGzaEOn5nLbu6Pqfp1bTk1Qhs3r4ccOXmjsNoCA/usUy0ldHEfnhK1qtC+2VY197JvL+QiT9AxAyeunjjTOC5kyEgiT0axO4RLC1sDiY+n4B2HTBd/vetq2t5l0K2KIysiB5qoJv52ZHjYLwyJxF8Tk/uEYZIifjojfbNNUoB7abHSD31n6FSwTbfYFlJCt64Zw8asvW6tlj2L48sAmQTnGlosb9D69nl5KvCf+7ZzvWqK6NmvlYWxqgQwRL4hGFBFdFfgnv/4vocAtjk8IcMxOYyiT1gUa1mlvMx1pTtfrUkyqeky9Hw9i7Gfe+fBHMsQSBjOVDsDV6C1nrIyEZwitBMT6eNk7zSxm9w+wlYY6ZAk5xVtB4vwOsPfXysTbcxiOrgKcQT2uGj/y4nEgr9lZBukqDbh5wb4PXlLy5GGshstoLYVPeGaAMPw/z/IBEJ76A/pbPWs7rf3K0bWJZVJRf/zrKpkli+q8DEq38dGchsfPH6sOVUCa382BLk0YKhsRcXnlp9YWOevr+KJ/YyephoBK1SANb5+h5A+iH/+v5YnPoqu+WKkWF+Tbx+NoLn7hCzJSbgujYmx+7eQPoKORzlWhq3wXfPZ1Rcs7g5GEQJvb0GGe/cL7jZdMZfe8kqlNScshVcmtexgXZ62+NPpd7'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_e3_345_1521_425_296_micro_20260606_witness_shard_3_enum_order3_425_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
