from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_enum_order3_345","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[1,1,0],[2,0,2]],"priority":316,"rule_id":"false.finmodel.predicatecheck.model_family.residual_20260519_top1.witness_shard_1_enum_order3_345.v1","rule_key":"false.finmodel.predicatecheck.model_family.residual_20260519_top1.witness_shard_1_enum_order3_345","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WTFr20AUPtlKrFBcS87QlgZsK2qdqUMJoUOID3MlcRf3J3TI0CV7CiE6WhesKa5j6FKI6Y/orJQMnUq7dUwDhYwOXTwYq3cnJSnWXbDJ3T2IHPN0evqk97373vP7LAQgLABqoyo9hgb70mNHyI5gCZTZF5ilp0VHgGunUYnvAFEUZS2eYxjVPiBkph0hWVLdcDlL9gUxwEBwWwD/PVnke5ZE1+p7jsDzKPAyXCgrhmAFtMoCT0YIJRt/nk+egSNTsDSBYvopKPEK7yea9MQ33D+en3TcB4/J8RKlBegVMDt3AuMr8mcn16JvjFoJAg02TKIdDdsaoiXBTB3ICI2YHQrTRqqNWDBfCzKSvtfWpFCXMwqjDa6D1Rg3lGIbJ6EINU0bUr4Y9F81wcL/HiQtrQOCEMYcVUu2Dio6jusi1G7bdctQSDYaqLvlunXUaluOU7cqCsnGbLGB0LBtOxWXBDPVkY3k/h7aPQsOrJKz4e6hYaWlmmxR7cL5HUWbrQOr1rLVkM3PAG02jgx9wcKY1ZpMKIlU7Wx6tlBGttzAJ1VxXNCzs1XH/tnyV0o2DTtbCWg0odRVYt8Xm+ukfCzoIdubs4AI//WLk80W7UcGjkqmP2uuaywkOcwQaZKROlME9Dy2VxcNHeBwFxXJXm3pgfaSIAvaVsNznIp6GfmiyAIFWmQkbLiB57oe2XBatK0l2kehjFxpmBozUtioq7C+2UHkRXX19Gw9nczGJAsJqzU9SjtjlWnOmzYbOSkmWx1orP5QB6Irs3TmCJGR1Zte6qggUz6L54zsMX+M/jyX27PdpFf7dyT3bLQLFb5Uz5CZsHRAQrpQoV9uqu6LUT+hHZ3UGVQo7kYx6+h8mU2BWEaaNgb4tJBUM0kyUojstACAP5Ja08STcCb4Dne2kcT2kchI/hYKqeDb+hzQURCVQzLKGy6KPCQQwDtfHkje2QSe/GrH6B/PPwXb8qIJs5+N+9d+ye3Zkt+P0qN/Xqt/zru3uRkGJM24UqbmFiGv1ec99G8zk43Ts+2mYcBBjlNsZpKRMbPSHGiYqaldY9XhFrepzUxkScrKgrSRMSCB96bZQn/M3S7a5YBkOnC3HYjejT/e1lKe4xK3RnNuamqBBBeuStSEcX7i6752eUJ0+p09oU9+LYVj/mHquu/yqfUePsefpn6Q/wC+e157'
_TARGET_BITS_PAYLOAD = 'eNq9WU+IZEcZf+0EW6KmPahzMEnjRSEHDSy4h8j2BgXNLV48CNoDe1DIzvaCyTywzVavOexJhFxEFsnqQQSVDFmc0Tw61bIHI3FDAoFdfXldsywke9h+b0hC1yTVVZ/f972/3dOzxrj96tD9uupVfX/q+/f7+iczKUXnLNBYe40+O45/PGEmEiLJz3AKwkRCp/PSDBfXvA1YOtre3vIF8DxvppctNL3Rmb8E5vBCB7eMzkdLtpw3RxBpnXT5owIDtlgQn3jo9u/csi03jzgKuuEZaWM32VWRtFoaX0MMEegx/Hsr3NQgwCZACkJCGhJAPV2bhgKkgAnoBIk7C5LWQEutjqBibcoVSmQEnYEnpaK8rJXA9fUIZ11KQtELwnuB1nty5twED5e4Lx1rbtIcaWEG+C7uQQ7SbdA1fGj4lQCEQaUkLmdnNN1p3Ip/cOJ9i9ebs0Qf39LfMRqeQhklWHVt8zLuEGaCZ7lU+TG/11n/edc99/xllBMJ0o3R2JNQw2hm1Daafg3UMmKmDsnQjXicPtJs7upYY2KDWiRD8y3HNon6pl0htVZJbJS52QpHIyOlLQStAUYIGLMTrmR0vOrYR1FHGGfE6p2tF0ziOIqCwPeToXYrdDYitLkbRcOg7+s4HmLsXZ2z8bi9EwRNP4nHERIzq3M2z7u0FjQf8Damo/h8hI9v9lftbDj++SB+9Df0oJ+sxtkGD0yhrtHwZrXRYmcDWxc1dLZPPXzs3Q/1rsKMbrHsCITAvI48JvYjOFvzbE2itQ8wMDpo7NeT2UYN7/77v+5tPxM0R2f9fZirDrOCa64ck7CUMUfTVKPxFwbZJXFW7EGNo7VRJ7Uv/v7Sz+794+e3Hge4ct+qa6DOPZ/buv636Jl7H9r+3uOPPvXdT8YPrrBI+Pv2FVefIg/Edbq8msrIOk0Engg5V0+mgdlV53yIXWQDg2lUnTORDXsyEOlkP7E9hlaELgPwMW5J7XydxAi1MMfHTlkEFLgxAlpWfcAtMNQEvvAHvJQYsRlMMFczoWmIO3GH0FhvARMyEzyOjxGY6gjDMIYTwLBIMwRiGlDSCOiAGElRCJWaijdAYgqfnkfJtny9E8bxeCuMIoNoMEkUJMIkQvcQJaFYEnA/UrGkAHB+RQ4sAlF2xHMBBY4YaBfhOUsgEk0bSSADgovFBP48SQnRT2Q9Y9pACjlJmBJyIs7TMFUMx2hS0RTvMJBhRgH5AQlwwHMcypI0iMmdiCQKzwRBP9z0qfbJtMbXw8i30BriEaccyrNAA+VIk09A7BFiZVWwXEgmYVBJNce1HU5VdD251ohrqSVMTWo2DifxYGWWZDYkFUlJYTtK73uopQTmT6MeDF0eDFMR8d4QqFtdl/l3w15gndvcVUqiSIie06xBKoMkTTikNbLHZS0CtgLk21U2VrIOq09nEEYVvRnUmgYn6FWbvYqEcq2x3hHCI1/8ekVXyBXTiKmrYMBVMpvJmgDjLM2hNWQtiFpGYrnz4UyS5uLVxsoh1Bj9pUwl4i5RQiaQF5VUeJRmkxcpeRerrDayHfzF7s9fOjUNUGX/KLOW+obnXbd540krKOJWOnV77bVhOVW54GwS8g5XJdwVy5CFSMh/5H1GepTzok7Q/577kfeZF/xCE1M8S53DhyB/DyNHpuSyFRblhiYrV1Bgtn2VteFUwZ+GbKr7ZGVKiUNhuypH1pGrqKIql04x28v3HDvGnM52rSrrUQyPQjz72FtvYRAk93Z9btottPRKOYrGYKmK8aI7UYPkrLcMxWNWTTBz28rNUP+vN1cycxBeoHFHzHbrAzxKnLIpDga4r88qUuJ1i6sDUdHaYUsqeqAVdVcMaD6/IWYrWj6Mg8vyPOwxohv8odQad1KpF1vKEee+SekuHaUBlZ5blpExsWIXm6+U7KDX3o+LTvEyS/ovjjCft8nZCkIN7t3lKkJCDgYfG8NddLZuyKpY4mxc8J1+9mLAWlN3xdmojFSwpIMsueD7/ha1gpBlipRon1A2rnMadoHGHRskg9/gqT/8wtU45iZo8MjxN7jThISAnC0pb///drasjDx9+Wo03NyhBtrb8avcaXrnlZ7rnnj/KlysOJvOnS1LvexsfKU+JBWcWiViy+tpeAc3W4g4brYdOdvgArSg7cQ+ICGAf3y5yhnW46kPfGTMtseBb23UcQu21nj4DSy+p4U9IhHvs8PFKQXBB4KTmhFZaVtdrBgmqaQ5yLy62Zy3tQ5Bfakc2XP2z1H76b0bN0C5PD+mGjue31KyxM0ZAJSyXWevbvUPBfYLERZSVBNXiu/WweJUVr3q3MdIKZXFisPRSjt8dev1KHrsbSzczaxqazsXkWUyeK7i0qlX4vz+yxKhuyRcFS644HA/nv3iuLvRqdhaXkmwZ/XmClwyGziywczgacHNFxskHPgSeWsxsKvue4ZAUQWomK++mEXTIjD9rw0SndYDhwK7uYq8kMGj0WWcFZmtDBq60vwpC7KjSqsGTNf2TNsbvQvXWicTOAfWNrz3BIgTlxYxG8foeQXw4R+6x9HZ+fXt3178K4YogWkaCDYzsOzDo1/6VfT0v77p+93oTy/216fjfrL5y2hRAWyFZi50CDgsZN6N3F7/9Mlv+N63fV99zYsiwogf97b1+JGDvStwfHxwAWAfbsAVaM/kT9+hOmVufyjWxal5GncoFf4DeVjIiw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_model_family_residual_20260519_top1_witness_shard_1_enum_order3_345_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
