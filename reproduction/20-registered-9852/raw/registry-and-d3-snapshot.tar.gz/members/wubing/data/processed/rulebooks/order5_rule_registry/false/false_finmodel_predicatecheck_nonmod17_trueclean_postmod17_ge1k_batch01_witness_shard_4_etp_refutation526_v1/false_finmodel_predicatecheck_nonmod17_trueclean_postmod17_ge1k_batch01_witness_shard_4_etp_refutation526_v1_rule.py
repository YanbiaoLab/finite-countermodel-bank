from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_etp_refutation526","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[1,0,0,2],[3,1,1,1],[1,2,2,2],[3,3,3,2]],"priority":723,"rule_id":"false.finmodel.predicatecheck.nonmod17_trueclean.postmod17_ge1k.batch01.witness_shard_4_etp_refutation526.v1","rule_key":"false.finmodel.predicatecheck.nonmod17_trueclean.postmod17_ge1k.batch01.witness_shard_4_etp_refutation526","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt0rENwjAQheFny0imgw2syOxBkYKGXbIBDpVTwigMELECGzBJRCQqpFC4QILwf9VJpyvu3SWnUlHKvmxkL3exdqKxW/rQJn1WGndcG/2guvw67xZ1SVsB/6MZ2ufrS/fu0PdjGUjl622O8ZwVOlnFU+1S9sZUlVuRDAAAAAAAeHG9LQhhTqwhAwCYrQeFXxF1'
_TARGET_BITS_PAYLOAD = 'eNrtWF9oHEUY3xDBl9B78k25F0XwQdSYYlrhKD5oH64vNUKiNgjaQsv1gkdusUduC4WKfSkU+pA/Zx8UlbTXSEru0PWyFkGNpFfFmmuzmV0hUB+u2Smcl7ncZGecmd3LXS6ncnZXotyPcLvZb3d++81+3/f7ZpJYsxXaiNC8OBQJ/9Uo5daX9sL6DTqlMqJtYZbisG23MGTXkZlU2hrrOqarLQ2BV4gJWhmUc9S2CGmHZFg31ltblteJSWE7Y2nU5B5i8ZCYBJPPK0PELqtYb+XK989fDN9I2R/hZlekd/WILFNzpfmR1+M3RgsxSC2yw5WT6pplYcUlbfgqhL/TsKZqTZ/mYWk7KpTQJD/5lWKKbR4SJvMrtO2mr2kHHewmnO9KiiNLomD89IEDIvM62O1YHmMljppxVitZ6cKKjAgBAMPOzOxmBKRK0JXM4Gnf2bqkLcnqvu83WYjpXk1/N8/T9/1lY+Lb80xviZ9GE7qq+svGhLtHHhGnIK34XB6DmwHRJXy39UMD/rGdoV0VfuQdkSa6ImR38vQf4FlSWQ0wCb1t0jN7qki0r4rbynqfbGcfi9++Dr7Zs+8zjN7i6h1csXHnI7SNS6YSYlEPWZ6FCOJNEFu2+JYAJ/RIFoAxsTjxHUpEXcuoapSva/xnm2GexWUUEf9knGsm8Gsm59YyumXNU4JZlrHvxpZeNvt4/lRmLQPiOgCIEoUi7PTHSid1djuKRGetlqKz9M7mRE4jinxLNh6HjMF0l1LUqf7ujobC6eHWjoYtXkOILXRj1olf2vigY64D1Rdm0HGERT+tEzqwxQjbLpKtJZ1d321pGLXhtmarQFots7EuJas6VYt8LOKOBOvO1J5HjdQKbXo54WZrkprPWtoEVWQXoBX930WkJB1euLVy8KnJif3hdw7HPr02ZF2Z6I+k0D1h3fS2jZR+3MuqVrgmOCbIqYkYMhLQj9VHtySNFGIz6r3jsK/w5s2ccSpXOgXLY4YIiNXh30MeeqdI0sJDvb1C2bigMsdkZFk5ZAirfmfJS+EJSNKjIxLiRCkmqNdkGVoGYGSY+wZPbmDSlD8PgicmP5794IufX33uEXnih0/uHnp5bmqwT15+AW740UY+Xf0Xwz9rfVm8io7IoGwUr6pGIodYhBhFPO/LpsWtN2I/uURgtJCYQUdgzkiMmSgXZNaKsz2teaQI7vaxCEbedNVjxL82UhCJpsuyAFBVltrUJp6TKeH9CzUi3nQZTrqxOpINx6ly4eC3onp71BBFQfpPLNVilELeyCrezWnDkgmz/K1PnrlNk+pS/LdlxfyrDZIOvESLqrvzpgeXuW5nHLUMcbPA7sCIB8rG8Xnq7YFfHs+mxgcHRo/eBSCW79cPzU4fv6DnF69M7+stWVb/b1ORJwcH+hYix46+NpAaf09GU7G8ZY2PX57OLA1N8guLi3NLQ5en84tfqYl8/7ET6Tn292Esv8GSt/TizVJPJ4j+i/gDjnIOhA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_nonmod17_trueclean_postmod17_ge1k_batch01_witness_shard_4_etp_refutation526_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
