from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_etp_refutation427","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,3,1,3],[3,3,3,3],[2,3,3,3],[3,0,3,3]],"priority":726,"rule_id":"false.finmodel.predicatecheck.nonmod17_trueclean.postmod17_ge1k.batch02.witness_shard_1_etp_refutation427.v1","rule_key":"false.finmodel.predicatecheck.nonmod17_trueclean.postmod17_ge1k.batch02.witness_shard_1_etp_refutation427","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmUFo01AYx79kmbwVhaQtrCf7Eiq27GCdohexWYxbA260Kt7E4mEg6NWLYJ813WJxdFQvwqC0HVRwMBBPglgEYTJFh3gSROZlAw9u1FEG6/NF8KJF6SE6x/sdkg/e//Hnfd+XL4EIAEDgT8zNAOcv8iW7uUpbI78ukByBEqAOW2anjhSiL+VuXGKANFHosHB/pjCYv82ClCH9Zj/BgCWs83JxOBwOh8PhcDgcDofD4ex8KKNIm5QemG+78eID9zrZuiB6YPaRPn29P9Cz0Roeb7g2RwOZjYkPKP7Mk6PNla8/XnmVGku869+M1VsjX/PL4ecBX/kg8sCMlEy/ZUrTpl8RSklNM0ziIEXRkeDF0d48bOCBENzZE4dM6YV5CkIQj1/0QY8niTw3ltgKrq/Uy8be83fPLNT6jbXicrh36LjkgVnj/ZXiqLHr8pq1QOavDlwbN/TPvfcU7HiSyKQyGkyjijPoU4NpU7UNlFdYKA3JXrjFqq7RYddIK0TtFKrIhjqRw0jkg2j7Mq0VcFUG5aQs4qpjoBsyqLKBdkLRGnS1Tj+Ft+jbxVq5Xcw216PtJUpxe7Ljq6LJhgCTPzlWyDZpwqFqd25RhHAfIREZECYRENkcFrAmAmb3n7W4T2ICJgcRdHAcgG6n9qXalOY7FFwa3pd3f7CkrEr8hGrnMrs71M18lLYqrvzsaaZEFRy6uZ3LNgvYQZJuChIQrLFRJQGyZZF00sppllxX7iZZVG0325x/gW5pt1jXJzXW1FZEUVTQTdtBQOD7B4PfAon1+Y8n4v/iG047u4o='
_TARGET_BITS_PAYLOAD = 'eNq9WU1sG0UUXjdUVolaHxDthSriilCFStUCEnWFhBAH1EitRCTyJ0XiUoxDkbNtTDqWQGoRh0rApQcI4gAHSAJC2C3LZhJVIkXQmkOFUcx6EgUpkZzshrTOJF7vDm927dTJrkPceDyHXa/feD6/ee97P7ODNrZQeI3x8b5zDSPnlqcMM4ZHGDMZO9NHuMTCNtxaJN2dsnW0ScvMf0iJIvEVBKW/DdtPEJZmaqw1CUC+gpDNiOYnQFeY9ZXtB3OPkinftXqyNsr6SqZXbcIMH0HGSA35/gLHKCv6SiJWQTH9YEKJvQel4HWvoqgfsQijPoq2nP81lnnWMNc8qmDnlh33oCRsqll2D1awtVnwet87twffhS/HVPh3KUMxK2ttttHnaWKSq3OsZx3dAYs5o8SaMoIOWMJ9MEWjuaotN0e1NhfNbg5aiwM20RwwVNlI8C3b9UsqDi3kojHROO4IOGAzzdnIMtn+OH3JRCuE2cQWSYJgtUf+20yyoSaR7corEKetXzigYYkmm2R9x9hldaE5ZFtrjkeGqoCQ8OAVkKqQJ4STbYPVqHSVXRad2TZSaDSeVRTBZEtsfMzLNCWYbCXXVlMbFxYSSLabAcclC0A2rV2GgILExUi0XNYIIMXXQJVSFwqztoRwaj9vr82BnWyTQEtgQ/EJNwjMYuJk+JHHUWmWYQBAZ16LnTV56haWvOfXIHkajMKVhYVXXKWhEmHEyWlO32GIBBvG7KTtAoVBRY6FxRUJ57KRlKY5LhFVlnR9u7mu2rjyWP+2o4iylCxHxg3YWsPC1eUfqV+1MYAYkGnEeUiWl6nC9EHfhSf9uJTM6vo4sM0lG6xlgdmIEKvhpDaQ1TTMVy+3tVgc2TJJRlZhC0E/Gy+JJpvbqBOuH7gAEQvWg6OmCWaCvUNZWuXlQkae8m7eAUpZFndAJK7BQflRRR90q+JChggOklEtluky1ILzUD41EYc5orAMREq7mAV7lWNWVZGAvb8g2we1bck2QrQidaNFUbMEEyBVyBh61AEy3rZMG5mGGRXas/VLrdCRtjt98LGz/Hoh+IWrbktDj07apFPP/LVY2he8cc3pg28tDu+7+CRNvyik+2iREi8fOjr2/cRTC3v/7Ahef3Tw8MwLi4XeOw7h5lAp3MByD0kJyGwmT6E2z2yqgmSq65jyTACMz+bcxNOYvjgkPUfuzrO3VtJsOHJc+YHNs3T6swIrOQnswcFgY0JZQJrYk99/qKNXnf3y3LcnOhfUA/2HZ4rjkyY/Uwg0tk8NS4n+o+r6JweSJ1D7h3c/uKbix4pv6kS2mUxB2lj3/3rh4/zofLd8u5CDaJmLq3RQh4/meNQ0kO959Y7ykVWLbPJkIfcbB4JoGR+j3YaauzhEaIQDrWE3btlVVttJ2YdrZLaaJ+FO5VVD9vBlpIl8/wnmBV8N2cOT7VTWP2vyk3w0TVjaqRwbQ7bo7dhwp8H0nwyLdMkqvWSwnKFSSAjFPARmXGn0l/7PIpuHWYtsD14tGJsrFWC1NoIIi7KhKrAd1Q+oFtkOdkhPzOyRnj7W2RvoT7TuzwSOSBIJXGBTPt7bCkEApr90M5ZolSZkKQff1pEgglOUrCIk6dC2gftZvEbm9ThQ6r4nVQz0sVk+HbiEmSy7atZzzPFp53mt8PtHR25MD/IXLGPJ7vTPufjQ8D3VO1dpHU128+nfjMBM2k3m36vPd8rvaiLIu9NeOyeNnVvId7xRJDI1sXI/byKiGRyDxg3Ld4nTo8q4xac7DUkuXndBjSoW9sZ55Emgu04GoXIJoHi3zdMt7j4ZTJpuWeItBE5KW5WZakswa+vMoLRsOQFpB38FH4eejVmpLnBq3krlIHTEZR6lXk1CwbCUZCb4eZkRSewTRXAdb8yCBTdS3tpar6L1f+zVLTlNW6FbNzeLSB2nbv8BtzeZaA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_nonmod17_trueclean_postmod17_ge1k_batch02_witness_shard_1_etp_refutation427_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
