from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_predicatecheck_etp_refutation352","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,0,0,1],[1,1,1,0],[3,3,2,2],[2,2,3,3]],"priority":728,"rule_id":"false.finmodel.predicatecheck.nonmod17_trueclean.postmod17_ge1k.batch02.witness_shard_3_etp_refutation352.v1","rule_key":"false.finmodel.predicatecheck.nonmod17_trueclean.postmod17_ge1k.batch02.witness_shard_3_etp_refutation352","rule_version":1,"verdict":false,"verification_mode":"predicatecheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWc1u00AQnrU32LUKsaMcOFR0sRYpjxAJiW6RDzYSUskT9AWQ4MYBqUtVpLQnE/EAFU8SLpy5c8kj5NhD1bA/Tgj1Ok1ar+HQOdh1J/bn2ZlvftYniDkw9kDKR3Ucc3Xq+vLIBqCFyAuHIXG6nCEwymTWNitgdlShuJi5ZsV4tltxywsBZFRMEZDYpODvwQnB9NLbPukbn3VOEadGzbMtRCA0KHphemy8g5350DJqRk6QYArVUjb0YeGOkqG+PmGvZApTJ7pffjGk9YkIgRWSQoLnz/pbg0ixwOJP4TElLjQiFwrsqBkw0Ka1mwGbaDTUDNqlAttrBoxr07xm0KYaraEYuVJgu82A3ZPtnmz/G9m8JWRknWxLyHvWybZgNXffwQfbZFuwOj+hSWKZbH9Y3R36qWWyudpX/cUBpvbQPsKVCslg0S9xbI9s7cIiAWk/Lc9bXdGYTeyn5R/I2xF+QpgAA+SDPImWz7FDtv6Eu0+AySlEADqqtfVtmfbYI4BC8IlsYK0XAffYJUDUfKXmjtAm2CGD70gDjYWJEouBNQJ8paM0jlVI5EkniuxWtlHSyYrMuIC1JgcC4nToj9RFNp+/bGG+6mQ0ivYF2zTZRGA6wm3EChjL4lMax4zoYU7HiDWy9TIgW2IJhX2IdWyTTQ/qRNrnMEvrtzRk5xgLN4m141QvoEVyd305zSug1HFkjuRgzW28+yaJPocq3oMesZwk8/is9y18GaiLYtfEHuYggZ7cB2lR4a8iZ1lrEtiAxC1f541W7FgmQBr0wihXQOEXByOOQ5zDP5LLdoNgNU8fB4erHrfD3XGd7d7b56sso/RpnYWHvPZW5rQbNgY3Tf/VqkdQ9Or1CVZJ0SRDX0x09YKFD0hFwschr9qvvrUIp2yb40MCeUzUcFnP6ylA1TvhqvPitOY2EnP9+teTp2z4KnS3ThTOJ2qumnInn1Oiuga/Ko5uUQHMmaTVFYmZzQf9eupC5acFxep4wAnkcAzWu7D+mr/boED81KdfhsUMyj4emty7GdnkMGVwJqzzv81ip/hWM+Ll+8pdSWYi+EZ4RX8VhDe3POdwx2LA5x4u53leKqB3LgbTIjiSsmWlAlpDMcAVdhg+OvbBvHOy/uLyKk/TMlrGDDHJYP19gDSo6Fe5E6Gta+3Eor1deidONmiofwPG1vI/'
_TARGET_BITS_PAYLOAD = 'eNq9WU1sG0UUXjdUVolaHxDthSriilCFStUCEnWFhBAH1EitRCTyJ0XiUoxDkbNtTDqWQGoRh0rApQcI4gAHSAJC2C3LZhJVIkXQmkOFUcx6EgUpkZzshrTOJF7vDm927dTJrkPceDyHXa/feD6/ee97P7ODNrZQeI3x8b5zDSPnlqcMM4ZHGDMZO9NHuMTCNtxaJN2dsnW0ScvMf0iJIvEVBKW/DdtPEJZmaqw1CUC+gpDNiOYnQFeY9ZXtB3OPkinftXqyNsr6SqZXbcIMH0HGSA35/gLHKCv6SiJWQTH9YEKJvQel4HWvoqgfsQijPoq2nP81lnnWMNc8qmDnlh33oCRsqll2D1awtVnwet87twffhS/HVPh3KUMxK2ttttHnaWKSq3OsZx3dAYs5o8SaMoIOWMJ9MEWjuaotN0e1NhfNbg5aiwM20RwwVNlI8C3b9UsqDi3kojHROO4IOGAzzdnIMtn+OH3JRCuE2cQWSYJgtUf+20yyoSaR7corEKetXzigYYkmm2R9x9hldaE5ZFtrjkeGqoCQ8OAVkKqQJ4STbYPVqHSVXRad2TZSaDSeVRTBZEtsfMzLNCWYbCXXVlMbFxYSSLabAcclC0A2rV2GgILExUi0XNYIIMXXQJVSFwqztoRwaj9vr82BnWyTQEtgQ/EJNwjMYuJk+JHHUWmWYQBAZ16LnTV56haWvOfXIHkajMKVhYVXXKWhEmHEyWlO32GIBBvG7KTtAoVBRY6FxRUJ57KRlKY5LhFVlnR9u7mu2rjyWP+2o4iylCxHxg3YWsPC1eUfqV+1MYAYkGnEeUiWl6nC9EHfhSf9uJTM6vo4sM0lG6xlgdmIEKvhpDaQ1TTMVy+3tVgc2TJJRlZhC0E/Gy+JJpvbqBOuH7gAEQvWg6OmCWaCvUNZWuXlQkae8m7eAUpZFndAJK7BQflRRR90q+JChggOklEtluky1ILzUD41EYc5orAMREq7mAV7lWNWVZGAvb8g2we1bck2QrQidaNFUbMEEyBVyBh61AEy3rZMG5mGGRXas/VLrdCRtjt98LGz/Hoh+IWrbktDj07apFPP/LVY2he8cc3pg28tDu+7+CRNvyik+2iREi8fOjr2/cRTC3v/7Ahef3Tw8MwLi4XeOw7h5lAp3MByD0kJyGwmT6E2z2yqgmSq65jyTACMz+bcxNOYvjgkPUfuzrO3VtJsOHJc+YHNs3T6swIrOQnswcFgY0JZQJrYk99/qKNXnf3y3LcnOhfUA/2HZ4rjkyY/Uwg0tk8NS4n+o+r6JweSJ1D7h3c/uKbix4pv6kS2mUxB2lj3/3rh4/zofLd8u5CDaJmLq3RQh4/meNQ0kO959Y7ykVWLbPJkIfcbB4JoGR+j3YaauzhEaIQDrWE3btlVVttJ2YdrZLaaJ+FO5VVD9vBlpIl8/wnmBV8N2cOT7VTWP2vyk3w0TVjaqRwbQ7bo7dhwp8H0nwyLdMkqvWSwnKFSSAjFPARmXGn0l/7PIpuHWYtsD14tGJsrFWC1NoIIi7KhKrAd1Q+oFtkOdkhPzOyRnj7W2RvoT7TuzwSOSBIJXGBTPt7bCkEApr90M5ZolSZkKQff1pEgglOUrCIk6dC2gftZvEbm9ThQ6r4nVQz0sVk+HbiEmSy7atZzzPFp53mt8PtHR25MD/IXLGPJ7vTPufjQ8D3VO1dpHU128+nfjMBM2k3m36vPd8rvaiLIu9NeOyeNnVvId7xRJDI1sXI/byKiGRyDxg3Ld4nTo8q4xac7DUkuXndBjSoW9sZ55Emgu04GoXIJoHi3zdMt7j4ZTJpuWeItBE5KW5WZakswa+vMoLRsOQFpB38FH4eejVmpLnBq3krlIHTEZR6lXk1CwbCUZCb4eZkRSewTRXAdb8yCBTdS3tpar6L1f+zVLTlNW6FbNzeLSB2nbv8BtzeZaA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_predicatecheck_nonmod17_trueclean_postmod17_ge1k_batch02_witness_shard_3_etp_refutation352_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
