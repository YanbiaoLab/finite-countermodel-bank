from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin17_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin17_explicit","model_table":[[0,9,1,10,2,11,3,12,4,13,5,14,6,15,7,16,8],[2,11,3,12,4,13,5,14,6,15,7,16,8,0,9,1,10],[4,13,5,14,6,15,7,16,8,0,9,1,10,2,11,3,12],[6,15,7,16,8,0,9,1,10,2,11,3,12,4,13,5,14],[8,0,9,1,10,2,11,3,12,4,13,5,14,6,15,7,16],[10,2,11,3,12,4,13,5,14,6,15,7,16,8,0,9,1],[12,4,13,5,14,6,15,7,16,8,0,9,1,10,2,11,3],[14,6,15,7,16,8,0,9,1,10,2,11,3,12,4,13,5],[16,8,0,9,1,10,2,11,3,12,4,13,5,14,6,15,7],[1,10,2,11,3,12,4,13,5,14,6,15,7,16,8,0,9],[3,12,4,13,5,14,6,15,7,16,8,0,9,1,10,2,11],[5,14,6,15,7,16,8,0,9,1,10,2,11,3,12,4,13],[7,16,8,0,9,1,10,2,11,3,12,4,13,5,14,6,15],[9,1,10,2,11,3,12,4,13,5,14,6,15,7,16,8,0],[11,3,12,4,13,5,14,6,15,7,16,8,0,9,1,10,2],[13,5,14,6,15,7,16,8,0,9,1,10,2,11,3,12,4],[15,7,16,8,0,9,1,10,2,11,3,12,4,13,5,14,6]],"priority":664,"rule_id":"false.finmodel.setcheck.affine_mod17_candidate6_sourcefirst_addon_20260526.v1","rule_key":"false.finmodel.setcheck.affine_mod17_candidate6_sourcefirst_addon_20260526","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt1j0OgCAMgFEgDIwcgaNwtB5dgoMSixBdxHxvIVpDbMNPrQHWE4xJZbD1wZ0jrnllL/Gdp4QA/kv2IXfCdv5QzJ/LzdUboCYRlKSl/fHydRxmy42AVcSjC5rYwlGdI1HGpoBpfD5Ols1RV+Bus4nWqTzoO4Sq4lUbadSrVDpLL4bRlJ4lCQAAAMzZAJyxBm8='
_TARGET_BITS_PAYLOAD = 'eNrt1j0OgCAMgNGj92gchSMwMhCKBAclghBdxHxvIVpDbMNPNQHr8SnZPGh5iOdIrF7pJb4LlBDAf8k+mE5Y5w9F87ncYrkBShK+kbTUP56/dsNsuRGwCnd0QRNb2DXnsJSxKqAdn4+TZYvUFbjbbNLqVB70HUJV8aqNTM2rVDpLz/nRlIElCQAAAMzZAK/Aasc='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_affine_mod17_candidate6_sourcefirst_addon_20260526_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
