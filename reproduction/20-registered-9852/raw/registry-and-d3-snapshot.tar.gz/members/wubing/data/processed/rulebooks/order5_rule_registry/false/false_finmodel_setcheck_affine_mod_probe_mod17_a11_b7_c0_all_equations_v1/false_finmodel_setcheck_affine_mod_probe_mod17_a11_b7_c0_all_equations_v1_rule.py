from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin17_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin17_explicit","model_table":[[0,7,14,4,11,1,8,15,5,12,2,9,16,6,13,3,10],[11,1,8,15,5,12,2,9,16,6,13,3,10,0,7,14,4],[5,12,2,9,16,6,13,3,10,0,7,14,4,11,1,8,15],[16,6,13,3,10,0,7,14,4,11,1,8,15,5,12,2,9],[10,0,7,14,4,11,1,8,15,5,12,2,9,16,6,13,3],[4,11,1,8,15,5,12,2,9,16,6,13,3,10,0,7,14],[15,5,12,2,9,16,6,13,3,10,0,7,14,4,11,1,8],[9,16,6,13,3,10,0,7,14,4,11,1,8,15,5,12,2],[3,10,0,7,14,4,11,1,8,15,5,12,2,9,16,6,13],[14,4,11,1,8,15,5,12,2,9,16,6,13,3,10,0,7],[8,15,5,12,2,9,16,6,13,3,10,0,7,14,4,11,1],[2,9,16,6,13,3,10,0,7,14,4,11,1,8,15,5,12],[13,3,10,0,7,14,4,11,1,8,15,5,12,2,9,16,6],[7,14,4,11,1,8,15,5,12,2,9,16,6,13,3,10,0],[1,8,15,5,12,2,9,16,6,13,3,10,0,7,14,4,11],[12,2,9,16,6,13,3,10,0,7,14,4,11,1,8,15,5],[6,13,3,10,0,7,14,4,11,1,8,15,5,12,2,9,16]],"priority":666,"rule_id":"false.finmodel.setcheck.affine_mod_probe.mod17.a11.b7.c0.all_equations.v1","rule_key":"false.finmodel.setcheck.affine_mod_probe.mod17.a11.b7.c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WEmSwyAMNJQOOuoJHOYhPE2X+feMcVLxosZgRJRUUjbG0JJaC79LXtbvKlR+83b5vniNpPOIIQkNLOH/YwqjGfkz9STx8LcTQQN6GN8LXWZ/oCiCcpl6gEIWlIigiK0FOWvhBMVASdvKFIFVCEGpWe0AjMCzDPZqb9xJeLnb9tVlngv03xmCDVKM6LwTWhA7tL6XJ6I3ziCuq4mT9dskNrDATXLV370VydgRgj9kGGHLJngK2eRBnHlEtlQh2xs6mQnqCdkIESC4O8z+BSG0BrQxsm1vTzCnu5ENuXgSf2iMsqbOCCQBpUhpS61dvoNLEZkQOqkleDpnNkMVxT9vCZEfk+0Emvwrr4i2OYHYZQWq2FNcjVgvI8XZbULdM3Mj3/rKSG2FPmTNn1m1x20zwbNXk/06oSPOjJKtrY+Kg2SrLeSr23cZaXQxE4wYUBeT2zNb7CCb2ubhAz4fX9n1bHoHRp3IBv0hzSCbpf3k38y9DmAiYIYe9xHH0OedQvkLZMt2NFbL4bkx2LSfuXwhs7Ul9ThMNqryMHiWlNoFnQfh3dVS5NrqR2wPcq8lM/ZrnXYaiYoD54YjIAvphM4mQW3NOFeDp5ETe7bc1BakUQ3Iaz3fWHiT2VCVn2eQzUo4fC16clez3kO2dUgaOjzuIlsAHft6T7i8LuxunX1M+shWGcrObkP1CJNcqzzFpBH/BqCS2cT/3CJuoOLFIiUgl0NC+eC2y0jqJBvbQ2o8rQOxFJMtXl8VR5vjP9sULPc='
_TARGET_BITS_PAYLOAD = 'eNq9WEmSwyAM/Pdc9DQeMgeeoKMOKvCMcVLxosZgRJRUUjbG0JJaCz9LWNbvKlp+w3b5vniNxPOIIRENLPn/Y4qgGeEz9STp8LcTRgN0GN+LXmZ/oBCCcpl6gKIWlISgsK0FPmvhBMVAqdvKmoBVFEGpWe0ATMGzAvZqb9xJZLnb9tVlngv03xmCDVKM6LwTXRA7qL6XJ0I3zsCuq7GT9dskNbDATULV370VKdgRsj9kGGHLJmQK2fhBnHlEtlgh2xu6mgnqCdkUESC7O8z+BTm3BrQxsm1vjzCnu5ENuXhkf2iCsibNCCQZpUhuS61dvoNLEZ4QOrUleDpnNkMVxT9vCREek+0EWv0rr4S2OYHYZQWt2JNdjVgvI9nZbXLdM0Mj3/rKSGqFPmTN31m1x20zIbNX4/06uSPOjJKtrY9Kg2SrLeSr23cZaXQxE4yYURcT2jNb6iAb2eaRAz4fX9n1bHQHhpzIBv0hziCbpf3o38y9DmASYAYd95HG0IedQuULZAt2NCbL4aUx2LSfuXwhs7Ul9TRMNq3yMHuWlNQFXQbh3dVS6trqJ2wPda8lA/ZrmnYaiYoD54YjIwvRhM4mQm3NOFeDp5ETe7bQ1BbEUQ3waz3fWHiT2VCVH2aQzUo4ci16Qlez3kO2dYgbOjzpIlsGHft6j6W8Lu9unX2M+8hWGQrObqP1CBNdqzzCpGH/BqCS2dj/3CJtoNLFIiUgl0NC/uC2y0jtJJvYQ2Q8TQOxFJMtXV+VRpvjP3FdRD8='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_affine_mod_probe_mod17_a11_b7_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
