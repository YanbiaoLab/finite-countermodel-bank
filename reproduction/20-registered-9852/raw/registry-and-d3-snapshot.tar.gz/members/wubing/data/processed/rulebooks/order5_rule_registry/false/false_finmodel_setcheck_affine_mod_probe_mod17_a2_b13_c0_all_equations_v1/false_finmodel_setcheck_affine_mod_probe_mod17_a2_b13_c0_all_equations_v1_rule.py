from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin17_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin17_explicit","model_table":[[0,13,9,5,1,14,10,6,2,15,11,7,3,16,12,8,4],[2,15,11,7,3,16,12,8,4,0,13,9,5,1,14,10,6],[4,0,13,9,5,1,14,10,6,2,15,11,7,3,16,12,8],[6,2,15,11,7,3,16,12,8,4,0,13,9,5,1,14,10],[8,4,0,13,9,5,1,14,10,6,2,15,11,7,3,16,12],[10,6,2,15,11,7,3,16,12,8,4,0,13,9,5,1,14],[12,8,4,0,13,9,5,1,14,10,6,2,15,11,7,3,16],[14,10,6,2,15,11,7,3,16,12,8,4,0,13,9,5,1],[16,12,8,4,0,13,9,5,1,14,10,6,2,15,11,7,3],[1,14,10,6,2,15,11,7,3,16,12,8,4,0,13,9,5],[3,16,12,8,4,0,13,9,5,1,14,10,6,2,15,11,7],[5,1,14,10,6,2,15,11,7,3,16,12,8,4,0,13,9],[7,3,16,12,8,4,0,13,9,5,1,14,10,6,2,15,11],[9,5,1,14,10,6,2,15,11,7,3,16,12,8,4,0,13],[11,7,3,16,12,8,4,0,13,9,5,1,14,10,6,2,15],[13,9,5,1,14,10,6,2,15,11,7,3,16,12,8,4,0],[15,11,7,3,16,12,8,4,0,13,9,5,1,14,10,6,2]],"priority":746,"rule_id":"false.finmodel.setcheck.affine_mod_probe.mod17.a2.b13.c0.all_equations.v1","rule_key":"false.finmodel.setcheck.affine_mod_probe.mod17.a2.b13.c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt1jsOgCAQRdE3xoKSJbgUlsbSFREa8JfYqPcUkAyJBZI3Y7ptlF93q4sG4YecYtoCNwHgGbZ0GGkKZYk5ZUrQ5LSJ3BOAgznVclC4FCTN6STzTamP+QYA3jdG7ub5s2Pk1jr89QZiO1/y/LmP2l6B6xyl2nBaqg965DIBAADwBTOQ6AbP'
_TARGET_BITS_PAYLOAD = 'eNrt1jsOgCAQRdGlszSW4hIoKYzzFBEa/CY06j0FJENigeTNmB4bFdbd6qJJ+KEolzbPTQDow5YOIw2+LC6nTAmanDaOewJwMqdaDoqYgqQ5HWShKe1jvgGA942Rh3ned4zcWke430Ds4EuBP/dR2yuIO0epNl2W6oMeuUwAAAB8wQy7iWpn'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_affine_mod_probe_mod17_a2_b13_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
