from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin17_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin17_explicit","model_table":[[0,11,5,16,10,4,15,9,3,14,8,2,13,7,1,12,6],[7,1,12,6,0,11,5,16,10,4,15,9,3,14,8,2,13],[14,8,2,13,7,1,12,6,0,11,5,16,10,4,15,9,3],[4,15,9,3,14,8,2,13,7,1,12,6,0,11,5,16,10],[11,5,16,10,4,15,9,3,14,8,2,13,7,1,12,6,0],[1,12,6,0,11,5,16,10,4,15,9,3,14,8,2,13,7],[8,2,13,7,1,12,6,0,11,5,16,10,4,15,9,3,14],[15,9,3,14,8,2,13,7,1,12,6,0,11,5,16,10,4],[5,16,10,4,15,9,3,14,8,2,13,7,1,12,6,0,11],[12,6,0,11,5,16,10,4,15,9,3,14,8,2,13,7,1],[2,13,7,1,12,6,0,11,5,16,10,4,15,9,3,14,8],[9,3,14,8,2,13,7,1,12,6,0,11,5,16,10,4,15],[16,10,4,15,9,3,14,8,2,13,7,1,12,6,0,11,5],[6,0,11,5,16,10,4,15,9,3,14,8,2,13,7,1,12],[13,7,1,12,6,0,11,5,16,10,4,15,9,3,14,8,2],[3,14,8,2,13,7,1,12,6,0,11,5,16,10,4,15,9],[10,4,15,9,3,14,8,2,13,7,1,12,6,0,11,5,16]],"priority":665,"rule_id":"false.finmodel.setcheck.affine_mod_probe.mod17.a7.b11.c0.all_equations.v1","rule_key":"false.finmodel.setcheck.affine_mod_probe.mod17.a7.b11.c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq1mE12xCAIgNXHwiWLHoCjcDQ2vXeb+WnNKEYC0r7pTGgUhA/IfCdOx+8h8Hjl58f3h5eGPjVPNadGqHlfSqvJvz9Dqc17aRU8uvhc+fSnEdQUctK3At3dA1fShytp6gp0CtbuGJj6YQwrrgxuhefO0ClIs+vlCqnm5bNjoPxv7W0FUE75dE11f3pnlzgiK+vU5JCsh70TOoJXD8tBbm1GSynSpAp5XIMBiZqIxtGqiAb1ULirIzbB+RH2XDIvxWQGM18Q3bCF9/c6bTNIzZLNK85ErdIrN9yAzVow4f5mlOY5DUktwQ7Y5ngEiVhUxbsbLha0BdjSKmyGM66OlGSVasIULlUrUeIoTuqJZUs8vfmpjyI4nZOCYeP4oE1mTKLumMlrk552APFFpWiWk70WXKYsX8SzboPtqkP70ybPWSRLK1w+Yl7FI2KMXOvEh0lfLtjEMD3UvzHyXgTRPNP4Oluxhd4DxLuzkX0Ui4WtOjqb1fYd5Z/2jMIL6PIlK+7OJsZj88yS+MJtx7FZLN2QJGxZFDfCVuJ9a2BDvDjNGgnb6PuBGgwbTDnMkekiF35QqGt4sSrsgK2MN6Jo2NRUkOgH7b9tsnKEvA22c4RkQ9UitXKUcYzFB5uhHrOzToq69CJ55Q5sy5MKB8Cm+VF3wMYKGbDgF9yDjTsVLjSDaoItK0/sxzWsj+Vyc+kzx/AubJ2Kg4dzmGckhTYe0TMT4+c91HMNw3vN+5mtdBF5FOTHl4T473cZRheMsNWxShbrpr+zDZ6oS59UthHiBxfGLBc='
_TARGET_BITS_PAYLOAD = 'eNq1mE12xCAIgO/dDUfjKBygC5YueGqb+WnNKEYC0r7pTGgUhA/IfFWsx+8h8njF58f3h5eGPjVPNdZGqHmfc6spvz9DSc17aBU4uvhc+fSnEdYUcNK3It3dA1fqhyt16op0CtTuGJj6YQwqrgxulefO0ilIs+vlCqnmlbNjovxv6m0VUU75dE11f3pnlzgAK+uk6pCih70TOoKXDssFbm1GSynSpAp5XJMBiZqAxtGqgAb1ULCrIzbh+RH2XCIuxWQGM14Q3bDF9/c6bTNIzVzMK85ErdIrN9yAzVow5f5mVOc5LVUtwQ7Y5ngECVhU2bsbLxa0BdjqKmyGM06OlESVauIaLkkrUeAoTuqJFUs8vfmpjyI8nZOCYcP4oE1mTKLumMlrk552IvFFJWuWk70WXKYsXsQzbYPtqkP706bMWSRLK1w+YlzFI2KMXOvEh0nfLtjAMD2kvzHyXgTZPNP4Olu2hd4DxLuzkX0Ui4UtOTqb1fYd5Z/2jMIL6OIlK+7OBsZj88yS/MJtx7FZLN2QJGhZlDfCluN9a2BjvjjNFAnb6PuBFAybTDkskekCF35QqGt8sarsgC2PN6Jo2NRUgOgH7b9tinKEuA22c4RgQ9UitXLkcYzBB5uhHqOzToK69CJ5+Q5sy5MKBsCm+ZF2wIYKGbLgl9yDDTsVLzSDZIKtKE/sxzVOj+VKc+kzx/gubJ0Kg4dzmWckhTYe0DOT4+c91nONw3vN+5ktdxF5FOTHl4T873ceRleMsKWxChbrpr+zDZ6oc59UthHiBzS6RR8='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_affine_mod_probe_mod17_a7_b11_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
