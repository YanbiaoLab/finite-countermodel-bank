from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin17_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin17_explicit","model_table":[[0,7,14,4,11,1,8,15,5,12,2,9,16,6,13,3,10],[8,15,5,12,2,9,16,6,13,3,10,0,7,14,4,11,1],[16,6,13,3,10,0,7,14,4,11,1,8,15,5,12,2,9],[7,14,4,11,1,8,15,5,12,2,9,16,6,13,3,10,0],[15,5,12,2,9,16,6,13,3,10,0,7,14,4,11,1,8],[6,13,3,10,0,7,14,4,11,1,8,15,5,12,2,9,16],[14,4,11,1,8,15,5,12,2,9,16,6,13,3,10,0,7],[5,12,2,9,16,6,13,3,10,0,7,14,4,11,1,8,15],[13,3,10,0,7,14,4,11,1,8,15,5,12,2,9,16,6],[4,11,1,8,15,5,12,2,9,16,6,13,3,10,0,7,14],[12,2,9,16,6,13,3,10,0,7,14,4,11,1,8,15,5],[3,10,0,7,14,4,11,1,8,15,5,12,2,9,16,6,13],[11,1,8,15,5,12,2,9,16,6,13,3,10,0,7,14,4],[2,9,16,6,13,3,10,0,7,14,4,11,1,8,15,5,12],[10,0,7,14,4,11,1,8,15,5,12,2,9,16,6,13,3],[1,8,15,5,12,2,9,16,6,13,3,10,0,7,14,4,11],[9,16,6,13,3,10,0,7,14,4,11,1,8,15,5,12,2]],"priority":668,"rule_id":"false.finmodel.setcheck.affine_mod_probe.mod17.a8.b7.c0.all_equations.v1","rule_key":"false.finmodel.setcheck.affine_mod_probe.mod17.a8.b7.c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt1jsKgDAQBUBXUqT0SB4tRxc/jWBC0EqdaQJJ93jLJgYAXmTej1x5HqPnapOKNHluWjt2NPNctUrxOnoXYoXrYbueo2gvjLb0uyBzLcdyO0f7lI98I1P072S1BwAAoNsCEc4FFA=='
_TARGET_BITS_PAYLOAD = 'eNrt1jsKgDAQBcCjezSPZJkiuIqfRkhC0EqdaQJJ93jLJhYAXmQ8jlR5nqPnapcHafLctHXsbOa1apXidfQuxArlYSvPUbQXRlv+XZCpluNwO0f7lI98I3P072S1BwAAoNsKOrJsIg=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_affine_mod_probe_mod17_a8_b7_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
