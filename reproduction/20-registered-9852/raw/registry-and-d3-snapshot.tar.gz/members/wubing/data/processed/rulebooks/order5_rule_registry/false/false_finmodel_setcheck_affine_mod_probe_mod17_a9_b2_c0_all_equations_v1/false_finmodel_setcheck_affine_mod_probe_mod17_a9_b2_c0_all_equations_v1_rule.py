from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin17_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin17_explicit","model_table":[[0,2,4,6,8,10,12,14,16,1,3,5,7,9,11,13,15],[9,11,13,15,0,2,4,6,8,10,12,14,16,1,3,5,7],[1,3,5,7,9,11,13,15,0,2,4,6,8,10,12,14,16],[10,12,14,16,1,3,5,7,9,11,13,15,0,2,4,6,8],[2,4,6,8,10,12,14,16,1,3,5,7,9,11,13,15,0],[11,13,15,0,2,4,6,8,10,12,14,16,1,3,5,7,9],[3,5,7,9,11,13,15,0,2,4,6,8,10,12,14,16,1],[12,14,16,1,3,5,7,9,11,13,15,0,2,4,6,8,10],[4,6,8,10,12,14,16,1,3,5,7,9,11,13,15,0,2],[13,15,0,2,4,6,8,10,12,14,16,1,3,5,7,9,11],[5,7,9,11,13,15,0,2,4,6,8,10,12,14,16,1,3],[14,16,1,3,5,7,9,11,13,15,0,2,4,6,8,10,12],[6,8,10,12,14,16,1,3,5,7,9,11,13,15,0,2,4],[15,0,2,4,6,8,10,12,14,16,1,3,5,7,9,11,13],[7,9,11,13,15,0,2,4,6,8,10,12,14,16,1,3,5],[16,1,3,5,7,9,11,13,15,0,2,4,6,8,10,12,14],[8,10,12,14,16,1,3,5,7,9,11,13,15,0,2,4,6]],"priority":667,"rule_id":"false.finmodel.setcheck.affine_mod_probe.mod17.a9.b2.c0.all_equations.v1","rule_key":"false.finmodel.setcheck.affine_mod_probe.mod17.a9.b2.c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2DEOgCAMheHWMDByBI7C0Ti6xmhExcLgoOT/HNTCRHxYVQFg0+UQifUhkbRehbJUmwa8JG3nfBtxxuyOqQCu8UlmDgNp6hPtfUf7X5sTi4kftpFitJHeNUt7HsLnAuCec6l9nUfk+QAw+DebP/8sOG60USo2yMxqAgAAYAAzEYAEDg=='
_TARGET_BITS_PAYLOAD = 'eNrt2DEOgCAMheGjczSOwhEYGYitxmhExcLgoOT/HNTCRHxYFQVgk+VQDfUhVb9exbJUmwa8xG9ndxvJxuyOqQCu8fFmDiNp6hPsfUf6X5sTi4kftpFqtJEpN0t7HuLnApCfcyl9nUfg+QAw+DdbOv8sOG6kUSo2SMdqAgAAYAAzOwBtKA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_affine_mod_probe_mod17_a9_b2_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
