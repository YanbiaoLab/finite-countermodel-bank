from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,2],[0,0,2],[1,1,2]],"priority":366,"rule_id":"false.finmodel.setcheck.bank.enum_order3_1527.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_1527","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWc2OozAMdhArZecUqnmAgFhpHgNVHMqe5pE4cKC3WbQPsI+6tgkhKabTCs1llE8VFDvJR/yXylXwCF6hVgCNbkDlkPDleJ/4Nl2qKosU/cT2/2hPRXHrIprT16SlMVXlFDY36Dagaw+ZBgMW6CtAyc8Wr06Lw/Ar4JALqjV9UKiVxjHr2GUJwKGWbgZQinMTEhISEhISEhISEhISEhISEr4tfl3raRwFBXeqqI91bodRF8VZl4fJ/tV/tv0vBhOdurYdR1OUFZIdb1f+rbdtOEZDRJfqStuqqrbV5XCYrJ9aWlXQMFFXF7QtMmU5mMNs7xOvKmiY6FrTttiUg8kOs/0+0dXSqrFCEAkNzudc2nT8whgp7c14QSQ4+DmXvnF/XGi+CqKGzHDJmGMxgGf3ru+9W8xZ37RWf6yrUs+38dsRREzUfcpRLBSb/HTt40xTy1flQfdXEKncuH6yE0ZN5aXvvKjnKTAr+QGGYFXr52qQRGLjWuBwap4CTkkP0Jtg1dzPxTcSREL/XOTwpgj3RdY12bpqZCLRakTU+L3uciymCPdl2Y/BqpGJJKutDr7L4U0BsfOWZBOKiZBZgsiVmU2g7yRb50uU2hZk+FT03EE0J5v9SZVDhTkjZJYgWg9FIdsHcxaTTYi1h8JGdtaaiXEWuGQTYu2xsJE5fCbGWXDnn6u5Tm5+PvQ7vyj6+bzd2O7mZNuLtZ2X2HkvMPN5i7F5h+2FnS4U9kDmA0cQ3S/OYKPTt9Hzv3DbEoXeydCZ3kdaFLnx2eK2BiJlECfkQK3I6VKs0aoYNb5SKFEkcITKIE5ou/8BHi+owg=='
_TARGET_BITS_PAYLOAD = 'eNrtWc2OozAMftR9gBW7t3LgwCPNaegBVXmMlRYBDzAqOc1EWkS8tgkhKabTCs1llE8VFDvJR/yXyrXwCN6gsQDKKLAjJHw5XjK+Zee2nSJFmbH9f9fXYbh1Ec0pG9LSmLZ1in7U6DagawmTAQ090FeAjp97vDotDsOvgEPOqDb0QaGxBsesY5clAIf2dNOAUpybkJCQkJCQkJCQkJCQkJCQkPBt8ffUZHkuKLhTRX2sS13kZhgupjtM9qP5te1/MZjoWtV1nuuha5HseLvyZ7NtwzEUEZ3bE22rbevadMVhsjKraVVBw0RVM9C2yJRdoQ+zvWS8qqBholND22JTFno6zPZ6pWtPq8YKQSQ0OJ9zqar4hTFS6pvxgkhw8HMu/cP9caH5KogUmeE8McdiAM/uXV96t+iLuWmt/ltXpZ6v8tsRRExUfcoxLBSb/HTt48lQy9eOQfdXENlRu36yE0ZN5aXvvKjnKTAr+QGKYNXezzUgicTGtcDh1DwFnJIeoNTBqqOfi28kiIT+ucjhTRHui6yrp3XVyESi1YhI+b3uciymCPfVsx+DVSMTSVZbHXyXw5sCYuctySYUEyGzBJErM5tA30m2ypcouy3I8KnouYNoTrb+gyqHDXNGyCxBtB6KQrYX+iImmxBrD4WN7Kw1E+MscMkmxNpjYSNz+EyMs+DOP1dzndz8fCh3flGU83m7sd3NybYXazsvsfNeoOfzFmPzDts7O10o7IHMB44gul+coY9OX2Xmf+G2JQq9M6EzvY+MKHLjp8VtCiJlECfkQGPJ6VKs0aoYNb5SWFEkcITKIE5ou/8BLlHIZQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_1527_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
