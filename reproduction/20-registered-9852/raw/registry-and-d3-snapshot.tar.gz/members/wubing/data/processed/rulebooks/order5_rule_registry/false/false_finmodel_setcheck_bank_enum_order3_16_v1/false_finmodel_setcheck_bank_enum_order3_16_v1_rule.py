from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[0,0,0],[1,2,0]],"priority":367,"rule_id":"false.finmodel.setcheck.bank.enum_order3_16.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_16","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgDhy4yMowCgYpqGEU+CHPgUXiwZ/P/Xrf8rHI/OeM/TddnBFTwgBMajEwCOBPDy+MFrZmOHk4sIwG/ygYBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBMAe8SOwZPEgcgdGwGQUQ8O8/nPnn////9TS17MB/eSZo+msAWvafn/hhbjLAD6CP7EEWsYNshvmQn0a2AY1mNWBoOPA/ABim///biwAtdmBgYKaJZQtUN94tMzbedjsvrU1lcmeHgXFx2rszcwyPSTB5KClQ27Y/9iAfHQfF2I+n9T/F/+eD+Ob/62nhOWCwyQPT4c//04E2gEH7n+7//1/9X0+LgPzw/8d/sIX//z+e/v9p/J/9P4HM+3/+89Ims/23/yjoCLTIFZzZKgX/A5kd+i1Dvxyx+I8rzwv/r6lFnc540Fm/b99o0TsKaAr2MXD84Wd5UM/IwaDwwV4AVNMw/fvP3MDwYT8DCwN4Xg5YPjP+/8/oQIWa7edz+dg3920+nr8+vb5kY/3nr0f/8V4UPvYvfd6P569P2++6sf/nr6T/bS84k/8bU16z+b/4tH9Px//5PzoWnP7/SaljnoDtz//+J9SP/PevcbnwFFiwuPh3zPvzX/2JMBMDtvlHDhJsAwAWQuKR'
_TARGET_BITS_PAYLOAD = 'eNr79/////r/xAF7vV//R8EgBc3/3rM/+I5FQp6Zp+Ai5wQsMgzfFjFmvPiHKXEeTF79//89/vQgfjauavre7ft/jwb/KBgFo2AUjIJRMApGwSgYBaNgFIyCUTAKRsEwB5+Q2OmfkTjvR8NmFEAAIwOcyczAwNBAU8vsGR78haa/eqBlDB+IH+YmA7ADfXQAZNEPkM0wH36gkW1Ao3+d/19vz7AeGKYMDAdeAy3e////H5pYFn/LT6nzzBlPlYkzK2/nlJWfP9MzU9A4+Zzl87/b796ntm3MB0A+sgDFGLtUA9sLhgkg/gmGBlp4DhhsD4DpkI0hA2gDGFQwlzAwiDIE0CIg+RnYGcAWMjDIZDBILWB2YAMyFZgZPtEmszEc4Hu3D2jRLnBma3vHAGSWX6ge+uXIcQZcef4NQ3MT6nSGfFmDo+No0TsKaAoc/39n/vBbvuHf9//3+Q+8B9U0fxkZ/tT/53f4//s/eF4OWD7/Y2D4t58KNRubxINFwgqH+Qw0Mhq6/Rp4uKwYP+m9sWSckcguIWJywFXdgY11LkOl+Lc5DGcor9k2iPM6OJczJLCXx5sw8N4tT3x/iI1hg/kNa4YNzbv1pYAFy+4N5YnMDDek3/z9j23+8TsJtgEANj6Olg=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_16_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
