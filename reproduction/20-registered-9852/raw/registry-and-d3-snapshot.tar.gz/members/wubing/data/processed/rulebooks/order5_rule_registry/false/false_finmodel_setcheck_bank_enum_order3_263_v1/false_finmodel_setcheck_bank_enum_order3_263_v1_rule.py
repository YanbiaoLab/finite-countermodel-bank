from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[1,0,0],[2,0,1]],"priority":368,"rule_id":"false.finmodel.setcheck.bank.enum_order3_263.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_263","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZECAFl4GGgHGBl4FrBIcDCoTGLFJHOB8ML8+jWEUDGbggIhUxtHQGAWjgF7ggHwCiPrz/79sw///6swF7A08o6FCBnigOhFE/fudn3as7PfZMx0SAsa0s20OKxOHAsMB8fg7vD8ezd/NaMyQxnCGQYKZJpY1/D8izMjC8OP///+SQGz/uP7Y/x5JhuTRSB8Fo2AUjIJRMApGwSgYBaNgFAwZoJCDTzahmfcd32ggDT7ghF/6BlUtc8BrnAODtIjIaIwQldkYBPAFJBMnVW1jYRDywBFjQOChwMjAwAjELCyjETMKRsEoGBSACVo+YU6CNWBRTeFoL8gmDqiF6EU1JvCg0GsWjA4LuDkYODBrSxYuTNUcFNoGAJy8NeQ='
_TARGET_BITS_PAYLOAD = 'eNrt2TFLw0AUB/AnFjp3t3RwcLdTccjS72HBXQeHDhWuq5OCU0Co3yKTxM2lH0B0iIi0Qi3FqL3iNe+ZQKFgYhDTSIT/D44b3pE/uUcukLAsdXzJCSvfSyxouTvgpII1rbW6tkCRucumMnYD4K9Y971oWid6UEQ385OZesWu/ELtdj+a1kqnduO4tF1vDyf9/NL2PgLtifV0semXq60m98WWugznuYQp2nlmI2UiGoTjaqPboMOBnKPpAAAAAADwb3hnadXekV95wSYVz2V6eWulYW7q5Vx5HI3QkR89bDJJ28hgutI0I2Pnm46FHI9FOBzGoDEAUAjB4nyK/wRTCaszfu2NkvQi8OtRHedkvLVrdnfftOj429K8x1frjGmfr7U7Ug=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_263_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
