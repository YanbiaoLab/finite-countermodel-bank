from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[1,0,0],[2,0,2]],"priority":370,"rule_id":"false.finmodel.setcheck.bank.enum_order3_264.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_264","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmcFOg0AQhhdCFKOmLDUela6YvkIPTUuaNZZ40JtHPfoImjSCCYk0HlRi1INRH6Xx5NE3UBsfQG8cjOsuWBNbSquCkWa/A0MywJ8ZmGEZ9kTwyUURxGIAwI6eAafgm2zYRIh0bJn6McZSr6NltUmxgkAS2KKhgkyx1kmPOPQp5Q+70+241gMjHeFuT+eW9KRfCbbyYFGt51p/RWk1uLPWpe8CTlawiTVHjU8oK3RnE4kpqj2TfWaY2PyIJbJFiCVMgVcWG2utz6lGWLpnXdqp0mI7wiqECGHsukpNTqXqFw90zw2FvDpCNey4MoQ1uZCG2AO5WqdCbzSNlmoGYcEComJSGmoX1uV2e+Emv9rA2+3moTwPK6iB/YKTTrERQoWCYiPVF/hIyLJzKFcdhTcizugTLmdbrNh4MjKDYaIJaoIXDlu5KlDgSeFwOBwOh/NQjlsSGGfW0xJP0v9jN9Yr+RtJirXIeJw3T6zsfhTk4t1PiS6Yr3XYx8PGCAabmdjJqZ3oXj1yJmioggTqqMlGQSKQhhlOD8T2Yt1C38h/hCLKWrQniEWQNPaDJSkGzFXtDPeRcPQf8QREfurLIxZ9VrG/Nem/k7IU21ynYwzzpGm534kZZmgirhzRBuq//IX6UT7Tsz2RjU32PfoLt+B8aLV3XeuBdA=='
_TARGET_BITS_PAYLOAD = 'eNrtmcFOg0AQhtd46E0fwFR9A4+eTB9FjQc1Bu3BiAmJYEz0ETzq0ZseTDFuGmp66Cs04pZ6NJalUSMaAusutSYWSqmCkWa/A0MywJ8ZmGEZ9lzyxUqdRKIRwo5+JOtkSE5l4IU6jkv6JoRO0FFQ8qB+g0gSyK5mkkxx3k2PG/uU6qc97HUs6r5xtmCvp3tLAum3/K09WNQIXOuvqF34d1ZZzomEkxVkoNxTkwOUS7pzgtwU1SbBLjNMrDliiSwAoHjPZJzFxlrrZKoR1mZZl5YqtNi2oIkxQhCKolW2U6n6221dEDtCgopQGUqijXHZbqQhNgOWzqjQGE2jYpb8sHADUTEnDbUVZfkof7fQujiAR/mdot3EN+gA5hpSOsUGABXyiw1UJvA0AFdS0a5IFm9EnNGns5wtsGLjycgMWgm9UuO/cNjK1cIeTwqHw+FwOJyZatSSQFtTpq55kv4f+5FeJ3eapFgBvEV5W0DJ7kdBO9o9leiCeVHHfTxsjKCxmYmcnNqGLqihM0HN9Byioh02CnKJE2c4PRBZiHR7fSP/EZZrG+EePxbPMdgPlqQYMFeVM9xHOqP/kCcg9FPfHrHos4o81KR/zslSbPfdjhHnSTPavxPTSh0TcuWQNqD+8hfqZ/k8PQQie3/pe/Q35slqbLUP7obvsw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_264_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
