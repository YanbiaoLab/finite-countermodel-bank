from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[1,0,1],[2,0,2]],"priority":365,"rule_id":"false.finmodel.setcheck.bank.enum_order3_291.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_291","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNprZGGAA5lYBrzAgYGBCUiZMDDM4GEgCcQzsPxjZ8IikeHpYTSzgwNT4kC90/T/T10ZqAEagH4UZGQYQuAClPZhI1qLDpS2RPfoAgUwxTKBxQFNBqaSBd0sBRhDgIClChhm0QtY/IczP/TrfctnGAVDADT8r48D0Q+MGBj+A4E8w4ET2jSz7cP/dlj6fgCyjRk5wQ5tcOD//3pGHgaFD/YiDSCv8bM++G8vwHCAVplNZaKLC4uniqDgR1Bmc3Hp6BAQVGwRYKKFbardKpM6OhQ6VZSU1Ca6HGnp4BAUVFJqEXCihWUP/s8PFxIUVNnp43IEFJDigoafvFyAlnHQwrY59fMqHik36e060f3DXfy3+SelJ64nugXiORhpktn+//evcbnwtL5SEOS1+Lgj/4HMR9yKowXRKBj+AKk5W+Ekvkh9NESGAnDo0lACNz0FGRo6lLgUWRgUWgRGg2UUjIJRMApGwSgY6eDBH2Z8svKxb+6PBtLgA3Z4RwtYfsg7UNGyA9dZ8ckK/xe2ZRyqAcmNX/oJCzUtW6DCiCNeQK1yByFPFxcwjzpDQVNUBDyYsBnlIMTIwuCh1NnBwcDIwAS0U4Fyyxqa8EozqjBSs+MhwITLzeChJkYWqCx1kiWB6GgYwuWIxS5EqKFHGUZlwBnbMW9Y+X6oggY2UlSTOsE4sEAMmvowkl8DlpSmoI61LCW60HZwhFCYZZMCZpZg8mDCUuiwEF/TQo3kFcOMT26cqlHACYYZRNsGAPYriqA='
_TARGET_BITS_PAYLOAD = 'eNrtmTFv00AUxw+BVDGUDGytKjN265ghg6fyLVCpkCgSojCEHlJUbAmJrmysaSZGpIoE9RRcOlAkVKQKJArGcSSWVDRnRAOmvfoednBKiR03ETbgcr/lXfQu98+9e/d8vtxmcMCHEkSiATiueQEwswMDUQR24psT4rhfrqxfxnbQIavVK2hkGeJAcedIOaSICd8u7fb9lVe+fdY90Smzbdh1pnV5Oj1Z91hmp2EdIWoGxvpTrKGDZubGxul7IEgBClIXPSutAyCXOsjZ14mpZdCtTn5Lntr+4YRNNzJCKt8BM7PyUfGm9mlPQisWyEltNn2WEFbWKT3jbTZCMLZorWA5Sai9y+vXMDbndMN4O0tyBWxTahgFq5qEmIQuPmhSqp9fIjkvkA36cvgRccXsJNQuqdMLY+/nNyaz+aHHjVPPh43R5WzeKto8kc2G0MM7ZGJEvUu9qRUXc8htjrVqohAJjj+HjrML1caFTRGRNKDdfGO0j54UFGx8qTEwC5YIi0AgEAgE/zvSyf0ob7109pwI0r/H08jbAjZU12IUk8f3orzbaHuVpzWQrWj3KItTbErnPdbFO5VrzTIh7U/xXAVd1a2KEzaU1uQMKsYctoGD42qavy+mzEe6uc7jfPGwnF6/uX3VxJnvjSctj1gOJcV1ZG3yZ9S6lyzwMPhawtPHavZpRdkdpPegfzD+Xbb87AuknxKSaeZmaC3tu2hrT36YYG0yg1vCqTghRYf1/6T1h/y8FVzPVs/ev5CFmb7VvgNWRuaH'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_291_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
