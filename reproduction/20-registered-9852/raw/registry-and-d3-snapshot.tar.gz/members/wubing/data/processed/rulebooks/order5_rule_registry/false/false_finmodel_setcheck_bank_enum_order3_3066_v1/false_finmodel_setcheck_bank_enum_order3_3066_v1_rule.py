from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,1,1],[0,1,2],[1,1,2]],"priority":362,"rule_id":"false.finmodel.setcheck.bank.enum_order3_3066.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_3066","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WU2S4yoMBsoLssM+AXF5qvoYvBQLp1dzJOdVXlWyy6TmAHPUBwLzY4STTNqtRbpjGwuJT9In5T+idkQRkN/wqbiEL8Pd/KN2ciKMNGQQ5s4OHmxIRf5U7+ynyo2P49Aq7IZXjAgj1HzK8sZPNvZGz7ERixuTUIQ2hJs3LtaeQQVsgNsPGkwZfumube9j3x86s/ZyEWaZffDHdbhfLjdtnmXWQQReymZTpoFxAnf73qgkIpjSCPsss5f8MvIJm5XXcBfeZLzoLehGs5rR1JQO/txU1y6840yZGvNpzXXvmU0x35Gz+QHb8QdMSHpGvJm/M/JBwTd2U7nXJ3insioZIYp8p3zQ79RWxe8W4g/sm+Q3wPibZEpibXupJoRN5GByjMCj6evFJ+mgaFsLTWr7pfU5JL6Q2jaRaobdMNig1uWJfrtgS6uRBctG4TB1YBHEAEBzduUm4tFAkZjfQD7hEypnLrcNUuccbK5Ep8HmTvNrM9rMI4pgU91RazjNtv0y2DgOgATbFrCRznU55wqwkRm5RGCjXg22ENW51wA24OQL90QJgc1rmaBe2RqMwhbymnvrVNfSz4XXrAMW59AfXjnStLLlNFUVsEFItoOvTI9U1F2heI0tI8G2BhtER3mYnCaK8kdps+gJkNKebK7UwSs0Mo8BkjUfMoPN9NAOXgeQdODAvAZRXXhNPK+jJIymXYReCVLU9cLbtu+15vuzvA59D/TBXTyLww1aK7svffawMcHW7vsD3zcxSgNIzRLhNkS9X+46KDLZ0q60r9+fReApwl0UB34PFZfMAR11hNyWgZQRd9P55ec9KrLGaA2vP4t/sRxdZptgh/GH1xHyjtnfP8EuOIDPLihaeq0SbFmOTu0IzWQC0mgXIPDYB0WI13JCdIz0trQj0TG7IrVLrdJIpLI52GQ5Om4uLgwAskhLD2+FRiKVDRTl2SbqiO4OAMrsoqs0MnT48fSREUEaCAVIDdLSwwuzmae8dgv7WtWxEmxdwldzrNVydBZsgeM+F2yxsi2wBopUeJ0gGI9+EAj54VkaSfEBzCbBtovEw0LA4Nk/ukmw0ago91pXeg2ZQIXNJTpiIJBFsFWpxE0xN8eKMkrz9K55o2erru3Gnil21Mml3dDSt+Yb51rrqdjOGnPipCW9r4un2Cf8FWG2lY2i5o3yygmUBmYimZP9yiD2eRoJOEAEvHYaeqLJhQgqG4wjvSjVwa08GUsGkcPGnia308V5g5fAhNontpAE20KGm26mko+rp6kOIlUaicxjK1mr5Mo08Fj1JI30XpOJ10ZJYtZyomczUx0yuoIXAxJ8Er7FRGamkYWLED7+/oDEBVssOKEIVvj44zbucbDRIrEjl9CGJMm+j0Fa/WkB7WLwhqSmo6k05khiF6PPk2mOXv6oYV7tQ1LpGZNTfbzoR/9YYueW3Z14mqOPumzEeK1Bq47+kcRuEMkJH3yFrAXb9BJe6r/VIJ5/OxDcNBJN7A4oTWw/355rTykf4A8GJMsO/i8qW+QDjwYk7rrqxKPh1dqAhHhQh6zlLFD+f5XDwFxnGQBfYCi2ZzOrESuQHC1GxqBPMPHUUrYsNs/8zmZRj4wMEBppgKSIkrvA/SmqY8XP/wPR82CB'
_TARGET_BITS_PAYLOAD = 'eNq9WU2S4yoMPuo7wFQmu6RqUi8+0qw6XlB5HKOrxuVwAptdWLiABwLzY4STTNqtRbpjGwuJT9In5Zemd001yA/4pILBl25n/qF31mipJ91xc+cOD066Iv9U79yayo3PSzdS7IZXjIjUynyy8sZv2fZGz2XiixsNp1pNWpg3LtaeQAVsQNgPFUzpfpJhHHdt318Hs/Z45GaZffDPodsdj3tinpXWQRpeKmdTmk4KDXf73qjUPJgycfustJf8Mv0Bm2WHcBfeZLzoLRhas1qq1JQB/uzpMC6840xpJvNpzXXvmU0x35Gz+QPb8QesdXpGYpq/S/2pwDd2U7nXG3gntSql1lR/p3yq79RWxe8W4g/sm+QHwPibpElibXupJoRN5GpyDMej6evFJ+mgaFsLTWr7ScgpJL6Q2jaRaobdMNig1uWJfrtgS6uRBctG4dAMYBHEAEBzduUm4tGgkJjfQD7gEypnLvsNUuccbK5Ep8HmTvNrM9rMI4pgo8OFEDjNcfwy2DgOgATbFrBhznU55wqwYRm5RGBDXw22ENW51wA24OSj8EQJgc1rmaBe2SaMwhbymnvrVNfSz4XXrAMW59BfXznStLLlNJUWsEFItoMvS4+U111BRY0tI8G2BhtER3mYQiWK8kfVtOgJkNKebK7UISo0Mo8BnTUfLINN89AOUQcQc+DAvAZRXXiNP6+jJIymXYReCVLU4SjGse8JEbcTO3R9D/TBXTzx6x5aK7svcvKwMcE23vqruE0xSgNIzRLuNqS8X3YkKDLZ0q60r7+deOAp3F3kV7ELFVfPAR11hNyWgVRqd9P55fcuKrLGEAKvP/F/sRxdZptgh/GH1xHyjtnff8EuOICPIShaeq0SbFmOTu0IzWQC0mgXIPDSB0WI13JCdIn0trQj0TG7IrWLrtJIpLI52GQ5Om4uLgwAskhLD2+FRiKVDRTl2SbqiO4OAMrsUqs0MnT48fSREUEaCAVIDdLSwwuzmae8tg/7WtWxEmxDwldzrNVydBZsgeM+F2yxsi2wBopoeB3XGI9+EAj54VkaqfABzCbBdo/Ew0LA4Nk/ukmwqago99pQeg2ZQIXNJTpiIOhFsFWpxJ5KN8eK0jLz9H16o2errh3aXlJ5Icmlezeqt+Ybp1rrSeXdGnMWetS9r4vn2Cf8FWG2lU2h5rXsIDSUBmkiWejbyiD2eRoJOEAEvHbuek30UXPFJowjvSjVwS07G0s6nsPGnqaw08V5g8fAhMYntpAE20K6PZmako/Tp6kOIlUaicxjK1mr5Moq8Fj6JI30XmOJ11qmY9ZyQmYzUx0sukIUAxJ8Er7FRGamkYWLED7+/oDEBVssOKEIVvj44zbucbCpIrEjl9CGJMm+j0Fa/WkB7WLwhqSmY6o05khi563Pk2mOXv6oYV7tQ5KSGZNNfbzoR/9YYheW3Z1FmqMvpGzERK1Bq47+kcRuECm06HyFrAVb8xJe6r/VIJ5/OxDcNBJN7A4oU2w/355rNykfEA8GJMsO/i8qW+QDjwYk7jod+KPh1dqARHtQh6zlLKD+f5rDwFyXGQBfYCi2ZzOrESuQHM1bKaFPMPE0KrksNs/8zmZRj4wMEBppgEQ1ZffA/RWqY8XP/wN6fhC1'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_3066_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
