from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,1,2],[0,2,0],[0,0,1]],"priority":372,"rule_id":"false.finmodel.setcheck.bank.enum_order3_3809.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_3809","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWUtugzAQHY+8mO6mUQ9gISr1GG7FIrmVs0t3FeoBetR6sCH83EgVraJk3gJsDAMzb/x5xsAcPp2egH2qWLg/fNVHQIBWykgxChQLTmrGWAb4GIcqXrwx92lS4XPZrKWKQqFQKBQKhUKhuC981u2+qt52USDs0RCwycrRvddV5UIsnaQWRRV8WGRRlwgNyJ1RRpxOwCK4IJ5c1hVVbA7JCPavCenYNrtD0+w7ReLGTTbEhy0HsZP1yU5eJBouiHypRNuYkYyxI9M8c4qV1y3xAi7q5lB3wcZMq0hNL2njO3E5pM1DPHZpE/q04ceeazcoz8zqhMhcf+7446VQp2xjmjaQ0ma4Gwty2M2ccsqrQnG7KG5/+jQ0bLr3F2SqWm0hGWhMbYZRbwMwlLYujYy+g+s6D14A5SgizDZFQwofLtLGhR9ZOZtbI6cwNaUncfIB1LN5Ef7uWCtTQH8wtTOex5Mw62w86mwD9ewXndMsVx0FarG0jHUl1+n3EfNHBwcgKmQVbvt7hNjGQJg1z0kXZFfb2fAV2n+bSdiRqL5iOyoh14hvg0soQg=='
_TARGET_BITS_PAYLOAD = 'eNrtWUtugzAQPWoPUKHsml19q2SBWh+jUhHyAap0dp2FNZ56sCH83EgVraJk3gJsDAMzb/x5JvAcNp0+GGyqeL4/PDTPTMyVlAljFDAWnNRC8MC8G4cqXrwx93FSgXM5rKWKQqFQKBQKhUKhuC88NtWxbV9OUSAcKSBDyMrRPTVt60ws7aUWRRXvPIGoS+Ka5c4oI/Z7BhFcHE8u64o2NptkhPrXmHSs6tOhro+dInHjJm/iwx6M2Mn65CQvEg1nRL60om3CSMb4kWmYOQXK65Z4Yxd1s2m6YFOmVaSmlbSxnbgc0uYrHru0MX3awGfPtRuUZ2Z1QmSuv3f8wVKoY7YxTRtOaTPcTQU57GZOOeVVobhdFLc/bRoaNt37MzJVrbagDDShCcOotwGAS1uXQUbfwXWdBy8AcxSJZ5uiJoWPFmnjzI+snM2tkVOYmtKTNPkA7Nm8CHt3rJUpwD+Y2oHO44mZdTYYdbaBerCLzhmWq44CtVRaxrqS6/j7iNlnxwdGLGQVbft7BMHHQIQ1z1EXZFfb2eiVq3+bScChqL5iOykh14hvySZI9A=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_3809_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
