from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[1,1,2],[1,1,2]],"priority":371,"rule_id":"false.finmodel.setcheck.bank.enum_order3_393.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_393","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWcGOozAMTRCHdE+A5gMCYqR+RoRygD31kxipK9FbB+0H7Kdu4qQtQ5wVVXEOq7GqIhqoeYmfnx1+McWZYmBv8K0EHH63cDJk9pAze6a4quAkYn9iA6yODRyHyIB3jFjGOD5wYj1+z1goxtGnPrNMSBRK+6mrskRG3i/tPE0oFHOPzjEozaVtGuSWn9XQliUCp3CHqg+gOIRXXYVQYDyvpgAKOEAe7v1gvyX2cGIJ7DGv8vDlYZgyAwo++S2IEtkxqbc6pTO/YInM8TyRjUmjJJoQSKwzOaZI5UwJObJk4KKpjcSiGZaGbLFET0O2uW+aROs2zroatE4EzYd+otT1A5EjQrLBIS9UGrLB4iXigKsBrmk4IF2U2PhX6ypjf3tjs3VkKyXQAVKE4wIRB6gJlG24cYCW5U7ZQHAsB0aLMGM5FdkWjjJhIkYy8Eligj8cKQ9LMCoZrxeOhIfFqWRc5gtH3MGSZPWXU7bOCk7fXCZRlk2jtajPhMoGjmwHVTedPk/GGcnCneaHI9sraT1NRWmckSyc6wnBkS26zm4qz0VHQjbXmoIjKziFm8qiI8nMrowERyA4fio7QVI0uDISHEFouqnsBEkv58vIOwf8VIo6/ybbN9n+f7JF//Rqt4jCfazXyBYdmU1ZpKphV29RUqnsoFkvP8SuZIsljDst+J5ki43cabEjtujGrfwwoNurQS/YXjW64rHmsP3MbXdlOlbDv52yiisjsfW0+7GGAyVrmGYT2yWNuTISJ1tpyCYzlcNU7pHG4hskFGIX3SBRBGIX3yChEDuvbP8i245iF321IAnEzod+LwN/RZj5ETGQTOfbO7zjbdZCdAMSNsi6T0+k7PqWopoANF//DSIGvsMTW8kWe1cTCRv+Gtm27zTJV8VgXNQDXw1BasVgfZW5rNjMwtOjHlg9Rvi6A8QAiZDteLtHPbAKfxVoHuTo1VWFlEpt3c/3b0aRZIKkTuSn5wpB/4I2jDUVpk7sp+e6rr+aFO1S'
_TARGET_BITS_PAYLOAD = 'eNrtWcGOozAM/dT9gBXTW5G20vBJPS0cIpTPqDQI8gEj4LTNAZFs4qQtQ5wVVXEOq7GqIhqoeYmfnx1+aa4012Cf8M0lHH42cFLO9jBpe8YV7+EkYj9iA7qLDVzKyIB3jNisFT5w1hV+TzFyrdCnPulZChRK88b6YUBGPo5NlucoFHMPmzAo7bFpW+SW333ZDAMCZ3SHvgqgOIQH1odQYHzq8wAKOEAe7uNqvwX2cHIJ7DGv4vrlYTQ3Axw+0y2IEtklqbcupTO/YInM8TyRFUmjJJoQSKw2OWZM5YxLUehk4KKpjcSiGZaGbLFET0O2rGrbROtWZKwvGUsEzYd+otT1B5EjQrLBYRp5GrLB4iXigKsBDmk4IFyU2Pjn6ypjf/vUmXVkKyXQAVKExQKRAqgJlK28cYCW5U7ZQHAsBwqLcNYTFdkWjmZpIkZo8EliUj0ccQ9LaioZ7xaOpIelqGRcTAtHysESZPWXU7baCk7VHnM5DG3LmOxOhMoGjmwH1bU1O+XGGcnCnbOHI9srMZbn42CckSyc6wnBkS26Tm4qT2NNQjbXmoIjKzijm8qxJsnMrowERyA4fiprSVI0uDISHEFouqmsJUkv58vIOwf8VMpu+ibbN9n+f7JF//Rgt4jCfazXyBYdyUxZxPtyV29RUvH5ynQl3uWuZIsljDst1J5ki43cabEjtujGrXg3oJuDQS/1XjU6V7HmsHmbbHdlOlbDv52yiisjsfW0+7GGA4NuNdO53iWNuTISJ9tgyCZmPsFU7pHG4hskFGIX3SDhBGIX3yChEDuvbP8i245iF321IAjEzod+JQJ/Y5j5ETEQmk3bO7zLbdZCdCUSNsi650+k7O6WotoAtFr/DSIGvsOTW8kWe1cTCRv1Gtm27zSJV8WgWNQDXw1BasVgfZW5bNzMwvOjHlg9Rvi6A8QAiZDteOtHPbAKfx5oHuTo1VWjEJxv3c/3b0aRZIKkTuSn5wpB/4I2jDUepk7sp+e6rr+yXYPV'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_393_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
