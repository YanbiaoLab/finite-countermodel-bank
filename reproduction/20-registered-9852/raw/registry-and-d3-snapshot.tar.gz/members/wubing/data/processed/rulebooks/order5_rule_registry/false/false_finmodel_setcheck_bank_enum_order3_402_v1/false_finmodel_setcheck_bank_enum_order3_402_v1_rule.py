from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[1,1,2],[2,1,2]],"priority":376,"rule_id":"false.finmodel.setcheck.bank.enum_order3_402.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_402","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmUFq7DAMhm3jhWdnh3eAxLjQY5jBi6SrHikDeZDs0mEO0KNWsjN5NHagofYsHpNFSxAZRbI+6bfzl1lKbEfwuhn8u7lh+O8PwTtLLd7d+LUlqevTfLgqaXm5mGpMGV47eMbx2GA7PRmtE4+8sc4knbxfW31KGfqrrU4uZcFQ6t1QlEqFMpnrOGYKpeqMUjQRSkhj1bIoFO9gtlUcirfzSkSheAdmjjLw4rNVX/jWiyT4I/cfeiW43D0mvf72rj2xGN4aZj3BO5gP63qTLoOMF2abw0vBWsyuuLdQv7NjikLBsLLOltqDatbnqnOurLebWR21ehpFUWeeREJafRkJUlzrMy/nbWkIyFgzgTfnkuBmurAvSQoMaAYM8F4QRTQZyjjzsLE7bCORqmHgU5aDzblhgU0prTGV8ixoEdim1ZEvTTeMQqmzaB4BG4SlGg3O+CNgC6kUzVAGNrc68gyEVDZDkSp5r1pNETYp/Rwoe+HkpKTGuYpzoOzlYdMIm+13dExB2ApPtu+wlR1tnyBCwAOM0NrPAYCNlvOGsDFiAwPgDWF7wGTrl8lWMpXxZCsK23882U4+IlMJgeoOwuKge2Up2EBGCpSRFGUksW4QhBJWEDZ6h40jbKRe1fpzsh2C7e4IB84iEgZZZOHCnrAJk80F7aP1IM9lYNOrI5wDMqQSlN1TRj5l5BO2J2wHJlvS4E+qYGugc8OWtFR3wZcTNr5z5GMZTNW2nsb8sCUs4CgIPpodtoTlZGTYXWWWkUlDfTHhfLIXeWFLWszMSc+voPLyZTLIyNR64nnsbPMqyyAjk7CB4KtQWfKeZFKW+yfhQHWADQGoc042tgebH3YQFieiPGwnowiC3z8EtgvXxPkKyZLK3U8L/rjfzBZhoz6VOWBbshZ9fsHdR6JHb9+J2AOv8dotWdtGl+j8lnWJXzjSsV/omrVNjeBWf1s2l6jGkMMDsO19q0msJtbnL2FbW9RmPeLOn0jAUdj+6YFNQ/6wNtGjfwnbTq318dc7GAbR88fayxtbW9SmIeNWP9GjYyp/zuHySda3qC1sUevEHp0HNvkT2KIEQFjjgaH3BbMLRsY='
_TARGET_BITS_PAYLOAD = 'eNrtmUFq7DAMho/aA5SZ7BJ4gcmRumqyMIOPUahxcoBH7N14YWxXsjN5NHagofYsHpNFSxAZRbI+6bfzx1DraO/wemX4d3Nj8N9fh3fUUrx71afBpa4XdiZz0vJ5YXOTMnz08AzRsYH2vGacJx55Nz1LOnk7DfyWMnQnOt9IyoKhTLuhCJEKpWanpskUytwzIWwilJDGeTBRKN5BRec4FG/Xs4pC8Q5YFWXg02druuitF+nwR+4/9OFwuTtM+vTtXTtHMbw1zKmGd2BnSjqWLoOMF2Zbw0vBWlSkuLdQvxUxwkLBmLLOltqDaubXuSekrLdXtjoaeN2oos48ic4N/NI4pHjiV13O29IQkLGxBm+EJMHNdGFfkhYY4AYY0J1ywnHXlnHmYTN32BonxWjApywHGyHtApsQnGMq5VXZIrDVqyNfmqRtlBBXNT4CNghLjByc6UfAFlKpxrYMbGR15BkIqRzbIlXyNg/cImxS+jlQ9sLJad2EcxXnQNnLw8YRNtrt6JiCsBWebN9hKzvaXkCEgAcYoZOfAwCbLecNYTOOBgbAG8L2gMnWLZOtZCrjyVYUtv94st18RGxWCtUdhKVB98pSsIGMVCgjLcpIR0mrnHWmIGz2DptG2Ny0qvXnZDsE290RDpxFJLSyyMKFPeEYJhsJ2ofzVl7LwMZXRzgHZEglKLunjHzKyCdsT9gOTLakwZ9UwdaA54YtaZnvgi8nbHrnyIcamKrDVDf5YUtYwFEQfDY7bAnLjcmwu8osI5OG6cLC+WSn8sKWtLBKu06fQOXly2SQkan1xPPYiuZVlkFGJmEDwTejstSdy6Qs90/CgeoAGwIw5ZxsZg82P+wgLO1UedhuTDgEv3sIbBfNHfEVkiWVu58W/HE/qyjCZn0qc8C2ZC36/IK7j0SP3r6Towde46NfsraNLtH5qekTv3CkY3/aNWubGsGt/rZsLlGNIYcHYNv7VpNYTazPX8K2tqjNesSdP5GAo7D90wObhnymNNGjfwnbTq118dc7GAbR88fay7tZW9SmIeNWP9GjYyp/zuHySda3qC1sUevEHp0HNvkT2KIEQFjNgaH3BZlmKnA='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_402_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
