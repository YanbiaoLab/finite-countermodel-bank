from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,2,1],[0,2,1],[2,2,1]],"priority":379,"rule_id":"false.finmodel.setcheck.bank.enum_order3_5318.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_5318","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWUtuwyAQBTSLyY7eYCr1ICx9LCJl0WWOXHBSQ2SgxhgnTuctokg4M8zLfB74LAJg/DQiB7eipse2AUqhc75qoXMLNrImH1a2DGVL3ENRgydCttkiGMOHq3FEKIzYlQUWFjJDz2IId/UmBWMLWKbgiMDQDnR/b59TmxrHTV8Q7NlPIESEb1ZsmsuksyTiyVZbbMuF5MGyd9/tqgqp19zWzM0R/DYw3TV7sSh0sUux6YrsbZls3EoZDAaD8Vagsi5SOJvhLToByvOc5OzMxUehgozM0nyd/wCZtBcoNh2kebrY7LzYzEplenEGKSW+jZIgBjoL8eESCfwqWf9N+2tt51NlCtXk70Gszu0Hydv8igv55miWkrj4LKLDs5Sw4cKLWJuOP7TyGPjHzZk9cEZivrHLDLkN0ctcYzcp63LNn/EvUJVxfhhYpi3d0LCCSzWQf4MIq28E7gl+chZ8841Nn9xeHtVPsti+K/TQD9P8GwQ='
_TARGET_BITS_PAYLOAD = 'eNrtWUtuwyAQPXKWXVQKx/KSg1TK3KDsMosRUHBSQ2QgxhinTuctokg4M8zLfB74bANo/JQ2B7eip8e2ARqrcr5qoXILIrJmHla2DGVL3EPRgyfCtNkCGsOnk3REaIzYNQUWFjIDr2IId/VmLGMLCKbgiMDQDlR/b5epTY3jpi+A9uwnFCLCNys2xWXSWRLxZKsttuVC8mDZu+92dYXUa25r8uaIfhuY6pq9WBS62KXYVEX2tkw2bqUMBoPBeCtAWRdpnM3wFp1A5XkOZnbm4qNQQUZmaT7Nf4BM2h8oNhWkebrYxLzY5Epl+ukMQkp8S23IDnC29tslEvlVEP6b8tfazqfOFKrM34MIldsPgrf5FRfyzdEsJXHxWUSFZyFhw4UXsTYdf2DlMfDJzZk4cEZivrGbDLkN0ZtcY5cp62bNn/EvUJVxfhgIpi3d0LCCSz2Af4NIq28E7gl+dRZ8841NX91eHtVPstg+KvTQD3h1VjI='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_5318_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
