from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[0,0,2],[0,1,0]],"priority":380,"rule_id":"false.finmodel.setcheck.bank.enum_order3_58.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_58","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWW1IU1EYvlv2oRRUzhwEpfXDwlJsP0oqNzKKghxSsSLcZKSRoJKKMTHvfkSZCiJFJpUzCoQWLkcZNW0SKq6ZFSKVpkjozI+g9qF23b1v52wiyd2y2PwT54Fdtp333ofzvs/z/DhXQFGUlloMTywh6Nr6OpQSUARLj3dN/TlGSb6Qt6DVfciAymahjLfittoZc60Yf127YCGddR5P+VHp/bHgiVKDldusWc4f/2MLvj48XZF6IERInUoURCHm8rwwTUFqSnTlfJls5MSN7WeRMrTrt1CryNQICAgICAgICAgICAgICAgI/mNkm741mUzPBgovTjfdnuz6PNAiyT9nq83vDl8CsqFRF4DEzAFt85yGFUmmASHBdmYpTqHc4GDML/uguqVmFtNIzIeULKjGY9fg1SATahGBpp1+MQnVCkwGI70AVYpkd7z34DUkqGzfHQxAjQpA6pgwwmHl3A7Fjp1BJvKAA1BNZcYZYELPYhomC2Di2tO34pX82rWBkrUCGEGlZHUKd72nkfJHtR8B7JZ6X9WBTnGmGu1I2ohoYm5+AFfbFyneoY47LPZzQ0CEAM2cwTAFGbk2Dm+ty1CFxFLNHF2GV4XBnVo66+yRQ2UJMwbv5YntUoYWwTYudQaS/Wo4ILPFz2LNIw8wnrG1jV9jIV5XHBZkov/fbEiS9nFo9koRaLWrDf0nT1ruo1gWIJmsP8dk6e4K5a8Y+xoa+gqv363R6wszGypO5VdcOJ2tUGTj8t6TeyWKQ48SO/ZEUQfnHhTyFzOd0aRNQWcsv2utaJrFaJpVilyvbK4Uowaok3C5frenAZHJ3gbM50vUomYzIrPFrODrYQaMu9UaViXfYevp1AMcuXSZpT9tbMTlGxznh5GWHiS98vVIoewPZvPzriaSddq/1t/5srllXxktsm8rhXvlJUUaT7lyU7s0TCNqg39MTXdz3Cw9HMFPjCF+11y0MkGHy3s3NhapAcqjdcIFQbYYt7ZpAOvAmmV6kdV/DImhoa/m+S71m4QOAf9+H7L5V7N5dACjEY4xj9nW6WOmwCy2b+cHhw/Z/JY2grnPH82WgXUwCdbB0hEXvb/xlnyrgYMY17oV/N76kI3AZ2j7y/FWZgzrIM3ZY72vyyujnXYUx533o7irPkbAl000Vnzdwqo6/2HqNZseHGU/Cz7BVsNgaW/4LKhW/xTxg2PIj9nmw3pRc/8C8rBSSQ=='
_TARGET_BITS_PAYLOAD = 'eNrtWW1IU1EYfu+d1+U+CvKjZoRkWiLSl0tJCZeuyGI2cYGQ5KwwoxDBr6IfuyWOJIsSjDJGm0SOCplBkWRsVpg/lliJ+sO0QJhlH1Bo6dpu52wiyd0y2fwj54Fdtp333ofzvs/z/DjXzXGcjpsP+1Oc6JqxfZJzcwSLj83ZcVdV9noXb0GnTWiCsiyXlbcikEsZRZEDf/02Z+EWLb7ftrzM+2POE21qOfVeP80f/4EUfD14p7z1qdPFtXS5RxBzxaUJ/cXWtuGy2TJr9L2T/TeRMnRf3nE/ydQICAgICAgICAgICAgICAgIljAalCuzlcq9sXUXlmUfC09eH5tpr78uK6rf+nkRyGJWiwDsCgpYmec0rNa+DBB6ZLcX4xRKABJGsSseSjKLQzCNXdFuosEY2fcdrwaZUIcI9Gns7nAoMWMyiE4EKDV3CHq9B6/OoLKtkDAAxUYAmyRCBY9NMzt0SN4EmcgDCsAYduO1GiI0NKZhGgEiqvZtcfzi134LlCwDQAVGE601C/I9jbTkFW0EkKbk+6oOdIrCErQjWw6iGTyRAKL0tTa8Qy312OHnhoAIAbIotToMmq7IKLy1ZHUpEksJ8/A3XnUFd2q3aHGSBcrOMVGwydKVZmPYcRigWoXQ4VfDAZmtNwRrHnmA8YwtPbKKhl5tzUSQiZa+2ZAkpZGQ5ZUisAZROvrP0jnto9gaIJk17qoyZWvyJH9FFZ+bG1936kixRlN3I7e8pb788p0Gs7kBlyfefWE3t+d17Xg5wj2ZeZDzP2Yq1DeHQWofv2sZaJo1aJql5ite2ZypQQ0wdOJyTbenAWMd3gbM5svIvGZTIbMNTvH1IARVt0FPGy1vZUmpGoBH58/S7IbRHFz+UXJtDdLSoc6dvh7psv7DbH7e1YzRYumq/KNr32c+r2THpQPVcLjiXK3eU276kGab0I+nwwJTU5D1OoRd84mfGDH8rolYU48WlyeO5tQaACqGta45QTYfty47FutA3qjc3Rj3AIkhN754zyvDtp4dbv79PmSzULN5dACrP0miPGb7qhkMA4VD2s8PDh+y+Stt3DOff5qtCesgHOTrqqNF7LOc45YhNQWDoq9T/N76kI3bZ2j7y/EMJgrroFmcJC/QXqpkxVIUx6kFI9RpHyPgy2YYK75wblWh/zD1mk0DksrQixtgSL2uOvFzCBh/hI7zgyPGj9lmw3pec/8BWcEe7Q=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_58_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
