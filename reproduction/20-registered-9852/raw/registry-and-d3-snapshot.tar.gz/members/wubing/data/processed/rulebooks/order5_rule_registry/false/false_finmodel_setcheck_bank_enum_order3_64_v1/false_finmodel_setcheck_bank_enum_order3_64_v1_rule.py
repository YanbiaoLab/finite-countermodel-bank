from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[0,0,2],[1,0,0]],"priority":364,"rule_id":"false.finmodel.setcheck.bank.enum_order3_64.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_64","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgDhw4xckwCugBJjAwKCgxMDCRoKWGUeCHPAdJttivP/1PvpIVU0IBxhDAq9/hacgUzRQWYAISUhqNs1EwCkbBKBgFo2AUjIJRMApGwSgYBaNgFIyCUUAtkPCWBcY84G7Zass0fLzW0IBgMzkgBuKGA/j3nymFlSHBCBh5f/7//1/PwODA4ObDSBvLDvyXh4cp0LL//DT1WgTTnxJBwYY5dUpMDQ5+wHhjOmLfpc4iQJuU+b+e8R+7wAd7JgbGf0Cv2TMC08n//4wMLDTJbC8VGlkYmIQ8GBQOMFsy2gKTpAtDB/GTBoM5s/2vj/N0cZnwxEhQEJRG4l2OnNAWFHTiUKSFbRe2ndJavcNrsm9ZUtbmk8d8eudIGZomZXEsV6FNZpv+9/+nV//3PLL/C/JbfdLXI0AxfzvWIR9tEdbElxkPFs31kmNkGAUDn9mApZMgI0MHeIrKBVJUNQg4YVesBC44BSERp9AiMMj9to+B4w8/y4N6Rg4GhQ/2AqCykenff2asReSPeAYmsHJgod0ArJoGeR3/ozL22/8Tq/9/7vpZcvO/8vp7HVeFf/+P5/kpgiWz/d+TZAdWbg4ubcSdSS1tAGCLkes='
_TARGET_BITS_PAYLOAD = 'eNr79/////r/xAF702//RwE9QP7///fv/v//lwQtzf/esz/4TpItBwJMGB+0/cKUuA9jvMerf7/U6uxrs38DE9Dbu6NxNgpGwSgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCqgF5gv9hjHtdxyrOvR3+Hitvh7B/rsfMRA3HAAjw9/Zv/7PPwuMPGYGBoaG///3/9+5+R9tLLNneAAPU6BlDB9o6rXlf5m7372rT268+7d+/0ZgvP21PlB64/d72qRMhoZ/jD/e8x/4+/8fI9BrB/4B0wkDw7//v2mS2cTu1/3+//ft9v/37f8c+3cImCR3/y8nftJgMGc2hoaF23bvzpc+++4dKI0s2G1tfuXdu73f79HCNn1P06sh7ltzNnXOnepjZrm5KPnpuVNzp36PuE2bzJbBxMAryuAse4AJ5LeGuVzWQLENB38N+WhbfoT4MkM+Nmnrw3//R8HAZzZg6fTu3/9y8BTVbkhRVf9+L3bFd8EF5ztIxN2vfj/I/eb4/zvzh9/yDf++/7/Pf+A9qGz8y8jwB2sRyb7g/1+wcmChXQ+smgZ5Hc/etoiTwTyEgaeUrVuN4U6AYrnWGxaGBZ/ZXmPJbAzOcw+ClZ8AlzYv9pBa2gAA6+bfPA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_64_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
