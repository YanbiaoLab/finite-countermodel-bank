from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,1],[0,0,0],[1,1,0]],"priority":374,"rule_id":"false.finmodel.setcheck.bank.enum_order3_742.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_742","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2T9qwzAYBfAnJ1Blit0LxBE6RsHGaMiROjWieEi3NuQAOUqO0iN4zFCsWkNIjawhUEFK3w9jG/nPw+b7NNgCgAX9eV/Oq8IDR71+00pNXLIAVDZ1r2f0AngBntAJSDm3qC1yyBwZRIYakH4ph3NLv0tERERERERERET/XO8ilgnCTrEwJxKknWNhVYoXGX20hwRhR/1hHotiWJtW73e7vFirxrR5k+Sz70HvN0q9+qB3H6uUMUNmIwX7536d3Mpv/C+IbdjzVVi9q9GIvW0mOLvZ5aJl2PPjHvj0Q7PRUJd0JqAI+6MOwhL4bd21DiZKgO7UN6+ZwAc='
_TARGET_BITS_PAYLOAD = 'eNrt2U+KwjAYBfCIC5c9gkfxKB5AHHe6EMm4miPNIhQLHiNEvYCtq4mgzZtmMYwlzUIwoPh+lLakfx4t35dF6wBI0MvrC68ID4z1bq6N6bjkBzB1172+0HPAGtgic7D2IrGRqGAr1HA1NoD1y745d+93iYiIiIiIiIiI6M31RMQpQdgoFiZcgrRBLKxI8SKjj3ZOEDbWH+pYls1aLfV0sajKncnVssqTfPad6Om3MSsfNPOxxijVZObWsX+e10gc/Mb/gvgMe74Iq/fQGpH3zQQDcf276BT2fLsHhn7o2hrKks4EFCFv6iAsgUfL/uugowToSf0CnNixIA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_742_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
