from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,1],[0,0,0],[1,1,1]],"priority":375,"rule_id":"false.finmodel.setcheck.bank.enum_order3_743.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_743","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmE9qhDAYxV8cYdLVxLnARLG3KEwYXOiux+mitKHMIrMr0gP1KD2Cyy6KaaJ1YEYLA61S7PdbSMxneP55eR/IcAn3IKakssvhgrbb31O5vgqFHircoWbAA3CDin2/XueBO6pchfTFCIIgCIIgCIIgCIIgZo5tWE0j9taqsWnUPhqx7TRiun205TRqVatG9iX+I7rM1kWW5cnB8CKNojjZZXvD470YQ+22bIS4BAMLJRQ03HAO/85f7aZLysfTSt2PTp84m6HQu7SBvNtFt2h1dhu96GxaxWIo9KZrIH+Wl1QoBMrvAQXGvRsD50cJeUiTRGo31u2kwHO2jiJ/eedbDmOE3zI8DgW8nd0kvmztTR3AXeMm/DnErF9kbfumPvPakR+3dlXsjql1WnEBkzylpTFy1CAbkU/xlpPl'
_TARGET_BITS_PAYLOAD = 'eNrtmE9qhDAYxSNddOkRepQeqEh3k8VQ0tJFj9OdLmTIQG9R0cwFxsyqGXDMa6J1YEYLA61S7PdbSMxneP55eR9ocQnPIKYkZPvhgmDr31N5/6i0GCq8ILDAE/CG0H6/XiS1O8pEVvTFCIIgCIIgCIIgCIIgZg5r2E0jdtOq2WnUrhqx9TRion20/TRqYatG9iX+IyJKt3GaJvmCmzgryyJfpUtuiqUeQ+01aoSMgoWtFCQE3HAO/85v2aZLysfTStCPTp84m6HQu7SBXLNDt2h3dhu96GxaxWEo9KZrIH+Wu0xL1NLvAQlrvBtr50cFtcjyXAk3Fu2kxn26LUt/eedbA8613zKmqDS8nd0kvmztTV3DXeMm/Dn0rF9kwPqmPvPakR+3dhmvjql1WnEBkz9kEedq1CAbkU9a291C'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_743_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
