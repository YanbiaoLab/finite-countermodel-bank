from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[0,0,2],[2,0,2]],"priority":378,"rule_id":"false.finmodel.setcheck.bank.enum_order3_75.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_75","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZCAGiIBJBwYGJoZRQAcQgEui4TMLDpkaKP2fGU1igQojiFJowNDCCKUxjBRg4ACSHFAehG7AZqnCaFSNglEwCkbBKBgFo2AUjIJRMApGwSgYBaNgFIwMwEpPyx7YMNLRthqGf+x0s6zhs4uQp4sLnWz7MP/H/85+DjrZ9u8/ftn//+2pZ9mB//J4ZYGAirH6g+EPP/1SpDx+aeo6ZYHKRBchQUEsMgIODAwOVE6tU1QmeSgpYZ1lACdTqmb8hkks+KQ9VQQFqWifABMHljF4MFAAESxUTSMEJmoaqGqZAySYPDbwostMwlQslMOM1f9EAwt/SHrA0HVA2L8GPTEycVDoe5yZ7Yc89XM2dK6G9omRAW+KU6C+zxga6Dp1WDCPnrbZkdR6qacws3kyQZI/RipmAZXImGU0RQCafXjFMOKTjRunahRwggTbAMkINrE='
_TARGET_BITS_PAYLOAD = 'eNrtmTFugzAUhh1lYInUI+QYHXOEHiHtXFF16upKHKBDD9JMZGCgVYYcAkWwVi1QRZXclsBrAC/Fxk3Eq5e+b7CFfuDH+H8WwhUcwkvThgAlEBZ46BP4pOhRPNmzXUeYR1XdxVy5pJK9csscxL4V8qjtuc40pqkiCIIgCIIgCIIgCIL4H3zZNJuuKotuHow+rJnxSZD6QWDJ7eTcYTfXwpLbiJlVxh7xzGYsMap7EGfVgfGbvUQmZhn3UebRVZBmmUbJQ4AQOa2XkbvcbLS7DE1MUQufu4VJ9qMsQ/TLS6H5B98Q102BmpFfNmo4qlnYvqbl2baruOrJ6f1OO/6DWS/aPChXzV4XXjeMpRg4+t5icxL8ypZ7NX8fRjAmLsYfGXCrW4d3Fzbdno76erkdWGx+2cZfSXFRr8jqGj0IWT7bZ2U+P997z/7B6RFu34NpOoU='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_75_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
