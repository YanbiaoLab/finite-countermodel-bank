from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,1],[0,0,1],[1,0,1]],"priority":373,"rule_id":"false.finmodel.setcheck.bank.enum_order3_767.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_767","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmbFOwzAQhtsSITMg7AgkxsYyUtcqUlfi4CFGQupAX4CB56iqDM4GEQNsfYUyMDOx8QS8CANS8AXkDjEVEk0l1PuGKL5T/Mtn3z/E3c7vSXSvg2yC8VN3bXPNxa0KGfNkTgpRGuNJUA1PsmdWzzwVkishRSiT8LDHcNsQBEEQBEEQBEEQBEGQtTAXi9dRHG9I7aMCTrHsyHY2W/37uMw4T0OtlDGURTwlUdCG2p1wQhkvDGGMc6VIlLchNi2VE9KCwbJUbqwYbUNtXC6FCgHLqkuZ01YuVc5DJ2Q3EJYFpcxp+v9P5EDXhWwmEtjNGzitrrb1SfqTWu3+1UEz8V412EG7+LnZHvfd+1t2db3rRmJxMTlqfvA8Ku8fVl6DXU6G8ZnKhy/H21TIRHPoao9reTzaE/p2npTIL1ewsWXSzmKbBpJ2IGkgBxrsI2i6lsejE0/Io+GS/ZzOrJSNwYDM+uQTvGmLuw=='
_TARGET_BITS_PAYLOAD = 'eNrtmbFOwzAQhiMx8CI8ARsTMwN9hW4woMAWD1bV52DgBcpQCQlnMElYK0VdK2E5HZFAsREDFgpt8QXkDjEVEk0l1PuGKL5T/Mtn3z/E88XvydhsgWyC4dF8bXN1xTkvlfJkHiIREuJJaAZP80ZWz9wXqeQiFWWalc8zhduGIAiCIAiCIAiCIAiCrIWu6OyP8nxDajsBcI9lR7az2erfx2EsZVIyzgnRqpCJKao21M6EE4plRIxSUnJuCtqGWD/kTogJBcvilFgx3YbaMFwKRQKWVZeS6lYuVW5LJ2Q3EJYFpaQ6+f8ncsLqQjYTGezmBZxWV9v6JP1JrXb/4KWZ2A0afKBd/Nxsx6/ufS++unx3I9G5GTw1PzgchacnK6/Brgfj/I7T8cHjNhUyYxK62uNaHo/2hL6dJzHplyvY2DJpZ7FNA0k7SHWVThjYR9V0LY9HZ56QR8Mlp1T3rJSNwcD0puYTkAjlbA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_767_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
