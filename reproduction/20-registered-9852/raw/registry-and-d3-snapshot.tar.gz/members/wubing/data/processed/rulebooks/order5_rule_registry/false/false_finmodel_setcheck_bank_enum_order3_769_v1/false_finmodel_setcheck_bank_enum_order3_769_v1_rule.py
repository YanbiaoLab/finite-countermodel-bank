from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,1],[0,0,1],[1,1,0]],"priority":360,"rule_id":"false.finmodel.setcheck.bank.enum_order3_769.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_769","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmTFugzAUhk2DVG/BqHuC5aGHqARGHsKNOrUkYiBbEvUAPUqO0iMwZohCbSikLjYSaq2q6vsWxLMfv+H9NsPzEEK5j4C/zrlWxD/yrEd08RB6QugBVR66z9heiIIdynInQkIoFaIsgxSvGaeCcRbyJLy7IVADAAAAAAAAAAAAAAAAAPi/XGoLcwdiR5tY7TlQO9nEYhcf0vpqt2Ay4Bc41gt1US2I5+Gej4fuXWiRfNpJcKpnXdJ8uOf1PfCmQjMtVDk9Cb7HK9urDsthRWkaZk2bhUQ0xZGfMUKiLfvovZCoCDbDhgwXRYkJkfOvie0wjoqlTJFzZEzd4M0Sv7BeaEW3KrObqoSapk8bLIJ0169rVKMdlquTKWpBclDe+Dzw1598oFvAYBtLNb9w7go5zK6umboFcovNmhN8TCx3+ruaQJJRVZ6mYo0r+m9usI0hNOoWrXKyarxt/hnsZ7BNYghNc+Q7oKg8iw=='
_TARGET_BITS_PAYLOAD = 'eNrtmTFugzAUhokyZOQIPUqO0gNUSbYwoIR26o3IYGGQeogOlkn2CpPNlUhxbSikrm0k1KKq6vsWxLMfv+H9NsOrhRBRJYC/ztxTZD/yrEcxq4V4EOJJ+LV4jskaoZCsgmCDCsYoRSgIyoTvCaaIYFLgtHh5Y1ADAAAAAAAAAAAAAAAAAPi/zDwH5wnEli4xr55AbeESy6b4kM5XewWTAb/A0jupi2pB3Jt7PjPde9Ii0biTYOFduqSzuef1PXCjQhct5E96EnyPW7JWHZbVgdKkiJs2C8tpwvMqJozlW/LRe2F5WO7MhgxGYcAZk/Ovie0wz8OjTJFzZEzd8N2R35Fe6EC3KrObqoSapk8bDMtk069rUKMdlquTKWpBclDeVLis9p98oFvAYhtHNb8w7wppZvvXTN0CkcNmzQk+JBZN+rsaQRpTVZ6mYo0r+m9usY0lNOgWrXKyarht/lnsZ7FNagmNc+Q7q8k0qw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_769_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
