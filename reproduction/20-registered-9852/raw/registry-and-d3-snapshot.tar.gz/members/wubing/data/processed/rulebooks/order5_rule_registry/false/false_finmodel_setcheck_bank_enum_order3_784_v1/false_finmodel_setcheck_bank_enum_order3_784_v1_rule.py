from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,1],[0,0,2],[0,0,0]],"priority":381,"rule_id":"false.finmodel.setcheck.bank.enum_order3_784.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_784","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgBLacZBgFdAQXtt3O22RcjCnR8Pm8/a4b+xkxZZZ0GnVp9AhQxfoN4OheFdkT6MSCR1mDAoMCi4LDaHSNglEwCkbBKBgFo2AUjIJRMApGwSgYBaNgFAx/kLv77bbdu7ffLSv/vm32mzN37u41Lk5/Nq/4HDMNLHvw//P5///r//1//v+8/f/b+3/+T/7/7P/+3/+taeG1P/v/Ae26/v///z+/3v7/GZ7//h+Qbf+snpsGljWAfPT//8//8//b//+TD/RW/9/Z//+/+/+eFl4r+Ff5qLOfY9cLJf1H8rFv7p/oniCuqO9Uo8jCAZJmZFFgcAAzqGLbrZTbvmVuOqvfvupINY2U3LjDK/3ZqQ7V4wJsNPDagYtPOWM75tks5L44Wb1EseqToGMcy0XhlgvutAhID2FXkUCOhR1KXIpTAl0SW5w4WgW4FEVYHAVoYZvmIpBFIoEuii1KXRotARwLBZwUW5oUOJhGC6JRAAFMLJBMC8zILMD8C+QooJQzVLXM4Xbe7pPnznBiymy6tW7drbLJc2euXl2Wtq4norinMDI3PDwXpPxqqLVxuNsay2MWDJBihkhg8f/P4u6/0ljyvPD/mtqf7uK/zePj39wXsE18U/+ss37fPpDy2ev1v+V3zDP4Zk9ijZS5qEeJSxnLNEhHxiIhJ0lXETeNJQEdwBzoaMDiahLIuRCkXCRI4wgwWypINI2mxFFAXeDgqcTJosDEodDZwOCpIiioqODgwgLMzy0MkzyUlJyEOBxYOjoYBEH5XXGo+Q0Aav3e9Q=='
_TARGET_BITS_PAYLOAD = 'eNr79/////r/hIC32f9RQEeg76ky0fdMD6ZEPY/BAVd1h3+YMtFlZ0uvF7+nivX+4OgOXVa8bu9vPMrq7/+///v+/tHoGgWjYBSMglEwCkbBKBgFo2AUjIJRMApGwSgY/mCSi5Cni4uHUmcHh2eKsLGyktOZnhmSiT2Gf2hgmTwDjwEDQwMjgwSDwQEGFQc2hjkMkgwOLAxHaOE1ZgdGoF0aDAwMzKxCDGwrJggwAtkHJBu+0MCyepCPGBjYGBIYDjAwTwB6q4AphYFBkEGAFl7rZ2yTLSv47ip+94Lsg0XCCuYl+S/uXdjbfO/3d5D0v9/3/+8HM6him+pslU2dOy+HCImWzzq17Jmf+9YZkqbltyze/6SB1+z1pL4tKk88HPdFL+dG971W3nf7Fv7We1Otv4MWAbn9za7X677Hld/9ei973e551Xu/V73/eu/1733vaWHbtViQRa/X7b5Xfbf0evX673Hv996rrr3//e9oQTQKIODvb0imBWbk38D8C+TcRylnqGrZfpWJLmaGxt8wZXxVAwNVO3OS0kJCOmcGFi/vKe5bNmnFikkg5VqrjpxZsTP4mOXx/5BihkhwnIE5poTpCZY8/4ahuYltxwuWEwsWCCu8PzRPuEGyrMHREaQ8JeAC54TyxPOcB0iskabFFt/9egfLNEj59Ni3e5/ter3zevT6cmAO3Hf+967T677FgZS/XnvdGpgt7z+vHU2Jo4C6YP+2u99+3//7/X5Z/f9tt9+9u3d//+7fwPxc/T93+927e99+3/+7vPz/O1B+vzfU/AYA4XSSMg=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_784_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
