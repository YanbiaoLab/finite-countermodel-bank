from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[1,0,1],[2,2,1],[2,0,0]],"priority":369,"rule_id":"false.finmodel.setcheck.bank.enum_order3_7984.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_7984","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmTEOgjAUhl9JQzAxpjEObDbRREZHxw4u3IIjeAIDiQODg2F28GgeRSmQoKUREmMA/2+A4S9t30sJ/3sk1JkTswhy2nkuj35AXK4lDWWhr2rOqF8IV9+cyAhlW+y4w1xl1Dx/mrffwXP1j4N4ldoWYwfNKl66/jhDu7JZw4sxCoTjyZgAAACAsXDIbFZ3k6Up8tOaIKwVCHUUMU6v9qHBSwjqr3W68Utu9zOzxAq5eD82azMBe47jAQAA4H8509GPGhVnMnQb6e5sDRLtEJzCCQ0RlXs3e1fSVGQy9iYmAACAb+NalcRSRN+HElrAuLA4AN1Y0H9OZfVV9RQpOfF0X0SVYhceasUYrA=='
_TARGET_BITS_PAYLOAD = 'eNrtmTEOgjAUho/i0RyciYMDgwnEE3gEbsHi0NHRERNN6sZgTGNMJKShTymQoKUREmMA/2+A4S9t30sJ/3t41Jmlsgj81nmuhH6AX67FDeWsr+yiqF+IVN+ywAhlV+y4w1xl1DJ/WrbfwXP1j4NkldoWYwfN0T+l8ThDm6lrw4sxCkSWcJ8AAACAsbB2bFZ377gu8tOaKKwVCHUYKUmv9qHBSwjqr3Waynlu9x2zxAqleD82BzMBG4njAQAA4H9Z0CoOGpXsPnQbmW5tDRLtELLCCQ0Rlns3e1fSVLg39iYmAACAb5NaFc9SRE+GElqkpLA4AN1Y0H9OefVVTRgxfk90X4SVYhce4axYig=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_7984_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
