from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[0,0,2],[2,2,2]],"priority":363,"rule_id":"false.finmodel.setcheck.bank.enum_order3_81.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_81","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmbFOwzAQhn8TpDAgYKygIn2ECnVgoh14kEyIoQMjQwXeeB0ewY/AyGjeIGOGqkcSZyEXR7awGNB9UnqR/taXs+93pFohhGOsmk8D5BD+gAsXLrdDQasumC+2ELs+UjYQSheeajX8SeGCIf4Ap8111N/PYNswb9P/GHzTPecSWEDLmgmCIAiCIAiCIAiCIPxrlE/4KDPgaps0WelVbveAfSuSZtt5FU0Ke1qnTKa9E2mrDLp4SVpa5c2GQ46KKGm2A02rlHIqDRWTakPC/7Jrv0QZanpNOpHTw7WlFWK2ELNNDqfbiTwXswWwceHxnZW4+mRf5ocaWOA+wowzF+Z8LzzjNY32p1Xh2fyHJJbbsFonMdvIWU1rtgHzsZeBzuPNxo6MOrOxLfOXZnPhhCthbXODh4hsSxdGJiOsba5NzEre+fohsG2aN0T4RmP6OrgS1jbPiFnJ2tcPgW0DG7PRfAOTbXgL'
_TARGET_BITS_PAYLOAD = 'eNrtmbFOwzAQhq/qkDFvgEdGHsGPwOuwGdSBkaEDYsqDMLRMDBXqIzQooI6AGIhE8E9SZyEXR7awGNB9UnqR/taXs+93pNoihE9s2k8N1BD+gBcXnpdDwdhD0EdsIRZ9pGYgFC5cZXb4k9IFTfwB3tvrq7/fQ3Wh6tL/GHx1eM4tsIORNRMEQRAEQRAEQRAEQfjXWJ9wUjTA0zJpssKr3M8BdVYmzbbwKoYs5rROmcx4J1LlDUx5kbS03JsNsxo5UdJsM5pWKeVUaion1ZaE/2VnfokaZHSedCKnh+tKK8VsIWabHM50E/kqZgtg5cL1KStxc8y+zA81sMNthBn3LlR8L3zjNY32p7Lh2fyHJIrbMF8nMdvIWU1ntgHV2MvA1PFmY0dGB7OxLfOXZnPhgythbfOAm4hsWxdGJiOsbR51zEre+fohsG3aN0T4RqP7OrgS1jaXiFnJzNcPgW0DFbPRfAO5BPkc'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_81_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
