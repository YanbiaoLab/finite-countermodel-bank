from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,1],[0,2,0],[0,0,0]],"priority":377,"rule_id":"false.finmodel.setcheck.bank.enum_order3_892.v1","rule_key":"false.finmodel.setcheck.bank.enum_order3_892","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt0jFLw0AUB/B3j4gpLhcy6Hg5xWy6uhRjObAZxE9QP4WDdDFChAsuUneHfgEXP4BDF7c6dReEjOImSOOLo4hLFyv/33DDu4O7/72nCOCbjcH2vT4KO/73Y8XXmuG/AAAAAAAAAAAAAAD+o4fZS9VUtx93a0836TwdvkUHJ5PmvJwezmeX9WPcxN13b3afm/1evbnwbXt5f3zlfTry3lQ71nqvo2TYC5NJnDt37dajyDkpdpNS88K3rSp1qvRrwKSC6UpGigy5Y6LgjFVBXLMpiDSNUyJesraVJG8PJFJAkkRLJgolStGWmaQetpnaYoYZ/zOynC+2zE87o761zLk0S9porEzssmX7BMkHOJE='
_TARGET_BITS_PAYLOAD = 'eNrt0jFLw0AUB/AUwU0cAwX3TnZz6eAHcPELdHC3uEgODBiX4uCn0E9QHFLhqJEurrpFNLlRh5BbxIjHu+eLo4hLFyv/33DDu4O7/73nGeCb54uHHXvZvKnfjyVfa4b/AgAAAAAAAAAAAAD4j7Z73SiI9lZ2Xzf3804+XquvzwfBSdy/6vSOwq0qqOarytxtBDez8Gnh227T6fBQqXyklInui0IpW5fjWVMOqlTrA/1S11pLcV7Glha+7d37M2/XHbF3/Y+MPRvWE2Z3Sj5hCskkzJaHOTMtWdtilrc7ieRYkljJxI1ESdoysdSbNlNbzDDjf0aW0vGj+WlnNC0KolSaJW00hUzssmX7BINqOKU='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_enum_order3_892_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
