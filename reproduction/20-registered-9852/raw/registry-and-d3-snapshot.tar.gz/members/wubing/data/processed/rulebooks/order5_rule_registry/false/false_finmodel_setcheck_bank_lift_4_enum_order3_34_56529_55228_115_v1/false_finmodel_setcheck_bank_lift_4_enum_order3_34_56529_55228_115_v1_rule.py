from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,0,0,0],[0,0,3,0],[0,2,0,2],[0,0,1,0]],"priority":361,"rule_id":"false.finmodel.setcheck.bank.lift_4_enum_order3_34_56529_55228_115.v1","rule_key":"false.finmodel.setcheck.bank.lift_4_enum_order3_34_56529_55228_115","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmT9IG2EYxi+aQqQVDFer0MF/QyhCQ3XpYExrU9vtCoXqogeC2E5d6hCrXAaFaC0qDrEgiZaCBYUQoYtoIyUWIRYbiqQ6WCvG/4NJjCQx3tPvTuhgrrTBxKF8vyEced/k/d77nuf94E7FMIyF+RsTw3nkc9Z3iaFcBAfhqX0M1DGaswGL08uCNaiKk36S8Ibibnth8n+tbbUuo8ypUAU5DaKtQMWozwbeD/dUdPWSi0c1JHZ7qmr0so+V19V508T9Tpvdrhjtelrz8A5JUtFNo1AoFAqFQqFQKBQKhUL5nwG8omCOCI1BhwiC0dXWRL7TObKkqCa9xdYAD3he9M+JX6RicJTo1+GO75bL4az0VksgHHd/XIFt5s2xVKzSXdt4An63PDcDrVmAZrin40ZnlDttrd7gAgKDnPyATZ3eagfwBwSzFsag9qdUjDWUtIXg6OfkrvLSrBEijK187EyCJ/ePYKsDHjTmBt3qDAhyFhAa9n9UBeG3yTcyEoDRx34WWzIh/yj4I3jHEe7BoVyte4k9Bl8du5oZs0H/stLmR2RJMpvQ8YG051lp6c2Ww8UXaTbmIs3GpN1sMM8JU/uyFAmBJWCg7l5Cf/o0W51mswnrcOqx14RNudpif0EQfEckXw6r0m424uq7NgTuJySNEJeTS6u+MxO7Nru4N0msfOKoWxjzikXmSO2E/TvQND+mMETIEAjvSOkz2nHdEdyFoRupDe3oVFXQ6BtEKxlWHpi46tL5V1H05cU1yTdxTWiw2uX0Pk2oVERZZ3UWYxlJxWyT06KTrLP5uUd6wVK/MDZAxDIY12QrqFdYvu6S0q+Fn20QLb2r/pSi2U7f1YiL5ZvfmtE33Vb2hNuHcGvjsZJ6wz2xF1L6qlWeNldSnTYJ3YsY3+gB1276Kp0DJs5qT0C3wWYlH2sHYIu0Urrax77VATmxFJVkcfiljsjJNsTZToyh3dfyyTbXzynJ5txmazWvC2SdezWHG93otrebJLMVlRwOKMnm3GZrNp/wZKO8q9ZARDC4hjiyh9BFtIqyUXK65t/9/2ezKclGqTl1CpMtym2H3NNWOKLWES9CpVZ7niEGbl6nKJvz8gutekmS'
_TARGET_BITS_PAYLOAD = 'eNrtmT9IG2EYxp8zJsGYxMH/EWsdtEFKKjUgNZSkiktBCShUKNUEoWYQlVoN1CGH1gy6dGpFEE4XLRR6W2tT2xiHLlpSkJLBf0NBa48IthhoNNfvTuhgrrTBxKF8vyEced/k/d77nuf94C4hiqJP/Btt3Qfk0275KVIugjx9cz76FsTY2YDPaRUghBLbST9RWQ1qh3s3+b8qSiaqseFUqIKjOcazlxDjZwN3uofWHg2Si5dLJPaheaXzh0WQ1zXyKcD/TrMXr3U+erb06j1JStBNo1AoFAqFQqFQKBQKhUL5nwGsDOvXsbNGFwNCsHV8hnwXcZ1I0Vh6i1UANnAcY25grkvF4NoKl8OhLlyXwyfpraaCXu24VQVP4/1sqdiqY3E2C1zh+mEGWvMB03A0qYNOLX/a2nyoFTD18vIDtnh6q+XBbGL9UQSN0UtSMSG0NW6Aq5+XuzpIs0aIMEr2UdQCjtw/gmcBeD17aHTEMyBIO8DO5V9eMcLskW+kzoSgRbjBTGVC/lpwObC2Qz+EXLnacI2QDW5Z8y0zZkP48arHDF2NZDZ29DZpz1Y1NXgsh7cv0mziRZpNTLvZ4G9gm/NlKRJMNUDfwltV+PRpdjzNZmPL4QyjYAalcrXa/j0juFHdvhxOpN1sxNXvPDC9UUkaIS4nl97wSCZ2zV5b0EKsnOVaqOuwMjt+3WKb+wowU9+hMETIENAXSemN0fZIDhy7hs+pDW1t84oxaOnFBBlWNgT45c36h1oMHKhjyTexgp3zuuX0gZhhk8HGyPKJ6OtKxWwtTYyTrHP6iU16wTJf19FHxNKrjh0rqJet/tIqpX/VPy0jWrq7fDNFs52+q2Fq10uvTmOgaXzjOZ8P9mPZCyX16oc0k1J6pVeeNt9TnTaqyKSGm7WBHwtck86BAO91qxApE06Sj7U8CDtRKT1uEe5FgCNNikryucxSR+Rk6+E9WUFD4QP5ZGvo55Vkc26zTfjLWbLOgqXcsmEMu8cCktl2tnL7lGRzbrNN+7M4slHWSq9Jx4Zae3iyh4joooqyUXJ67N/9/2ezKclGqbl4CpNNyxcbHE1euLTeLisMm173QUgDvj6iKJvz8gue9yek'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_bank_lift_4_enum_order3_34_56529_55228_115_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
