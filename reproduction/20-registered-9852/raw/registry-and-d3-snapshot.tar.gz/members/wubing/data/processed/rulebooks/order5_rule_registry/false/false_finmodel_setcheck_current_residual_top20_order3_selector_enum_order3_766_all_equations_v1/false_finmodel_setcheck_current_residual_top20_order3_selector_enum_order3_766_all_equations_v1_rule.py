from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,1],[0,0,1],[1,0,0]],"priority":604,"rule_id":"false.finmodel.setcheck.current_residual_top20.order3_selector.enum_order3_766.all_equations.v1","rule_key":"false.finmodel.setcheck.current_residual_top20.order3_selector.enum_order3_766.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmUFqxCAUhs0QqLtq6AEScTG3mBhc1F2PFIYsnF0b5gA9So/VRZmMzykJBTNtoZYW/m8j+sTPROODWDDGegb+Fo+M1SoV6MdBj94nIm8TsfsRfX0pCiao2LplXraScpmMNspqoyvTVncbiWUDAAAAAAAAAAAAAOA6/WgrZ238zzbeK9XZwXMpO97ksD0ExcHzKCKt90I2KsjKHLbTtMJtBtnLmmwqMthe12S7HC9y9dFu8AEB8H951k8fbliupgq6CIqJQql4dHf8m0fbUdPJv/lS31/KSOBTWqcOWqmYuZ2WlLBpSZpBJPJ4omneLWZeySUYRhlER8FQMaI0Wxe2pC2jiLTvI4VONGqcxGUDhgm0iaaEYw7Wg9gHVWijCt/X/Ax4br14'
_TARGET_BITS_PAYLOAD = 'eNrtmUFqxCAUhlO6mGP1KD1ASbsbFzLkSN2lC4mZW8xCTA5QorOzECaOzykJBTNtoZYW/m8j+sTPROODOHnvKw/+Fk/e9zoVqEquSsYSkduC2P+Ivr8Uk7dUHOplXmIwZpmMklooqQbZDq8ng2UDAAAAAAAAAAAAAOA6VSmGWoj4n6180boRnDljGtflsD0HxZa5KCItY9Z0OsjGHLabYoVjBtndmqyYMtg2a7J9jhe5+mhv+IAA+L/cq8cPNyxXUwVdBMVEoXU8uhv3zaPtQdHJf/pS31/KSOBT2lpvldYxc9fKUMKmJem4TeTxRNO8W+S8kkswjMJtQ8FQkXaUhzpsSTFGEWnfRwqdaNQ4icsGDBNoE00Jxxzsud0FVWijitv17gzUA7Ov'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_current_residual_top20_order3_selector_enum_order3_766_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
