from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_and","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin2_and","model_table":[[0,0],[0,1]],"priority":180,"rule_id":"false.finmodel.setcheck.fin2_and.all_equations.v1","rule_key":"false.finmodel.setcheck.fin2_and.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmTFLw0AUx9+lZ021lWihBYtwlIKLOEmhnU6o4FRw69AhY4cOpfgBjopQcOkH6CB+go6OdeuoW8cOHfwY5iWK0bsLGdJQ9G4Il/fCvbz/u9/y3j1wgBb4i/pPrny56OALv9v58igW0zmA6By2zsG1Z1k6h6NzCO1ZW57KcR/ARcl/p/LqZgAqZ3IqIlsBWLpETuViCTDP7supPL5kAeqdnz+QLwGMiPfrbI/Y0Jt5pkIJv/V+WVCHToLPXM/h5DGRG1uf5iaWnWo0kmYwlmpqNM1gItXUnFSjWWkGM7AZ2AxsBjYDm4HNwGZgM7AZ2AxsBjYDm4Ftq2ALOlX9sKk/IyCwm5Q8bEHDrBC+vYU6wOzF2gBsHANhMt9rpuqlJQNbz1etHjbV5ZZeUrAFqmVDlrncWUwKtqADuQyblnKDMynYgkZoJWyqSH3WpGD77MdmQiY3uDYGNgPbH4OtJ981xdRBHmoAI63dNZae3wo2v0LTmna/hgwa2OS7phh+cAVsNfEuprgZHzj0GU8TU/EAR1GwKYYkihmMQgBBnZNJEXdvZARlPG1SHBxyKwq2eKopYJvAU2aIFtbkzqqKpqF1bl1HwRZPNdWU6Ijf8jZuWru21fXr1/aql4uCLZ5qCgG4NT5Y4NHiHS69cnlrkXu2GYmCLZZqCgHg2itXAy3OCbMHh2hqkDKpRcEWTzWFAJBjTXaKm6cMJed+/U5XVUH/HWwfxea1Cw=='
_TARGET_BITS_PAYLOAD = 'eNrtmTFLw0AUxz9Ghw4du+nYzY6O/QTi0A/QRRDEch+gFIcOHTM4dBM6FSx4k0LpVFyEIgdSwUI12GrTeM098xLF6N2FDDEUvRvC5b1wL+//7re8dwQUoA/B4sGTKl+GHXyhx2+fHsViOgcIncPROaj2LE/nsHUOoj1rw1O5bwFYKPnPVLatNcDkWk6FuBOAoiXkVIZFgLL7Iqeyv+MCDDrff2AxBagL/9fZq3CgXfFN8yl+6/8y4TavhZ9ZvsNeYCJnjj7N31hOptFElsFYpqnxLIORTFOzM43mZRnMwGZgM7AZ2AxsBjYDm4HNwGZgM7AZ2AxsBraNgi3sVLWiplZFAMFuUvqwhQ2zefT2zgcAlR3vF2CjGAiT+VoVVS8tHdjagWqDqGkgt/TSgi1UzY1YynJnMS3Ywg5kMWoqyg3OtGALG6GTqGki9VnTgu2jH7uOmKzw2hjYDGx/DLa2fNcUUwd5qAFM9Fd5LD1tEFY+R1Oen34OGTSwyXdNMfygCtjGJEequDl8tvkunkaq5AAe42BTDEkUMxiFAITbd7UZ7rZEHR7wtNrs5Il6cbAlU00BWw321k20sEtqF27R1PRGXi8OtmSqqaZEj7RBu7jprxzvNKhf16/eMg62ZKopBKDe4XMJjyY5uPDL5a/SctdhIg62RKopBICeX64rtNh3zDl5QtOVeBDjONiSqaYQAJbskt3gZm/NxSio303hlvB/B9s7hou8HA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin2_and_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
