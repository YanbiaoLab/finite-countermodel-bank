from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_complement_left_and_right","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin2_complement_left_and_right","model_table":[[0,1],[0,0]],"priority":160,"rule_id":"false.finmodel.setcheck.fin2_complement_left_and_right.all_equations.v1","rule_key":"false.finmodel.setcheck.fin2_complement_left_and_right.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWU9oHFUY/94wh5ec3mz3kHp6M5mUbfHQJlYULy/DJOyGFhJF09xUYlsPCUggXscwyqyskG5CSdVKEwKCCcGGEoXgRaSaEEoVvCTm2oMYr179vjezs5lkG8SmbQ7zsSw7b973vvd97/vz+94yUL0BtKBZt67ASR7ubZhw4mlQlA0W6yLbTDCeZK077g2/YFn1suN4Ba7MKAILrcFt6Kq69SgKwBCgDWQCBwEKoMTdj0AFbh34tGkAcxxF7+jzOGo3KhKZGRqXePVKmh6u7Yyv9kwcViG4Gboz1UioAmPZN4vV7k9LtWn6KRQwrT4/WsmzwB2DyQB3ayKPJi3y2w36/makNuSZR5gxkCBNqRpcOeWUU0455ZTT/6ZSBbGAHxDKQBwhGjhCtSrmsuo6jp4ecUE1X+SVOKWiiQBNqgIHUwNDy5KAcA1MjQ41WEOrafASW42mt1qoyegYJiDCDHLj5pTTgXZR90oV3y871YhbluP4PrfDOEXd8P0wHgyFN61bK2yelG9GIJjiLIqEZTset00MNgMTnk3B5kMEMgRkAY9T84UP0CvMoO6ngiquRZy0vB0KLYhSp4gHhcexszEU9XAYtZQiMY8KFsuApgzfDzi2eKGgFEq51gZAYRJ/DdabgkgZ39fLh2LKFQFv5GhAfoMrvS+DRbBfDxMTjQxIBiYT7LV03pEGNZEeZygCN4APmGMEDBRSQVmr6ZaTlGm2nNjnccAW0koGJQ1pNU3Qc6ROVSxZmljwgV6KOImpipMKylpNH0/S+TLqfCV9GKZOVCuVEUGsBwiLGeDT9lJTAGe0oSDOsOKoyqYyboMLY1t5uLI1N0eMKMPj2oFwK2hEm/wEwItVlPzZuv8dqXv+tOBoq6H2ko5H6IKjTx93KFpcEaAeXO+bNRmbVSdE3ZNunq5hZHI3k/W12Gp0PA2rxZUtG2zaViQDvZLHMnALbF9lo2CjcmgnZc7Mc9sxkeptAg9XANcxo6O4hdtwmdxiqRRtULDpo2kyUrDFd0xxsDXuj545ja3vra2vf7c7+eE/a1/8tfXH7g89E9cefTXx4NTTCLauu7uTPT1rO+NXP6HbsPM9E1f/3vrywv0Oo+zI45Z2b29189zKb6Mzt+e26VKu8+v+S5/NvfDj2Qq9pbxOgXtMcRLc1JUtDtpLZ+K6ZllYGLmsBqBLg1R+GAALn1zaw/ov55bm+Mzllx2vvoF1ba7jwsV3B3inyVxLyCCtNcdi1O3RncuT/S8u7f0ZvXdx5PTd7weuPdqMun4WZw7PFY27SJUOtcjo8qSEdvlUX3GIz0dOuz075L8Tevxj0W4Xzd4W97GK7nsTt4ntq/WIozw1d9AwQCOkWdPFxlaXnfbO4q+jXeHq58u1K+V56w07nHqbFzQTpg6VcCQiWcZWqacGWXNDKjKnp0DTRlRaEGD1FQ2YijCtC24XPc4RB2A1yAZbQPgpcZt4sAHsjAawUwdPMz48/jxUUzvj6xsPttoOv1ndXlnZnpy5fWtpafLqSu3KRO2DkbHh4TGa/vubr/UM9y+/ev8VidAxXsj8D6319Uq5+1bEKUUd2MZblDpHuy2LIPqs1RkKZwlhpJ5OuH0zwkzKTGjh94+l9xdqGGyuNrVQ++Iyur5Q8E73FftLi4PRvPB6z5t9Lw21zdP04uulnwb5vOyYasoQJ84jF0FGHC1eSHwtzRdyAVVUwuKkqokmUyCGCJngdO2ECLZlHtHPCUZWHEL5GTxAYRNC9t9KSRheZPP8iSqaLehfguJq9g=='
_TARGET_BITS_PAYLOAD = 'eNrtWU9oHFUYv3o14qHXmFwELSUkWsSLBDSUVEIiCCEpVm0oyTbgYgYd4lwNBCE52Mag3tIomkBLdkmGybuIYt20B2mXZjLzTraH7c47Je8wzPv8vjezs5lkG8SmbQ7zsSw7b973vvd97/vz+94qYJsWtKBxt8DASx7O9YRw4mlVlCMV68L3QoieZK0L7hW7HgSFsuc5dclCw4AArSF92J5yC4ZhQSRAGygECQIYQFW6XwGz3ALIyTAC5XmM3tHncbQblTgyKzQu8eqVNJ3u65jrr8weVsG6bLoTU4ZgdaWyb4antj6vFifpp2CgtPryaCXvgfQixS3cbYg8mrTI93vo+4Ol4ooTHmFGiwMPOWtw5ZRTTjnllFNO/5uqJcQCtkUoA3GEaOAI1qqY8ynX8/R0Qwqq+SKvxCnVQgRonNUlhBoYBgEHhGsQanSowRpaTYOX2Go0vdVCTUYvCgERppUbN6ecDrSLulcq2XbZmzJkEHiebUvfjFPUFds240FTOJO6tcLmidmhAUIxqQxDBL7nSD/EYIsw4fkUbDYYwE1AFnAkNV/4AJsitAp2KqjkBsRJy/um0IIodYp4UDgSO5uIUQ+HUUspEvOoULEMaMqwbUtii2cKSqGUa30AFMbx12qhKYiUsW29vCmmXWHJRo4G5I8k0/uKlAH79Qgx0XCLZGAywV5L5x0eURPpSIUicAP4gDlGwFo9FZS1mm45SZlmy4l9ngRsIYNkkNOQVjMEPYfrVKWSpYkFH+iliJMYK3mpoKzV9PEkna+izpfTR2HqRLVSGQbEeoAIVAQ2bS81BUhFG7LiDCuOqmws4za4MLaVhytbc3PEiDIcqR0It4JG9MlPAJxYRS6frftf4LrnTwuOthpqz+l4hC44+vRxh6LFFQHqIfW+VZOxWXVM1D3p5ukahid3M1lfi61Gx9OwWlzZssGmbUUy0CtlLAO3oPZVNgo2Kod+UubCPLcdE7HNJvBwBUgdMzqKW7iN5MktFkvRBgWbPpomIwVbfMcUB1vj/uiZ03xvW19v73vtM1+/0PfJS12vtL9Tmb126qPZM4+eRrBtn2+fqVT6OuYWvqDbsDuV2YUXuz6+ffZhVPb4cUs719bffXfgtcWJi2OddCm38+H6zc/G/nn7XoneUl6nwD2mOLEu68oWB+3N+3FdCwIsjJJPWaBLA2e2aYEyn1za6cIbd4fG5MSNPz2n0IN1bezh7Vvfr8mdULmB4FZaa47FqJ2LHTdm1v8eanvZ+O7W0oPz765dO9VtbL8p7h+eKxp3kSwdapHR+UkJ7fKjjdqKHDW8XX98xf7BdOSXYtevhZst7mMZ3fcmbhPbV+sRR3lqbqthgEZIq6aLzfcPers7tdcXt83+TweL18ujwS++Of2jrGsmTB0s4UhEqoytUk+1suaGVGROT4EmI6M6IiDYqEUwbWBaF9KvOVIiDsBqkA02i/BT4jbxYAPYRQ1gxw6eZnx48nmoxjrmenvOdO0dftPfOTDQOTNx8dLQ0MzCQPH6bPGbpfnl5Xma/urPv1WW1wd/P/sHR+gYLxT+h9b6aqm8dcmQlKIObOMnSp2LW0FAEH082DGFN4QwUk8n3N5tYCZVIbTw+8fStyNFDDZXm1qwfXFpXB2pOw82auvV4VVjVDibd8KNv1b2Rml67dfqW6tylD+cbsoQJ84jh4EbEi1eT3wtzRd8BFVkIpCkaogmYyBWCJngdO2ECLZ5HtHPCUaWPEL5GTxAYWNC9t9KThheZPP8iSqaLehfyY8GQA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin2_complement_left_and_right_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
