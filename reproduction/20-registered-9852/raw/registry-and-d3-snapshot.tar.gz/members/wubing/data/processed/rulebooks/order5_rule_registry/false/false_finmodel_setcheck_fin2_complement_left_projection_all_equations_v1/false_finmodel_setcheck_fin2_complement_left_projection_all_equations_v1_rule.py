from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_complement_left_projection","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin2_complement_left_projection","model_table":[[1,1],[0,0]],"priority":130,"rule_id":"false.finmodel.setcheck.fin2_complement_left_projection.all_equations.v1","rule_key":"false.finmodel.setcheck.fin2_complement_left_projection.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmDsOgzAMhu0yMHKE9CCVuFaHqnC0HCVHyMgQkfIofRmLIuEqov4WJAyybPzbJgg2Px7gBRtNfwkRn/cu0OaQCG3sMdTgB0Okhno0rInAja8gtYyGQjqUfPJlPkIp+0szH+hKYvVI23ugZ2i7G1eAE3jk37eZ7/LgM3BYF6AoiqL8JffpS6nkloAZJOaQ5ZxFFPDWcM5KiUSyoUnse471JhFa4JwZVauKbffsWGw1G1qmk03Ftnt0sqnY0oLNWiPQo5cO57bt0YFbvp1A2fBHlUGgbJZOTMX/PpTkxbZjVGybTTYzZa2iA7ak1WuYBHzVP5uhqGv6vKVf01ENeN1xH1WO67KGTLfRNXJl1phuU6Untt9yA4i+V/c='
_TARGET_BITS_PAYLOAD = 'eNrtmDsOgzAMhoMyZMwRcpQcDaoOvRZSD9IcgZGBxuVR+jIWjYQrlPpbkDDIsvFvm0Tw7eUKL3gVhotW8XnvCEULO6FQAwEb7GhQ2FBOhpQI3PRKxJbJ0HCH0s6+wkco9XAxy4EmoqpH2t4DPUHR3zgAnMFG+n3f2T4PtgMXywYEQRCEv+Q+fTEV3xKwAMcc8pQzFRm8GcpZzZFIMjSOfc+R3jhC05SzIGoVsWVPxmIrydA6mWwituyRySZi2xdk1gxDj147nNu2R2tq+XYMZUMfVWqGslk7MWX/+xB2L7aMEbFtNtnCnLUKD9gaV28gEvBV/zRjUZf4eY+/psMasLLjPqo8pmUtEt1G1sjErBHdptqf2H7LDcOzGT8='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin2_complement_left_projection_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
