from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_complement_right_projection","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin2_complement_right_projection","model_table":[[1,0],[1,0]],"priority":140,"rule_id":"false.finmodel.setcheck.fin2_complement_right_projection.all_equations.v1","rule_key":"false.finmodel.setcheck.fin2_complement_right_projection.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWUtugzAQpSgLlhj1AGC5Uo8ByAvoqkdKIhbOrkU9QI/aGYxsocwkIAWqIM8KY/yZN++NBzj1h6hMo8F+VN9IWbfyoqSMrq1s66zVenwMLxt5MYkQUmqdFF203N5b9a11p3pjvnRmZzImrZPK7sL1pqKQte6gh53rsx+20yohChw7zCSKLj332m126MWZDGw4faQrj7TRFbe50f+kOCyf6xcwBGQJJN8u2M4dztZ/6PlSTWeU0TJpznUeczMfVSW1qlRWldlrLDZFiCfOdTAJDz0IfqDtBpBxCLAG7mHjnCexRWpYaIiJe5TgFAE0sYaPKAzBDUEnNKr0UEX7tSOrRAI1gv0+pG6gV/kYLxu8HOIWBQtiuyO2MTsSXCPOEQIAYg0PxYSU6Bt73lBJ+BqAm0LwfkEDfTttKjb+9J1HG2INTyDnFzbQtyC2cLLds03F9vIf9eFGYvvI3EJ3USNoQ63hCDQhJSaSki385+Xom0KYkBJ9Cyfbg062UCQFCxYsWLC1jT/Z1igR2DKyXKNE2HHY2DLy+evxILZnFBv/X2CNepx9Z4vXqMd3LDb7zkZwbR5tymVAsj9J5tEmZK3pp3+Ca4SyiFvLviLsOCGPH0gIrs3L0cuy1rZi+wOXqVB0'
_TARGET_BITS_PAYLOAD = 'eNrtWUtugzAQPWoPUNHs4gVKcqSuCgsLOEalWoYDVJgli4jSMUa2UGYSkAJV0cwKY/yZN++NBzhH175o+sFeVZRqnSX6qLTub61IsjqRcnzMXqb6KFpjtJayLeN+uX0m6k3KWEVCHGTtZhKiydrc7cL3NqbUmYyhh5zrPRq2kyhjSjt2mMmUcXOKpN/s0GtnErDh5pmuPNNGV/zmRv/b8rp8rhfAEJBFkPw62nblcXb+Q89BpbFQQuo2PWVVR818UbmWKld1XtTfndkUIZo4t8FEPAwghIGuG0C2Q4A1cM82TlXbOaSGhYaY+EcRTiFAI2uEiMIQuyHohEbeXPN+v3YhlYighrA/hNQPDCof4+WCV0HcejYW2wOxjdkR4RpyjiAAIGsEKCaktL6R5w2WhG8BuCuE4Bc0rG/nTcVGn77zaIOsEQjk/bIN6xuLjU+2R7ap2H7+oj7cSGwftV/oIWoIbbA1PIEmpLSJpCAL/3k5+q4QJqS0vvHJ9qSTjYskNjY2Nra1jT7Z1igRyDKyWKNE2HHYyDLy/9fjLLb/KDb6v8Aa9Tj5ztatUY/vWGzunQ3h2jzaFMuAJH+SzKMNZ63pp3+Ea4iykFvLviLsOCGPH0gQrs3L0cuy1rZi+wW0yCDC'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin2_complement_right_projection_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
