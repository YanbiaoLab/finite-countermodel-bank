from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_left_and_complement_right","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin2_left_and_complement_right","model_table":[[0,0],[1,0]],"priority":150,"rule_id":"false.finmodel.setcheck.fin2_left_and_complement_right.all_equations.v1","rule_key":"false.finmodel.setcheck.fin2_left_and_complement_right.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWV1IU2EYfs/xaKeQPGcK6pXbyR/KYKn93cTm+IRZwoKo6MKMkhXURZcNJmfForMUNC1SEGdQQRAYXhhI6AiRiYvqqiKiMdS86MLqZsLY23fO/Mm1xGiLZue52MfOx85z3ue877vzPudqHoAHEuiXYV0EXueydNkLI++3w2+hxYNYxabYuNB46emHUH4KLjmCiOchHfDkWU+cYiCL8ArgTC0Ae2nLhn/iZoRoGQ/gSg50sMI01SpJXBexJu3g1ub43WIGuORz7QEQAHZpn+vlw3ztvesXbHYrPcHflvcgandWji/it5cWlEFHFsCD8mm6RHEJ8tybkDljbAt4Q0vzZeQIYNwkQgaodkw+xPAHWESYzFSxld8ixLtSbE5nKNTbVzNZkpMJtor28m5FefJif92BkXfOuclQR19pXd1kyblMkIXRf9IgivFlEf2L+75ddFKy/Eyw9csDVyI7nlswhouf/GjBuvj52Muo3MFkpNgQHW4SxTUoxc4avRHp2PxIPM4GCtHd5or4h8y6ItkA6/Suarq03jne9ODx8M1HRcd2PjTosujQoUOHDh3/O8KxlbkzYBl9O746PKl+Vdgvx1EX6d9DHDVv0jMNmm9Bn853DK3uctEWaxrJAljGLmWEOgdjwarNnRgK5DYmW4Wk4eTuAU8Aj4LqW1iKaIRUu+WimMlNb7H1EIMoqgbQhFpsomiSbMQr2Hi12KyGRkI0Ydm0sN3e3W2XpGuqAdRLaQsliRBFoWT1BoYDu+RTeFFkWUJ445+TqW4kvfyumVpRVHOkhUwEq0XRxpu0baZcFNIo5OW4K+Lr5EfnJXOkrPnzx2B7V7HJbHObOF5j44ygFQCTpmJDyxex/i7ONmjF5qIRzjYoZu9S6FncRxLWP2iqrWkZ2qi/Vr6wTx4b+/nG6834r8OTB9DDQHCb+qUpL3Gs9qw66mv9qjLRvqylqjvJvd2eTbGNAR8r4MIyw4NxwSKo+cXGMccDC+PAgfZejiYqg8jQxZjKiBJ+fgn3S4PkiK17ipDWO4RwjZWFYj3xKvbSGtq1hg+rrbPHpxhph77fUWLyCqxdStEouY3/00Yd81/HnynojyqD0/hVUgaEQ4voCFZNqN7yq1naWIhDGYhh1Uwhm6jJJAShd8Ns3wEmlWaU'
_TARGET_BITS_PAYLOAD = 'eNrtWV1IU2EYfsfA3VRedGEqYxGRXaU0aQyJKSHkRSQEQQU1EVRMU9A80agdEtZlFwY2LLIuoiJoUDnoY25005/aoB8sPZtXU3A7x5A66fGct++c+ZNzhdEmrc5zsY+dj53nvM9533fnfc7FOUQ3JlHP4i/h2DMv0+U11uz8jL+FfjfAqJxmo3eg5+AO62waLtYMANcwE3DPBe/dUTCHUIp4cxhR7vm27p90K4JpQkT0pAZ66lNkXx/HSW0kmLIDX28bmqYUlFLP9QZRQHyvff4qHwqGT57vDfiD9AQbLe9z0O4sa8iDTWUhYFFHDsAN7C26mGARbOFuazhrbPlwTkvzJSwIGP1HhHRQ7ZRZNMIPCPFoz1axjZ0hxLVcbF6v1drYMGKfXMgG26fOsVaGObz35dCLml3eQru1oyE2NGSfvJ4NMgs47yZ43rAkojPv1aarXko2mw22erbusnl8fwiMkLfNCSEYMlwzlpnYDiUrxQbg6yYmWIUYtI/ojUjHv4/k46wjDt2XPGZnbVhXJBcQLH//ji59zfcfHT9y6OzR6QcfjiV0WXTo0KFDh47/HRbj8tzpCFWXVK4MT6pfZXGyBtBF+vtgAM2bdJej5lvQp/Px2pVdydQfzCCZAybkxYxQ52CYWbG5k0MBe0nJVSFpOPNv0O2Ah6j6FqFpGiHVbqkoiuczW2wtJMHzqgFUoRYbz0e4AHEJAVEttmBigBBNWDkjbKfftvo57oJqADVS2jjHEcIwlGwwoUjo57oYkedlmRAx+udkqhtJL7+teJjn1RzpJxW2dzwfECPatjLGCxkU8orBY+5qF6sLuLB54vbW7bbOtqlIONAdkUSNTYqiVgBKhooNQlv4wSYoeqoVm4dGWPSUCbsWQ8/hPpK0/lFTbVXL0Eb91fJZutiqqrU3Xm/GGw73HGKLgrYv6pdHc8ljwzfUUV/rVx+T7SsYU91JqeRzLsVWhaJxRrKwiojR/JCg5pdsgAU35leihNp7OZqoCoBCl2g6I0pY+xLupwbJ40DrPkL6mgmRBj7G+UHiYvyxEdq1Dj1RW2dLFxOlHfpEx2TEJch+Lk2jlNb/T2vyFWyuPMCA08ScKofNHFMnPMsDn220QvWWS4toYyE+ps4Io8VxOVmTKbBh47rZvgMl6wqi'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin2_left_and_complement_right_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
