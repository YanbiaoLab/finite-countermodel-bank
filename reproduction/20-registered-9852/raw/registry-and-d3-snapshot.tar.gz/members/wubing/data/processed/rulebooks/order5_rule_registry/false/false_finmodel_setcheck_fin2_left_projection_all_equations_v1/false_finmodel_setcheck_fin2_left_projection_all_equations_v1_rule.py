from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"spine_isolation_left_zero","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin2_left_projection","model_table":[[0,0],[1,1]],"priority":100,"rule_id":"false.finmodel.setcheck.fin2_left_projection.all_equations.v1","rule_key":"false.finmodel.setcheck.fin2_left_projection.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmTFOxDAQRcdyMaWPYA6C5GtRIJwLcKeIk+QILlNEWbwOpsh40ETYAsFMsVLy5f35P3lu/OpmfHi7eciz3Uz+nRsXz7BjvsAlFuU+AcgsRSjrTnMIjgprESIV5mOJpcpeBE+FdCyhwnQISJXfGwWrlz9FCZ9e5yimeuEpiqtep6DHwyYa9An2fOMF4BGSgRU2d3fOt1Io//QRZbYpC8nCYiZXYzam0eK3Z+XMwgAzYKPhALOFdRsRbePM/ACziY1mB7glziyOKHLn3NwAM4VNYVPYFDaFTWFT2BQ2hU1hU9gUNoVNYfs52JzoMWwn2IyE+dgJtiBi3nWCDUXMm06wiZgPnWDzIuaxE2xWxHwn2KKIea+wKWx/DTZfW4v0MQL9bDxTgJPBZusiR2FD+tlYpgDRK2UPSZpnMM0C5K/0i7OadmuO2W1QBpu51pphdhsZbOFaa4HZbbwMNrzWGjK7jZXBdrE1ZreJ/x22dz/9Gyo='
_TARGET_BITS_PAYLOAD = 'eNrtmTFOxDAQRTdKkdJHyElQ7sQFYkTBtSxxEHyEKaewbLwOpsh40ETYAsFMsVLy5f35P3lu/Agbvj3cfMoz32L+3RoXz2nCfIGrLcp9XCKzFqGsO80hABWWIlgqbMeSQJWpCJ4K5lhChf0QkCq/NwpWL3+K4j69zlFi9cJTFKhep6DHwxoa9CVN+cZTSq/JxLSkGe7O+ZZx5Z8+omzBZMGEtMYdaszGNFr89iycmRtglthoOMBsZd1GRJs5Mz/AbGejhQFuhjOzI4qcODcYYKawKWwKm8KmsClsCpvCprApbAqbwqawKWw/BxuIHiN0gi1KmLedYHMi5qETbChiPnaCTcS86wSbFzGPnWALIuY7wWZFzHuFTWH7a7D52pqlj+HoZ+OZAkAGW6iLgMKG9LMJTAGiV8oekjTPYJoFyF/pF2c17daA2W1QBlu81lpkdhsZbO5aa47ZbbwMNrzWGjK7TZDBdrE1Zrex/x22dwyDVgw='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin2_left_projection_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
