from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_nor","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin2_nor","model_table":[[1,0],[0,0]],"priority":190,"rule_id":"false.finmodel.setcheck.fin2_nor.all_equations.v1","rule_key":"false.finmodel.setcheck.fin2_nor.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmL9P20AUx9+dDnEBhkuCQGI6GepkqUAIMaHqgjwkEr9GkIraP6BDx3bz0MERDFYGBAtD13ZAsDF5yB/ikTHsCHjn2Cbmh4SAIS3vM9xZvvjdey++vO8LA0TAAFFJwzDzSZzjaKYfLGydGl2SIOcYKy74JxEf/5wGWYhVwJSNmOOwbaOeZsMRo1pOppnE+5HBUD4kHhqNU0U+y5aG0GCAqolPCz64MsKEwqmBKXGKtuQEDrz/NEilQ5urChowfQPCTyZjdJZRBQRBEMS7pHczGpcA2NWXrXvVF67n62+92/VNR2qIF1tra8WF70dzrvtPJ7Le+nbW9X7Zy9CrlMscS6605dnYW02nHUgrcIR4k90+/vnbCYJQcMWUwZLvgQTFcKsmZwFgjhk4WOED0PSKv1c2wArFuF1zYeWyK/wSVMGF/Uc/KzVKQ9YXji8i+un4tTEuel7Dh+O6VPCVm4Yv8JVMNCorqM3HDgEb2kSO+rnzPDvQCT8cHDYxGIw1vbVSxp/OGl4s5PG4WbhRHvZhbmL2/mYx9Lx0o6iKNuoy+1KswbiNw6RIvUn86lmrY1mHcOfc4UDDkPUUjPQ+QRAE8X9zBVw+IWZ2AS5+79n/yhbTJqhbrcJxoUITBDGU+B0vaVkyTXx3ypsOKuL1gxB0rseXdlY58JZBraxSGezk7Qc3dN4JgiBewy0zaE80'
_TARGET_BITS_PAYLOAD = 'eNrtmDFv00AUx1N1JyOjP0gGT2xFDHTtkIWKIfJQFA8M3srYoR+gCCQYC1RKBqs5oUyoqkAsiQnWTZVSkeSGtr6qp7vHO8d247ZIqGRI6fsNd5Yvfvfeiy/v/2IAUTCDm3BYZD6rRziy4bWF3ceMJxLkwJjyQvDE1advsyBLsSo4thFrHN7bqIdmMWIUX9LpKPX+YjaUH6mHjOM0ln9li4PHMEDRxqeVnl25MErg1MGUxGVb8gQHPX0apOCezdUYDbCpARWkE2M8z6gAgiAI4l5SrZw7CYBZfr17pfrC0rfevHdbqjQkB+ewtbdXXth6NoiiO53IXmt7pRa+tJdeOJ5MNJZcacszs7facdOXVuAoNZfdvq8+bfi+p7QwgmHJD0GCMLhVWxsfMMcGYqzwPnB6xe8rH8EKRafZj6D7oKaCBEYQwcaNn5UcpaGZCsdb4W7GQf9Mq2rYCaDekwJ2NOsECl/JVKOaktq86RCYhU3keVA4r/MDnfIqxuEDBoOxZre6E/zp7OPF1yKeKA/XLcJeL0z8vLqZA9Uw28gdoY2ezL8Ua9Bp4vBLZd6kflWt1bO8Q7h0bn2mYch7CkN6nyAIgvi/WQYt/yBm3gA8XHth/ys7zJqg2mgE9VKFJghiIQkaYdqy5Jr48pS3Y1TEn557wAs9fvBuX4NuMdTKIpPBcdF+aEbnnSAI4l/4DRkYIgI='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin2_nor_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
