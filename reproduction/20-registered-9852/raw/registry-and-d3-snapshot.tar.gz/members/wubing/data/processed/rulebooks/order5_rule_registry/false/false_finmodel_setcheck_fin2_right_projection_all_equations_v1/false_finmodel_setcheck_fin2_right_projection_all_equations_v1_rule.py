from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_right_projection","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin2_right_projection","model_table":[[0,1],[0,1]],"priority":120,"rule_id":"false.finmodel.setcheck.fin2_right_projection.all_equations.v1","rule_key":"false.finmodel.setcheck.fin2_right_projection.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWbFqwzAQBZPBo2X6AbZQofQrbKPB7pR+UowGZUtNu7d/2lMUJILvijQIQrktykm+e8/vvcH62vQyHRd5VlJ+qm2WckIX6kNr2NkuWt8q7ucsz7YWQkqt6958w6ZWiFC1thG9nOr+8HxWm7WXUNXGHYPKy+IebELVPQmOTfXoG4fq9UnaQOWtXZQQfaj6AaBy3K7jhOptANOsmw7DXqt+AKg8OJR9e+OhIO09lHXf/sdDQdp7KN2+/UXNxiqrZT2vU/e6uGFs2BuHUaPUalTtOLRP1TsJE2EReUmhezwYKYQjsMcVYdEcxoZme/8yEYRYj0ClOwIDwX9usXZ1Rb50RFMIAUiPSEXEBQuHjdYewhpCANIjUhFxwcJhIy2A6WJPANYjUBFxwcJhO5FOTJMN0iNSEXHBwmGjAyFNNkiPKKA7UTpspJnTZPOnEe5E6bANbDY2G5uNzcZmY7Ox2dhsbDY2G5uNzcZmY7M9ktlKEEmbrQSRpNmGAkTSnypLpBZptqpEapFmK5Fa9EfXEqlFmu1UIrXYbGy2RzQbwlqabPKI9GZDtJYmmyGPSPKSJE02eUTSdzVJsqnyUou8MkqTTV5q0TdXaRmdl1r0BVpSRp/yUsubDQn2tIzOS63pH5vtF3+gFl8='
_TARGET_BITS_PAYLOAD = 'eNrtWbFqwzAQ/dN2b3GzWYNwPqmZag/C9leUQoWcDyiWRw/B0FMUJILvijQIQrktykm+e8/vvcF6qVTbn1pTa2NeddUZ06ML/aYU7JxbpW4V97MztVitNUapdZLPsGm2NlSFWOxk+nW6fNe6EuIQqkq6Y1D5at2DZai6J8Gxfh1841C9PklJqHzMrbZ2ClU/AFRO1XWcUL0NIJemUmHYa9UPAJUHh7JvLz0UpL2H0uzbP3koSHsP5bxvf9CdFFoos3ZNf/5s3TAi7I3D6MEoPeh5GOef7Z2EibCIvKTQPR6MFMIR2OOKsFguw0KzvX+ZCEKsR6DSHYGB4D+3aM7rRr50RFMIAUiPSEXEBQuHjdYewhpCANIjUhFxwcJhIy2A6WJPANYjUBFxwcJhO5JOTJMN0iNSEXHBwmGjAyFNNkiPKKA7UTpspJnTZPOnEe5E6bCNbDY2G5uNzcZmY7Ox2dhsbDY2G5uNzcZmY7M9ktlKEEmbrQSRpNnGAkTSnypLpBZptq1EapFmK5Fa9EfXEqlFmu1YIrXYbGy2RzQbwlqabPKI9GZDtJYmmzGPSPKSJE02eUTSdzVJstnyUou8MkqTTV5q0TdXaRmdl1r0BVpSRh/zUsubDQn2tIzOS63+H5vtF8zRWtc='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin2_right_projection_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
