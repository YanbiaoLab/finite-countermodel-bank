from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_xor","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin2_xor","model_table":[[0,1],[1,0]],"priority":170,"rule_id":"false.finmodel.setcheck.fin2_xor.all_equations.v1","rule_key":"false.finmodel.setcheck.fin2_xor.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtzzFuhEAMhWHbmpEGqgFxAAtRLLfwShSTLuFE3lUKSpITpOCg2WGbNFukf1/7y5Lf7bDVA/3HFIctFZeOm63wnUySlBp0/rHFpFZb2hyot2xSyxvHUfqzjqsr7XSnvobSXnK3U635SwJ7yGGvwVa7bR5q9W3QRJPr889vaZcwnXU56ErKgaca9uFdR+VadYxJqNGk/Ah+nM+etZstU3mcNZjycorGIBw9p0za8sthNGtOF/o0J/pIBAAAAAAAAAAAAAAAAADwxy8vsFH7'
_TARGET_BITS_PAYLOAD = 'eNrtzzFuhEAMheGDUuQECSVFtOsTkXSZAim+BVsg5AMgmApGmpHt7JBmmy22f1/7y5LfteGeir9iykuXAulmRxfs4qxJQw0yvvHAWisPeyy+cmSt5cfyrOtZ557EW7/4WkPYb3Frvdb4ocWoxNLWwD1fOyq1UrdI8onk/8933YcynXVo/NfFik01tMu3zGK1ypyT+iFJ7B6oOZ896zZy9HA/OzDl6RTJRS1TTNFlt6fDfJSYbv7J5P6VHAAAAAAAAAAAAAAAAADgwR8c0B87'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin2_xor_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
