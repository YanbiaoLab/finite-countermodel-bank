from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_addition_mod3_n3","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_addition_mod3","model_table":[[0,1,2],[1,2,0],[2,0,1]],"priority":270,"rule_id":"false.finmodel.setcheck.fin3_addition_mod3.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_addition_mod3.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmDFuAyEQRT9oLLGukOUDUGzhY0ykFC6dG+GcwEfwUTMz7EKi0KVKMs/FYvhi+Dts8wOE14p4ACiVG8CTP87/IlEEqo7KMaR8yTI6yBTuOk+ZHibjogukw7fkb81xHMdxHMdxHMdxHOcPE2I6o8VD5y9J0K3oKoNNVQI0LwoIJtfJl02YcWo7iUBVOHHmOC1W2AppPllj+LxyJJlGgh6hYIWGWEV+KtfJsp8ttq3lcFUPCI4pXufWWhAKOm5mOnzfzeizkpkgkMmHD7XZthZFtrDsKq6XabGKoIUqh2ZmoBlcM6NPy99ilZHKhw+zubSdgHebWEoqYVotFyuUL5uZgYZ9ZqZ3huWZTT589JbKGjjbGw0U1vmLjKSFLE+2QLHz5N1M70xCRDT58LG3VDQisP6ttVSaFtuCa35uZgZ6P83M6IzdT8u5u4/e0nFJR+75jZStkF5qMzP6qffTzPTO2P00+fDRWzou6UNcn/xj84/tF3xsjuM4P+YD5xhMqg=='
_TARGET_BITS_PAYLOAD = 'eNrtmDFuAyEQRY/qI/gEMTeKSxeRMsdwsQUHsCyqNZIR/MwMu0yi0KVKMs/FYvhi+Dts8xuYt4D6BEqOZ4Amf5z/RS4VCDKKa8vpmnj05CmcZL6kclQZRVkoMnzN/tYcx3Ecx3Ecx3Ecx3H+MK3mG3o8dPuSBJ2jrBJIVbFB8qKGpnKZfN+ECfe+EwtEhTslqtNikbSQ5JOhts8ra+FpZMgRIhZIiBX5J3KZjPvZat+aDxfkgKCa62VurQehKOtmZkCn3Yw8Q1ETBUXl5kNs9q1ZkTQsu7Drx7RYQJNCgVo3Y0gG183IU/O3GngkcvOhNh99J+BFJx4xxzatlqIWStfNjCFhn5oZnSF+JpWbj9FSXgMlfaOttGX+ImuRQpona6A4ONBuZnQmo6Kq3HzsLWUNC7R/S4ihTIttwTUdNjOG3E81Y53R+6k59/AxWmqX1HLPb+SkheRSqxnrp9xPNTM6o/dT5eZjtNQu6ZFd3/1j84/tF3xsjuM4P+YDZVkkjA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_addition_mod3_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
