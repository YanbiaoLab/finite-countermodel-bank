from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_left_cyclic_successor_n3","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_left_cyclic_successor","model_table":[[1,1,1],[2,2,2],[0,0,0]],"priority":240,"rule_id":"false.finmodel.setcheck.fin3_left_cyclic_successor.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_left_cyclic_successor.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmTEOgzAMRe1mYMwR6EEqca0OVcnROApHyMiAkpbQBSWuoISq0P8WBkIcbH87SpiIzieSaHw5PG7kCjogvR+osszVhbnqlA8DasFc1gd3D5+VkxdmXGywtZ1bruSY6E50IcvysEZZ/VyropaNJgAAAACA/8J4CbWBNSsZqxGJDzbtCaotrIk5UiASAGLbr9ha0Ro6Gzrb8RljpGdpXmUSG8/R/Pq0Ec8IE5rXmcRWSMuYwJnENkvzFZIcgL3gfHx5IDXY1Rui1y1RH9dbF1eO1KXGovrZhQ5i4vFN/DNt3HBsvvoJwJjl73KN4w2R0Nrr3xPbd3kARZoKYQ=='
_TARGET_BITS_PAYLOAD = 'eNrtmTEOgzAMRRMxMOYIHIWjhapDr4XUg5QjZGRI45bQBTmuoISq0P8WBkIcbH87SgIR3e4kUatueJxJ93RACjXQZpmrjHM1KR9G/IK5jIruHj7rJi/suNhoazu3XEgHohPRlUyQh9XeuOdaPVXBOgIAAAAA+C+skvAbWDOSsQaR+GDTnqDdwpqYIz0iASC2/YqtEq2hs6GzHZ8xRm6W5n0msYU5ml+fNuIZYULzLpPYemkZE0Imsc3SfIskB2AvaMUvD6QGu3pD9LolKni91bxypC41FtXPMnYQy8fX/Gcq3nBMvvoJwJjl73It8A2R0Nqb3xPbd3kABuZm1Q=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_left_cyclic_successor_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
