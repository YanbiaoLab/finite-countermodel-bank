from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_left_minus_right","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_left_minus_right","model_table":[[0,2,1],[1,0,2],[2,1,0]],"priority":220,"rule_id":"false.finmodel.setcheck.fin3_left_minus_right.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_left_minus_right.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWUGOIjEMtC2PZDgFxAMyqA88I7PiwN54kkEc+sgTeOrGTroHkGBGaHcHzaSQoOk26U7iSpXD7gCgcBNJ0+76XMfcSwIigF5QIVkc3MVv4CVRhPyT5VzLHckubETCTIEZIMwI0C4oPIaw2AJFDLmtCC+S24/iF/SgMENJ9pCzVwhgp+XBu9zsyt/EMYS4BKQ1R0C0MzG/7qLD0IsAzRAD+E+AfFbia0xroHHObLI+mK7IQMi5lZC/4O24VX6mlbVH96IanhksC6MCT40SZKms7Ax04qeTpQMyds4wYGAPfztLjASbyzWDUhvWhoYvhgIaq7cmHFjXfIw4sPrlQrVIc7yFm85o1Zq6EmR+v8GkNHl8jr7tyWQe9iZCgP5Q7B085U+ibe3B3N4k4R48XM/NRawiOch31zKm4XGyHdxcucd022ap5kloBld7M52jh1v+ykfuxWTMSBpcZHw3lB+avoaGmyZ+4kWKL4tWFdgSWURA1sxxiWJyULO3Z8s1qmWRFLN3lpBjIj6Ft1PYUe6PJhyV7ei1CqzsXRa2nGtUHpRNLdyqwZFPUgRtxObhgrDhs5Bp8umhKtOeZJaXSgEmLtNlKqBW8B7+rtDuSOrs1ek6/siB7DjYyJiC+D6BU9uNnfbA64MxAmt95tsqHp48rFA71JYQzg7xx5Htv9rIupdm5lurtNeBGCtwmKfgvPCR9nC7YxiL9Zr/YyIAt2Wl4VGE6MVhWBlXxXNxXtLYWO27Pfl4UtfoYRFIJLS5bimfDuVg3sa1oeGLQWysdgXhKu1FPE5p2O1xN29sd1ZPL5VkEqUo234oRyO2YvR74Rtv/YeFWzczTwnFEz9WZftM9eEOLFxZPOD2J9c/xh/BymVC'
_TARGET_BITS_PAYLOAD = 'eNrtWUGOIjEMfCpP4NgHBH4St+WAdvIMDi0mD0CQE1gay/bGTroHkGBGaHcHzaSQoOk26U7iSpXDYqYKehMBwuL6XE/UYVBm1Q4FNFic3sUvpS1z1PyT7R7KHdkurBDTAZRINR1YxS6APoa0WypHSbmtqG+Y24/oF2AGehAM9pCHV01qp/HBu9zsyt/ENKW4VeE1RRWxMzG/7qKX1CEqH0SS+k+UfVbiawxr5XHObLI+mK5IykK5lZS/yO24TX6mjbXH96IanhmEO6MCHY0SbKkM5Ax04oeJpYOQ9M4wJSUPfzlLjKCryzWDQxvWhoYvBqgYq5cmHFLXfIkysPrtQrUYcryFm85A1Zq6EmR+v+ipNDl9jr7N2WRe5yZCKv5Q5B2c5E/mZe3B3t4wyFw9HM7NRawiOch33zKm4XGyzdxcucd022ap5kloBhc6M52jh9v+zkfuxXDMSB5cZHw3lB+avoaGmyb+5EWKL4tWFdgSWUQA10RxK2hyULO3I8s1rmURFrN3lpBjIj6FtwNdcO4PBBmVbeq1im7sHXe2nEMEGpQNLNyqwZFPWARtxOrhgrDhs8Bj8OnhKtOeZJaXwElPLtNlKrRW8B7+rtDuSOrs1ema/siB7CnZyJiC+D6BU9uNHXRK65kxQmp95tsqHh48rFA71ZZEzw7lx5Htv9rIupdm5huqtNeBGCtw3YfkvPCR9nC7YxqL9Zr/YyIotWWl4VGk6MVh2hhX0XNxX9LYWO27Pfn4VNfoYREIjLy6bimfTuVg38a1oeGLwWSsdgWhKu1FPCZh2O1xN29sd1YfL5XkFLEo23woR6O0YvR74Rtv/aedWzczT0HQEz9WZftM9eEOLF1ZPKX2J9c/xh+Kpwv0'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_left_minus_right_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
