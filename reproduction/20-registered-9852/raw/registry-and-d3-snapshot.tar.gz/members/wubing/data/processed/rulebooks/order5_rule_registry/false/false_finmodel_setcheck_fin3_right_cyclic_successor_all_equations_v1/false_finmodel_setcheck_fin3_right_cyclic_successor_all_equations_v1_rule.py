from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_right_cyclic_successor_n3","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_right_cyclic_successor","model_table":[[1,2,0],[1,2,0],[1,2,0]],"priority":250,"rule_id":"false.finmodel.setcheck.fin3_right_cyclic_successor.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_right_cyclic_successor.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWc2OgyAQpsYDRzH7AErYZB8DDQfdUx+pMR7w1jV9gH3UBTEQU7CYrLZN5rvBgDDf/NCZnhBC/NzSgVGKHoC3dd4KEZT/sh+REzI2lE4LpcxISWtcpp8DG6W8WqnoJSZESdB2fOctI6TUF1bnmS9R2mc1AqxYZeJKW2GyiVB8YWOV4p7JK2t6yaSguOnqIgl9+cIqKljF8ornHwkBqv/VYJ4wso4/T/ZZZ+NqnqxxZYPLbTRiXPaF2qLWqDk9wF2Bb8we1NDBuIBZ6vGL+wD2nWHE6nZqi76QEqpBWmXp6VAiz+OkURxrHgKsHm6jpcLppQdat2Be8rDm7rV6ho3U2V7GeMpoHTcZ2xPUcW7jOcNR4fRSA60bxCTgtQDBBi/bo5ftUNUuo7AvyNLX4txm9dVZOKXWDRIAAAAAAACApyPY4Nvj9zjQDQA8vWbbo/gNdiN5VIPSd4bNO8siUSeSYM0WV8atFqaL9qfWLdiNTPYofoMNkvdv6361+voeX4tzG76NyOCfJHFu88pEAt4RczfS42txOXpb1jo22P4A6qr/dw=='
_TARGET_BITS_PAYLOAD = 'eNrtWc2OgyAQftR9gI3bmxyM6SP1tHogymNssgR9gI145GAsBTEQU7CYrLZN5rvBgDDf/NCZXqWU5FKwlDImH4AUVVdgHJR/0C/ccZ6UjE0LEep5wyrRDL8pTRA6WSnOkOBcSeR2fHcF5bzRF1bnmS8xlvWVBKxYZeJKW2GyCVZ8CWOV9p7JEy0zRBFmosyrdgx9+UxrhmlNu5p0fyMHqv/VYJ4wso4/T2Z9buNqnqxEbYPLbTRi0WSt2qLWqDk9EHkrPqk9qGSpcQGz1OMX9wHsO8OI1e3UFn0hJVSDoe6H66FEXpJJozjWPARYPdxGS4XTSw+0bsG85GHN3Wv1DBups72M8ZTRcmIytieo49zGc4ajwumlBlo3iEnAawGCDV62Ry/boaqdE2xfkKWvxbnN6quzcEqtGyQAAAAAAAAAT0ewwbfH73GgGwB4es22R/Eb7EaSqAal7wybd5ZFok4kwZotroxbLUwX7U+tW7AbOe5R/AYbJO/f1v0p9PU9vhbnNmQbkcE/SeLc5pWJBLwj5m6kx9ficvS2rHVssN0AYcdxsA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_right_cyclic_successor_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
