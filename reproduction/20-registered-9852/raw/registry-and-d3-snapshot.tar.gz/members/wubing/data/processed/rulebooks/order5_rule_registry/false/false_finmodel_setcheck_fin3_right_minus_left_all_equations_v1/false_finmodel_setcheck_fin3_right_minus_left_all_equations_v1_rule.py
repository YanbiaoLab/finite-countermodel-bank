from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_right_minus_left","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_right_minus_left","model_table":[[0,1,2],[2,0,1],[1,2,0]],"priority":210,"rule_id":"false.finmodel.setcheck.fin3_right_minus_left.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_right_minus_left.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWUuO2zAMpQQtODs6J+AYOYgw8GJ6KxaYhZfTG5ekPjEKuw2ySFBDDxNb0fhDUo/iJwHyh+RLhgSvwCcy6ynMkWiKEFSMhwX5JuIZAiIAzwnsaeAfuUKcQsg8M0T2azPgg295CyasiA7nD2AgHdCDqlxiXBJDUCGXL5XJ7ue/3iFfAlPArqhraDrCNdCKKKbX+qnK2x/eowrnBVRkn4l2l8oQTCUhJCgTB3gHQta3mDHw2cRBmgT6WtgiuA5un5x9CqtUewYWkHqGPpKjt/2ANEeljhpjvki5IZaX6qOnt2yMKmQDpklniz25UyAU6UI7UB2/HNeUVsw7VsuyQuJirUrlHdab4rmeoY/yEX2vTlD3RLcaNiugPdqM7AL4Qpil/XKGvmwbUlcXxuNVOzHyBX6u4laTVbcQM0+xQzIuLpF8feqCLim1Db4bPIPP5LZ0+i3DwImc7bn4Tr4Xenw1arqzukLm1fRLlZKuhfHTL09F4S0xCW7qQuBBmoH/ACOyDfwTp04jvYQwlntx4tt6aMm35+r2bz96xeGRbZtyc+V/bCUHPr+qGBgYuLfl4F6d0rZ2tk0gLwjJnbg7Mv7h0Dgc+2yRzUKVRzZrQ5WsJrbIZgXoLVhZZCtFa9okOKEl/q3h1MvXgYGBV4HfvRFhG7vHgVumZr3r0mhv27mspOVOrf1rXXNL8RA2w7H/DwwcOJs1CUsWRa0TZjHVm4QeGdOBs+10CulFv+wdNEjuywd2GiT9FzvpB9h0WQbOgN+fAGWh'
_TARGET_BITS_PAYLOAD = 'eNrtWUuO2zAMvXFn6cUA5a06C2OggwQeniDmbrgQJJakPjEKuw2ySFBDDxNb0fhDUo/iJ1nCJ4RrkCivwAcj6ikviWhNklWMhwV5I8JFMrMILlHsaeIfuEhacw64oCT0a4Pwg2/5ziYsgA6XT0EhHdCDqlxTmiNKViHnd5XJ7se/3gHvIGvmrqhraDrKJdPEDKbX9KHK2x/fowqGWVRkn0l2l8qQTSUgJikTB/gSYtS3mDH42cRhWkH6WtgiuA5unxB8iqtUewYGgXqWPoKjt/2SuCSljhpjuUK5IZWX6qPX72CMKmQTpFVniz2xUyAX6XI7UB2/HJcYJw47VgswScRirUrlHdab4qGepY/CEX0vTlD3RLcaNyuwPdqM7AL4Qpil/XKUvmwbUlcX5uNVOzHCVX5O4FaDSbcQM0+xQzQuzol8feqCzjG2Db4bPIjPhLZ0+i3IwImc7bl4i74Xenw1arqzukLm1fRDlYKuhfHTL49F4S0xSW7qSsZBmoH/ACOyDfwTp04jvYQwlntx4tt6bsm35+r2bz96xeGRbZtyY+V/aiUHP7+qGBgYuLfl4F4d47Z2tk0gzCzRnbg7Mv/h0Dwc+2yRzUKVRzZrQ5WsJrXIZgXoLVhZZCtFa9wkOLkl/q3h1MvXgYGBVwG/vBFhG7vHgVumZr3r0mhv2zlMpOVOrf1rXXNL8Vg2w7H/DwwcOJs1CUsWRa0TZjHVm4QeGeOBs+10CulFv+wdNEjuywd2GiT9FzvoB9l0WQbOgN+tcQuV'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_right_minus_left_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
