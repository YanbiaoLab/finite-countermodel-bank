from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_000_000_010","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_000_000_010","model_table":[[0,0,0],[0,0,0],[0,1,0]],"priority":307,"rule_id":"false.finmodel.setcheck.fin3_table_000_000_010.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_000_000_010.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgBLacZAGSB/7LM4wCeoAL227nbTIuZsKQaPgPBuyYWv6AJewxJR5AtDBiykAk+DElNpwEkasiewKdWJgYfvxnRtiMbNKB/8jAfjTaRsEoGAWjYBSMglEwCkbBKBgFo2AUjIJRMAqGL8jd/Xbb7t3b75aVf982+82ZO3f3GhenP5tXfE6YBpY9+I8L0MJrf3BZRovB0AacXmOmgW0fcFlWT4uA/IfLNn4aWHYAZ0Ay0sC2H7gso8mgKE6vsY9mttHMNgCZzeF23u6T585wYspsurVu3a2yyXNnrl5dlrauJ6K4pzAyNzw8F6T8aqi1cbjbGstjFgoMLlCDWBqIzWz1pOR5CgIAp6YfRNnGSE5mYyQhz1NQ2hCaMiIASCttGrbdBaWD01m7d2Xd9gUmhnW3Zu40SjpreCx1a2zs1rdqwMQQ/vZMjOTGZxKPsSQbw6lpeVdDvVcvzXl2rWOlcbG35VJ4AtqxJerUtCKv7D5DPc22DT6PDXi+/x8FQxAAAIUMUWU='
_TARGET_BITS_PAYLOAD = 'eNr79/////r/hIC32W8gac/w4P8ooAfQ91SZ6Hum5y+GRD0DGPzA1MIMljiAKSEP0fIPUwYi8QFTwt8MRIYuK1639/ff/+wMfxA2I5tkz4AMDoxG2ygYBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbB8AWTXIQ8XVw8lDo7ODxThI2VlZzO9MyQTOwxfEMDy+QZcAFaeI0Zl2W0GAytx+m1PzSwjR+XZQ20CEhGXLZ9oIFl9jgD8h8NbGPHZRlNBkVxeu3HaGYbzWwDkNn2q0x0MTM0/oYp46saGKjamZOUFhLSOTOweHlPcd+ySStWTAIp11p15MyKncHHLI/f/78batDvemIzWwMpeZ6CAMCpiZ0o2/6Rk9n+kZDnKShtCE0ZEQCklTb1nkqgdGAy1cV1qsomYGIIVE1zOzvX6JzlLK9Fi7yEbgITwwoh48XP/CSfy2BJNueyZk7UWrUlJGqypGZ52JmeLcei4AnI3XupaWbv1imF5y5eq/TfLHP+MwfDKBiCAADHZR/R'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_000_000_010_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
