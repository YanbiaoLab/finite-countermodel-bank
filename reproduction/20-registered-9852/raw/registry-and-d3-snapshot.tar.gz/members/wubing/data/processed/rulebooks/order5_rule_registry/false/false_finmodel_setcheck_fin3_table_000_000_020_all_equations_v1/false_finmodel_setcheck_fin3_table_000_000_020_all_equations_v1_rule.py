from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_000_000_020","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_000_000_020","model_table":[[0,0,0],[0,0,0],[0,2,0]],"priority":308,"rule_id":"false.finmodel.setcheck.fin3_table_000_000_020.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_000_000_020.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2EFLwmAYB/B3ZrjRwY0dOqrbYbeCzuVKFnTbJyivfQAviaDJgoFHD3ay9GNEkESHgZf2DSwSdtSdVGRPW3aI9KUkXot4focxeLb99757nw3GEUIq5CtT4MJtx12PEbQCA3gzX6jMColFjyiizxd6s1O4+QoIx0FjkyPxz4URfKTf7LY23LpWyBR9a8sws4pTSxer4sTxdloXp7mj/fACHD40hBBCCCGEEEIIof8MaBIMwnrUNBZDm9LCUgzCKtShrTFIG9DCyiwmMqClJRmEdagTyeJP5YgWpmOzYbP9UrPpQ+mgAf3DaE7LZxKEu/a29T70FTUb+su0wjh/8gBmyXjshyvEMO3mFLQX+Rm0rOL5d7d8WzPMAGRfGIKckqLD467c1gCEsRW+9KQn9T6ZiftKAN2amOfPPcGtA1ilXNrKVsUJn/PUMEflfdVe5sY4Zs3G5B0dLJGWWGmz/fzLZkbrwIarkX3dBV+xm+LeGExHW7BsYoRfcAWHXH477RX7y1Pd'
_TARGET_BITS_PAYLOAD = 'eNrt2EFLwmAYB/BniHqaHgdG+Q3WRdghwiD6GFqe8uBRGDRMQeziB+hqfYLdgoY16xzUbYdNPXYYm4fYJHNvW3aI9KUkXot4focxeLb99757nw0WEELq5CsxCMJtXnyeErQCaXgzX6jPCuNFjyiizxeys1OC+Qp451z5MSCTz4UkfKTv3RafxIrR7rd45UFTe5ZUHbRqblwS7opHp92L6/ACAT40hBBCCCGEEEIIof8MaMYMwrLUNBZDi9HChgzC6tShvTBIS9PCGiwmkqOljRiE5akTyeJPZZIWpmOzYbP9UrPpKeeqDJnLaE4bJw6Eu/K98j70FTUb+suMdqJztgVqU9vMhCtEU+VSDIw1ex2MniXwO7t+wdBUDmzeS4E9dKLDJ6JdMAC8hBK+9JwNc3vUn/AWB7mq2/GPBU+sACjN7kDp1dy43xXMMMf0eVNe5sYCZs3G5B3NLZE2Xmmz/fzLpkbrQIaDpLyfA96SS+5NAlTJWLBspsRfcAWJHH477RVQph1Z'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_000_000_020_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
