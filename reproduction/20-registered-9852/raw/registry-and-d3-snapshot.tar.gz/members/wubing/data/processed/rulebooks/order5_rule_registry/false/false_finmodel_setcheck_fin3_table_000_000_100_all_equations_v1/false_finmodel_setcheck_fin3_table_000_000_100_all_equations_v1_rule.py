from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_000_000_100","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_000_000_100","model_table":[[0,0,0],[0,0,0],[1,0,0]],"priority":309,"rule_id":"false.finmodel.setcheck.fin3_table_000_000_100.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_000_000_100.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgDhz4L88wCugBLjAwJBgxMDCRoOXPfxCwx5R4AJb4z4gpA5Hgx5QwAJNaDAwCBNIDMrAfjbZRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBSMglFAFfAAMWYFHoJiHw2SoQD+/ccB+Glg2QFclmEbCKUY/MBlGU0GRXF6jZ0mmQ0XoIXX/uCyjBYzDw04vcZMA9s+4LKsfshnNvqCH7iiB0tl8IBWsTkKSM1sbAwMkxkZTnCBOD5sEDGjJCCZwgpiq0FiyUHSEEhuAs98TYYU1Qt6JICk4VREPHdowtkBbjzItihothkMopptFJAGACJObVc='
_TARGET_BITS_PAYLOAD = 'eNrt2bEKgkAYB3CjwbFH8BEaG32CnqE93Bqiyd4jokdoaGrKF1CnhKaaakyIQKP8Ug9S0I+SOkn4/4bj9EM+zs/z4C4iIpM+oysHgjp0iRY20aPCI20lYRUDWhpQomJEBPxiwE3bLdH5zfeQZ6FsAAAAAAAAAADwE1q2Z5VuQQV4JU3QUhi+hGQ6l6xsI/RrKpdMyqYoO7RAymTjyBham0sm4+TBZId2l5CtwyWbNn6y1UvlylOyGGiyqglVJ1tIZETUuyYXq1Dcs+dxO7sl/Z2o0uboxG0/PfkyxK96MDrFrTPM6jz2Xv3l+pLPsvcm7h+tbFDNEyoyA98='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_000_000_100_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
