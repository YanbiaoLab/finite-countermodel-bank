from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_000_001_001","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_000_001_001","model_table":[[0,0,0],[0,0,1],[0,0,1]],"priority":312,"rule_id":"false.finmodel.setcheck.fin3_table_000_001_001.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_000_001_001.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2TEOQEAQheG3CJuIVu0ojuIojqF0FDql4+iQUCwhFBTk/4qdYjdvqplmje7LJU/4DbPWYH8xjK7oPCGr58O6WQAAAAAAAAAA4D0XHzXlo82aER/kMya4YJeSpFLdukulDGOpL8zR641O1e1uE3XGyVo='
_TARGET_BITS_PAYLOAD = 'eNrt2TEOQEAQhWGd4yh1HEXpGI7iKI6i1ooEwT4SiiXEFhTk/4qdYjdvqplmjdwV0iT8htnqcLzwPVt3nVAmy9HaWQAAAAAAAAAA4D03HzXZo81iDx80Mia40a6lrqQkspdK1jdSkJuz1zuhUuduM9arp80='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_000_001_001_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
