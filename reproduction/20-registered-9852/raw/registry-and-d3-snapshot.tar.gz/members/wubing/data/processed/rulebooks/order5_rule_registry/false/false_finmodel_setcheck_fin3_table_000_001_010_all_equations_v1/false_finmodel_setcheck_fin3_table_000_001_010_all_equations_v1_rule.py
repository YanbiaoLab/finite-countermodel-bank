from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_000_001_010","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_000_001_010","model_table":[[0,0,0],[0,0,1],[0,1,0]],"priority":313,"rule_id":"false.finmodel.setcheck.fin3_table_000_001_010.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_000_001_010.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGBhIACWdIDIAwcYGUYBPcAEs1saiwycMSUalh5mtmS0xaLlz38QsMeUSHj5wcHPgR+LlnhG1n/sQlgkFnRAU0SAkwoDg4SFggCQzcLEwFDAwMcAMomlASTr8ECggTGBAaxWYDTSRsEoGAWjYBSMglEwCkbBKBgFo2AUjIJRMAqGM8hc3Gu2y3rLRbfydrMujTMX7i40cE5sayrmY6KBZQkvP1z2d+Gv+9X54iBoNOwHh8B/jX+CDi+YaeE1yMAaFiBPA8salh72txe0/fFSfRE7/xOWLw+UHf4s/uHOsJCfFl77UHrxab0C4397R4EHnf875wmwKFR9AvrLhSZp5B+ugKSF3w7gsuw/Lcawf+CyzJ4WAYnTa+xDPrPVxJb8lPc48N9fgKXiUf0idRbGjnl/gP4SpIVlDTgDknkYZLZdNoqMDtPVVcAFGNBiF/8nrgxKNLHM4VbG4o5DPJqYMiKYQoK5IUFg5VNFuIxFnDQ4jikokJQnI6xsJghfYGbBrFqYMMx5oCTLIQdS3tzO8IHJSY6xwQ4oqsDAQmJmI66I+kNpaQOdqxHgwJDhwHBxQ3eJQgVYuRzTAW6OShaGXyBREmZialhFfsh7MDAA3YhmYQMQo1r4YT8TCyNYuSMDMBH/Z3RAcxCU64AzswEbB4Ktkl0Ziyc5SbuKpK1YEjBjoYCTowGbJi4tXET4AUfS2VBSoaC+gF38pcOHB41zGuRsWBrEBT5xMHxhZMHeImlwIGgT7kRD35rt0kOQj2KWMB9sZi9iqvogwBDncEKZ4QI7lmSDI1ugex53ovnBpfHBfkLDf1EFjgUH/jswcTAxcP4A+ksJW7IB8R0wDYfLEQQAMNqPjQ=='
_TARGET_BITS_PAYLOAD = 'eNrtmU1oE0EUxzeEuodS9paCRQNCb9ocPIhQGy89efAoNB+leFAECYhNqlSnUtqIUQQPFi/Gj4MHkcZTtWkysfGDgJBbE2jjJiJajGZTNO7aye5zNwbB7C5pkC1Y5gcJ2Xlv5j9v8t7sMqsAACLQBk9I+3a7FaBsB4FMf86XXdIb0Mhg/bWybNDFzmik9Iaog8NPcdWgyz1l0yZ9NTCMhpoZMZ9YBfj0hhfU30QGuAkboI1EkGbFTgEpUWj4CvRPo1AoFAqFQqFQKBQKhULZydz2nssMvzw28PzqRGY8d9C1z59dunvh0vUN2QKxqIPbH4tXr3QFe4e00zBWFJicrYJ761aE9vtgzYCiBWJoZDCWqiyzjrxPqvaRbucatnvZZ+CvWhEad21g9xSvMKmk4AwywTGB8DM9alxxS3LEZraQVsTmNhNjrDjDZs3EUlYspGlo0n9fbNMPIruKC24mJpDwnilfniihMbsaV8UKMWS6kPUdUGzD6XcKPp1fbWxgqnA81rcIBUvEcP+cN3Tk24reUtY3VW49ftJwP1OuvS0ncuJhnu+oJh+9Sge+uOpEf2uRdeM4C+/FkuY+OQGcnCgp6IXaygPpsNi2tkXZ/3W3ab6rEUSdRdTNGJ2P8OGGe0l2fxdnCXRprR28iZneLLPFBQB1ji2CSP38LcgdlYnScE+CmsSMglsm1LzEpsWmPhxULn4cn/OeTXxYLN854Zk/5RcSyezPFbMutS3EYJI6xyNhPj8qrTsw57x8EpXSBK0LPSJ0K8T4iQThtkrmSbO9d7YDe7WIHnrqQ5PSDXmGE+A+PrQGLskgbUzKojV486RhazkuFUDMZ14cdTNYFmX4wapxFYzSRrvG+sH/2NryCxum4Zo='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_000_001_010_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
