from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_000_020_001","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_000_020_001","model_table":[[0,0,0],[0,2,0],[0,0,1]],"priority":314,"rule_id":"false.finmodel.setcheck.fin3_table_000_020_001.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_000_020_001.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZAACFgYk4MAwCkY4kIhV2yLgy8HZwcCgwMCQMTnVNFJy4xo1bWU2BiawApYGENngywYkA84m9QgpCYyG2igYBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBiSgAWXhEMzLwNDzgZGJKENB9kYGMwiRgNtFIyCQQ8acMpkAHN1A68ZspDZDQaGA2zco6GGBRy4/rTzf+e8P+u5L05W/6de9UnQMe7I//qWC+7/rre+OCn8X9j2Z4eC/qP/9k4vlHEXqESCjNu55jdn7lyzbfXqbXdT0p+9WjV3prbyNZnkmLDbV0Nv520yLi69eu7MVMHsPkO/oRWQD+wXnv7/Self/SPlJr3/p7sVqpy+PPlvrzhf4L/9R0HH6f+fugrYKlZ9+j9/gj8HSANF0y5r5ted0vx30dV+r80vzeU/3PX7H8m32nA9qn+xaH6c3N8pwX8WT3f/2O8kx/rRvoXizLb+NCgdMGK6mshkQxK4sA2cDjBr8Aaikg3fYM5s9U6gdMDAwIguQ3yyIR5E2IPSgTJmeXmAqGRDYl4HALll1to='
_TARGET_BITS_PAYLOAD = 'eNr79x8Ifv9HAvv/j4IRDp4vuun9ftP3b+X//9///396zqxTy575Bd+8cufn/79gBb/rQWT9pp9Acr3R3OK3d9+PhtooGAWjYBSMglEwCkbBKBgFo2AUjIJRMApGwSgYkuA3Lon9NZ/+/5/s/w9JyN/u5///J5ePBtooGAWDHtTjlJkOzNX1n04iC51U///f/ueX0VDDAuw1pMoYyhKZA77o5dxgvNHK+27fQmuGhmr9HYwaVeJmbxjeHGIrv39BluHAXvE7uAtUIsF0lUkn1NLcgj1DQjyVZs+QFA1NSrtyR/PxnMUrVbRWqUz0PdPTpWVonPVuSuG5jUMrIOUPxJkw8N5lbJC9U3uRwaTkfutebmmGA/cS3jMc4Hu3L4NBatf7Q/daeRkS8jd8B2mgaNolOKHR9Bqj3q4DTodZr0Ww77hQIPug6vBX2Qbx2ISFD5my1zDHZOzgK9j78BffgWqKM1uACSgd/MN0NZHJhiSg7wlOB5g1eD1RyebjYM5sDXtB6eD//3/oMsQnG+LB8gOgdHAHs7y0JyrZkJjXAZMMmk0='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_000_020_001_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
