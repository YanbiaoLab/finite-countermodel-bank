from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_000_110_222","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_000_110_222","model_table":[[0,0,0],[1,1,0],[2,2,2]],"priority":294,"rule_id":"false.finmodel.setcheck.fin3_table_000_110_222.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_000_110_222.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWTFr20AUfrKMrYAVKSFDS0odhAoZCy0hUyyKhihTf0IoJVMC6dYh4INS4mwmdCnp4J9QWsisEOjU7u2mbBk1ahBRpZNoqe+eIpPzo0MeWEZ6uvvuHe+7e9/pveYBhF0o7IhfQ36FFX71ypseHPIbT8//0kwDqUWZJXdANkQcSabLHWHWR5psIc8hRoYF7A3WpIc5Ji7W2ZMFxLGO9eUZmKd1Wyjp9ISy6kE0REJZHAihlH/ur860pwSZXAgOg48sf9wGu7hrFw/N4t2iyeu/L+7mP7vqK8y46UBiCQcb0oBBGZpFAxaVaBoNWsrBBjRgrAytS4MWl2hEOXLDwfo0YPdkuyfb/0Y2IqCKbIRgIRWr60ui+ZBtSAgW6fGADu0IbuhSklmE84iXunOxb1r3UUxGts2I6Y+p0B5QLlqgM0Jq71JGBh/c023HaRGR7dRfDnyfKLSXeWQnI4MIbWc5cJeWiPjtBc6J6zhEoa0HlBmJCvV52ATGbTq0Fcp5ZLYHGllwdstYY2SxvaCcSA/WCNEMytBuKSMVC+OoVhxGioVxWisOU7XCmNWKQ6ZYGNdrtlixMN6qEViFolMqskI8sqRfHJ8orcTwMnJxM9STq2OlKgsdeniVj2OQqt3Z0JPwouB7dXawt6e0jMQWz6Lg2//643tPIdnQcnX7iwns4FxpFWajaObzsfb5ovNMJRoKxo/7N37CHMiWWlKyCUumJdshms91Uq2FkhYiq2WvRbOcwJU9HiJkm+o4FvAjLZ1hpZlUzJKQbV/oJhDyk41GHx82R2tXZYlItnemNG3+tbH2dIbQ8C9XIDkUSu64GaAf0EB2KHTXzaCammNh0OzSapA2ub2Fxtu6p/1ZoqZM8olPkjYAvt9cO1dlpLkhhNZZbZA24LJr9qnxRP4GEUAGrA=='
_TARGET_BITS_PAYLOAD = 'eNrtWTFr20AUVtCgUWO3aEv2diqUaA409Cd4aOlSgrc4lMIZMnRrIJlCKfkJmaoMosiZQmihY6BCxKGlGUIiRYbKxrJepZNoqe+eIpPzo0MeWEZ6uvvuHe+7e9/pdeYB2EMobItfbX6FS371ypsBbPMbL83/dC0DqVlaJHeA1kUchpbKHbbWR5ocIc/BRIYF7B3WZIA5Wj7W2bdfiOMU68tLMM/ktlD06Qll1QOri4Ry0xNCKf/8pdG0pwRprQiOhI8sfzyGsLgbFw/j4t2iyfu/L+7nv7Dqy9a4pUBiBgfr0oBBGVpEA2aVaBkNms7BejRgrAxtSINmlmhEObLAwfo0YPdkuyfb/0Y2IqCKbIRgNhWr60ui+ZCtSwhmpWaPDm0LFuhSkkWE84iXunOxx9nwu0lGtmOLpedUaBeUixakjJDa+5SRwSt//TAIJkRkW3evHNclCu0gj2yjkxChfbxy/OtrIn57TrDhBwFRaKcOZUaiQn0e1oL2mA7tknIeWehBRhZcOEnOGFlsnygn0oMzQrSEMrRbykjFwtiqFYeWYmGs14pDXa0wZrXikCkWxvWazVQsjI9qBFah6JSKLBuPzOgXxydKKzG8jLw5tlNjcVOpykKHbi/m4+jpanc29CS8KPg+vNjZ21NaRmKLZ1Hw7T59+GigkGxouXq4FgPbWVVahYUoWvy5nT1bGX1RiYaC8eP+k2WYA9n0SEo2YcmMZDtE87k2qrVQ0kJktew1a5YTuLLHbYRsUx2bAr6V6TOsNK2KWRKy7QrdOEJ+sk7n5c/maOOqLBHJ9iaWps2/1s6+zhAa/uUKJIdCxh03A/QDGsgOhe66GVRTsykMmj2JGqRNbm+h8bbuZX+WqCmTfOKTpA2A6zbXzlUZGZ8IoY1+NEgb8NkD9rzxRP4GO0Bqig=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_000_110_222_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
