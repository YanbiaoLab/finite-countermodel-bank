from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_000_122_122","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_000_122_122","model_table":[[0,0,0],[1,2,2],[1,2,2]],"priority":315,"rule_id":"false.finmodel.setcheck.fin3_table_000_122_122.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_000_122_122.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWbFqwzAQPdmhdqHEdqYOoWmMC/mEDqU1RkPcqZ+SMVs8eEigS0I+IJ/iqd9h6A947FBwJTkN2JEdhYgO5R5GBp10z2fdO4FEQAU3MGNtSMIBIP4ABane307DkOw78kVzyrspXv3HzKwbdoFwFqwp7dUtD9e8vV8Fvl832GCw9gqgBy7ABISHmI/lMyj9/RgI2bhQPD1cNAQCgUAgEAgEAoFAIBCI/4xy0WllGOkjy0un08pg6mP7LkmnteyO/Twk5UunlcHRx1aUVqeVgehje4a2ZclK1nyNqgj1kGVW3rYsgkh8SqErK2+t4SyTBsfPYzNizaGAnLAhOgg/E7M/lwbNiR5zcOAOnmAOuQYZ7II1HXiexLKZ+n40iCldLl1v7Ef2+PJD4G3AvRrHhpATTf3V0vY836fUHqeXi21DuVeJRRDFgcfDoumSkbkXs71thFeJRRDxU/j9r0xd42K21wH3KlGvOO7nlwFp9StTN9IgtqoWOi1ia5RMR7ZDqBear30tlMw4LjCyYXlnkW2KTbSzjDgysTUcJ+ZTs4uJPrFY7VMUG/lVlnEsNuM4berBJect6TY4KEsiNkna1LvcSh1uZCuJrfXmSjFtxGZrqe5srRdoamlz3lb0Ufm0hnnDuVraiFpdHP7QCYSxcShRJ3NE0rUvM5GtpLhJ3JJramkTVmWG7Q1Ksf0AXS6kdg=='
_TARGET_BITS_PAYLOAD = 'eNrtWbFugzAQRerQkR+oxHd04lPyAVWyVGoGBrplzKd0Kh0sRKsM/YRIRaSpMnQKUFUqVAFfbUMiQQx1hNWhuidkJJ99j8P3zpJNQQWfMGdtQIMtIP4AJq3eZ2nL4NYd1m17ynUhXh/PdtE0jELhLJwQsmtaXr54+3oTRlHTkEHJ2m+AHSQASxAePD6WzyBk/zEQsHGBeHa4aAgEAoFAIBAIBAKBQCAQ/xnGba+VYa2PzDLSXitDoY/tzKC9VqM/9tPgGo+9VoZUH5tp5L1WBqqP7Qm6lsU2WHO+riLUQ2bnVteyCCLxKaaurHzPN3NbGhw/j7VpPgMTLMqG6CC8cIuPmTRoTvRsQQpvsIAZWBpkMAonZBvHEsv4IYr8rUfIdJrEq8jPVsMPga9C7rU8NgSc6CG6mWZxHEWEZCtnuNjGhHuVWASRF8Y8LOJMGVkymO1uLLxKLIKIn8LXv9JJysFs91vuVaJecdzPLwOc6lc6ia9BbFUtTDvE1iqZqWyHUC8053UtlMw4LjCyYVZvkW2LTbRzm6YysbUcu8Wi3cVE7+as9imKje6VVR6LrTxOm2Zw7mlLehUelCURmyRtml1JpY7Ez5TE1nlzpZg2YrPNVXe2zgs0tbQ5bSu6rHzmG6vlXC1tRK02D3/oFwReeShRv+aIpKsuM36mpLil15FramkTVGWG7Q1Ksf0A70PMsQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_000_122_122_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
