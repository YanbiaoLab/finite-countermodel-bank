from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_000_211_122","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_000_211_122","model_table":[[0,0,0],[2,1,1],[1,2,2]],"priority":290,"rule_id":"false.finmodel.setcheck.fin3_table_000_211_122.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_000_211_122.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmU1u2kAUgJ9/qB0UgY1YdIESbLkSR2CBWhfNwu6q4QQ9At2xiJRpRBQnK7B6gKgnsRSp53Bv4CWLCDozJlaxxwgSj9VF3sIGj/Hn92be33AjuTJEGlC5ZMcokuip69OjO2HXTmFKv8guHXrasBuKEm/a/AHYXJUMrDYKfyDanJf85CN5Ay4nkSDmcvB3aA0jHui0Nx1yIQ+OdefYNmfkw4nvmCbHAoPQC1Xes9x7T2o4vJFQbiLV4avCpKAo3l4oKnraY6eWVlDFk+nJ8eX8iM8oDy5yc0M60AvvAFQwADxAVK8GvZc9KbtP6m/finwkM8akZD6rlhWDXdUDg1S1dj2wOKVJ9dCeGOxTPTCcqqbVQ0tSWk1rZM1g5/XA3pztzdn+N2fTdmyqCHa2HZteCXa28x2btgU7m7ITwMQuzX9Mtxa+NGMlYYAVtSdTMxEYMC9hzZYkBaX10lrcqqSF2TNIfFh+LnVJfRiLD8u/Ja2XAGi9WIqxMoIZJBBLWIwbREPCOAMG6k2xBm04g1FWEVcs77UMNI0k0TlHuVWmMMOPRBfWd4ywwOD8Lc5AkTQkJiTLhphSkPx0Qs+2r50wCBaoY5q2jVAQGGNdxLzhEHV8hBiIYsdoHuimOdYtEap9JYi7QGcgiiVqmZZNYKoI2pcO7S8/UxDDpqbUrbkImOvbtM1lIIq1UlNac0MEbeBnoCWdOrHOljbqrI2nUycLhT144dxBiDbZ2PEBDJO7R1CRdP0M5I07dJsiICIqs3UvkHljTFzpBJqDvuTKWIUTsMXQFvb94JcxZiC6a+LBAshHVQxtgjIQ6l7o1lY7Mbq5k77d0OWBYS6gYcudvtSfGwvAWAjNa2YgYymrElYNdVFHGVnS0VVY58V7K/Cqu4+nvRV4xd0H3luBV919JHubw6q7j9KNW9JgwbZWr66M1Ii1+C9Puo+o4k2hbRnJEbrxTCraSpVTtF6Lr/QfctBiUueRz8qsmsxWuhNOs6pdMvbyMtJZIsSJ9i4tiErGXuxs5O19fvAMVZJeHYtUDZhkVr2azMZSKEca3QUYF8ias8TagSoyeelfC2y7357gPkms1wRWkbMB8L17VYz7vNuOCTSrbSzk/KIY93m3xcdscyhMtym0oM1xttyDp8VL0uioMpKVqeFinl9zoVPQww8Lyh63Vp0G8yzUNHJO5f4IsMpZNrkFDaS988B1D94gYQYpZsukMB2vTgalf6Bxnv36ZPAuDce3xdX3WJi1IWicbDCDg9O6u1SfQ1R+Pjl/8XnjYsRERA4vI9MQRcrInGqymY9mrLzNvxPu48ND9l9eWI0c'
_TARGET_BITS_PAYLOAD = 'eNrtmU1u2kAUgEFZsPQN6nNUiuSTVDlAZbxKiILSidQFu3KEnoB0VXsxom7FgiMg1bJJxKILhA2KiB388zozJlaxxwgSj9VF3sIGj/Hn92be33CVmDEoAVD5zI6KktDTXKdHc8CuPUCffolNOnTSYDcURW4s+QPQuCkZaDUi/oDSuCv5yS/yBlyOlIDM5aAvsBorPNDDrD/mQs4s58Kybc7I70fdcl2OBSaqoYa8Z5nnRrKxeCNqvMahxVeFSUFRtL1QVPRhxk6roKCKEdOTpcf5EZ1Rzkxs5oZ8oBeeAELwAAzAVK8NvZc9KbsvmW7finwkM8akZD6rlhaD3dQDg1S1ZT0wOaUl9dBOGOxnPTCUqhbUQ5NSWk1rpMlgd/XA3pztzdn+N2cLdmwaCXa2HZveCHa2ux2bLgU7W7QTwMQuzX9M1xS+NOVIYoAWtSdTUxIYMD9Dky1JCkrrpaa4VUkLs2eQ+LD8XOqS+lAWH5bfJ8FMAghmciKjaAQ9kEBOkBg3UMaEcQ8MNOujAJZwD6OsIq5Y/gQZqK8konNOdBn1oYdOiS6s7xghgcH5q5yBlGRMTEiWDTGlIPloqYZtX1tqp6PhhevaNsadjjf0RcwbUvFCx5iBKHaIux3fdYe+I0K1bwRx0fEZiGKJWq5jE1gogvZ9QfvLHxTEsKkpfacrAmbqNm1zGYhindSUTtcTQZvoGahNp06ss6WNOmvj6dTFQmFnhtq1MKZNNrJ0AM/l7hFUJHM9AxnDBd2m6BARldnmt9i98gZm8gjryTQxYxTCI9hiaJp9PvngDRmI7poYoAH5GIqhDXAGwvNb39lqJ0Y3czC1N3488VwNNna8mCbTrqcBQkJoxjoDee04TFDohVodZWRJR1dhnSfvrcCr7j5O9lbgFXcfaG8FXnX3Ie1tDqvuPko3bkmDBdtavboyMiDW4r886T6UijeFtmUkR+jGM6loK1UuCmYrvtLvyCGQSZ1HPke9ajJb6U44zap2ydjLy0irjTEn2pu0ICoZe7GzkbfX+cFTDUl6tRxSNSCSWf1qMhtLoRzZzDXwbrHTZYl1AVVk8tK/Fth2vz1AU5JYrwmsImcD4Ht3qxj3ebcdE2ha21jI+UUx7vNuk4/Z5oiYbn1YwZLjbLkH94uXktFRZSQrU1Wtm19zqlXQQ1cLyh63Vq0N8yy89nJOZX7qoJCzbHILGkh7Z4BpHrxBwgxSzJZSYTpenQxK/0DjPPv1yeApDceXxdV3Wpi1MQScbNCDg9O62Q6fQ1R+Pjl/8RnDYsTERA4vI9MQRcrInGqxm49mrLzNvxOaosND9l/uGeQL'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_000_211_122_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
