from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_001_000_000","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_001_000_000","model_table":[[0,0,1],[0,0,0],[0,0,0]],"priority":310,"rule_id":"false.finmodel.setcheck.fin3_table_001_000_000.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_001_000_000.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2cFKwzAYB/AvNdAPL0tl9yVhh/kUi6HCevSJzKRC5mn4CMUH8VF8hB13GNZkXkQNbmAGHd8P2pQmzZ8k5NIwAHDwl13PgJzOpt/7WeE+K8rfliiaH5NyDaiLsLD8e8W2/6pMfe8kSC4NLRchhBBCCCGEEELI+etTygxhb8m0HEPbpcImGcJccmgXGdI2qbD7HBP5nkobZQh7TU5kjj/Z21TYfPCbjfyTtX6adcJWt2M767zFR3GpwiM+yMEPLb3ZyFEmJ122F5AeuakZBye1iAdB2IrCgeygACMqhFByi8yAuAO2bw6hLFQLElCNw92EjiRYXMa28ShxKSyEvuIV69iN4OyAI0ZyINPo1VTrhV55bKZVpbStW4+qFc8Lre1VU9fei/gaFR/Y2D4AL7Ns2g=='
_TARGET_BITS_PAYLOAD = 'eNrt2cFKwzAYB/DKDjvuEXwUH0T6COLJBSwuPpHHDiwxewp3GEl2H2t2ka8Qm89kXkQNbmAGHd8P2pQmzZ8k5NJ4ROT4l1HhkZzOpNj7WcE/K7rflihaHJPyiqD6sLDue8W4+KpLfc8NGmckLRchhBBCCCGEEELI+StSugxhl8m0HEMbpcLWGcJ4cmjvGdImqbDHHBN5kUrbZQi7Sk5kjj/Z41TYYvCbjfyTW3W3LK1onzdiWTIB9/ZNh0d4MIMfWnqzkaOsT7ps12gYONl4h9woGw+CoLI9R1Nij9K2gKF0ArxE+4R+3xxD2esKDYLehLsMHRkUMItt41HizAoMfcUr1vkX6/wBR4zkQLJW05VSczVlUK/aVivRVAx0ZW/mSolt3TSM2fgatBvY2D4AHM0EXA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_001_000_000_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
