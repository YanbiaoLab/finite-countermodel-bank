from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_002_112_102","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_002_112_102","model_table":[[0,0,2],[1,1,2],[1,0,2]],"priority":296,"rule_id":"false.finmodel.setcheck.fin3_table_002_112_102.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_002_112_102.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmcFu4yAQhgdEJdITtvoAxGKlPgaNfLB76iORVVZKblmrD9BHXQac2DKgNhtPtYfl4CrBzucZZoZ/6C9uAWzPwY93g1f7glc4hKsNV3gCHT5YHm4buqbhkIwP87utqyqdgB8nMxyPmYnn3j/TinTC9s3JNE3mkdcaMvf78TZYzWRmwv20tcw+9CQuFi6GFsoCy81sHfAcBCQDlf0tG5yXG7zwvTclznfLO9wgCo8+xQkxpKbEiXNiabRP7xPPRDsuVsa/LtzLlqYlK4brecDVVtW22bUHtZNAMGLgBNAZg65p2tYzd5JR0GL8BhDGvjfrKKtqJ7cUsDGNAqjug1noSrkVFLSYzQHUNSc0C10ptwcKmBvaK6g3VYyQo4cpCtrbMIEwNEdXHhSnoL3WV1AIzehKH/8UsP/J9j/Z/slkC7vEhsR5abKF8CNnXbWI95szoXZoQtooiYRycBZceZbFzZfT0GKyOetBQ+chwklvp6WBfRiGvxzl41g76Fz5bpS3yGIORGHIgAtBBERhdq2G5CE5l7p7oYlpj7zXoDCrudmDdUepQjyShKR9mUBGgVQV4xiPNCH5LBEUFK9PtqWkXXs8sAuITRxGBPvQcYXsXMuTjYPvirBSMQFSu5BrPg2IsE7NQOJaIok8qfgEcqNZiqxu7WYgNZrFqSqKlTMQj2bZ2OoRDMkQNOswScfYqCMwNuyOEKbFCNJTRmvCZJsyi7r4e7dNFYSRA9UCRLuV8m/csy8Vnx4E31LxMzIyGz1Xwbd2z5aZqXEPQsG3es/GC+sp9cmtuPGMPRsUaatucrOeLTvWDdXiwa12BqBwDvz3PRsvCWOHbVw+Wu+VkXkXOluvWjYfSifNAaS6VXV5+SQ8JBvftHDRDavJyGz4B8G3X1NZOlXSjAG0MYqtqBtU8Z3xuCScwrfrVe1iDASQOa98QFJqnTKlk2fj84bUf+5Hry2TIFv5cx493pZsedHTcbaMDKs32f3vFhlZoLHEWmBG3bLwN/hcF8Lm3gMSzAIsUZ+/2flO2vgPtC8WpXu7kcfodN6XNN+yRn/F4+WebSpRCzNssvq80/CFl/pURm5MGmhJrNv0Kx9jtyTbHzBt06Q='
_TARGET_BITS_PAYLOAD = 'eNrtmcFu4yAQhh+1D1B5c0ukjTY8Uk+1D1bKY1Ra5PAAlc1pg1QEsww4sWVAbTaeag/l4CrBzucZZoZ/6E/LAXhtwY9HgVf+glfYhysPV3gDGT5wG26rmq6zkIwH8aPthyGdgN9bUe12mYnX2j/TmnSC191WdF3mkeceMvf78VRx6XRmgv3ivc4+9GYuFi6GNIqDy82cGNgcBLQDlf0tHpyXG7bwvTclzjfLO1hlCo++xQlTpabEiU1iabRPHhLPRDsuVsa/LNzrlqYlK4brucfVVsOpO7Z7ddRAMGLgBNAGg67r2tYzj9pR0GL8BhDGvjdrp4fhqE8UsDGNAqivg1noSn0yFLSYzQHUdFs0C12pT3sKGKvaK6gWQ4yQnYcpCtpTNYEwNEdX7pWloD33V1AIzehKH/8UsO9k+062/zLZwi5xJnFemmwh/MhZVy3i/cZEqB2SkDZKIqMYbIxVnsVx87U0tJhsjHtQ1XiIYdrbyWlgD8LhL0f5ONYOOlc+CuUt4pgDURg6sMYQAVGYXasheUjOpe7BSGLaH1tLUJjVVhyAs51WIR5JQpK/TCChQKvBWYxHmpB81QgKitcn21LSrj3e3QXkJo4jgj3IuEJ8ruXJxt53RVipnAEtWcg1nwZEWKZmIHMtkUSeVHYCsdEsRVa3jjOQGs2yVBWF6xnIRrN4bPUIhnYImnWYpGNs1BEYG3ZGCJNmBMkpoyVhsk2ZRV38vdumCuLIgWoBot1K7Rfu2ZeKTw+CL6n4GRmZjZ6r4Fu7Z8vM9LgHoeBbvWezhfXUcstW3HjGng2KtFU3uVnPlh3rhmrx4FYyAVA4B/73ns2WhDHDNi4frffKyLwLGe9XLZvvpZPmAFLNqrq8fBIeks2eW7johtVkZDb8g+A7rKksmSppxgA6C+VW1A2q+M54XBJO4dv1qnYxBgJIbFY+ICm1TpnSabPxeUPqv9aj15ZJkK38OY/ubku2vOhprFtGBpfn7P53i4ws0FxiLTihbln4G3wuC2Fz7wEJZgGWqI/fbHMnbfwH2ieL0r3dyJ/odFuXNN+yRn/G4+WebSpRCzN4svq2kfCJl/pQRp5FGmhJrPP0Kx9jtyTbXxwTnYM='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_002_112_102_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
