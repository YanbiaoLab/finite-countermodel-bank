from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_011_012_012","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_011_012_012","model_table":[[0,1,1],[0,1,2],[0,1,2]],"priority":293,"rule_id":"false.finmodel.setcheck.fin3_table_011_012_012.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_011_012_012.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWc1y4yAMlhkO9Eb7BDSTB2E7PuSxyEx3psc88gpEABPJsdOS2UN1yDiW8Yd+keS/4A14SPSZfj04+qOMQ6YLoEDD0SLHeJg0/hHIiZwpCAwzaes5RgZmiG66W4YlDr6xYwQS0CTuYq1Ob1tysyi4rYlUEGU2YMGlB99xW/ivckNcpq6iNFygZUWHhQt5GXykzTbcvAyyBG8nXK2mVhTiXLx6TfDQiRK0ily8OlztlEVh4EkUBh6F0QAhq9tMUQB8JEBnEw0uQtlklD/wTDLTM9FE/x1B2WBPos/Oj4ZSVqN5DpqYEIaQqrlFV1EHke+A7OBgE1LbEBIz7MBgYxL9uGAjIFfy7aBwCLYB0iXtD8os9k7M/yx9iNsYkDo9ODHm2+rhJ4ON3cYAt6Fg47YxwG1cW8EtD9gtbuP3BlvRWreN28qScZt9mUA+2bRUwt5RwEMnG2NNTgH7TCqebHYRAyAW2TcmtbIq5JONCbbFvu5j3BrTdEDLR7ueQFCAhGGEMnK71sIOjOk22Ow+rdntGG77ycZ1N0zzVIKtLixOSg0RMUkv4snGdDnM0c5iEJuWADGzXlQFCqX2ccD2eowCWIza6FW5LKz2hIzWGAVwGEUVrVwK1lpTTmuMAjiMoorOeCsd8ja34TCqAy2Nt9aob3MbDqM60NJ4K2XkRrdZDYSl8X6D7TfY/rdgE0uJi1c0x6p0cvj0i/5OzyZx3k5OefUyN7dejnaSRombSEtrESgL8wqHvLMz/sRRaTCPFcw52Bg6ubMhYZTX+Pp3Nv72DkiSHzCUgM76ADN8AV7qH+j+xcEtApHWerdZVFBxH3T1usGantYyrdTxgvpblsnJbZZ6jyad45RxU60slpHMPDYNdE+ulSOiE83Xaqs6ENb6fmMZmYCi1qKEV7cBCrZ1jMnVxtpsHJCMyFriyTYia8kn24gSQTzZhpQI4sk2okTwYmK3p5wn22DrP2rgq2dyWD9fQy3ICSaP/pnEroynPNnm6Bm6JEcK9Rs7fAo2JrH7KK05RlivxWCrctiy1YbZSSl/q0HrTGjSYgTNetIj00gusUcgfPX1xQH4r0QPjP6ZxO4uMU++7RgpxkOQrg7CRvKAhEns8TNW+nx2Mzjh4eggwPdl1StxQMIk9hCljTEA8cju5xhNpq2nQ8ncX1X+z1YXuYxkUhRaR6UYyDYy7K0qRwmEltkkEl+nkYyvxbeibksQTewtBqNlNokkKuMfBuEFww=='
_TARGET_BITS_PAYLOAD = 'eNrtWc1y4yAMfuQcO7OdKY+Vg6flQTIpT9ByKwcGawUigInk2NmQ2UN1yDiW8Yd+keQ/oB1oSPSafjUY+hOcQaZREMDDySLHaZg9/hHIiJxZCQw3e6s5RgZmiG6aa4YlDr6xYygS0CXuYq1Pb1tysyi4rZlUEGV2YMGkBz9xW/ivclVcFi6iNFygZUWHhQt5GbynzTbcvAyyBF9HXB3mVhTiHHT4TvDQiaJ8iFy8Ol/slEVh4EkUBh6F8QAqq9vNUQB8REFnEw8mQtlklA94Jrn5mWii/46gbLAn0WvnR0Mpq9E9B01MCEMo1Nziq6iDSHdAdnCwCaltCIkZdmCwMYl+XLARkCn5dlA4KNsA+ZL2B2UWeyPmH0vv4jYGpE4NRoz5tnp4ZLCx2xjgNhRs3DYGuI1pK7jlAbvFbfTeYCta67ZxXVkybrMvE8gnm5dK2BsKuOtkY6zJKWCfScWTzS5iAMQi+8qkVlaFfLIxwbbY122Ma2O6Dmj5aNcTCAqQMJxQRm7XmtqBMV8Hm92nNbsdw2w/2bjuhmmeSrDVhcVJqSEiJulFPNmYLoc52lkMYtMSIGbWS6hAqtQ+Bthej1EAi1EbvSqXhdWekNEaowAOo6iilSvAWmvKaY1RAIdRVNEZb6VD3uY2HEZ1oKXx1hr1bW7DYVQHWhpvpYzc6DargbA03m+w/Qbb/xZsYilx0IHmWJWOBp/+8f/Ss0mcr6MJOvxMza2fk52lUeIm8tJaBMrCfMM57+wNf+KoVLn7CuYcbAwdzZsjYYL2+PpPNv72DkiSHzCUgN78GSZ4Abz0D+j+xcEtApHWerdZVFBxH3T1vcGamtYyrdTpgPpblsnJbZZ6jyad4pRxU60slpHMPDYNdI+mlSOiE02Xaqs6ENb6emMZmYCi1qKEF7cBCrZ1jNnUxtptHJCMyFriyTYia8kn24gSQTzZhpQI4sk2okTQYmK3x5wn22DrP2rgqydyWD1dQk3JCSaP/pnEHpymPNnm6Am6JEcK1Rs7fAo2JrHrKK07RVjtxWCrctiy1YbZSSl/q0HrzGjSYgTPetI900gusUcgfPXlxQr4r0R3jP6ZxG4OMU9+7RgpxkOQrs7CRvKAhEns8TNW+nx2NTjh4eggwPdl1QdxQMIkdhWljTEA8cju5xhNpq2nQ8ncL1X+11YXuYxkUhRaJ6QYyDZy7K0qRwmEltkkEl2nkYyvxbeibksQzewtBqNlNokkKuMvRZ9rcw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_011_012_012_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
