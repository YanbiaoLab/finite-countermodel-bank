from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_011_012_110","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_011_012_110","model_table":[[0,1,1],[0,1,2],[1,1,0]],"priority":297,"rule_id":"false.finmodel.setcheck.fin3_table_011_012_110.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_011_012_110.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmcFOxCAQhofJmOCNbnwASjj4GMRw2L35SGg81Js2PoCP6tDK2tpt0sbVVXe+w6ZlOwUGGOanCma4IsO/Ac6TV/9MaFQbwAHyfdLlnwuVHWN+XYsfALiNKV8euXEaBEEQBEEQBEEQBrz4duvczWYX4xZVA1VlMRDUZB+9c/4OYmq0URaTwacsrTqREot5wxYstXQNRpUyVy7YZFxZauO+op3tLAkasAC5IiDDMqhi3RazFMJpY9Wqrt22fUVeVfaSLMbIarDTgITvisvuH8Yims2oqCMckFR4RnPkWlv2SvIGdBp1Pmx2QGE0NOxpwM6tqZibSrnswzBw9+B8gj7VVnfvN4v0LE2LUNb0/6cfZLvoWTkGEb6ddD8XeHSepcqrY57Kzh8UKo6INpEMyDK0IhN4p0JdBof6eJH2bh5nAdqmfq+jcQAiWHB8W89FJTPduHQZTeHEcBJrD+ca+YsCzwccrsnDqcvyxHU2fbFrDRYQ5nfIMHn1l79O6I8QtaaDwml3tp9dbOLwv8gbSa4oPg=='
_TARGET_BITS_PAYLOAD = 'eNrtmcFOxCAQhh/VBzDVmz0Y5ZG87R6I4TE8EMoDmC03SZwM49BKbe026cbVVXe+w6ZlOwUGGOaniRZ4hsC/hs6TC3sFGFJlyBHyvYrln9eUHRN+XYtvibiNKl8euXGRBEEQBEEQBEEQRlzaauvc426j9RZTTW3r0QA14G+sc/aetKpjSB5VwOssrTqRoot5zRYstWJDIZUyVy7YZFqZqvRQ0cZ3lkA1eaJcEUFgGdSybtNZCuG8semgrj1UfUU2tf4FPGrNarDTgIDvissPD2MRzWFS1GH2SCo8oznyFD17RdlAUU06b3YbAjMZGvY0YedWVcxDm1z2oRm5e3Q+AZ9qa7r3h1V6FuZFKGv6/9MPsl/1rByDCN+OulsKPDHP0mTTMU9llw8KE0dEr0AGZB0xQTC8U2EsgwN9vFCDm6dZQPSq3+tgGoCAVhzfNktRKcw3rlhGUzgxnMT6/blG/qLA8wHHa3J/6rI+cV1MX/yhBiswyzukmb36y18n4keIOqSDwml3tp9dbOLwv8gbAtJI+A=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_011_012_110_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
