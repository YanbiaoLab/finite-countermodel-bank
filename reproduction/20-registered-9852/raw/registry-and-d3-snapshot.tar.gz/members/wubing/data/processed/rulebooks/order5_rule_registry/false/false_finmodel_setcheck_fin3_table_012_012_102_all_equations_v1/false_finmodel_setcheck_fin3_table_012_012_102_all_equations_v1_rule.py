from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_012_012_102","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_012_012_102","model_table":[[0,1,2],[0,1,2],[1,0,2]],"priority":291,"rule_id":"false.finmodel.setcheck.fin3_table_012_012_102.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_012_012_102.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWVuO5CAMNBEffHIE9ibsnoyRZu+92Dg2SYpMeqSW9mOQZtQdktgulx+4/7aaqFb6IKJPypW2WgtF2j5pS4VqKo02irFk6l8qhdi/5NTv3gJRotCIP1f+X2K/N4+X8I2+wgdlSo3vkmdj040UYr+dYm4kz3aJ/UOXqIL7vyi7FFiN/hbattRfLTqyUnx73+I3s9SuUexXQyz9rV2/3PdbF5woirKhUJatxk/G2J8p0y7JHsXCaoUBAZvCL+KPRL+6WommXdVNTZl2Vb5haLu7lfRHlJ129THKuTtBYC2Cc38Ra9ZVzv0NdWDF4n0NUyh2TQRnBoiGV0QdIH6YAsSPv+GjrRsmuLIX5N5JJmNH4hSi34NE7JPG3nYd2OWCsdwrL2A3yO1irdFkGMSYDdVpJtFhpWDUEPN8MT6MuC9nkpqY5zcNP9WdLhVJW/JX3MR81BAYe1UAEFiq2mJPNJOeHctME67qMA4jdbYo3eV2hwehtl6MiG4vrhHnIkjcrDwPI4YEtXGxSwSsf2215mlDUCsjfp/SxiDzEJbgcP8H5dRtQnhGG4XUniv3tm3byC09Lw0KqFe3Z7SpYvrRnFBs03b1Qp0EHbhmudmJJoI+vpLhwZbogMxNantGG8/dlt6nYAt7DqiayJcZVgRJDJhnQH0AMjyCitWLNASuE/012ECZQjIcCrcrDAd+ToKKKc07V9Sslt7LMCjcrjIEtjwJiqZ0gKiBbANkOBRuVxwCtWRZbTaSNUudqh7sHTwTTA/uEWTpw2rFH3ePNBC2PHWqrok8CcyVSzOBP2hl8bI02KTb4PrqMTN1D6N3KCjYrEPxyuZQHDLWfUv0iDa727apshkUR554DwC49ow2SIbmyjP/OTSL8ODa1oB+ANCm7qkptKln8HTv6Usrm3WiQgHVuqB+ANDGM4EHgmIR51AbmK8rG+foQRvzPgJg7zy9IkytUbUc/UVlc2+aZxAA5lIP6Kk1OvCk3lQ2LsdhxMDuGdRka9zm+cG9XG2aq3Yjt3VlA8Hmet3LGPqlqhCqkRyiaRLExvit1zMBAgDJMCiMKTR8PdrIh6gBAKCMHQoHsYyIKpOgL1EDACAZBoWDOMi+rGzodAMOTxZs/qCR9FxubiobOOWA0g5laNpq59juweaCmqVI2b2e9QAAUMYOBR17oLszIUANAIBkGBSn2L45miLUAABIhkFxct7NCfkZbZAMJ9DReXcH9We0QTKcQEfn3bSRD2lzGwin3u4n2H6C7T8LthBs8CTNjR0/wSXQI/mJ1HvlsDxvr+eMNsrwJpTPCaexFZgC3UxPdLDG7Vot8wwCtAg2AZsO2KDn37PGPtSbVMverh1PuuASYNJrS4MNnHTfMWlaDm7RLJd7kZxmrLwN8cHZRKBtHgBxsPnhMI6uUI9FRXqrLR0PjWcmWc/v0X6zlm0kmMcCJt1PgbbzTHLZRr5j0rSubO/IWsvK9o6sta5s72gRlpXtLS3CsrK9o0XQ34+Ea3KSN5KBGS44/DphLdrbOsHo6B+MddEM93rJRxxm5M0awQbOfiiyrpfQuH/aPFmpwQYGLSBHAyZ9a/QPpprXsRL6leg7o3+Q2MHoH1yyrHUYC86/EMVpCKQDEpDYr6N/MDO5FoJtQmcx+geJHSRkkLYPdoAfio480TYSpCg0w71eem0+rtNIwDUw+geXXpuP/wNqW5Fm'
_TARGET_BITS_PAYLOAD = 'eNrtWVuO5CAMvPeONJxsl5ssR+CTDxS82Dg2SYpMeqSW9mOQZtQdktgulx+4f4VYKEb6JKIPypG2GBNV2j5oK4liSYE2qjVl6l8itdq/5NLv3hpRoRaIP0f+n2q/N4+X8I2+2idlKoHvkmdr0I3Sar+dag4kz3aJ/UOXqIL7vyq71FiN/hbattJfLTqyUnx73+I3s9SuUe1XW039rV2/3PdDF1yoirItUZatwE/W2p9J0y7JHtXEarUBAZvCL+KPRH+7WoWmXdVNTZl2Vb5haLu7lfRblJ129THKuTtBYE2Cc38Ra9ZVzv0NcWDF4n0NU6h2TQRnBoiGV0QdIH6YAsSPv+GjrRsmuLIX5N5JJmNH4hSiP4NE7JPA3nYd2OWCsdwrL2A3yO1irdFkGMSYDdVpJtFhlWbUEPN8MT6MuC9nkpqY5zcNP8WdLhFJW/JX3MR81BAYe1EAEFii2mJPBJOeHctME67qMA4jdbYo3eV2hzehtl6siG4vrhHnIkjcrDxvI4YEtXGxSwSsf22F4GlDUEsjfp/SxiDzEJbgcP835dRtQnhGG4XUnkv3tm3byC09Lw0KqFe3Z7SJYvrRnJZs03b1QpwEHbhmudmJJoI+v5LhwVbogMxNantGG8/dlt6nYGt7DoiayJcZVgRJDJhnQH0AMjyCktWLMgSuE/012ECZQjIcCrerDQd+TIKSKc07V9Sslt7LMCjcrjQEhjwJqqZ0g6iBbANkOBRuVx0CtWRZbTaSBUudqh7sHTwTTA/uEWTpw2rFb3ePNBC2PHWqroU8CcyVSzOBP2hl8bI02KTb4PrqMTN1D6N3SCjYrEPxyuZQHDLWfUv0iDa727apshkUR554DwC49ow2SIbmyjP/OTST8ODa1oB+ANAm7qmphaln8HTv6Usrm3WiQgHVOqF+ANDGM4EHgmJR51AbmK8rG+foQRvzPgJg7zy9IkytUbQc/UVlc2+aZxAA5lIP6Kk1OvAk3lQ2LsdtxMDuGdRka9zm+cG9XG2aq3Yjt3VlA8Hmet3LGPqVqBCqkRyiZRLExvit1zMBAgDJMCiMKTR8PdrIh6gBAKCMHQoHMY2ISpOgL1EDACAZBoWDOMi+rGzodAMOTxZs/qCR9FxubiobOOWA0g5laNoK59juweaCgqVI2b2e9QAAUMYOBR17oLszIUANAIBkGBSn2L45miLUAABIhkFxct7NCfkZbZAMJ9DReXcH9We0QTKcQEfn3bSRD2lzGwin3u4n2H6C7T8LttZs8CTNjR0/wSXQI/mJ1Hvltjxvr+eMNsrwJpTPCaexFZgC3UxPdLDG7VpM8wwCtAg2AZsO2KDn37PGPtSbVMverh1PuuASYNJrS4MNnHTfMWlaDm7RLJd7kVxmrLwN8cHZRKBtHgBxsPnhsI6uUI9FSXqrrRwPjWcmWc/v0X6zlm0kmMcCJt1PgbbzTHLZRr5j0rSubO/IWsvK9o6sta5s72gRlpXtLS3CsrK9o0XQ34+Ea3KSN5KBGS44/DphLdrDOsHo6B+MddEM93rJRxxm5M0awQbOfiiyrpfQuH/aPFmpwQYGLSBHAyZ9a/QPpprXsRL6leg7o3+Q2MHoH1yyrHUYC86/ENVpCKQDEpDYr6N/MDO5FoJtQmcx+geJHSRkkLYPdoAfio480TYSpCg0w71eem0+rtNIwDUw+geXXpuP/wPiFt/B'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_012_012_102_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
