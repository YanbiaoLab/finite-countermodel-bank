from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_020_110_122","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_020_110_122","model_table":[[0,2,0],[1,1,0],[1,2,2]],"priority":230,"rule_id":"false.finmodel.setcheck.fin3_table_020_110_122.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_020_110_122.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WDFv00AUfndxaketGjetoAODFXlgqIARlvZAkYipKjGylQWJEUYkpF6QkIo6tIr4AfkBDP0BDJ6Y2brmJ2TsEGFsn6smuXtRoju/N9iyXs5f3vP3vffuvjMBkPpQ2EF5Tcsr7JVXoR62ICofBM9v02wHjDbO2mYHnO4ijtuhMDvSb8gKOFQ3pjmusRXyM+bZAq+880XHKGbIkibmeIyBiADzcMwxqUDGWihN9UrB9VBK8zpaKOoWDwrvnEeBRMxbXBLM/bPgflm0ELxQfvXFstIaIVDYbQl2Bh0SNBXaJXCK4MYKjdEkclqCHZFggcyONr6kbJY2Ndoku/mw+2KHJjT4l+1/5D5FXIXYbnpwUgiSSGzH3R/nAcQkaKcPkzgnv16WahHbMR94VR7rB/x1EckChqRqybxVhUBlk+z12m3ORmxot+U1iA1jRihqENtQECZykwOdjRsTpNEE5pHOyg7gCV1wsj07PM9aNDOd3dHGFq0adZEyEjlO5B/mP5pQJTJ9DrJB9tn2fVjGPMfybtxH5tUKVNj7qqnlZJO62sRCzLa972c87He73LWGEbENe52k1yPiyNuhiFhAxcg3nSAqskgy/YiXREBqh5ygrhpo02RAZyO4ostjdTaDjQOO9wQyH3IYWXAhJ9rTlPaKkCJ5ySWMDALK0CA7W8qQadvtAcnS18nfTkP7eoICFR/V7bAin7a8JWgsdlrUrlFCeg/ymjZwq/pDvNRvAzxLnYaWoqN/eJXnctvtDrwaI02JDKW2J7WVZkPlUOoUKYH6bjsbSjk18CVOe88eRjnRScBbGFptu5JEOdLnOVAQaZHZAIYoWisOtYHPlp8omDrul273bD5a5Q1cHxt1sjraO/XxLkyZ1AfLluFn52uJrbBPpnauCUPoO+/1Ej2qlLVSP08iy8HZW2PrGVmL7Y4c/kqMsmwG1QFJsFIt5LZi26je0zIeIESGGm0xsws2U6I0tAW+lWeJ3OJUo0Jo6X+QbwL8nXuV4IGBY+uI7T/G7YzF'
_TARGET_BITS_PAYLOAD = 'eNq9WDFv00AUNsrQMT8hazdmJg/8gA78gPwAFJWhohISuUpIjDAidaEbI1JVHKQIrl1gBNSBwYpuYCioTZ2qVZzGOT9sn6smvntRoju/N9iyXs5f3vP3vffuXqQcwJ9AbqfF1S+ucF5cuXq4BlE8cJndGt4lGK3ljcwOOLhAHBsdbnb4L5EVcKJuqebYwlawN5jnGpLiLquOdpgiS6aY4zcGwmPMIzFHswRpaaFM1Su51EMpLBlqoahb2M29Cx4FItKkuiRe+Gfx/TJRCZ4rv/piXmGzCChsowDbgyEJmgrtGUiK4FoKLaVJZKMAOybBAuYd377203na1GhNb3P/4tslTWjwwDt7JycUceVi2+zDYS5IIrEdDZ7vxhCSoB38DcKM/HpZqkVsR7KblHmsH/DJjmA5DEnVYlmrioDKmt7ntducjdjQbitrEBvGjIjXILYOJ0zkjQQ6a82aSKOJzSOdlZ3CL7rg2Gh+eJ43MTed3dHGFq0cdZEyIhwn8lE6+dOkSqT/HdiM7LOdTWAZ8xzLe3YfWVIrUG7vy6aWkY3pauOVmG1739Ow0xsMpGsNI2Lr9IdBv0/EkY8dLtKYipGfhrHIs0gy/fCvREBqhxygrhpoM02BztqwTZfH8mwGGwcc7wlYNuSkZMFFkmhPU9gXQopkJZcwMogpQwNvbylDGiO3ByRLX8ceOw3t1SEKlH9Ut8MK+zlOlqClodOitoUSMvmX1bSuW9Wf4KX+CuCH7zQ0Hx39o+0sl1dud+DlGGlKZMS0PamtNGcqh0ynSAHUc9vZUMqpgS9w2nvOMcrxYQBJZWi17UoM5UhPZkCx0CKzAYxQtHEYaQOfLT9RMHXcz9zu2SZolTdwvWXUyepoH9TH2zFlUh8sx4af7a4lttzemtq5Jgyu77zXS3S7VNZK/TwQloNzssbWU1iL7Y4ck5UYZdkMygOSeKVaKG3Fdlu+Z2w8QBCGGm0xs/N0rkRpaBW+FWeJ0uJUo0QY639Q3gA8XHgVl7GBY+uI7T+FhORi'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_020_110_122_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
