from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_022_010_112","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_022_010_112","model_table":[[0,2,2],[0,1,0],[1,1,2]],"priority":260,"rule_id":"false.finmodel.setcheck.fin3_table_022_010_112.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_022_010_112.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WUtu2zAQHTJEQAMNIHjRRVcM4AN00QMQQRY+Qpdd9hh0ke59hBylR+iyxyn/IjUzthRL5iKBNSJn5nH++g1Wg4W43uJfCyb8UyC1/6GNA+l/HAJF20RhlmEpwjEEDWogCZkxsdJDI8SUMCSKQCe6witQO4qCx6gxopqRl+33JFWGsGcfACqnZ1Wi0JEqC1AFwyG860Ed/Olp2wvs/J6G6lnFbVmDvZ3q6BLlL8ipkioK6xTCzCRxIir9BT1HcUy5U9fdy4iGFnoCy8izuRQL91xa3JMba79brHxhd1pv3gbMvZhlGI/30Y8NCJssOXqI2pyZhR+d226roR4v7w6myUbYDZ0t5roQ8PSmUCZn84wUhKSQw73eyNkGKysjVbPORoGThc2pzwDvp3W5vbBieJ3X9j8LXIDcR6qENa+QL4ki1eTEvJKOqQagxNjAbPg8s9PYbNTNzsaJgSvLwd6oYI5R/3B4JNTY4wtexj1ntodPuNRFtxmjzfQeFl2pXODzerkyhJWTqAUx/kxQU1OjctcDEpHZgsBfCWfD1qsYAOS8zCbKpkdoK+aKmunMxjE8JhtpAzJJo5TZ0Ku9MiOjeTzMHCtnfX4ocn3c2bgqJKKmetQCAPKG1D5wHkoURFbucowmAFDznY2yNYtQO4bXdqoHQFfhRJHfXMlslK1h1KKzna7xGNtehBlbRsbge8So9YmwdQQ1x9k61NpGHUWO2LmH1rnVowpX1LzobFwZGRm5HjU8Imh4FBFEEcHAtALOs5lqa6KcRPTyHABVj7rR0UbqhqZe7eoBYqIxlrf5YVPjNhuLmi4BrUclBzkycnlnftUzOtt63ABUHU3zGKcq2SjLiOUlMTp5+iEoo+urkZGux0myICJ5VChavWSaA53KpEddRY0AgOJRoWj0SuFeHOr1XEWNmkARPCoU0F/ehYx/zjO0VXs21vu/hGL8Qa/KTnG53f56qqqvNUFxwBWiP99F9vb1WsbsbMR6MiCMUAZe06Wv0W2wg1sTYuRh5Z5N58CObOGbA7X2REFPqqimi/Fanycy7Niqd+6ARLTl2rj3jI85Yst8/UjPRkzCa4nQ4HC4sfpXI6OjaZNg3/x+pGdinS2dqiBH3sqIKHDVvL7okrPhwM5Wlkw9PqtpZD8tUCUCtqSLNb9irPeIBRq+e0aPHVD4o0YAfkGAyaP/EKIIP+z9z5LJQC9ytijhiXFZfcXZ3EJn477VUJKpG30gTSMJW+PCgFqsEALivMBrbpjE5gFJrAdgzqU4/EVtSWYTgGJh7gfpPDg1ngX1g03tRAxRGneIQDzSbUNhFiUbLWIKxSMDCljpnc2H1FrFiqVjyv/K/oyD'
_TARGET_BITS_PAYLOAD = 'eNq9WUtu2zAQPU6XPUKPkiN43yDmMbrsskfwIgh4gC56AAPlqosuDAEpYCJgyCn/IjUzthRL5iKBNSJn5nH++gpSg4S4HuNfCSr8M2C1/6GVAOt/HANFy0RhlmIpTjAEDWYgCZkxsdJD5dyUMCSKQyeKwitQO4qBt6gxoqqRl+z3JFWGsOcUACqnZ1Wi0JFqC1AFwyG860Ed/Olp2wuc/Z6G6lnFbVmDk5zqKBLlM9ipkiYKKwzCTCVxIir9Bf2O4qhyp6K7lxEN7fQElpFncykS7rm0uyc31n63WPnC7rQevQ2oezHLMB7uox8bEDZZdvQQszkzCd87t91WQz1e3h1Mk42wGzpbzHUh4OlNoUzO5hkZCEkhh3u9kbMN0lZGpmadjQInC5swfwEe9utye2HF8Dqv7X8SuAB5ilQLa14hXxJFqsqJeSUdUw1AibGB2fB55qyx2ZibnY0TA1eWg7xRwRyjPuHwSKhxwhe8jHvObO//cKmLbjNGm+k9LLpSu8Dn9XJlCCsnUQtifJmgZqZGJa4HJCKzBYF/Ec6GrdcwANh5mc2VTW/QVswVNdWZjWB4TDbSBqSSRimzoVd7ZUZG83ioOVbO+vxQ5Pq4s3FVSETN9KgFAOwNqX3gPJQoiKQ95xhNAGDmOxtlaxKhdgivnU0PgK7CuSK/upLZKFvDqEVn21/jMba9CDO2jIzB94BR6xNh6whmjrN1qLWNOoocsXMPrXOrRxWuqHnR2bgyMjISPWp4RNDwKCK4IoKCaQWcZzPV1lw5iejlOQCqHnWjoI1UDE292tUDxERjLG/zw6bGbTYWNUUCWo9KDnZkJPLO/KpntJP1uAGoOprmMU5VslGWEctLYrT39GNQRtdXIyNdj7NkQUTyqFC0etk0B9qXSY+5ihoBAMWjQtHolcK9O9bruYoaNYEieFQooL+8Cxl/l2doq/ZsrPf/CcX4u16VneFyu3x6raqvNUERwBWi3x5c9vb1WsbsbMR6VeCUMwqe06Wv0W2wg1sVYuRx5Z5N58CObOGnALP2REFPqqimi/Fa7yYynNmqd+6AxLXl2rh3h485YMt8/kjPRkzCa4nQ4HC8sfo3I6ODapNg3/x+pGdinS2daiBH3sqIKHDNvL7okrPhwM5Wlkw9PqtpZD8tUCUCtqSLNb9hrPeABRp+eEZvHVD4o0YAfkGAyaP/EKIIP+z9T5LJQC9ytijhnnFZfcXZxEJn477VUJKZG30gTSMJW+PCgFmsEAJit8BrbpjE5gFJrAdgzqUI/EVtSWZzgGJh7gfpPDg1ngX1g0ztRAxRGneIQDzSbUOhFiUb7WIKxSMDCljrnc2H1FrFuqVjyv+Bc+Sk'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_022_010_112_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
