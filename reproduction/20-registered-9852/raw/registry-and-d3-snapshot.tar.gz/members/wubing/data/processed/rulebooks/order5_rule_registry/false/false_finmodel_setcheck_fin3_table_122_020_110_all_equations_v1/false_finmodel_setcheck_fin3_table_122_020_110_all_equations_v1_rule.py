from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_table_122_020_110","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_table_122_020_110","model_table":[[1,2,2],[0,2,0],[1,1,0]],"priority":295,"rule_id":"false.finmodel.setcheck.fin3_table_122_020_110.all_equations.v1","rule_key":"false.finmodel.setcheck.fin3_table_122_020_110.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmTsOgkAQhmcBw1aKNpZuQWHpEQiV3MIjWFJu5QE4gUfhKB7BA5gowypKIHExxmTl/wr+kNlHZobMPhCUkFscKOw3bIJfTC8G90ik0ahjSY1o+7HuTRPyrbscX8ZvR2hSvyt+tg2SvMc8b1BGPAIAADBSzn7Ocg2jv3OtXJ4WQtZrpO5fyIEVO9qzTDmmvI/KG0uI4AAAAHAQFUTJB1cDLqDZs4Bk18I+a6d9SyvPor4LGJPN2ufGqHqHwGYQgJGzzoYUVGFKpxsc4zlLIW0aZ05lTRcBX1xvvepwL1sV/ln9gQXlrJbLqvtRl65vioRuVnmPOn9EZIzsA/Albv2PGHE='
_TARGET_BITS_PAYLOAD = 'eNrtmTsOgkAQhk08gEfwKByFE3gAqy0pPYK3wIpwBEsLCixtFK2WCLsjwypKIHExxmTl/wr+kNlHZobMPtAUk1ssKe83bItfTK8H94il0axjiYwI+7HuTWMqrbv4L+O3I3St31N+tg2S1GOeN6RGFAEAABgpszJgmeTZ37nmHeZHLes1UvQv5MCKNa1YLhxT3kcFjSVHcAAAADhIWmTxB1cDLiDYs4Jk18I+C6d9iyrPsr4LGJPN2ufGmPYOgc0gACNnFw4pqNqUTjfwkxPLQto0Dp3KmlgUfHG9UdXhXrYq/LP6Awu8cy3Tffej9lzfFGnRrPKKOn9EZILsA/Albk7iWMU='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin3_table_122_020_110_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
