from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_table_0011_2233_0011_2233","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_table_0011_2233_0011_2233","model_table":[[0,0,1,1],[2,2,3,3],[0,0,1,1],[2,2,3,3]],"priority":301,"rule_id":"false.finmodel.setcheck.fin4_table_0011_2233_0011_2233.all_equations.v1","rule_key":"false.finmodel.setcheck.fin4_table_0011_2233_0011_2233.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWbFuwjAQPSdRk6GiSeeI0igf0JGholbVAf6CT0i3Dkj1wMBY9Qv4lHxKPiEjQwW9c8A0wVAGhgD3pDhn+2zn+S7yXSKgiRwKaDMGuiw+TzHXLXSIscCiT/U7aDnUe2Uj4X8cO2QOXx7eUiSpUhTCSPw3JAAHyxsAD8JDeh70JM0IpC+AwWAwGFeIcuXvObJWiFMfrMvV3sdAnPVRtIAf+27lxHnxgMWZM7xEqMpm2jx1WKy53H1V2KQbL9eBOMRZ7jZ6Ov2iuUd+XDbt4GMQ34VJK7m5ijhlmgxRNQw1Z3KKLcOYyJDClmHX7JEZuM0Cdhxv/GchUVPVC5HwbHbNPNfBNYwnFy47KoPBYDAuGxNbuLbObPBcLV/ON3x7wpBKWcnFmfKV2ykxIMldVBmwH1wp5qn27O9hkjj1HkvTKI0aX5fVLIiiJJmGry3M2Rx5j7chkRjh1TN0LE2W7+dJshbkm7eWZrPN5I/T8HpyNn9fpntkQszpL4PRRgTCCyUAltBT4IAHAaCIPU4gQYKoqlL//7M0VfooK6o6WKt10r9DlKmCPfAL4nRZQw=='
_TARGET_BITS_PAYLOAD = 'eNrtWbFuwjAQBXVgzCfkU/IpfEHVkYHBlRi6lU/oX8BQVS7qwNgPiEKKMjcp6pBUSXy9c8A0wVAGhgD3pDhn+2zn+S7yXaKgCQ9caDNmunTvTzHXN6yIscJiTvUvaDnEY2UjlT0cO6QPdznefCQpfBSSWP03JIUSyx+AHJJDejmEkmYE0lfAYDAYjCuE08n2HFkdxKkP1m5n72Mgzvoo6sGNfbc84tz7wOLMGV4iRGUzbZ46LNbs7r4qbNKNl+tAHKKxVzR6VnO3uUdZ5DTtkGEQv4RRK7kVgjiNNRmiahhqzuQUW4YRkSGFLcOl2SMzcJsF7Dje05+FVE1VL0TCm9k181wH1zCe7BbsqAwGg8G4bIxs4do6s8Fz1Xk93/DtHUMqYSUXjUUmipWDAYlXoMqM/eBK0fe1Z99Og6Cs91iaJn7c+LosBmkcB8EweWlhzlbKT7xNicQEr9DQsTRZvp8HwVqQz/laGgw2ky+GyfXkbNm+TPfIhJjTXwajjUhVnkgALCEUUEIOKaCIPWUqQYKqqlL//7M0VfooC6qWWKt10r9DlKmCPfALaf0X8w=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin4_table_0011_2233_0011_2233_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
