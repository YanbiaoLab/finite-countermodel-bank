from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_table_0231_3102_1320_2013","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_table_0231_3102_1320_2013","model_table":[[0,2,3,1],[3,1,0,2],[1,3,2,0],[2,0,1,3]],"priority":280,"rule_id":"false.finmodel.setcheck.fin4_table_0231_3102_1320_2013.all_equations.v1","rule_key":"false.finmodel.setcheck.fin4_table_0231_3102_1320_2013.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNqdWUtuXSEMNYhKNCNaZQGoyiDLoFIGHXZJJFKlDKuuIEstNsZ8rrn3vaA2ee9+wODj42PnT0wByj/rAJxxHiAlsAbgCR6hfMlgDN6JqXwJ5Wv7AjaACRGGET3dCBk84Exg+X+Zw5f54RW/Jxhe+gXP+OsLvvat/MiOb/DCHhf0OIe89Ea2gim3yJzYbgZX3ilPJ3B0Q0YuCxdzMj7lPV0y9Y5z5Z2634ymJ/C8lZRpq4n2i5O3yb6SsR/48Qfa9bdvpW7hke/KSAmndRGnoGNwzTrrbKQdlQXr/nj7+61EulFMjkCH7/l/2Qot4Cx+N8NL0ZA55M0X/PS93THWOTw7i66jc5I71W00sfG2ur08SP7tw9djoYueQRQLKsrM42MVC4EOPdWn0fbypB8fM80rwwj94OfhrQ9sFK2WxX7CMNDB5nqpmW/ogB3cP7b4TXG4ZGI9lHL6zh42Ml/Ju42dOYyCJb/DeBFBmG0FTZ+hmSeLPO1Wcz4ENKcFSLeTAp+9YuvZ/mwx0cEij7sBvwBeXWwPX4JNdWmbxgb0nxki/M6xjSIFywkBmhkisILECy/sTdkGM51aCONp+fLB4uN5PMrYDzMuv9ex5xS6ZKdIQnzGYs2MQJtkjauQ8IF2ZAJvRl5QYBPxsGLkbXk5wNziYLBAX23LsL/xxzdTubaOF8fZoyNdUkg1FcYZtGCrQfa7RZGMB2iZqUdUsYc4fnGGPfs64W6Xb8ibdK8PZJvgFxZpTxi49No+7WFWzcVTsXuG8EmZzs7AZ4Dms7Aegk0h9krPlTaYz4/aQUsAWkKYRIBG7LgaKRDgDWpsQ9u0c0DbHR6bIlKIHd2DTO67L/HSEmx6gLmsr8aSSCN2hGT8MYA8mRYD0cCnRtUACrEn/GZqus71iBQxNrxgGrz28I+ecIDMm2ffIkcrsKk/lJwtbksAkDbBZhAHtFBdTTyM2pFhM67mZnSLelUSwi6zScLpWPeUXt2gRzSF3JNMVzJ+G24cbCKEO9hxtTL9aK4abGxcWCh5E2ySQmselcA8nhoFm/GLS+Tkr+UXC3/icxPGJBg9J5xuM+HTcNKWNV1aoLnfog90erhQYOMMU5Rl6kzDORxSu5u4mS+ZvYwk+nit0Z+6ZiQZWT6GziPENpTa46DMm4wU+rdpG2w159+mB8QuTZd2A+w2A9RgIzDMWFNgQySA6m52/DGOdwmg+AVBrWCNFCT9iAKbI9soXL+PtbIfwgGpO2NGXYawyRPGEgZWFUSuoyMwNZphZ7vxjyxLr+95iZSP9LIqi/df5u2gnkoVfnMuwAlb7f1luvMIIrZEbz237DONpbLI7kpGYsJpweaZYVE5TOmDKLSKOjPT/lxm5O1qVUbWFPrux7KINvE8SsReVz19Lo2WqXGhG0+tpPYPZYZGcpfjiXZUxUGaFsNNvMwe6HYNfg8taq8XK2iWqObMxoGplPrUJsLgHOO6c+iJomuhEkgYe8eauMsnpKjGWpUG6QF6HFzn36apfYPLSX1jrSU5cov4Jo4OVUKaI0W6tazSMptkEBNGJEfPzNGAr7JND4UwfzzLbKLuMow1m68UmJnPlcwWRx0Ur2q2n03mpEUPKLBJWQRRTx+Kj9JO2O37jLQaCyLmeK4H3Fkz6XRsG2uEkXbJ5QYDG/xhI8uVPUayo6hWKt2hIJaLRGsP8OnyN0RS+dK36HbexNH98TBBMZ7VbErjVoqCLkcLYiw9nqe+5O1j342UomDQGaghrNP1sAiJE1M42LA2Yj0g8W24lILeQipagx63w1Hmfph5+a3ISJSKRHwxjL1Foc5R15jcKtTp6mUbEq464UfYUE8h54U0Ys/pa2NByWyPU84WxaNUuq3bPiC9t0ols510YzBUMMhw7ofpzvOggVpEFXtqO3aVGWdfp8yGfqqNZNLjph0QepPuzXo8xYVFGum7G2q2bTeSmoy2VqLsGcJncKtXojC+Pe1FSrApxK60/pV2rJIATgpFbv0rxH5s/Stsc1+lza1/hdiV1n+KvR102ucPmzzKrX+N2I+t/+Mfze7NbF66fguxH1v/2l+J+gtS6/grGUnusTNFyR9yxG2KjFT7c3EHyuC68KhZp0WP6BTRI61nY8+BcBZsFRoY1bOMJEJul2xqrjfebfVj54RtzUZcqJUsXTbIRWmQD5WFUGKOvel4b+ufGiQsI1vP422oyMxaqR0Fw3H8B93S9QU='
_TARGET_BITS_PAYLOAD = 'eNqdWUtuXSEMXWpWUHUYqVLCkjrsIFJZRgZRxQKillGKVAQuNsZ8rrn3vaA2ee9+wODj42Pnm7Meyr8UAWKOAcBaSBngDd6hfDGQM95xtnzx5Wv7AslD9g6G4QLd8AYC4EyQ+H+ZI5T54Rm/Wxhe+gGv+Osfvvan/DCRb/DCARcMOIe89ES2Qi63yBzXbvpY3ilPW4h0Q4YpCxdzDD4VAl3K9U6M5Z26X4OmWwi8FWtoq5b2i5O3yf6SsQ/48Rfa9bVvpW7hne/KsBanjQ6noGOIzboUk6MdlQXr/nj7+604ulFMdkCHH/h/2QotEBN+z8NLLpM55M0X/PS73ckpRjy7hK6jc5I71W00cQ6pur08SP7tI9RjoYuBQeQKKsrM42MVC54O3dan0fbyZBgfy80rw/D94OcRUvBsFK1mxH7CMNDBmnqpmZ/pgCPcP7b4tW64lF09lHL6MR02Ml8xu42dOYyCxTzCeBFBaFIFTZ+hmSeLvO1Wi8F7NKcFSLeTAp+9kurZ/mwx0cEij8cBvwBBXWwPX4JNdWmbJnn0Xx4i/M6xjSIFyxYBahgisIIkCC/sTdkGM52a9+NphfIh4eNmPErXD9Mtv9ex5xS6lKZIQny6Ys2MwGRljauQCJ52lD1vRl5QYOPwsJzjbQU5QNPiYLBAX23LsN/xx59cubaOl8jZoyNdUkg1FcYZtGCrQfa9RZGMD2iZqUdUsYc4fnFGOvs64W6Xb8ibdK8PZBsfFhZpT2S49No+7WFWNcVTrnuG8EmZLs3AZ4Cas7Aegk0h9krPlTaYz4/aQUsAWkKYRIBG7LgaKRDgDWpsQ9tMc0CnHR6bIlKIHd2DTB66L/HSEmx6gEWjr8aSSCN2hKT7NYDc5hYDLsOnRtUACrFb/JZrujb1iBQxNryQG7z28HeBcIDMa2bfIkcrsKk/lJwtbrMAYDfBlhEHtFBdTTyM2pFhM64WZ3SLelUSwi6zScLpWA+UXuOgRzSF3JNMVzJhG24cbCKEO9hxtTL9aK4abGycXyh5E2ySQmselcA8nhoFWw6LS+Tkr+UXC3/i8+zHJOgCJ5xuM+Ezc9KWNaNdoLnfYvB0eriQZ+MyU1Ri6rTDORxSe5y4mS/lvYwk+niu0W+7ZiQZWT76ziPENpTa3aDMm4wU+k92G2w159+mB8QuTZd2A9I2A9RgIzDMWFNgQySA6m52/DGOdwmg+AVBrWCNFCT9cAKbI9soXL+PtbIfwgGpu5xHXYawMRPGLAZWFUSxo8MzNeZhZ7vxhSyzz49miZQH+7Iqi8cf+emgnkoVfnMuwAlb7f1vuvMOIrZEb7227DONpbIw8UpGYsJpwRaYYVE5TOmDKLSKujzT/lxmmO1qVUbWFPoYxrKINvE6SsReV719Lo2WqXGhG0+tpPYHZYZGcpfjjXZUxYGdFsNNvMwe6HYNfvctaq8XK2iWqObMxoGplPrUJsLgHOO6c+iJomuh4kkYh8iauMsnpKjGWpUG6QF6HGLn36apQ4PLSX2TUiI5cov4Jo72VULmI0XGtazSMptkkOxHJLvAzNGAr7JNDwU/fzzLbKLuDIw1W6gUaJjPlczmRh3krmq2n03m2EUPKLCxRgRRTx+Kj+xO2O37jLQaCyLmeK4H4lkz6XRsG2uEkXYpmgaD5MNhI8uVPUZMpKhWKt2hIJaLRGsf8Ony1ztS+dK36HbexNH9cT9B0Z3VbErjVoqCLkcLYhI9bqa+5O1j342UomDQGaghUtT1sAiJE1M42LA2Yj0g8Z25lILeQipagx5Pw1Gafphm+a3ISJSKRHzOj71Foc5R12TTKtTp6mUbEq464UfYUE/BmIU0XM/pa2NByWzvU84WxaNUuq3bPiC9t0ols510YzBUMMhw7o/pzuuggVpEFXtqO3aVGWdfp8yGfqqNZNLjuR0QepPuzXrcuoVFGunHG2q2bTeSmoypVqLsGcKnj6tXnDB+Ou1FSrApxK60/pV2rJIATgpFbv0rxH5s/Stsc1+lza1/hdiV1r91vR102uf3mzzKrX+N2I+t/+Mfze7NbEG6fguxH1v/2l+J+gtS64QrGUnuSTNFyR9yxG2KjFT7c24HSh+78KhZp0WP6BTRI61nk86BcBZsFRoY1bOMJEJul5Jtrs8hbvVj54RtzUZcqJUsXTbIRWmQD5WFUKJxvel4b+ufGiQsI1vP42moyPJaqR0Fw3H8B26ffCI='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin4_table_0231_3102_1320_2013_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
