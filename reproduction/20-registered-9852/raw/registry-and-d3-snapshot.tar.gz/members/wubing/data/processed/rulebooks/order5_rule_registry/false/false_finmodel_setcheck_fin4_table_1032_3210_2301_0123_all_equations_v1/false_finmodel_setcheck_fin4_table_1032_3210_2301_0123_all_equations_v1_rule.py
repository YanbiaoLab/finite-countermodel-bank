from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_table_1032_3210_2301_0123","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_table_1032_3210_2301_0123","model_table":[[1,0,3,2],[3,2,1,0],[2,3,0,1],[0,1,2,3]],"priority":305,"rule_id":"false.finmodel.setcheck.fin4_table_1032_3210_2301_0123.all_equations.v1","rule_key":"false.finmodel.setcheck.fin4_table_1032_3210_2301_0123.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWUmSwzAIRCodOPIEnqL5GZmXjwAt3iapco2nsqgPji0rigMNNPJN4B6yZEibsZQIy0cMAAjBvh8znANSJlsSgCH6mJxcizjrY1BZqz00+oICqawtejcwEDw9iDK7WdnsrH+ET67FGb7UxPrvYzXxI3ep9ZL7Id5jh/kK70+aeGok7MwQXlEjFOJZdHbmUSFGsukB2kFvY72/oAFOy16Jkul6/k2r6NPcLMVTaL7ENsTFdYt5vMvqMEJ+4i0gcFP/96I4YpI1ojHWRO+hK1omW5nhXgfCvmCEadqJiU2wiSVk05gm2zwLQ83RmDyqpOdozc3JauoUTxMXoCT5m9d01woLbZYG/aoQ0CFl4mLeMTFPd3oXVDbTq4jLotS7ydFGHlc2lJ1UxV/7SvuhyFUTj2W0hJomNnPZrRj76aiaoVm0HT6zitZmf2816Tpl+EEt3Z3Ew/OrM5mNxn8Fm3kqZOM0OX3VPVJ8Y2HoDjkMtuol6W7D03s8L92z+V7agfgmy1ph2UGrpW36KmnEXUDAR5py4k9AbFFtJfR7VZQCjRwdnH7Kz5qjW84dWiBtLiYuRAiY6o4OrcqfKThMmy2d7N1H3ouOIfHo8Z7wxCshpq5X13u49ppFy7QPKgEOdPSQVbK9mHgX+Na/yTUsRIhDT+9pY++QyHVISxoH2/1xMmTiPH4AfGc6aw=='
_TARGET_BITS_PAYLOAD = 'eNrtWUmSwzAIfPmEn42eoidw5EBJjAAt3iapco2nsqgPji0rigMNNPIN5B4CBOHNGDNS+UhZhCTb91OQcyAMaEuKREk+BifXwhj0MbCs1R6afEEQLmuD3s1RUJ4eiCG6WaPZWf9IPLlWDPKtJtZ/n6qJH7lLrcfuh3SPHeYruj9p4qnB1JkBcUWNXIhn0dmZh4UYbNOztIPepnp/QQOalr0SJdP1/Mur6NPcDMVTZL6kNhSL6xbz4i6rywj5ibcAyE3934viiMmoEU2pJnoPXdAy2cpM7HUg7wtGnqadmNgEG1hCNo1pss2zsNQcTexRBT1Ha25mq6lTPE1cgJLkb17TXSsstBkP+lUhoEPKxMW8Y2Ke7vQuqGymV4mWRal3k6ONPK5sBDupSr/2lfZDKVZNPJbREmqa2Mxlt1Lqp6Nq5mbRdvjMKlqb/b3VoOuU4Qe1dHdSHJ5fncFsNP4r2MxTORin0emr7oHiGwtDd8hhsFUvQXcbnd7jeemezffSDsQ3WtbKyw5aLW3TV0kj7QJCPtKUE38CjBbVVkK/VkUp48jR2emn/Kw5uuXcoQV4czFxIXImrjs6uCp/puCIN1s6wbuPsBcdQ+Lh4z3hiVdC4q5X13u49ppFy7QPKgEOdPSQVbC9mHgX+Na/yTUqREhDT+9pY++Q0HVISxoH2/1pMmTiPH4A0Ao2yw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin4_table_1032_3210_2301_0123_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
