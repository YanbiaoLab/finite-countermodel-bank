from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_table_2013_3102_0231_1320","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_table_2013_3102_0231_1320","model_table":[[2,0,1,3],[3,1,0,2],[0,2,3,1],[1,3,2,0]],"priority":292,"rule_id":"false.finmodel.setcheck.fin4_table_2013_3102_0231_1320.all_equations.v1","rule_key":"false.finmodel.setcheck.fin4_table_2013_3102_0231_1320.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWEtOwzAQHY+CZLoyiANYFQuOMUhdwK7iRFNWLBEn4KjMx3bcFoRQVUSLn9TEcdI2ns+beQ5ACMQEE5w6XgHyUs53ABT6G5wBEwQGmcVD1xlCyJBgI8MUD/ytN1ysptuffIPl9RfgC10carBHs9I7rSQEthFlhbJUoG9skctb6bO/iwd5cTld6JhWZfLajlcB1jtPy2OrHcdzni36n3F70YbrvMyzH2nz8qltlk/VdF/75h4uYeCIIDIGouxZqNlKYHQ0sYwmTegEJX+juDELwaNldhjW65BjViPZQYuEWtBrYdSaaOUilA8EsWBiu53M5j9ONrixc6XwmX74BZzR5P/dQ3axRC9sfx8pm/Uwa6xFi0UEI4pJl3jvZaJAl0glOFvJmX3SpnAE6MBJQJpLDWorjYGceINRROSaAy0FUtJRjXiEvRSIfuBh14ETaSNBm262WPbKJrisle1uJ1mwVLa+oyn1lAbnnytiMi5UWkylywreRiEW6pwF57MGkncCVYV0aiS1qdHOHruy+ZaDS+qqol0npquiwGesOzne/I5Nsw+cJwJqVjObouryE0wUlIYouYwypveGqDU4LbVp92LgXIBTmtSnUyP26moVh8geDZjL/kYdzo1x7htm3J4bONYGCWW1dUp1Z6L1Z59IfWV65q0Kzb2oYdjXOgMDA/9gg2RjDKA8ET37Q6f8tvsBLQa2QZJ7jo/79DFo5KzwAYzlN6I='
_TARGET_BITS_PAYLOAD = 'eNrtWEtOwzAQPSonQCxZ0TkR6g4WlfAxWKBqDoDAq2KJaDzMx3bcFoRQVUSLn9TEcdI2ns+bec4ciAMEnvjUccWMazk/Mofc3wBkipyBZZYOXWfOGTnyQoYxHfhbl7RZTU8/+QbI62/YF7o51GB3ZqWLsJIQ2EaSFcpSOXxjCyxvpc/+Lu7lxeX0ruOwKpMvdnzNvNx5Wh5b7TgecLbof8bTexsucY2zH8Pi+lPbrG+r6b72zQO/8cAREYIxUEDPQs3WwEZHE8ho0oSOXPI3iRtRCJ4ss/OwXgdMqEaygxYJtaDXwqQ10cpFLh/OYsEIdjuazX+cbPxs50rhM/3ANTujyf+7h+xiTV7Y/j4imvUINdaSxSKxEcWkS3zwMlGgSwwlOFvJmX3SpmgE6MBJQJpLDWorjTk48WajiAQ1B1oKxKijGvHEeymQ/ADDrgMn0kayNt1gseyVTfBWK9vjTrJQqWx9R1PqaRicf65I0bhQaTGWLit7G0VUqHMWnDcaSN4JVBXSqZHYpkY7e+zK5lsOLqmrinadGF+LAp+x7OR48zs1zT5wnsikWQ1giqrLTzZRUBqi6DLKmN4botbgtNQOuxcD5wKa4qQ+nRqxV1erOCTwaCAs+xt1ODfG2DfMtD03cKwNkoBq6xjrzkTrzz6R+sr0AFsVGnpRA7yvdQYGBv7BBsnCGEB5Inn25075bfcDWgxsgwR7jk/79DFo5KzwAb+MOZQ='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin4_table_2013_3102_0231_1320_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
