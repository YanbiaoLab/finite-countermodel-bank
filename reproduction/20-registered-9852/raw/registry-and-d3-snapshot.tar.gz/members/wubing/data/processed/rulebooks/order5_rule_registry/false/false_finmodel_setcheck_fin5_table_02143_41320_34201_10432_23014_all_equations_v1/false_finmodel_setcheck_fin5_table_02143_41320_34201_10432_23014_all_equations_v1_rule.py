from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_table_02143_41320_34201_10432_23014","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_table_02143_41320_34201_10432_23014","model_table":[[0,2,1,4,3],[4,1,3,2,0],[3,4,2,0,1],[1,0,4,3,2],[2,3,0,1,4]],"priority":300,"rule_id":"false.finmodel.setcheck.fin5_table_02143_41320_34201_10432_23014.all_equations.v1","rule_key":"false.finmodel.setcheck.fin5_table_02143_41320_34201_10432_23014.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrNWUmyHCkMFQQLljoCR8E3o39E37uRECQCQdYvbzodTjsnofHpofq3ZICcoQBAgEQX9U+oFy7FeoHg6UlIwE/4tQD1Cfj6IIKjO/SoHvUdV28iyvVzOHAIvAJgnB9En+lBFV8/9O0eS5SFWU77th/eR16e/q8eINlRH4R+itDWKoUWBpLoXJo/qhajyMGq5HMkdgXrspriWRgZGhZT+JJN+dPNEN+4Kpt8V7SsH4jV1+zuLH4SU5CcCT7Xf5zrKjWhbVVyvlo+kKD6D0dlPmoY/zTX10U8PuGqtyPL9bB+E/ivLBybYjXs4hTl8/5plCRKibREuRuGhKC9SGEokxBlvlbEPOLIRZ0EzT+YlAfY5CJu62k2Oa6LjKfVjvmbSTbfil370FM2P542D1w10QHDQvr01Xy3RAsslG/8+vwyrI69HLXOu9a6BMBFlj7dQyqkdAjVE6ujG6kSCTbKHltKG5DizKI44U89hXdL3MHBB0DgtHmS0/e0iWuO3WxZD++b7lXhUFSYuC7lVosj67UmdzJS4bRY/d47sVzDIzDMKLU5P/+B74/qNxR1jGITo4qEtWMdK58uIo/BPCFsawZZfJvGOeIlLdyh7EexJejFFtz8GkFzReg5u9xUima+aVWtEkG0c43yU+cDYy2fyto3BkLP8LUXWyK4d1zVqJTKAzlUsve0Wd1ZAMBQYTG+tSzWxm9YXzTW79xhKWP3VmwN4slra/RDYyBTLPIHAm+HMCKmCjG0YpYY7VSHr7di87lbn1+LrVEiejftYahZ6SeQJYweoUn61RcshokDFCIPHotKZrdClEHG5hfKiPDJ2RXkBxZ6P1fKgM5RYY1D5A/NsIut0RXseDvsKFOOhae/tNfdJVvyMXzS2Zhj6mIzOpvRQvOvTJPORl9lXZh7Zyu0EJ/q5RG7bmhdP+NicxtEyQLy/eCRPr2ARjqjaM6cB+y1qDKstVC3Im6qb3ibC6T3zhZzT69StubB0RzZZ7V208Ryp5ElC3LMDNALtOjCOtPI8kruUoOhxldxWHDgA6lHc0HuO1VVNDLaEPXD0oU/54dGxk5fdAE8loZjTZQ08dWw9eAw52WDtbCkQ/wFruCz3VqKjSU6r8LivgOrZU/IGmvy3Vh+XqC2nsIbfPgzjWy40MwKG/vQUY+wO+AbGkkOk2JDSUyDRtJy4Res8UAj2Q6EFxrJZqlAshYF3hrCsmcjmYuHRjSHrPue7ZOOEFx4Nkgc3TJ/U5YdYm7Fhjfx59Wk2HghF/OdD5jFtq1RbsUmKSk7icmRuM0fvP/LYvNtiOLcxO7LgXyXCay+ycc+0jIgKuSND7Cn9xlX+HQ+UmlkA13/AHvoMapLJR2YbQJlSb90nOrBXtU8tBqvF9huTUOjW+90t852mDPyLl9kp7amkTbGfurCjELvWjLt0V4TPXNzltna7UJwx2JzvarT3KSySpvOSIxS8p9nJLaNDD7GzFLKY3hPm9Ha4YuR3XFwywwuqejz5jBGwZGbSeXoYqpqbjgRn3ToAxK3GeGETBhU67XpCY0klt854+QNvftga/MhVB9t3JxQxbByJE4/TSNjed+6v9DI0ySci61BZ4InfPz6dXR2K7YIaM5wx0RphiPau+GSdsYWzR2Lrf3UQMmHYdbYmIOkOObn+V5q6bpnw7S9wcSDT88wB1cHWIa4M0gef1pIrSOA+oGCqi9sUUqf5oiM/kcNTD7cR/9++1HDRg18Gf03uhZmHrmnDSuQ0olG4vuIvO3ZjJ2uMfrPaSu28tEQfqGRTNc8ChEK9uifn2IZHvgNgVSjfxgNZ1TAPvq3fiVSJRBeFiNu0LfU45crd+ADrbXP46ADnsT/CY08DEg+2+pLU7C33haN/Okjiz7Dfej/6+7DTox8mUYOlr94becDXhqOxQaiCtehKP4D7DSrhA=='
_TARGET_BITS_PAYLOAD = 'eNrNWUmyHCkMvXdH/OZm5igcQUsWBKiRECQCQdYvbzodTjsnofHpofrHeUTv0SFiwkAX9U+qFyXEegGY6UkKyE/4tYT1Ceb6IGKhO/SoHvWdUm8CyPVzFCyAvAJCnB/E7OlBFV8/zO0eS5SFWU77th85R16e/q8eANlRH6R+itjWco4WRpJYSpg/qhaDyIGq5HMEdgXrspqSWRgZmhZT+JJN+dPNEN+UKpt857SsH4zV1+xuL34SU4CcidnXf0rpKjWhbVVyvlo+kaD6D0dlPmoY/zTX10UyPOGqtyPLzbh+k/ivLBybYjXs4hTl8/5plCQKgbQEuZuGhKS9SGFwkxBlvlbEPOLIRZ0EzT8QlAfYZCdu62k2Oa6LjKfVjvnrSTbfil371FPWP542D1g10QEDR/r01XK3RAt0lG/8+vwyro69HLXOu9a6BLBElj7dAyqkcAjVE6ujG6kSCTbcHltKG5Ti9KI44U89pXdLysHBB0DgtHmSM/e0iWuO3WxZj5yb7lXh5FSYuC7lVosj67UmdzBS4bRY/T4XsVzDIzLMKLU5P//F74/qNxB1jGITo5yEtWMdKx8uIo/BPCFsawZefBvGOcIlLcqh7EexBezFlsr8GkFzReg5u8pUima+aVWtEgGwc43yU+cDYy2f3No3BkLP8LUXWyC4L1zVoJTyAzlUsve0Wd3pENFQYTG+tSzWJm9Y7zTW79xhKePyVmwN4slra/RTYyBTLPwHAm+HMCKmCjG1YpYY7VSHr7diy75b71+LrVEiejfsYahZmSeQJYweoQn61RcsxokDOCIPGZxK5rJClEHG5hfciPDJ2RXkBxbmPFfKgM5RYY1D+A/NsIut0RXoeDvscFOOpae/tNfLJVv8MXzS2Zhj6mIzOpvRQv2vTJPORl95XZh7Z3O0EJ/q5RG7bmhdP+NiKxtEyQLy/eCRObyARjijqPecB+y1qDKstdCyIm6ob2SbC4T3zhZ9Ty/ntubB0RzZZ7V200R3p5HOC3LMDDALtOjCOtNI90ruQoOhxldhWHDgA6FHc0HuO1VVNDLaEPXD0oU/+4dGxk5fdAE8lqZjTbgw8dW09eA052WDtbSkQ/wFrsCz3VqKjSWWrMJSvgOrZU/IGmvy3Vi+X6C2ntIbfOQzjWy40MxKG/vQUY+4O+AbGkkOk2IDSUyDRtJy6Res8UAj2Q7AFxrJZqlAshYO3xrCsmcjmYuHRjSHrPue7ZOOkEp6NkgcXTd/45Ydom/FBjfx59Wk2HihEv2dD5jFtq3hbsUmKSk7icmRsM0fcv7LYsttiFLKxO7dgXy7Cay+ycc+0jIgKvmND7Cn9xlX+nQ+UmlkA938AHvqMapLBR2YbQJlSb90nOrBXtU8tBqvO9xuTUOjW+8st852mDPyLl9kh7amkTbGfurCjFLvWjLt0V4TPX1zltna7UIox2IrvarD3KS8SpvOSIxSyp9nJLSNDDzGzFLcY3hPm9Ha8YuR3XFwywwuqOjz5jBGwZGbSe7oYqpqbjgRnnToA5KyGVGETBhU67XpCY0klt854+QNvftga/0hVB9t3IpQxbRyJE4/TSOje9+6v9DI0ySci61BZ8AnfPz6dXR2K7aIYM5wx0RphiPau8GSdsYWrRyLrf3UQMkHadbYmIOEOObn/l5q4bpng7C9wcSDT88wB1YHWIaUM0gef1oIrSOg+oGCqi9tUQqf5oiM/kcNTD7cR/95+1HDRg14Gf03upZmHrmnDSsQwolGwvuIvO3ZjJ2uMfr3YSs299EQfqGRTNcyCBFK9uifn4IbHvgNgVSjfxwNZ1TAPvq3fiVSJZBeFiNu0LfU45ercuADrbXP46ADnsT/CY08DEg+2+pLU7C33haN/Okjiz7Dfej/6+7DTgx/mUYOlr94becDWRqOxQaiCtehKP4DYD3Fow=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin5_table_02143_41320_34201_10432_23014_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
