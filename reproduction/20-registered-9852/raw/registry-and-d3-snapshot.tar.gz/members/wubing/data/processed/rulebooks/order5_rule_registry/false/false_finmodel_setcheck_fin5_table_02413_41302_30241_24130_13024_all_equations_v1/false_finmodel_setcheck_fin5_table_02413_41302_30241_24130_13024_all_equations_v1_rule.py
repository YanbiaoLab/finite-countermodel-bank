from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_table_02413_41302_30241_24130_13024","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_table_02413_41302_30241_24130_13024","model_table":[[0,2,4,1,3],[4,1,3,0,2],[3,0,2,4,1],[2,4,1,3,0],[1,3,0,2,4]],"priority":298,"rule_id":"false.finmodel.setcheck.fin5_table_02413_41302_30241_24130_13024.all_equations.v1","rule_key":"false.finmodel.setcheck.fin5_table_02413_41302_30241_24130_13024.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNqtWUuO3DgMpQQumF6pGzmA0OjFHEMzqEUv50hKkAFqWUfIUUci9f/YriRK4EbJNknx8/jxf+A0OAClAD7AGADnw08AJIg//gH+ATZsOi13+DEPKl1Ah39xWeV9/OvijW4pHZ9jwja8GyjLG0AGrPxhDnUlxjaxb5ZmBqDDprXtjUfYeAehHI9T3vcWtAFlorAmCSgLyRCLkW6UZYWrDTe87o+ilA0PRxLGZIHkKM5nWbvjR7VhpdmsN61vGLYVDCvQd0lQ19HyCDryiwdNynH5KEwb5fjtURyLg1RFTeuLkvu3qJ5h6UJFfcp5EDPHqgs5OGSrR61HU8rF5sfZdwb608l4Lx96enxan8n4ZhSKid4J2tP6e7WJGh5NRzheW/9lvVFnVWfLjbKwbngwJ8ySwazL8QWdnBp7yaZge259YHViN5n39qPdXLuKhUmzu+VFM3ws6pROZj5HcdteBZTv+XZjsbaAwEKY1/7pVzVbxnR/jtd3oBDnHOqu04ePu72QLLkiNwfTjHfLFWLnWybU670AWnVTuSjZtnvbbI9JwoUCoZ8LDblWAv6Bv+ORW4QVrdlWTgLlR1jrlKnOgy2GUMcnnczOr+OYpp4NNnaFksMGgW8IrX1CsK0Eo8E598H2wwenpgWWWsZEE0hhNhbeozfqBoYH/ekTbillUed+mNn1WlvUDnOEH643YcRRnQJZ+6o11+O7ghWXyytVRJGeT1ktvW3NRIqTAQebsgck9/xTSYRJgRWeWWGDMWMyoLF0sVNk7zPEl+rh4gLV/d8DQi2A/gI47dK3lXwlmG7aZ2OwjfVA2PJ+omBPeHTBVizN9VJWw+AdxW3MHGwLJuoosy1Ag+sUpQfQAanjOkaucFCytY3wR60A5WTViDgCphRn7sztaR/hQdKUARLeZqoWYjnqWofzdmZCc8F14DyGH5NOwyahmAJyGalNV/UeIJO7kE9J29gYMKMZkU0ypU70ptTe4PWVlBe8IEr/raTpnlu3xdCi4NeXdaVejZ5kkr029YA5qAzgQg7AhHYMUdo2Zlfko347lemlJ+qr9Y//KY9ENi8uBHpRlZvl/OpDs7AO2GvLSFHz0vnyh3jPnIXDY/+OFP5OhK74yHc+lpPjKdMqREtD2np4dF9yv6hGhoUSbKWwonLtCXCgD3X0islZGSnlhx615u2oB/jrD5SRKkveHjo3bp3MiCd+4fchYiV5cWbji8lqIJgyGydsP+nMXM5sSKU5pFRB5aJJjfWAP7MJncSD/2goTL22v2O7Z+5EfhNqlyIuZTbKeNvALS57NrcL7CvB9sZQJYyEtksvLopvtwAt+4RDxpGWSq+o95TH6rUPCBkMPQHA04CEyLz6dDItadtv65rfSTTyPubeiC+l5CxzrBo/zk++4J8C5P2ckZsCnvaU7qN2CHhYsh4EG+Z86V1fumP8r5qy3MIitbdKPs1s4SGdQrsf9Fio3UfrNkj7UYsvtl3b99ECvpox7dY5nI5zNeWPYeS4elgPbhd9tXPTpOu55TT7AdWauDjLnZZuM6DN0lR4XEaqUrNh+0ZI0HqwDPl13NG1aSTmuU4vEPunkgSSxjnSoWbwRrjaz1yYhL8s8O9rrXY6mM1jgGybbbAhep4kl5aFasOMfRpjEJiHre5yaIcoi9Hj5sZIppE2BZ2vPdvo0fp6GnikYoQmnbPbcMKJd0wG+judDsL3ttt+WpCoNr38z81DVugZ68IFsC8KouXovww6dr/bzJZa6gWwT99x1qN/Wtemm2BTa2DnOT9vUaa8GP2vp6pmk8nT6H8B7IsByZ8a/S+AXU1OvR79T3rTB8GWJh56BPbFFyMNeUBCh2e0u8h7JPi4lQFnkXTqdGVi6ErPv4TA48yGtaX2EyAPXzxj1OnxQXt9ZB69IFf5OHrP+MVIkoHqkbB0GP7cfz5TcRDqVb8wdQdP9h0nB0B45mvA/67Jtdg='
_TARGET_BITS_PAYLOAD = 'eNqtWUuO3DgMPWqOUMsCJkh4pFn2ojCjY8yi0dABgm6tOlwIEkci9f/YriRK4EbJNknx8/jxX6QcKSLviV7JGCIF4SeRRYo//iH+QTpsKid3+DEgny7kwr+4tAeIf1W80S3v4nNMWId3A2V5g9CQlj/Moa7EWCf2zXLMgFzY1Lq9cQsbbySU43HK+6DJGfImCmuSgLIsGmQx0o2ytHDV4Qa4/ije6/BwJGFMFkiOoiDL2h0/qs1Wms16d+5hw7anYQX6KgmqOlpgyUV+8aBJOSofhWlbOX57FMXiWKyipvXTy/1HVM+wXKHiX+Q81maOVRdycMpWj1qPppSLzo+z7wz0p5PxXj709Pi0XpLxzSgUE70jtaeFe7WJHx5NRzheW/9lvWFnVaXLjbJs3QAyJ8ySwbTK8UWdnM72kk3B9tx6tdWJ1WTex9d2c+0qmibN7haIZvhY2CkdzXyO4ra9CjDfg3ZjsbaAwEKYj/7pDz9bxnR/jtc3whDnHOqq0wfE3V5IltyjmoNpxrvlCrHzPRPq9V4ArbqpXLxs671ttsdE4YKB0JeFhlQrAf+wv+ORW4QVrelWTiQPI6x1yvTnwRZDqOOTTqbn1+2Ypp4NNnaFksMGgR+WWvuEYFsJhoNz7oPtKwSnxgWWasZEE0jZbCx7j97oGhge9OdOuKWUhZ372cyu19qidpgj/HC9CyOO6hTIDqrWVI/vnlZcLq9UEUV6kLJaelubiRQnAw42rw9I7vmnksgmBVZ4ZoUNxozJAMfSRU+Rvc8QP6uHiwtU938LCLUA+gvgtEvfWvKVYLppn43BNtYDYQtgoqBPeHTBVizN9VJWw+AdxW3MHGwLJv4osy1Ag+sU7wbQIanjOkaqcPCytY3wW60A5WTViHYETCnO1Jnb4z7Cg6QpAyS8zVQ1xXJUtQ4HemaCc8F14DyGH5NOQyehmILlMtKZruo9QCZ1IZ+i07ExYEYzIptkSpfoTam9wesrKS94QZT+e0nTPbdui6HF068vrUq9Gj3JJHtt6gFzUBnQhRxgE9oxRDndmN0jRP12KnNLT3RX6x/4Io9ENp8qBHpRlZrl/AGhWVgH7LVlpKj57Hz5VbxnzsLhsb9HCv8mQld85BsfS8nxvGkV4qQhbT08ui+qX1Qjw0IJtlJYYbn2BDjQhzp6xeSsjJTyw41aAz3qgf77A2Wkz5K3h86NWyeztSd+AfsQ0ZK8OLPxxWQ1IE2ZjRM2TDozlzObxdIcYqqgctHkx3oAzmyCJ/EArw2FqdeGu233zB0RNqF2KeJSZsOMtw3c2mXPpnaBfSXY3hmqhJHQVunFRfGtFqCln3DIONLy6RX/lvJYvfYBIYOhJwB4GpAgmg9IJ3OStmFb1/xOopH3be6N+FJKzjLHqvGjYPIFeAqQ93NGbgp42lO6j9oh2MOS9SDYbM6XoPrS3cb/vinLNS1Se6vk08wWHnIptPtBj6bafbRuY3E/aoFi27V9by3g+xnTHp3DuThX83AMI8fVw3pwu+irlZomXc8t5dgPsNbExVnuuHSbAW2WprLHZaQvNZtt3wgJ2g2WQVjHHV6bRto81+kFYv/0kkDSOEc61Azelq72Mxcm4Z8L/PtRq50OZvMYINtmG2zWAk+SS8uCtWG2fRpjEJiHrepyaIcoi9Gj5sZIppE6BR3Unm30aHc9DdxSMYKTztltOOHEOyYD/R1PB+F7220/LUhUm17+5+YhK/SMdeEC2BcF0XL0XwYdu99tZkst9QLYp+8469E/rmvTTbD5NbDznJ+3MFNejP7XU1WzyeRp9L8A9sWA5E+N/hfA7ienXo/+J725g2BLEw83Avvii5GjPCDBwzPqXeTdEnw8yoCzSDp1ujIxVKXnX0LgcWaztaWGCZCHL54x6tz4oL4+Mo9ekKt8O3rP+MVIkoHvkbB0GHDuPy+pOAj1KixM3cGTfrOTA1h65mvA/52ou08='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin5_table_02413_41302_30241_24130_13024_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
