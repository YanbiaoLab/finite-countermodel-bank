from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_table_03142_31420_14203_42031_20314","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_table_03142_31420_14203_42031_20314","model_table":[[0,3,1,4,2],[3,1,4,2,0],[1,4,2,0,3],[4,2,0,3,1],[2,0,3,1,4]],"priority":299,"rule_id":"false.finmodel.setcheck.fin5_table_03142_31420_14203_42031_20314.all_equations.v1","rule_key":"false.finmodel.setcheck.fin5_table_03142_31420_14203_42031_20314.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNqlWUtuKysQLRCRSEbEygKQ5UGWwZM8yNBLwpaelGHeDrLUB1XFH9odG11dp7tpoD6n6lT1v+AAzuAEACgwGuJ1HKd4B5zBSwUWn7jwV/j3gffiBHwPtMRXLPg4W+F/8ZZJq+Es+I0XNDWNL74MM81/cfE0eGMLwtDy+Vm4+Iy/L/ybh6HtowxwrR94EPh2POxb80qQ6xJ/2rtxX2chrYWiSFYLvNJR3BngKFtRdBG1Hs6BCHc1CA+ahOJxAx01KjQ/qES50KvVZBYFpGAtiE4U+gmiXJp37Gv1vNnmH1zCpp0mq7n4VIM1rAbL5lO+nIfmmugd6BFxLnmIt2VWt/4biU/6HBQ2TB8HH0qYZGyFTsS+1GoTJ2g+srD9QjDMH8bSfz36lBpm649uhVda4ycIfeBziMVmbDBUw1ma6omsbcOGOkppJ4vIjavW0oSNsI9Ae7nKCmzg2mPiTF8vabY01g/Pph+RGN3Gz0TgaX4i5I31tbLeMiCg25je54CmV55UrZT0Ijr9V8dV9NYQl35H5OkgHFm2lfkEW5ftcWXYyP0OTz50sYqDr3kYIQwr2Dk0qpAC4RUPnRSEtxpj2yCc1r3TubsQq6GyiLBog9bbz6pGhFjiwMISbHbAFJR3rt+1s0ewYZrylYekpaW7L5pSxpD6OBxl+XKGiDd9kUbvxfEEbBZR7aLKZCdZAMAkfWBKN1Nv24R1lbImgf0lRY7icCN3YE8dAL2AgAStpoG9MJDspigqerCrJND8Vwa08htgWwV2P7CHmAwsPDGYEk0Cu3wXordO2O186sxik0TJmGbtOMQBJoEdA67QrrL6hIwl9dIkkYPrAmz8qq8CO4/PEs+TgWQKnQ8OxRuZFNiLIkVxm3QyyT7y4EiZDdeZ8IHWAAEqXj4hGmc2Ykqq13EH9xij3TMueZNvLgBRzpEhL+gqtySZtOQAX53hd8Yvh5SKUqhuI8AlbmjQp/lmCG4Op9cqdzIzih2ZzeWNWovkiqEaQ2r/4xDwIplGYt2R2SDJTE76kyKwmOZGsXezoPOrnPIB4quaZ6EqB75aU9X9YPNyPF7kKWqc/dGD7VRykNoBtsjg7KAli7dkW8rFQ8jebV22CRW6sHQXYzON7KukCPZwWpVjLPrnSCO56Mg00q5FPEg9wKbKNd91RP7WQ0n5txGgUkrA9kjfGlJVymLEdGSPPSkRdwjWSCMF9AEZQ3EXoq7p1kRXhX75dVAhGkmBvQueYqj4zDv47xGupq1w1hEl1mxk/2kVwzSS1RRTO9yt2TbGSeRq3tmjrcuIKLJ5N8XBn+IiqXuSXb+tYpDLWqAD+AK2Xiy5/yjG+Kxp0WA7YMhEkImmqGDWpmY58j5plRJLlZF8e0+M0HGWYYBTZnPNLqrdYx27QkK6pbykKEczwgz+6sYN7LQJst+aWha61jYOkHzzgdkyYweqHG5vZks0kltXicw1ma0c42Vvhp5mtlWf0VTdHMMaztFGAjxC8EhrmNn0vU6HeRpsp7Lq++vgAG3kOB78c7sZallgE/LWyoLQVlWucbGYNNsevj2WjVuKWrqrXWE/1Vk0SARnECX7PNq5Nma2ZxTJNDK2PX8n3tPQSLp4xlME0bXrkC+8m6vs5YlaY90JlzD01bQa8phveoX3DnJizbyLSEAae451tS+l/rRZkUoktQSbX5hCr9vOj4PNOEfq4/pM15mNnF01NWPKSA/VbKtPCzZ3WHwDtu47gL7by21Uvmr9E6rfmnps3o10+8G2av2jqH2s1xP7a/B/ABv2cEdecxlDFLZjW7B5ZdRP7p2LpsCb08hU17etf6zrj2I0i9ysADc5w7L1j26D9rLtWm4ruG9jxKf6evhyNXGb8oHxsMlM9bpBQmFr9LXJF6OYKFIXa93FFWuzyVLpfjaTJm5DHaLPwVSn9IwY28nbRX/eHaAmOV3o69xGn9UyQu5CnK6/ajaSTNzmRsxWVJFM/Ykc/Q/NDbAY'
_TARGET_BITS_PAYLOAD = 'eNqlWUtuKysQXWp28DKM9CSbJXmYgaXHMjKwLBYQxYwSpCCoB1XFH9odG11dp7tpoD6n6lT1vyABziA9AFjQBuJ1HJd4B6TGSwsKn8jwV/j3iffiBHwPjMNXFIg42+J/8ZZOq+EseIkXNDWNd74MM/U/cfE0eGMFXtPy+Vm4+Ii/v/ybh6btowxwrB8I8Ph2POx380qQ6xR/2rtxX6kgrYWiOFYL/NBR5Bng6lpRTBG1HlKCD3cNeAGGhOJxABM16g0/qEQ50avVZBYFnGct+E4U+gminJp31E/1vNnmP1xCpZ0mq8n41IDSrAbF5rOinIfm6ugd6BFxLnmIUGVWt/43iU/6HBQ2TB8HH8rrZGyLTsS+1GoTJxg+slf9QjDMH8bSfwX6lB1mm89uhR9a4zUI/cXn8IvN2GCohrPT1RNX24YNdXVOTRZxG1etpQkbYR+P9pKVFdjAtcfEmaJeUm9prB+CTT8iMbqNmInA08REyAPra2W9ZUBAt9G9zwFNrzypWinpxXf6r45r6a0hLr2MyDNBOLJsK/MFti7b47qwkXwZnnyaYhUJ7/MwQhi2sHMYVCEFwiMeOikIbzXGVkE4Y3qnk3chVkNlEWHRBq23n22NCL/EgYIl2NSAKSjvHN9qZ49gwzQlKg9JSzt5XzRrtSb1cTjK8uUMEW+KIo3Zi+MJ2BSiWkaVuU6yAIBJ+sCUrqfetgnrKmVNAvtvihzF4UbuwJ46AHoBAQfGTgN7YSDZTVFU9GBZSWD4rwxoKzbAtgrsYmAPMRkoeGIwJZoEdnfzvrdO2O186cyikkTJmHrtOMQBJoEdA643srL6hIwl9dIkn4PrAmz8qqgCO4+PEs+TgVwKnQ8OyxvpFNiLIn1xm3Qyxz7y4EiZDdeZ8IHWAAEqwj0hGmc2Ykq213EH9xij5TMueXDfMgDRzZHhTugqhySZU+QA753hd8YviZSKUqhpI8ApbqjRp/lmCG4Sp9cqly4zih2ZTeaNWovkiqEaQ2r/4/Dw65hGYt2R2SDJTE76miKwn+ZGv3ezoPOjm/IB4quGZ6EqB75aU9X9YBNuPF7kKXac/dmD7VJykN0Btsjg1KAlhbdcW8rFQ7jebWW2CRW6sHQXrTKN7KukCPZwWptjLPrnSCO56Mg0Uq1F/HJmgE2Va97qiPxmhpLybyNApZSA7ZHeDKSqlMWI6Uhde1Li7xCskUZ66AMyhuIuRB3TrYmuCv0S66BCNJICexc8/VDx6RuItxGuuq1w1hEl1mxk/2kVwzSS1RRTO9yt2TbGxedqXqqrqsuIKLK+6eLgT3GR1D3Jrt9WMchlFdABRAFbL5bbfxStRda0b7AdMKQjyHxTVDBrs7MceZ+0Ooelyki+hSBGKDnLMMAps8lmF9vusY5dISEdUl6ylKMZYRp/TeMGatoE2W9N4wpdaxsHSL75wGyZsQNVDrc3syUaya2rROaazFaO8bs3Q08z26rPqKtujmYN52jjAB4heKQ1zGzmXqdDPw22S1n19jM4QBs5rl/iud00tSywCXloZUFo2yrXyFhM6m0P3x7Lxi1FLdPVrrCf6iwaJJ4ziHV9Hu1cGzPbM4pkGhnbni8T72loJF084yme6NpxyBdCzlX2+0Stse6EOxj6asYOeUw0vcJ7B7mwZm4+EpDGnmNdLUqpP21WpBLJLsEmFqYw67bz42DTUpL6uD4zdWYjZ7dNzZgy0kM12+rTgsodFtGArfsOYO72chuVr1r/hOrvph6bdyPlfrCtWv8oah/rzcT+BsQfwIY93JHXnMYQhe3YFmzCavuae+e+KfDmNDLV9W3rH+v6qx/N4jYrwE3OsGz9o9ugvVS7ltwK7tsYEam+Hr5cTdymfGD82mSmZt0gobA1+trki1FMFKmLte7i+rXZXKl0P5pJE7ehDtHHYKpLekaM7SLUoj8vv6AmOV3o69zGnO0yQu5CnKm/ajaSTNzmQMzWV5HM/okc/Q9/ZMEP'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin5_table_03142_31420_14203_42031_20314_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
