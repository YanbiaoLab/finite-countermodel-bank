from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_table_31420_02341_14032_40213_23104","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_table_31420_02341_14032_40213_23104","model_table":[[3,1,4,2,0],[0,2,3,4,1],[1,4,0,3,2],[4,0,2,1,3],[2,3,1,0,4]],"priority":303,"rule_id":"false.finmodel.setcheck.fin5_table_31420_02341_14032_40213_23104.all_equations.v1","rule_key":"false.finmodel.setcheck.fin5_table_31420_02341_14032_40213_23104.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWcFuwyAMNciTvJ7Y1A9AO/UzfNyxn0R32nGfsE8ddkggIYs6TZqW1q9VIkIgxbGf/aiDCqQjXAF0IQHlkzT0AB72CQRI8iUAjr+ciwZrYJ4zctvBQyeHfH7Yh11cWRJv39bYzIFhpyEQzzkEvKtxTPA4ejT2A470HS2s3m4wGAw7BudPZjZK0oiFGrURhAtRWNOPqVIuLUqJ+CNeJIgyHrEUKHpJHpEkyeohN0vF5bEj3QjxvxoykqYY/cE+lJqBS6WBEVybWsh3hgx1jYa/g/dq+KSe6FL1S3Fsnz2/eR3MtXvmlNNkZk/DrvAxSbgcA+9VOWa8eAhP7b2DlOwTSDtoG28wBVsmxFCHJUDOrJlmfOhWZ3UWbAbDXYPmIr9tHADOswqKL7An7R75sy7xoAsYK8OTsCZpz3NjB96YzFzlJjVb0uR3WkmDmqGDplmubsPLHUws8iRcE2xB/cj5IXG3tXORb74mZtFsNJ8Vx/ijZeTeGZD0nchuZOhLKMwGdJXQLqMCnylEnmog2400GDaCTbf+tR5YkOelkRGYcAw53wub12sflqJu+aRYk26J1IFhQ5uN5Q/G1LNssnd22/gCDpAhZg=='
_TARGET_BITS_PAYLOAD = 'eNrtWcFuwyAM/dR9wo47rf6kHnf0Z/Q08QHVxqmzNAs8cEggIYs6TZqW1q9VIkIgxbGf/WiUCqazXAGOHoTSKTf0IEH2CRaB/CURdL+ciwZrcJrTYduBQyf6dP7ch11iWRJu39bYLIphpyHgjikEQqxxTPIxejT3A870HS2s3m4wGAw7BqZPYjaC3HCFGrXhMxdyZs0wpsp8aVFKuB/xIonL45lLgaKX8iMgJ1k9pGapuAJ3pOvE/VdDOtIUoz84+FIzYKk02ElsUwuFzpC+rtHwdwhBDQ/qiRGqX2bHDsnzm9eBWLtnTjlNZvY07AqPk4RLMfBUlWPCaxD/3t47SMk+gbSDtvEsU7AlQvR1GAhjYk2Y8WFcnTVasBkMdw2ai/y2cRE5ziooPMietLvDh7rEiy5grAxPmTVJe94aO+DGZOYqN6nZQJPfaSUNaob2mmaxug0udzC5yBN/TbB59aMYhsTd1s5FvoWamLNmo/msPMYfLSP3zsCk7yTvRvq+hOJkwFgJ7TAq8JlCxKkGst1Ig2Ej2HTrX+uBBXkeGhnBwGPIhV7YvFz7MHC65QOuJt0SqQPD+jYb5z8YoWdZsHd22/gCPfBP0A=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin5_table_31420_02341_14032_40213_23104_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
