from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_table_34120_20413_01234_13042_42301","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_table_34120_20413_01234_13042_42301","model_table":[[3,4,1,2,0],[2,0,4,1,3],[0,1,2,3,4],[1,3,0,4,2],[4,2,3,0,1]],"priority":304,"rule_id":"false.finmodel.setcheck.fin5_table_34120_20413_01234_13042_42301.all_equations.v1","rule_key":"false.finmodel.setcheck.fin5_table_34120_20413_01234_13042_42301.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWVmOwzAIBYsPPjmCj+K5GZ2TTyC146XrSCO1HZ7URY5DDNiPJQhXQEgFnkNmQPvZPgrcX8FkF+BkX89KnZFIuEpReGt8Axcg14LPquBLLIwP46ab0/TwaFEwL5e8aJFl8dQulSAQCAR6fAFlSNk4Ig8k73+QhwAiNiQ7zcyC8AFCzewPEgtYNPCdLAFGbWE+nRtJzmsJBN7vsPkpSaLDZsbzji4PHbZ+EoZd/xZC7qqUlxzYvLn5sc+sqHpzyu8aZTXeyi+gWtFSc0ZgWzpppwekQQ/hNY3EYyDfzTB5l2BCdSxM7EE+VJq1/NmTuS9VIBqRIBAIfATUIgpg8Wgz8Gn2ZCDNnYPa+7lAgmXOzgOBQH/YdD9CS17jDULP1VvfDbwPmgTuNlXzvzNkkd1SOtT0btWysI91YTcy45mrCOYegDyZRvq9ZTT/qQ5dSE+P1FHhdu818HY1m4fQ1vHvIqHUDUl9zbbNTFdi51TdBQK/AKG1PbuA07YbGm/KXFZPHaJ+d/L9yAZIqQodCHF/PZTP7w3lGJromGGh48Bn4QcIYypf'
_TARGET_BITS_PAYLOAD = 'eNrtWVmOwzAIPfmUm42P4iPwyQcyTCC146XrSCO1HZ7URY5DDNiPJaJXwMJJn0MmFfvZPqDUX5FiF/RkX89KnVEYqUoBfWt8KSVl14LOqshLLIwO45ab0+DwaAI1L6e8aJFx8dQulTUQCAR6fCtnLdk4Ig8k73+EhgCCNoQ7zcyC5AFCzeQPQgtYPPAdLgEGbGE+nRpJzmsJBN7vsPkpKQjDZpbzjk4PHbZ+koRd/xbI7qqSlxzYvLn5sc+suHpzyu8aZTXeyi+gWoJUc0YlWzpDp4eWQQ+kNY2UYyDfzTBpl2BCYSxM7EE+lJq1/NmTuS9VIBCRIBAIfATAIopK8mgz8Gn2ZKDMnYPa+7lAgmnOzgOBQH/YYD9CS17jDULP1VvfTb0PWlDvNlXzvzNkwt1SMNT0btW0sI91YTcyo5mrWOceAD6ZRvq9aTT/qQ5dSE+P1BH0du818HY1m4fQ1vHvIiHWDcl9zbbNLFdi51TdBQK/AIu1PbuA07abGG/iXFZPHaJ+d9L9yKbCpQodCHF/PZTP7w3xGJromHSh48Bn4QdEHUbX'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin5_table_34120_20413_01234_13042_42301_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
