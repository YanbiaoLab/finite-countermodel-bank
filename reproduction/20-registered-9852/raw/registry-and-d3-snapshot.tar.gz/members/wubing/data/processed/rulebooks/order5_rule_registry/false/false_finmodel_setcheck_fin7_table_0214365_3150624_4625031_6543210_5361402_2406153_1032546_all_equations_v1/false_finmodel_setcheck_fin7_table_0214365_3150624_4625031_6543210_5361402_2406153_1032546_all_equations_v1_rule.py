from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_table_0214365_3150624_4625031_6543210_5361402_2406153_1032546","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_table_0214365_3150624_4625031_6543210_5361402_2406153_1032546","model_table":[[0,2,1,4,3,6,5],[3,1,5,0,6,2,4],[4,6,2,5,0,3,1],[6,5,4,3,2,1,0],[5,3,6,1,4,0,2],[2,4,0,6,1,5,3],[1,0,3,2,5,4,6]],"priority":302,"rule_id":"false.finmodel.setcheck.fin7_table_0214365_3150624_4625031_6543210_5361402_2406153_1032546.all_equations.v1","rule_key":"false.finmodel.setcheck.fin7_table_0214365_3150624_4625031_6543210_5361402_2406153_1032546.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNqlWUly5SAMBYqFljoCRyE3U1LV924zD5Js/D+V6sST0PSkh/ofRWNiNGSM8ddf+Sf9df3AdZEeXxc+mPSkXqQnxpn0hk0flo9MKHexXY9ly920EOYHUB5cIqvEa2WJdeMss3+bl3NDwvIAy66YZfkmPgksOubHNswf+bKbd1XJvq5tf+oGzBToSu6mJBHW7ObH8hDaV5MpPttnd1EGsTgzpl/WDE9Qe9Xt3/gaOWe2FXpIk++GSpdgZ0UPl5f9Zphv7woria1JFLKWWJWbw7B4MYWB9iha9p5XNkwia8ruuudHYfPA7HunbgLabmr+xsAE+sWmaNSFXJM5YIizSs5MCBuLlk3AvF8e/NjAbkYPXFeNfYWq3T1+ti4kOjm2QQh3qj/XP1KMeXxEBysFoVwQSxsQ8+xwNWwlqNAS98iQE++Te/OKsGpNiRJ4WRXIF7/m8wUmYlVYABsKsaAnA27BplTYKH2XSi6KBen5VlXQt1AsaQTA0AtcEOrxkcCWzSLJfKG8ekGQN8c1koono2B8YPccJbVgC5s3z2VsbVmKgsRjsXKHI0AvAtpuEc1eEZHHwn6R/rV9BuRySFb/Vy35z55siBJ2Q5799gFsT/WrcADiVIuE3ArmrhTTczkLtSIfILRwiK8628j9zel/nHCtmWhvc+Gus8VO25o/cp6DEJ8vUhLnWghLIQq8jNixm/tktwY24Oh2FRZbvoXnlNA0uWhk0rVXhy1IXqjg/jOzWpGX5XgjHmO21v5uFRop0FGKSlU/oJF33KF1Nrd2Nu5E8EJnk7zq9M4GcokiBWzwMdYukb9aiUJG71JnIwY/eAO2okmslWO1WgAbmC+WK253PNfHoWBERnhNaAM3NDJ2G2B1plCjo4ToF9CrNBLcnN9WO8VYCez0BmzQpdKsK/Zj+h0hWludfQbbYPk4Q9j1Nj2f4c23nY2MSFpzNIXD7xcpSY3NJK+VERBOqq8xksG27w93YMOh9sK3rRB+lGXZc7CVOLDZDCmV5SsaqY60cM2WvFHMnXCnW+f5DziM4G2MuMO+qlpXgrsqtbKfqrlw6zYF6CCI+pzRLbJLDjmWjHTORiYa2aY9e3uyS8NmhEhrbFY135oa+jD7Khp2qw3BPqeRATUgY532TJpa7Qh+SFHUwW1mXmGJTDyuWqS6OOuLY7eJlJJUnezbPTiN9IU22VsaSUd8Dm5pZGiHzEUQRVZ6n5PxubMpk3A3ey30uIaTqquDLfRXNrD5PUXJmPvJ4FP7ppbnLP2FQU852bmDCWTQtXGCZeVb5C7CD80qArT/Wghj2tNPH0K+wZuOU0f/ZdASFn4P0gki7GkjUT28QQZ14/1+piCBeQQNWwfgUM9swug/BiHH8B3YFBrJR/+FENG5JRxs0IfiUM4dtJf6cDb6OYB20tS28rie/VAFy6tR1v69lWd/6dGPTAM/P7OV8DA8UjTizMRKQ4zzaWQ/Unu/gDSKh8bwulMvNBIU8t0rR1yjj8IY43T9BzNAc3g='
_TARGET_BITS_PAYLOAD = 'eNqlWUly5SAMvXdXJbpZOApH0FILCmgzD5Js/D+V6sST0PSkh/ofmBiNiRBjdNdf+Sf9df3QdZEeXxfOxvSkXqQn0cf0Rkgflo+iLXexXY8Vyt20kOYHVB5cIqvEa2WJdeMss3+bl/dDwvIAy66YZbkmPgksOubHwc4fubKb81XJvq5t/+oGzBTqSu6mJBEh7uab8pDaV5MpLtsXdlERsTjTpF8hDk9Ae9Xv37gaOR+3ZXtIk++GSpdgH0QPl5fdZphr7woria1JZLOWWJWbw7B4MYUB9igG9p5TNkwia8ruuudHdvPA7HuvbkLabmr+GssEusUmE9WFXJM5YIizSj5OCBsLlk0ovl+O3NggbEYPXFeNXYVq2D1+ti4kejm2Vgh3qj/XP1KMeXxEBysFoVwASxsS8+xwNWwlqMASd8OQY+6Te/OKsGpNMRJ4WRXIF7/x80XRYFVYABsKsYAnA27BplRYI32XSi6KBen5VlXQtVAsaUTE0EtcEOrxkcCWzQLJfKG8OkGQi8c1EoonjWC8Zfc8JLVoC5uLz2VsbVmKgsBjsXKHI0AvAtpuBuNeEZHHInyR/rV9WuRyQFb/Vy35z55siBJ2Q5794QFsT/WrcADgVAuE3LLxrhTDczmztSIfILRwiK8628j9zek/nHCtmRhuc+Gus5lO25o/cp6TEJ8vUhLnWkhLIbK8jISxm/9ktwY24uj2FRZbvtnnlNA0uWhk0rVXhy1ITqjg7jOzWpGX5bgoHmO21v5uFRop0FEwSlU/oJF33KF1Nr92Nu5EckJnk7zq9c5GcokCBWz0MdYukb9aiUJG71JnAwY/egO2oomplWO1WgAbxS+WL273PNfHoWBERnhNaAM3NNJ0G2h1plCjjYToF9CrNJL8nN9BO8UECezwBmzUpcKsK/Zj+h0hWltdeAbbYPk4Q9j3Nj2f4eO3nQ2iSFpzNIXD7xcpCY3NJK+VERBOqq8xksG27093YMOh9sK3gxB+lGWFc7CVOLDZDCiV5SsaqY60cM2WvJHJnXCnW+f5TziM4G0MuMO+qlpXgvsqtbKfqrlw6zYF4CCI+pzRL7JLDnmWjHDORiYa2aY9e3sKS8NmhEhrbEE1P8Qaejv7ykR2qw3BPqeRFjUgY532TJoG7Qh+SFHUwW1mXnaJjDmuWqC6OOuLY7eJlIJUncLbPTiNdIU2hVsaCUd8jm5ppG2HzEUQGFZ6n5PxubMpk3A/e832uNqTqquDzfZXNrC5PUUhxvvJ4FP7hpbnLP2FQU852fmDCaTVtfGCZeVb5C7CD80qArT/WrBj2tNPH0K+0ZuOU0f/ZdBiF35P0gnC7mkjUT28QQZ0491+pgCBeVgNWwfgUM9swujfWCHH8B3YFBrJR/+FEMG5JRxs1IfiVM4dsJd6ezb6OYB20jS08rie/VAFy6tR1v59kGd/6dGfTAM/P7OV8DA8gonizCRIQ4zzaWQ/Uju3gNSIh0b7ulMvNJIU8t0rh1mjj8IY43T9BxlA/a8='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_fin7_table_0214365_3150624_4625031_6543210_5361402_2406153_1032546_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
