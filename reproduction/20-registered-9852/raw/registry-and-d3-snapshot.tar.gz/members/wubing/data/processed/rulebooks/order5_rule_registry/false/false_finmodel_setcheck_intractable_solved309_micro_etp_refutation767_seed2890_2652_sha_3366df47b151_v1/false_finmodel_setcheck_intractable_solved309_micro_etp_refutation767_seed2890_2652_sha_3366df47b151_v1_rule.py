from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin8_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin8_explicit","model_table":[[0,2,3,5,0,5,6,7],[4,1,5,1,4,5,1,5],[4,6,2,6,4,2,6,2],[4,7,7,3,4,7,3,7],[4,1,2,3,4,5,6,7],[0,1,5,5,4,5,6,5],[0,6,2,6,4,5,6,2],[0,7,7,3,4,7,3,7]],"priority":748,"rule_id":"false.finmodel.setcheck.intractable_solved309.micro.etp_refutation767_seed2890_2652.sha_3366df47b151.v1","rule_key":"false.finmodel.setcheck.intractable_solved309.micro.etp_refutation767_seed2890_2652.sha_3366df47b151","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WUFu6jAQHVteDH9loX8AV0oljjGquoAdRzISlfp3FPUAPWrtxOHT4kmC8IyFQGFIXp49M+/FvAFBfuXxt38vB8fhYDhyEPoIDQfM+OIC8MQFNjsmQFwALBfYc4E4croZiQrWqbgTgalSOYCtnoMmAVWpUEhAtdu2FrrqKX489YZKuQzZCpX+4yYQHDCrZnqCAWbGFdup3xJojo0q2pMm2FdnFNE+nSJYVM2SPWytHtoLGOe1wAhDVCy2Xffx+qqVKM//uvP7u1qxfTjr9YrNbkPQKrYzrVdqOeJBc/zRBCNUVbadJtqzptaEGQfXdhQ7u1ZStitfpaBsiyxZO2XLQLG4SFnhoV9Asn0Fr3yxvDUxfe77H67aCBYbXZiJp+Rnt8aQgFYOtnkBTWLqQKhxJmVLZqsAJdOVgaPYVO4thkMBOhRaXqzuXqzpvE/MEpAvtCwIeS9KU+hGIDvQIrEC3yRmND6JiovA+KCeK46k4YLLC1Z2BrAYIrHWfPxf2ihe2jHNXmKEmY0JRXDENMB7DCZmIN/vmrgM5aVkwNoMNKTkSdxGpspyY/qvL99JKRteGHkSLzYzJ+pNn9lm4rvWxTbJrGn9xfNkp191TeH2vDdOtxEOrmnbnLiWa+5jiZ+nU/v2haxAOwFnabi5jBnItjVd/E64RFM5OouBqbPmHih6bvtfwrcmZQMTueYZLsnSStmYvxbCj92aNmtIbJf3uFAM7qC+4SWngrZ6cHkN95RdoUFhcl9giY1sp7nzw92B9nB7jpJtg90g2S6ah0bKZs2iXLePTW/ZjcRlNosedGOIXK5V2Fak5765/QZ4JkTX'
_TARGET_BITS_PAYLOAD = 'eNq9WUFu6jAQPWoPUFF2v9JHwkdiB4uqmmMgNVJ9gAp59ZmFZU/txOHT4kmC8IyFQGFIXp49M+/F/CWg/Mrjq38vB5vhYDjyZPsIDAfMeOIC9MkFjnsmAFyAAhfYcQEzcroZiQrWqfg1UKxS2VKonoMxAVWpgE1AtdsOgbrqKW489YZKuQyECpX+4yZgPTGrFnuClmbGFdup3wJpjqMq2qcm2FMXFdGevSKYUc2SHR2CHto7Re+0wACtUSy2fffy9qaVKB9/utXrq1qxvfjg9IotHKzVKrYVnM5qOeJIc/zTBANUVba9JtqHptbYGQfXdhQ7e1JStitfpaBsiyxZO2XLQKa4SFnhgV9Asn0Fr3yxvDWJfe67H646ChYbXJiJp+Rzd0KbgM6eDnkBY2LqSahxJmVLZqsAJdOVgY3YVO4C2m0B2hZaTqzu3kPsnEvMEpArtAIJeS9IU+hHoDDQArECPyZmMD6JiovA+KCeKw6k4azPC1Z2BrAYIrHWvPlf2ihe2ibNXmKEmU20RXDENMA5tNFkINfvmvgM5aRkIIQMNKTkWtxGpsryY/qfLt9JKRteGDkQL7Y4J+pNn9lm4vvWxTbJrGn9mdVkpz93TeF2vDdOt2G3vmnbnLiWb+5jgZ+ndfv2haxAewFnGbm5NBkotDVd/E64RFPZ+ICWqbPmHsg4bvtfwrcmZaNouOZpL8nSStmYvxbsj92aNmsIbJd3uFAM7qB+5CWngnZ+cHkj95RdoQF2cl9giY1sp7nzw9+B9nB7NpJtg90gOSyah0bKFuKiXA+PTW/ZjcRlNgsedGOIXK5V2Fak5765/QbUSyxf'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_intractable_solved309_micro_etp_refutation767_seed2890_2652_sha_3366df47b151_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
