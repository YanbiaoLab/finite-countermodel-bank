from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[2,3,1,0,4],[2,3,1,0,4],[3,2,0,1,4],[3,2,0,1,4],[3,2,1,0,4]],"priority":747,"rule_id":"false.finmodel.setcheck.intractable_solved309.micro.z3_o5_seed1336_419.sha_ed12326c0d86.v1","rule_key":"false.finmodel.setcheck.intractable_solved309.micro.z3_o5_seed1336_419.sha_ed12326c0d86","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWFtuAyEMNIgPPjmCj+KjESkHL35gSEpXUbWtog2jatOY3TgZw/gRYOAOhSASISSI8CMSFHkNfjm6+5egjLV9bLskSKWyo+ieT0NKkQAJMqQMoTYnyL+P/y4DTC2qAfjaGM2NQgT+9wz6mDvgoMS+EzY2Ni6GHIZ6kClxFi2OmZqYhK4qLAIhocq2GitM2m3KE8GWSTNIEg2hP0kkb4V7I4w5CO3noye1DCvWGt1FEvLgyp7IMNGtyyiLTF9mlmWllslRctlvK4usKo44moc+bHnES4OH+4icfdgkPLIF/My8tm162GIPG3nYdGuMfVKvftiknGXWRKKMNiHMKkvjsqisyRlwrlzTpoNgsUjzUVPOr4wYA0KRriBVoNorvrY5IwStoCGr+GsZLbcrv0YzS8z8oDANJIIflET6m07ijRBujYD8ImvCtNw+uNIn8vyg9iw4kyhyHBAnR9Lg+K0ezREZ/17HPqw9QtvzGfQw7ASwsbGxsfEfEy0pjFeVSuuupIux6u2MoZTOCCG2jyLNe1ajrMaGN/56mhm7a+uUvGQE75x64qyfEbY49Ypl2JYmfZN73TS/eaoSn8nbY8hLDkgWJmnjdDBlxmm27SMqX/7W/h4MSBamxfx86aM3jQ9jrb0pNz4cVVW7uLqTLw2bN5IL05QARu6fG8+0ST4fNo0ULayueAjL0f/CdDi7fhBIDu8Xs6FWrQ=='
_TARGET_BITS_PAYLOAD = 'eNrtWFtuAyEMPHikcDQfxUfgkw8ELn5gSEpXUbWtog2jatOY3TgZw/hRaeBGEagAIGUq9CMyRXmtfjm6+5eAhKF9bLtkyjGwo+KeT0POBQiBEuVENTQnyL+P/y4DzC2qlfjaGE2NQiT+9wz6mDvioJS+EzY2Ni6GVId6gClxEi0uCZqY1K4qLAI1o8q2GgNN2m3KU8iWQTNIFg2BP0kkb4VbI4w5qO3noye1RCvWGt1REvLgyp5INNGtyyiLTF9ilmUlxMlRdtlvK4usKo44moc+bHnES4OH+4icfdgkPLIF/My8tm162EoPG3jYdGuMfRKuftiknGXWRKKMNiHMKkvjMqqsyRlwrlzTpoNgscjzUVPOr4xSKlKUriAHgtArvrY5C1WtoCmp+GsZLbcrv0YzS8z8oDBNIIJflUT4m07ijVDvjYD0ImvCtNw+uNIn0vyg9iw4kyhyXBEnR9Lg+K0ezREZ/17HPqw9QtvzifQw7ASwsbGxsfEfEy0pjFeVSuuupIux6u2MoZTOCKm0jwLNe1ajrMaGd/56mhm7a+uUvGQk75x64gyfEbYy9Ypx2JYmfZN63TS/eaoSn8nbY8hLDkgWJmnjdDBlxmm27SMqX/7W/h4MSBamxfx86aM3jQ9jrb0pNz4cQVU7urqDLw2bN5IL05QARu6fG8+8ST4fNo0ULQyueEjL0f/CdDi7fhBIDu8XmNAaiQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_intractable_solved309_micro_z3_o5_seed1336_419_sha_ed12326c0d86_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
