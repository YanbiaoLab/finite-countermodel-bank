from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin6_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin6_explicit","model_table":[[5,4,5,5,4,4],[2,3,2,2,3,3],[4,1,4,4,1,1],[1,5,1,1,5,5],[0,2,0,0,2,2],[3,0,3,3,0,0]],"priority":749,"rule_id":"false.finmodel.setcheck.intractable_solved309.micro.z3_o6_seed215_3050.sha_964b3a4ea79d.v1","rule_key":"false.finmodel.setcheck.intractable_solved309.micro.z3_o6_seed215_3050.sha_964b3a4ea79d","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmc1OhDAQx4cPBU5QssfNujR9CA8b3ZAe4Oaj+AAm25g9dG8b4gP4KDwKj8DRAwHbRTdGEaMuCcr8EkqTafLPTAcy0xrwnjw39GuWwji5Aqj8oUUeWbRjlI7OefHiebEZUsUFU43nADYEvQuXx5kBCIIgyCQpG+d1WjQKa1C1ujlOKyW2wfj/kDehq1Ugr/+Ra3dQH1JSp2JbL9UDZyXye/LLQlgLUMMK5rfCAR8WsIISC8xR88CyhNJ7lkm55yEhlHIuZRC7Q+ybyHiYcn4Q0rIx30qXkNiNcCO+xTqlus1N6E66KSMkakMZbQOMDYIgSNUYvdaTdh+itwIXurHycUsmjuXMP7EU6nEKKHUdja3Olx8b9aD7liMxlZWxiOpzcCHdU6gF5s3a8LosZ7M9gGEvQdjgQQjyz/Vs7dFP17XM08XHX2bHsqbB/g5BJs4zHhBXCg=='
_TARGET_BITS_PAYLOAD = 'eNrtmc1OhDAQxyEcPPIIPAqP4gMYsrftYWO6iQ/go3iDQ0NWswcfoinrZo8bCidA+RjbRTdGEaMuCcr8EkqTafLPTAcy0zbwHtdt9Gvvwzi5A7DSoUXOeTTnQozOefriubMcUiWHWo2PACUkvQs3x1kDCIIgyCSxjeJ16hiKalA10zhOLSW2xPj/kDehM1Ugb/+Ra1dgHlJSp2JbL5kDZyXye9x7h1ZbUMMadte0gBS2sAYbC8xRc8G9QIhL7hEyY7GUQjBGSBLmQ+wb9VjsM3YQ0rIhW5BcyjCPcCO+xcoXus0NxJzkPpcyakMZLRKMDYIgiGU0vdaTdh+0twKnurFKcUsmTlXsPrE46ikcsHUdja3Olx+byKD7liOolZXzSOhzcEryU6gl9c2qybosT/sZQFNugJaQQQzkz/Vs7dFP17XM2cPHX2bHMsPA/g5BJs4zLnAaLA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_intractable_solved309_micro_z3_o6_seed215_3050_sha_964b3a4ea79d_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
