from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin6_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin6_explicit","model_table":[[2,5,0,3,4,1],[1,3,4,5,0,2],[0,1,3,2,5,4],[3,4,2,0,1,5],[5,0,1,4,2,3],[4,2,5,1,3,0]],"priority":751,"rule_id":"false.finmodel.setcheck.intractable_solved309.micro.z3_o6_seed2331_2441.sha_bef8b9628b21.v1","rule_key":"false.finmodel.setcheck.intractable_solved309.micro.z3_o6_seed2331_2441.sha_bef8b9628b21","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtzzEOgCAMBVBIHBx7BI7C0Ty6GpaOKiwm75G0HSjk17JOGy3usk2+1dO8P1uJfDv/f1wnPkUpa6L0t1EAAAAAAAAA/u4EOYsCVg=='
_TARGET_BITS_PAYLOAD = 'eNrtz7sNgDAMBcDRGS2jMIJLCiTyEY1LCGmQ7iLZLuJE76rr7HeLUc6Pb5U0H89WIt/O/2/9xFSUuiZKeRsFAAAAAAAA4O8aEvVu4A=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_intractable_solved309_micro_z3_o6_seed2331_2441_sha_bef8b9628b21_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
