from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[1,1,3,4,1],[2,1,1,1,1],[2,1,1,1,1],[1,1,1,1,1],[4,1,1,1,1]],"priority":761,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block001.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block001","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt1b8KglAUBvCjCN0tg6DRGzTYOwRKBNXWE5Vt0tQDNDQErr1A4LM01SoNIpZp1nhLKcXq+8FFkCuH++d8SkRk0Ssbm6BE22nQdfxhnk/CKGF8pPz6cdyTvvJsHr8PAAAAAAAAAAD4dZFI7euXFoqWpuHYc7mINrJeQDFXeCOlAqr5omIGmi0XhYilj5icvrPQOhXnBkdntdeydVbrfPIOyfRdbzFrerodtav/Z8sWUWE5aQP/zDT5XCF5xCWLJE4qJxqQXVRM6owv4zQex4NbnVskM7UhutXszWpXwnjT9g=='
_TARGET_BITS_PAYLOAD = 'eNrt1b8KglAUBnBLxCFca+pZhF6gVWho6AGawq1bT9RWQYRC75BD0HUMgmwzED1p1nhLKcXq+8FFkCuH++d8RkTE6JWeSVCi7lTZGuoyzyeylLA/Ur7/OO7ZOng2j98HAAAAAAAAAAD8Oknk8vVLk0VLc3HsudREG3kuoJguvJFRAdVUUTEbzZZLQOSnj1iYvmNonYrTlaYxaLvZOutQb2itZHpnM5ocNceU9tX/s2WLKLmctIF/Zll8HFC44BGjiJPHiVZkFhWTjs+HcRrP48HZ7hbJvncS3Wr/zWpXifmdMQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block001_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
