from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,2,2,3],[2,1,2,3],[0,1,2,0],[0,1,1,3]],"priority":762,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block002.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block002","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9Wc1u4yAQBsTBuWE/AbW8Uh8DRT44PfWRnFVWSm/ZqA+wj7owYH7MENeNXQ5pY2wPM8z3zcfkD1EHogiMT/hUlYQvXVPpLwc5EkY46YT5AjdyUhj/ijMvY2Hi9WRejAxnGBmMUP0p84l3NrTazonP3zgKRSgn4BdNZi5gAryqSDz7r/vbN3XdDHqWJc/8+uju1+tNv5Gwikyhs64YW+bqzVxlLHWF61XArNCLN/8S8gaLlR9+1rzUxNd5kJsfG/hzU42YRce6MnLv0LRP2hWF79ovWI7bYELiPap4+P5KITZmUWnUR3inMiZZHImfGK/0J60V83eP4Tbsh8anzgH5U8bGCGv7jyIh7DKOmmOEQdMDhtxsOJL2sN3XQ01tf/v+whtiqW3fUWTYncAGRUXHE5i2qvYHm6tGnu53Mjk2qtGGAAOQmsSVmF2Gy0CKYH6H8QafUDnTceu3d3ACmy3RMdjsbm7LaFYSjQ4DVkfA61Vz6vsBRAzdjGOsBoCoWWdcVu6SNtKGLtVcPm3kxmnzSe7GI4+BunZgg7TparVl2pQrG8ckbDbWWS9L3Y7NlwABmO1De1yzpb6yZTIV8jMxiIjs1WArqGVfDDZMm4o6Q9ky8jMBUtoFWVWfXgJ9sOTJKncGKe0sWRzJQ5Fusk0OhKIsqmNn0nUt28gF42d3H9r2CBTVflyrum7bvq9eLvKsrXS3hKOVttI8QZnjvfeGTl1dv7TH/nLVxkSnKXPkzUgEnVxpbMX9Pke/34Ohj864db2KWhv7DYJoFjVtaJAp6akspI8qW+MNgeiyobyIoxNEMUdbsPE524gUCA+0oTq13pApOMKGUhyrZhJEV3/zIchbF8qxCjZkOUnnMlLMYRoLIpeVNm2SpQsRxXI5pLGMTPNZZpWtm0ggAhszbgr3IF0AWyIjc7CBW9yDLW8R+C0N4ab0AdiaRA/U/lbYTRPfcVqj6X0A2JQKgJ4iWU/bJeW0J3zOhVpGhu1JooZy9CRvvQ2vcaMH3bR9hNhJaz+qbK4x4W81hpR/nSCYjsZthK6KXZBvsbxZj/IGDCKIsABgNnwoYr+Y7QNNwgPKtAabu9XrlBA1LACYjShJvV/KNkiCoTRqTR41pAPlFxfZ8KEg6eY9qPiW64f40mDgcHhCv5b7jM3AmGKnmBUOHaVP9TcueBvSdOYO+kNCd6x1MDoHwqXfrGwMfxCiZkoDZaS3QX/6CPDOIA+QcehqKs+d1KZg0/kEdFy9fmkUG7cI17vKjb+o/sISIrDNRnfjHHFaFc8s62SkmLVIWf7uEIZ1im5RRkJRgcrtPRyC0Jvu6xcUXTWvbIVOOCPbDycjWdaud0WFbNm/MGCb9IDhIykX9PjyMW4ZbDQjduQSkkkK8Z0+apAUflpA2v2lA0kpQ3gBOwixi8HxZMzRWSbFCfuFBgktEntl+hbnhKN1MchoZM1JwIINIXZ7qOriPEDAtu48Wv6tBon800Cw3UiU2G2i8HB6QH8lWtcgKZ39+EJL8XuVLeiBpQaJvW5+UVtoXj1qkJApqRNiF/npA+b09fSUsEKh6DPbGc9hR522iS0D/sw5IZTNcIbiXwKboQ+kZYDISJ1ISguig1exq9uU/wFu6gFg'
_TARGET_BITS_PAYLOAD = 'eNq9Wc1u4yAQftR9gCqbWyNttPEj9dT4YEU8RqW1XJ7A5hYfELAwYH7MENeNXQ5pY2wPM8z3zcfkjyJ3RRSMF/gkI4UvbT/qL3daKaG4apn5AjdyVRi/ijOfVWHi42pejAxnGBlCSf1J84k3UXfazpXP31gxoiRX4JdMZs5gArwaVTz7q/3d9MPQ13pWJM/8e20Pp9NRv1GJUU2hs64YW+bq0VwVInWF61XALNOLN/8q9Q6Lpa9+1rzUxNd5kJuvevhzJD2bRce6UnHv0LRP2hWC79o/WI7bYKXiPRp5+P4hITZmUWnUK3gnMSZFHImfGB/yJ60V83eP4Tbsh8aLzgH6U8aqCGv7jyIh7DJummOYQdMDhtxsOJL2sN3XQ01tv5vmzHtlqW3fUWTYncAGRUXHE5h2HPcHm6tGnu53Mln1pNeGAAOQmsqVmF2Gy0CJYH6H8Q6fUDnTcWy2d3ACmy3RMdjsbm7LaFYSVQ4DVkfA60l/bZoaRIzcjGOsBoCoWWdcVu6SNtSGLtVcPm3oxmnzog7GI4+BYXBgg7RpB7Jl2pQrG8ckbDbWWS9L3VbMlwABmO1Dd1uzpb6yZTIV8jMxiIjs1WArqGVfDDZMm1E6Q9ky8jMBUtqZWlWfPgN9iOTJMXcGKe0iWZzKQ5Fusk0OhKIsqmNn0nUt28gF40t7qLvuBhTVvZ7GYei6phk/z/SirbTHhKOJttI/QZnVofGGru0wfHa35nzSxlirKbPifaWYnFzpbcX9Pke/HYKh19a4dTqxQRv7C4JoFjVtqKYp6ZEspI8qW+8NgeiyoTyzmxNEMUdbsPE527AUCA+0Ibl23pApOMyGkt3GfhJEJ3/zPchbF8pqDDZoOUnnMpLNYRoLIpeVNm2SpTMWxXI5pLGMTPOZZpWtnUggApswbjL3oFwAWyIjc7CBW9yDLW8R+C0N4ZbyAdj6RA8M/lbYTRPfalqj6X0A2AgJgJ4iOUzbRem0J3zOhVpGhu1JooZy9CRvvQ2vcaMH3bR9RNlJaz+qbK4x4W81hoh/HVOYjsZthK6KXZBvsbxbj/IGDCKIsABgNnwoYr+E7QNNwgPKtAabu9XrlBA1LACYjShJvV/ENkiCoTRqfR41pAPlFxfZ8KFQ6eY9qPiW6+v4Um3gcH9Cv5b7jH0tBBHXmBXurZRP9TfOeBvSdObu+oNCd6xzMLoEwpXfrGwCfxCiZkqDFKqxQX/6CPAmIA+QcW8HSS8t1aZg0/kEdFy9fmkUG7cI17vKjb9o+MISIrDNRnvkHHGaFM8s62Qkm7VIRf7uEIZ1im5RRkJRgcrtPayD0JvuaxYU3TivbIVOuFDbDycjRdaud0VFbdm/MGCb9IDhI0oX9PjyMW4ZbDIjduQSkkkE8V0+apAUflpA2v2lA0kpQ3gBOwixs9rxZMzRWSbFCfuFBoksEvto+haXhKN1MchoZM1JwIINIXZ7qGrjPEDAtu48Wv6tBon800Cw3UiU2G2i8HB6QH8lWtcgKZ39+EJL8XuVLeiBpQaJvW5+UVtoXj1qkKgpqRNiZ/npA+b09fSUsEKh6DPbBc9hR522iU0D/sw5IZTNcIbiXwKboQ+kZYDISJ1IRAuiu1exq9uU/wHdh2/W'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block002_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
