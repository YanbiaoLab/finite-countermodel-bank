from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[2,2,2,4,2],[4,3,3,3,3],[0,4,0,0,0],[1,1,4,1,1],[4,4,4,4,4]],"priority":763,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block003.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block003","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmb9OwzAQxs9pRNKFpmVhqFCJAs/AgNQIZWhY4BF4AQY2JuqBoRkp3Yt4BAbmsPAceYSMHaK4bsIApA5/ak6lut/QRD1VX3zNnf3ZDHz4SFxeJu+/68L6cKMKpC1FgF/F7IciD57qFwcRGLamoRjKoajU+dQsrr6hQb4U6cWVwC4cyk8bCIIgCOIrUiEaeGq5QBxaLIRgW1hqM8w8gvzXtq+xxBIrHcpVR97qYahljbyfsFhYx1SdK/HKrG6KVmxHCW/sFY6DLwohpfz/jgtUtYk3HriugSPGx0EnDAIbpY3AuRxZNMJyQ6ed0Gu396XLBNPxgS9smrz9GzE/dCPPdb27ILhd2FoHelBoEuvMhFKghxNMMR+KfmVuYiLFEFEsEVNEtUzUbR5mqdbVOhdiR85sqrDtMaZRTXq2Pt7MRmjCqo2eUYK+W2zK5ergqQn88llnrYGjPDZgpvO/p4a4fCOz6gFMvuRdzVZ0CbOw7JT3o9GnxxA1rZOo8HaUVA0s8VXkCWpQ7g3yl5b+ZWSzbFGP0eYlcg46kFbj'
_TARGET_BITS_PAYLOAD = 'eNrtmb9OwzAQxh1l6JhHyHOwkJmBR0B0L2VMBwaXiY2BF+ARYCEdIpRKDDwDRKFCHVhoU5YmKI2vbsIApA5/ak6lut/QRD1VX3zNnf3ZAgL4iFNeWu+/G8L6cKwKWBNFgJ864oci+6HqF/cu5ImmoeTKoajUeTMrrkGuQb4UGTiVwBPcyc8ECIIgCOIrLMZmeGoGQxyawxgTr1hqDcw8gvzXXk6wxOzU6spVhzEZYKiZM6NvC4elN1SdK7El0qGFVmy3Np89Fo6DLwrBovz/jnNUtVbY7kVRjiPG2/7I8/0EpY3AhRyZ28FyQ1cjLxyPH6TLhCwOgC9smrz9G7HAi9wwisJD3z9a2NoYBlBoEutMi1Kgh2tMsQCKfpVtYiJZF1HMZk1ENZPVbR6altbVOmfsWc5sqnASCqFRTXq2Pt7MRmgirY1eUoK+W2zK5Wpvdwr8bEdnrUGsPDYQWfy/pwanfCPN6gGMseRdNVd0CQ2v7JQHnc6nx2A1rZOo8HaUVA0s8VXkCWpQ7g3y7Yn+ZeS0bFF77uYlcg4R8BpT'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block003_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
