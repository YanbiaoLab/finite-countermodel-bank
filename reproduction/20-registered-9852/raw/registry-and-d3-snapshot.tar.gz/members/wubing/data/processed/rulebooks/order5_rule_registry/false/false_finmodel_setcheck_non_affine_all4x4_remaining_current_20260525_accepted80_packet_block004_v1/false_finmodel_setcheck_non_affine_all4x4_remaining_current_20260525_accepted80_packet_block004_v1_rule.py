from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[1,2,0,3],[3,0,2,1],[2,1,3,0],[0,3,1,2]],"priority":764,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block004.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block004","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWU1O7DAMtqMgBVYBvQNYT2/BMYzEgmMZViw5Akd9tvPTpjOwAtpB+aSkbRJ1Jo6d73OKoOAMIUIFMwTsDwLYH74BT3Bvlyst+VYriXBwXPuffbfbv0GrN/iFQLCpQSr3HyJBdifpYycmPoOQmD/pDkOQqXqNew4BZkjmTrEWCFnAhxOUMjFx2YgxChR+Ffads26bdlP6FjwbKY7baoY2AmuQTExMnA82VAJJziBeqaYJNXi0NdKgbFC74hhsoZaFkSYmJo4gI1UcArqMxLTmTFeQXlGTjMQt/tehHU5SmZnATFwI/gG8JhD3Ya6e/VQi4xXgceQqG/Zn8wLOjSKnMSe+AA++6aqq4o2KKlk+F/2Evg2z+Mgho49nBBYP2dCOORv5sUQwkkDZJGitKUo5xYjKTOlkIpuWwMdYtUxs/yTYUrwUFuyTtmSzrEqqKhitCbs0Xg/PvSpW2B/1SNuPlXAg+54UrMS/aQg/Ac/rebTZ1PlILWeQcrKepD8kAmtjmNWY19Yi0xo+PKxMKYsxZXPdF8Q+o8iNLrp5Tt1GzFjFAGFxA2qTHITaEWSkrvgtFgq9GXr8o0RjzfpNQhmXH09fcv3p424IsS8PEcCSwZItRhD3rroy7p85bleFehocDhPWvxyE783Xqks2peYuaepOcVdaLuij2c8zW1yEh2/sWMuiU7oecTLQkWGmgXvjP/l9NdE='
_TARGET_BITS_PAYLOAD = 'eNrtWU1O7DAMPipHYMnq4WOxQHo+BguEfAAEWUEkotjYzk+bzjxWD9pB+aSkbRJ1Jo6d73PKosAgOUkFomTuDyDcH74Bd/Jglw8t4VUrSHJwvPufvbLbp6zVtfxCsNjUJJb7fyJKcCfpYycmvgIQmD/pDkMSqHqNew4JB4nmTqkWyQHEh5OUMjFx2UgpgRR+BfSds26bdlP6FtwaKY7bapA2gmuQTExMnA82VgKJziBeqabJNXi0NdGgbFi70hhsuZaFkSYmJo4gI1UcCruM5LjmTFeQXlGTjIQt/tehnU9SmZnATFwIHkVuooD7MFbPviuRcSNyP3KVDXvevABDo8hpzIn/gL++6aqqwo2KKlk+Fv3Evg0j+Mgho09nBBYO2dCOORv5sUQ2kmDYJGitKUE5xUjKTPFkIpuWjMdYtUBo/yTbUvwpLNgnbclmWZVYVTBbE3dpvB4eelWssD/qkbYfK/FA9j0pWIl/0xB+Ah7W82izqfOBWs4ghmg9UX8IQNbGMKshrq1FpjV8eF6ZEhZjwua6Lwh9RgkbXXTznLoNmLGKAfLiBtQmOQi1I8hIXfFXLhT6NvT4R4nGmvWbhDIu3p++5P3Lx92QU18eIpElgyVbjAzuXXVl3D9D2q4K9TQ4HyasfzmIr5qvVZdsSs1d0tSd4qW0XNBHs59ntrQID9/YuZZFp3Q94mSgI/NMA/fGJ1L0O2U='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block004_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
