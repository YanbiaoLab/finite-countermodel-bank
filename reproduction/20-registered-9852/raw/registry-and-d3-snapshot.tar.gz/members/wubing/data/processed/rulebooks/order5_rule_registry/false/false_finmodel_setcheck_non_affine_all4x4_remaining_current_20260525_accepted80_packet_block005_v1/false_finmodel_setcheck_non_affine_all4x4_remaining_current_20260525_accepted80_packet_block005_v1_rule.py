from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin8_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin8_explicit","model_table":[[0,3,4,6,1,2,7,5],[4,2,0,1,6,3,5,7],[5,6,7,3,2,1,4,0],[1,7,6,4,0,5,3,2],[2,4,3,7,5,0,6,1],[7,1,5,2,3,6,0,4],[3,0,2,5,7,4,1,6],[6,5,1,0,4,7,2,3]],"priority":765,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block005.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block005","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtl80NwjAMhe0qh3IzEgNETJIjY5lNGBXyAyVyaCsQIsD7DmmrtJblOvYz00c5EJ3idUckW/oGNtPtfqAfZSS5rEyhYw+Ti3HReseltfyassfpAwAA+BM0l8FcAn215U3VTKXezVjqiyE7q9ZpvnfY396Wpo2ZRwC6RfJ5jbkfjC4yuSzUEnKCMMZwhWvUpFUe2EhLv2yUEVcAWjOblsojjZktmFMU1pgE4GkZOTVKp1W6HR803sWEGwLCCgB4G8yjW99zWclhtgUAGNWtRURLY4KtJ92wavaFHgcvcAZIvgzD'
_TARGET_BITS_PAYLOAD = 'eNrtl80NwjAMhUdlEzwWx0yCMgASvtFDVBvyAyVyaCMQosD7DmmrtJblOvaz6EfZqW7i9aDKR/0GTtPtftQfZVC+rKJuxR4mF+NC9U5Ia/k1ZU/SBwAA8CdQLoO5BPpqy5uqmUp9mLG0LsbsLFmn5d5hf3ubmzZmHgFYLZzPa8x9Z3SRyWXWlpBjhDGGy12jxq3yIEZa+mWjgrgC0JrZqFQebsxszpwi12MSgKdl5NQoA1Xptn3QeBcTbnQIKwDgbYgMob/nCmnAbAsAMKqbiojmxgRbT7qua/aFHgcvcAYDwmRz'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block005_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
