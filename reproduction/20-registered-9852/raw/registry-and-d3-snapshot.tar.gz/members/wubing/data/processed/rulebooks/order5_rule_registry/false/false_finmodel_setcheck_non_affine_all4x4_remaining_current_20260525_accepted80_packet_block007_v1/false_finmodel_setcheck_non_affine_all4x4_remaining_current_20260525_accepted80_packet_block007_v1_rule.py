from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[4,2,2,2,4],[3,4,3,3,4],[0,0,4,0,4],[1,1,1,4,4],[0,1,2,3,4]],"priority":767,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block007.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block007","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWc1u00AQHq8WaVtxWIccQFzWi0FGXCrEA2yMkRLEoeENkDjAW5jIrdyqlYL5OZeoT8ATcODEI/A0zKw3dtw4BGgqIvCnqm6a3ezO7Hwz32w8MIMUWvA+ZAaUe3Gec9h67Msh80pb1A4HdpnPOgvfJj3fJxcYEMAFgEfeUHD3KCzy3C5TGNB2tKRfkQjfgEmhADHlDDwGhuNU+lmFXTZSONlD59JcHCrLN6b6OJrJeNmE9DCFd56Qpof7aeD86OFxdDK1fxv3P/FzI++D0MxTKe52vnDptbN87tL4Z+eeKlBcGejQoUOHDh06XBbRiKeoI0hlWB2hqZyv0BHqKNTaDrcVnMHlVM+/hT4vSL71UL5ZYej7KOBQz/BV6rCoBW87lGYc0NVp59wOHZrtYjHUOu6NkmSoj3Lh+1oniQgyhZRjzRQlgdoj21qBbazAq/sr+7AspYclG3d9ieeYx9MiqRYahb4f6DjJclxM8mliqiRoquYMk4DhdX+z2Du59oXzlLqvVC72N64JKuqFKN8mSZ5LHxeb4ATX6zGXow3tSwBmG7SDmbkdqbMDHz7uaNEVZWLP3NYkPO1VC2EPSmaRKzMZp43WTpYv0HHYQvo4l3pNVb9fjXG40Me5t8xIVwtRwZGlK2Us3PEslh2Bh2NP03qmdiFruJJdLFeyrbKVITAfalts6+T69Jcrm3QfbuhBx0UTFwJoMU7Wtb6bxpmycVAVnDyfxzN1+CUHoDRFtlwRtBGhLlfOiXMTlbubsbFWVraaM0tkm9b3GH9Gti63bQhmYIWHvSUKMXNI33PxbIUHE4u8EsrdYplKbVS3QzjGcU7rOdkErNEuV4v7s1zvBv1xEmT6OMr2xScZB9lEid5VkC1QX14C+xyDsrdhFLxnJzfRUWzINu6F81O6WNtPbnyQ36PZ3uPgIL5+IHcnwbA8J3dmm+FJ+jGhXGjTY/Hsno4XSItEt6WhouqlMe2lSkvwr0kwkxxzkQSFuZ8WD6WsVpCbceTz5PaTfhzNTmPxpD+mCHlxGItrAxmumLC2l1HbQu3hDWsRceD9OHmRxQIjJOjzQct9rGlsnV+0Q6x2AP8lsjHkg2mKHG/d/iV0uGpM8WBmqP8GeKxINpvrkWxEb6wGmEZKDScpGtJVYbNW2Im/YZo5jmZ5LHZaAmt/6V++TQK5o0gciYlSDevW4ZUQe7dQYIfeUtguBbp6gCXUDqdS+y33fttBr2cnevdO2PD7qsSUPBrvfKLh/efRV6SlujnZ5og8B5ULVIsoWNd+ZSTHJBZxuFUfQbY9ufe/k5EjTSq/RQ/YDrz5baXc4qLZgh89edTE'
_TARGET_BITS_PAYLOAD = 'eNrtWcFu00AQ/Ro+gRMHvoAvqELPUEwkqtYCK/gv4IDUPyA9IBIJ4+wHIMQFYYFZ7wXRQxrvAbUrsVoPM+uNHTcOAZqKCPxU1U2zm92ZnTfzZlMAm4TQgr3UMBDuxY6vYetxLMemKG0R5xrMZT5rN70fzfKcXMBAgVYABXlDwKfD1PN9u4zHgNvRkn4lKn0MLAQPVF8bKAwwjVPpZxXOzEjg5AKdS3NxqCzf6PODpCfjZRPChyHcK5RkM9xPAzuHbw+S/b79m7n/qZ8b+QEUN4UIcbfzhUuv7fpzl8Y/O/dQgNCCQYcOHTp06NDhskhGOkQdQSrD6ghO5XyFjhCHKed2uK3gBi6nev4tTLVH8m2G8s0KwzxHAYd6Rq9Sh14teNshuNGArg4753bo0GwXvTHn8WwURWN+6Ks85zyKVBYIpJxppigJ1B7Z1gpsYwVF3V/Zh2UpPSzZtOtLCsc8HXpRtdAozfOMx1Hg42JS9yNWJUFWNWeYBJiu+5vF3sm1L1qH1H2FcrG/cU2QVy9E+TaKfF/muNgAJ7hez7gczWhfCjDboB2Gze0InR34yHFHi64oE3vgtibh5axaCHtQMotcGcg4bLR2snyBjsMWMse51GuK+v1qjMOFPs69xUa8WogKjixdKWPljmex7Cg8HHua1jO1C03DleZiuZJtla0MgflQ22JbJ9env1zZpPtwRg86Lpq4EECLcbKu9d00doWNg6rg+P48nqnDLzkApSmy5YqgjQh1uXJOnJso3N2MjbWystWcWSJbv77H+DOydbltQ2ATKzzsLVGKmUPmhYtnKzyMWuSVEu4Wi1Vqo7odwjGOc5zPyaZgjXa5Wnzo+fwsmw6jLOAHSXCsbss4CwZCza6CbJm4+QzMrRiEvQ2j4N3dP0FHmbHZuBd2HtDF2nF0eldeS3rvXmeP4m+P5NkgG5fn5M5sMzwJ70SUC2169F585PECaZHotjRUVL00+rNQcAn5dwls4GMukiAw99PiqZTVCnIzjnwefXk1jZPeg1i9mg4pQo4exur7RKYrJqztZcS2UHt8ai0iDuwNo6MgVhgh2VRPWu5jWWPr+qIdarUD9C+RzSAfWFPkFOv2L6HDVaOPB9ND/TfBY0Wy2VyPZCN6YzXANFJqOEnREK4Km7XCTv0N09hB0vNjdd4SWMdL/8ptEvAdReJEDYRoWLcOT5V69xUFdloshe1SoIv3WELtcCq11/3itx30pLfPzz6nDb+vSkzRm+H5bRo+fZ7cQFqKk8E2R+QOCF+hWkTBuvYrIzkksYjDrfrIgu3Jvf+djBxxUvktesB24M1vK+UWF80W/AAPB5xj'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block007_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
