from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[3,1,3,3,3],[2,4,2,4,4],[0,0,0,0,0],[4,4,2,2,4],[0,0,0,0,0]],"priority":769,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block009.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block009","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2UsKgzAQBuAYXGSZeAIdLPQYQbKIO49kwUXctTlBj1qjfSx8tIUKKfyfi4CC44xM0CRhm3TNw5AOB2w71uXFmHSphtSXRN/cS04Djz1njdcOAAAAAAAAK3/IXemdO5tMKSJjnJOVSPaIduifgbwlqkznhFKVKPYIdh0yewTK6jEtVdAQ7P/XTVpvQkaWeifqUoW0QimLTu4RrfGvQGHV5F7KTnL0T8RWO1iiNvFq/NbV/NtVSwCIQ8WSdHHuzVvGWSo1a8OszX+ysaOnQSxM/838lJ4/EzYSAD5sNjsONj+5999amc1p1mzxugG+Ki1o'
_TARGET_BITS_PAYLOAD = 'eNrt2UsKgzAQBuCj9gRpd2Yh1CO5M4sgOUahMnoCk2UWElOjfSx8tIUKKfyfi4CC44xM0KT3m1ThwtANB2y7FNVRym6phpRURN/cy0yDiz1nhdcOAAAAAAAAK3/IacU4P8lWayIpOTel7feIdk2egZggKmXKrdalrfcIdhgyewRqizEtXdMQ7P/XTTImQ0aCEm6LSoe0Qinr1OwRLWevQGHV5F7K1Dj0T8RWO9igNvHK2dbV5ttVSwCIQ+n7bnHubTLvfGeUz8Ks7X6ysaOmwS5M//n8lJo/EzYSAD5sNjEOojnz999arWho1mzxugGOR0PO'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block009_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
