from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,3,3,4,4],[2,1,3,3,4],[0,3,2,4,4],[0,1,2,3,4],[2,1,2,3,4]],"priority":770,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block010.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block010","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrdWEty5CAMBYqFlhyB3ITKao7lRebeY4P4WZIb0tCLYZFKrMBDQk+/vyqACiqun/gzKJ/+MOBPoT+UUTZ+CxD/0SpheVGiD0EA2rrACRCYWemjpwKXJOeJN8GRFIQo7fbaeFovxePjIQYuqb6k+dCv4/rqrq/RQOfp169ZlUZ6nh63ZRsWqcJt6jtetpHitgJGTHM41MjclUyqKGvoq8TrMG+TVPH5TeU3qmfdMZtHCeqTq7nUB5bovzsWPtiHVuL5hxaaET6DJgaELcvU2PLEpjUr3ID2aggIdNozRmsj54AFS4ywG8mWgHSK2H5bLPtpgHwJ95vocLgGyJassymyuBecX7u+xWtsCJ1BeZHzbfWwKrNJJdEOt0lk466xwW18W8H1CXbEbcIs2YrVbteglSXjNnORQM5sViphXxjgV5mNeU3OAHNPKlfcVBmgytipSCBnNoZsXca9YThq7iBmNqIM2xOQ1P6IAUIZ6TpllNiasAYQMTQlm5uzmhvH8IKXB4Hz9k42dfNTmCJCbug8tZrLdUr5yPRwOlcwuRFTNZwexKUdAllqtbYgAiRbuReL4RBDFwcK98wm9YRMy0ljdK5gumYyX8FEQ/uqpNyaMgVRvdczRm57FV6oKCmWkRzZjvKaja3QWCb/eyh7gEQYuVFnrMYYoOpRNlZTtHrpxzKSsxodEbAY6FX1vUB1sxlaDwy6DYdRHah/vIcyctBtOIzqQL1TnpmtAr22GjXAMxH6x/u/ySaOo8bc5pkI/eO9jNpr+yn/3H0aWApn5dazqr5qgoJk46t/uDJLfrQViEg2tvo/gbQtrr6i3xfLyOi3i2dQAbAeIL5wamxX96RiGZnmsaGvg/WbBBHLyCOMHDzHDnkSvmMiI2a2IDQXewYkv27jXpONBvYt9biY2aQuxoxjWMGj/kghcsD/JgIMjv71EBqbDGCabH5IjeDfnH5Njf71GrJNjG7emWsf86x5Y6iNA5LTmmb0eub3cGn0r4we8vXKNFAygR8yW2Q1DJVZ0QAXBzAAwGwCwGkkDVGcYS+gWKdgFavVZOHwD6van4w='
_TARGET_BITS_PAYLOAD = 'eNrdWEty5CAMvfdk4WPNKsVNhiOw1IICxgbxsyQ3pKEXYZFKrMBDQk+/P0FBUCGur/hTBZ3+cKBPoT6CCzZ+UxD/0QZhaVHiD0EA3hrFCRCYWemjpgKTJOeJN8GRFIQo7fbaeFovxePjIQ4uqb+k+dB/x/XVXF+jgc7Tr1+zKo30PD1uyzYs0oDbwne8bCPFbQWMmOYwqJG7K5lUCdbRV4nXYd4mqaLzm8pvVM+6YzaPosInV3OpDyzRf3csfLAPrcTzDy00I3wGTQwIW5arseWJTWuWugHt1RAQ6LRnjNZOzgELlhhhN5ItAfkUsfW2WPbVAOkS7jfR4TANkC1ZZ1NkMS84v3Z9i9fYEDpV0CLn2+phVWaTSqIdbpPIxl1jg9votoLrE+yI26hZshWr3a5BK0vGbeYigZzZrFTCvjDAjzIb85qcAeaeVK64qTJAlbFTkUDObAzZuox7wzDU3ErMbEQZticgqf0RA4Qy0nTKBLE1YQ0gYnhKNjNnNTOOoQUvVwLn7Z1s4eanMEWE3NBpajWT65TykenhfK5gciMWajg9iEsbBLLUam1BBEi2ci8WwyCGLw6k7plN6gmZlpPG6FzBdM1kvoKLhtZVSbk1ZQqieq9njNz2BrxQUVIsIzmyHeU1G1uhsVz+d1X2AIkwcqPOWI0xQNWjbKymaPXyj2UkZzU6ImAx0Kvqe0HoZjO0Hhh0Gw6jOlD/eA9l5KDbcBjVgXqnPDNbBXptNWqAZyL0j/e7ySaOo8bc5pkI/eO9jNpr+yn93H06WApn5dazqr5qgoJk46t/uDJLfrQViEg2tvo/gbwtrr6i3xfLyOi3i2dQCrAeIL5wamxX96RiGZnmsaqvg/2bBBHLyEONHDzHDnkSvmMiI2Y2JTQXewYkP27jXpONBvYt9biY2aQuxo1jWMGj/kohcsD/JgIMjv79EBqbDGCabHpIDaXfnH5Njf79GrJNjG7emWsf86x5Y6iNA5LTmm70eu7ncGn0H5wf8vXKNAgygR8yW2Q1DJVZ0QAXBzAAwGwCwGkkDVGcYS+gWKdgFevDZOHwH6CX0Zs='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block010_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
