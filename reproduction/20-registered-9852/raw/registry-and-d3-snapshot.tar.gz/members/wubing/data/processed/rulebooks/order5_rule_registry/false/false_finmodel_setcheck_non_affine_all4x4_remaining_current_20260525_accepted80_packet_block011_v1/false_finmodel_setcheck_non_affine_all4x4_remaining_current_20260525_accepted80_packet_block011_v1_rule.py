from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[4,2,3,3,0],[3,2,1,3,0],[4,2,1,3,3],[4,2,1,3,0],[4,3,1,3,0]],"priority":771,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block011.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block011","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWUtugzAQHSwvnJ3hBC5ypRzDQixglyM5UhZk10QcoEetf/whDQpGTeW3IFFCPMx45s3z5AwdanMVwGAe4mBeMGyHY4mpmLVFmAS0aq2TvV2tOPpCWhN6RYjUm86/izFhv9WXCP4GGg+KDR7qm8dCrTGJCsCHijB5YWVpMkFgFUO0d4SOu25VJCFgA8herQW8DY4lv+X5hSu2+MoVl6QpVntIPVn7vPJ7VRlDiDCVMYa2PTEM0/2nMRRZtxgIT67VkLSGmHML+yoH3fZaQ9i6Jb31OLpc8wHbSKKkzPOt02ZRA+yUNh5Rw10XWxKNBSu7qvhpVSQrYkNpaW2IqvLJBK/hhIpUzkpdPtnNuQCk2ZotzVweOO3fFXSPOhuObmV0J7LxlAm6x57QuhgZGt46kg+toedsTDeTRLrYTA3Q0a2GOqHXesyBZBSApjrmbJAFGUkHzsDg8DGMmvzVj2Eoxp3N/IiwSdT6u+mihmASgGbRGRss0HRAQEBAwO74fjyBROWmog0vHT0FOgAUTDXFGFLXF8/qwim8p2D2DDRSOA8PkJ1kkbNLBexVbPyWJ3HcHqX8Hotqfi/SNEsmAxI3nIEt62p5QGKF/4BmMHUyuZ+FuEnWJ4Yc6szWGpLOLepNSWc9Q7Q9nuH/kJFrRv8Clflrg5LF0b/QzE94Pw8CHhTbItXj5zpCgMu7Ml34Z9RQ53CIrUofmbmhI4DVpWAHJA2ZQDd2nBtiIyL056351VT9A0pcUzE='
_TARGET_BITS_PAYLOAD = 'eNrtWUtugzAQPWoOgJLuwiJSfKTsYIGQjxGpFvUJwLt4YZmpf/whDQpGbeW3IFFCPMx45s3z5AodInPFQGEe+GFeBGyHeyIYnrXFKQK5aq2bvV2tOPoCWRN6RajVm86/izFhv9WXGn4HGg/SDR7qQCqs1phEBeBLRZi/sTIymYCFiqHcO0L3XbeqRhCwAVCv1gL+DO4JOWXZhSi2+MgUlxSFUHvIPFn7PJNjHBtDklOVMYa2PTEM1f2nMVRbtyhgT65FULaGqHNL+CoH3fZaQ8K6hbz1OLZc8wHbSKIyybKt02ZRA+yUNh4RwVEXW1mPBSs9q/hpVYRibkNpaW2IOPbJBO/hJtMCzUpdMtnNuQAU+ZotzV0eOO3fFXSPOhuObmV0J7LFlAm6x57QOh4ZGt46kg+toddsTDeT17rYTA2w0a2GOqHXesyBZBSApjrmbPAFGckGzsDg8DGMGvrRj2Eoxp3N/IjTSdT6u+miJmESgGbRGRs00HRAQEBAwO44PJ9AymRT0SaWjp5YPgBSqppiBYXri1d1IQz+pmD2DDlSOE8PkJ1kQbNLBexVbOSUlVXVHqX8HosickyLIi8nAxI3nIEt62p5QGKF/4BmBHMyuZ+FoknWF4Yc6szWGkLOLeZNSec9Q6w9non/kJFrRv9YJtl7g5LF0T/WzM9JPw8CnhTbItWL1zpCgMu7pFj4Z9RQ53CIrUpfmrmhI4DVpWAHJA2ZQDd2nBtiS47156351VT9DQIkHgU='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block011_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
