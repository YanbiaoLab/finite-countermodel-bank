from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,1],[1,1,0],[2,2,0]],"priority":772,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block012.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block012","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNprZGGAA5lYBmKACQPDDB4GkkA8A8s/diYsEhmeHkYzOzgwJQ7UO03//9SVgRqggYWBSZCRYQiBC1Dah41oLSpQGsOjCgpgiqWBwQFNxhOqlAXdLAUYQ4CApXCFDPQOXov/cOaHfr1v+QyjYAiAhv/1cSD6gREDw38gkGc4cEKbZrZ9+N8OS98PQLYxIyfYoQ0O/P9fz8jDoPDBXqQB5DV+1gf/7QUYDtAqs6lMdHFh8VQRFPwIymwuLh0dAoKKLQJMtLBNtVtlUkeHQqeKkpLaRJcjLR0cgoJKSi0CTrSw7MH/+eFCgoIqO31cjoACUlzQ8JOXC9AyDlrYNqd+XsUj5Sa9XSe6f7iL/zb/pPTE9US3QDwHI00y2////jUuF57WVwqCvBYfd+Q/kPmIW3G0IBoFwx/AmrPAvFXhJL5IfTREhgJw6NJQArUsBQQZGjqUuBRZGBRaBEaDZRSMglEwCkbBKBjp4MEfZnyy8rFv7o8G0ggHBy6y4pMV3iVgyzgaSoMOTGEQ8GDCNqrkIMTIwuCgwMkB6s8xubgMm5G8UUAqsNgFprAN0GFk6QecsR3zMJQ1jAbiKBgFgw8AACW5ezY='
_TARGET_BITS_PAYLOAD = 'eNrtmD1Lw1AUhq8oiEPt4KaU+At07NAhU/0XgiKoIBaHaoSiCQi6urnWTo5CsYqX0uKiIAqC4EdMU3ApaO8V/Igak2NT2iJt8QOM2PY8yzlwTvJyX+4JN3fRhArXMfgOhwAT9/AjomC2PVt1CmuJ7aNxyagtiEpykvTuwm8gm2AxGxqIwVKMv3z7EbUUaxaq68VgypCqqiRKrWb1u/Rywr8QrTTCX9u7Tyqpd+akaxWQBkAmyroThSMAUiALov/UNTUvmS/vb8FRe/u4YRsbkRDFvgfdm76RnaXdvQokzUF0a9jUEKVmQmWs2xk2SiWJs0yEW26oXYbVaUnS51RNuwjRQEQyGNO0CE+6ISaQkY08Y+pQnAYcI3Ps2LNFC2KGG2pjyuiK72rhJOgPd+7kOg48Wt+uP8yjhu3KsBGyuUQHe5Vl5iwtuh4ghdT3kMEPEdL8lI+zhdlaSeaGz9GRRiA1e6Y5J0vOQJa0x4wJeoSjLQiCIAjS6gjtb59Vs7GefjSpxREHXj+r3gb5no0u/TumgG9b9W6VUnnbhJT+ZDj/cxalTXOTh/yU/WAx1Lugqxlp4Skmjda0yWgigvw/3gEmx/Xx'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block012_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
