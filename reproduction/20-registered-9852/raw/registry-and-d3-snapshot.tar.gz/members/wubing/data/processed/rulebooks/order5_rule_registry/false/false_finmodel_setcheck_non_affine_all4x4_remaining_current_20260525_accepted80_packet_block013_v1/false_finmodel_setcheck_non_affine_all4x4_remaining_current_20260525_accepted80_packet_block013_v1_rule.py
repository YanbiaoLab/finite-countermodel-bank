from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,3,1,3],[3,3,3,3],[2,3,3,3],[3,0,3,3]],"priority":773,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block013.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block013","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmUFo01AYx79kmbwVhaQtrCf7Eiq27GCdohexWYxbA260Kt7E4mEg6NWLYJ813WJxdFQvwqC0HVRwMBBPglgEYTJFh3gSROZlAw9u1FEG6/NF8KJF6SE6x/sdkg/e//Hnfd+XL4EIAEDgT8zNAOcv8iW7uUpbI78ukByBEqAOW2anjhSiL+VuXGKANFHosHB/pjCYv82ClCH9Zj/BgCWs83JxOBwOh8PhcDgcDofD4ex8KKNIm5QemG+78eID9zrZuiB6YPaRPn29P9Cz0Roeb7g2RwOZjYkPKP7Mk6PNla8/XnmVGku869+M1VsjX/PL4ecBX/kg8sCMlEy/ZUrTpl8RSklNM0ziIEXRkeDF0d48bOCBENzZE4dM6YV5CkIQj1/0QY8niTw3ltgKrq/Uy8be83fPLNT6jbXicrh36LjkgVnj/ZXiqLHr8pq1QOavDlwbN/TPvfcU7HiSyKQyGkyjijPoU4NpU7UNlFdYKA3JXrjFqq7RYddIK0TtFKrIhjqRw0jkg2j7Mq0VcFUG5aQs4qpjoBsyqLKBdkLRGnS1Tj+Ft+jbxVq5Xcw216PtJUpxe7Ljq6LJhgCTPzlWyDZpwqFqd25RhHAfIREZECYRENkcFrAmAmb3n7W4T2ICJgcRdHAcgG6n9qXalOY7FFwa3pd3f7CkrEr8hGrnMrs71M18lLYqrvzsaaZEFRy6uZ3LNgvYQZJuChIQrLFRJQGyZZF00sppllxX7iZZVG0325x/gW5pt1jXJzXW1FZEUVTQTdtBQOD7B4PfAon1+Y8n4v/iG047u4o='
_TARGET_BITS_PAYLOAD = 'eNrtmUFo01AYx18Ho8yyeRC2i0METyJTdDgQpCJ4EmEwwcLaUhh40bIyqdka66vgxauCsINUvInasgnpZsxS8aLorIfRiiV59dRB2wSU7uGy5PNF8KJF6SE6x/sdkg/e//Hnfd+XL4E4AIDhT0xMAecvsjvTO4j8S78u4DSGONAOWyZnXicrx8xuXMpANdvpsHBhKrmausKCvGL9Zj8mQCyi8nJxOBwOh8PhcDgcDofD4ex8ECOBAgi9H/e58eh59zrrv297YLYPnTryobnV51+eD7o2r5rZvrn9tHTSk6NNxG6cGTqaXygeXO8th/xLu1LDtRPNduwd9cAMx+WWJFvTcstw4gVNU2QsUMNQqePF0Q6fC5K1Olz+XIJs/Lj8FOpQKt1rw5YniXy4UOxp9A+FYsqnB5cej4XXlYHEcG1z5YXlgVnwwO3EovL1zoA0hsdvrd2cV9Q9mxcNIniSyIKx2MjRqLDa1hs5WRcVmjJYaK2YXriVI67RG9dIS1bEPI2aij6XJtTmg2j7Mq0lScQE45lpk4ig0Osm6KZCd0LRgmgwhPbWetCh0XDMl8gE+iu+EYSIb7bjqyLAhgCTn36ZzARQUUB6d24VSskGxlUTKMFVsNkcdohmA2H3n7Vkw2ICJgcbVBAEgG6n9t3wjNZ+2xhZ/phyf7DkpWjpuS6ms1861E0+m5OirvzRE6akUVK/tp3LNglEoJYqOxZgorFRZQEVTRt30po5llxX7ibZ1kU325x/gSppV1nXFzTW1FLVMHRQZVGggOH7B0NLAov1+Y8n4v/iG/42tZ0='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block013_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
