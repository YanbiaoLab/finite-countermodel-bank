from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[1,3,4,0,0],[1,4,3,0,0],[2,4,4,0,0],[2,3,3,0,0],[2,4,4,0,0]],"priority":774,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block014.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block014","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2b0KgzAQB/BTHOKW+AQa0vcQyWA69ZE6ZIhjpQ/QR21iRRCtbQdbLf/fonCB4y4fSIzIK01MbyiJFsfd1EVnQsxEDo1qnSPYlKh/JtMQQ3d+pt9GbS1llRmtneOikBUrkjWyXdWQqJaNY0JIqTUr7P4beWq7iowSomhUKKtrpeXxGtmO2ZDIT6C2j1ZaXq2RrDRySBSO1m6FaJ8MGxcAAAAAAABWdEiXouGGIUaTAHYnT3g53BSPxCwnH0qIEafwCtvx4rg977i0/orTr76JaGaR/ln1AN/fbHOfd+nT0SOf/Pa9A51vKKU='
_TARGET_BITS_PAYLOAD = 'eNrt2b0KgzAQB/BH7QMUO5rBoY/UqXYI4nsYok9gspkh6DWxIojWtkNaLf/fonCB4y4fSOzIydOW3pATrY47iBOvlVqIFLGIGCPYlG542nnIoDs/M2yj6CZlVqecM6ZVKTNT2hDZjmJMdJMxM0pJybkpk/038hL1FaVCqTIWvqy+lYluQ2S71mMiN4E8ebQy0VmIZHkqx0T+aO1XCHfJsHEBAAAAAAAgoKJZi/obhhZNAtidyup8vCmeaE1FLmTJkCb/Ctvx4rg977i04YrTrb6ZbmGR/ln1AN/fbEufd83T0ROf/Pa9A68CSJE='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block014_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
