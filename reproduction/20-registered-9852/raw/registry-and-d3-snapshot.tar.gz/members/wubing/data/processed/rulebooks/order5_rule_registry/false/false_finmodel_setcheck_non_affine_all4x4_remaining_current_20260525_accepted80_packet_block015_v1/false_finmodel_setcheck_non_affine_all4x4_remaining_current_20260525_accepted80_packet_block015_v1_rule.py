from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,0,3,0],[1,1,1,1],[2,3,2,2],[3,2,0,3]],"priority":775,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block015.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block015","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9Wb1q3EAQnl0ptgRHLIkrDhywoojg0pVJlSxGBF3n5AlUuoghZYqQrIuQc2E4jjyACz+AK9eq0qVIF5LmHsHlFYbL7kqyD2t0WHh3t9CxmkOfZna++dM3YBRKUCtVV1btXF9tDqoN7MkNZXLzGTrW3OmSOJsdgqNZh4C973rWBsANKpgCFC8wAY9hYwQEkbgD8NBnnUN8mqISQvwUAkTgRWyKq0KBuKgkojRzY0SwV/+2FOX1g9qKClWUdeh9QZzXR9havjJJzDKg2Ns1N/Nacfnfe7Zo3kpeyuUO2FuLpWMRbfnVIth8uWUR7WZJ7IFxoZm9g7smMLd3cD+3Xs3B1smVJflujwC7//LkdOJZQjv2x2kYWvLK83EyjqwZ8uJseMioLbJdcBoSzx7Z7gKY8ZjyejWAvTFPtlub7nyBT2bRVkqiy1/7WWYWbXx3Uvt/J4VZsAK4CloLCVqd2rU5tBSG6nebNPXSZMMc2UijEcCmcbKtlLpxYhztAKgnKj9nUEDByUBUgUyWfGbiGAuYLCcFUACDPQHiihJ9YEo1jyogWXAHzLghiaPYpoCMx+W4UECqcYNRzQVjBPihuiWeziaTaRaFodnMNlPdjAKa5UliNqMeCluKZniWU2DRuGGdKcwDyTXCqJ9BHp94ssmSHIjNkI3BiezwYsJBtbUChhvzzF3IEzlVSIk8OuNkqxp1qV+UG7LfSpPNb3vtanKCzgg0LdeXQArRY5QqV/RMHRsfhlXQEqWkdE3jmU1mNJlv7qYmxjAjBcTkcCRTahJ8UqKHbNUszQtCDiShgVlD5p4CksoEIa1MyI2hrR/9LPVONObO+vGJ3u5j8Gzt+OTaKTU24vylv056fPVcZ+KZDtdJL3+/dXXOGDoHt1AK9/iomWwU+Bku+uMB15y9mzISVVp7ZUmcjtq7lECkkBWLWCM9A5LOSfjMRGZz0ylg5mKiYNYdmHlMXJxungqWaayqBq4nbEq98MAk7wbvsjr16MkLnZ8WqnF/A6KHB2UdeRHRoq0yGgR6JIj6e8QTRLTdQsOCAD/qRzYArHws225atP/Wz3fqbzWIC1DcbR43IOkiFOOT+2Tr/ErUZ0CinOQh05GnGspItT48IGawR4/YaNVWOwQJW+3Q4iDZZ7dHZptC1/wgb/tIztqv0EffvMJB6tW2EnHitu72i9n/AfLckvc='
_TARGET_BITS_PAYLOAD = 'eNq9Wb1q3EAQPnDh0o9wTUK6FOlSqU7lB3DhBwjHgQtfSOFNSJEy4BQu9QSJuxNBmE2q4OpKExRFhhhcHJJsDiQ70u5kdyXZx2l1WHhnt9CxmkOfZna++dNboAwcUCtQV1rtikxtTqoNzOSGUbn5AB1rWHZJypsOwdGoQ0C/dD3rFmBDKxgDuL91AhLB7SVwjaRYQK591i5E+4FWwnkWQKoR5DEd61VhwAutJGbMLyKNYFb/thQl9YPaigpVlHXYqiDy6iNsrUyZJKI+MN3bNTe9WnH53xVbNG8lL87gHOytzUFpEW3wziLYcHBlEW1jwO2BEaGZvYPb4jC0d3Avr34OwdbJOQ5/Y48AZ0+8cH+SW0I7zKZBkljyyt1pOI2tGXJnb35MmS2y7RCW8Nwe2e4DGHpM+bEcwL7jk+3Opufv4SMu2lJJtP3i1Pdx0ab3J3X6dOLigrlAVNDalKDVqW3hoQUwV78XvKmXJrd4ZOONRgA36GRbKnWjEB3tBFguKr9y4YJL+EJUgVSWfDhxjKZUlpMCKIXFTIAUokRfYKmWMwUkC+6UohuSl4ptCgg9LkeuAlKNG1zWXEAjwGvVLZFgNJmM/ThJcDPbSHUzCmjkhSFuRj0WthTN8MhjQONpwzoszBPJNU5Z5oMXHeSyyZIciHDIRuFAdngRJ6DaWgFD0DzzDLxQThUCLo8OnWxVoy71iz0k+y012eSu164mJ9oZgaFVZBJIIeaUMeWKOdaxkXlSBS1RSkrXRM9sMqPJfHM/NUHDjBUQlcMRX6nJ9ZMSM2SrZml5mhDgIUtxDenlCkgqkyasMiFBQ1s/+hmYnWgMy/XjE7Pdx+Lv2vHJVukYbMTJr2yd9PDVH5OJZzxfJ91+/q0wOWPoHNyCI9zjk2GyMSB7etGzHIjh7N2UkVqljVeWvOyovR0JxF1ZsYh1aWZA0jkJH2FktiIYg85cVBTMpgMziXihp1uugmUQqaqBmAmbUi99YJJ3069+nXrM5IXOTwvVuL8BMcMDp468GtFmW2VtEOiRIOrvEf80oosWmi4IkKN+ZAPQlY9O203d9t/6+U79rUbjAkzvNo8bkHQRipLJKtk6vxL1GZAoJ3nIdOTaQBmp1ucHxAz66BEbq9rqkmvCVju0lJrsc9Yjs42ha37gtX3Eo+1X6KOvV+Fo6tW2ElFYtO72i9n/AVmV3jA='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block015_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
