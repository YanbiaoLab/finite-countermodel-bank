from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,0,1,3],[3,3,2,3],[0,3,3,3],[0,1,2,3]],"priority":776,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block016.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block016","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWU9vHDUUf2Ms5I04eFZ7oJw8s0u1oBySUrhwcUeT1aaiUlNB1QgupC0qSD0henajKZrAIq02qoTgQqqCRMMBVlXFBwh/EkDKhQsfAYnvwHvPs5NdskRUISRI85RMZuxnP/v5/fs5AVjrYAplsm4hLj4ebsPJJ63LVwMSxGHmMq0+CB2IrjFWKCuVghBnhQgiB0IBPjSgggQKUqDBAijVcoC6rIPS2B4IsNRHP39HYm+N0tEcI9o9/dM7wzMr+0e4QdYa5DkLmOy5v3bmg3avz++jmdTBm6wBxIJ2RcobLYkeX/NxP1juLSXyQC0VvxVVVFFFFVVU0SFJ1bCOSP9hmeKkEMTuHOgAk7cWlQLLkkr6WkiBVBA4mKwOJwsuX/vY6dVMQM04meQ/OJGrlFtRRfvhohW1VHZNkEMYGMJGRprbFKL6lkJU6EOUtiIImN1CTu6lAsRQoYnJ/2ggAqdIGoNRELszxnKJIvDFnqel0xYCCV3AcbUWsCinyEtREPLUCZLRNMxOKA0xHI0l+TiRLhZHoSCldnJuRxDPMQSyinFN5iGUrncpfAQtrTneYgig+UE7qZ3yOFFYZkUpNZDInlPQEGXQcBw0WFQINIrXxyDSo7SsgF4aEtwZdjqClrpctAQPOfUE5LSkAGUKDlZAMUIC8xjekO/WHhcGvFvtVWm7Y4LqStEIngEY/E9qjQSZQKJeD5IR0wSKMLJXotco40uf2ZxEQay1WDBCtqQ16c0mwEZvNvszG4qK6bKCVmYlyxg3IAkZCkn8Fo36b83fGI/50YKLhOOzBqkMtE84pAo2G3yWVwQjswEeQedZDhzLOjCyE8npq3C2MrONsRaZzYtCvU93tmkyiswmC0sMijQnq9j2L5G15U0Pm8Bk4cGn+dfrlem3WHyy7P6lAR333m4O/3jp5eajX2+9tzX85KvelTc+f+Hd698PrqonjkDYZ6357dPN5qMf47dW6TZsrpl0sp/V/JY+iq09XBvuPN/bvbZ+V+/cGM4l0Z3OKx99PLMaHYXS3SCtL6ZpP62H4aAbx0ma5SoMExUpc9tBDfOjKXJWdnhpuyhiM1friyhosJ2mea7D+ZXzKjoSp//t2usXbnVmN3/5Pb/+4vKpb749f/WLnfzZH/ST/3vX7oYLjSW1kcczUWMpjbJE3dH4Ks/xfay2RUxVHpAEMLo2Fd7l6WOEKRTsWbGYACFleLg5LAWxs6kNnUTZqlEV+DvB1Ie8HWP9t0C1XM5HHTWorPX24Ipcy6fv+OiLfDEym4KTefZw6ririmPKBPbT2c3tnTzY38P2eXn9bvjhl2dXHvSuXHrqzeULlzvM/t2rz8y/1pl97v25x5PWXuzGa/mUjdoydPpQFmU6XmvFMbPHMTcmKng8aW/f68UzzSkBMb9xr56cWmh02vcv5uiB5+bkwtml2gaxNy61ty6qDfP06km2yBZuYqq9GP6/nw79F6vMf4zYo6zy52MrI7sMwo6iHjh2+hNc5O+m'
_TARGET_BITS_PAYLOAD = 'eNrtWU9vHDUU/w5IfAQuXCIBCX/yAVBVLRxIkaBquICQqqxWYiEjOkp9LuJUCSrahgsoVUFNpaJmtRlNfeECpckhglXZnfGJcljt+ICyFjLjx3vPs5NdskRUISRI85RMZuxnP/v5/fs5DqQUMIVCO5CQFB+n5+Dkk9blqwIL+WHmUt0G5NrlLaVkbqQ1BjKcFVJIBeQG8KEBFZSjIAMaJIAxXQGoywEYje0uB0l99PN3lO+t0QqaY0QzD5/7pPZgdf8IUQ+79SBgAZM9Z5cffNBpNvh9NJM5eJNDgCSnXZHyRkuix6t83GfWmuuxPVBLxW9FFVVUUUUVVXRIMkOsI6J/WKYIm+fELgRoh8lb55UCy5LK+lrIgDXgBExWh5MFl6995PRqxlEzTmb5D04kKuVWVNF+uCjzYWRbygWQOUXYSFl1kUJUQ1KIynyI0jJ3jtklBORexiGGylRC/kcDETilVimMgtgdMpaLDYEv9jxthZbgLLQAxw27wKKEIS9FQcgzIEhG0zA7oTTEcDSW5ONEulgchYKI2sm5BUE8wRBIGsY1oYdQetCi8OG6WnO8xRBA84MWVgvjcWIumRWlDMEie0BBIy+DhuCgwaIyoFG8PgaRHqWFBfTSEOPOsFMQtNTloi14yKknIKckBRhVcLACihEWmEfxhny39rjQ8W61V6VsjQkaGEMjeAZg8D+pNRKknEW9HiQjoQkMYWSvRK9Rxpc+swmLglhrSc4IWZLWrDcbh43ebPZnNhSV0GUFrUxaljFuQBZCFBL7LSrz35q/Uh7zowUXCcdnDVIZaJ9wSBVsNvgsrwhGZgM8gs6zHDiWdWBkJ5bTV+FsZWYbYy0ymxeFep/ubNNkFJnNFpboijRnq9j2L5GU5U0Pm8Bk4cGn+dfrlem3WHyy7P6lAR333i7Xnvju296ppy99NF9757XmjS/e/OHjqy/Wr5s/jkDYW92tuYe93qnnk89W6DZsuxe3w2fN1rw+iq2dXq7N/ticubZ0Xs9eqW3H6YX2N++9u7uSHoXSRT0abERRIxpkWb2VJHEUBibLYpMadVHAEPOjKnJWeHhpMyhiITBLGyioPhdFQaCzrdW7Jj0Sp3/q2pd3LrV3Fp55Mrj6/dqjV16+e/2N2eDnF/Tv/3vXbmWb/XWzGCS7aX89SsPYXND4au/xfayWRUw1HpA4GF2b5t7l6WOEKQzsWXE+AULK8HC5VgpiZzOLOk7DFWUq8HeCqQFBJ8H6b5NquYCPOu1TWevtQRS5lk9f8NEX+WJkNgUn8+zh1HFXzY8pE8i3dxbmZgO3v4ft8+bS+ez91++vnmneuPXb52t3braZ/aWvf9n6qr3z04fbjyets9FKloMpG5Vl6PShLA11stxNEmZPEm6MjXs8aZ+eaya7vSkBMbhybhA/2uy3O2dvB+iB97bt5v314SKx92915m+bRfXrykm2yC5uYqq9KP6/n878F6vMf4zY07Dy52MrI1sMwo6iHjh2+hPvjYGB'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block016_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
