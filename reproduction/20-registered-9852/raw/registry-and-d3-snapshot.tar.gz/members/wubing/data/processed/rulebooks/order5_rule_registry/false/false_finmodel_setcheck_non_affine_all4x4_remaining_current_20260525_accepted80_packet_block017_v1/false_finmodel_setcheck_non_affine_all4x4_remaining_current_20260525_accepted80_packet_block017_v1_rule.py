from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,3,2,3],[3,2,2,3],[2,2,2,3],[3,3,2,3]],"priority":777,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block017.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block017","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWUtuAyEMNYgF3dGegFY5COqqx6JSFl3myLXNdwZPNFHVTeS3IITPDH7+jPQwcAZXcCFBArAGFP+PYH3MyLaPSLpx4CEAdSFTgz/UBo+Ny91FtDpjC+gqAxbKNtwXaD5S6yw2JtYt1ZfZAVw2r8dnOnq4pbdFDym2vfhQPh/YsdqpvxQKhUKhUCgUCoVCoVAonh7vk/DEolUG1qCkIZa2jCuKFg9CU7jaGgfQp3kL1EnWnaqiRd1EHd+PwZIYaZS5LKFJkqe+eWlb55vyBSbWTuwqlu+6WMV1kuFiP58HaQj/WJZKZTuqIjdRMdtFx8uTRYbP1cAaHBtjUzv0KukNO1yunUFF3Gt1dULSdC+4fDf+BnDbrcqV0p8zMfJZnL5SJLEmhE3TQCe6pwAqxLY/2GVKHBR6Owcia0LYDIWz0z0CKMCsf5JfTDn+Ir4KQ1LY3E+Eya7w5MnmKtMCXgC+dtG3CNf47OqYjxMB+czJZu/OXjbPviX7t+qfPKewEGsYkRYjssejF4fqettiM8FmcgrMxP5yB7FGwcium+4nuncn995N83rtsf2yCSUKc82jyT2Lozg02V2ql4HN5Eg4mjm+qxGsHRUO8uT4tVyNFNwmnDuMNSmzdu9Z8FoZPbghzIELnwDk1iG3nVk0flTTXpgeQyjGC1WLaOXrsyl716Gx3mzY3k1uvmwiXzaUgO+BLdToB5OtnESoWtJnbB2Ki/8nfuP+bb4X3xMFWRpq5eqUD38BfsxgLw=='
_TARGET_BITS_PAYLOAD = 'eNrtWUtuAyEMPXKWXUQqx+qq4iBRywladmWBwLXNdwZPNFHVTeS3IITPDH7+jPTIcAZXiN6CBUgZFP8Pn4IzyHZwSHqOEMADdcFQgz/U+oBNNN1FtNpgC+iqDAnKNtznad5RGxM22dUt1ZcmAtw2r8dnRnp4ore5ANa1vfhQPh+ksTqqvxQKhUKhUCgUCoVCoVAonh6fk/DEopUB1qCkIZa2ciyKFg9CU7jamgjQp3kL1EnWnaqiRV1LndCPwZIYaZSmLKFJkqdeeWlbF5ryBdnVjusqVui6WMV1kuFcP18AaQj/JJZKZTuqIjdRMdtFxzOTRZnP1cAaHBuTbDv0KukNO6KpnUGF22t1dULSdG+4fDf+BXDZrTKV0pczMfJenL5SJLEmhE3TQCe6pwAqxLY/2GVKIhR6Owcia0LYDIWz0z0CyMOsf5Jfcjn+Ir4KQ1LY3E+EyS7/5MkWK9MCfgDedtG3CNf47OqYjxMB+czJlu7O3jbPvtj0t+pvA6ewEGsYkQkjssdjEIfq+tRi08JmcgpMy/6KB7FGwcium+4nuncn995N83rtsf2yCSUKcy2gyT2LnTg02V2qV4bN5Eg4mjm+qxGsHRUOzOT4tVyNFNwmXDyMNSmzdu9Z8F0ZPbghNJ4LnwDkNiK3nVk0flTTXpgegy/GC1WLaOXrsyl716GxPm/Y3k1uvmwiX8mXgO+BLdToB5OtnESoWtJnbB1yi/8nft3+baEX3xMFWRpq5eqUD38BzaURBw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block017_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
