from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin6_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin6_explicit","model_table":[[1,5,4,2,0,3],[2,5,4,1,3,0],[2,5,4,1,3,0],[1,5,4,2,0,3],[1,4,5,2,3,0],[1,4,5,2,3,0]],"priority":779,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block019.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block019","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmUFuxCAMRQ1i4SVH8FE4GpXm4LXjDDgJlWbRtJr2v8VEAQIYwwc8ib4PKdujNsp0H1q3tiPe1EwDX3pFHZJuqbqQNPeCOiBhqN+RB2WWZU4qQtLVyaweFupvZ1rNux31MnHrxZrM7ao0Zru8rEu2AsTXBcXh2ipmiomjGM1WeY78odg5FwDwg7QmulZXZ4zcbAdkKmyLVuhlsfinRxEXwDx++KB4aYjiUyr74XQ3pTKI6zx21N80rXtXmIINPbzkaEKOPZeTGRT3oXoeQAAAAAAAAAC4787m4WMLEurzGQy0O8oiyUJt0vfAmSXaHSht73uZTjSy/RPyTL/2PEKtMr69KfbVa2iojP4hkA1CfOFDJ+dqAja7jLPd7nPDMIG/CSfT/4Wwb3+YqH4O8U/LJC/fxkbAdMgMu4CtsU+/Ohzd'
_TARGET_BITS_PAYLOAD = 'eNrtmUFuxCAMRQ8+UjkaR/ERWHqBwLXjDDgJlWbRtJr2v8VEAQIYwwc8Xb4PqtujZGlyH1q3tkPe1EwDX3pFHdJvqboKZfeCOqBjqN+RhzSmZU6vJJTUyaweJklvZ1ppux3lMnHLxZrG+ao0Zju9rEu2AsjXhcTh2ipmiYmjmMxWeY78odg5FwDwg+RMulZXZ4yWbQdkqWyLluRlsfinRxEXwDZ++KB4fYjiUyrT4XQ3pTKI6zx2lN80LXlXWIINKby0aEKLPaeTGRL3oXIeQAAAAAAAAAC4787m4WMLEurzGQy0O8oiyUJtlPbAmSXaHahv73uZJDKy/RPxTL/2PEKtNL69KfaVSmiojv4hkA1CfOFDJ+dqAma7jLPd7lvGMIG/CXfT/4Wwb3+YqH4O8e/LJC+fx0bAcsgMu4CtsU+NN1RZ'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block019_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
