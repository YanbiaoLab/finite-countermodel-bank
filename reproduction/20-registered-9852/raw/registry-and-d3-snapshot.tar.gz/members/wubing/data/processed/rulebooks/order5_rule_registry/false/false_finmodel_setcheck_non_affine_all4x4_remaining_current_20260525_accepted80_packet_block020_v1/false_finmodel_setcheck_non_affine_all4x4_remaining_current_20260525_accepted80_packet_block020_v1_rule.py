from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin6_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin6_explicit","model_table":[[0,3,3,0,5,0],[5,1,4,1,1,1],[5,4,2,2,2,2],[3,3,3,3,3,3],[5,4,4,4,4,4],[5,5,5,5,5,5]],"priority":780,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block020.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block020","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WTFv00AUPiemcYVKfOkAiEpJXEM6MVUVQ9WcIqM2LOEnMHRg6V6kqjZgpGRqSCMxNuJHMLuoAxOCjbFUQuqYiiVDFHN3Dm0V31WJeveeVKfR8/n5s9/37nsvH7IEoSiPmA0r7BgZ/EuXHwk/oiVU4l9Ilp0WHyGhncZFsQPFcZy1RI5BXP3oeWbaEdEllQ1HsGRfEgP1JbeFgr8ni2LPkuxaPRdLPI9bbkYIZcWQrCBWSeLJSKFkk8/zyTOC2JQsHUMx/RSUZIX7k0x6khvuHc9NOh6gJ/T4H6WF2BUCfu4Exlf0z772xpgVCQKwwTja0aAJEG0czIRARmnE7VCaNkptyIP5IMho+l5Zg0FdzmiM1r8KVuXc0IptNA5FqWnahPHFYP/qCRZde5CstPYpQpJwVC/Z2l4BY8fxvGbTrlmGRrKxQJ0tx6l5YdPCuGaVNZKN22Ld8wZNG5cdGszURzaa+3ve7lnrwCriDWfPG5RD3WSLqxf4dxxvhgdWNbT1kM3PIDAbxQZcsChhNZBJJZGunQ1mC+Vky/V9WhVHeZidrTLyz5a/MrIB7GxFBGhSqavFvi821mn5mIch25uzFhX+6xcnmyHrR/pYJ9OfNdYBC0ku4IiAZCRkiqCuy/fqggEBLuh4BbpXWzDQXlJkraZVdzEu65eRLwo8UAtERpK603Idx6UbTsjaWqp9NMrIlboJmJHSRl2H9cy2R19UB6Zn60IyO6BZSFkN9CjtjFViOW/afOSkmWw1BFj9CQSiS7Mgc4TKyMpNL3WYVymf5XNG/pg/xX+eq+3ZbtKrvbuKezbWhUpfqmuoTFg2IKFdqNSvNlX35aifso5O6QwqknejAe/ofJVNgVxGmnaAgtM8Qgo3hpwUGQvkD5XWNPkknAu+w51tlaWGykjxFkqY4Nv6/BYhjJkcUhEzKMg8LFCw8+Wh4p1N4llYbRt8Cr+tLpo0+3mgtV9qe7bx70fp0b+o1T/P3K7UDBpJpUzNLSJRqy966N9mJpugZ9tNwyD9nKDYzCQjE2alOVA3U1O7+qotLG5TmzmWJSkrSdJGxYCE3J9mC/1xR82AZDpwtx2I3ks+3lVTnuOisEZPc1NSfTN/WaImTPATX+d1SSREZ5aRC2spHHOPUtd9v5DOseB8hmj/AP6LW34='
_TARGET_BITS_PAYLOAD = 'eNq9WTFv00AUdpQhC2rGSkihIxuIiaGinvkRKB2R0tBOiUQAu6pE9y4MHfgJZCGtsKJLlQFVnZgacJ1EKgKG5hwiVKc48XF3Dm0V36sS9e6eVKfR8/n5s9/37nsvL0eIELNPmKVb7GhG/EuBHxE/klPS4V/QiJ1mrBKhLRldsYMYhjEKRI6M0XjhOGHSYdIlrQNPsGQTiEGywG0R687ymdhzCl0r72LA863kjoVQjiNgBQo6gGcMQhnFn4vTZ1hGCCydQAntBJR4hfsATXviG86vXEw7fpKv9PgfZUDYFSx+7hTG9/TPv/bGmHUR0WCZSbTVTFlDtEmwUAcySiNua2DaSLU0D2ZrQUbT98qqDOrJWGG07FWwBueGUmypSShKzdBHjC8R+1dNMPPag2SlNUsRopijasm27vQw9jzHKZf9ehApJBsLVNzzvLpTKQcY14O2QrJxO6s5Tqbs47ZHg4XqyEZzf8vZzpU2gi4+8LacTLuimmxGYwHfM4z9ykbQqPhqyGaPiTZLGZG+YGbMak0GSiJVO5ueLZSTbZi1aVVM9fXsbK2UnTt5wsimYWfrEo0GSl0l9uis2qTl41wP2d7mSlT4NxeW9yusH8lilUz/XG1qLCRDiyPSJCN1pggpuHyv7kU6wFlFp0f36kAPtA8UWakc1FyM2+pl5MceD1TSIiNRzSu5nufSDafC2lqqfRTKyONaqDEjwUZdheXDdYe+qKKenq2gk9kWzULKak2P0h8HHZbzoc9HTorJVicaqz/SgejSAp05QmVk66aXmu7LlM/wnJE/5ufG3U9ye7ab9Gr+j+SejXWh4Et1I5kJywYktAsF/XJTdRNG/YV1dFJnUCbcjVq8o7NlNgWwjAx9i1hLfUIkbgxDEBkLZKel1jR4Es4F39rOrsxSQ2WkeAtFTPDtPXtDCMZMDsmIafUgDwtk7Tz9IXlnAzyDo/WIT+F35UUDs58HOrwvt2eb/H6UHP2LWv3F8e1KTaYaV8rE3MIUtfqih/54brIJerbtJAyUHQqKzVwyMmZWkgO1MDG1qx35wuI2s4UTWZKwDpA2MgYk6NcsW+jDv3IGJLOBu+1A9Hf88bqR8Kx0hTV6lpsC9c35ZYmaMsFPfMV3HZEQnVtGDg4TOC6+J677apDMMWtxjmj/AE3mFbg='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block020_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
