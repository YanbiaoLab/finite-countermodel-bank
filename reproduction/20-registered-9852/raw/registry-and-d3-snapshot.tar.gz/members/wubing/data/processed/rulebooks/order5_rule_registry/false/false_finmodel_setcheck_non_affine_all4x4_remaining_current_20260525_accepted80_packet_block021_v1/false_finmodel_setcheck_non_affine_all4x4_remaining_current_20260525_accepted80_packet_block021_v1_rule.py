from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[3,3,3,3],[3,3,0,3],[3,3,3,3]],"priority":781,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block021.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block021","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZBgFowAN7Li7btvUs6siewKdWBgYMianmkZKblyjpq087WpK6hG4sgZfNiAZcDapR0hpNNBGwSgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBgFo2AUjIJhBg78pwjUk2Zbxu1c85szd67Ztnr1trsp6c9erZo7U1v5mkxyTNjtq6G38zYZF5dePXdmqmB2n6He6revVoGV78pKf3aqw/S4BDtpttmvP/1PvvJrfZzhfL3f9U+uSm+sSvr/v1tx/i/79TP8p/+1//SqN8J24///Ryf4/50ffmY5WLnbmnk3/v9POrGcNMse/P98/v+3/H//n78+bf//9v6fv5L+P/tvn/zf+P//z1+fzv//9n5N7cb6z//nb/w/8///n78+gZTv23dj/8//52/85yHNtjXz605p/rvoar/X5pfm8h/u+v2P5FttuB7Vv1g0P07u75TgP4unu3/sd5Jj/WhfctFfvx+s/PTiH+6K/U0/5JlIsqwBEtdYQv8PUYmENK9d2AZOB1icQVSy4SPNtro4UDrgwpT4QFSyYSQxsz0HpQMsMkQlG0nSvBZhD0oHylicQVSyYSHNNgADaImd'
_TARGET_BITS_PAYLOAD = 'eNr7938UjAI04K4U6JllFLqseN3e3///T8+ZdWrZM7/gm1fuZGrNnmUNV1a/6SeQXG80t/jt3dFAGwWjYBSMglEwCkbBKBgFo2AUjIJRMApGwSgYBaNgFIyCUTAKhhmwZ6AINJBm23SVSSfU0tyCPUNCPJVmz5AUDU1Ku3JH8/GcxStVtFapTPQ909OlZWic9W5K4bmLIUKioWDlrlNnSJqWn7J4/oM02w4EmDA+aONqWHgu4SJLg7TWE7/WuQwMJfcSWA8EpG/IYDrAK1q0/JAfA4NV/gamhBXGEWDlO4MT1RkY5ppHkGaZPAOPAQPnBEYGCRGTAwwqDmyscxkkGQ7MYTjDwMDDJZXAIKTQ3OTXwMOQ4MeQxsDAxsoLUu7oqO7AxmCgzvCZNNuCExpNrzHq7TrgdJj1WgT7jgsFsg+qDn+VbRCPTVj4kCl7DXNMxg6+gr0Pf/Ed6NbbcKEArNwkhn3HvYJa9gd/SbKsHhLXWEKfmahEQprX9D3B6QCLM4hKNh9Js61xISgdfMWU4Ccq2fwjMbNJgNIBFhmiks0z0ry2/AAoHdzB4gyiks1v0mwDAEkY54o='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block021_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
