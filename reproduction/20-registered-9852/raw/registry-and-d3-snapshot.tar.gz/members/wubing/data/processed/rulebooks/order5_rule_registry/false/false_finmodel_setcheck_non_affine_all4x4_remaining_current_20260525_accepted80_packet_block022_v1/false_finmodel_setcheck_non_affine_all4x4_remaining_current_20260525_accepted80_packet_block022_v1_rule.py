from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,2,3],[3,3,3,3],[2,2,2,2],[3,3,3,3]],"priority":782,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block022.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block022","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmTEOwjAMRR1AggkYOyDKEToyAQMH4QAMjAwIcrQcg7FHYOyACIXAgp3SQMOA/utgyT+qk9Z2pERRHTrlQ2SIugR+wNCZFhO0uhujmLJ7WNt+EVbObHiU1Blj5Uk8oyeUywMW93lmRBPS+GcAAAAAAAAAAAAAf43yCcMIwVZeZRoh2s6raKuaDqa9b8wjLO3kn/+l+ZPei61WrZ03F8zYtFItaXCFhV9i57HfYw+VakmKYqtTbJUJp28fcoBiq8HCmR5XsiNzJWvmmtAyIFrizEiQ+Jq0VAp5QCq9uSSJsrMJdzV05q69lLXd8GKL0KKEiXlzRHB1uKsVFC1zRvgYQtr0uWscFG3msuogbTQ8+YRhRUCjMd51bGr16O0HO5vYfHnaSMPykEZzBbVLTx4='
_TARGET_BITS_PAYLOAD = 'eNrtmTEOwjAMRYMYGDlCR46RowXEwMjAATgIAzAx9ggUMXQEJioBMYXAgp3SQMOA/utgyT+qk9Z2pMRSHU7lQ6SJCgI/YOfMhQnG3o22TBk+rDq/CFNnxjxK5oxW8iSe0XNK5AHz+zxTojUZ/DMAAAAAAAAAAACAv8b6hF2EYFOvsooQbehVjLJNBzPeNyYRltb1z7/V/ElvS1WrSi2aC6ZVVqmWNLjCjl9i57Hfo/qVakmGYqtTbJUJZ24fco9iq8HcmSNX0h5z5RPmWtMsIFruzFaQ+JqMVApJQCq9uSSJsrMJdzXU5q6BlLVFeLFFaFHCxLw5IrhO3HUJipY6I3wMIW0O3LUJirZ0WdWXNhqefMKwTkCj0d51jGv16NEHO5vYfHnaSMOSkEZzBZcmIhg='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block022_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
