from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,1,3,3],[3,3,3,3],[3,3,1,3],[3,3,3,3]],"priority":783,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block023.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block023","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZBgFowANCHiCSA7ODjDvx39mINnwHwj4UZQd+I8M7EfDbRSMglEwCkbBKBgFo2AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGE7A4WaatOeZMxyYMpNuLFt1ymzSjJkrVyWltXVwJPcYCmCqUiDJth/g6YZ6TAnU+QgwkKfYbxBz+HE5AwUwU2rZA4g5jLicgQzqKfbaH1zzNg8wbeOn1LKGTWdB6cAzafYqrdseSWnLVnXNlFRS6jE8prLRN3RqroqhcXDo0TM8goLHJJKxJBtBwbS0kFBPzaUpIAFjYy/NpSGhhsbOLi2Gx2ZMCfICosQeQzbFFgGewwY8n/+PgiEIAGU5aJE='
_TARGET_BITS_PAYLOAD = 'eNr7938UjAI08H4biPz+rRzMY2f4AyTrGYDgA4oyewZkcGA03EbBKBgFo2AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBSMguEE9qvNfLLN2Pg7pkyuemSo6cnc9LSw0LkzK8u/zyk+9x5T1X2SbGMHTzc0YEqgzkeAwQOK/QYx5wMuZ6CAP5RaJg8x5x8uZyCDBoq9xoxr3kYe07YPlFpW72sESgfb5qaEXlXZPndmZGhp2rO7d4vPWd7227Qqa9Ltc2fWrLIy/vzuneXzOViSzbt3M2euXrXtWtRskMCZM1uvRa1ede7Mnt3V5yzTs9duBaJ5xed+3qt+/9nm/GcehlEwBAEA5zgIpQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block023_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
