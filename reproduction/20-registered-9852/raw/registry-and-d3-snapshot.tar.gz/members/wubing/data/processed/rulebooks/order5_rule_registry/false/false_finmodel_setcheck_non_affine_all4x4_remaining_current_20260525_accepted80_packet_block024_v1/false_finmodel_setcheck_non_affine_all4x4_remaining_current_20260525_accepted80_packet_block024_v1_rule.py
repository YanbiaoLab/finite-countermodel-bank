from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,2],[0,0,2],[0,2,2]],"priority":784,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block024.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block024","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWUtqAzEMlY0Xzs7tCdzSg5jSRY/lQhZZ5siV5O94NENb6CboBYaJ5RlZT5/Ai4Gf4AouJMCPNaD4fwTrYwbAK5JuHHgIQLeQ6QJwp+uzB0gu9xTR7oxXwFQZsFAew+cC2d/wmp3Fd5tYHym5jF+uWAfwnQ5fju9AP9HDJz3hnsnkeMMTmggp9iWFQqFQKBQKhUKhUCgUCsUj42USnli0ysAalLTE0pZxRdHiRWgKV9vjALqZH4FqZN2pKlp0m+jG92OwJEYa5Q2aoHVxJHHhzUfbl31VviYp7LWpWMk3XazhOslwsZ+PHO2X8ItlqVSOoypyExVzXHS8PEVkONQG1uA4GJvqkiDpjThcrkuDipdVq6sGQdO9vFXWOjLpf/c0L6EPv/o4wXtJ+p4iiTWhbJoGOtE9FVAhtn3BW6bEQaF3Op/AmlA2TeGc6B4FFKBZK7wpx9+Jr8KSVDbnjTDFFR682Yoh7Ysn2UvtgQ5BuEYfdvFxgkduNntkKKzd56V7siWbf0Xy3MJCrWFFWqzIXo9eXKr7bavNBBvjVJiJ8+XkWgOqkRTJLeamtWYnfaT3tM0h2LkAS7MJIwp7zWPIvYujuDTFXaaXgY1xNBxZjv+r8Vgj8MVubz2VvWPySK8wrnoLLg3njmoN9jXSOuaolTxSubT5siPw4BNGFHLrkNvOLAY/pmkfTL9DKMELI4qizVTwERmqBNhKwBgaoxnMhu3FuPllEwY7xhBKwffCFgj4ZbOVkwgjKnzWHsiYhcMZHZf8b8tn9eaPRhSUgWzOZzT6qJ7zOgglfAPjOHfV'
_TARGET_BITS_PAYLOAD = 'eNrtWUtqAzEMPXKWWRTqY3VRig8SWp+g9S5eGFuVLP/GoxnaQjdBLzBMLM/IevoEXjL8BE8QvQX8pAyK/4dPwRkAvCLpOUIAD3QLhi4AF7p+BgAbTU8R7TZ4BUxVhgT8GD7nyX7Dq4kJ351dfYRz6Z4jWwfwnRFfju9APy7ACz0RP8kUy4YvNBGs60sKhUKhUCgUCoVCoVAoFIpHxsckPBXRykDRoKSlIm3lyIpWWYSmcLU9EaCbyyNQjUV3qooW3Vq6Cf0YRRIjjfIKTdC6R5K48Oa17TOhKl+TFPbeVCwbmi7W8DTJcK6fjxztl/BLKlKpHEdV5CYq5rjoeGaKKJdQG4oGV4JJti4Jkt6II5q6NKj4WLW6ahA03futstZhSP+72HkJfYTVxwneOOl7iiTWhLJpGuhE91RATGz7greFkghM73Q+gTWhbJrCOdE9CshDs1aEzMffia/CklQ2540wxeUfvNnYYPfFY9O99kCHIFyjj7T4OMEjN1s6MjBrl3npYhNn86+wobSwUGtYkQkrstdjEJfq/tRq08LGOBWmLfmKcq0B1Yh15BZz01qzkz7Se9rm4NNcgNxswojCXgsYcu9iJy5NcfP0yrAxjoYjy/F/NQFrBJ6L22tPZe8YM9IrjKvegkvDxaNag32NtI45aqWAVC5tvuzwZfAJIwq5jchtZxaDH9O0D6bfwXPwwoiiaA0VvEOGKgGpEjCGxmiGvGF7MW5+2YTBjjF4Lvhe2AIBv2w2PokwovxL7QGDWTic0W7J/7Z8Vm/haEQBD+R8PqPRR/Vs1kEo4RtpOflS'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block024_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
