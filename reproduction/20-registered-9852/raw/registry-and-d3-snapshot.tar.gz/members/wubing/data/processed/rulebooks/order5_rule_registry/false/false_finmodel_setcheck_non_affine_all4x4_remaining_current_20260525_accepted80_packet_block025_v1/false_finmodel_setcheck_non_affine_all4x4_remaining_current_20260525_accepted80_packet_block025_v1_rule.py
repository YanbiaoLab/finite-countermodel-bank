from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[2,2,0],[1,0,1]],"priority":785,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block025.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block025","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZEAHBxgZBjWwY8EhEbBtkLuceCBgBqaYMCQa6jkhDNp6lQPZdo1JOFQ1eICUOHg4sDCMglEwCkbBKBip4MN/9gecdLPt33+m4RqQFp5/Pp8/w0Mn2/7///+5o380+Y4C3IAPTD7oVGdgsPlI67begcpHnep2SjYfj7izMMwDW6zMNBoHo2AUjIJRMApGwSigJ/jz/z+/Am7pBdzUtKzh/36VXR0duGRVmDioaZsB34+H7fWjUTwKRiRoEMIl47Gok6Ehd5vkaBiNAnqCByqKnXpKShAOzWezepgLDjDKYZPBtLphNHIGCTjg6SQU6+LCoIAx2jrPQ0mpCdR8UFBycml5wanYIkCxbRLsDxqYbbA5g5HdBkRUMDDwM8gx2DA8YKbcbwCZAD/d'
_TARGET_BITS_PAYLOAD = 'eNr79x8d2P/7P6jBwd84JNZ7DnKXEw/enwRTfzEk6hu+QRi09ep3ZNuv5+JQVb8dpGT/9v2//4+CUTAKRsEoGKmAn+GH/De62cbI8He4BuTxbcw8Bsaf6WQbAwMDT3nBaPIdBbjBRzApX3bj///DfLRu69m3yZbdOHj3MJ/1jt//E8EW3/k7GgejYBSMglEwCkbBKKAnYGZg+HAft3T8F2paVs/gcNu1vByX7O2/36lp2/mP7HIVDaNRPApGJKh/i0tme2zZ//pJns9Gw2gU0BPI375XdvHuXQiH5rNZxX/67f89xCaDaXX9aOQMEmC/be/bRbt3/7+PMdqauP3u3VpQ8+H+3b27q8W/3at+T7Ftz3/I1/85jM0Z/34cBhHt//9/+P/w/+H/8n8o9xsAs3ExWQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block025_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
