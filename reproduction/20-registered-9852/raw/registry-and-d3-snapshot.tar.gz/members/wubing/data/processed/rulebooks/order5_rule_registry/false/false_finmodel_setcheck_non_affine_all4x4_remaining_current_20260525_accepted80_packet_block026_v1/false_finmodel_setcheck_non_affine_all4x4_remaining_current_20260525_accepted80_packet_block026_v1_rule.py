from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,1,0,1],[2,2,1,2],[2,2,2,2],[2,2,3,2]],"priority":786,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block026.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block026","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZECAFl4GGgFmBpkCrBIaDAwbsNp6gPPB/Po0hlEwcICJoAoHBTiTcTS8RgFB0MAPpiQe1APLhD/8owFCLjhg/wBE/flvb9vw//9ydgf+Bjna2abhCY48UEG94ayZsfEwCsgH6hNZgNS23/Vpx8r+nz/DIGFgzEwz2+aoM3EoMBxgk77D++P5/P+SxgxpDEAraWNhw/8jwowsDD/+//8vCcT2j+uP/e+RZEgezT2jYBSMglEwCkbBKBgFo2AUjIIhAxRy8MkmNPO+4xsNpBEOHG7glWWQFhEZDaTBB1gYhDxwxBgQeCgwMjAwAjELy2hQjYJRMAoGBWBjYHgAojEnwRpoULMBbfGEFoho7SIaeM2C0WEBNwcDB2ZtycKFqZqDQtsA8kM7Kw=='
_TARGET_BITS_PAYLOAD = 'eNrt2bFLw0AUBvAHFTq7OQg3OLiKTsUhc6eubhbcXRwVLquTg1NA6H/RjgkupRBwbLcglnSoQgxqLNfe81JEwdQWlMOq3w+OF7jAR96Ru0A0vztO2ZIx35zNnOgy12amOk+i7noMP2ey8A4/ervU6BcsJJNpGQjX7AmlBA35KicQeSlRcCmJ9p79RF7bS+s2p4uXb9S17U4Y/qFGit6hMqW64nqVU9ra4cFVOLaWdtCbZBE7o/5GWl6rUxyyxybSTqCk3VutuExEsRnBuluho5gv8PYAAAAAAMCvEZ3Pm22cpKv3aNI/52/OneX+cIgmLR/Fd61PVsxoRZpZm6EUWgUAS2HELPJa/AkmLZxsJqX5uiF++C6y8Ght7e8/ZJwVT0v1WLw7+2baC1ouNgs='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block026_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
