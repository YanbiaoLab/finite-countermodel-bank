from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,0,3,1],[3,3,1,2],[2,3,3,0],[3,3,3,3]],"priority":787,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block027.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block027","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmb9OwlAUxk9pSetib5lJgVp348RA0trcAR7CsDj4AA4MJNwYjNfNf7OB13DQJj6Bb3DdGBkxIRxbDUgiKgnWRDy/pac5Sb+cc8/5hlsNAESYg2WIH/Nf5tVgue8QGdDW2KhkLUj0/MqZ73kLMgjFyam5IFGeBuzreRjs9k8Oo3porHtzm2BMzN8a7p7f/+TAsmCsHz03XdofgiAIgiAIgiAIgiC+Y2MulvO3UG83SAcGtejfM8FZOEbETqZiMZamoUjE0F6jRibl5BmIGFnSU8SAJRWGAFomYr3tC15wHP+C865/dSaZU/Ei3mWRlQvfL4p/imv/su55x/6llOeprOdxLmUilkVxAoPN9KneeppOTKxndmo7blUJE6oK7NAsqnysJ282tLNaNtwCCAVq02VD1N5dWPzh8a/efpr6MCVqY1/ekPUSmXIH1tg2VEezoDwMWLpduQnqAob3YMDrf7nUn5MNDFcXCxtRocF5ashGw3ecPd6VluNEVmVmneXUoaVV6bKV1UamGgY1gXYLxAMOAVyojdCOzRjNGsRPnRYkJuaO0VQ/YJ0vICSHdw=='
_TARGET_BITS_PAYLOAD = 'eNrtmb9Kw1AUxk8o2DFjN+8b+ARCdPA1Wpz9t3nFILfg0MEHcHARH6IOl5hAh07ibkxqcG5uXExo2hwTS6tg1UKNoJ7fkhMO5OOce8433GSIKOwRzoOxMvg0z2rzfYcogeNMVe/jGYmG6++7njcjA/igHSQzEr1JoD6fh9p1/fDUurTTv97cc0y15KeGu+HWPziwMqgMT5bOA9ofgiAIgiAIgiAIgiC+4ulNzN/eQo1vkM5SatG/R4NpWAGAZqliBtxPQpGLQfSHGpmXM1AoDFB5TwEclVdoI2aliDVud2U/DN1dKU13e5+r0PcsaSorHtmvF8XfxZa7c+l5R+4O53uFrOdJyXkuVkZxApzH4snGPS0mxhiWdmo3QZeJBLsMIzt5YANjmL9FeFzWssEdoi0gmywbQPbqwuIXj39348PUuylhTxd8k6yXKJV1jCtRyppZjD3dUcV2jTQYCtTXMMWX/3KFP+cbaC8uZretflvKwpDTthuGV9LkcRhasT+1zl7h0Dz2TbWwWjVhutMRELVQrIKOGGCnCpGRGJB00FhutjA3saACCfsG63wGLFzpsA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block027_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
