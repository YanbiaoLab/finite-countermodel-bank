from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,2],[2,1,2],[0,1,2]],"priority":788,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block028.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block028","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WUtuqzAUtS0PnDcyqAtwkCt1GVbEADrKkhwpTyKzFHUBXerzh4DBdh8IbA9SUSdc388593D5CwQEApj1Zj4FMX++OdUXJ3OBAdcXUNiLyPqJbYBzbOOjZeGNwXBgIQDDG1fQoOCGpAJAdWrf1B2giCv8qy6LgjYIma/Icef9wfuukyFXOByiY3bZ5AqT+ibU+8knaMPmh6+WwnPFnvcpSt8Vs489Qz/8Fsnau/m0h1ss4jo2Xc0jaIPwOqMAOddHVmvnnMaGhGVa3zldk1mrJEoISdZFcQx1mSLlEoTlBFur6LDGuJcLakuyogybBmxf+EW4c6JPAzZkEgezgK30u0S6NTQdmMfaH9uOTpnAZkUQFXnApitEThhIymFWAzzrLIljE87EUmUczypvoNeGNAZMHygKd5cf67AMeZS6s7U5O5vRiRoDUqMcGUGpfbaMJn/LItkENscQIqpiGBD29gmCS+BoaLlgIMehkt4iIyVwe434n8F9YMPWUB6l8M37pqouZVvXTfXoSFFUVV2T8x3cOANGPhCFQKaDKEVJbRSwE9pCxURlgcLpQS8Wd9nXo6GWF8W5utT3Thmjqnawok5JhhKloceu0L9+A1s/GXpw7VbX0UIZQwFBNOaVAs8PEQCER+6f5WhIR+1uQ3mnlxTKRLTVaEg3HGpDSS8khSCyMvI+djY2Oo9asYyaLhs2jxUElU3pqoq2MjLQ2cQqFG9DzSAjx4bTdW6qjU6ZzPojAgcIxC9SHACbMaQwYKMGXQ6ZR22iHOzjaQ0QlIzU0xNNy7YPgKEFmJ8P1Ml+o/otAuaKmuplyPQBYFtAGh30aQ09/HuvK5Jtne1k6kALD6nHabRwK/Norf4BrSGURZJEe9cz1On2PrNFd8oEsugezSdS6WwAPDLAsseRMm9UlQLdGuBx4bxGIXXiBWA3Xh0ZyOjglunhLF+Uzd7OBmMPh/yJl01tN7NYGRm4kZ3HCqNGRmbRbLpH8J1jPfmpz1AqwSfwjKDgjqer+CQ8xXOplZHIv7Wd4B88IFEycvYoig6LWhBspoUGBvHrm936iom+WhgMHSrsBj5q/PPRxvPFf6kB3IJd0dleFAX/344Fand2bTv6ZzcvcyLE0V6O5Eawxd7V7CqGGNiGE66RCMG3RNsGJI4emC2cgEeurh6YHYMnGZDYWoPL0jLMv0YOb+AZ0Wo7oRqeqJM4BwiAbZOMHClqcYzSJ2RdSGRPcv8BjISjjw=='
_TARGET_BITS_PAYLOAD = 'eNq9WUtuqzAUXepbQJVmFqSHFC8po8IARV5GpVrEC6jAoxcPLNvPHwIG2y0IbA9SUSdc388593D5K6GQUJr1bT4hNX/eENEXT3PBJNIXAtqLyPoT25CP2MZnhcMbg+HA4lKEN26y5sENQKAU6tS+qVLyiCvoven6ntScm6+Acefrgk5FAUKuIDFEx+ziyRUM9E2I95MPWYXND1/toOeKPe8Zdr4rZp95hv6gayRrX+bTHm6xqOvYdDWPoA3C64xQ5lyfWa09chobEpZpveV0DWStkighJFl3xTHEZYqUC1KcE2yVosOGsRNYUFuSFWXYNGB7Zy/CnRN9GrBxkziRBWyd3yXSraHpiDzW/tl29MwENiuCCMwDNl0hYMJAUg6zGuDcZEkcnnAGlyrjeFb5lidtSGPA9IG+d3fRsQ6DkEepO1uVs7MZnagxADTKuRGU2mfLaOCnLNJNYHMMcaoqBktob58guFSMhpZLBHIcKuktMhJIt9fA3wzuAxuzhvIohTd0qtv23lVNU7eXgvZ92zYNfZTyirA08oEqBGIdRAA7YqPAnND2KiYqC0RMD3qxuINTMxqqUN8/2ntTFsoYUbXDFHUCOpQoCT12hf71E9hOk6EL0m4VBemVMR4QRGNeifT8gAFAeOT+0Y2GdNRKG8qS3FMoE1i1oyHdcIgNJbnTFILIyshy7Gx4dJ5XcBk1XTZ4HishW5vSVRVtZWSgs8FVKN6GmkFGjg2nKNxUG50ymfVHBA4QqF+kLAA2Y0hhwEZNuBwyj9pEOczH0xogKBmppyealm0fkEMLMD8fqBP/RPVbBMyN1+3LkOkD0raANDrowxq6+PdeVyTbOtvT1IEWHkCP00jvVubRWv1TWEM8iySJ9q5zqNPtfWaL7nQJZFEZzSdX6aylODLA4MQiZV6rKpW6NYjjwnmLQuqJeomvqD0ykNHBLdbDWbQom72dTcQeDtGZLZvabmaxMjJwIzuPhUaNjMyi2XSP4HvEevJZn6FTgg+yGUGJHU9X8Ul4iudSKyO5f2s7wT94QKJk5OxRlB8WtSDYTAsNDOLXN7v1FRN9tTAYOlTYDXxU++cjteeL/1JDugW7orO9KEr83o4hr3Z2bTv6x1cvczDE0V6OwEawxd7V7CqGGNiGE66RCMG3RNsGJI4emC2WgEdurh6YHQMlGZDYWhPL0jLMv0YOb+AZWGk7oRqeqJM6BwiAbZOMHClqcYzOJ2RdSHRPcv8Dv+3NmA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block028_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
