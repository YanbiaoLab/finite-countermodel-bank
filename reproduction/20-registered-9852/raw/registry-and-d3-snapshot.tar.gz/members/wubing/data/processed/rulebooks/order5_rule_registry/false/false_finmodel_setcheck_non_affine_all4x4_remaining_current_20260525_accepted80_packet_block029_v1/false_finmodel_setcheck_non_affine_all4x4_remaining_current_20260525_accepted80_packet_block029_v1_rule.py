from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,2,1],[0,2,0],[0,0,1]],"priority":789,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block029.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block029","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmD1uwyAUgB+ISnjD7gUI8tCxR0CWK9lShw5dchtSZXC2xFPHnKGn6LHKn/8SV+pPqrTp+zaM4QF5hA8TOERzCZeFERoIA/DzYn6OsYYB7Up+1gQujz3bljQNCzGtuSJM9EsyRtR+RZLGl7gIbSUcJoYGCQiCIAiCnIAbku80Mznl4A9upRjj3CqMzqzEVGrFIU0ptQ9PcfgGB9gyCkTozoWcBlWUmCBF8tgckP9EAS5JpLGyzGySGJcg1Fmj8+rBoIMsSlftZXuQbA7CZZFPIuoFs2/ji2ON1HwUiIaWPqYt9Iouuhasz03e90Bip6Ne2VB9TsUnppv80arFkY2HHGcm+kd08O6+Ibw7Lwl+Q4dAJLwq+1fdz+RjCJgE+lgM1H4EQRDk0lkPZ+IUTROrydL5OKh4Lq7cqdo5EoL8efb5CqiAtlKKUq6hk3nyU5utkm5nlcPOKhmfD2biZvuq1Zu2DFdq21HtbjiqiBuXw6yPH0AxO+I/4S5P6qaZqWm366bKWpFuGqmeGl7wxfc/kCzv1aZJZoaRLcvH5zJLr+/K10aki/Vt4e+iyPkxqnZ5QKZXWpgpnoKHF58Hn2iBV9pfwBtIOT0l'
_TARGET_BITS_PAYLOAD = 'eNrtmD1uwyAUgI/VU/QMGTs52eIharhNlg4dKtlSLYsjdOxgES5Qm81IRfBqfoztxJX6kypt+r4NY3hAHuHDBg6hksNlQQQFowDcvJSbY6hRoPuSm7WBy2OhVoVu/EJMa16NEnFJxojMrUibupIUvi2Hw8SgwAFBEARBkBPwbKolVaTSEtzBzZhSUnYKQ+tOYnK2ldA0WncPT3H4egdYKQ1G0N6FrAbl2hAvRfzYHJD/RAk2STjpZFl1SUJsgmhrjdarB4P2sshttZPtQbIlCJtFLom0E8zYxhXHGknlKJD2LV3MrhAVXfQtVMxNGXswodNRr2qoPqfiG9JP/mjVwsjGQw4zE/GRHrw7NoR358XBbWgfyPhXeXzV/kwuhoBJoI/FQO1HEARBLp3NcCZOobrtNJlbHwcWzsWtPVV7R0KQP8+i2oIWkOSMaS0p9DJvfmqz5dzurGLYWYWS88FI2GxftXqSFP5K3XWU2RsOK8PGlTDr4wdozI7wT7is2ixNZ2qS1SbN60Q065Sz21SWcv/9DyS7B7ZO25lh1Lvi7qaom5fH4ioVzX7zVLq7KHJ+CMtsHpjplRZmiqfg/trlwSda4JX2F/AGBEc0EQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block029_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
