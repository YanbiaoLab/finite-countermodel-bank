from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,1,3,1],[2,1,2,3],[0,1,2,1],[0,1,2,3]],"priority":790,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block030.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block030","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrdWEty5CAMFRQLlhyB3ITKKsdikbn3GJD5GMmGbuhFWExNrIaHPk9I+gdOg4O4fuO/Dmz6Q2p7CK0HCSp+czr+UAGzLCsRnhFooYyjBAhMrPTR9gKTJMeJF4FPCuoobfaqeForxePjtaQOUhGkBrd9+fDVhK/RQMfp4b+nKpX0OD1syzbMUsBt8B0vW0lxG5wadKbxBjWSVyWTKqBk75V4HcI3SRV7+pT3UTnrilk5xcEnV3WpDyw2fncsdNiHVuL5hxaaUX8GjU0IW5YsueWOTWuWuwDt1VBDMGHMxyktxtS2a7EZdiPZEpBQcKbnnWRLQDan+02m9KYCUvnV2ZRZzAPn165v9hobUqcDy3K+rh5WvWxcSbQjbBLZqGtsCBtbV3DtAzsSNm6WbNlql2v0lSURNnOZgH/ZFFfCPhjgpZeN8CZlgDmXVhW36jkvL1brlFG9S80rLxtBNtHdi8KQfADpC1D702tP0D3ttxiaKSNNowywrQlpABZD9GQzc1Yz4xiWifIEZDvOt3GaWysgMWTZ6DmyFaAQ3IWmpU7Jd2x6uIKhKiLE+6PYJyPoOsoLkG9/2hVECcg+Y6CaJtlMFF/wPSHRcvY5+qxgmmbyvELSy2Ylb1pToiAq97rHONverJfJEciUkZU3z1BKljYXW6Gf242iBJCvIphv1AmrEQYoeuSNxRS1XuK2jKSs1o8ISAxU00LrvJsycjBsKIwSQJeg5MvIwbChMEoAtUF5vGwF6NlqvQHuidA672+TjR1HjYXNPRFa5z2WEmv7KX7OiAl/KZziW8+i+qoJCpKNrv51yJGn01YgItnI6v8AEiqHuloyIGEtpdZZMM+PsR7oYuHQWK3uSdkyMs1jXVsHizcJwpaRvj/G2TfJyE/Cd0xk2JfNMc3FngHJy23cM9n6xL6lHmdfNq6LkeMYiomoH0Lrn95OjskAk6N/wSXk58dAT5PNDlGWINtcppka/Ys1ZJsY3bwz1/bzrHljqI0DksOacvR68nW4NPoHKYZybWGaBp7ANy9bZLUeKrOiAQIHMAHo2QcAp5F9iipqmIZssU7BKlbAZOHwH10Yo0M='
_TARGET_BITS_PAYLOAD = 'eNrdWEl25CAMvXdnwbGyyuMmzRFYsuCBYgYzWJINVVCLsOjXsQo+Gr6Q9A+kAQlxfcV/Jaj0hzPqECoBDmz8Jk38oQVmKVbiBSMw3mpJCTIwsdJHhQU6SY4TLwKRFDRR2u218bRemo+P13ImSH2Q6rztvwhfdfgaDXScHv57qtJIj9PDtmLDIoW8DX7iZRtp3ganBsg0QmeN3FXJpApYh70Sr0P4JqmiTp/yPqpnXTEbp0j45Gou9YHFxu+OlR32oZV4/qGVzWg+g8YmhC3L1dxyx6Y1S16A9mpoIJgw5uOUFmNq27XYDLuRbAnIWzjT806yJSBV0v0mUwrdANny6mzKLPqB82vXD3uNDalTgmI531YPq142riTaETaJbNQ1NoSNaiu4/oEdCRs5S7Zitcs1cGVJhM1cJuBfNsuVsA8GeOllI7xJGWDOpU3FbTHn3cVqSBmLXapfedkIsnl0LwrD8QFkLkD9T689AXrabzEMU0bqThlgWxPSACyGx2TTc1bT4xiKifIEpBDn+zgtrRWQGK5uFBzZKlAI7krTWqeUO3Y9XMWwDRHi/bNYJCOYNsorkOh/igqiBKSeMbKaOtnMV1/wPSHRcuIcfVYwXTN5XiHppYqSN60pURDVe91jnG1v0UuXCGTKyMabZyglS+uLrbKf+42+BpBoIphv1AmrEQaoepSN1RStXv62jKSshkcEJEZWU0HvvJsycjBsKIwaQJeg5MvIwbChMGoA9UF5vGwV6Nlq2AD3ROid97fJxo6jxsLmngi98x5LibX9FD9nzAl/KZzlW8+q+qoJSiYbXf2bkCNPp61AzGQjq/8DyNsS6nbJgIS1lF1nwTI/zvUAioVDY7u6J2XLyDSPlX0d7N8kCFtGCnyMVG+SkZ+E75jIsC+bZJqLPQOSl9u4Z7LhxL6lHmdfNq6LceMYlomob0Lrb2wnyWSAydG/5xLy82NgpsmmhihLkG0u00yN/v0ask2Mbt6Za4t51rwx1M4DksOabvR67nW4NPoH54dybWWaAZ7ANy9bZLUZKrOiAQIHcgIwsw9AnkbiFFXV0B3ZYp2Sq1gPk4XDL+9ZzeQ='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block030_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
