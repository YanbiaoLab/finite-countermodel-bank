from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,3,1,0],[3,1,1,1],[3,2,2,2],[3,3,3,3]],"priority":791,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block031.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block031","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9Wc9P1EAUflOKdv2RtIWoeKFbusoB9ObJZCebGnclQQ4eIOFEIvGi0b+AktSkhIPLhmxMMLBHj8rBkHghhnDUKwmX1ZMnQ+KFA6HOTIvodkbZbGfeobubt+3XN33fm++9vtQwwHYBqK2W6BEj9iNkR8yOMAgO+4E18nEEDeBau2zxHXAzWNAMnuNJbWzF9/WsA8/MrZVuuZxTJgUYMNUUOAIN23zPoOhaLd0UeIqBzg/FQIIzMFs8nmki+Oepp9r5j2BTF5yahqJf73Q4yRl6HXd6kht2UGb5k9hPokw+g+S/naGd2nZcpml018KgwA7j8/SmvPW3kQK0OI77DKjrKiKDdhz7tmVphqMC7SiOF76NVJREBsEwY+JhHA9BjeaTq0lEO9gw0odXHmEUkBrb5+GHpGi0Nwg1dRNTviD6VQ7YdqH9ilz96OeXS6y0HsQjgBOOSrDRGY9U6bDUfB3VaWq6ru9HkVkRlryebHzZa0TROwrUqLpuxQ8jw7IqRlEGWKv0ngJ92H82v2vXfH8rMq2iS8CkPLjV8ca06366MzHrT88tLRsD1g131r9WDKWQbXPnCgHam1/7OLQ/9sL6+mP3Xrhs3A5NKWTrq2qgzI4HkDowQrYNUBacUBJJscdLT5tbkSKwdhLVupqdLZWz9sQjX8HONgAKTSh1pdgDm+3VBSVgGDEgb0Un6o5qUUsm00fBU1hI+tlRkYxsqUwRWPU01g8gFcEFDd8mQIYisiX9Xs2zkCNfRlY0RGSks6hERmKDAXl1rLO21rQcmTIS6QozUtioy7C0yVbUs4UqmR2Y+M9pgGQzEyCaKQrIpoHC6p/ORRRxwFCZI1Bme7XwoX7X8pTP4jkjW+artZ08Bd8bOC78g9X5yqKguUO7UOFDdXJN2Knm3jzpQoX+fFN1Uhw1SR7v8H6uZJsRZhzZ3oJz+1U1MpIuYYD7AHLcGPqFkVEgeJKvjBROwhskGzHJ1jxLTQg2fwtlyrLqLBqAEJVDeWAGpphni+TgydjZOEYrCJvC51i2hNmfjPvzlXjp+yOc9fBafe6cqItSMzrxe9U6coTX6vMWPeqabJyc5ISBW4hTbLqXkZy8RFkaIq/HQZ5wzR1R2uQwIBG9ivvbeu2RTwYk+IzU7M0upJy7LNJ8mRp9hhUX92ynJarjIlk0rerAGW7qvzKSo4C0i5nrcvotvSuy/QJon67L'
_TARGET_BITS_PAYLOAD = 'eNq9Wc9P1EAULuHAxYR48qR7IeGqR0IMFxPiAT16XIgmZkOW9UBoYhPKX6DRC8GEEwkcPCAJ7hqbzWziyZvCAd3SLRdRA20Tf2yV0nnOTIvodkbZbGfeobubt+3XN33fm++93o8RwFgbqE036RFh9sNgR8SOcAAu+4Fi8tEPZeBaoeHzHfDOXIhDnmOxuj1jWVHWgVaX7zTfOpxTNgQYsF4SOMwYeXzPgehaxSgQeFpmxA8lxIIzEFs8nsUi+Iepp9b5D3MiEpyahhJ96HS4yRlRBXV6kht2cWb5k9hPokw+zeS/naGd2pjWoGn0ykegwAa0H/Sm7KlbugI0TdOOQ6hEKiKDgqZZnu/HoasCrV/TFi7u1pVEBuYeY+KApu1DleaTE0tEG5wM04fX2GUUkBrblb1npGgUJgk1owBRvmD6VQ7YWLtwj1y9/9zlr6y0Dmq7gBKOSrCdVZtUaaNZuqtXaGo6jmXpelAXlryebGvWLuv6TQpUrjlO3TL00PfrYUsGWLF5gwJdH3q0NOJVLWtcD/yWQ8CkPLjprfKa41x9vblirS3PzYaH/ntnxfrYMqSQbWL0MwEaXrpzbX9o+4F/6fzIS2M2fGMEUsh2XItBmfUdYnVghGyToCw4oSSSYk/mHpfGdUVghSSqKTU7Wypnvc2nloKd7RAUmlDqSrHnHtur20rAEGZA9kxE1B3Vor5Mpu+ArbCQHLGjIhlZVJkiMG3HrB/AKoIzy5ZHgEJFZEv6vartY1e+jKzHmMhId16JjEQhA7IrKGJtbeC7MmUkjhRmpLBRl2Fpk62oZzNUMtsM0J/TAMkWJEA0UxSQLQaF1T+diyjiQKgyR6DB9mrhQ70Q5ymfxXNGtsyfqqN5Cr7b0Nf+B6vzlUVmaZR2ocKH6uaasOul4SXShQr9+abqhjhqkjz2wItcybYqzDiyvZk/h2pqZCRdQhMdA+S4MRwJI6NAsJivjBROwsskGxHJ1jxLjQEefwtlyrLmzoeAMZVDeWCagZhn8+Rgy9jZOEYrCJvC51i2hNmfjPvzlXjp+yOU9fBafe6cqItSs7P5e9U6coTX6vMWXe+abJyc5ISBiphTbLqXkZy8xFkaYrvHQZ5wzV1R2uQwIBG9ivvbeu2RTwYk6IzU7M2+p5z7ItJ8mRp9hhUX92ynJarjIlm0uObCGW7qvzKSo4Dib5nrcvqtqCuy/QLj0sJc'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block031_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
