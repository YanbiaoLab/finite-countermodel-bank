from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,1],[0,0,1],[0,2,0]],"priority":792,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block032.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block032","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgBNbMYRgFdAQfPu96839iOAMH8VqWdBp1afQIUMX6FXO6jFp7gIwAJxZ86hSgeBSMglEwCkbBKBgFo2AUjIJRMApGwSgYBaNgFAx38P//6X/1lV/r4z7O//cfCOw3ViUBxdTnM9HAsgf/57sICQqqTHRxOQKyTFxQUcnJpUXACTJcRmUrt7zddEpr3aWUyXNn3MrbZFysvNzNp3eG1CFNztFoJwmE+Yk/Ffn0YtEcJ7nYKcEnFos7fWxxkmN1tIOMMQpQ1bIDF13FPRtYVD6yODaolyhWOQk0vOAUFGQQYKSF1zwEfUUCORZ2GHEpigS6KLY4cbQKApksjgK0sE1zUYcal+IUkEVKXRotARwLBZwSW5oUOJiGfBphYWACZWIWAXhGdoBMTziACA4FIMEIVjYKBhE4cP71pv/ucX/nh59ZfvqffOVXtzXzbvz/n3RiObaq4rno55cg5XsFV6t/+79f4pPmYPZb5qIeJS5lkYsuqi2gCZYAj4UCzootTQnYMpuLSSDnQrDyII0jwGypINE0mjhGAXWBg6NCgwoDkwcTYwMDowqjALBMZGno4MAxi8tBoW0ajAoTWFgYPEElcqMKyC4GDgFBxgbsRnNQ6AIAWv2Kww=='
_TARGET_BITS_PAYLOAD = 'eNr79/////r/hEBw8v9RQEfAz+MqzJC34v934rVEl50tvV78nirWhyeXnq0qBjLW7/2NT919KB4Fo2AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAXDHTAwmDA2tHE1LORLYGQAggN+rXOBYjcS/tLAMnmGhN1v3727nbd7tzXIshfv7t3du7v6/V7IcBmVrfQW8jW9Gqg7OycpXXWi75meOxE7NxelP7W99m002kkCKze+kHrNKx6bvPfhouw15jEv9vJV7334a99ByBjje6paZq+368W2+t+3+X7vq7/Rfa917/t68W/v3v1//48WXtv+btPrdd/jys9+vfd63e571Xu/V70DMn/ve08L267Flt/8ei8bZNHd0uvV67/Hvd87r7r2/ve/Qz6N/P7/F5SJf7+HZ+T9kOmJ/SDi+30g8Q+sbBQMImBvIOLLsGMhU8IK4wgTxgdtXDuDE9UZGOaaR2CrKiRe8YiBlDu9C7nByeDwnPfaYPbbtNjiu1/vvNbbfasaNMGyfnvc+z33qmvnY8tsu0+v+xYHVr72ujUwW95/XjuaOEYBdcH+fffrb///u/3vv/r//27/ew8sE3/Xl3/HMYv7nULbrv+7n//79/9toBK57jbIrv/f37/7V4/d6O8UugAA8XTmZA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block032_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
