from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,2],[0,2,2],[0,0,2]],"priority":793,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block033.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block033","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmMFugzAMQE2Ug48B7QMgymGfAYjDuO2TuooDvW394jkJhFR41TRNTKv8Dim2ExwnNpVcwHeYQJsWhKMwCusTAI3QQqEBwYB/vHtFfvaJRqCrKkBBXPYTyLVG+lXeZf31NNfZwXWu6trqSZVybYIgCIIgCIIgCIIgCI9LkzWeQtPqBKEHxalCa6vQsaMVlLB2uNY5GiCZwxJYjF44mClrw9Vpf7QjRkWCCq1SPo6lI5cdRR4XPniO9PHS90fEnRqTNqkHuh13lkDxYFfhYLCI2981XxkVlzb3CyGLyzx4sQn/kRZDCTO5RhmpKCNTPiKrWuarNTdbuDFmidn+0T8b84miWkMKOVVxzaqyuOPXq4Ab41Zw3iL8Eq/XF3uZkUbbV+MwzLMpG9tjM7nrPL8PVVlaG9Q9vjGqGb00mT4sG+gBk7HDRjeT8UYSjO7MscU22ouzNsQ3ujLub6bIzD5azai2OPyysiTdZtziIsHH9jy6j2HQwZF3u7yJJvm3hk3Ec6MNtIyK8ZGM9WTO5Ip0XsBzjZ+F2n72'
_TARGET_BITS_PAYLOAD = 'eNrtmM1ugzAMgJ+42605oI5H2o0dEOQxdogCDzBBjj5E4DkJP6nqVdM0Ma3yd0ixneA4sankGb9Dgd5pFI7CTdCXiDSixtkjoMPwePeKwuySRqSrmnHCtOwnkGsP9DsFl/3X00xra9OaodXDxzTKtQmCIAiCIAiCIAiCIDwuXdZ4ik2rEmMPilPF1tbsU0crKnHtcK1zPOJmjktwMQbhYIqsDddv+6MdMSoSptgq5eNYOnLZUeRxwYPnSJMu/faIuFNj0mbrge7HnSVQOthVOBiY0/Zvmq+Mikub+4WQxeUevNiE/4iGWMJMrlFGTpSRWz4Cq1rmT2tuarwyZomp/+ifjflEUa0BhbxVcc+qsrjT12vGK+NecMEi/BKvpzd7VkCjbYaqrpVyY2cb6ApzUuq5HsbR2qhu4IVRKQhS4Zq4rKYH2IwtdL4rXDCS4Hzrji22yp6NtTG+yoxpf4oic7fReka1xxGWjSPpduMeFwkhtvfKPNW1j46C2+VNNCm8NW4inRttQDMqxsdm7At3IVekCwJcevgExpfyMQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block033_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
