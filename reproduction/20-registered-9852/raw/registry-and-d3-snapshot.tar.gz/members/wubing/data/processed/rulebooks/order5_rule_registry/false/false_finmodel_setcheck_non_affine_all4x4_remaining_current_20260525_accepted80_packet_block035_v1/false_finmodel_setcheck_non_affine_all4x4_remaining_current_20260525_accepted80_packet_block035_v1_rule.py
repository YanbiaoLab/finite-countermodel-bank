from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,1,3,3],[2,3,0,3],[0,3,3,3],[0,1,2,3]],"priority":795,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block035.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block035","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWc1OGzEQHltGciIOTppDj94lQuFGUR/ALNsqh1YKvEOl9i2sKEgLotIKiR56gsAT9A2KeuLWN+p4vN4NLD9BJIVWO4IlWdvjnW/n7zMMjLFwiwjRNaCLLxcZvHxRqvyoQQB/ii6tleHAHASGSxBoP4PYKY6s00wXHOW4kQTaWMq+BcSyC1LhfcbBuDH3c5fw6hkFrq0G8q3vg6naqZtgj604tn6D6yMXB1uHg6OcPgdN8n4jWwAxL95xwI62PA2ve5SIe1EqfhtppJFGGmmkkSeK7yPmbFNcn0Nth3UVnMPTup7/S0TVu0hg9gZqog4yNw90MzgqsPUD24DbSCM36OLQcaUWCAo2Bpoj/wGhmUtROaYox5Nil6JyCNQqdeQJiQzLZOBXHRYW8hBsk4KX4MSJ50q5cV/wIqGFS9w9T3b6uRFWdK3TSmqQ2bgw59I4XazIj4yIG0W08dGMy9zz2dlYt4FXDsmiPiifOYCmgrJCgSRjYkwdxPUIAJreATLA22HJjtRp7LiFMmRrxT1LCyYqSDhDtdoRTPw789BEOdU1ylkB4G9qgMJMynmohmworTUeRFHSPWMo4QlSrxxxDULkH5lvqQ4V4lx6m6aESZa8MSCLL7GAwl30LZXtNtQgoMZ8jkXU6pVNFcoNVAsNEDN3OHgzCj95iPouWrQmi1wFMbg3xoA3RQPTlduAdxuPtD8iCACALO0ICyso/PsKJuribKbYqIaaoGOICrUQbOb+PYpgmwHRBt9oZBFiin7DFsF2vfEwd3R3d2rzpzUh2J5ZNs6/xu03vd/vo/31w8GvUetscyeajPXqMvrR077+2df8x1BrOg3TGlJ7JH1xWLj4g7VR+upEXQ2mm0m0n6zuq/Y4Wgbo9lvabaUiN90OO/6wHiepzaRiRjKpXaBTMvGFZAFNaM6lnmJJ2kZHGme+dKhELsmb9tLOx14yOM8S+a63K89UEk0u5cq2+vdTzLBDFmVxO+rtptEkkeghUU9s52UHAqEomdBeQJleZ8tkVVJrZC7gtDEtN4oPB5ORh3KsZUP+XrDkYDV2uJ0VF+b+gF1jsBX9ShnOquz1oO42bGbODaeYnfvXK9vV52mWrLL6iKrf6nzq7dH0E9Vew3wgL/Xjdhu0hro15z+k9IHgnKZzpANZBuaxAH2ZHsXttflSVPp2t3Xmpvf2sAbKM/16/JI9sg+QzQuHciSrnB5Nmnh+vjaSSNgy+oFnlz9YhaeF'
_TARGET_BITS_PAYLOAD = 'eNrtWc1OGzEQfqPeOFX0DfoEkHDqoUhopSJYiSjyW7RS3wGQ2kPULosfoKLciFDY9bGHNPEBJZaw7Ol4vN4NLD9BJIVWO4IlWdvjnW/n7zMWOGdwi2g94iCKL2sxvHyRsvwoQIN5ii4hJDdgHQTcKNBov4XMKc6Z00wXHDW4kQLaWKkBA8RyBErifWuAuzH3c5eY6hk1rq0GopN3/ZY8qpvAtpjeYn6D6yNruyc7/e2IPgdN6n4jpwCZKd5xwI623Aiv+zDV96JU/DbSSCONNNJII08U30fM2aa4PofaDuYquIGndT3/l+iqd1Fg2Q3UdB1kwx/oZnBUY+sHrAG3kUZu0MWe40pT0BRsFoRB/gNaWJeiIkxRjidlLkVFEKhV4sgTEhkbq8CvxjYsNCHYOgUvwYkdz5Ui7r7gRcEUl7h7nuwMIq6ZHjGnldQgs3FhbhR3umyRHy0RN4po7qMZl7nnY7OxzgKv7JFFA5A+cwBNBcm0BEXGZJg6iOsRADR9DGSAt4ORHYnTOHYLVcjW0niWFkyUkBqLaoUjmPh35qGJcsprlLMCwN8UAIWZlPNQDdlQWss9iLqke5xTwtOkXjriGoTIPzLfUh0qxLn0NnkJkyp5Y0AWX2IBhbuIWyrbbahBQM36HIuo1SubLJRzqBZyIGbucPBmFH7yEPVdtAhBFrkKwnFvjAFvigArKrcB7zYeaX9EEAAAVdoRFlZQ+PcVTBTF2UyxUQ01TccQFWoh2Pj9exTBNgMiC77RyCKEF/0GK4LteuPB7+ju7tTmT2tCsD2znK1/yCY/h6++5XvnO/3Xh9P26VHe6YrLZfSjGwPxZiDM254QdBomBCRsW/nisHDxB2uHye9NudJvnab5Xnq5JyfdfBmgs/fJaJroiI/GduvreZYmLFbScmWVcIFOycQXkgU0oZFRooUl6RgdqRv70iFTtSRv2k/GX4Zpfz1O1ffhgWrLNO+sqqtj+e+nmN6YLIqzST48SPJOqtBD8qE+jsoOBEJR4qG9gDK9zpbJqqTWyFzA6axVbpTt9DuHHsquUA35e8ESARPY4Y6vXJj7A3aBwVb0K2U4y7LXg7rb2Jk5N5xidu5fr2wrn1pxemnrI7J+a/x5uE/TN+XkAvOBWhWP260/7YnpnP+QErvaGJpukA7EMfDHAvSxtZ1NLuZLUcmPg2nbTR/uYw1UbfGr+5I9cgAQzwuHdCSrnJ53mnh+vjaSSNgy+oFnlz/z7Mmi'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block035_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
