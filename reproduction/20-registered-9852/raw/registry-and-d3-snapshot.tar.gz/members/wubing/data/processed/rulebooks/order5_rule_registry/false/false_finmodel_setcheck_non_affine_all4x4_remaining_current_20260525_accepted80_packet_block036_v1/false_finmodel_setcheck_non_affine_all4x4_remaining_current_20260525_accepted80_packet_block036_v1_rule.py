from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,2],[2,2,0],[0,0,2]],"priority":796,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block036.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block036","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmUFOxSAQhqeEBUtoPAAlLDwGbVjYnUdqXrro22njATyqM7SpmsfTRKN5i/9bUJhh+EmGUAINgdvD2uT5oxJ5Ug3XDJEYaFq1fJ5y69znkJmU8TRxSTZRQ4o0R9mf6YuInkpV0f34EM6Luew1xT7k2Me2T+2dckgbAAAAAAAAAAAAAABfM625HXOueMod3Bid68KQ58V0s/212uN65WaPitA5hpDzsljHYgrJuY5ptE21y9eKiRtc8xMdRvIkwdze+3iiw72F7M7tPrf7MKo5YjlBFdMmpO13Gru7hNDuJOQcgH/kNT7Lyw6XeY5r2Xllt7eD+Qu1l8j7fziJUHlQ2nf7wTTIxO2SxiA/5sp5QLI5yPFhXzim0xXTkeVewpxj27uTR+HVJk5u9Fb396MsRn15HiijlklsC4cnkCqmisbh9LM9sRTbpGFO3rwBYVphTA=='
_TARGET_BITS_PAYLOAD = 'eNrtmUFOxSAQho/qAUx1ZxfNS4/kri5IyzHeglAOYApLFoSOM7SpmsfTRKN5i/9bUJhh+EmGUAIrgdsjBO34kzU5yivXIpEYqG+SfB7V4v3nkI5ydNRzSUHTSpkSR4Wf6YtI6ks103l4sU9tvOzVm8kqM5ll0str9kgbAAAAAAAAAAAAAABf0zdqGZSqeMod3GC8n+2oujbOXfi12nNz5WaPitCTsVaptg2exTKSc524pqBrl68VEze45no6jORIgrm993FEh3sL2Z3bfe78YdR4xHKCKqZNKIXvNHZ3CaHdScg5AP/InXmQlx0uVWeasvPKbh/G+Bdq94b3f3sSofKgtO/2Y1yRidtFD1Z+zJXzgGRzlOPDvnDinCqmI8uThHnPtncnj8KrTZzcmEKazoMsxnR5HiijlklsC4cnoCumisbhdF04sRTbpBFPLr4B6xcP6g=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block036_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
