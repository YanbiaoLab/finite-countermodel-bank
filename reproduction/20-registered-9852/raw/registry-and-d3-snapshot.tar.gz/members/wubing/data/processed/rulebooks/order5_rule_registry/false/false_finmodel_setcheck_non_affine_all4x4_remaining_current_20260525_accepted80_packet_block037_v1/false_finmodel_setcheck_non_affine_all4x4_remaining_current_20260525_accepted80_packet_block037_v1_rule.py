from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin6_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin6_explicit","model_table":[[2,2,2,4,4,4],[3,1,1,3,3,1],[0,5,0,0,5,5],[3,1,1,3,3,1],[0,5,0,0,5,5],[2,2,2,4,4,4]],"priority":797,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block037.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block037","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWcFuwyAMNSgHthPJF5CISfsMFHFodton5ZBDeuuqfsA+dTZB0bokXdNC1Gm8Vo2EFbmAzXs2DAyDM5iG0+Okv41l+HkUcM4UyBnD+3FX7XsxNbRHWzTWrnHyqT9skeczlpe9PvZ9mKm8FY3OczY1SD5MVaifU+F+k4oA7l+e6FftdVXd9H4LBv+Ocd/HiY+EhISEhE0huQEmgGVIzSxTxAgCabqN4+0ZGqIuIjCN/NnO0X4weEWEksBuQHOvDTnqSGUcSINUlbV9L2vBYngb5IxzhPKpqm3XizyvRRnDmVISODCMFGUwOjLcNAYYKirKQp60mxFJPycMh6UUZZeS9RaZWpJOdKE5LGUn6zjJVo2OKDRlXlJUYvynjVgFX8KMOeCXUpTZn082X9A5Ry40h3Or7GQMb76uHHPAL2Xni7SUbAkbIzFbSrbHQtnC/GkosSoALlyPiNReEGZbNu14mNbYWbJN23DDfmKdAy7/cIau3AnBbBfZeaFdeDuzbeQoIXSyiQvJpjA0W0o2ntbqChk5d4xEUJaL1xOwkbKM2CAZZiVUOxORVwwpMGsaJP6ppwdUk4J6FbO5LAh3n/V/ZeSC4bBwiXifjOTjEXVuoaKA/zoUt594H74AvwOS+A=='
_TARGET_BITS_PAYLOAD = 'eNrtWcFuwyAM/dR9QNX11hxyyCfttOyAIj5jUlHCFyScNg4ReDZB0bokXdNC1Gm8Vo2EFbmAzXs2FriFM/DS0GMnvo31+HkUGGMlqBnDy/6tPmZ6aij2rC0ZW+PkSTyztutmLKej2GdZmKm8tqXoOjs1KDNMVcufUzF+k9oA7k+f9CuPoq5ver8Ajn+Hu+/jxEdCQkJCwqZQhoPVYHukZttLYgSNNF3E8fYBJVEXEZhA/izmaD8YvCJCScA2oLn3khzlpDIOpEHqmrEsU5W2MbwNcsY5QvlUVyzPdNdVuonhTEoFBixGiuQYHT1umgUMFRllIXfCzYiknxOGw1LqJk/JeotMbUgnutAcljJXVZxkq0dHFJqqaygqMf7TRqyCL2HGHPBLqZv+zyebL+icIxeaw7nV5CqGN19XjjnglzL3RVpKtoSNkZgtJdtjoSlg/jRUWBWA0a5HRGovCLMtm95MmNbYWbJN23DDfmKdAy7/cIau3AnBbBfZeaFdeDuzbeQoIXSy6QvJJjE0C0o2k9bqChk5d4xEUJaL1xOwkbKM2CAZZqVlMRORVwxJ4GsaJP4ppgdUmYJ6FbO5LAh3n/V/ZeSC4bBwiXifjDTjEXVuoaLA/DoUt594H74AjW7eLw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block037_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
