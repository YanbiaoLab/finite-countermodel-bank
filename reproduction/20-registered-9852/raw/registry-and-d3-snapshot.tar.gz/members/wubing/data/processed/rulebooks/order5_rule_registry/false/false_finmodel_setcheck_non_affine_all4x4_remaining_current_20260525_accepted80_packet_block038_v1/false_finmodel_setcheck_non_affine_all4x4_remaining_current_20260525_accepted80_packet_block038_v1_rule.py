from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,1,3,3],[3,3,2,3],[0,3,3,3],[2,0,1,3]],"priority":798,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block038.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block038","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmUFrE0EUx2eXRaahh9k0B+tpdhpliznEUnveLpuQSgtJ1dLgydiACr16XsO2TOoeZKUXvZhQBdseNIj4AaqSiODFix/BT+HMZE02bVKodg/B+UEWdubNvHmTefPIPwoAwAUjsbq979tA8rdYAPM91BB/UfkD8309je9Xvj5szVVOdriBlw4oHTJkrz63Y/roXFb8Vnzd+2W/ZGun2eHwI5FIJBKJRCKRSCQSiWTMcYEFFACg+KEv5AArVIy4ouFyRQP1FA0V8qfCHyiUBhRmEaoIVkRqiioVsC8jINCdQQubIvqDKmYYaOSOcK8z9BGZNWJ2vPfPKO7IjS5I7b2oMDoeRl274NjiRJjDnbj/wSHZbB0uXJ358GOjetR6fuivL7/Sb1Y/BxU4FYOzl2mjnSakVSCkxtUwTGzH86HhoThC6wprRWdqF3XMZtY2tuzJLZSoGTCOZAuc5JLjPHWSuh6w+FhgFOq6DY04QiuyLaxTyB1VmNtlSpFuEOZMGzjskfz5F35u3Fl5lM8cfPtFq9fL0+8+3rj3ukMvf0EXxv74F/RcqgQblCSMVMkxPBuyE2KktMVYTuRss+eI7JheETaQbXg1DFVZrSRhFevXJo3lbz+D8cmahAYK6Cjw6C7rReag3aFDrglRDNae7epP3sxX9v311cm75ZW1vDD/dOvStdv5zOx29myhmUvi1hqyjN7V6TjiKvMQqbNCIcwJEY02PONl9qDpk8TMkL9B6P1m0p7OpfLmXpGyDFzMarn50kSDm6dWzSOWlvhiTZ5EyfliFbCiYRXixy6YwEDHGDg8nz2Axj6233fbiro='
_TARGET_BITS_PAYLOAD = 'eNrtmUFrE0EUxz+FH8GLF0FMUPsBRCT10FbQknjRSzF42DaDXeKevQoqpMaTpFRtAi02JMt2z1pqDpEums7OyXrYZudQ0kGWzTgzWZNNuynUdg/B+UEWdubNvHmTefPIP11KqUZHYvZ6byep5F8xKeJ76GH+4vMH4vt6Epe/X32Z2i4e79CyaisLQMSQ2dz2gqXgc1nxHfF1z5SUsuGdZIeCj0QikUgkEolEIpFIJJIxR6Mm7VJKxA99IQeYgWLEFQ2NKxq4r2j4hD+7/IEDaaDLLAIVwQxJTWGlggxkBEx7M3hBU0h/8MUMQ43cEep3Bj5Cs4bMjvb+HcUdaeEF+f0Xn4THk7BrjR5ZnAgz2on2HxySF6mpz992b11aKkykHk0py+v33Y+F69ki2Y/B2YOWnWxBmKpCmOdqGIKGrirEVnEcofWEtYq+P4cTVrph2IvGwSLu5G0SR7Jl9faGrj/R266bZfGxwABxXYPYcYRWYVuYA4Q7KjK36wBg14bMmTd02EP5cxYuLr1be15rTl+5AApfSnuTNz+9uZcAP67h32N//Ktu3SmTDIAd2ynrtmoQdkJsx9uM5UTupPuO4IKlVkgGG7aaR8SX1UoSVLFBbfJY/g4yGB2vSXiogI4Cje4yHzankwkQcU2IYrDyeM6dv7tVnFGWVw/eltZWasL8xoefX9/XmjtPG6cLzdoQt1bEMvpXp66Lq0zFMMcKhTCHUDQa5JSX2au0Aju7EX+DgNfptrFXd2rWbAWwDNxsePWt8mGGmzur1gRLS/QrL0+i5Hwxq6jrIZ+gZxo9RNRFiOo8n1WKxz62P9SW5m0='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block038_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
