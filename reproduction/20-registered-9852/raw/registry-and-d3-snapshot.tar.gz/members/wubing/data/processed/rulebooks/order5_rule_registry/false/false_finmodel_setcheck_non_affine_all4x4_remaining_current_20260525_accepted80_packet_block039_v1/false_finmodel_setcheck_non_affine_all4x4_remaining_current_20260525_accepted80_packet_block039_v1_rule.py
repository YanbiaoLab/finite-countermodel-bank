from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,0,1,3],[3,3,1,3],[0,3,3,0],[0,1,2,3]],"priority":799,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block039.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block039","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2E1qwzAQBeAnMQulKyXkAIrJQYaSRY+lRRde5sidsZBjyI/xolDS9y0SW8gjWwKZ5wDVireQ83xYIIi/M8oJXrki2mjaR/aflM7VW6KfRwRrkpVa8XaPUudqr9RarXrqAyycQx5TakvZK6XXxXbAEG2u5kcA2qwVLB/subLsS0RERERERJt8IkhGqS1HutBC2RQ5s9qJWLDLHvIUIfUEJi3tqfWzK6Slt1s4W0ZRWQ12tFEpUySPiqK2EJJ8EYqvTSjI0+cI8ZXJfeofJPge2fuF/ifrHxGI6E3Uq8akkjWGcFAMqhh9R0ih7w70B33hctyjjoO9qfXiLd/548Sdm/4FPWzovN8pZ4yI7vwADOYWGQ=='
_TARGET_BITS_PAYLOAD = 'eNrt2E1qwzAQBeAjd+lFFzpWFqHMQYKjA5REq0aLQXqZsZBjyI/xolDS9y0SW8gjWwKZ5wqRgLeQ0nwYoSi/M8oRXjmg2GjSR/afnA/BW4qfF1Rr0pVa5XaPGuZqr4QQrHruAywcahpybkvZK+XXxS7AWGyu5kcA2qxFLB/subjsS0RERERERJt8oWpCDC1HutpC2RQ5k9iJWrBLHvIENfcEpi3tifWzK7Slt1s4W0ZRXQ12tFGMUyQvgii2EJp9EaKvTY1I0+cI9ZVJfeofJPge2fuF/qfrHxGI6E2EDylZNEmp9SQYRTD4jpBr3x3oD9ph/31GGEZ7U8veWz7Tz5E7N/0LctrQ+XwRzhgR3bkCP5pbHQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block039_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
