from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin6_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin6_explicit","model_table":[[2,4,2,0,2,2],[3,3,3,3,3,3],[4,2,4,4,4,0],[5,5,5,5,5,5],[0,0,0,2,0,4],[1,1,1,1,1,1]],"priority":800,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block040.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block040","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmDFuwkAQRf8uK7xISLhMgZSVBRJHSBcXFM5tuEFcUIQSn4CjcBSOQEmBtFnbSZpgS0hmBOa/YsbSWPvl8e73yAqtpHUao5+MsepsrUXR1EMLZdxVax1VQyGfSLTFQoc4BAxiEEIIIYSQtsHs8CmhFuZDGaG+8xJVabrKIwG1QT4o076c7t+qXRPxFZBnYfGRJZsvK6Q2H/1dFlmS6JuK7bJiPVsue/lli1MogxAsrIOChoGFu41arK3LgRBRyVrEcL+/oci94iWnkYOfCKqdvRI8bP5d8NGOPmqtBhT3NiEPh0bDwOPqaqfsaxs5X7Dl0+t/Q71w2zVGc/pxSloTuQ+GzSej+02abk2ZssL0r5HfjeQtIQ=='
_TARGET_BITS_PAYLOAD = 'eNrtmDFuwkAQRVeioOQIHIWjcAJTJkUKcwNugwsK03EEpETWRkpBaSQk1mjZ/aztJE2wJSQzIua/YsbSWPvl8e73yB6tpHU6oJ8csOhsrW3U1EMDb/VNa418QyHeS7TFwIV4AixyEEIIIYSQtsFsPJdQC/OhjFDf2RVV+lrEhYDaOT6XaVJO95tq1xR8BeRZ2C6T7OXVCKm9H38voyTL3F3Fpkn09rFa9fLLlqfwFiEYGA0PBwsDfR+13BkdAyGikjXIoX9+Q5FHRUlOI2O1F1QbKC942NRa8NFGqmitBjz3NiH/DoeGgUfX1U6Z1DYyuGLLw8+/hnrltluMZvjtlLQm8hicmk9G95s0ndkyJZHtXyMvvo1EFQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block040_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
