from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[0,0,0],[2,0,2]],"priority":802,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block042.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block042","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmb9uwjAQxs8BhSwIzNoBiPwEVcVUlQh5gLfowNq9Q1VclSHdAHVB6sBTdG63PkJHxo4ZGRApzh9VxA4KIvJQ3W9IpFziz/b5O0sxgSI8RFcPvAogBgjCmj4gwv7RFAGE2RStGJE3Nue8ehghcfzTzrZ1D7t97BHgGgICDsjvhAw05cX6e/E2fZa0hSAIgiAIgiAIgiAIgvxTwoiGGbF1rGbol9M2EuubERPx0Gpm1IJYzdAa2YXHo6VO8kfYPhotd5I30TxODE1k/sjWE2nFUm24YnPeolQTWQxdd9Aace77Tdp1B063erbaK5OtWmrAk0JD98V3KHVdzp3u9HyzLfI6LIX8u/flssQa07ScjtBG6lczsnqyL2EMXzAjHbsENSs3n/J3f++71AWZmG2rekDjaumUtq7oFd1ANtERh1Df17g62ioquqJXdAOJuxqopWmj2nDb0JS1yklmI6mzMgkcMUoP+yvYwvczJuFT6Y+9EwupxavfUwMdzepVHzkn7myGttAkyTWDajfpEInqDG2NPgdvZKUlKpMBzRFfTjUtTiJR7yn5tC+Unj3Xle+Z+BFvhdV+AZNLrlU='
_TARGET_BITS_PAYLOAD = 'eNrtmb9uwjAQxoMYGDN2ZOwjdGvnPgVDJZYK2JqBqqbq0L1rB94CBguFqhOq+gRWgKErBrGECOIrzh9VxA4KIvJQ3W9IpFziz/b5O0uxgCK8RFcX3B0gBrCtjT5ArPHRFAFY2RQ1mJA31qZ0exgRcfw6yLb1CpV97BngE2wBPsjviAws5SX8e7GfPkvaQhAEQRAEQRAEQRAEQf4pVsTKjFg9VjP0y6kaiY3NiJF4aBszanasZmiNVKzj0VIn+caaH42WO8m1aB57hiYyf2T1nrRiqTZssDZdcK6JtIaeN1oMKHWcJZ96I3+6PVvtnslWQzXgSqGh9+D4nHsepf60e77ZWnkdlkLO222zWWKNWYb+jGgj66+OaDwF3/AOV9ARs6AEtTA3n/J3/+Sy1AWZmK2qekDjaumUua7oFd1AatERB1Hf17g62ip2uqJXdAOJu2qrpamm2rC60pS13UlmE6mzMgkcMM4P+0tYy3EyJqFd6Y+9EwupxavfVQMzzepVH/kn7myGttAkyRuDah/pEIXqDG2NPgd3EKYlKpMBzRFfTjUtTiKxnij5DH6Unj2ule8ZuSB3hdV+AbkmwtI='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block042_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
