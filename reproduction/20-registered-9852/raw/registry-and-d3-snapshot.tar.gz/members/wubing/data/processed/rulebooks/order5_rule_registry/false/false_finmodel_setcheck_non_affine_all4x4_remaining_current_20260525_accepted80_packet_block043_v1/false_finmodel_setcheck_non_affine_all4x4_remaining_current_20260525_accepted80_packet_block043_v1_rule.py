from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,1,2],[2,2,0],[1,0,1]],"priority":803,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block043.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block043","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmEFuwyAQRWfoLKjkBUdAUQ/QI8wyx8hRaFZd5sh1IE7jGghOghSl/8mSkW0xsuHPzDfTXzTEk7yT0vEgoafCCA3ZG+5D6UVwn+lVFzcCcRpw1/j2Mrp1pcde5nsDAAC4p2TtTsPdWD+GvtH2YqeheGbG9wegX8d9FpvrHUxTV+lj52mez36ALKNd3I72JC6WnpzDt80/e5iZB7c+eYdkUdI82+lqYR7z62imfQUAWCG2s8RmydiH2u+Da5Pm5eoKkSt1oCV/QPbg1so21DoQCawPdB/Bf4ktaiqIp01GGjd7NtGCethcSs5hF9Sxswa2mMLWJiRTSHhvnE+1cZ1Yl/9lW3po/YeVjWtiG9fIdxJbWBawWFplJramFZHq1jEL+fqWPdzSCwAAwCP5AZsjFVs='
_TARGET_BITS_PAYLOAD = 'eNrtmEFuwyAQRY/cZVcNR8kxspwj5ABRxRFYWCqLKTNxIU7jGghOghSl/8mSkW0xsuHPzLfoX8jEE38p6c+hrE9FYB2yN9yB9EVw+/SqixtGJQ2ka3x/Gd270mMv870BAADcU7K2p+F2rB9D32gf7KchWxHB9wegX8d9FpvrHYxSV2lj5xmez36ALKNd3I32JC4WnZzDu88/+zYzD2598jbJoqR5dtPVwjzh19FM+woAsEJsZ4nNkrE1td8H1ybNy9UVIlfqQEv+gOzBrZVtqHUgbIQe6D6M3bAvasqw1c+MNG72bEwF9Ui4lJzDLqjjZw1sMYWtTUihkPC+JZ9q4zoJLf/LtvTQ9A8rm9TENq6R7SQ2syxgsbTyTGxNK8LVrRMW8rUte7ilFwAAgEdyBLFOW9s='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block043_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
