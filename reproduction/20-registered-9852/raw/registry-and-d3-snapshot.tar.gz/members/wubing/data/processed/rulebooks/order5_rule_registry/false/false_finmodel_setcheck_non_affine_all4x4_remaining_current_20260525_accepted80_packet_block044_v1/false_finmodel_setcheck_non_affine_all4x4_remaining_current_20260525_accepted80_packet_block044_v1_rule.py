from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,0,0,1],[1,1,0,1],[2,0,2,2],[2,3,3,3]],"priority":804,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block044.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block044","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WUFIG0EUnV1HXSvW3QhaqOBmm6gHW3oQ6UHokm4hqYo9FFpqQQk99CItPdmL2WhKN3hJYwi9GTz1ZntohSIaRaGn0p4aWgpWevAY6cVDcDszm3rI7kiCs/PBjeFn9+fN/Pf/+5OXTToAxU6AbSOMr0WBvMmRq06uoBeo5I3ehF4q9grwtH27z9sB7IVeUfJyHE8PvTYM6HYUf8aXwprmccs8JQYo5ykO8+9ul7enl/asQkiheMJJ6A1lUKDcoUsqxSNSoTQ5r4e1nzDXIeXWKhTY44Li3BH6ptd6nC9c2G6pdVwC/ej6H6UE8BNM8tkajDPoT/6/Y7ZjfTrgYMdOsLX8W4tDtCo0yAMZohGxZWraMLUKCZbgggyYKNQnCcwdJCQwiaFeEX2MVkbJiJ4vVFpI+QL+bt+JbU+XofoKURPKOuaLgP/1J1hxa3+h/QL4k7kFTFxaZagC3eGoL2RLfJgYT83m31gZI6AommYYliVHJMEXsq3c3Dy23uFA2aimRYyUJSlKRAr6QrbE+4luRcmX+rWdQIzAUoIaCubLxm2sbf7QtJ3usXHjQTydRrD60VJKwZQvZFvf654yjFJ8yZKmhhQMCy9lMCX7Q7aECLjZiS3wC1bcIqzmZFRJ5Is9XbqatyxOwfZbywlUFU86uXS2jfDmw1Vt5/7YPYNDZ+sDHI0qdX2xL12To0fK7zY+ZHtxkB4AYPQIAnMAQ1X8ZPqNyVGOhaTVQcRJRvJMEZALkV4dEHiAM7MG7tUSH2h3s1ERJYkQEnjIyDuBWEgGapKLjNRjKhpnQSiDAuGxFgX2UUYOxiDHjKQO6n5YAWYMtFFZPjNbjiezTZSFiNWcllIWyRLiMsKBbBHAsfrrPBCdmsQzR4BtD5y1qZVOlvKZfs5Ilnn51y5LwVdpf34WqwvtbA9I9nBno25qSGCZsOWPpXjaomcK21Sdp6O+hia677eZysgpasah9lacZjsD02UklE1g7ovVasZIRlKR4UA9j9h2NupJOBF8i7MzgOH4mIMBb7LpgRiE0UIStQYByyEW5c0M0DzR1SQwZ6+z7mwUT8dwRiCn8I/ZRaNmPwk0UmI7szm/H1XcR/9eo/6heL5SMzdGNs999F/0GvW9Fv1zw2TzmNnm3DD0Z4JHsWlIRjrMcnMgBl0VKzYsexa3ug1WZYnLVErasDgg0XvqaaFfm9kckNQH7rzN4KLzsuDGsd3sWaPr+VJUfdN2WqJqzOMnvuwT1UuINiwjO0ZcOFouu5672OHOMbOR7vAP5AoJSw=='
_TARGET_BITS_PAYLOAD = 'eNq9WU1IG0EUXsnBSzFHD8UGSkt6aumpoGgUKbQ9tN56kngrIaa5SLY0mo2XeiotXnooQaGWFnqoqE2g27AFD0U8lNaDP+lmBQtVMLtWrKuOu9OZ2eghuyMJzs4DN4aX3Zdv5n3vfW/y9FiBMLIDsfWu4WvEJm/i5KqQK9yAGnmjHKOXgDAAPS0krHs7oDCyYZlejubJpceyDNyOyJXc0JqqetwySokBgzGKQ7rQse3t2aA9K1rSKZ61DPCGsmxT7lBMjeKxqFCOndfW2k9IdwDl1ioUsOmC4txRuq7UepwvHO06rHX8gavoeoLShPgJEvlsDcYJ9Gec7Jjg2LoCOVizE6wv9lDkEK0KDfBAhmhEbJCaNkwtQIJluSCDEgp124RjbVkTTmOovywfowVRMqLn24FDUr6gv9vXJAiTQaA9QdQEhoL5YuN//QkW6Q6N7P2DF5NfoIRLqwE0qDgc9YVs2Xszs+nx2CMxKVd0XVVlWRSNomn7QraBrz3N4gMcKFFQ1aKcFk1dL5plX8iWvT+zpeux8KraWckTWHpZRcF82bjevp6rqtq5NTcrv8ulUgjWKlpKs5z2hWx32remZDmcGxLNqSUdw8JLWU4b/pAta0Fu1iTY/IJFugmrORlVEvliL4d+xkSRU7DQQTCLqmLTDpfO1rvW87Zf7Xw/90Hm0NnWIUejSl1f7Ob29HyLfmmfD9metaVWIJxvAVBawVB1P5n+bXqeYyE5cBBxkpE8UwTGS6RXV2we4KSEjHu1yQfax0TBQklil2weMvJTJV8yoJbhIiOVvIbGWVhKokB4rEWBfZSRy3nAMSOpg7ofFgVJGW1Ugs/MFufJbAllIWI1p6U0LLKEuIxwIFsRcqz+Cg9Ep2byzBEoCCtnbWpgh6V8pp8zkmUevNzBUvAF9p6fxeroHtsDknbc2aibWrJZJmzwbjiXEumZwjZVR+mof6CJ7tpnpjJyippxqL1FJtnOwHQZCQwJSiGrWs0YyUgqMhxo8w3bzkY9CSeCb3h8AjIcH+Og4k02pZIHoBDNoNZgYznEorxJFZqn0J+B0vh31p2N4tldTNrkFP41u2jU7CeBFsJsZzbn96OA++jfa9Rvtc5XasbmyOa5j/4jXqO+16LfaphsHjPbmBuG8sL2KDYNyUiHWW4O5IGrYuUXDc/iVreBqixxmUZJGxYHJMpmPS30xhGbA5L6wJ23Gfx1XkbcOLqOPGt0PV+Kqm/2T0tUjXn8xJd4pXkJ0YZl5O6CC8fhb9dzh3fdOSY10h3+A2hnZ+s='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block044_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
