from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,3,1,3],[3,1,2,3],[3,1,2,3],[0,1,1,3]],"priority":805,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block045.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block045","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WUuy3CAMFBQLllROQG6ieqscy6nKu3f4fyUbP5thMTVjbAs1krrRfANqQAjjX/hEsPGH9D+0PdwXBdb4H+FGBcyw7Iw4mAktmGeSYWLEi3aeMHFGKDNMHNFBPT+iopNlVlRXTLXVjd9uWRrKLLauGIR+tnWlmbXgvwJ8hcU2s24BHmzIHvi3S9G6YpJH0gyLi66Acp8Godmn5IriXLFHmj0m2LJjCd8JddVuCsInhxaftMbG745hpwDeOVyea/spYwlG/RlrbEHYMmSoHh+CMhXpkrZmc7JR9WHXYCvspmRDX3W1ZUni9WRzBhV4UkjlfpPNwzSGVGGdTYXTXOT8u+OLXQa+7yCyWd2rhzeTjVyGUINMeSvZqGVsCBvbKrieYLckW0FtWAajLPcwm+Ik7AMATqTutJsUAPe2lGW2HazDM9sSajerjR4MVdFOnAkeAyB6Q83ZIRuyXdhwAAwP0lDYwVB/q+1CkwOAs2EpZqO5eocgysy2hNoLMrKphRNqY/Q+BeD8TCiZnTmrNmfJxh5N18MGLoN0lJHzCXlmtufJlmRkVXcJSorZnidbKyODM/H10OxmukgDUBa3mGzVUHcrETYYX9z5URY321DrMpIKGwKArHFbuAsUkJy2eQOaZCNQw/I6A5SOpm3UDEpO53Tik20xbAgbTQZVv+R5sq2FDWWjQNH4hWM76hI1qtoQNpog7TbvUkrgRNta/bwg2/NnpcZOx4J4xEGKF4vV9Wzhr3/A/FzSHoY/7oroTM1R9RKzkerfGRKqhLqCoJm5puiijGTp0Hliu/J+eBiM5o6acoHZ4otnPJ3H6mCOcfBD+tbANUjmfiymjbwkmfsyMqD2S7fUjDYUk9YGZhsHTTKa6kbKpVPMaw2SSXxH1N49KnbM1mFAGFJPAWCZLV+C2goikg1rP35FIrDMRrT7T5XlikRIz/2xE2o+hZG4W467OKbkcdYgSYdfsiAPFc2TgSbr9q0zmyXbMYnG6h7NyXbvPHrV+lev9kxOWv85UIoiZv8lutkgCWiZtQ14cIZLDRIX+RKXDkjhH7WV5hXfIAlBPRR2PGsaNnF4Q6FgNKEZmSWJS1EQiZFsVvRDlJEhqPuzH8kIzpBLi6JixV2N8h9cDIpt'
_TARGET_BITS_PAYLOAD = 'eNq9WUuy3CAMvHdSFY6V1SvdJJwgxZIFBXr8zFey8bMZFlMzxrZQI6kbzS8EjYBx/I6fgDL9sOGHlsJ/MShV+BFvNMgMyc44wUxoxzyTDRMjXZTzhEozzqhhQiQH9fyISU6WWVddUdVWN/75ZWkss9C6ogD72daVZlZi+Ir4FRfbzPoFBLDx8CC83brWFZU9smpYXHIFjf9UgM0+ZVcM54oUeVZMsB2OZXwn1E27KYCfHNp90hobvzuGnAJ45/B5ruWnjGUY9WessQVhy7CxenwIylykS9qqzclG1Yddg62wm5INQtXVkiWJ15PNGzQYSCGX+002hWoMmcI6mwqnusj5d8cXuwx430Fgs7pXD28mG7kMZwaZ8layUcvYEDayVXA9wW5JtoLasAxGWe5hNsNJ2AcAnEjdaTcpAO5tKctsO1iHZ7Yl1G5WGz0YqqKdOBM8BsD1hpqzw2FIdmHDATA8SEMhB0P9rbILTQ4AzoakmI3m6h2C6GC2JdRekJFNLZxQG6P3KQDnZ0LL7MxZtTlLNvZouh42eBmko4ycT8gzsz1Ptiwjq7rLUFLM9jzZWhkZnUmvx2Y380UagLK4xWSrhrpbibCB9OLOj7K42YZZl5FU2BAAHBq3hbtAgdlpeWxAk2wEalBep5DS0bSNmkHZ6SOd+GRbDBvCRpNB1S97nmxrYUPZKFA0fsHYjrpEjao2hI0mSLvNu5QSMNG2Nj8vyPL8Wauh07HoHnGQ4cVidf2w8Cc8oH4uaYXij7suOVNz1LzEbKT694acKaFuMGpmrim6KCNZOvSeyK68iwCD0txR0y4wW3rxjKf32AjmGIc/pG+NXINk7sdC3shLkrkvIyNq/3VLzSBjMWltwGFD0CSjqW6kXTrFvNYgmcR3Qu3do2LHbB0GhCHzFACW2Y5LWFtBRLJB7cevSASW2Yh2/6myXJEI+bm/ckItpDAQd9txF8eUFGcNknz4JQvyUNECGWiybt86s0myHZNprO7RnGz3zqNXrX/zas/kpPV/BEpRxOy/RDcbJBEttbYBD85wuUHiI9/C0gEp/qO20rziGyQxqIfCDmdNwyYObygUSCY0I7MscSkJIjeSzYp+SDIyBnV/9iMZwRvyaVFUrLurUb4B8GXmug=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block045_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
