from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,2,1],[1,2,0],[2,0,1]],"priority":806,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block046.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block046","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmEGOwyAMRbHlBUuOgEY9iBc9GEcfIAkNJSAmSqUq89+ibYoExebbn5KJaEivRqzT+JA+mTsRd8fp3Zv3rcn6ZLfRG5L2xSUQe4iMM4fZttWD602ttw3aFyRsyYorof4QUQK6ngwXl6U2/wCAS3jsZf5T1eKmPod53R/LNUiedpnnuRZ5t1WYUEqLbN9rmYhHqxHy+EnskjKZi7x0Gsgsmwf4g5cCAJyBaFTTyb9LMdXo01bM+7KQHhSIVsgv+zf2pgAAAEDpXTxypKSX/n/hNeQbStsa2aYWZfOIu6hZyat/ajWj1qZcdo10JmL/7oyw5BhRE6IcVQ6tJZnxPp0LiQ4vKhp/gINqp8RmumKrcuQvOdmr2JhmxBYOxabTYgvLiLZly/Yu2mxGDh4eGQAATvILkFUWRQ=='
_TARGET_BITS_PAYLOAD = 'eNrtmEGOwyAMRY/OwbrwQUYVR2DJwrIZIAkNJSAmSqUq89+ibYoExebbn2qIkEmvgb2j+JA+hTsRdyfp3Yb3rfH65LfRG5L2JSUQe1SDC4fZ9tWD601Ntw3aFyRsyYorof4QUQK0ngwXl9U2/wCAS/jZy/xZ1eKmPpt53R/L1XCedpnnsRZ5t1UYU0oLb99TmUhGqyny+En8kjKeizx3Gsgsmwf4g5cCAJxBdVTT1b5LMdXo01bM2rIQHRSIVsgv+zf2pgAAAEDpXTJypEqX/n9hyeQbStsaxacW5fOIu6hZ8at/UjUj1aacd410JmL/7owI5xhpE6IcVTGtJZnxPp0LCQ0vKhR/gINqp8QWumKrcmQvOdmr2ERnxGYOxUbTYjPLCLVly/cu2hJGDh4eGQAATvILvBxa8Q=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block046_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
