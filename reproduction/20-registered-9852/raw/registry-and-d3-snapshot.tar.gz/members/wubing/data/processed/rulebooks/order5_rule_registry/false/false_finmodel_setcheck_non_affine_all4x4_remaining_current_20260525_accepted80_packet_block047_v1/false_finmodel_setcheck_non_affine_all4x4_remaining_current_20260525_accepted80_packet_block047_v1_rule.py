from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[2,3,2,3],[3,2,2,3],[0,1,2,3],[0,1,2,2]],"priority":807,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block047.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block047","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWcGO2zYQHRIsQC96oBwfCvRCsSrg3IqiH8BVuYBdoICdP8ixf8EYSkEvEsAV0vvG3S8p+hX9mg5HlGyt7U2KdRCj1WAPtixyNKN5M+9xGdhrD0fsXTG2oNOX+yDg4m2hZpw1seiRAP6Uve6K39w4y8YzYyyXIKQEFrOh4dt1UYfg4/aYIA4CJKi4ZCoLD9YXNciN4MAMt/G3+HfKrvhc42KGyS1egW13AtiY2+lWlYch+NqL2ktlx/g8Pbtff387fbOhzzZdk48H+Ryk4UzHWERy3GTtLtBnBovysffuNWihLQw22GCDDTbYYE+16TzxiBA2OI4Z5xZO8Qi9Loyh232kDhyexnr+WzYRNTJYO0b6RsQwy5DAIZ8RxA6JcPWt3hHe46YNF4AM0w/JHWywvlysUSuV47lzM7MOMsuMcU7mlX5VGI5qylUBEWh4pfjGjjMW1aWNkicKGSalyrSxkEMGLUo1JLBFLcdJjzTIE752naN5kWW5KXF7dKaKjXNejAMoplF/eWyKCmGOGs7GtSz1R9b4APRh056NjvOtBIpPkWC+qHeOYr91LgSVobMVqibZ79GWz52YQew2EB8gxoHqyoe4m4s7ZvhEXrbdWiWVViW/Cn4ad46arFEqK1WS5FQ9yWkxcTDSFFa8qAFSmLStwgseIP2cdCGjyJPcs3PTOYoDRzWpVKWk1xOzFrqsyah/Uaty2zXANo7mHuqnBtpxJSmJravdZBN1eJi1XdmgbG7e/uFkowqJDwdRWnta6Jrni3kQFGOqkw9J33PbnaaIuoETuvOCqPBp4DjhKRnqyBGBdSIBIYR24W5cVQraOqGiTWczTdZosjHN9yZbL2sbOsfogW3Px0eAbehtZzJ73REPX2DnUBkjzFjoysansklgG/XAFjqwZR3YzAOwfS57vg3mKp8sXV6Z22m1kO9VmVcrLcefAmwFDhXN65nWdBqGxes8Iq4CPuNnz8L923iwtnDPfld/T7ff/Zi/Lr98ra5W+aydE3A+nMTJNnKCJiQN1BiYYlYyqRHoNBqgGSRnIKEbHvRWQXajOKwCVpqCHHu/xNaEo017CkvudfAn2Qv39c+TcvrH21LeTJaxQl7++qf84loVJxZ8UMvoS4H27BlFFDHwbuleVqXECskn4vrIeaw9LJv9OOTpBIiPAhuXuvHBuu3Y0W32TMFgn9oIbNi7byCBDRqwQQu2ltgR8+SSiGu6CIfE7sTblJ8jNHs73YZSjo4U1gKD4b06zm6wCcTbCSLlVK60PpDijx6QjGZ6hBSmYA/L9gBMoNeCc7odyaZA4mP/bYJ+2b4xV98UPZicakzuh+Xofbx98mL6F8JSf7W65Iq8Bx2k2NXaY/WjlpGZ4O1E9fPqcnrv/45Gzk0UYUf4ABGG/n8r1QUPzSP2D32t8ik='
_TARGET_BITS_PAYLOAD = 'eNrtWcGO2zYQ/Zp+RdEv2Tp7b6AaSLAmGsHhX/SYP4gNFKgNLKvlBxRFbzFQleKlQA+OxUOxJlCCnA5HlGyt7U2KdRCj1WAPtixyNKN5M+9xA8g7DkfsebmRoNOXK+bg4m1ulj40seitA/+Uva7Lb8WmrjdLpaS34KyFELOh4bdJmTHG4/aYIA8OLJi4ZGVLDpKXGdix8xCUl/G3+HfK7v1C4+KAyS1fg2x3Ahirm9XIFIch8Iy7jFsjN/g8Pbua/HKzejmmzzJds48H+Q6s8kHHWFxy3GTtmtHnAPPisffONWinJQw22GCDDTbYYE+11SLxCMbGOI6D9xJO8Qg9KZWi23mkDh6exnr+W7Z2GTJYuUH6RsSwrpHAIZ9xxA6JcPUt2xHe46aVd4AMkw/JHWywvlzMUCsVm4UQSzVhtq6VEsJWuX5dKo9qSuQMEah8bvxYbuoQ1aWMkicKmWCtqbWSUEENLUo1JLBFLedJjzTIczwTnaNFWdeVKnB7dGbKsRDcbRiYoFF/cWyKBmGOGk7GtSH1x9D4APQh056NjuOtBIpPkWA+z3aOYr8VgjFTo7Mpqibb79HSL4RbQuw2EB8gxoHqirO4m4g71vhE3Lbd2iSVlie/Bn7cdI6arFEqc1OQ5DQ9ySkxcbDVFFa8qAFSmLStwQscIP2cdGGgyJPckwvVOYoDxzSpNIWl1xOzxrqs2ah/Uat62TXANo7mHuqnCtpxZSmJravdZHMZe5i1XdmgbG7e/uFkowqJDwdRWnNaKJrni3lwFGOqkw9J33PbtaaIuoHDuvOCqPBp4AjHKRnmyBGBFC4BgbF24W5c5QbaOqGiTWczTdZosgXt9yZbL2tjOsfogW3Px0eAbehtZzJ51xEPXmLnMHUgzEjoyoansklg2/bAxjqw1R3Y1AOwfS57N2LqvlrPRJWrm1U+t89MUeVTbTefAmwlDhXts6XWdBqGxSs4Ii4Hv/Rnz8LVi3iwNhfvvzFfrEa//lS9Kv56Ze6n1bKdE3A+nMTJthWOJiQN1BiYCdIGqxHoNBqgGSRnIKFjz/TIQH1rPEwZVpqBCnu/xdaEo01zCsvudfAn2Vvxxw/rYvX1i8LermexQt5895X9+86UJxZ8UMvoS4H28j1FFDHwfCbe5IXFCqnW7u7Ieaw8LJv9OOzpBLiPApu3uvERuu3C0W32zMBgn9oIbNi7byGBDRqwQQu2ltgR8/SWiGu6CIfE7sTbtJ8jNHmzGrHCbo8U1hyD8b06rm+xCcTbCSLFyk61PpDijx6QbJd6ixSmDA/L9gBMoCfOe7odyaZD4iP/bYK+H71U97+XPZicakzi59n2Wbx9/Xb1JcJS/zm95Iq8As2s29XaY/VjZpGZ4O1E9av8cnrv/45GLlQUYUf4ABGG/n8rzQUPzSP2D87Efv4='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block047_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
