from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin6_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin6_explicit","model_table":[[2,4,0,2,4,0],[2,1,3,2,1,3],[2,1,0,2,1,0],[5,1,3,5,1,3],[5,4,0,5,4,0],[5,4,3,5,4,3]],"priority":808,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block048.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block048","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWc1uwyAMdqJMYjeo9gAJotIeI4o4lJ76SK2UQ3rroj1AH3VgWLS20AktrD/iU0UqoBgcf8Z2dyVM+BSmbdWPrhO0ACVOG1echybF4V2JDykrjyzF94LzmLU2elv7gVwObEe5UFJ6fvIGsJrnIPNiM+JjFj3XVrsVbc9HXpx6xPkAhZVuifls4T5hDacX4zAc5IIxzqUcBtqRIoW05X4SZN5JJ/uBMNaRBjJi4JiIPFWCscaqsulp1s0d44nJdtQn+xZkTFMfy1glaaoU0uzV2U0csKrU9v/4ZHO3LwoyN7dTZU/LzJ9MtlvgX8l2k/gQw7vYMDke68XEajRNq8qedimEucB/4gC1fkvbfxKygShcBHwwHj+tKpevpkWypbeRoz2RTXAUhvWsgIyMjIyMjEeFy9k8IynSuGC5s33GyDJpGHltNFAHzrgxalM49saNur+EkrSmRlzor3ME6L1esPamBVBUQGonqppF2HaUZlUPUBAmPeCO93fQ4J6J2cMODzlbkrO+WnYRh0o+cIEEH+b1FJcOGX7tiitx2JzNg8CfTRkhskV493wZXCmQBI0OHfIpAt40pkCC8JHA06c804YIaV9CHZWe'
_TARGET_BITS_PAYLOAD = 'eNrtWc1uwyAMftQ+wJT11hwitY/UU+kBRXmMSUUkDzAVbkNalHhgWLS20AktrD/iU0UqoBgcf8Z21wNMeGGmbciPrhM0AANOK/achybF4Y2wV0p7jyzCV4zzmLW2elurUl0ObAp6JJR6fvIOsJ/nIPNiW+BjFj13Vru9bM5HPp162PmAhL1ulfls4D5hDadiRVku6VEIziktS1mrMYW0w2oSZN5JTatSCVGrFjJi4JiIPCVMiNaqsq1k1s0d44nJttAn+xZkTFMfy1ilavsU0uzVWU8csKrU9v/4ZHO3LwoyN7dTZSWHzJ9MtlvgX8l2k/gQw7vYMDkeu+PEajRNq8pK1imEucB/4oC0fkvbfxKyARtdBLw0Hj+tKg8fpkWypbeRhT2RTXAIhvVihIyMjIyMjEeFy9k8IynSuGC5s3nGyDJpGHltNFAHzrgxOlM49saNun+AQTWmRjzqr3ME6JVesPOmBTD2oDonqp9F2KagZlUPUBAmPeCO93fI4J6V2cMaDzlbkrO7WnZhy54+cIEEH+b1jJcOGX7tiitx2JzNg8CfTRkhskV493wZXCmQBI0OHfIpAt40pkCC8JHA00c808oIaV8KY9uJ'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block048_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
