from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,2,0,4,0],[3,3,3,3,3],[2,4,2,0,2],[1,1,1,1,1],[4,0,4,2,4]],"priority":809,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block049.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block049","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWUFOwkAUfVOKLcZIS1gSbSdjwhFcGG1IF9aVR/AIujdxNC7qDokH8ChdeY4egSULQu0UVLQFRTuN6LwFLfPLvPz350//Zwg8vEcUEXFpB3NjW/g9OATGzSLDkCz4Bb9YmeSRuXeM0gLLXqM8VzTd6mI1V2aex1cl0BMtc9XLGUwIywagw1o6g/M2FxQUFBQU/iWGifFyGycpalLZJsnr7Tglu5JKFiW7FQo5kizde8xJN0mFPJJKFteGR9W5dolJtiSFntN6aVKptH8GT8ToDKsii/ZjXttB+nGAzjk30MQODhZXxAoLcJZKmF7Osy+GbLYHNjim9IYNwrDvt2ybUt8PQ6tnyogbH/itwPczIkHb829D07Z7pivDtdOU4i40KwrbSStgtl3RavcCKtrczD9B606ldG8tlT+/GO0Ax6JDD4C+ruT4PnrY7DoEmulBtzzZycYdmDC7Irfqafgc4vwZISVX4B/KyKRZIds4IUutpXYffGkFzkVjVaLvcz2bwvqgZnQWZYYo9WKIYj1Src6nyUYbCAot4u3KGXOpeMvycmo/Szv1SOHhQb3dB4jugOtooIVw3YSMpttI0bHMKP/XSdFjSfL1inc02wtVR/hD6Nm69mDlTnm0eu7hay03RBwVggwb29Mlmd9yI/L5yKpl5L3+skV9ACuYmq1ViJ4BXzR5Yg=='
_TARGET_BITS_PAYLOAD = 'eNrtWU1OwkAULmHBkiP0HK56FA9gkJ1dGB0T93oEj+DKumhIMS48AomTaTUsCS3GSCul89kp/qAtKNppROdb0DKvzJf3vXnT9xgOB+9hGFxcBtbc2D1+Dy6A+qjI0OQLfkGOVibZpO4OZazAcj0uz5UkDnpYzZVnz/WDEuh5krnq5AwhhOURiBEsncF7mwsKCgoKCv8STS16udW1FFOpbDXt9baekh1IJTO0mwqFbEiW7j3mpKulQnalkunTZrc61w5Ry5ak0HNWL9UqlfbPYINH/WZVZMaVTqa3SD8u0T8mEUa4xeXiilhhAU5SCdPLcfYlks22RVvnjO3Rlmm27aHvM2bbphl0QhlxIy17aNl2RiRoO/auGfp+J3RluHaaUuyYYUVhOxta1PcrWu2OxUSbm/knaN2ZlO5uoPLnF2Ng4Vx06BbQjpUc30cHDz2PIwkdxIEjO9mIhxBhT+TWJA2fx70/I6TkCvxDGamNKmSra3yptdTugyytwIlorEr0fa5nU1gfTKP+oswQpZ4OUawbqtX5NNnYGFahRbxdCaUuE29ZUk7tFySnDi88PJgM2gCPPZAYYwxhrpuQxmwbKTqWaeT/Oil6TNO+XvE2nvdC1RH+EHG2rh0EuVOeZJJ7eD/JDXFPhSDD491sSea3XIN/PrJqGbkdv2xRH0ALpqZrFaIn7T33xQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block049_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
