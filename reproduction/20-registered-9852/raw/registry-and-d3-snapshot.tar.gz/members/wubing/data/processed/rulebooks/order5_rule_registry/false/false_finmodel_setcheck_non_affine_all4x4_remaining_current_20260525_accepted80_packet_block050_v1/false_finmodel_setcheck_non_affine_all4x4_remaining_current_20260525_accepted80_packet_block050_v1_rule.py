from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[1,1,4,4,1],[2,1,3,1,1],[1,1,1,1,1],[1,1,1,1,0],[1,1,1,1,1]],"priority":810,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block050.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block050","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgBJZ0MIwCOoIPeqcyt1c4kaJlSadRl0aPAClaOBkYlJiwSSyARXeAEws+AxSgeBSMglEwCkbBKBgFo2AUjIJRMApGwSgYBaNgFAx38H/9//+z13+5/99+Wd3v+n9Xb6z+///7+7afXkw0sOzBX/YDjAwMBUDmgfrdd/czgwTlaOW1Nd12u170BvhZXxU+pbm8wulj6yPeo8Jc8xU5hnysTWBoUFBiYBBkBbIbIGN+CgJOtPJXmJ/4W5GiF4vnOPHFTgk+sVjY6WPLITlWRxmWIR+QHoKuIoEcCzuUuBRFAl0UW5w4WgWATBZHAVrYprkIbpFSl0ZLAMdCASfFliYFDqbRgmgQZzYmBnBmA5ZcDE0dDmAx2mU2uoIDuzWW333EyUiU4vjYL05g5a02XJUh33Q6+hUGs98yF/UocSkTV0S5mARyLgQpFwnSOALMlgoSTYPZayoMDB3Epj8BQRAJU67YMpqfBwo4OCowsDAwcTAwNjAwqjAKAHMPC2gKt2EY+A0Arupk4A=='
_TARGET_BITS_PAYLOAD = 'eNr79/////r/hEB0+f9RQEfAf9F0mkf7XlK0RJedLb1e/J4ULd/+/7/7F5tEPCy61+/9jc+A+1A8CkbBKBgFo2AUjIJRMApGwSgYBaNgFIyCUTAKhjtgCGBgSAngVmA4ENnI0sCopR7CwMAhUMm29S8NLJNn+mH/7///fiDTvsFFyeEPSPAhrbwWXHLQVbxo/cYjWm9Mr0W07+Wrkv1k9eZrwr3vQz7W8v/X37/7//+7X0B2PWTM7/77vbTy18qNL4Re94rHJO/9uCh7jXnMm7181bYPf+17/HvIB+T2d7ter/seV373673X63bfq977veo9kPl733ta2HYtFm7R3dLr1eu/x73fe6+69v73v6MF0SDObH//gzMbsOT6X1u+HyxGu8xGV2Dvcj1CSfbbP6IUL1jEvResvOrw17bVnJfLC+4PZr9Niy2++/UOcUXU7tPrvsWBlL9ee90amC3vP68dzF67/f9/ObHp7/07EAlTfq96ND8PFNi/7/7/3///fv//r/7/v9v/3gNzz2/QFG79MPAbAJ2HDFY='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block050_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
