from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin6_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin6_explicit","model_table":[[0,2,5,5,5,5],[5,1,5,4,5,5],[3,1,2,5,5,5],[0,1,5,3,5,5],[5,1,5,3,4,5],[0,1,2,3,4,5]],"priority":811,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block051.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block051","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WUty5CAMBYoF2XEEchNVVjkWi8y9xwaM+EjYdEOzSFWbbuv3JD0p/wQYASKcv/AXhIsflDk+GOeFEjo8AxO+qAVzHHsjPXNhpLbkRRJMnPjQ9Rc23vRv9NFAE26rGx3eRtw6beH4pIw7buVpl00iv/3pmCAi3pamgIi3kPQ0hSl4K86fnR75CcoWt6fI07+XBdDa6G2ySLVGRlOEVn1UgjpEbKIp7oqpr19XGIbvamUWQQHxyWPkJ6Wx+N1xUsA+dP4CjD90khvNZ6SxBWHLUaF6uGGFXHagSVu7OdnK0iaD4H0xZCvstmTLhT5C021OttBRzqaQyv0mV3pbCNK562wqnPYm59eeH1YNWG8gsIio2cO6ZGPUCNFMNEWvTDZKjQ2wcSWDqxvsBtj8odcaNXpm+TZs+M6mOQp744CXOhsRTcoBcyFtOpuvc15VPDXTaDeqBPaVzsZ4re64k7AxjSAlSubdzAR9NC2l/x2NfOa1kQOaH9IAco0gc+c1+1yGe97ZqOkGOy6i8Jqv0ncySOc6GzFkoV7pIRMuw6HSKhTkk1lB25hsUGZ55BCXA3KyUa5UNGD4mRDSj2BUo/UVSJ+jaXO4FDNlU17LxqDKWqADRC8DOJByNBIn5KKzXdG/9EJf2QIS2d2lp2sjvwtBiDXFeg1ZJ2GHvBASzZRjGllijYFNsyJA5bIKucm7Dj5VslVfjV6rIhP14uxQmNC+aVdyTbJhJSjcnV0hotHXh5tkS7CJD8lqQ8rArUoK3rViuUm2e9gQMooMQrvUONmewYaSkV1R2AV0sg28Rm2gCBkI0jp4t1Ri7QznxtxXmaXiNL2GrPnBqpHRs0T0eG7ObF85fadkI9n/IUjqDPUV0wa7uA24XTx0Q/QQsUo7LNarZ1LDbmI0dmw94PpTiGVppIcnL4bJZOM24WrjgiSTmwEfX7wgKZvgy2PcfbL1hT3LLvm4apFERU2OFiRMZ5sY4zjOrxlE/Z5f+apu7e/56q97/E0UmLT6p4bMHiBkMzDTyeb6cQ/6cgbuzTXG1Opfrkm2idWNfmMv4+ez5o2ldlqQHN5UT9VTr4uLCxKh5KNai5lmBD9QDzpb6NnmEc2KY4aBauScaQCRRlL/2lA08wo8JbFYObum/A+bqpp7'
_TARGET_BITS_PAYLOAD = 'eNq9WUty5CAMvfdkwbGySukm4QjswoICxgaM+EjYdEOzSFWbbuv3JD0p/zxoDz6cr/AXvIwfrD4+aCm89SY8Ax2+aDxzJHvjBHOhnVHkRRJMnPhQ9hcq3vRvFNFAHW6rGxPeRtxKo+D4ZLU8bt1pl0oif8XpmCAi3pamgI+3kPTUhSl468+fnR75CcoWt6fI07+XBdDaKFSyyLZGRlO8sX1UgjpEbKIp8oqpqF9XGIbvamUWQQH/yaPdJ6Wx+N1xUsA+dL4CjD90khv1Z6SxBWHLsaF6yGGFXHagSVu1OdnK0uaC4H0xZCvstmTLhT5CU25OttBRzqaQyv0mVwpVCDK562wqnOom59eeH1YNWG8gsIio2cO6ZGPUCNFMNMWsTDZKjQ2wkSWDqxvsBth8odcaNXpm+TZs+M5mOAp744CXOhsRTcoBcyFtOpuoc95WPDXTaDmqBOqVzsZ4re64k7DRjSDrS+bdzAR9NBWl/x2NfOa1kQOaH9IAko0gfec19VyGfN7ZqOkGOy6i8Jqv0ncySOc6GzFkoV7pIRMuzaFSWRQkkllB25hsUGZ55BCXA3KyUa60NGD4mRDSj2BUo80VSJGjqXK4LDNlU17LxqDKxqMDfC8DOJByNBIn5KKzXdG/9EJfqQIS2d2lp2sjfwtBiDXLeg1ZJ2GHuxASzXRjGllijYFNsyJA5bIKucnLDj5VslVfjV6rIhP14uywmNCiaVduTbJhJSjcnV3ho9HXh5tkS7CJD8lqQ8rArUoK3rViuUm2e9gQMooMQrvsONmewYaSkV1R2AV0sg28Rm2gCBkI0jp4t1Ri7Qwnx9zX6qXiDL2GrPnBqpFRsET0eK7PbF85fadkI9n/IciZDPUV0wa7uA24XTx0Q/QQsUo7LDarZ1LNbmIMdmwz4PpTiGVppIAnL4bJZOM24XbjgiSTmwEfX7wgKZvgy2PcfbL1hT3LLvm4bZFERc2NFiRMZ5sY4zjObxhEfZ9f+atu1ff56r97/E0UmLT6p4bMHiBkM9DTySb7cQ/6cgbyzTXG1OrfrUm2idWNeWMvI+az5o2ldlqQHN60T9Wzr4uLCxJv3aNai5mmPT9QDzpb6Nn6Ec2KY4aGauScaQCRRlL/2rA08wo8JbFYN7um/A+wx9as'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block051_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
