from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,3,3,2,2],[2,1,2,2,4],[4,3,2,3,4],[4,1,2,3,2],[0,3,2,3,4]],"priority":812,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block052.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block052","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWV2SwiAMhgwPPHIEvEnGk/Gwe+8toC0tpEKBrOss4+hoKCE/X/78Fij8yy8V3vdftI1fbKDgRiksSxGEpAiaIjwYFxZQjxiK4Mh7qXAaXhQFDqKoMq9FFLfsVQYjdbvnPZwWqbtnn1uQFAVyUeIHEKIUrHZzK5206d5G9mQbCs6lWblJTmaWVbQvGlDjl2MVzbByA05m+Bq2nwA2YACbYTTeArYlr6GQKup0alxxJoRkn31invkH21WwfW5mu3GGZN7MpjiZOdJ4ah7YJE+CfV+wyTFgc0yYl1v9v+871mRgz9wGGsFGZTaZVf39CvgNsL1hGYmsYNP9YGssI+0fAhtlPD0hdNoDqvVksJ2NLcqjhMtu48tIX6+GMlIZ4evXWFHGiQZosf74KG8PCvDTDV2MbbkqDGyM3ONJf/yTUYqQQh2dXC7nkavinjLabUV/b70eB8U6OrlcziMDcpgDJeZJtsamQAi9/hg1fdCVJHnkvqBlZFSltdIEajVpzkO3JuKxAH8RhGBsBa2q4gxTZhtbQRtaVTb4oB2ZbOFUx4N7AzzV8egCgvY4VYjUvR4jHRHYXS412mlgm9EWKEqnOKE1duSpM9q4NLPtD5zRxpF/LVAlAhAKkPVgwzpkYGf/oOmL1ZmyyY8khYKCGAWwuUFgm5F4Wkb/thcDjnWaYGZ2FlQkBFnl69BneCR92GAd2FqUEsvI0vwYqiRrc5kfrjI8tw=='
_TARGET_BITS_PAYLOAD = 'eNrtWV2SwiAMvvfuAydzchM5Ao88MIEtoC0tpEKBrOss4+hoKCE/X/78cuD8yy8T3vdftIxfZKDARiksSRGcpQiaIjwYFxZSjyiKIMh7mXAaXBQFD6KYMq9FFLHsNQoidbvnLZwWqbtnn1uAFAVzUeIHEqIUrHYXK5206d5G8mQbOM6lWblZTmaSVbRvGlDjl2AVTbFyQ05m8Bq2nwA2ZACbYjTeArYlr4GzJup0alwRKoRkn31invkH21WwfW5mu3OGZN7MZjiZCdJ4Zh7YLE+CfV+w2TFgE0yYt1v9v+871mQgz9wGG8FGZTabVf39CvgNsL1hGQmsYNP9YGssI+UfAhtlPD0hdMoDqvVksJ2NLcqjhMtu48tIX6+GMtIo5+vXWFHGiQZqt/74KG8PCvDTDV2MbbkqFG6MxONJf/yTUYqQQh2dXC7nkaviljLabQV/b70eh8U6OrlcziMDcpgDJeZJtsamwDm9/hg1fdCVJXnkvqBtZFSltdIEajVpzkO3JuKxAH8RhHBsBW2q4gxTZhtbQStaVTL4oByZbPFUx4N7AzjV8egCgvY4U4jUvR5jBRHYRS41yGlgm9EWGEqnMKE1FuSpM9q4NLPtD5zRxpF/LVAlAhIKsPVggzpkQGf/oOmL1ZmyyY8shYKCGAWwiUFgm5F4Wkb/shcDgnWaoGZ2FlQkRFvl69hneCB9WEEd2FqUEsvI0vwYqyRrc5kfnj80fw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block052_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
