from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,1,2],[0,0,1],[0,2,0]],"priority":813,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block053.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block053","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWE9rE0EUfzOMMKk9TGIOFS+z6woRPVQRz9N1W9pbG/TgUbBQQb/DENKyLS2Eqhe9tKE3b8UPICKCfw6e/TS+ebNJNt2ktTTVKvto0iQ7b968N/Pe+/2GgTEWRkhdcAM6+3KQwsUXpfofNQjgZ5lrL6oaDmwXQ2C4NEICMAjdxAETODOFrGbcT86ye5MysoCxrIFUaJxxMAJQT463wv0aGb4E6g4e/Lj7Zu1QPShq2A0LL5k3MPzkYPPuVmO7Q597M8njnawAhJxilbnglkTe97Z7ORbHTaCzVymllFJKKaWUckZpyD4WsCeN1RXEOYJgh+vgHM6Gev4vEQMEK4FZOBEd5gDvWLwj3KbYMrillJKXV9HuYhjGNQliMWQpshPt+A8IvRmFoej4EsUc4+GdhCvmyBMOSPFHAyz1GviH/ziQooYEH0Ob+An3PKlNiW13k9pSkhiXrUsaqgOyIzrGgCNorhz6IqoMJrbjcNbNwGkcG+S/yRSFlahjVZ5sZSRIoUcWWMSUr7dAQ0FZfJcd4npYOojrmVoFBFUb54cPgFswFQ2qHVVS7FVrlS28nbmoIIaKUJ6UiSFSZml0j9opv3YmQWpyx3FNDXkSCQNfKKJQfGTmtEWPNH61kXJlcqgWDhdJqful03rSeqQQCm8qC8W4zmajHEPuRc0fG+sPAUWt2NlU1WsYZ8NtFyqSPi6Fycx+dk5Oor6TFq3Jo5q7L0Db/r7An2cNiqJGu98/NkcCkPdjkAhZKLL96rmos7sZMrQIQ1GDQtQ6whmi4cfbyDpbLoi2v6mlTECM6QMPOgJHgAcvYI1Bso29QBqfbH9WXrzbvH/5zvtHC8H6/bfPvz+s7M/Gq59bevo88Ojejf0PT4EfNkHb6OVmiqGK9rZnzgmWHey4i7Xl5Mpr9bPRnX0QrMfT62qqFUiYfJ3BzgbYQaipUEN1FpRP2l4PmhwI7dSMDrElVfBwtlJD94AqlueU9s3k2nw9bnR3YjlfX5H7Kn6yEctLc+rfLzGLVfIoDaeC+koStGOJJySoi7kR97HG91Kb65l51iGH0rvYX1FudvuGwq1Ge9mFMmi3tOQjlEq5INLhQMnm0Akmm4dhlGzMAT2bR2Y2A67syLEpALtCov6VTmC+rXW/xNOVEY9U4ZfHq/UmDX+tpq4/XLgtP+rTWVuTcvaqHVmiWAGX3cIWSsNdq/yaslMH6Fl3O5y6/nslKrm3Utl3w+vNxidMSz3TusgnMgJI5chtKvYWRSSrNzxol/n812DkHOHCUXhgzNn+d66rfgFbNacu'
_TARGET_BITS_PAYLOAD = 'eNrtWE9PE0EU/zSePfgnMcb4AQw3b6Rw0QtCmkhgI00z30ETSTDx6EEC3CC4LHM2BjlobOKyOxcjh9rOAekkTmaeb95s2y3bggRQMPtCS9udN2/em3nv/X5jgXMGQ6SpDQeRfRkP4PKLlL2PAjSYs8w1Gbe5ATuDIeBGca0ALCRu4tRqnJlC1uLuJ2fZvSkVM8BYtkBJNG4NcA2op0ZbMX6NFl8adfsPru88XhyTW0UN9ozBtPUGBp+Mz+/MNWar9Lk7kzreyQ5AYihWmQtuSeR9d7vXIn3cBCJ7lVJKKaWUUkopZ5SG6mEBdtJY0UGcowl2uA5u4Gyo5/8S3UewCiyDE9FhDvCOxDvabQorg1tKKXl5Es9sJEnUUqA3EhsgOxGO/4AW83GS6KovUdYxHlMNjbSOPOGAAH/kYAOvgX/4zwApCgjxMdSInxjPk2qU2GwmbK2HIXfZui6g3Sc7uso5OILmyqEvopJjYjsOx9wMhsbZfv7zTFEzhTpM5slWRoIkesTAxlb6egs0FCTDd1Ulroelg7geb3VAU7VxfvgAuAVT0aDa0SbFbrWW2cJrmYsSIuho6UmZHiBljEZ3qZ30a7cKlCB3HNcUkCeR0PeFIgrFR3xbMPRI4FcWS1cmB2rhYJFUolc6mSetRwqh9qayUIzqbCzOMeRu1PyxYf4QUNSKnU22vQZ3Ntx2oSLp41Ksyuxn5+Qk6nveIgR51HL3BWjb3xf48yxAUtRo93vH5kgA8n70EyELRbZfXRdFdjdDhjZgIGpQiFpVO0M0/HgbWWfLBZH1NrWUcxDOe8CDjsAR4GEKWKOfbCMvkEYn29+V5w/n3//8+ODtZrrw/tGLG8udid1o6U5dHFwEHp38OnH/FZixFRAsnp4PMFTx5Oz+BcGy8afuYm0t/DElrzUqu1vpQnSwIA/rqYLzrzPY2QA7CDUVaqjOgvRJ2+1B5wdCqy0uEmxJHTyc9YDTPaCM1AWl/Ur47V0zalSeRupdc1VNyOj1s0j92pZXv8RstMmjIDlMm6thWosUnpC0qbeH3Mdy30tZrmfmWYcaSO9if0X5UukZSuYatTUXyrRWF8oMUSrlkkjVACWbQyeYbB6GUbJZB/RYHpmxDLjaI8emAOwKifpPOgG/uVi5HR10hjyShV/eLDVXaPiUPNxb3vyk7onTWVtUavc7G1qibAGXfcYWSsNdq7wV2FMH6GVlNjnc+7MSFX5Y7Uy44c2Vxl1MS7Ffv8wnMgYI1NBtKvYWSSSrOzytlfn8z2DkNuHCYXhgxNm+OtdVvwHxPMn5'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block053_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
