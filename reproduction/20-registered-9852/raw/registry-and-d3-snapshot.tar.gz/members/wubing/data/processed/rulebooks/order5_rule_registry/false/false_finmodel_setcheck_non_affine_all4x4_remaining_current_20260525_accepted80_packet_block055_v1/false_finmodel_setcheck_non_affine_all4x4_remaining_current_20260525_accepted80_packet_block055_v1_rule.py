from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,1,2,4,4],[2,1,3,4,4],[0,1,2,3,4],[0,1,2,3,4],[2,0,2,3,4]],"priority":815,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block055.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block055","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrdWEtywyAMFQwLLTkCvQnTk3nR3rsOYL4ShgS8KItOE8UW+jzpSb9gESy48+P+WjD+g0RzCs0BEpT7zqL7oQLmGFYiDkaAQmlLCYJi4vgvTSvQXnK+sRIc3kB00uJZ5d5WSoMp7iXOBVHqztd5LYTz0iJIj9dj8jIlk55vP/+NpiQphMfg2102k4bH4LKgcc2hg0WyNtKbAkq2UXHXIWLjTTFXTPkYpXfVOrOgWHjyZJd64LD5u+OEgD10PM4fOsGN+Iw2tiBsOTLVlh6a1hxbKdKbweYVueIVS/Cuw1bYjWDzioSv2GZbLfvJFJlY7jfB4dCZIhW7zqbKom8wv/Z8s9fYUDotGBbzUPODFWBjKNGOtPFgo66xIW1MzuDKBjuSNnYWbNFr1TVaZkmkzVwl4Dub4ijsjQPe6mxENCkHzIVUVqy5xLwsIjPmgLc6GwG2ouNWaaNbd7fBxEpR+dNqJmhbe1cHMjSS81o9mpAOYHWIFmx6zmt6XIchgixphL7KCOu1XtoMdDbCa+2QxTigskPxdUd7SPlaWP60IUTlvSqwdZM0dTZuJiRGzrZGXwymGCYzVyAEofcLO5oShCjdq6/jGnvhMlpfAeBoZNnZUo2u0yYP6S3Y+EGd8BqVNtGO+GByRW6X6NJIymvtioDUEZp8ihdCsZtp+cBg2lA6siQtgtehkYNpQ+lICVQm5QtsUdG911oH9IFQBu+/g41ZR42lTR8IZfBuqcTaecr0GYXEpeoUP3om01dtUALYaPaPZ9hi0FZoDGAj2f+pSKiY6mqBNnZx6/J28Q7KYuQDLSFRq2dSlkb6fawtKYb4ECAsjTza11hD6MIpsHGb8B0bGbazEXx844Lk7THuHmxtYd/Cx9nOxk0xclyHYrKXyDXKk5apAOMLEnZixrFmgNNgM0NmEA6YqzRTq3+xBmwTq5tP9trHPGo+WGqHBcnpTTl6Pfm+Or8gASmGcj0hDYEHcKezOVQjQ7NkvdeSDgOhAOBsswnbyLZEUY59KXI8JbBYMbv8+QPfDJ/s'
_TARGET_BITS_PAYLOAD = 'eNrdWEtywyAMvXe78Mk63KQcgaUWDKgOYL4ShgS8KItOE8UW+jzpSV8oAAW68+3+CpT+gwF5CuWBBrX7ToD7oUbmSFZiD0YAVitBCYJi4vgvZStQXnK+sRIc3kBw0uJZ7d5WSoMp7iXOBVHqzu95LcDz0jZIj9dj5jIlk55vP/+NpiQphsfwx102k4bH8LKgcc2hgkWmNtKbgtq0UXHXIWLjTZFXTPkYpXfVOrOgCHzyZJd64LD5u+OEgD10PM4fOsGN8Iw2tiBsOSbVlh6a1hxRKVKbweYVueIVS/Cuw1bYjWDziqyv2HJbLfvOFMlY7jfB4VCZIh27zqbKom4wv/b8sNfYUDoFShbzWPODFWBjKNGOtPFgo66xIW1kzuDKBjuSNmIWbNFr1TVaZkmkzVwl4Dub5ijsjQPe6mxENCkHzIXUVKy5xLwpIjPmgLc6GwG2ouNWaaNad7fBhEpR+dNqJmhbe1cHMDSS81o9mpAOYHXYFmxqzmtqXIckgmxohL7KCOu1XtoMdDbCa+2QxTigskPzdUd5SPlaWP60IUTlvSqwdZM0dTZuJiRGzrZGXwymGCYzVwAGofcLO5oShCjdq6/jGnvxMlpdAeBoZNnZUo2u0yYP6S3Y+EGd8BqVNtGO+GByRW6X7dJIymvtioDUEZp8ihdgsZtp+cBg2lA6siQtgtehkYNpQ+lICVQm5QtsUdG911oH9IFQBu+/g41ZR42lTR8IZfBuqcTaeUr2GYWBpeo0P3om01dtUALYaPYPZ9hi0FZoDGAj2f+pyOqY6nqBNnZx6/J28Q5KQOQDLSHRq2dSlkb6fawoKYb9ECAsjTza1whJ6IIpsHGb8B0bGbazEXx844Lk7THuHmxtYd/Cx9nOxk0xZlyHZrKXyDXKk4KpAOMLEnZihrFmANNgk0NmEA6YqzRTq3+7BmwTq5tP9trHPGo+WGqHBcnpTTN6PfO+Or8gQWOHcj0hDZAHcKezOVQDQ7NMvdcyDgOhAMBsswnbyLZEUY59KXI8JbBYO7v8+QNtZdE7'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block055_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
