from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[0,2,0],[2,2,2]],"priority":816,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block056.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block056","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2UsOgjAQBuC/ceFSb4BH8ABGPZYLYzkaR+kRWLIwjOUREmWsY+KixP9bQEKBhnl0QR3sKmANytN1PMvK/EgxplVeBy5oHXADDqjd++fP2MbjHtihZAKIiIiIiIiIiIj+WivpUZHT7yarpEiORov9ly0+ORoVrDaDMllwZRfIDZvN3mz3+Fb/caJ5ffaRFnO4m36LQ0mP0tWhu/S8I1JPs7nsshaGL7JHTQmALHptW6TjkDyvdcY8x14r6VwXmmasNaVX5juN2m3hm4XmAVBXf/0='
_TARGET_BITS_PAYLOAD = 'eNrt2UsOgjAQBuAhLlhyBI7C0VrjwmOp8QAeQW6gSxemv+UREmWsY+KCxv9bQEKBhnl0QQPsGuAGWqbNeJa7+ZF2TKu8DmxRBGANHFGF98/vcInHE3CGYwKIiIiIiIiIiIj+WiHpUZH97yZrpE2ORtn+yxafHI1aVpuBSxac6wJ5ZbPZm20V3+o/TjSvzz7SYg532W9xKOlRurruLj3viFTTbGFxWauHL7JHTQmAZL22ZekwJM9rnTHPsddKeqkLTTnWmtIr851G7bb6m4XmAfwa8So='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block056_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
