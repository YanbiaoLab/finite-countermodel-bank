from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[2,2,2,3],[3,3,2,3],[2,2,2,3],[3,3,2,3]],"priority":817,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block057.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block057","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWUtuwyAQfSAWZEdzAhLlIKjqIseiUhZZ5sgdwHxsj61EqrpI50XBeADBfJGeFZ7BDcYF0E9D8Adw2voIUEtGVwYWDqmLmBrgkZoj/YPpLkqzI7UgVylolGW0zqXxC/1jmu1UXVI6/tsst6etjaWnTrt5iyvqfihzP6aJQVwlEAgEAoFAIBAIBAKBQPA/cBqIp0xaRWQOihNlakuZwmhlISrDVecYoA3nJZgG00tltFI3pI5tx8iUWJLfm+iQFiSm66tKYpvfqbBz7QS7VO020HC+nc+CE9GLzlQpr8fEyA2mGPVKO8dBI5VVrbg2ZRoHy1B6XY9G6nVTnJaqufJQa38eLktJNMelKJhoX4iRz+L0tYk4qzFhUznQwdxDABXD1hfqZtMZFPNWVXmrMWFTGc7B3D2A3FI1q8rxV+QrI+LCZj8RBr3cmydbidqwDp6gD0sRQ1w75V/4QvHOybZphmy1y+NXq3+wOYWZWKOI1BSRLR4tK5rm6xqbAbPBITBD9pfhY22Qdd807w7u3U1zOL2+2ZgSRblmSeWWxZ4VDXqX6qUwG+wJl0a2v9V0WT99q3ClxG2WKws+4cxWrJUNH1zGbKWS7abcmOFy4WNKFINeTVtheg2u+J0pUe1G8D3ZMH1RO2MWNfN89czg7GZjCjt3sqcMsJds5SRMiWqFOu7VaL/w/zx8VjfbVonCuiAzNZr2uMM9rdsPRWdh8Q=='
_TARGET_BITS_PAYLOAD = 'eNrtWUtuwyAQPXKWWUQqx8qiqjhIlHCClF1YIHgdwHxsj61EqrpI50XBeADBfJGeI57BCd5q0C9A8AewwRkFUEtGjx4OFqkLlRrgkJo7/bXvLkqzFbUgV0UElGW0zqbxC/1Vmm1jXVI65sMvt6etvaNnSLsZhzPqfihzv6eJWlwlEAgEAoFAIBAIBAKBQPA/cBuIp0xaKWQOihNlaiv6wmhlISrDVed4oA3nJZgG00tltFJXp45rx8iUWJIfm+iRFiSm67NKVJvfqbBr7Wi3VO000HCmnc+BE9FLyFQpr8fEyA2mGPVKO6tBo5hVrTg3ZRoHy1B6XY9G6nVT3Jaq2fKIa38+LkuJ8velSHvlXoiRr+L0tYk4qzFhUznQwdxDABXD1hfqZtN5FPNWVXmrMWFTGc7B3D2A7FI1F8vxV+QrI+LCZj8RBr3smydbiVq9Dh4dHksRQ1zbaF74QvHOybZphmy1y+FXq792OYWZWKOIDBSRLR4dK5rmhxqbGrPBITB19pfnY22Qdd807w7u3U1z2LC+2ZgSRbnmSOWWxYYVDXqX6hUxG+wJl0a2v9V0WT99q3ClxG2WKwc+4fxWrJUND1zGbKWS66bcmGFz4WNKFINeTVtheg22+J0pUe1GMD3ZMH1Ru2IWNfN8Nczg7GZjCjt3sqcMsJds5SRMiWqFWu3VaLPw/zx8VjfbVonCuiAzNZr2OMI+rdsPBxkPRQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block057_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
