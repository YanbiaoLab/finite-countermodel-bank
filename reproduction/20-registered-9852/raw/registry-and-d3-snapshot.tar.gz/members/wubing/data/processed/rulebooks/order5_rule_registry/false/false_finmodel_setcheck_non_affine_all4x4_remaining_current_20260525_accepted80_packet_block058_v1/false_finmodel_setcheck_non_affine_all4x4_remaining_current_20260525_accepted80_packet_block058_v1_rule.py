from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,0,1,0],[1,1,1,1],[2,2,2,0],[1,3,3,3]],"priority":818,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block058.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block058","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWL1O40AQHv/oYusQcSIKCnRYlpGoTldeBSuUIr6KR+ARuB4pS3ESdCjiAfIoru45/AgpKSJ8ZtfkBN5JbHnziYIpHNkT77ffeL+Z2f3jCKJ8QC92o665utKBugp9s0exuhFu9bMqHTJaUQ7NDipnjOOp9MyOvDxmXjljntOSmRbJ39wre5xjkXKDnYSM45QbSwScx91GpWhQqSMsXIaKP25Q0T/pbQNFg8SO/94RvJlZQOs/xO+iIt58MWUeQexJgc0wYKSpDTFghUZzMGgrBXaOAZOa2gCDttRooDXyrMCOMWCfYvsU20cTGwioFhsQLEepenNLtBuxzYBghbc8x6Hd0DNuScohMI58q7sT++sMjpYwsf0spPcNhXaITFrkSaC0r5DM6DGdT5PEBYltPhlnkwmI2mXF7P4uAKH9GmfpaATSt8iS+zRJQNROM+SKZDfqu7AFPfg4tANkHGUkyIGRi9wgljBuF8hACnWIhrIASW1bG7my2h0VmzeH0u5ubrVxOGG3pMvNm0MnHeH2bItbu6o/4137RD9yq18t55k9VGH+Pge1kX4kTae1/dpIdvUooKndysaehOuGz25Nf0w5nb00fFUhspnWJPtZpm5FOrCbriMWLUyjCs6u2Fgwfdxvt8TWYjNlecP3Kow66XBAwmf5sNUjuusstmtTOW9MQMSNR90CvaiV1aqeZ33Xp1/zaGNx3xZwfUDSasfdtxi8HpC0y4XjnoH8UmsuNCwSc45uhLdDG+n8T1Fb0ebC2Ih2biPD5gTdr41x3cCwxrqI7R+3XbrA'
_TARGET_BITS_PAYLOAD = 'eNrtWL1O40AQNkpBmUfwc1zlR8kDoIgOpCvYSPTHI/AIVOcUEVqorkRXIZ1lmRMFBUocxMkO8s9gdn0g8E5iy5tPFEzhyJ54v/3G+83M7vdSEnkrerFjdfXUle7VVeqbR4rUjSyqn4FTktFcZ2l2kDNhHLtObnZ4zg3zyiXznIbMtEj84F555ByjgBvsT8I4rrmxZMp5ik1U3AaVOsKyYKhk8wYV/RMcNVA0SFRmHx3pu5ml9PqH6ENU5LsvpiwniO0qsAkGjDS1JQbM1WglBm2gwC4wYEJTW2HQhhoNtEZ2FNgNBuxLbF9i+2xiAwHVYgOCeShVr2+JtiO2CRDMzYcXOLRj2sEtSbEExpFvdbdi38rV7RAmtl+uyP+i0O6QSYtyAZT2KZIZ7QXjaRgWILGNZ3N/NgNRO6uYHRymILSfcz9YLED6ln54EIQhiNq1j1yR7EZ9Gzai/QyHdo+Mo4gllTBycZFGAsbtHBlIqQ7RUJYiqW1qIwdWuyN3/eZQ2N3NDdYOJ+2WdLF+c1gGC9yebXRkV/WXvOuB6Mqz+tU8ntl+FebfY1AbmcXCdFrbr41kV48CmtqtbOxJuG747Nb0vYDT2UvDVxUim2lNsJ9lWlSkU7vpOmbRkiCu4OyKjQXTx/12S2wtNlOWN3wv16iTDgckfJZPWj2iw85iOzGV88YEZNR41C3Qo1pZreq533d9ZjWPNhb1bQFfD0ha7bj7FoP/ByTtcuG8ZyCfas0lhkViztGN8HZoI8u3FLURbSyNjWjnNjJpTrD41xi3SA1rrIvYngGVFLZn'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block058_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
