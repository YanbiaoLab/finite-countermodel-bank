from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,0,3,3],[1,2,2,1],[2,1,1,2],[0,3,0,0]],"priority":819,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block059.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block059","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWT1u2zAUfpTkmjaKhjI8Gq1CsECP4KlhAw5WpsAn6BHarUOBMkUHZ1OFHiBH0dRz+AgeMwRhSSp2EotxrUIE3ICfYVEQAT7x/fF7Twh4BI9QcTuM0YNnL4HAoeA9wMQ5sUKQUdeE/AwRAdRGyBU7Hrhn3g5Q1pU2ymgoEubeikVjo/KoHt0bbYncSrniYtsFMER7LaA1Ub8VtNNuQEBAQMDzwUr117fLb96l3arN7c2Rb2GVerM5f+NP8MWvtGsVr2+LH0wIv9LUva3oXGZ+hS3j1YkZp5sLrPxJ+wq31iVTzU245Sc4CnH6D/iN+hNtJ5RkwAFhMIOmfH6UWU2XMn6tZSAC2PDs5O4f0A4fM1lpryc6ziptNKNCAt4C4BcrZ5R+Z+Vi4X9rshSjXIhCjNLUv7RzvbPLBS7rmmldf/nS5NkoZ2n6QUdbHWy6soq08fxkZp7TS0YpBiQBGw/JbDEXcNgYIzbQhmI6vGenNqax/gW0xlwMTRSgHgNh3d9nG4PPM9rD0TuSFs9OkWon5b9ntN3QSLWL8nddfdyoXU4xkXHV4e6kOtk1y9hxlwfPg5rNAfIzSkJb7wARo+SVO8Ms9aVft6d5OBH+GmzUHqEOzEYm2BJDumRXhKig8ydmeuMCiCGy8j+tc6r+k52YqSNBu5Zo0cS5vsuUDtOlzWc9h92z4PsGzOqGiyHZ8jt+sZCh5N4fL+oz+aJBBGwFvh0QyJFQ8P4f0Hi6SVHb9mx+sswxb66QHGw/5Q8mVV+A'
_TARGET_BITS_PAYLOAD = 'eNrtWT1u2zAUZpAho4/gc3TSUXKAQtUWD0XDAh26tUfoCYxOlQeiZTr5CAVCMErh0bCYorDpWhJfSSp2UotxrEIEnICfYVEQAT7x/fF7TwpoBf8gonaYqnvPfoOAQ8F3gIlzoqcg464J/AEqAaqNkFN2tXDPXC5U1pU24mpOCubeikVjo/imHt0bbYnUSjmlZNsFJFR7LaA1Ub8VtNNuQEBAQMDzQQ8t17f9t96lHaHN7fGNb2ERut6cv+VHeO9X2gkq17fJa0aIX2nozlZ8iDO/wvpl78KM480Fev6kvYMj65K55ibU8hNZhTj9D7xQy4m2kyoyoKAkmEFTPj/KjMZ9XP7UMpQAaXh2cfsPaIdPGY601wsdZ5E2mlGhAG8B8JLFI87fsHgw8L81HJNZSkhCZnnuX9pnvbOzgYzrmmldf/nS5JdZyvL8m462Oth0ZVVp4/nJzDTlZ4xzCQqDNB6S2WIu4LAxVWyhDcV0eI++2piW+hfQGkMyN1GgVgyIdX+fbQw6zPhKVj9Enjw7RaKdlP+O0XZDI9Euyt919XGMdjnFBJdRh7vD6GLXLGNXXR4892o2B8SrqghtvQNEqYpf7gzT15dl3Z6m4UR4NNi4PUIdGM1MsBWGdOGuCFHChw/MrKYJCENk8ROtc6Llg52YsSNBu5Zo0cQ5uc2UDtPlzWcrh92z4PsGzOqGkrnY8jt6PsCh5N4ff+oz+bxBBGwFvh0QypFQ5P4f0Gi+SVHb9mx+skwlba5QHGw/5S8mKxG2'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block059_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
