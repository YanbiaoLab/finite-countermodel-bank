from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin6_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin6_explicit","model_table":[[0,1,1,3,4,5],[5,1,2,4,5,5],[3,1,2,5,5,0],[0,1,1,3,4,5],[5,2,1,3,4,5],[0,2,1,3,4,5]],"priority":820,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block060.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block060","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WEuO5CAMNYgFS47A3AT1yRip594TwIAJNvlUUixaXSHB+Pn37H8QLATI6zf/DeDLD223H9ZH0GDAu/Qjv2hAWF7cUVHYsMo4dgMFM6s89POGKzvzibEoaPPusGPyacyuNy49zRBsJ6bTUeSfmJ5uuwp3iSpZVtmFfvmK4fa07G4npX8BfvJlyW46NOFbNcjn0CtHhxppt0OnqAKmKVTthKowtimq+PpunGCriiG+E+qGGiXAN5dV35Qm+u8bCw32pZXi3H9LGMJovyNNTAivLJ2zh19myMdW2IWteznYEoQ5H+fElwS/Z0Mxw74UbNl4NuVk9bZr/lZBG36+pfuXZEZHBJlWdV5KnO4g5p9dP+I1wvMKBvBizFP28GSwsdfI1kSaYp4MNu4aL7iNpwxuLLAvuM1vR213jZlZfuw2cmUzEoU9AOBWZWOsyQFwzaRiZXOzMo1G+1UmcHcqGxNss6CLbmNZ5iv0BAIAV2mkG5SRUBMA6JeDGYqdkd0RamZAzZ2X4dnKBlhCfSwnGQw2AGS0qhyPpX30wtpfqfahbM2xsg2olSZrQK1VXOy8yOVGduGkYLM12IoyJNiqMv04CkALNg5KDfMNlj3hDjUNLABVDxpsXso7cmvKECLVrMkFtJeddE8j6a4VKhvnNkJSVXxypTRy9Oe5snFuA8VjIDQZq2CjNHJ81bgp2OYRQTfpyWCbUOuVbcxo3KSiBcIgI/LlSqaRstuYQQZyXPIhbpdPoGxiEtJdUGxG8B01RS0z8WheRp+qoNJ1xHIj2NyRjAYF1UufCbYBNQYATgZx0qZXqMEWzqLGTaAYGcRJB+MdUokwkR37AX/162+1DQOPBfXRfMPwY8iRH1QJf3uiusUno0hEt+c2K9O7749bAAw2lv1vgpRprm44inB5QCIMbrMmfq6+zkqt5vEVgm18YGb/Jh66KMjZd00jd2rM81hK9K4xukMaGXvtqRqGXntCk7UuMpabRjKTcA3Pr2FAQu/H8PFHBiTAsqjbbdxxsM2JfcnH4ZaHLCrb2F3BqiGRPMQIsRM8G8KBeVvvr27ON244+ld8Qt5ltFQMLJu3L/VsXuoQzRDFc7Bd60ePRv/m/shADDZRUKRNEeM2twYkGS13zgAfDLVxQLKhqcNhHCMpd6eGV/KApDj1mBvDamhI/PACQwnFw61As/R+rtUIUWs5wxqKqWcLXIrisl8SlHkKslh1laP8B2luleU='
_TARGET_BITS_PAYLOAD = 'eNq9WEuO5CAMvfe0NJysxU2GI7BkgcATwIAJNvlUUixaXSHB+Pn37D+gHWjI6yf/1WDKj+C2H84oCODB2PQjv+hBWEbciUrYcNFbdgMFM6s8NPOGLTvziaoo6PLusOPzacyu8TY9zRBsJ6bTUeQ/lZ5uuxF3iSpZVtmFfvmK4fa07G4npX8BfvNlyW46NOFbNcjn0CsrixoFu0OnqAK+KVTthKowtimqmPqummCriiG+E+qeGkXDN5eL35Qm+u8bCw32pZXi3HxLGMLoviNNTAivrJCzh1lmyMeW3oWtfTnYEoQ5H+fElwS/Z0Mxw74UbNl4LuXk+LZr/lRBG36mpfuXZCpLBPlWdV5KnPYg5p9dv+I19PMKajBizFP28GSwsdfI1kSa4p8MNu4aL7iNoQxuLLAvuM1PR213jZlZfuw2cmXzEoU9AOBWZWOsyQFwzaRiZbOzMo1Gm1UmsHcqGxNss6CLbuNY5iv0BAIAV2mkHZSRUBMA6JeDGYqdke0Ran5AzZ6XYdjKBlhCjSoneQw2AGS0sRyPpX30wtpfxfahbM2xsg2olSZrQK1VXOy8yOVGdmGlYHM12IoyJNiqMv04CkALNg7KAPMNlj3hDrUALABVDxpsRso7cmvKEKLYrMkFtJGddE8j6a4TKhvnNkJSjXxypTRy9Oe5snFuA8VjQDcZq2CjNHJ81dsp2OYRQTfpyWCbUOuVbcxo3KSiBcIgQ/HlSqaRstv4QQZyXPIhbpdPoGxiEgpdkGpGMB21SC0z8WheRp+qoNJ1xHIj2OyRjAYF1SucCbYBNQYATgZx0qaXrsGmz6LGTaAYGcRJB+MdUgk9kR33AX8162+D0wOPhfjRfMPzY8iRH1QJf3uiusUnlUhEt+cuK9O7749bAAw2lv1vgqJvru45inB5QCIMbrMmZq6+1kmt5vEVtGt8YGb/Xh26KMjZd00jd2rM81hK9K4xukMaqXrtqRrqXnt0k7UuMo6bRjKT8ADPr2FAQu/H8PFHBiTAsqjbbdxxsM2JfcnH4ZaHLCrb2F3BqiGRPMQLsaMNG8KaeTvsr+7PN244+o98Qt5ltFQMHJu3L/VsRuoQ/RDFc7Bd60ePRv/+/shADDZRkKJNEeM2twYkGS17zgAfDLVxQLKhGfRhHCMpt6eGV/KApDj1mBv1amhI/PACQ9HFw51As8J+rtUIUWs59RqKqWfTXIrisl8SlHkKsth4laP8B+MD20I='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block060_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
