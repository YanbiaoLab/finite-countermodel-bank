from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,2,0,0],[1,1,1,0],[2,3,2,2],[2,3,3,3]],"priority":821,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block061.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block061","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWL9r20AY/fSj9YWaWjaGdgipMCp4Kh07JUdxIOrUv6DJn5AM3gy+DoV2KyHQ1f+B906aunTqlFVLdtHJg4ninJRA8X22hE9v6jfI1n3SPb3j3nfv7osjiZIW3cdEXxN9pb6+yuKmTaG+0bfL3CFjpHnHnKB8yiQWuWdOJNdPmFcOmXbKmM8idcG90uYSs4jr7PUekxhyfUnBZdxtVNI1Kh3u1ZKKv5aYFT8GQkVLuA4v/ulekP/wNyQ+klyHR5BYaLApBowKah0MWFqgORi0pQY7woCpgloLg5YVaKA5cqvBXmHAkvz0R35zTP/FtrPY5r/zvwNCiW385/iTDxLb/Jn/k1CRoVRdig0IlqBUvdkSNRKnL4BgqZcd4dAmdIubkqoDHEfe6jYSv5zWfgYT27tUeQcotJfIokWeAkr7DMmMrqLLk8HABYntctSLRyMQtY8rZt++ChDah14cdbsgfcvY/RyFqDkyjJEzkt2oNxEz+u7j0PrIcVSBJAdGLnBFqGDc3iMHUlIIRBNIarRlc7i06o7SzZtDZffoZLm5O7tLutpyEhNZpZaNN3dnV/WHfOo50VvLNpI3dqvyot6gbKQfqMdTdGs2kmUm7SubPwlvwvBdRVzxbMDwKfbrTxowsgHbp+MH1tFYsCbWoFJspipvWIbSHUvNgq/yoto6KGqL7dy0nK83haZiU8tGFsqq9PDObtrneDQxbR4PSCA77ocDEokAo6el5pwqk8QozRrDKx22RMlKTbUGpZSKQWuuqNJUz0LcAY+bpPU='
_TARGET_BITS_PAYLOAD = 'eNrtWL9r20AYVfDgqWjvorVTpy6ZNHXPf+A1YEy2Fjr0At48NH9C07+gUxSwKWdPHUunQIVRSocEjCOHlJ5b/fjqnpRA8H22hE9v6jfI1n3SPb3j3nfv7k0uifwl/Yu+vvr6SjN9lcXNHUX6Rt+2nJyM4TkLc4KcYybRdlJzwn/2h3llwrSTy3wWiXfcK3dcohNynX37xSQuuL6k4jLZNireGpUF92pJJVlLdIofA6GiJVqHV4+6V5Tc/42ID9/RkRIk2hrsGANGBbUFBswr0HIMWkuDjTFgoqC2xKC5BRpojuxpsEsMmO+cHjpPh/RfbDuL7eCF82RKKLENng8/JCCxHfxMXhIqXJSqS7EBwXyUqjdbokbi9BoI5qXuGIfWpz3clBQL4DjyVreR2M+XP1yY2D57Iv2OQrtCFi1KBVDa75HMqBv2zqfTDCS23mgejEYgah9XzF69ViC0s3kQ3tyA9C2D7G0YoebIRYCckexGvYno0FGCQ5shx1HEknIYuThTkYBx+4QcSEkREE0hqdGWzWHLqjvyNm8Ohd2jk9bm7uwu6WLLSUxolZo72NydXdVP+NQt0RfLNpI3dqvyIr6ibGQSi4dTdGs2kmUm7SubPwlvwvB1Q654NmD4BPv15w0Y2ZjtM09i62gsWBNrUCk2U5U3LEPejqWmzVd5VW0dVLXFdmJaztebIlOxqWUjC2VVenhnN51wPJqYNg8HJJAd9/0BiUSA0e9Sc3mVSWKUZo3hlTlbomSlplqDUkrFoLVMVWmqZyH+ArzWzDI='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block061_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
