from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[1,1,0],[2,2,1]],"priority":822,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block062.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block062","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNprZGGAA5lYBmKACQPDDB4GkkA8A8s/diYsEhmeHkYzOzgwJQ7UO03//9SVgRqgAehHQUaGIQQuQGkfNqK1qEBpSXSPKiiAKZYJDA7EmqUAYwgQq5CB3sFr8R/O/NCv9y2fYRQMAdDwvz4ORD8wYmD4DwTyDAdOaNPMtg//2yFJH2ghyDZm5AQ7tMGB///rGXkYFD7YizSAvMbP+uC/vQDDAVplNpWJLi4sniqCgh9Bmc3FpaNDQFCxRYCJFrapdqtM6uhQ6FRRUlKb6HKkpYNDUFBJqUXAiRaWPfg/P1xIUFBlp4/LEVBAigsafvJyAVrGQQvb5tTPq3ik3KS360T3D3fx3+aflJ64nugWiOdgpElm+//fv8blwtP6SkGQ1+LjjvwHMh9xK44WRKNg+AOk5myFk/gi9dEQGQrAoUtDCdz0FGRo6FDiUmRhUGgRGA2WUTAKRsEoGAWjYKSDB3+Y8cnKx765PxpIIxwcuMiKT1b4v4At42goDTowhUHAgwnbqJKDECMLg4dSJwdoqJnJxWXYjOSNAlKBxS4whW2ADiNLP+CM7ZiHoaxhNBBHwSggBkBzGYcIhgwLF07VZAMA3nV75g=='
_TARGET_BITS_PAYLOAD = 'eNrtmL9Lw0AUx08UxEE7uCkS/wIdO3TIVP8LQRFUEH8MtRGKJiDo6uZaOzkKohWPUnFREAVB8EdMUxCkoL0Tao0am2dSq4itEsWI1fdZ3sG75Mv7cu843pQJL5zFwA07AAM5+BRRMGtuCxUS86vx3X7JKE+ISmKQtKzDdyDbNTILqojOUly+c/2JWornbwvV9WIwRyHp9l/684K73Qg/be8WeVn6xvYb5gCpAmSiLDhR2AUgNmkQ/QeeqfnIxNPRtwUdtYfXB7a6EQlRrBzovo0L2Snt6l4gGxxEr5pNHaHUXFUZa3KajVJJ4iwV4QUv1E5C6rAk6WFV045HaCAiGYxpWoQnvBATSM9iljG1a5kGHCMzbK9xhdpihhdqfUrvbNvp5H7QH6pfy9RtN2qt6/4QjxqWJ81GyNI07WxRZphTWnQhQOxl23UKLyLk7/PqOTubyHQfoSPVQHL8UCs+PRnIkpZPmaBHONqCIAiCIP8dofbho2w61tyOJv1zxI77j7KXhG9a6NKvYwh4vFBpqpTMWibEtbDhjJoLlP6ZSR7yWbaCxVBpQFfW0sJNTOot2yajiQjihlKXGRdlGTP/7u4v8wht/PVB'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block062_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
