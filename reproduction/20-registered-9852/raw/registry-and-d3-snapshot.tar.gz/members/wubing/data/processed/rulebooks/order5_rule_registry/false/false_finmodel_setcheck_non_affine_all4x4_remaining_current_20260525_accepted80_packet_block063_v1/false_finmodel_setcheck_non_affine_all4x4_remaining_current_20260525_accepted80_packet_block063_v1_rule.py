from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin6_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin6_explicit","model_table":[[1,1,5,1,5,1],[2,4,4,2,4,4],[3,0,3,3,3,0],[5,5,1,5,1,5],[0,3,0,0,0,3],[4,2,2,4,2,2]],"priority":823,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block063.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block063","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2T8KgzAYBfAXDa0FQdO5UIcUPIZDh3qbjt3q1tUj9CgepUdw7FBIA0IXQ5Bi7b/3GyQayQdP8kFQYIgYvylejbdWDtRypLVa8dZYIgT2OgMkUhARERGRS5UAJmQO5BGewj0OzIH+Ul4+hvV2qdRrq20WpVZqooP0uTv7a1uu0naQKsHv/Yw0iLIKiDIICJmhgL0TkEzmo5njhMUuJmHiY2jN3DtrsY0RkVfTtZGboy1f171HrtfYaIgGKbqdsgv6U47/j/qr9tUdJBgctg=='
_TARGET_BITS_PAYLOAD = 'eNrt2T8KgzAYBfBAh44eoUfpUXoE125269jb2KGDxxCawULnRkGolWheA0IXQ5Bi7b/3GyQayQdP8kHQYIgSv6k8j7dWCoR6pLUC89ZYKrT2WgMaOYiIiIjIJSoA0TAH8mjWzQ5b5kB/KY0fw/BwUeq11Y7XWCo10UF61Z39pS0XSTvIleH3fkbeVlkEVBkMjM6QwN4ZaCbz0cRmwmILUTDxMQTi5p212MaIyGvZtZGZoy3PT71HrtfYaIgGSbqdsm/7U47/j/Kr9tUdKGhUgA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block063_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
