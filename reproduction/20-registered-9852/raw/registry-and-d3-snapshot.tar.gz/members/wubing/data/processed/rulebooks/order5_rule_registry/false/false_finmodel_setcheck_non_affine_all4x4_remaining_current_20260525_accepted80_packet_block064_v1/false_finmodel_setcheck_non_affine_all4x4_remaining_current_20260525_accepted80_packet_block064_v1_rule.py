from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,2,3,2,2],[2,1,4,2,4],[0,1,2,3,4],[4,1,2,3,4],[0,3,2,3,4]],"priority":824,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block064.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block064","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WElyAyEMFBQHjjyB/ITKyzg4/w7DvkgDY4M5OGWIEZK6tf2BkWDAr5f/NKCvPwK4dF+ktsDdl2vPSBNOiKXJE2aJAwlCoQdRMLLCph4PVDhhw402ybpOmxPhbzPjqQ673gRpN4j88bepa5dL7U5to4p/tPK/dbfLShWhrv91NypIP/v1j61Or0sv+yYNTK+jVVEj3isZVAEx2EyH5yC++fHP0cmnpI9YdVcns3KKgW8uyb4pjcTviRUd9qX18jD+0qqZeH6RAeHIquKSOC7MdLQ9q6H0AkpoO+tDMsIeJFsO9CE8nyWbE+RSg87h/pApraoEiZx1DgVONeH83vVLPsPsV9CQiGirh11ko0oif6pjmSK2kY2jjz8BG5pY7ABsXuQzxsryY9jQmU1QqWJigLcyG+JNHwR6PzxyKaeUUaMyckkZtZTZ5mRjQ8a1KzK652IpFGG1JgzQ2shMy0jVKNNaTTeWtlMZkgaQ7gRNrabWZeg7lGNWUx3ZgIg6S8HCPdcQkCwtWP59k9rfQaWqQG07slW9XiJbjtG8kC29VN4HAeh6whbPTUHkr0ditEgVTN1M6iJS9l02hbVcp+TN6l0yw4YlGxUZogCIoWUk9GVkyWzZoZdmBTa8J0Ilo0c+n5WR0WqNZ+revMjwupdQmVr3aOgaL3QZ6QVZSJ4BfETQyQDI3oPozNp5cTYz1gO6cCBbrbyryCiE5oVstqMTm5WRyESjgU2yVVQTB2nUSydg8CLIZifomNmCN4tnhjp6QoTeefQA5hOymVEvfjsHwqyGGACTkU1R6RWAwYqgqdWwCRQiI5tiACWbVdBbe7b72pfLreIEFalr1Xe1jBaoQtRU9cGuljGSDa3+nTgmMtR3dBucTusCdjfdRubAPlb/YndPSpaRYR5rprX+I8SSZaQ1Kxc/Y4cmJ+H8zIAE+hDV1eP72ntbl2siJ49P2rg52cbATjW/atpXsLsBCZHZ2oIP7hoSquYXBKIMyYw5/h4EmDj6Z0vS0GQgH5NNL6lh9IdjjEejf7aBbMujfwQ2bw1InrDmg6F2HJA4a/LV5/H3xfHgC86WsF6YJleaXWRAYgkMm8G8qmr921i6TDafQseRAWbYi2wupOYqlj0dU/4DKMqIIg=='
_TARGET_BITS_PAYLOAD = 'eNq9WElyAyEM/Hd84GUpfhKewJEDBQrDvkgDY4M5OGWIEZK6tf0AV8DBr5f/5CCuPxqMcl+UYGDcl2uPKx5OiCXIE8uIAwVaogdRMLLCphgPZDixw40sybpOmxPtb+PjqQi73gRpN4j887fJa9co4U5Zo4p/tPS/dberShUtr/91N0pIP/v1j61Or0sv+yYNeK8jk1Ej0ysZVAE92EyE5yC++fPPEcmnpI9sdVcns3IKh28uZb8pjcTviRUd9qX18jD+0qqZeH6RAeHIquKSPi6Md7Q9q6HyAkpoO+tDMsIeJFsO9CE8nyWbE+RSg8jh/pApmawE6Zx1DgVOOeH83vVLPoPvV5CTiGirh11ko0oifypimaK3kc2gjz8BG5pY9gBsXuQzxsryY9jQmU1TqWJigLcyG+JNHwR6PzxyqaGUkaMyakkZuZTZ5mSzQ8ZlKzK652IpFGG1IAzQ2ohPy0jZKNNaTTSWZlMZigaQ6ARNrSbXZYg7lGNWkx3ZgIg6S8HCPZcTkCwtWP59k9rfQaWsQM06slW9XiJbjtGmkC29VN0HAeh6whbPTUHkr0ditE4VTN1MiiJS9V02hbVcp+TN6l0qw8YmGxUZugDIomUk9GVkyWzZoZdmBTamJ0Ilo0e+mZWR0WqNZ+revMjwupdQmVr3aOgaL3QZ6QUxSJ4BfETQyQDI3oPozNp5cTYz1gOicCBbrbyryCiENoVsrKOTnZWRyESjgU2yVVQTB2nUSyRgmCKIZSeImNmCN4tnhjp6QoTeefQA5hOy8VEvczsHwqyGGACTkU1R6RWAYYugqdWwCRQiI5tiAKWdVdBbe7b72teoreI0Falr1Xe1jAyoQpRX9cGuljGSDa3+nTirM9R3dBuGTusadjfdXOXAPlb/endPSpaRYR7Lp7X+I8SSZSTjKxc/Y4cgJ+HmzIAE+hDV1eP72ntWl2s6J49P2rg52cbATjW/ctpX2LsBCZHZ2oIP7hoSqubXBKI4yYw5/h4EmDj6t0vS0GSgHpNNLKnBxYdjjEejf7uBbMujfwQ2bw1InrDmg6F2HJA4a5rV55n3xZngC2OXsF6YplaaXWRAwggM88G8smr921i6TDafQseRAWbYi2wupOYq1j4dU/4DI7bpBQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block064_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
