from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,1,3,4,4],[2,1,2,4,4],[0,1,2,4,4],[0,1,2,3,4],[2,1,2,3,4]],"priority":825,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block065.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block065","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrdWDty7SAMBYZCJUvg7YRJlWVRJPsORpiPkWy4F27xKDJJZDjoc4SkX+FAOBHXT/zphMU/FNggtF4ooeP/HMQPtWCWZSXSMwKQ2jhKkICJhf+0vcCgJJx4EXhUEKK02avjaa00HR+vhVKJUtz2L1wLDqlEA4XTj19PVSppOD38mlUpUpG2ia942UqatolTg8403iSN1FVJVEVo1XslXofwDapiT5/yPipnXTErpzjxyVVd6gOLjd8dKznsQwt5/qGVzAifQWMTwpalSm65Y9Oa5S5AezUEcZgQgc60uM+HbIbdSDYEkpix7bZc9lMB2ZzuN5nSmwpI51dnU2YxD5xfu77Ya2xInU5YlvN19bDqZeNKoh1hg2SjrrEhbGxdwbUP7EjYuFmyZatdrtFXlkTYzGUC/mXTXAn7YICXXjbCm5QB5lxaVdz6ifPQK6MnksXdy0aQTXb38gSG4gMILkDtp9eeoHvabzGAKSNNo4xgWxPSACyG7Mlm5qxmxjEsE+UIZAnOd95v4xToZOE5shWgI7gLTSmrQe7hTKWHbjH0uacnsqmAfPwUqk/bggiB4ufYybUY9UZVXVMWX/A9IdFy9jn6rGCaZvLsN1W8JQoxMNjWlCiIyr3uMc62N+tlcgQyZWTlzdoz5XN1JYKuglS2/lJPZSRlNcIARY+8sZii1kvelpGU1foRAYmRHvniLxDNbKavBwbDhsIoAdQ676aMHAwbCqMEUBuU4WUrQM9W6w1wT4TWef832dhx1FjY3BOhdd5jKbG2n+LnjCnhL4XTfOtZVF81QUlko6t/OHLk6bQViIlsZPUfgKTOoa6XDEhYS+l1FszzYzy4b6WCxnp1T8qWkTiPdW0dLN8kCFtG+v4YZ98kIz8J3zGRYV82xzQXewYkL7dxz2TrE/uWepx92bguRo1jaCaivgmtvwdjfSLBpNG/5BLy82MA02SzQ2oQZJvLNFOjf7mGbBOjm3fm2n6eNW8MtdOAJFhTjV5PvQ6Ho3+h5FCsF6bBXZfMv2yR1TBUZkUDHBxICQBmH4A0jexTVFHDNGSLdUqqYqWYLBz+AOrqn94='
_TARGET_BITS_PAYLOAD = 'eNrdWDty7SAM3fdLwbJSZdjJYwmUKhggGGE+RrLhXrhFKDJJZDjoc4Skf16Clz6ur/hTeoV/WFBBqIS33sT/SYgfGs8sxUqcYATgjJaUIAETC/+peoFGSTjxIhCoIERps9fE01ppOj5eC6UOpbjtf7gWHFKHBgqnH7+eqlTScHr4NatSpD5t8z/xspU0bfOnBp1phE4a2auSqIo3tvdKvA7hG1RFnT7lfVTOumJWTpH+k6u61AcWG787VnLYhxby/EMrmRE+g8YmhC3Lltxyx6Y1S16A9moI/jAhAp1pcZ8P2Qy7kWwI5DBjq2257KsCUjndbzKl0BWQya/OpsyiHzi/dv2w19iQOqVXLOfr6mHVy8aVRDvCBslGXWND2Ki6gmsf2JGwkbNky1a7XKOvLImwmcsE/MtmuBL2wQAvvWyENykDzLm0qrjNE+ehV8ZMJIu7l40gm+vuJQgMywcQXIDaT689Qfe032IAU0bqRhnPtiakAVgM15NNz1lNj2MoJsoRSBGc77zfxinQyUJwZCtAR3AXmlJWg9zD6UoP02KYc09PZF0BifgpVJ+2BRECxc+xk2sx6o22uqYrvuB7QqLl7HP0WcE0zeTZb9p4SxRiYLCtKVEQlXvdY5xtb9ZL5whkysjKm7Vnyuf2SgRTBalr/WWfykjKaoQBih55YzFFrZe7LSMpq/UjAhIjPfLFX+Cb2UxfDwyGDYVRAqh13k0ZORg2FEYJoDYow8tWgJ6t1hvgngit8/422dhx1FjY3BOhdd5jKbG2n+LnjCnhL4UzfOtZVF81QUlko6t/OHLk6bQViIlsZPUfgJzJoW6WDEhYS5l1FszzYzy4b6WCxmZ1T8qWkTiPlW0d7N4kCFtGiv4Yqd4kIz8J3zGRYV82yTQXewYkL7dxz2TrE/uWepx92bguxo5jGCaivgmtvwdjfSLBpNG/4xLy82MA02RTQ2oQZJvLNFOjf7eGbBOjm3fm2mKeNW8MtdOAJFjTjl7Pvg6Ho39v3VCsF6bBXZfMv2yR1TBUZkUDHBxICQBmH4A0jexTVFFDN2SLdUqqYp2fLBx+AWGH0Uk='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block065_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
