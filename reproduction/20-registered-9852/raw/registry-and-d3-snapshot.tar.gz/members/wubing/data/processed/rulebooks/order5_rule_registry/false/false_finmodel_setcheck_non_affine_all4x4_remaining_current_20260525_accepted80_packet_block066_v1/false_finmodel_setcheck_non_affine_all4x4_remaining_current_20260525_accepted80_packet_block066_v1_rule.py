from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,3,4,3,4],[3,1,2,3,4],[4,1,2,1,4],[0,1,1,3,1],[0,1,2,1,4]],"priority":826,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block066.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block066","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WUFy6yAMBYaFs8M+Ac34z/QYTMYLp6seyfmTP5Pu0kwP0KN+EDKGIJo4satFWhsbISE9PeR/zGyYYSBf8GsqDRdtU9mLjR6YYJK1yl3Ag5IV5Ls48jIUBl73bmJCUDEhgnH7q/OBd9FvrZ69vJ5xUIZxycAunowcQQVYVbF49Lv97Jq6bno7KpJ3/ny0l9PpbGdkomKj64Ipg7Qznt1dIXDS0Yd2FYN7R9nFu38Ze4PF6o8w6iZ1/kULcvVDA3/OplFX3vGmgHplkl1pPw29a39gObjBjMV7VMnp+pWDGW5RqdcHmNM4lSL2xG/IK/9NbcX4XUNww35JvmwM6N9SNkS5tr4UAWEV2VmMUS6bfkDIxQRBOqTtuhZaaPvsuqNsENrWlSLCrphsUOsc0lYVWVsWTTasRgHuV0qHoTGNVQQ5AKHJsMSsIhiBnMj5FeQNfqFypnLuljdwTDZfouNk87u5LKIhj8AciHlEs++6HkgMXwxjPAcAr3ljMCpXCRvtXZdyrhA2euGw+WIXZ1HIgbrGZIOwaWuzZNiUK5ukKGwm87SXqW4rrpcADrjah+1uzpaGypbRVIjPRCFBsmcnW4Eth2KwYNhUHBVdl1BXfa52kyjtimX1ydykkWkOsOTwoZOwuUabXEdVDiDtg4OAKJ/VsTHpum7ryCvkV3vpt9sdQNT241TV9XbbddXLUR+slvacYLQRvuI+nGyXLijat3X9st11x5NVploLmYNsBmcMmtL4ivs4Rr9fJkUfrTPrdFK1VfY3EKLJa45D9DoFvXmVrQmKgHR5Vx7VDglRjNE+2eQ12iiyMpPJtt8GRa7gKO9KtavAa86YU3h4I0MOoCuHatKhy0F6k0Yascm8BmGTLF1ZJSadFS75TBrZA/OS8c60OQgI4cxU+CIfE0HTyZbRyNRrB+e18VxPtQjCpKewhFDkqWQDRYEP1Fzgo7Cbjj4MPkJQETxuYju81ON2aT1Cpww7yAONnPhqwgdIjB7pLd6MOG70Ig77V5gf9PqjyoaNifCoU2TCdLAzGY+mdUxdFfTBuBVv3qK8AUMQIsoBlI7gitgu4ftAI/GAMm2TDR8NPGXyGuUASkcUpMEu4xskk6LUa03uNaIDFRYX6QiuYOnm/VDxPdb38a1ec58WD5/Ziu82vRBG7GOQ2LScP3WgO9JtyIBafIIFTHT1VGUTtC/Ba6402D+dd/rTR4B3AXFAyKZVXB9abVXBpssx0Wn2epcUG7cE1gfUephGbgiW77H+LOWQ8/Gn2gxFGkn0Yz0X0fezxvtpJHrNooOcwiZQhPG5btaxo9wJF2x5QRopsnY9FhW2ZP8Ckw1cBGU6FMECH799jLudbDwDduIWeSDJbec/NUgKnxaIdn/pQFLi/JkrTBHYVY84GWN0FkkuYO8/uGHrnwL2yvUtDglG22KQwUg1O9kIYPd53KYYnfHxeefR8rcawvNPJ4LvRpLA7gMlOkyQX4nmNUhKZz95o6X4WGWb+MCtBom/776o3Whe/dQgGc9+KbAj80rx3VcEkcThDIZiz2wHOoYROuMmNuSfOydMZF+Hxci7ks3BB9EyIGikDSTDjN4EFju7TfkfprQCOQ=='
_TARGET_BITS_PAYLOAD = 'eNq9WUFy6yAMPWoP0Emza2Z+5sdH6qrxwpPhGJ35npQT2OziBQN8EDKGIJo4satFWhsbISE9PeQ/hl0MMyCv8MsGDhdtN9iLC6+MMtK0wl3Ag9IU5KU48l0VBr6ObmJCUDEhymj7y/OBD1WfrZ6jvJ6xEsxoacAunYzsQQVYNZh49KV9a7q+72o7qpJ3/r23m91ua2c0ajCj64IplbQzbt1dpXDS0Yd2FZV7R9jFu3+N+YTF8vcw6iZ1/kULcvVVB3+2rBNX3vGmgHrBkl1p3xi9a/9gObjBxsR7NMjp+kuDGW5RqdcrmJM5lSr2xG/Il/5NbcX4XUNww35JXm0M8N9SVkW5tr4UAWEVOVmMES6bfkDIxQRBOqTtuhZaaHtrmr3sENrWlSLCrphsUOsc0g4DWVsWTTasRgHuV0qHqmOdVQQ5AKFpsMSsIhiBmsj5FeQTfqFyprJtljdwTDZfouNk87u5LKIhj8AciHlEd2yaGkiMXgxjPAcAr3ljMCpXCRvuXZdyrhA2fOGweTUbZ1HIgb7HZIOwaXu2ZNiUK5ukKGwm87SXqW6rrpcADrjah/NpzpaGypbRVIjPRCFBsmcnW4Eth2KwYNgMGhVdl1BXfa52kyjtwmT1id2kkWkOmOTwwZOwuUabXMdQDiDug4OAKJ/VsTHpum7ryCvka7upz+cTQNT5fTf0/fncNMP3nh+slnabYDRTvuI+nGybJig6tn3/fT41+51VJloLmZXsKmcMmtL5ivs4Rn9sJkXvrTNrtxO9VfY3EKLJa45D1DwFvXmVrQuKgHR5V+7FCQlRjNE+2eQ12giyMpPJdjwHRa7gCO9KcRrAa86YXXj4IkMOoCurYdLBy0F6k0Yydcm8BmGTLF1YJSydFS71TBpZA/OS8c60OQgo5cwU+KIeE4HTyZbRyNRrB+e18VxPtQjCpLuwhFDkqWQDRYEP9Frho7Cbjj5UPkJQETzOYju89ON2cT5Cpww7qAONnPhqwgdIjB7pLd6MOG70Ig77V4wf9PqjyoaNifCoU8TCdLAzGY+mdUxdFfTBuBWf3qK8AUMQIsoBlI7gitgu5ftAI/GAMm2TDR8NPGXyGuUASkcUpMEu5hskk6LUa13uNaIDFRYX6QiuMOnm/VDxPdbX8a2aa58WD5/Ziu92tVJMHWOQuLRaP3Wg29NtyIBaeoIFTHTxVGVTtC/Ba6402D+Nd/rTR4APBXFAyKUVmh9ablXBpssx0Wn2epcUG7cE1gfUephGXgiW77F+K2WV8/Gn2gxFGkn0Yz0X4fezxvtpJHrNooOcwiZQhPG5Ztaxo9wJV2Z5QRqpsnY9FhWzZP8Ckw1cBGU6FMECH799jLudbDoDduIWeSDJbdc/NUgKnxaIdn/pQFLi/JkrWBHYRY04GWN0FkkuYO8/uGHrnwL2wfUtDglG22KQwcgwO9kIYPd53KYYnfHxeefR8rcawvNPJ4LvRpLA7gMlOkyQX4nmNUhKZz95o6X4WGWb+MCtBom/776o3Whe/dQgGc9+KbAj80rx3VcElcThDIZiz2wHOoYROuMmNuSfOydMZJ+Hxci7ks3BB9EyIGikDSRmGL8EFju7Tfkfpb1u/Q=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block066_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
