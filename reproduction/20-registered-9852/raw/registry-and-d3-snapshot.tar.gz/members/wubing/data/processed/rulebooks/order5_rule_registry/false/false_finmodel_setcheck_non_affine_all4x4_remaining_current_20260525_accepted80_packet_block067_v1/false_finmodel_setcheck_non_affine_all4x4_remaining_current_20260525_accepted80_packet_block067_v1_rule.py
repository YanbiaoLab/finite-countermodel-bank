from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,1,1,3],[3,3,2,3],[2,1,3,3],[0,1,2,3]],"priority":827,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block067.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block067","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWbluGzEQHRIMMGukoGQVKbkbFZsuCPIBNCEDKmX/gcv8BSHIwEZQsRCQ3hb8KanyVeG1l04bsmwl4MBeXbxmdt7MexIBKTVsMcaoBBFePBVw/sZ5/VQAA3rMWkJwSYHYEEhAYAhAbDQEpGBX1vbSl2ETtzHiUIOJZR+Qg50Lkpmp9m+X0eaMzMxtPiizeb7ianOGnmpYhg26nzz9/DbPF6U7TrUS7ncyAchouMdV7NyJHvztJjBRbG+Uwn+0aNGiRYsW7UhD7HKB/Q3Y8BzmaIft4BSOYz3/l7GGuyAQDQfZYYvw7uQ7zFA/0DG40aKtycVxpZWEARvxYAHmS1QZSpRVPNTLIyetwAkrII2+ak2swMaCLiEBeUxz90IKMy8RQQk5scOs9mEB3L6I2nckRdnSN24GqwZhKBZoztdBtq505diWDzIE7p0BbYcC1+aKpXOGelfMLokViz4AtPZDBz/MQ89NrKo1DwefhaNxUEAYB2EFJuPhsNSfhjpn3Kper0kbOBRuhD2/sG9p755zRwQfKLR1HKvlnpS1+nPOrNVC2hGQKOrSub0AMr9VCMWuzqZZv4oa1FHbkTadzsbD4jYEQVp3EqidJ4ek72ubEK2k7nxfQESTNtCkDV8LwH4gQJUnzLcv1troYNSOBFusba9kUrYqyybYdrC7vUvuAdvb2pdVkV2kg5tROsvm+WyCj1yls6nAU/DRB/Ggh0CXE1sml64uDXWBJ6Jl/ou1yejyF/+Tr76q9F59vOcX0/QUQdfLUT+RrJR9QpbjLFPSOMYJIPFAd8Xk1UhoSaXITEtKzPNpIX2zU3gi2N+OLq8HKl8tFF4PbmyG3M0Ufrji/36JGfecRzUGFJoMSQfsqmwRkQBTWfXShoW0wY8deG/214NgiwrwPM2kggObves6/J7iwUZaZNMzM70jbdpj1pJiS/q8XWeb56tCYbL5iftNhnZSsueKQBEgonKcipftliOK5JnVTySmhbrhtlUWxcsD9GO1yC4+P69Ejb7fJI92+OA2/21gKT5NzzkjhwDFc8PBe/ZaDU9nEc/vRyMdLzwFH3h3+wtCfo7v'
_TARGET_BITS_PAYLOAD = 'eNrtWbluGzEQ/apU+RRDdh9A2EJQFrAg8C9S5g9slQIs0PyAIEjnLZRdlilkiUXgHSAEOeG1l04bsmwl4MBeXbxmdt7Me5JGxghuMSkVQx5eXKR4/iZE/ZSjRHXMWpwLplDbEDAElICobTQ4FmhXJvayZGETtzHAnKCJ5RJBoJ2LTJqp9m+XqeaM0sxtPkjyYdYTdHMGGRPshw26n1x8/j7MBok7TrUS7HeyRMxVuMdV7NyJrvzt1jihcm+Uwn+0aNGiRYsW7UgD6HKB/Q3Y8BzpaIft4AqPYz3/l8mGuwBqggfZYYvw7uQ70lA/JDG40aKtycVppZW4AZv2YEHpS1QSSpRVPMrLIyet0Akr1I2+ak2swCaDLtEBeZII94JxM6/kQQk5sSOt9pEB3L6I2neYAtbSN26GrAZBKBZgztdBNql05dSWDz1H4Z1BYoeiIOYKiXNGeVfMLqUViz4AqvaDBD/Mw8pNrKq1CAcfhaMJpKilQG4FphThsMqfRjln3KperzEbOOBuhD0/t28R755zhwcfFLZ1nKzlHmO1+nPOrNVC1RGQwOvSub0ASr9VCMWuzkbksooa1lHbkTadzibC4jYEQVp3EqidJ4ek72sb562k7nxfoHmTNtikjVgLwH4gYJUn0rcv2droYNSOBFusba9kjLUqyybYdrC7vUvuAdvb2kMvzZ+Kxe2sGOXDbDSBS0GL0ZjDKfjoFb8ic1T9iS2TfVeX5iSFE9Ey/8XaZPb4SXzIej9ocU1/X4uncXGKoJP+bFkymbCl1v1pnlNmHBMaQXugu2LyaiQ0UYznpiWV5vk4Zb7ZUTgR7G9mj3cLmvUGFO4WtzZDvo4o/LkX/36Jma6cRzUGKJgMKRbyPmkRkQBTVvXShoW0wQ8deG/214NgiwrwPM2kggObvesk/J7iwaZbZNMzM7Ijbdpj1pJiS/q8XWcbZr2UQrn5iftNRnVScuWKQBogQjMY85ftlgHw8pnVj5emhbrhtlWm6csD9KU3yJ9+Pq9Ezb7dlpd2+OIm+2hgyX+Nzzkj54jpc8MhVvZaDS9GEc/vRyMdLzwFH3h3+wsKAuI4'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block067_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
