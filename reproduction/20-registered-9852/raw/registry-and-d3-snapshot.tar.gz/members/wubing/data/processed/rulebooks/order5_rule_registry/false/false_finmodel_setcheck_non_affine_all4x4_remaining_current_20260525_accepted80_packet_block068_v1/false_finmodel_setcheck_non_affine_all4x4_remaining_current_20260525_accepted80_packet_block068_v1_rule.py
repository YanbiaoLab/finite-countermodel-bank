from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,3,4,0,0],[3,1,1,1,1],[4,2,2,1,2],[3,3,1,3,1],[4,4,4,1,4]],"priority":828,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block068.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block068","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WT9ME1EY/6484RoD3JUETIDQni0woBNBBxIveCataHAw0cggNg4OEjeDC71KDdcwWEvTuNkwuQELLKSpBBIno1ujMfyZGEwscenQcL73rjD07hEId+9LuKP5ev36e+/7fd/vfX3XpAKU2oHYRoRcSwJ9kaNXlV6hB4L0hdqEbzXzEzjartnn7IDEfK9PdHJUnw590DRkd5R+xRciiuLwyCwjBlTyDIf+b6vD2dPD+qxCWGZ4IknkDGVQYDyhikGGx8eE0mTdDxrfoa8jxqN1KKjbBsV6IvxDbfRYX7jwpbnRcQX68fUYpQjkE3T63gaMU/hPOt4x07I+FThY1Qq2nP9scIhWh4Z4IMM0orbITBtXrUaDJbggA900u8xxqO4nRJggUK/6PIxWMXf2bgB015pp+QJvt+/INP9KaGoeUxNJKuGLQP71Jlhp5xkuqfBn5TbopLRKKAiqxVFPyJZYvX8vNZ3/aGS0gCwriqYZhjQmCp6Q7f2tYtVYIYGyUUUZ01KGKMtjYsgTsiVWtztlea2sKJuBGIUlhxQczJON21gu/sSBOsc17XE8ncaw+vFSiqGUJ2Rb3+6c1LRyfMEQJ4dkAossZSgleUO2hA+42ZEp8AtGyAbcwDElkSf2auFa3jA4BdttqSRwVTxq59LZNiLFJ0vK5qPxhxqHztYHHI0pdT2xbx0To4fynp8P2d7spwcARg8R6AMEquwl029OjHIsJC0WIk4ykmeKQC5Me3VA4AFOz2qkV4t8oD3IRoM49/1hgYeMvBuIhSUIJrnISDUWxMdZCGdwIHKsxYE9lJGDMcQxI5kHdS+sgDIa3qgsnzNbjiezdZyFmNWcllLy0SUkZYQD2caAY/VXeSA6MZFnjoBpDpy2qbV2N+Uze85Il3nx95abgq/W+/o0Vhcuuzsg2SadjbmpYcHNhK2sleNpg50p7qbqLBv1dYBi+Y6rMnKSmXG4vZXaujnJSCTpoE811auZSzKSiYwE6n7pbmdjTsKp4JubnnKz1ORQwJlsasCPULSQxK1BIHLIjZh6gOWJLiVBbx1xu7MxPK3DGYFO4Z+7F42Z/TTQSNndM5v1+1HNPvp3Ouof+C5WambG6ebZR/8lp6O+06J/PTfZHM5sM3YY6orgUGzOJSMtZtk5EEO2qV1sWHIsbmc2VJclNgsy0saNAYnadZYW+v2SOwOSs4G76EC0zbq9bbV57KtGa/RZvhRT3/hPSlSDOfzEl30RdBKi55aR9lqoN9taqDpnXwCkn2e4+B8NaAgH'
_TARGET_BITS_PAYLOAD = 'eNq9WT9ME1EYP9KBxVATByb+xGi6aZxMINg0LLAAmxOpm2mg1oH0iMVeWSRuBgcHU3HAaOIg0VoSz+ZMGJQwKQPQei2BJkJC74CYHvjofb73Dhh69wgNd+9LuKP5ev36e+/7fd/vfX10pAAEd4FYb55cgyZ9MUKvCr3CJpToC+UI33zCPXC0DmHd2QGp8Y2a4eRofr38QJaR3RG8lh7Lq6rDI5OMGOCPMBzSpe4dZ88m67PCBY3hySeRM5QVk/GEYpQYnhoTypF1b61/h9SHGI8eQ0FlGxTricINpd5jfeHwncN6xx9Yw9cTlAaQT5Doe+swzuA//WTHBMvWFeBgzVawochdkUO0Y2iIBzJMI2qjzLRx1Xw0WIoLMpAEYUvIQHNbyoA5AvV3zcNofqGz/QdA2XdIyxd4u31NgnBZRzPjmJpIVwhfTPKvN8GCna9wSYUrg19BIqVVRyVQLI56QrbUwMdPienIfTEmVzRNVWVZFPWcYXpCtoffQs3iIAkUnVfVnJwQDU3LGUVPyJYa6NrWtP6AqvZUshSWVlRxME82rncodB0H2s7I8tt0PI5hreGlNIoJT8jW17U9K8uB9JhozC5rBBZZymJC94ZsqRpwsybB5BeMkA24gWNKIk/s2diviChyCtZx4E/hqti0y6Wz9eZDb4bVnneZ9zKHzrYOHI0pdT2xWztzCy1ae5UP2Z60xVcBFloQSKsEquYl07/PLXAsJAcWIk4ykmeKwEiB9uqKyQOcFJVJrzb4QPsQnS/h3K8WTB4y8nMlW9ChlOQiI5VsCR9noRDDgcixFgf2UEauZBHHjGQe1L2wMIrJeKOifM5sIzyZLeEsxKzmtJR6jS4hKSMcyJYDjtVf4YHo1AyeOQKCsHrWpvp23ZTP7DkjXebRq91uCj7fxtOzWB3+6+6ApIt0NuamFkw3E9bfH0jHRXamuJuqk2zUPwFCgS+uyshZZsbh9hbcK3OSkUiXQJo5Oq5mLslIJjISqPzc3c7GnIRTwTcxPeNmqRlBFWeyKZUqQvPhJG4NJpFDbsSUKizP/HASpP1Ftzsbw7O/FDPpFP6le9GY2U8DLQbcPbNZvx/57KN/p6N+a+1ipWYqQzfPPvoPOh31nRb9dsNkczizTdlhKIOmQ7FpSEZazLJzIItsU7vsku5Y3M5t6FiW2KzESBs3BiTK1nla6M1/7gxIzgfuogPRPev2eN/msa8ardHn+VJMfVM9LVF15vATX/RFyUmINiwj7bVQOrS1UGXCvgBIamS4+B8/GGkv'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block068_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
