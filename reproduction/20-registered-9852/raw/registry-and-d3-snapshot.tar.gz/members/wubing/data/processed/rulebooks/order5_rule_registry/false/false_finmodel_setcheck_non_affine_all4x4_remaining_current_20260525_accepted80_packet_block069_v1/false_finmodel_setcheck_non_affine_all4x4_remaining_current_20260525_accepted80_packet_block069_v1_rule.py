from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,2,0,0,2],[1,1,1,4,1],[2,3,2,2,2],[4,3,3,3,3],[1,4,4,4,4]],"priority":829,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block069.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block069","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWT1r20AYfvWRSimhVoyHDiURRoFsWTslSnHA6tQ/UCj9Bcke8BEotFsI/QH+G52iLoX+Cw0dO2j0YKLKd8Y0uXttCZ+eKe9wQnrRPXrO97z33PmLkxLlAS3iWra5bGkg21Td7FEsb1Knvswrh4xRVD1zgqoJk5hVnjmR3/vMK6fMcyqZzyJxxb2yxyWmCdfZ0S6TOOb6SkMu426iUmhUetyrSyp+oFFRl+RcQ1Eg01RLhI+6D8l/0tcq4v9/sUqGR5CYSbAJBowUtR4GrFBoDgZtLsHOMGBCUQswaKVCA82RBwl2iAGrxTb5+PeCnsW2vdjuk89DQont5MefCx8ktsnvo4hQUaJUvRQbECxHqXq9JepGbH0gWOGVZzi0a3rATUnRA44jb3U7iV9O8KaEie1tIbwDFNprZNEiTwCl/QnJjL4nd+Ph0AWJ7W7Uz0YjELUPNbNvX0MQ2vt+luzvg/SdZsNdP0bNkeMMOSPZjXoXMaVbH4c2QI6jiFJyYOQiN4wFjNs75ECmFAPRQiQ12rA5nFt1R8X6zaGwe3QyX9+d3SVdbDiJSaxSK0/Wd2dX9ad86hXZ9uo5351Y7OhQNtKPhOEYd0sbyTJbAFl2tPxJuDR8IrFsI7niKQ2f3ZVBsHZ1fFNn7TKrVzYuszO4Xf3TYitYMHncb9mnL8VmqvKGZajYstTM+Cr/stk6OG4ttkvTcq4/ujQVm1Y2Uimr0QBlkbm4NQ6f48FNGysHJEHHS+ijAxLDV3dgwl6oy43O46fTTJotPip1ViXqqTk4bzRLW5WapXx2XL146tRcfcvltxLAPx0MsY8='
_TARGET_BITS_PAYLOAD = 'eNrtWT1r20AYVvDgUUPHDvoXhS5Rpv4N/4ASsrVQCGfI3vyCUugf6FQZYholU9dsgQijhA4djCOX0EiNPt7Kd8Y0uXttCZ+eKe9wQnrRPXrO97z33PlDFRL5GS3iSLa+bGkq21Dd3FEsb8KqvvSciozhOXNzgpwhk+g7hTnh7+XMK+fMc3KZzyLxkXvljksMIq6zq3smccn1FaZcptxExdOozLlXl1TyTKOiLtGphqJABqGWSB91n1L+pK9VxP//Yo6MgiDRl2BDDBgpanMMmKfQKgxaT4KdYcCEopZh0FyFBpojOxLsGgNWi2345cUJPYtte7HtRZ8mhBLbxZuXJzlIbMNXVwmhwkWpeik2IJiPUvV6S9SN2GZAMK9wz3BoR7SDm5JiDhxH3up2Eq+r7KcLE9sPTxQ3KLRfyKJFhQBK+zOSGb2N9keTSQkS2/54FozHIGpfa2bv3qcgtG+zILq9Bek7DCb3eYyaI5cBckayG/UuYkAHOQ5tihxHkYRUwcglZRoLGLfvyIEMKQaipUhqtGFz2LPqjrz1m0Nh9+ikt747u0u62HASE1ml5l6s786u6s/51G+y7dV9vjux2NGhbGSeCMMx7pY2kmW2ALLsaPmTcGn4RGTZRnLFUxo+uyuDYO3q6LDO2mVWr2xc5mF6sPqnxVawYPK437JPX4rNVOUNy5C3Zanp81X+T7N1cNRabMem5Vx/dGwqNq1spFJWowEKEnNxaxw5x4ObNlYOSLKOl9BHBySGr+7AhP1Vl0Odx27VTJotPiqsViXqqTk4bTRLW5WapXweSr146tRKfcuVtxLAPy90v5g='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block069_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
