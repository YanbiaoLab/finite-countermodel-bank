from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,3,3,3],[3,1,2,2],[3,1,2,3],[0,1,2,3]],"priority":830,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block070.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block070","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WE3O3CAMBcSC7jgClXoQ61t9x6JSu++RywDDr01gAmExmoQkzzZ+9oO/DBQD5scf/wvMhAvxulDGuj/S3wPlH5SMGIac4ZaYUJx4JwIjI9w0/YQOM1zqZsIGB1X/igxOplmeXdHgrhADfjqzFEuzULri7obZbGcRwzxr2OsvY1/e2GLWf9RF5O0BtOg2zFgQGnWFSZHfTq4QqxZcMTbO0muUv9ViFosC7MlRGPXAIPP3xDBdAp8cjufKPAUWw6ieQSMLwpEhfPV4KJSxSCfa6sNki+XpkUFW2ENk80DKkE1iO9kcoGSvphDL/SFMqwsgmbrOocKpLzi/d3yRZsB+B4Fkda0etpGNMoPLRqbsIhtmxoG0MaWCqxvsEbKlqDVmEMryTGeTlIS9EYCB1O1WEwvA2pIWna3WiSe6Dt3ZELLxu9VGNUBZtCN7goWiN5KRunKGVUCmShskAM22YBAK0wDVj5oqNakAUBhmvrOdEER0Z0s6ZWNqapGBbHTrhTmOGhukzbizUXvCrFPizclqMyIbuTVFBBGRNuwySa93yH1nu0+2UkbWUZtKm/c6T5KtlJH8nSHA8LRBAtAv6STZ6kcDULUyyElFNq7HkKtkQ9KmDkCuBOnFkkHB6UQnmmx5U5BWBqk2GEY+VYlOv49YlsiGBADDSKEo/RITZLtMGwyjSNLkF7Rku4wadgKFYBRJWi3epZTYu4cz4yInfmyFk7RYVD6aHxT5YWcj1QNjP35pvlzkLzsbqv4d3G+ZUn0HoqDboWzv3940Qiikso+n+cekvdTjH8vI1jPhi0lRWX3GtKRZylhSRlro2iT07IRFslEn4dv3UKPOhkZtp4ysUhMBkncDQHY2vz9Lt6j0X6xpZGdDjvupDQklQyRh23fPbf096clCgYlH/xwvyDPNQC2TzUy5Aaazy66SbcGyPWSbtKxPm48OSFZYc2MPFw9IXPqJuURzRPkcLhyQMMG71ILRoWHx8IJ+gLBmCj37RLNUKGhq6dJp5OuzXLZ7P7QjOCBXUpOK5atS5T8kL4mC'
_TARGET_BITS_PAYLOAD = 'eNq9WE3O3CAMPXL3rVSO9a0qH6RSOQK7jwUCygDDr01gAmExmoQkzzZ+9oOfFqQF68cv/wuWhwv9upCcuT/K3wPpH1SWGJycMYyYkIZ4JwIjI9zk/YQIM0aJZoIFB2X/igpOplmTXRHgrhAD/jmzpE2zULri7obZbGcRwzzL7euvtX+8scWs/6iLyNsDaNFZmGGgBeqKVTq/nVwhVi24wlmcpdcof6vFLBYF7JOjMOqBQebvicG7BD45HM8lfwoshlE+g0YWhCND++rxUChjkU60FYfJFsvTI4OssIfI5oEkJ5vEdrI5QGVfTSGW+0OYTBRAKnWdQ4VTXHB+7/hDmgH7HQSS1bV62EY2ygyjGpmyi2yYGQfShpcKrm6wR8iWotaYQSjLM51NURL2RgAGUrdbTSwAa0tadLZaJ57oOnRnQ8hm7lYb2QBl0Y7sCRaK3khGisoZWwHxKm2QADTbgkEoeANUP8qr1KQCQGHw+c52QhDRnS3plI2pKXQGYtGtF+Y4anaQNuPORu0Js06JNyerzYhs5NYUEURE2tjLJL3eIfed7T7ZShlZR20qbd7rPEm2Ukaad4aAxdMGCUC/pJNkqx8NQNXKICcV2bgeQ62SDUmbOgC5EqQXSwYFpxOdaLLlTUFaGaTaYBj5VCU6/T5iWSIbEgAMI4Wi9EtPkO0ybTCMIkmTX9CS7TJq2AkUglEkabV4l1Ji7x6Oj4uc/t4Kp2ixKH00Pyjyw85Gqgdrv/8Ks1zkLzsbqv4d3G+VUn0HoqbboWrv3940Qiikqo8n/2EVu9TjH8vI1jPti0lRWX3GtKRZylhSRjLo2iT07IRFslEn4dv3UKPOhkZtp4ysUhMBUncDQHY2vz9Lt6j0X6xpZGdDjvupDQklQxRh21fPbfE16clCgYlH/wYvyDPNQC6TjU+5Abyzi62SbcGyPWSbtKxPm48OSFZYc2MPFw9IXPrpuURzRPkcLhyQWG261ILRoWHx8IJ+gLBmEj37RLNUS2hq6dJp5OuzRrV7P7QjOCBXUpOKNatS5T8oUeel'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block070_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
