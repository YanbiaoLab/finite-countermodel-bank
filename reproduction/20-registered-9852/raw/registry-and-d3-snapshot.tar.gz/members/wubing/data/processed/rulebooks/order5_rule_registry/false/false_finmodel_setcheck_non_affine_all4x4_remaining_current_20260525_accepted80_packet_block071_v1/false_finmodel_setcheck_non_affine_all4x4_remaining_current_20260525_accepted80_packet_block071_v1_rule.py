from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[1,1,1,1],[2,2,2,2],[0,0,3,3],[1,1,1,1]],"priority":831,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block071.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block071","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmU0KgzAQhVWEZpm46rIOFrrsEUSy0K56kB7CRRZx13qCHqvH6A1ao/1BrFoRqYX3KQQy4nNGh8xE2+okTBwzuMUButkkwUlK91MMKQuIhtyLV4PzU4d61VMrLK4JyxPfBwAAAAAAAACAeoesglzro/SEIJJSax4xewq1dfYSymOiSCrNhIiYP4XYufDsKeQlpVvCp0Ls//viNJfGo5gyzZJAGLdMKH3Fp1Db528hs2vyCKXiDvJnxrRmMEds5sv1tuiwrobuWgIA5sHOM0uo3ZLVZR1myiEixaPRYmE1sKZle2lMLQ/NZ7Ik3hgAXyVb9Uu2LJPrFtN9OL1T03Zd47gDVEE32g=='
_TARGET_BITS_PAYLOAD = 'eNrtmU0KgzAQhXuDHqPH6glsd2aRhYfoQbqqLoJ4hC4LlbHLrkyWKYhao/1BrFoRqYX3KQQy4nNGh8zELO8kcFMzJMUBujm54UaI5FMMyQ6JhtxLVUP6U4d61Z08KK4JyhPfBwAAAAAAAACAeofMQ4uxrYilJBKCMeXrbAq1s/0SsjwiX3CmpfR1NIXYuvDsKRS7pVsyokLs//tixxLGI49spt1QGrdMKCOuplDbW28hs2vyCCVXKfJnxrRmsEJs5styceuwXobuWgIA5sEhNkto1pLVZR1myiEirvzRYkE16KbluGpMXXfNZ8oF3hgAXyVb9Uu2LJPrFtN9pL1T03Zd47gD+DA5XA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block071_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
