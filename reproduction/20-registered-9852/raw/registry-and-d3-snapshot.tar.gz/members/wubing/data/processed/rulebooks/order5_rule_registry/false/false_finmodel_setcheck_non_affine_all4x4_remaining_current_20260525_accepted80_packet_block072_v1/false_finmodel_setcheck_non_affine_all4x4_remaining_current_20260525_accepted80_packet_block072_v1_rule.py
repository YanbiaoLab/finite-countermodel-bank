from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[2,0,1,1,2],[3,3,4,4,1],[3,3,2,2,2],[2,2,3,3,2],[4,3,0,0,3]],"priority":832,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block072.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block072","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZAACByYGaoAHL6hjziggA6hQ0SwFGENgNFzBIJ6B5R87vRL3ApWFnSpKSnSy7Q9zyc94udEoHgWjYBSMglEwCkbBKBgFo2AUjIJRMApGASHAiV/ahWU0iEYBPcGBi6yjgUANoKCAS4bJgUFhNHxGAb2BxS7i1T7gjO2YNxpko2AUDAUAALClDvI='
_TARGET_BITS_PAYLOAD = 'eNrt0sEJwjAUxnGK0BU8ZoOu4Mk1Ki7RDtElQtfoIccOEUJwAm+hNI1RhB7VIiFQ+P9OgRfeg++9R3xRIaYgjmn64A86YS+7Pu7k+iajL6Zcx33RdaONyTTtsHSlvLFiAAAAAADwi/teHjwRIadTNRNCCtZ+qgQVLfkgt/G8/a9wfXslMmAPnpvMYkQ='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block072_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
