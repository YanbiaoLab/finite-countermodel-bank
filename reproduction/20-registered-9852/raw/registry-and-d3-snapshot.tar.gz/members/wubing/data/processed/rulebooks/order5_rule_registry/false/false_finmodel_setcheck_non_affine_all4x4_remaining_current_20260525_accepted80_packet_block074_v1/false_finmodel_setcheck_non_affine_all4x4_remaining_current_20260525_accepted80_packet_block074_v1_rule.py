from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,4,3,3,4],[2,1,2,3,4],[0,4,2,4,1],[4,1,2,3,4],[0,1,2,3,4]],"priority":834,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block074.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block074","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WEmS5CAMBIIDR55A/UTRL+NQ8+8xS7FKBmxsDt1RxkZoSSmlfwwUA+bX1/8FZtw/yYQ6fihjmTh+uGegIOwQy5A73BIbikmNbkTByAoPTb+hww7vTrQ/WW632pH+NOh3TZYF9Tcff5oXIZT5mS6p4i+tIX6rClXk8dQ6o2rmPnPH/PnLFruHKGdsFjUQ0OpoddRItEoGVZjsbGbCdRDffPx1zM+npI84a8ySZRZOAfbmUvxNaWT8PrGiw15aXx/GL60Sic8vMiE8soq8JB8XBg1sn9VQZee9EJpkhn0QbL7WuUSv8NqyFWyHIMlcUYjp/iE4WF0IkqnqPJQ49QDze9cfeQ3YryCQEVGzh11goyiR3zWRpshtYBPo5Z8IGxpY/IGw+ZLX6Jnl7bChK5ukSsXAAJcqG+JNnwRaPyy5VCxgXq0rQ1a2OavVr9tVsDG8hCKoRu6lCZSe0khdZY7aaqYKm+Zeopeh6AAyjSA1spqel2FmopzEfCzt9yobvjCrpYp7kSVpKqgt5n1e5OhB0iMqW+wJ0VgToxxdu1QMuCEE6h8a1y7WEiEqwiZMAzoDhCsQATSkkdlqDdj0EGx0GvvYlNhDCNhkNZ86e7AJRYKNh/vr+A0f08j0qmQ/b8bjsRFBJSObW9YBpHKvr1A+UHtTJEun13kLaJHNbRsg8xGNRCYaFdhCSCSOWwZptI8Nt/SbMTBEFmTjl/FVJwjScZphPBqXkacq4UJpxEIPYKqw8WZCwYbISKYo9RKncyDMaogBMBnJFIVeITB4FjS0GjaBQmQkU7DaeScV3w6L4gUaKU+ZilBbxUmK/0Ch+q6W0TKKiELBD3a1jBFsKPs/xHGZQn1Ht0EObg2T25tuCBaSPVM4NJa7e1KSRoZ5LAy5/lLEkjTSwszBa+gwDR+YaAvuDUhyp1vWdtjSXKBgq/iAvdfGjcHWJ3aKWeqh1/gEjWwTez03ZGcNCcX5JRFRQCKjshpQxH0WbJxUHpGGFQO1DDYzBSMwN8cYS6N/vgFs06N/JGwuDUj0AmpuDLXjgOSwppi9nrguTgRfCD6VazPS1MRkDBuQWDyGkdjRReufyP5KAQg0EhkZYIZ1YDtSamKxfHVM+R80734n'
_TARGET_BITS_PAYLOAD = 'eNq9WEmS5CAM/PfUgZd16CfFEzhyIIAxS7FKBmxsDt1RxkZoSSmlfxakBevXx/8Fy90/ZbU8fkjOrD5+uGcgIewQi5M7hhEb0iqBbkTByAoPeb8hwo7pTmQ/WW632lH+NOh3eZYF9Tdff5oXoSX/mS6p4i8tIH4rC1XU8ZQ5owrrPnPH/PnLFruHKGdsGzXQ0OrIRNRIt0oGVazqbMbDdRDffP11+M+npI+MbcySZRZOAfvmkuZNaWT8PrGiw15aHx/GL60Sic8vMiE8soq8pB4XBg1sn9VQZue9EJpkhn0QbL7WuUQv8dqyFWyHIGVdUYjp/iE4MFEIUqnqPJQ4xQDze9cfeQ3YryCQEVGzh11goyiR3+WRpqhtYNPo5Z8IGxpY5oGw+ZDX6Jnl7bChK5uiSsXAAJcqG+JNnwRaPyy5VC9gXq4rQ1a2OavVr7NVsFm8hCKoRu4lCJSe0khRZY7aarwKm+Zeupch6QDijSA5spqYl8FnopzEfCzt9yobvjCrpYp7kSUJKqgZ5n1T5OhB0iMqW+wJ0VjToxxdu1QPuCEE6h8a1y7WEiEqwiZMAzoDhCsQATSkkdlqDdjEEGx0GvuylNhDCLBkNZ86e7BpSYLNhPuL+I0Z08j0qrI/b8bjsRFBJSObW9UBJHOvL1E+UHtTJ0un100LaJ3NzRogmxGNRCYaFdhCSCSOWwZptA8Lt/SbMTB0FsTil/FVJwjSccJiPBqXkacq4UJpxEIPYKqw8WZCwYbISKYo9dKncyDMaogBMBnJFIVeITBMFjS0GjaBQmQkU9jaeScVnw2L4gUaqU6ZipZbxSmK/0Ch+q6WkVmKiELBD3a1jBFsKPs/xBmVQn1Ht0EObrlV25tuCBZSPVM4NFa7e1KSRoZ5LAy5/lLEkjSSwczBa+jgDR+YaAvuDUhyp1vWdtjSXKBgq/gAu9fGjcHWJ3aKWYqh18wEjWwTez03tGcNCcX5FRFRQCKjshpQxH0WbIZUHpGGFQO5DDY+BSPgN8cYS6N/swFs06N/JGwuDUjEAmpuDLXjgOSwpp69nr4uTgdfaDOVazPS5MRkDBuQMDyGkdgRReufyP5KAQg0EhkZYIZ1YDtSamKxZnVM+R8XkfMA'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block074_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
