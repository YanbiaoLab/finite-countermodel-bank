from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,1,4,3,4],[0,1,3,3,4],[3,4,2,3,4],[0,1,2,3,2],[0,1,2,2,4]],"priority":835,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block075.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block075","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WcFu4yAQxYiDfcN8AbVYqZ+BIh+cnvpJziorpbds1A/opy4MGIMZknpjdw5uY2yGGWbePMZ/iG6IJiCfcNW1hB9K1OZHI0dCCSOK2x/wICMF+SqOvIyFgdejnRgRrxgRSipzlfnAOx06o+fIljOOXJOKEbCrSkbOoAKsqkk8+qX+9qJtxWBGafLOrw91u1yuZkZCazK5zpliddm7Vw3rTE1hZhUwys3i7b+EvMFi5UcYtZNa/3oLcvWjgD9XLfjCO86UkQWDIlM0vmu/YDl+gwmJ96hm8+/XCnxjF5V6fYQ5tVVJF0p3l9fqJ7UV43cP8Rv2Q/JpYkD+lLIxyrX9pQgIu8jBYAy32XQHITcTD9Ihbfe10EDb374/M0EctO0rRYTdKdmgqBh/AtLWP5BsvhoFuN9J5yi0MIogByA0iS8xu4iPwArJ+R3kDa5QOVO59tsbOCWbK9Fxsrnd3BbRHCUafQ4YHdRPr8Wx7wcgMdVmGOM4AHjNGeOjcpewkc51KecKYSM3DptPcrMWhRxoW59sEDaq1VuGTbmyMYzCZrJOe5nqKrpcAjhgsQ/dYc2WhsqW0VSIz0QhQrJXJ1uBLYdisGHY1JVXlC0jPxMgpX1l2X2Z4SOl6XVuDFLaabI4krsi3WQXHAhEuayOjUnX9VhHThg/1W3ougNAVPdxqdu26/q+fjnLk9GirglGa6NFPAGZ460Pio6qbV+6Q3++GGVcGcgcmRgJryZThKu4/4/R77dZ0YeyZl0uvDXKfgMhWnjNKBpkCnqrGMybCIqAdDlXnvnBE6IYo12ysSXa8DQR7gSpPnZBkS043LmSH2oxEaJLeLiZ6a135VjPOmQ5SJc0ki/TNCZEPipd2PBFsq05qMQ0Mo1nmVU2NYFAnGzWTO5frB4kW0Ij82QDs1hItrxFMG/p95JNJHygDY/Cblr/jtP7tvcByRYnNPdR2U5LkHLaE4bQyHl7Eq+hGD3R26AjcNzoRT/sXiFu0OmPKptvTIRHrSIdpuME49G4jrmr4hYUWixvzqK8AYMQIswBmI7gitgu6vpAE/GAMm2SzT8aeMrsNcwBmI4oSINd2jVIZkWp10TuNaQDFRYX6YiCNNm8OxXfYf0Q3xpsOjRP8Ndyn1EMlGp6jKGnUVX1VH/jjLchbWeuMRcJ3bHOp9HpycO4qWwU9yV4zZaGipLeOf3pI8A7hThApFG8kicljSrYdDYlOs5evyXFxi2C9b5yP0EjG4Tlg6grY4jRT7UZIhrJFy1Sms+NuGGV9iKNhKIClZvNYRMiZXquv1fIsAZJoRNOyfbiaSTN2vW+qJAt+xc22SY+YPFIPuLjj49xj5OtyoAduYVEkkZsr+41SAqfFpB2f+lAUqIhrJA7CLDzweNkjNFZJNmA/f7Bzbf+MWCvbd/ilGC0KQYZjNSrkw0BdneoUilGZ+5Zdx4tf6tBPP90IrhuJArsLlDYbDP6lWhdg6R09mMPWor/V9lmPvCoQeLu2y9qD5pX9xokZArq5DGenz7AzeZ+ekpYwVDMme2Ex7CHTjNWTzNC/tlzwkz25/Mo+1ayWfhAWgYIjTSBpA0hagKLXd2m/AdEZ/4e'
_TARGET_BITS_PAYLOAD = 'eNq9WcFu4yAQ/dT9gCrNrZE22viTemp8sCI+o9Iily/A3OwDwiwMGIMZknpjdw5uY2yGGWbePMa/Nek10SAvcCUDgx+UD+ZHzyqttNRU2B/woNQF+VUc+aoKA59XOzEiXjEiSo/myvKBd1W3Rs9VLmesBNGj1GDXmIycQQVYNeh49Bd9bXjX8dqMquSdv2/0cDodzYxaDXpynTPF6rJ3jwTWmZoizSpgVJjF23+1/oDFsrcwaie1/vUW5OorDn+OhIuFd5wplQwGRaYQfNf+wnL8Bmsd79Eg59+fI/jGLir1egVzEqtSLZTuLp/jT2orxu8e4jfsh+TFxAD7KWVVlGv7SxEQdpGbwRhhs+kOQm4mHqRD2u5roYG216Y5S64dtO0rRYTdKdmgqBh/AtIOP5BsvhoFuN9JZ8UJN4ogByA0tS8xu4iPwBHJ+R3kA65QOVM5NtsbOCWbK9Fxsrnd3BbRHCWqfA4YHcpPT/i1aWogMeNmGOM4AHjNGeOjcpewYc51KecKYcM2DpsXfbAWhRzoOp9sEDa0I1uGTbmySYzCZrJOe5nqUrVcAjhgsQ/tbc2WhsqW0VSIz0QhQrJXJ1uBLYdisGHYDKNXlC0jPxMgpX1l2f2a4SOl6UNuDFLaVbI4nbsi3WQXHAhEuayOjUnX9VhHThhf6KFu2xtAVPt2GrqubZtm+Dqzi9FCjwlGE6OFPwGZ1aEJiq60677aW3M+GWWCGsisJK+0GCdTuKu4/4/R74dZ0Ru1Zp1OojPK/gAhWnjNKKpZCnqrGMwHD4qAdDlXnsXNE6IYo12yySXaiDQR7gQpubZBkS04wrlS3AY+EaJTeLif6a13ZTXMOlg5SJc0UizTNCZEPipd2IhFsq05qMQ0Mo1nllU2OoFAnGzWTOFfHB8kW0Ij82QDs2RItrxFMG/p95KNJ3ygC4/Cblr/VtP7tvcByRYntPBR2U1LYGzaE4nQyHl7Eq+hGD3R26AjcNzoRT/sXtFu0OmPKptvTIRHrSISphMa49G4jrmr4hYUWiwfzqK8AYMQIswBmI7gitgu5fpAE/GAMm2SzT8aeMrsNcwBmI4oSINdxDVIZkWp13juNaQDFRYX6YiCNNm8OxXfYX0d36ptOvRP8Ndyn5HXShF1jaGnp+P4VH/jjLchbWeuNxcG3bHWp9HlycO4qWwK9yV4zZaGUenGOf3pI8C7gjhApKdiZBfKjCrYdDklOs5evyXFxi2C9b5yP0Eje4Tlg9CjlIjRT7UZIhopFi1Slc+NuGGV9iKNhKIClVvOYRMiZXquuVfIsAZJoROu9PbiaaTK2vW+qOgt+xc22SY+YPGIPeLjj49xj5NtzIAduYVEEkFsH+81SAqfFpB2f+lAUqIhspA7CLCL2uNkjNFZJNmA/f7Bzbf+MWAfbN/ikmC0KQYZjAyrkw0BdneooilGZ+5Zdx4tf6tBPP90IrhuJArsLlDkbDP6lWhdg6R09pMPWor/V9lmPvCoQeLu2y9qD5pX9xokegrq5DGRnz7AzeZ+ekpYwVDMme2Cx7CHTjM2TDNC/tlzwkz25/Oo/FayWfhAWgYIjTSBRAwh6gOLXd2m/AcIGXMJ'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block075_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
