from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[1,1,0],[2,0,2]],"priority":836,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block076.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block076","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WTFr20AUPtlKrFBcS87QlgZsK2qdqUMJoUOID3MlcRf3J3TI0CV7CiE6WhesKa5j6FKI6Y/orJQMnUq7dUwDhYwOXTwYq3cnJSnWXbDJ3T2IHPN0evqk97373vP7LAQgLABqoyo9hgb70mNHyI5gCZTZF5ilp0VHgGunUYnvAFEUZS2eYxjVPiBkph0hWVLdcDlL9gUxwEBwWwD/PVnke5ZE1+p7jsDzKPAyXCgrhmAFtMoCT0YIJRt/nk+egSNTsDSBYvopKPEK7yea9MQ33D+en3TcB4/J8RKlBegVMDt3AuMr8mcn16JvjFoJAg02TKIdDdsaoiXBTB3ICI2YHQrTRqqNWDBfCzKSvtfWpFCXMwqjDa6D1Rg3lGIbJ6EINU0bUr4Y9F81wcL/HiQtrQOCEMYcVUu2Dio6jusi1G7bdctQSDYaqLvlunXUaluOU7cqCsnGbLGB0LBtOxWXBDPVkY3k/h7aPQsOrJKz4e6hYaWlmmxR7cL5HUWbrQOr1rLVkM3PAG02jgx9wcKY1ZpMKIlU7Wx6tlBGttzAJ1VxXNCzs1XH/tnyV0o2DTtbCWg0odRVYt8Xm+ukfCzoIdubs4AI//WLk80W7UcGjkqmP2uuaywkOcwQaZKROlME9Dy2VxcNHeBwFxXJXm3pgfaSIAvaVsNznIp6GfmiyAIFWmQkbLiB57oe2XBatK0l2kehjFxpmBozUtioq7C+2UHkRXX19Gw9nczGJAsJqzU9SjtjlWnOmzYbOSkmWx1orP5QB6Irs3TmCJGR1Zte6qggUz6L54zsMX+M/jyX27PdpFf7dyT3bLQLFb5Uz5CZsHRAQrpQoV9uqu6LUT+hHZ3UGVQo7kYx6+h8mU2BWEaaNgb4tJBUM0kyUojstACAP5Ja08STcCb4Dne2kcT2kchI/hYKqeDb+hzQURCVQzLKGy6KPCQQwDtfHkje2QSe/GrH6B/PPwXb8qIJs5+N+9d+ye3Zkt+P0qN/Xqt/zru3uRkGJM24UqbmFiGv1ec99G8zk43Ts+2mYcBBjlNsZpKRMbPSHGiYqaldY9XhFrepzUxkScrKgrSRMSCB96bZQn/M3S7a5YBkOnC3HYjejT/e1lKe4xK3RnNuamqBBBeuStSEcX7i6752eUJ0+p09oU9+LYVj/mHquu/yqfUePsefpn6Q/wC+e157'
_TARGET_BITS_PAYLOAD = 'eNq9WTFr20AUlvHgpcSjoeBm7NbSqUOoNfdHFAe6FBLXmWSoW04h0OxZOmToT6iXOqGHOYcMJYQOneJWkW1IaTvYkhtKlES2rncnJSnWXXDI3T2IHPN0evqk97373vOrMcLYHGFq2Q49mhH7ssSOiB3xEe6xL2hMTzMWMdfmjT7fgQ3DGAc8R85ov4QwTDtMsqSz43KWrApi4LzgtjC4szDge45E1yo7nsDz3XImXCgHkWAFCnoCz0QIZRx/FqbPAEYoWJpACe0UlHiF8wBOe+IbLpfOph2/8DdyvEAZYHoFwM6dwvie/PnJtegbo9ZHWIPlkmiLuZqGaEmwUAcyQiNmy8K0kWpZFszWgoyk75U1KNTDicJo+atgbcYNpdgySShCzdBHlC8R/VdNMPO/B0lLa54gRDFH1ZKtCoee57oQ1mp+K4gUko0Gqmy5bgvWa4HntYKuQrIxGzQhzNV8r+uSYKE6spHcX4PrRWsl6Hs77hrMdeuqyWa057x7hrFdXwnadV8N2ewJ1mYZI9IXzIxZrcmEkkjVzqZnC2VkO83bpCpmRnp2tk7GLh4+oWTTsLP1sUYTSl0l9mjQ2CXl40QP2d4WLSL8d+cWtuu0H8l7Kpn+ubGrsZCcAoZIk4zUmSJ4yWF79TDSAQ5U4JDs1YEeaB8IMqsWNB3P66qXkR+HLJClRUaipms5ruuQDadO21qifRTKyINmqDEjhY26CiuHVUheVEVPz7akk9mAZCFhtaZH6U+CHs350GcjJ8Vka2GN1R/pQHRpgc4cITKyc91LzY5kymfxnJE95hfG3U9ye7br9Gr5r+SejXahwpfqRDITlg5ISBcq9MtN1VUx6q+0o5M6gzLF3ShgHZ0tsykQy8jQBxjMj5JqJklGCpHNjzC2s1JrmngSzgTf8sYmlNg+EhnJ30IRFXxbzyw6CqJySEZ5A0ORhwTCYOPpT8k7m8BzvF+NyqWzL3hTXjRh9rNx/959uT1b8vtRevTPa/ULvHs7v8GApBFXytTcwuS1+ryH/vjGZOP0bOtpGCh/yik2N5KRMbPSHGiGqaldc9/jFreZLUxkScp6grSRMSBBv2fZQh+e3y7axYBkNnC3HYj+iT/etFOeUp9bozk3NbNAQieXJWrKOD/xVd65PCE6+86e0Od4L4Xj7Efquq+PU+sdUADPZ36Q/wCN9hK7'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block076_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
