from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[1,0,0],[2,1,1]],"priority":837,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block077.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block077","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZECAFl4GGgFmBpkCrBIaDAwbsNp6gPPB/Po0hhEKBKB0wkA6gomgCgcFOJORYRSMAkKggR9MSTyoB5YJf/hHA4RccMD+AYj689/etuH//+XsDvwNcrSzTcMTHHmggnrDWTNj42EUkA/UJ7IAqW2/69OOlf0/f4ZBwsCYmWa2zVFn4lBgOMAmfYf3x/P5/yWNGdIYgFbSxsKG/0eEGVkYfvz//18SiO0f1x/73yPJkDyae0bBKBgFo2AUjIJRMApGwSgYBUOnz5aDTzahuf4d32ggjXDgcAPf+KUDg7SIyGggDT7AwiHkgSPGgMBDgZGBgRGIWVhGg2oUjIJRMCgAG7BNAqIxJ8EaaFCzAW3xhBaIqECBBl6zYHRYwM3BwIFZW7JwYarmoNA2AJTkPNc='
_TARGET_BITS_PAYLOAD = 'eNr79x8Bqj/9pxH48/9xP1aJ6///+2O11f6bfELDzP8jFLyH0vMH0hF/CarYfx/O/Pd/FIwCQqD+A5h6Lt8ALBOYP4wGCLnA/oA8iGJmOHConoEh4sf+D/UPaWfb9W3gyAMV1P5GJ8+cGUYBKX8j7zeQ8mRpmGnZyWBg/P/5+TN/aGZb8o2/3+//t//5RPkTu0QCw7Mz/2f+B1pJGwvrGazf/Pv9n52BgeEZEB+QabBkKH72f85o7hkFo2AUjIJRMApGwSgYBaNgFAydPttkfLLzaxoEP44G0ggH+9XxjV/u///k9evRQBp84Pf3t9txxBgQbL//7///f0D8+/doUI2CUTAKBgX4CWyTgGjMSbB6GtRsQFu2QQtEVHCfBl47/m9//Jfv/79j1pa/v2Kq/k6hbQC3jTRf'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block077_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
