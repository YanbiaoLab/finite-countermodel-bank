from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,1,2],[0,0,1],[1,0,0]],"priority":838,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block078.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block078","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2DtuwzAQBNAhscUm1SbIAWjBB1kELnIsFi5U+shZiqHkwohipDGMeYUtS/yJBGgME9wrnoLZelkgyP9pq5T10qHR2uqA1nJFNmQfPbcP1WONwu1pPEKKW7LTS97GKEvd4RIjmG7VqLVG6zo6uHJMNqvWnyF3+nv3L8CUUbZXAPqsrS9vO7M0ymYQERERERHRnT6RxFBqz5FN6vFqiZzm8UMi2FkLeY6kI61JT3se5aKG9PS2pdjrKCq7wY7uPi9YInl2lOW8QNsilLY2qcCW4whpK2Nj6m8k+BHZR8X2JfuHCET0JOrFs7qY55TeHZM75rYjaBq7Az2gL5w+3lDnKf6p/dTunO31wJ2biIjoL74Bjb4Wzw=='
_TARGET_BITS_PAYLOAD = 'eNrt2DtuwzAQBNAju1SRgsdKYQR7EEPmAYJkq2SLBTnhiqHkwohiuDGMeYUtS/yJBGgMK0QSnoLqepnhKPe0lfN6KbDW2uqMaDmhKIqMnuPD7JRa4XjaHqG2W77TS9nG6Evd4dBGMF+rkVJqrdvo4MKp6mSWfofc2d/dfwNzQd5eAeiztr687szSKFtAREREREREN3pDdUVOPUeG2uPVEjlV2g9vwU4j5AmqjbTmPe1JK9dqeE9vW4q9jKK+G+zo5vOCJZIXQV7OCywWIcfa1AxdjiM8VkbH1F9J8COyj4rx5fuHCET0JNJBiomrlFo/BLMIptgRrI7dgR7QK47vn0jT3P6p5Rh3XvTrzJ2biIjoP34AvrNaZw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block078_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
