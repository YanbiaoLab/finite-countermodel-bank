from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit_accepted80_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,3,4,0,0],[4,1,3,1,1],[4,4,2,2,2],[3,3,3,3,1],[4,4,4,0,4]],"priority":839,"rule_id":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block079.v1","rule_key":"false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525.accepted80_packet.block079","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WU9I21AYf6lvmrJVkwpuMKFt1qoHN2SI7CCYlQjtdHSHwcY8rBQPu8h2dDBsqh2keOlqKbu1eNrN7bAJQ6SKwk5j3srGmPPkUdnFQzF776V6aPKkxZf3QZOGr8mX33vf7/vXtx0qANUegGUjgo9VgVwUyVElR9APguRC7UCnulkGjrJvBpwVIL14zSM6KU6eD7/TNGhXVH+lliOK4nDLAsUGOCpRFPq/nV5nTT/tWZWwTNFEMtAZypBAuUMVgxSNhwqlwzofNv9CX4eUWxtQoA1pxbojvKc2a6wXrmx1NitugAF0PEMpAvwEnfy2CWMSfaSzHTMtCaiAg5xYxtZKHwwO1hrQIA9kiEZEVqhuw1TqxFiaCzKgm+bEVxHMHwREkMBQb3lctHZk/hHQ84U3gIQv4O72nZpm4hUMLiFqQknFfBHwV3eMVcvJRa8HzObvAx2HVgkGgWpx1BWypT8/nM7Old4bec0vy4qiaYYhRUXBFbKVJzZPjI/YUCGmKFEta4iyHBVDrpAt/WmyT5ZLNUXZ9scJLDmkIGOubNzG2uZPZKhvStOepnI5BGsALaUYyrpCtvXdvhlNq6WWDXFmWMaw8FKGspI7ZEt7ADc5NQV+xqplwmpOQi2JXJGXy7dLhsHJ2H7XURpFxdMeLpltI7L5bFXZfjL1WOOQ2QKAo1BLXVfke29i/Fj+6+VDttcHuUEAxo8h0AcxVNlNpt9LjHMMJF0WIk5lJE8XAcUwydV+gQc4vaDhXC3ygfaoEMOtkhDmUkY+8MfDEghmuJSRajyI2lkQziNDuK1Fhl0sI4fikKNHUht1N6QC8xraqAKfnq3Ik9k68kLEak5LKXnIEuIwwoFsUcAx+qs8EJ2LyNNHgGkOXrSp9R6W5TN9zkiWeeX3DsuCr+69exGrK1fZDkh2cWajbmpYYOmwR19qqZxB9xS2rrpAR30HdXR7k0zLyBmqx6H0Vu1m2wPTy0go6UBPehrRjFEZSUWGDfVOs81s1Ek4KfiW5pIsQ00R+p3JpvrjEMYqGZQaBFwOsbCp+2ma2GoG6L4R1pmNovGN5gUyhZ9lZ43q/cTQWI1tz2b9f1S3j/6dWv1Dz+VCzfwU2Tz76L/q1Oo7Lfq3tsnm0LPN22GoI4JDsGmrjLSYZedAHNoiVnxUcgxuLQtslCU2CVLchsWARL3eSgr9cYXNgKQ1cJdNBt3WadE+IdmCjjG6lZei1jfe8xDVJA5/8RVeBJ0K0bbLSN+YDUfnTdtzl3x2H9PbGS7+Bxr4AXg='
_TARGET_BITS_PAYLOAD = 'eNq9WU9I21AYj/TgZdijJ+cYG705dhooWkQGbofN207S3kapXS/SwKpNZTCPG152kNIdHBvssDJdC4YugochMmTzoLZLW3CwCTbRbjS6Z/P23kv10OSJxZf3QZOGr8mX33vf7/vXpycKhP4DiGWkgI9+k1yEyVEhR7gLy+RCOUEnjxCEjtIrVJwVMDn9p2E4KTpfbz6RZWBX+G+kJguq6nDLDMUG9IYoCunKwL6zZpf2rEBRo2gKCeAMZcuk3KEYZYqmQYVyYp27W38hjQLKrU0owIY0YN1R7FNaNdYLB4aOWxW/4A46nqI0IH6CRH7bgjGNPvrpjgmWVBTIQTotY2OhRyIHa01ogAcyRCMiE1S3YSoeYizJBRmUBGHlrgFneyoGzGCoPxouWvMK10z0fPMZJOELurt9HYKQeQHKU4iaQFcwX0z81R1j/mB6ut6A89HPUMKhVQdlqFgcdYVsyfsfF+NzocdiVK5qmqrKsijqecN0hWzBleFO8SE2FMmpal6Oi4am5Y2SK2RLPlje07SQT1UHq1kCSyupyJgrGzcyNnwTGdpbkuW3qVgMwdpBS2mU4q6QbbR/b0GWfalJ0VjY1DAsvJSluO4O2ZINyE06BJOfMX+QsJqTUEsiV+Tl5PeQKHIy1nvkTaKo2HHAJbONFIbfjKuD75beyxwyWwVyFGqp64rc3s+sdmlX63zI9rwntg3haheA0jaGqrnJ9C+ZVY6B5MhCxKmM5OkiMFwkubpq8gAnRWScqw0+0D5EcrhVMotcyshP1WxRh+UElzJSyZZROwuLUWQIt7XIsItl5FYWcPRIaqPuhgRAVEYbFeHTs4V5MltCXohYzWkp9QZZQhxGOJAtDzlGf4UHojMxePoIFITt8zbVc8CyfKbPGckyT1wfYFnweepfz2N14C/bAUk/zmzUTS2aLB3We8+Xiol0T2HrqjN01N9QR9e3zLSMXKB6HEpv/kO2PTC9jAS6BKV0oxnNGJWRVGTY0P4i28xGnYSTgm9qLs0y1IRB1ZlsSjULQC6QQKnBxOUQC5tSlabJjSegVNtgndkomtp61CRT+Hl21qjeTwyt+dj2bNb/Rx776N+p1e9uXC7UzC6RzbOP/v1Orb7Tot9pm2wOPdusHYayYToEm7bKSItZdg5kgS1iZdd1x+B2YQHNssQmZYrbsBiQKL8vkkJv/WMzILkYuMsmg0PrNG2fkAwBxxh9kZei1jf1sxDVIg5/8UVelZ0K0bbLyNqaDcfxT9tzp2p2H5PaGS7+BzGIb74='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_non_affine_all4x4_remaining_current_20260525_accepted80_packet_block079_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
