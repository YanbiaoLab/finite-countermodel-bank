from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,0,0,0],[0,0,0,0],[0,1,0,0],[0,1,1,0]],"priority":598,"rule_id":"false.finmodel.setcheck.opnorm.accepted_false.04.0000/0000/0100/0110.v1","rule_key":"false.finmodel.setcheck.opnorm.accepted_false.04.0000/0000/0100/0110","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmU1ugzAQhU2DFLcbnCr7Glb0FBCr2ScnCkJEQqx6hAT1IBwlR8iiiyyiuo6hP5FltbHkVq3et7DAj2FkewZGdkAIKchXPNWhajt5R8BP8Jg0acvElSEUUjM2TY5ayExh15sEptILkSls6uFiIdS6H+ToTdifvamTn8mwbAAAAAAAAAAAAAD/l/u2Tm7i6fIhrpImrRZ0y0RclZzeenC2kzZ8DO1oc+ZjM7SwDm3kwdve5mzlYyJfbN4iD84660QGHrwdbM68bIpahzZGsiHZfiHZ8iZta0GvTYXlqjk/xpjMp0I/vmbqjyFSWnJO8kEMv51sK9fojVySLXKN3sAl2QLH6M1cki1zjd7LvjaFKg4ma6bPtXQI9EXCjIXz6ZJudfnQd3Ja6hri9PjQycJZXOmIKfmH4XsAbZSJqjVOorrJOaPPEvxBXgE4tMG1'
_TARGET_BITS_PAYLOAD = 'eNrtmU1ugzAQhV1lkUUXOUKOwkEqkiN0FSEFIXKiZJ/KgVOUFbh71JhN60ikuI6hP5FltbHkVq3et7DAj2FkewZGdielTOVX3EStagPyIMFPcFsuipDTF0NIieZgmoy0kJvCtDfpTKUXGlOYR8PFhqp1H5PjmzA5e1NAPpNj2QAAAAAAAAAAAAD+L/dhVD5V9fquistFEW/EjNMqTph49OBsSmz4GNrI5szHZmhqHdrRg7eJzdnKx0Re2bw1HpwF1onsPHgb25x52RS1Du2AZEOy/UKyZYsijKh4NhWeqeb8GGO/ral+fMnVH4MWImFMZoPYfjvZVq7R27gkW+MavZ1LsnWO0Zu7JFvuGr2XfW1SVRzsl1yfa+kQ6IuEHW+39VrMdPnQdzKR6Bri9PjQydtdFeuISdiH4XsAzZWJqjVOorrJGBfXBPxBXgETzK9y'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_opnorm_accepted_false_04_0000_0000_0100_0110_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
