from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,0,0,0],[1,2,0,1],[2,2,3,0],[3,0,3,1]],"priority":597,"rule_id":"false.finmodel.setcheck.opnorm.accepted_false.08.0000/1201/2230/3031.v1","rule_key":"false.finmodel.setcheck.opnorm.accepted_false.08.0000/1201/2230/3031","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmT1Ow0AQhd/Yq2iNosiiQqLZUCBK6FJQrEQKCg4RoRwjSraELiXiFBwhJUdImSvkBpl16NiYpLASk/dJ9kgey6P5tTwWKP4b++CBrE7vcL8wSU0/dDObUlxhOM9BjoL8yN85swzOubBNftW3H/Xt3TpKPEeRv+hoEnXQmCYLewoxJVbv3Rs8rmcIFg8aT9OMMW9d0KePv7xRadVVp+M5/Iu0PVXneQzd5UIaHkX6zoridhl7oATuBJ3mrE22zSafwGA14/AhhBBCCCGEtJB+vvMbXLn2eGWMzp2L2l1ItuwExuj0cKb06bVgvOqzYlgt1ZxjqE6JPza5bW61WG6S/kch6btb4/1Ij95urwk5QrMpRUJV7FekbwdY2wDzhRv9'
_TARGET_BITS_PAYLOAD = 'eNrtmT1Ow0AQhW+QK6TMEShzBE4RUaaDcoM4BkIcgoIiSFukSBdKlIJsg0SFLBThVbT2PGaddGycUFiJk/dJ9kgey6P5tTwWKPYC+2CBsk7v8NoPSc3CLEufUnxiPCxADoJs5N+ceQbnXFgnv+rbq/r2bh0ZnqMonnQ0iToYQpOFfQsJGbrXy3dMOiMYj5nGMzRjzHpn9On3lzao9Oqq0/FsTiJtL9V5GEP31ZeGR5G+s6KY92IPZMCbYNWctbt1s8kAmHZHHD6EEEIIIYSQFrIotn6DKx8WD4zRufNTuwspeyvDGB0fLmQ2vRaMV22Zj6ulmnMM1TGxY5Pb5laL5SbpfxSSvrs13j/q8b3da0IO0GxKnlDl+xXpzT+s/QJY7FU5'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_opnorm_accepted_false_08_0000_1201_2230_3031_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
