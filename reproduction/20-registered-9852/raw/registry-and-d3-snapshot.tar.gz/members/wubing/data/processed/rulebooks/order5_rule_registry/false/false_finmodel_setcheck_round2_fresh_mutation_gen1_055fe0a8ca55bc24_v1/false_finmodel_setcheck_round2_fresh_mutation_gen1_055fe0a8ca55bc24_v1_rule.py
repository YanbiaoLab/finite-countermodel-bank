from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,1,1],[3,3,3,3],[3,3,3,1],[3,3,3,3]],"priority":641,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.055fe0a8ca55bc24.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.055fe0a8ca55bc24","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgDhy4zcswCgYpqGEU+CHPgUXiwZ/P/Xrf8rHI/AcDfkwJBRhDAH96eFu2dW1O2NmkHiGl0QgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBgFo2BEg3///zMDqYb/jAx//v//Xw8agGSklWUH/svDmA04RjmpCH4w/flvLwi0SJ2p4cB/BwYFJpAP+QWYaGLbf1yAnQaWLVDdeLfM2Hjb7by0NpXJnR0GxsVp787MMTwmQQuv/akHppL/50Ge+fm8/rf5fzC//H89LbzWgDMgmWlg2wdcltXTKLNhB/xDvhypIKHUeLD6/799jAyjYBTQEOxj4PjDz/KgnpGDQeGDvQBoQpXp33/mBoYP+xlYGMDzcg4MDIzA6s6B4Uc8AxNYOYMCQwOwBEJMthFbs/18Lh/75r7Nx/PXp9eXbKz//PXoP96Lwsf+pc/78fz1aftdN/b//JX0v+0FZ/J/Y/8/n78+BSmvqd1Y7/ylZeN/SRJrtv8UARJLGwCh/jtZ'
_TARGET_BITS_PAYLOAD = 'eNr79/////r/xAF7lU//R8EgBc3/3rM/+I5FQp6Zp+Ai5wQsMgxg8AFT4j6M8R5/ehDq9AqavNJobvHbu6MRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBiAaMDAx/gFQ9w7//zAwMDA2gAch/tLLMnuEBjFmPY5STioD9LzPDgXdAi278rbdn2P///l+QDz+8/0sT2xhwgR80sCz+lp9S55kznioTZ1bezikrP3+mZ6agcfI5y+e08BpzAzCVMBiAPMMm0cByggHM72BooIXX6nEG5B8a2MaPy7IGGmU27ODDkC9H2kkoNeRDGBgd//0fBaOAhsDx/3fmD7/lG/59/3+f/8B70ITqX0aGP/X/+R3+//4Pnpfb////P2B1t/8/+4L/f8HK/9//Xw8sgRCTbcTWbGwSDxYJKxzmM9DIaOj2a+DhsmL8pPfGknFGIruEiMkBV3UHNta5DJXi3+YwnNnAzMMlBVLe3OTXsIe72o/hGYk1GwNFgMTSBgCqczXd'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_055fe0a8ca55bc24_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
