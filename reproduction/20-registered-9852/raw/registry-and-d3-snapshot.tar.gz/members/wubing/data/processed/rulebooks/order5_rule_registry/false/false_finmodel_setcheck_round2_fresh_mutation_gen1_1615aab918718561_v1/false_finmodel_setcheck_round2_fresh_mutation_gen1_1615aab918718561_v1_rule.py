from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[3,3,3,0],[0,0,3,3],[3,3,3,3]],"priority":661,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.1615aab918718561.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.1615aab918718561","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2bFLhGAUAPD3eZJyDXlTBIfKNRQ0tDRcVChH4V8QNYVNjTW1hd8VRLR4NLe4BK3X2mDQ0L/QErbdcnBBg4X50jvqhrroIKPk/aan8vn4fD4/UQYAHL7H9xmQ39AA0CvDDYnc3WfjThlmiMZYLH02Qn8Lvj6dGSic2VQtQgghhBBCCCGEEPKz7Pv30GfzbDFHU+O8Hwtm/0NcHsSIozZAHT2IENGZBsQ6wEgmyXxEjpoauYXoAFNjoProdK6kLLKFOICRRTbE0+bxzNztytRhnCa58RrW5Nn+TlHIotla0P3qLyfXtFCFpSQ089Js6V24uhe2nYvxbrW2rhGf1mrns3loNqGcPD0kUe81m55ULWAg5KBs69WBhz78nwoqZVBpxfwLzSYClBgcyenGstjbp9TysbJZCy/adgvdjWL70bn0TqxNN0bpYUL891MLZbljcI4lkHUfQUjKx8JkMc3mzeQVyMSMIQ=='
_TARGET_BITS_PAYLOAD = 'eNrt2bFLhGAUAPBnUg5BB7fclrT0LzQEObTWGrS4NMe5RAR1n7Q11diUNBX9BVIcSkU3tDQE19ChchBNZ0OHhuf30jvqhrroIKPk/aan8vn4fD4/UY6IDL9HUTiS31BGdBrDDRG1nVF7yh9miMu5EH42wnkLvj6dJfuMG1QtQgghhBBCCCGEEPKzjMn3UOFX/CJHU2OsH8dW/0NcHggAzwZiBVQUAUCvI0AF8SWTZAoAA9cTtY64Cakn9BTQC3NhFtkkGMDOIhvAyuLa7fX06d2GkCaZUcvm/fLWbjvOotlK2P3qHyTXtFPD8yS08tJs6V14si0V9YXHbrX2ZwHGjqtLN3lotriZPD3CyOk1m5NUTeYY56BsR7WBhz78n5IbTfRoxfwLzRYhtjiuB+nGWdTb51fzsbKZlyPuXgm0w3ZxXJ9XV80DTYBw4iH691OTgqBgMwYtDBwFME7Kx6VkMc3mzeQVg63lBg=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_1615aab918718561_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
