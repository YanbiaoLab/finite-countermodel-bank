from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[1,3,3,2],[2,3,3,3],[3,3,3,3]],"priority":651,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.1f8cea26003e7140.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.1f8cea26003e7140","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmL9Lw0AUx1+uKSYieGl1EMQmof5CwR+Tg9CzpNJNUFd/IP4BrorQq3TIWEFQty7uzkU0g4Nu+hfYod0cHDOUnBeLTlUUG1F5nyE58sh9eXf3vg9OAQAOn8PzFEB+gjKAaX/tl/14n5/KtwlUxiveNiNtIhtKPOhKtAmYrwP6oSSrUa5s4m4hCIIgCIIgCIIgCIIgnaVWf7uH9Iar7gWuyJ8gEIYuX0UXoCmEKABYJR6VmCdSRJ4SkwJwKSZ6w2tuGpWaL94hE4WanLf/XKt4YpkEcnx1JDNkBJIkmmI7zCUMI33qONdhsVHD2so6JZrVolA7mpzOE8LTMQ1OnISRBAI9rgsskl3jorC+tOrcNWZnjHCzNhavbyZ2jaxuRaG2E9w3dB2q85ZSS609PoBu7tlThCoRFVsoxI5H061iMxVnqZ4D+x/4yNzcF06vPghDaL2/AK4CGAq4L7bhqK1vNPsWV/9wbpeku9mbrhXiGhl7ypThAJh05hhvWaTdWV9mK6x4y9XtM1iA+EgswSjk2cAMSCORekw+OrmUfneYERf9ZthwGNEI6L7sptJI2hjXd3vCM8QdkLc='
_TARGET_BITS_PAYLOAD = 'eNrtmL9Lw0AUx6906OjgZof6F+imQ4co0tndpZsKBR0zFHsF0dU/oIjVVYVuRUM8wcHJKij+Kk0qgkNtcwVpIm0vz4tFpyoWG1F5nyE58sh9eXf3vg/OBQAKX0NRXEB+gkUAs9TbL8vNx1A53yUQv4wrGSa6RLJuM/Bc6xIw3wb8U0kW4dTdwN1CEARBEARBEARBEARB+ksk/H4PqdzG1ClckT9BgFi2fKVUgCAhJA1gJKlfYgopC3lKTA5ApRipe9fc3C+1EPmAQz/U5LyVaSeukF0RkOOJhMyQCagKf4ptYb9mWcVZTYt6xcYtY13Xklx3/FBLnJ/mhaDFtgNzWs2qgoAnVQXmy65Rkt7MbWujQycFy9us7F50/GLV0m3DD7W1wMiQbUPsyHAj5a3BYbDNldKZ4K5PxeYJsfnrYqfYTFfLhfeh9A985Pi4h9Nr38MdWu8vgLYALBfUV9vQWp1vXH+Pt/5wbpOiEawXI+mmI64GDhdhCZh05jbtWGSpv77MdlhqjLYyM3AAzZt2jXHIs4cCSCORekw++rmUoYaXESUV02s4TDgC7JDsptJIuhjXd3vCC4hU4HA='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_1f8cea26003e7140_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
