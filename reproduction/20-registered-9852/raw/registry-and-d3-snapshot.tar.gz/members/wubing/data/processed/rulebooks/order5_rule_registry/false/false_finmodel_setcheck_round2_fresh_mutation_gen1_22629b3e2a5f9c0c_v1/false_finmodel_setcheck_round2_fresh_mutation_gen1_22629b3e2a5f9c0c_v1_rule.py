from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,0,0,2],[0,0,0,0],[1,0,0,0],[0,1,1,0]],"priority":633,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.22629b3e2a5f9c0c.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.22629b3e2a5f9c0c","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2U0KwjAQhuEv0oXd5QaG4j3M0p1H8CKCOYJH8CgeqwtxbFIFF1osKPjzPlDatJkMISWFqZOUhM+yk0IzLmTjfDubjgqppWZy70G4XvjhAcJtXwAAAAAAAAB/7GTK9UnXHUcz2+Z76V3JDrZ2tar5XjF1yWwlLeVdn/7lWntgwbKPUqm8I1VpXGrT6Tem5pVCPpW59YX6oAlLDuB5MfbfsLyZuFB+0cXhiO/ZZM4w0i6j'
_TARGET_BITS_PAYLOAD = 'eNrt2U0KwjAQhuERFz2WR/EIHiGCF/EI7lzGe0iJN8iuLkrzaVIFF1osKPjzPlDatJkMISWFaZLkhM+ykEI9LmSVYnU4jgpppLq79yBcL+LwAOG2LwAAAAAAAIA/NjHl+mQ6H1MzW+Z77l3JZrZOjdr9XN6dk9lG2iqmPv3LVfbAjmUfpVV5R9rSuNSm3W9MLcqFfCpz6wv1QR1LDuB53vffsLyZpFB+0fnhiO/ZZE4brkKT'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_22629b3e2a5f9c0c_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
