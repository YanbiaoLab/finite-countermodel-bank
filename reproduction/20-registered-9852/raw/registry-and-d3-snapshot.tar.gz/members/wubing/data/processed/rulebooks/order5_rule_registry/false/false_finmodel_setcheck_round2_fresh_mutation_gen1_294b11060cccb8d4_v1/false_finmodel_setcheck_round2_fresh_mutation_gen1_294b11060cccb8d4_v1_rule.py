from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[3,3,2,0],[2,3,3,3],[3,3,3,3]],"priority":653,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.294b11060cccb8d4.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.294b11060cccb8d4","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgDhw4wMgwCugBJjAwKCiRpuXP222//5+RIUVLPCPrP3YhLBIKMIYAXv0ODwQaGBNGY2sUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBRQFyQ8hTMPsFo22oyGyJAA//4zcSgwMDCyKDD8+f//f70CgwNo6JmJJpYd+I8L0GIM+8fvt9//n137f//s3V/v/k9//+7M3L2//9fPKRSjhd/+/1/zb/Xqb/dT0p/9A/nozFrB4O/vpxV5MdMksyk0sigxCXkoKIEzm4ISgwtDB4NCy9BPkA3ARLj/r/3v1/v/p0PSxuW/u3+lv/zfT4s0cmFThNLqDs7JmUpGSZNOuvjM6BAQNkzy4khkoU1m22WjyOgwXV0FmtkYXfyfuDIoDYNyJMISpxRGWfJgkQyT3GjROxgyGzCZCzIydHCAOC6QNN8g4DQ8aray23/r0979f/tqVe73/zN37soClczmxyXYh7zXfnBpfLCf0PBfVIFjwYH/DkwcTAycP/7z4yhIOCi0DQCQvKaz'
_TARGET_BITS_PAYLOAD = 'eNr79/////r/xAF7+3//RwE9QP7///fvkqaFWciThcH4MSlaFvz7xfjjLRaJ+zDGe7z698u/r/83fzS2RsEoGAWjYBSMglEwCkbBKBgFo2AUjIJRMApGAXXBfCk40/7XsbrDoyEyJAAjw9/v9/////f7/n9mBgaGhvv/94OGnv/SxDJ7BlyAFmPY7CxCHAxGQQwOKS5cSgwzBASNk5xYGBqS+17Swm8MDMGMISGcCrNnSDKCfGQc9G4Nh0Bm79Y/NMls9+t+3/37dvv9u+DMdv/u/93/y//frx76CbIemAgdmA6wiDgwzICkDR0mF9YZYgwFtEgj+r7L74aUf8uZdvfs3Fyz3ZvTy9+/OTd36/d5v2mT2VwP3/u3P+PGbWhm+7d7g/Su/3eHQTmy/BhOKYyyRD728d+Ho0XvYMhswGT+7t//8u8gzm5Imq9/v3d41GydKkwNMwUZhERDJ3EwpLm5TgWVzCcsnv8Y8l5j/3qd/0B+PcOr+9/j7Rn2//3+9/83doYPOAqS7xTaBgC7tcp0'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_294b11060cccb8d4_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
