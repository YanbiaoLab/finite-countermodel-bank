from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,0,0,0],[0,0,0,3],[3,1,0,0],[0,1,1,0]],"priority":644,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.2a1c8f64a2de97c9.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.2a1c8f64a2de97c9","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgDhw4xckwCugBJjAwKCgxMDCRoOXPyU2/9vdIkGKL/fLuf/yVLJgSCjCGAF79Dk9DpmimAPU3CCmNxtkoGAWjYBSMglEwCkbBKBgFo2AUjIJRMApGwSigFkh4Ch+zOuBq2WrDNBokQwH8+8/EocDAwMiiwPDn////9QoMDqChZ9rE3oH//zfdd4v7OzX8zPL/IOC2Zl7E381JJ5bTwjYP4VSRQImFHWpailMCXRJbnLhaJbgURVicBWhh2///a/6tV/72PyX9yD9QQJ5ZKhj8///kIg7m0cxGCmj4/9/f8qj9rhfLp7uD08jTwD+LJ7g7/uFnpIFtF4xm6aye4Dw5VbQoY9FJJ565AlrKZklaHI8UaJPZpv+1//Tq/54ku78gr5knfQUmFnFnO9YhH20RlsRHz4NFc5zkGBlGwcBnNmAxIsjI0MEB4rhAypQGASfsipXApYwgJOIUWgQGud/+pUT+jXd78//kqY7Ur/WSG2d4KS/791/9qAAbptof9ZuMkkDKdZZd6lj5/7+nYctgTp8/LGO/1J9Y/L+Yq7Lk4n/F/jiOo8K//suz/MQSJw/+AzMbWLm408eWf//ZHe1YSLMNAJ/Sqzs='
_TARGET_BITS_PAYLOAD = 'eNr79/////r/xAF702//RwE9QP7///fv/v//lwQtzGa+rA7Fz0mx5UBECeOHtt+YEvdhjPd49e+XWp19bTZQf/3bu6NxNgpGwSgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCqgF5kvBx6zsdx2rOvx3NEiGAmBk+Pv9/v///37f/8/MwMDQcP//ftDQM21iz56BwVdh50KmrBXGEQwgsDM4cTmTz1zzCFrYtv3NrNfrnseV37x6L3vd7nnVe79WPf967/XvPe9pYRsDQzBjwB1OhtkzrBlBAWkc9W4NA0NO7/c/o5mNFFDPwLDhmNUBV/GIjB3gNCK1jjkmf8c+5g//aGCb/tnUyyH5e3JmveqdHmu293PS+6t3Ts69+l32Pm0yWwbTAV5RBue5B5lAXjsxlwuYWF7sOfhryEfb8mPER498bPLeh//+j4KBz2zAYuTdv//l30Gc3ZAypf79XuyK74JLmXeQiLtf/X6Q+41x9jKmBTuFGcxMy2dxNTzzS996J5KR4YbV+5+YatkbfM/OBSm/HKlbHsbAsO1c9WBOn+zHFnE3mMcw9Hxt69ZjuFew8LvVG1aGB7/ZsMSJPAMws4GVv9jLV83I8GPfwd+k2QYArJ/F7A=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_2a1c8f64a2de97c9_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
