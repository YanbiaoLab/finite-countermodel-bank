from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[2,2,2,2,2],[1,2,2,4,2],[2,2,2,2,2],[1,2,2,2,1],[0,2,0,1,2]],"priority":639,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.2b605ed61b50ce9a.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.2b605ed61b50ce9a","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmDFLw0AUgN+lgQQ69IqiDsW0Qchf6GBJFcExq5M4+BNcLIUE6WBBUHAUquAPKPgD2iBdHESdOgkRKQgutSC2NeR5CRSXIhU5cHjfknAH+XiXd+/BYwDgwWz4PgPin1JlfGjoUzaC10EHN5wpOwZApE37Vn7ywn9UlgPusR06eoIgCIIgCIIgCIIgCIIgIEKI55PxDDlERDde82TJfDSU+MmFQ8gwI9EFMET8wLsm4hm+xza8fWx/otsaLciwocvmOVyAwsWZItoc8lBWQM5wPsDmzYppXm2Z5nUcmWWu79aO9EKNy7BVc3sjo+yjA2oxcD1NhcNGiBpIkYnEMNqrpdHz4thK/pp9EKbH1svlsQxbH7s9dz+L9lv2KZbNlQqVAZ6fOLqcy1ZMQkx9X7aMtPT3td9kb+qPtqUkMtDVWbIXcrBMpZeQSgv0MKMGLtMh3xflWHQaJcKUnIbjd3t1rDfCZvrh1IqsyiC7tt1Bt3a/KaWzicJli0rJkp466XaySskXEn6YRg=='
_TARGET_BITS_PAYLOAD = 'eNrtmDFLw0AUgF+IbUWoXQShiAGnTioOLkXS/gChP0DQgqOgINShSAKlLv4EB3Fy7SiINtShfyEgaSIdVJReh0ICafK8CxSXIhU5cHjfknAH+XiXd+/BixHRwNnQ9RiJf0ojZhnPn7KhLWWLcN+asuMhKsG0b7mTF/ajsq0xI76moycIgiAIgiAIgiAIgiAIAhVAMZ8UM2QVAEyxZsiS6eBF4sm4g8tgKNGFmAGYh80KwCEsCBtsrZXmwCyn32XYwIw/GO5jxPiZAlgMXWxHKGc4r0Fl+9lxdm8dZ0dEZjsPV/VTv1dnMmyN/mXaa+vQwrCrmUYQ4llVhQClyHhieKWnTnrlLWUnf806V0cpe3nvRIYtB4W8eTEAa3GwKmSfnV4zCwfHLV/OZesmIY6/L9tQWvrrwW+yd/xH22sSGfrhLNmLfXyh0ktIpYy+Ogw1M/bRzfFyzDtNpMBYTsPRC/ka1KpqZbR+ZCt2Mzt4vCmCWd+4k9LZeOGyeKWMk5466XaySskXOgLY4Q=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_2b605ed61b50ce9a_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
