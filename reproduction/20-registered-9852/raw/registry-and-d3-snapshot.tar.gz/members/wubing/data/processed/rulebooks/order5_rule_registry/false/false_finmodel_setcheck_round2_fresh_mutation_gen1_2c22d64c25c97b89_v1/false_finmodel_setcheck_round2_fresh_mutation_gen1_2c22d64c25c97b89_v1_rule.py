from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,0,0,0,0],[1,1,4,0,0],[2,2,2,0,2],[3,3,3,3,1],[4,4,0,4,4]],"priority":646,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.2c22d64c25c97b89.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.2c22d64c25c97b89","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrdWD1Lw0AYvnwYU2htcBI6GKSUjh0661Ec2s3dJWMH/QeCV8RRKMUf0KHg2snVcxHcxKmb/QEdHB0KMaYtVZI3JOTyDL5DwuVJ7sn73vt1d8s4Y5KFUg+vfDUw/w5a4SAcXjFC5gaFGBTS3ycA/k7NZVHAkAIEBayVjJEx+YmmEYBNfcHJuXQKaK3vi4gq6z/2DEIVKzKnS6qq/cbpv7O3b5PvBiL9Q4aTL98AsvnXQLK5XwWyLX0NRyYCzU5gbJ9aTJwUJi/VA49OKIpFSnaDC7fmefeoBGO7LJXqMLJxz31twNgmd+03mI+IycCqaTYu2IByjCSTEslGtkSFSA9ZRj2kZqyOJBNQ9x9CDdlBkvGkfl252FBDQn3Ehap2j4w2MTKBbGeBLXEr19Ft3MpxzgY4Uzaxwab922BDej8TDpLNgdpSB1c2oGArW/Je9Gmp9ERjntizeg8fSlUrl5PQxVRpAy0aSVlLVB6VJrVhOwmdPltKDUnPJve2R56qgo0O7VlgSAsVbD9EjuLIJ31AFpBixiQyKqKymWTytJWXPQFNng50W6AjOxVJb+9nUeUW2ZJDRLqr204MVItJmTGv9TMHm5sq2Dw3g48lLI6Taj1zu42ZoVPJ7TabAxJvF9GPbA5ILpBtpKGl6vmMfFHJ6RTVTfWInWavbDG+pkef6ZWcW5VvLtdHXg=='
_TARGET_BITS_PAYLOAD = 'eNrdWL9Lw0AUDnRwdOgfULdO4ia4eK5OXYUO/QOkFBxFeoL/gQ4ds7i7tYOU6NyhYylF4lBwktQWGmOSO2PaUiV5ISGXb/ANCZcvuS/v3ft1dykNKZkMZRJejdXA/TsYhoNweCMJqXgU4lFI550AjH1qLocCWhTAKWCtZIw0yE+EIACb+sIg5/IpYLi+lyOqrP9Y9whVnMicJqmq+I3Tf2dv3ybfDYRprxInO5oHZNOugWQVbQZkK2kCR8YDzZ5gbLsiJk4Kk6PZm04nFMXCmLzChdvovveyhLHdLpcTGFmjax6OYWz1i8EBzEd4ve1MhY0LNqA8I8kYQ7KRLVEh0kWWUR2pmZwgyTjU/VtQQ/aRZEZSv65cbKghoT5iQlU7R0Ybb7pAtofAlriV6/s2buUMQ7Zxphxhg03822BDer/kFpLNgtrSB1c2oGArW/Je9KSk9ESjktiz6md7SlVbLJLQck1pA83HSVmLz0+VJrXWIAmtHTtKDUnPxj62R56qgo0O7WpgSAcVbD9EluLIJ32AFZBiGiTSLKKyuWTytJWXPQ5NnhZ0W+AjOxVGb++rUeXK2ZJDRHqr21cMNI1JmTGvdTIHm5kq2HQzg48lLI6Vaj1zu42boVPJ7TabAxL9E9GPbA5I7pBtpCdS9Xxevqg06BTVS/VIPmavbDG+5kef+fOcW5VvHakp2A=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_2c22d64c25c97b89_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
