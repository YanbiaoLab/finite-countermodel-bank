from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,0,0,0,0],[0,0,0,4,1],[0,0,0,0,0],[1,2,2,0,2],[2,2,2,1,0]],"priority":643,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.430d850c4a301763.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.430d850c4a301763","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2b1KA0EQB/DZi5AphKwgKBi8jQiHWNhqIZfCwkqws9R3SBmSRVKcsQhY26T1IeQaGzvf4B4h5QnnTfaKqOAHWizo8f81N7Aswwyze8UqIrL0M2mqCP6ovtJ5yL/aEipVNvUnC2YR6G/3dzNt1TlaDwAAAAAAAAAAAFTKa1iIyNBrslTCRWhdMml5zXZ28NJ7Sqa3g/FO7/SkM3nkh3gcrS5faB/Z3rWudKXFXkvLZO9q2wQ3x1smrRoZme7RKGEa/f+BdIMRysbhs6zdRVVpsntZXIsk00kdDhu33aep3g5bkNXj+WZ9/8ulxofppTZt4uoFr+6Ji9ZSNlRMZhbr6kE1KKVha1BazjyLrZUVYnf/U8BEKnd/U+Ml2xwduFof'
_TARGET_BITS_PAYLOAD = 'eNrt2b1KA0EQB/A5D7wyj3BvkM7G5vAhbNNYCykSrwiyEcu8g5Z2gpWFRY4U2lqIHIjuSQQFwQ1YTMDcjntFVPCDWCzo8f81N7Aswwyze8VaEVGymCSxAn/UrjVRwb/aUlgbTM0XC3oemB/3D2Oj7D5aDwAAAAAAAAAAABLQWxgSUd9rsoSKeahcMpp4zXZwujRopq2Nne7l4PDopr3Cq1k3f3zeMz6yfWhd4ErLvJYW0/nWlS43j691UjUy18OTXsrS+/8D6QajoLvRMj2s51VpdLEddojSVrsOh43H7jO174etjOvxfHN/9u3S7NP0ylhucfWCV2vC4eQl7lsW3chM9aBaBjRTNSgtYm5kStGTsLv/pWQRG7m/qfaS7RUuyBcX'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_430d850c4a301763_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
