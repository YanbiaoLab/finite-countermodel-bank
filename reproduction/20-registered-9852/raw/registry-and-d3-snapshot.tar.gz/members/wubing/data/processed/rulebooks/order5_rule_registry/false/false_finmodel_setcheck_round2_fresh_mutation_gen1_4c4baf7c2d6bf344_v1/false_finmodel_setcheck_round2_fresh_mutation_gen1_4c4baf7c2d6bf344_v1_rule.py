from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,0,3,3],[3,3,0,3],[1,1,3,1],[3,0,3,3]],"priority":631,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.4c4baf7c2d6bf344.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.4c4baf7c2d6bf344","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAYBUMeLOk06tLoEaCKWRoMXRAGAeMUoHgUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCugIDvzHBRhpYFuEeGzJRe6Fc4q61KcE+31secR5VLhLXcTOUYAWftNc1KHEpSgS6KLYotSl0RLAsVDASbGlSYGDaTTeR8FAZDZ2MPWHH1Pqhzy6yH9mCm37ATahAZSX+QmpfQBSxTwaQ6NgFJAFNDxVJrq4sHiqCAoqdqooKbm4dHQICCq2CNCkrgEASCxECg=='
_TARGET_BITS_PAYLOAD = 'eNr79/////r/o2DIg+iys6XXi99Txazr/0shDALG3YfiUTAKRsEoGAWjYBSMglEwCkbBKBgFo2AUjIJRMApGwSigI7BnwAX+0cC25S8Wdet9iUvuLb2RvWYjX7XsN6s3pTdeH9z3nhZ+uxZbfvfrvdfrdt+rvlt6vXr997j3e+9V197//nc03kfBQGS2H2CK+QOmFPsDdBGGPxTaxg42oR6Ulz8QUisPUvVnNIZGwSggC1zfdjtv9+7f226/e3ev7Pbdu7t3l5e/f3ev+j1N6hoABFQtLA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_4c4baf7c2d6bf344_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
