from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,0,0,0,0],[2,0,0,4,1],[0,0,0,0,0],[0,2,2,0,2],[2,2,2,1,0]],"priority":626,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.5bcb2af0194a6600.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.5bcb2af0194a6600","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2TFLxDAUB/CXqjSg0opDbzhMNzd1dFDiFxFuc3RxFBpcHG640Q/gJ/ALSBB0FSdH6yA6OFQPpZXQZ1o4Xaro8EDk/ZamBPr4p0kDjQAAAz9jrQD2R+2LuFSyoyN349HK625HjxKiDuOOjnTSiL8tuZXHRgx46BljjDHGGGOMMcYYY1DjR9MhYkZazKKaNI0vhhFptVI61NYXCnupRQjm2oQRrJFUw2ymzRU0Y4qoAVK6H/M5foWimtM+kT7zTx+Wd1mVPK82CROcpQjo35dCvVlh8rbcJtIHboj4cDyiiFZEZTPp23lxiLfCan+PykVEi032/SUUn4styP/H8U1v/RezF/qwxJ9eRuoUpIum80xISAsdNweqQY1ThmZnq+7V9uPNxtPl9VG2d5KNX87r+avFi3qHZmeThTYGF0C2O5sEEKX/gqUk2d4BQGulEQ=='
_TARGET_BITS_PAYLOAD = 'eNrt2TFLxDAUB/BXgi3KaQcHxcE6OomrghS/gJ/AD+B4ww0ukoCji6Ob4Bcx6OCobm6N3HAdxBY9SFGbZ1o4Xaro8EDk/ZamBPr4p0kDjUNEiT+Tpg7ZH3XoisjYjo5E9Pq308cdPca5oCo6OrJJo/i25HlSSHfKQ88YY4wxxhhjjDHGGMMAPpoCABRpsRTMpCl9MShJq0VWgE59oWqUpYD1c5uwxGuSaqBe2lx1M6YAGjGj+zGfwFcoqgntE+kt//RBtKTCfPamSZjDmCKgf18G9EUI+dRdm0gfiAHAwm6fIlpcRs2kb+fFPiy7VPt7MKIkWmx26C+V+1xsdfI/jm9GV7+YvTjEe/70MlLbaEX5mihnMYt10Ryo1gG8SZqdLVw0Z/Mrl3Prq3vqaEf1ZjaDp7WHjeCEZmezsZYSHtG2O5tFdJH/gmUk2d4BDBXMFg=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_5bcb2af0194a6600_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
