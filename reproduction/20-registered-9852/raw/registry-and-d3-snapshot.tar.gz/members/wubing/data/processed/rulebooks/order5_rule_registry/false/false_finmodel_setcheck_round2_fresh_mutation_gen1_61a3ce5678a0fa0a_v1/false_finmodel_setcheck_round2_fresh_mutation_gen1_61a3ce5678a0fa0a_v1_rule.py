from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,0,0,1,0],[1,1,1,0,0],[2,2,2,0,2],[3,0,3,3,1],[4,4,0,1,4]],"priority":629,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.61a3ce5678a0fa0a.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.61a3ce5678a0fa0a","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrdWbFOAkEQnV02sjSEw1bjBin4BGPDxFBg56f4B+6RmEhjLsReCz+ETyFWlpYWxFXOKzQweJfbe4VTXLJMlsfMvjczt9wSEy0VbWyYPzl/kvm9cPkiX65JsNVYCZ62FhzTvuDgmYTSlRyZ5PCSowhyhz2JHiXFaKUdLMJLWaFraas30tbCYbYcTgxV/fTLZre+a6ctw5hw9h7aQLQQQsuiwFYhTPpJAkJbh3DzcqoxYP6E6Bx2am+PeyQW3e67ZywXlMi2TImOYaGNkulgDkPrqKITIcxdUmpgaM/zwQzGEW9SShRMbC1gPaaPQyDYRmw4E0eiZsSmgWArZGTAIrIRG5T+GTSRF6RwYLxvXo9uFppIhQRz0NAehsBC4heTvoJ17SuNPDmtLe7kmIlw088Iyn+l/q3YDBLM9xiI1oPmEjn8EEM5gu1sf1z9vEZNtHzP+E3Yu6ihHVlgU/dDBawzmUPWme5eoMiqZ5lxX+OlP0CJzTSgfJEivoESI9+ELxoYVIwRi2cnetvz0OLZg74WaOSkUvx/xOUyyTVLzVTOmi13lLay2FypMNhV4Fjtw6lNG9PUL9spthZy5sqgM1cRklaluK7rpZdlDnM5sVVJihW5pkt9VK1mfwLCvz5e'
_TARGET_BITS_PAYLOAD = 'eNrdWbFOAkEQXUNhaWll+BQ+xEJ7Qy42mJjA+gd+ip0UxAyN8RMoTrJGWzlCw2KW3VHOKzQweJfbe4VTXLJMlsfMvjczt1wzMXcCbyzNn5Q/2f1emHyRL1ssWHscBM/KC47hTHBQX0JZSI5EcmjJUQS5w85ET5BitNIOEuGlrPCttFU7aWvhcFsOI4Yafvpls1vftdM6asw4O1QrIJpSam1RYG2lRrMsA6G1lLo5efYYMP3C/Ag7taPzPRKLbpeLJ5ILSmTrDJhfYaFNsuG0B0NbhqITIczc88DB0E570z6MI9oNOAswsa2B9ZgP3oFgG7HhTByJmhGbB4K1kZEBi8hGbFD6J9BEPnDAgdG+eT26WWgiAxLMQEO7SIGFRHdHswDr2nceeXLeW9zJETHjpp8JlP8h/FuxOSSYnhMQbQ7NJXL4YYJyBNvZ/rj6OY6aaPme8ZuwV1FDe7PApq7TAKwziUHWmcVeoMiqJ5lxX+Ol/kCJzTWgfJEiuoESI9+EdxsYVJwTi+cyetvT0OI5h74WeOSkUvx/ROUySTVLzVDOmi13lLay2EypMMhU4Fjtw6lNG9fUL9sptjVy5kqgM1cRkg+luO7rpZdkDlM5sVVJihW55kt9VK1mfwKJsjLY'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_61a3ce5678a0fa0a_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
