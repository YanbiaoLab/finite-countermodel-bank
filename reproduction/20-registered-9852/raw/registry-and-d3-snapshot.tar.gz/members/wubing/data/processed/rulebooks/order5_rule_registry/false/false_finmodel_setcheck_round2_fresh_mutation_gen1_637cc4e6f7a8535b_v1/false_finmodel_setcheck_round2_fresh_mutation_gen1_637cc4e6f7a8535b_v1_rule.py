from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,0,0,0,0],[1,1,0,0,1],[2,0,2,0,0],[3,2,3,3,0],[3,3,4,4,4]],"priority":642,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.637cc4e6f7a8535b.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.637cc4e6f7a8535b","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WbFKA0EQnb1czImSnCGghcURUliItlZmlRRGG0sb0U/QUhDcRlBs5PAD/ACLfIDFgeAv2F4jWKZMEVzj3SlIduKF7L0hXHI3yb283Xkzk8m1kERRhb5tPTlGyZEayVGmJ4sUJCfJ6VALMlqsa2YHnSwzjkHIOCKHcdA25+hxDnXOeRY5x2OL4UhlzrHG3Ut6nIfl2M9A4jEqZe6jGRV3zPGYPhkIpVeCcXjvz+09cn9eBsRbpBMrEcQGCdgVBoxSajUMWJyiCQzaMAFrY8CUblf1CyhEqK/f3q8ulkBon3rrwwGFCEVvZcLZQB80b288ENrJcrclfBBYfOAI3EI+3QF3TSFDZCS2ChDtUwPBwGILkdu2gASLS/02Dm2dNhyc2GrIhewhwehVVFb7MLFtkSrBqK0gkxaVgMzoFBojD61wr9kE6U2FnXq30wFROwxlMI9qfmi/7gWEaknkDjJG1rpItDKwrxv9yL53cWgN5DoqX5KAkfOdiUMGy7aLXEiJZEYekhr9M4kZWu2O4smTGPVsldrl8WR5WC3panN+or9lNan910baVf0276qSbW3w82NSo0cV1Ua6vvqdoltrI1lm0r6y+Ul4EQ1fgws5WffIdhFS7LffK6CR9dl7Ctf+tIsFK6IGZf8fmbK8oQzFM6aao3Tz7vIVPW/G2piK7cxUzscvBaZkM1UbmSor15tn7qZdjkcRYfM7IIH84u7xm1SAzWWaE3mCxCjNKZZXCjZFyVyXplqUTCqGGuAs5GE2Xc7+Aql0eZE='
_TARGET_BITS_PAYLOAD = 'eNq9WbFKA0EQXUmRMqVgc62/IAhX+AEp/AA/QA4bUbBZQbDUT1BsLG00FkE3VraKhUUIV1gohHgJihdzuR3j3SlIduKF7L0hXHI3yb283Xkzk8mOVkRun77tITm6yZHayVGlJ2/kJyfJaUloMpojumYHHb8wjrLHONyYcdAN56hyDnnAed44x1qT4UgDzvHI3UuFnIflWMlAnDEqA+6jGZVozLGWPhkIpVf8cfjwz+1Din5e+sSbKxIbEsTKCdguBoxSal0MmJOiaQxaKQFrYMCkaPTEMihEqCIWF3b3X0Foc+J2PgaFCLmLA8JZWZy3trZDENrxS62pAxCYcx5r3EKubgJ3TSJDZCS2PhBtTgDBwGLzkNv2jgRzhpUGDu2B7mOc2LrIhawiwWhJ958qMLHdkhzCqD0jkxYNgczoCBoj603vstUC6U169U6tXgdRO/OU/4FqfuiiE/qEaknUNTJGHmtItAGwrxv9yN6IcGht5DrKQJGGkQviiUMGy3aFXEiFZEYhkhr9M4kpWe2OnMmTGLlildreyWR5WC3p8u5jor9pNan910baVf0N7+qRbW3w82OSo0cP1UZGgfydoltrI1lmyr6y+Ul4EQ1fmws51QnJdhGS7Le/LKCRDdh76sj+tIsFK6IGZf8fmbK8oQw5M6aa03TzNvMVvXDG2piK7dBUzscv+aZkM1UbmSor15tn7qYjjkcRYfM7IIH84q7ym1SAfWaa03mCxCjNKZZXaTZFqVyXplqUTCqGGhC/52E2Xc7+AqL995Y='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_637cc4e6f7a8535b_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
