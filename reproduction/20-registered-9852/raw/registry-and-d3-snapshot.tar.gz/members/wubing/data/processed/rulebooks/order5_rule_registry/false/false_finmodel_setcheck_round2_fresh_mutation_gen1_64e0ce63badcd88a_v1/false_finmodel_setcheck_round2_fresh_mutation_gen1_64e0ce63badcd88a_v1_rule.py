from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[2,0,0,1],[1,2,1,1],[2,2,2,2],[1,3,3,2]],"priority":628,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.64e0ce63badcd88a.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.64e0ce63badcd88a","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmU9IFFEcx39vnNaxRGe2IoNoZ9dJwQ6KG+EhnUGGXEHpUBhdSiSsg9ExQWGesNCoh1UrSJDsFAQdomBBoVz2JLVhR6NDQ4EnD0oQKy37evM2/LNukrhrrbzPYX67+3b58vvOe7+d93tDHgAMGaaaYUdiMSTQcA6inytgV9zAX9K1Qo6B2+19rzsTYg4tqydC6gOQD7DH6LqGoIj4CNDdSGOf569/MojkpE8CULITfaqpQ5oqiGOGkTXiA0iX0rjN/gZ2rQOQd5Q0HBmjbpD+hUNNA+zOWumZn6sL+j0dOEUAJlYXDUli2UAo+jOvUTi1FXLfDYTcJUuuWokM6gExMkaIhcoh9WNuHBPGuxAoIBZosVnauGmG70QnJ1cXWr7rgUCH+diWW6WCFNUzo9qEbb/8cD4YjH7q7b2YCE+eDAbjVf5CiDlk+qpXUaJrNb1x18bIjLzqr2mV/AWxcsp60v+1On56INGWvBVZk04oS9WJtip/uDCLjZBLg+biNzIqsSmSjreFR6X6sMwLEefgk3mcjR0duDLY3xMZqeSOFAPG+7qzNNx8dBzwi1cjz49dLuOmcDgcDofDcZbX952x2ln7TdbotLV8nZv0/5Em6y9TdDdqbR0VFzuNPIrFiI/1m+XMPphUbrS53VHUBBeK1khiHRJpOlhwPSVEB1DRJu/MvLYunNTGYqufnZ/Lelr3thv5lHuoTYQCAtYmbBgzvYqiCqZp29BKhZAIIXUYACEBTDMfTWdM9AqaHHZcTyk+mmLJRnMEqZDPTklDRZMrxC6lpxxXuBTYppTlQtMDdhPRPiy2zWuh6Mi0/nMcO7CtftbsHW6ua9l+43kx3newB+ABgvnD7puOzLkWbuz5w7cXy4spt7cgpSpFx0ISqCu67M4vIU1Kck8zdY+Hmka7IdCiq40bBpRpSKHBBkUBidarbfVDCKnqntSSACs6rZSI/af+/oywsnWEnVNuIVdVtneh9gt+YO4Y'
_TARGET_BITS_PAYLOAD = 'eNrtmU9IFFEcx9+y4RKEHjwJxXSIPCZt4WlZCxQWig5B0ClDMKjUPagTLPgGFOwYeSgJsS6R1CEUXGOQGe0g0YoeErRxdzaCjGpnFMtxG+f9evM2/LNukrhrrbzPYX67+3b58vvOe7+d93sdaQAMGRrGYUeCQeLQ8BZCJ5ZgVzzGxz2zTo6BB8M9Fwb9dg4tqS+MpuOQD3BaGXhKoIg4BdA/SWNP+q9/0klMX9ICMLITvabpHZru2C2KkjWSBPCs0rjN/il2nQEwd5RUBBOTfrD+hUMTXezOSp66Q6VV6l0VOEUARtIADT4kiYAo6tWUUji1MnTHDQjdQxWu2poJ+gExMoiQRJbBe7imGSPG2SgYYBdosUlasyxH7ocaG0urxo6o8fiQfEM0R62CFNX3rVqTKF46/SYWC53s7X3ljzR+isUCC4lCiAmo/lnKMEIlc70B18ZwnVmamBu1EgWxskG63n1sPvChyz/iexgusT4bFfP+kYVEpDCLDaGXnXLlUdRqsSniCYxEWq3piMkLEefgk3mcDX7ret7Z3RduW+SOFAPKmZl3NDy6+QXw5YttV76+WOGmcDgcDofDEcrX953B2VrxfNZovVT+hJv0/+FB6y+9dDcqbR21KweVPIoFUZL1m83MPhgtbrS53VEyAa+L1kgk/bRpOthxPUVIBdDJJu/kvLYuBO/GYpuura7JelpPDSv5lLulNUXjDtaaRGiRU4ahO7IsijBKhYgNUb0dgBAHZDkfTWeM1CWaHBZcTylJmuLaRnOE6JDPTsnU0oQrxC6rHwVXeBXYppTlQtMDdhPJPiy2zWuh6Mi0/nMcO7CtftbsbR+fGdt+43kx3ndwGuA2geof7puhzLkWnuz7w7crl4spt3NgeRdtQSIW6GWq6c4vx4PWck8zfY+Hmsqw4tCiqzUrCqxoxKBBBMMAi9arbfXDier6ntR8AGUqrZSE/af+/gyxsvWdnVNuIVdVFneh9gvOEYMP'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_64e0ce63badcd88a_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
