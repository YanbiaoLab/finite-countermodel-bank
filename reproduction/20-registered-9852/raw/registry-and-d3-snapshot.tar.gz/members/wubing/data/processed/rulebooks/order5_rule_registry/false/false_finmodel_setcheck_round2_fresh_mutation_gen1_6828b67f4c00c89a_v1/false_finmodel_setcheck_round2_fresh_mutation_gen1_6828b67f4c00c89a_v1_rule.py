from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,3,3,1],[2,3,3,3],[2,2,3,3],[2,3,3,3]],"priority":662,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.6828b67f4c00c89a.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.6828b67f4c00c89a","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAYBYMLTGBgUFDCJtEwqUVlUkcHFpk/pz/92j9PgirWK0AoRgYBwuoURmNrFIyCUTAKRsEoGAWjYBSMglEwCkbBKBgFo2AUjAIiQcMkFyFPF5cJLkKCgpM8lJScXFo6OAQFnTgUaWFbANCKzg4OsEUgazs6BAQVlYCWsdDCtn///3MnMDA0/l/I8Of////1Ggz//zcyMLDRJCAP/McFGGlg2w+QwefX//8///9XsCVn/4J8uO+nGC38lrtpjZq28rSrKalHNs1a0xPhs1QwOPXIpCQO5tEMNApGwSgYBcMXOHgqdaooMYFqbgZPFUFghe0AaiQotNDENg4G8CQgB5gDaxaAq1AmTqBbGKC1qQNcNWaThgTbAHNOZ44='
_TARGET_BITS_PAYLOAD = 'eNrt2T9LAzEYBvBXixUEv4iTiFsH9QMUhG4OooODQ+ggNMNBz8/gWBFHF8FBOIdQ7ksIImd6Y3FouohBtPd6iX8WK1poQOT5LceRcE+S43hfuIKZY4a/pcmc63EDsYgyIeWYkcrq4tz6bn8q8fnbpeDhz/NyvC0AAAAAAAAAAIBfioUaJEo11cAYcaV1V0XSGtO1vRBpF2VES1of5GKlHJqeLsOeQ6TNED2cMrdpmytEdHjDRG3mpyAHuUbfKQKkzbsHL28S7dCCD1mZdTvcqN6H2NtRvXF7fbe/dNyp1fcaB2eXW+a8UxMn9gUfEADA/5UmupXpkavcnGSmLNipaxLyKEiaZf8T0Pqbj7bAl9DRY7kWfq+m6efsry3NBGmv2SMJqA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_6828b67f4c00c89a_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
