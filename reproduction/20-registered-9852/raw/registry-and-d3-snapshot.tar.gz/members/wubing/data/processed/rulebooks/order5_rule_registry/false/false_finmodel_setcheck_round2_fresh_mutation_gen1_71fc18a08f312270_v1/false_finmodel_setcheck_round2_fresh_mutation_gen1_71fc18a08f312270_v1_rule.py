from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,1,3,3],[3,3,3,3],[0,1,3,3],[3,3,3,3]],"priority":630,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.71fc18a08f312270.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.71fc18a08f312270","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmc9rE0EUx5O2oB60oJcKRYsHLz1pkBqKVkS8efBQY6GhUGkD0aTI4m4hxM0fELyIh9Iff0BTU21NQjo021NLNU29RGg30y0IKZTurhezxXH3uZuWXjahjbIeynwOe5m38/Z99/tmYMbtcrliruP4tNpiPpfE8y7K/+BrWgzPeZgm20AsI3FocrHZ/spvOU0g324f2NY1KaypNbJAlVb7wIdV6zndF398v6XJNYrcVuZZtjNSKYaH1o/ClmQ29f7Fk7XB+MVr9J9RKBQKhUKhUCgUCoVCoZxqQkhOI5TBLKelx/fyJbzoYQLlKaZwyYFk27KGX3OQE1WlehpGEDei7GFGiThRWvVgTdkCEWNRAQ/DaYW8DnzB2+pAspgm8QQDUQSBB5kFRZV0NM+t66rbgWw/oA68E0IaIIY4bgTJiqJbSVAkUC7k7+xMnHEg2ZI5P4ChC5IuHJSkbpUANKw5Udq+aFaEFwEEswcgUD6scIK54kS2en8NnBDSOj7mTSWJChKPsECAA8XABJxptnqlXXWi2eoK2XwKmq0OTqxa98QwWi3kz9lH5jaTyU327eRYIsEOJ+NPmfjLvpDPF7LCi73dHt/DGe/y7Q7Xg8OJWmLHZxsl0Yy40V2j532kGCXhzDzHF5W1d3eev4kqCX03Z4UjIaiVP0/dWrnbYJPwSDZ6PDVe2ufRQlDU+WGzwrEswNqNZV3w+1NWuM8n583Vptz2vfFmq31XM6BrmixgRdKjiPdVZrKQnTUIqVjhRg4LnZFvJWj/m2brqfEZcBIaEzKWxpYPvgQt1R6xB6rdHDRVG0pZql3vrqrWf/mjqVoN2zTYbJWqDwZknyYjXNjSe1GXqZq3kp2tJEgFhwOqMY3HTdXaSclumwtnj2Y6yb5rsJYPFJB3p0MajGUXgoGyAV0rbRqwr4rWvVy/P+VhAMafxYndNm5XR1MDOxtRLR9Ef0pSBljEm74w/BvzZWMn90tVxeoaTVhI7vUxwNht4+1obGeDf6LB1eYPQsP8Kw=='
_TARGET_BITS_PAYLOAD = 'eNrtmc9rE0EUx9+uI914cXdLoQGh28m2YC42jZb21E2ZhiS22tj0D+gPehAvkj8gawh0VxZpooG0WCgp1LUHD95ExFpKLBI99eJBqhTsRaF6UKFt4m4qvSShjbIeynwOe5m38/Z99/tmYKZULpcT5eO42rNnPfvl72XK/+BSWE4PF42DqoFESNLIxMB+9StnxDAC/3b1QBvLSWmOr5EFKuxWD1zvsZ9jy/EnL/YOyjOkZGce0TdTLm96vusorF/UIzfuP+5eiH/9QP8ZhUKhUCgUCoVCoVAoFMqpJkPEMCEhrGtceKrZ78EDRSPnHjd8XxxI1iZy+I4GAZkXKqdhiGizQjM2hJQTpVUO1oR2kDGWBSgaGufzs6D6CrsOJEtwkoowIEFRVBB1EHiJJUNaF8uXHMh2HuqgOiEkA3JG02aJKAisnYSkcm6ff6118pcDyfqt+QEYVpFY5bAkvt0DwGHOidKaZKsiPACgWD0AOfefCieNT05kq/fXwAkh7eNj1VIS8SCpBCsINBAYjMCZZqtX2kcnmq2ukPunoNnq4MSq9VJOkx6f/0f1yHBHNNqh35qYjsX0uWj8kRG/t5wxzYwd7l1ZL5rPRgt9r7fKz/9MtJc4PtsMSobkzvUaPW8ibxKlQ0Oa6hW6b649uJ0UYmxLwA4nSpZzXxl/0/uqwSZRicisFmu81KSSwazMqnNWhdNBgO53faySz0fscNMU/dZq49650Hiz1b6rWWQ5TlSwILFJopqu0SAERxiEXHY4E8DKZuqiB7b/ptlWa3wGnITGhEyEse2Dy1lbtaf6oWpvFyzV5iO2au/XK6otfb5mqVbDNg02m6vig0XR5ESCfe3sCtmwVCu4giOuGHLhdI5nxvCUpdo28lTb5tvPo5lOsu8yuu0DAcSWsQwH08HBbM7NwEbvDgf6Xa99L7eUjxQNgKmHcVRtm1J566CBnQ3xtg+S5yQpBDpRLV8w+c4hN9MaOMvzcmWNRjpEm5cNMKptU9hqbGeDf6LB1eY3Cb10/A=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_71fc18a08f312270_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
