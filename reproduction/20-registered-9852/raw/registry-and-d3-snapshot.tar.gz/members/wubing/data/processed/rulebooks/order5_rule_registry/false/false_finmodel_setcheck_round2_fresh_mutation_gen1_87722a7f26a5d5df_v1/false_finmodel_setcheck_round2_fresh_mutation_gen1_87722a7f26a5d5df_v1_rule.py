from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,0,0,0],[0,0,0,0],[1,0,0,2],[0,1,1,0]],"priority":658,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.87722a7f26a5d5df.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.87722a7f26a5d5df","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmc9LAkEUx9+MCWMXd7Ho6A8C6xR06iKuYuBtobv3/oVAcAuDOXoIvJn9B50lcg8dgi71H3hI8GieDBZf44pdcsMtJxLe5/SGYefLm533HXjDAMCB5XBfokD8BQ2AVCbcJ9Xo1jhZXjDRQx/2dQZjlUlzZ8FEah4Y35+HweHN5WmxbG3QHyMIgiAIgiAIgiAIgiBWR2/A56Gb6Bg5RluyDkzQ3AewziWAh4g1gHTd0dU6dDHpHxIDwJm2P+PLt7l/wBgDyOtQU+tu34q2iyd8ouLulcrQ4pDgWootKDXUoeYFiSU1iDmBqUU0qA2DxGp6ig3zb2ahif1jv9jOTFShPKivv48cdUKc3lhFtsh6/wFTpzcZSDEdlGa27xjFz0Fm5l6WSK9fbvd804vv9mpRwfeG+QZcgKWcOeKIYZdvMP9drgAphshW8FTmYgh+f7PZg1H3TuL1WLafcJSRLSP3jvZj9gHtaum5r4ylZMuWh9lXdf+IBSuIEGofvt0hOg=='
_TARGET_BITS_PAYLOAD = 'eNrtmc9LAkEUx58s5Mk8CnbwP6hL0KHDGuG5/yDzJnTwOJDUCkL/Qnfvwd6ExFa8dAo6lRD+OEbJrpccUGde44pdcsMtJxLe5/SGYefLm533HXgjEdHC5TC3R0j8BQXEbjvcJ+XRW7RXXTCRAh/5dQaGlUj+ZcFEdx5435+HxP3x2VW96ozpjxEEQRAEQRAEQRAEQRCrI5UQ89DsZ7ympC1ZByLgPiI6FwzRAIASYqdo6WodmtDzD4mHaE3bn4Pl29w/IAoBNHSoqXVfj3jWhGsRUXH6VGXoCOwLLcUWlBroUDOCxHoaxKzA1CYa1OJBYiU9xQaNTfc2D8kbv9guXVAheyiuv4/cZUKc3mGF5ch6/wFTp3clMj4d1Ga2b3n1z0F75l4O76xfbgfi3Rg8p0ojLp7ijQKeo6OceWLxeFqMpf8ud4tdCSBX8FRmQgh+f7PZiVj6kMFJlGV3IdZmOa+5AfZeax/scm0nqYylZrOcAa0tdf/wBSvwEGofjZRP/A=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_87722a7f26a5d5df_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
