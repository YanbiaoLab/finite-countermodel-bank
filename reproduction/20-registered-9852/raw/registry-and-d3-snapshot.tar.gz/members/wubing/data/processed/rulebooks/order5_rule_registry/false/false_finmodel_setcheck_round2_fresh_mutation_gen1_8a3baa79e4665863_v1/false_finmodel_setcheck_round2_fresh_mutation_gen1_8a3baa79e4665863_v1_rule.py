from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,0,0,0,0],[2,0,0,4,2],[0,0,0,0,0],[1,2,2,0,2],[2,2,2,1,0]],"priority":632,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.8a3baa79e4665863.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.8a3baa79e4665863","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2TEKgzAUBuD3tGA2062DVI/hZo/SgxTM1luVHCVHcHSQvMaCtYOUOgRK+L8lDyQ88pOYIUxEhn5jLRP8qRvrsVa7ptTMvtAbH5ql0F/nX5w2fEX0AAAAAAAAAAAAQF7e5SQifdRmVuqlNKGZlAkF+RGdD0vrojZza3R2DrJIJ8fXxtiUJ3DY2ioM93w9bKVL4/nm1O7YvVTRGb9eiOpBaioPrmdFzdDp+UE185KbBJY2KjV0xsiRVGOFMkXEY7gSmijdnuxLU4E='
_TARGET_BITS_PAYLOAD = 'eNrt2TEKgzAUBuAXHBw9Qo4SeqtuEXqQHqVuHiMWh26NW4Tqe9WCtYOUOgRK+L8lDyQ88pOYISwiVn5jDAv8qRP7vAm7pjTMqvcbH9xS+K/zL9pbPiN6AAAAAAAAAAAAEEXvMiOiMmozQ81S2qkZdQkF+RGdmpZWRW2m1+jMHGSfTo6vjbFpSOCw1e00HIf1sHU6jeebW71j90orV/x6IaqDhKx76JKDuKLy84PqqGiwCSwtD6GorKW7BGdIxiDC+XQluCjdnmAmHbU='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_8a3baa79e4665863_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
