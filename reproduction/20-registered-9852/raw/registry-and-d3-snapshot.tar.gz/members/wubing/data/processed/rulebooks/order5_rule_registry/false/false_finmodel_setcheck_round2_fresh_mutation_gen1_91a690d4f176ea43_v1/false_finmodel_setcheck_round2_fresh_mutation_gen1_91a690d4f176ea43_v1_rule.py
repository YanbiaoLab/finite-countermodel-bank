from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,1],[3,3,1,3],[2,2,3,3],[3,3,3,3]],"priority":656,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.91a690d4f176ea43.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.91a690d4f176ea43","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgDhw4wMgwCgYp+HNy06/9PRKYEgoqCowsCkxYtMgzMPxjx2aWAowhgNdKhwcCDYwJo0E/CkbBKBgFo2AUjIJRMApGwSgYBaNgFIyCUTACACcSu4NjNDxGASb49x/O/PP///96mlp24P9/8dgn8TYfjx9v/w8CX1r+cV4UdvqnTgvbPARdRQI5FnYocSmKBLootjhxtAoAmSyOArSw7f//t2rWxtOvlpVe/QcKyNitxsWpR2Yl9zAP+TQyhWWShxJTg8qkDoYJDkICjApMLi4dHQxONLGs4f9/f8uj9rteLJ/uDk4jTwP/LJ7g7viHnxbzHAUiFY84mxh2vWBScWCMbWDxYJggrqjPpKAw9DMbfYGEBU4pjHh7wCDDIDda9I4C2tZsKZF/493e/D95qiP1a73kxhleysv+/Vc/KsBGA8scPByYOBxYWCY4ODBwKjAIAqkOUMrnoMnk7A8Ghg/2wJKSEVynQsX+84MobkzV2Fp+DSTYBgASU3hm'
_TARGET_BITS_PAYLOAD = 'eNr79/////r/xAF7+3//R8EgBcxmvqwOxc8xJe7fvv/v9/2/WLQ8+P+f8Qc2s+7DGO/xWrlf/n39v/mjQT8KRsEoGAWjYBSMglEwCkbBKBgFo2AUjIJRMALANyR2+ffR8BgFmICRAc5kZmBgaKCpZfYMDC8WSS84zGdhUcEAAtzVjN/03uxlvEEL27a/2/V63fe48rtf771et/te9d7vVe+BzN/73tPCNgYGoZtHzmRodXZpMYICcpHXmZ5Z1qlziv8M+TSS/Tt3+92/9bdzy//n73/7/t/9v7t3l5f/30sTy+oZGDYcszrgKh6RsQOcRqTWMcfk79jH/IEW8xz9r9tlv9X+dxX/e3v/v0X1v7f/z39x78Lf+/eHfmajL3h+HKcURrzJ/3/8/+Fo0TsKaFuzzV7GtGCnMIOZafksroZnfulb70QyMtywev+TBpbt377/7/f9v3/n79///9v9/++AVDko5X+nyeQs+////AeAJeU/cJ0KFWP4AKK+YKrG1vKrJ8E2ADot+ME='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_91a690d4f176ea43_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
