from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,0,0,0,3],[1,1,0,0,0],[2,0,2,0,0],[3,2,3,3,0],[3,3,4,4,4]],"priority":625,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.9b0fbaa5cfebaefe.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.9b0fbaa5cfebaefe","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WTFuwkAQ3LNNcIHAQUihoLAIBaXLVHCKKCBVfkCekPSRck26FBHKA3iKq3whrZ/gkgLFIWcHKbIX2+I8K2Twrc0w65vdveNVSKKwTb/W0cdQH2mgj5Iyj69P9Ok+EVRoUdIrdtCaGacd5whdzjPjHAHnUE+cp8M5thOGI7W4W6acQ7JULM4RZ+hRjorgbs2oODnHNn0rIJSO+Hl499/Xu+T8ffSJtzDRZhPEdhrsBQNGKbUeBixK0QQGba/B5hgwlcwdi1AWJ18tGBh9J+TCwMIrH8fsIDYbiLYWQLDI9oBob7blwh6cugQyO4itTVCxEVBsyEDukGB0TVCxxXMcWoe6ODDVQwYygM6RT9EexTCx3SCpDZFJi2wFrKMP0DnyMdksx2NQb6c2i/5qsQBRu99IYCDv+kAwKZBt5HSFnJEtJNiW3h0c2gBJTXmSBIycZyG53SLBJCHF5iKpUclOzN5odxSV7MSMjFJ7Pr0cNVvSy9rIidG1cVAiNrOqn/GuLpnWRngixoeX4ZUB30Y6njruohtrI1lmDTQq/E54Ew0fW9lkA22RYn/9soEqxFc24Zjfg2LBmqhB2f9HRVm+oAxFZ6aaIZ933Wp10K0ttseicp4f8ouSTa02MlVWpYvP7qYdjkcT0+ZY2SAr7oB/SA3YRaY5UWWSFEqzRnilYFOUrDRUKyiZVEQlGta5LcQPG21pWg=='
_TARGET_BITS_PAYLOAD = 'eNq9WTFuwkAQdERB6Se4zRdS+Sk8IEIp0qW5SOmTJ4QfpAoUKDqoUrqkIMgFBZEQMYjCBNu3IWcHKbIX2+I8K2Twrc0w65vdveNOSSJ3R7+21UdXH2mpj5Iyj69P9GnLUlRojrUudlCPGac253BDzjPmHB7nEI+cZ8s5OlOGI+25WyacQ7JUEs5hZ+hOjoribs2oRDlHJ30rIJSO+Hn48N/XhxT9ffSJN9fSFhPE2hrsHgNGKbU1BsxJ0RQGraXBRhgwYY2ihFBmW5d7GBhdWBTCwNxPH8fsILYYiNZTQDAnDoBot3ESwh6c+AIyO4htR1CxEVBsyEC2kWD0QVCx2SMc2pY2ODCxRgbSg86RK7Wb2zCxvSOpLZBJi2IBrKPP0DlyPe0OZjNQbye6w1V/OARRe+lKYCBfV0AwqZBt5KSPnJF7JFiHbiIc2hJJTQSSFIxckCC5vSHBJCHFFiKpUclOTMtod+SU7MTMjVJ7OL0cNVvSy9rIqdG1sVciNrOqH/OuDZnWhnsixoeX4ZUB30ZGgTjuohtrI1lmDTQq/E54Ew0fW9lkA22RYH/9oIEqxFc2FZnfg2LBmqhB2f9HRVm+oAw5Z6aaBZ93w2p1MKwttqeicp4f8ouSTa02MlVWpYvP7qYjjkcT0+ZY2SArbo9/SA3Yd6Y5VWWSFEqzRnilYlOUrDRUKyiZVFQlGsm5LcQPMRMH3A=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_9b0fbaa5cfebaefe_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
