from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[2,0,0,0],[1,2,1,0],[2,2,2,2],[3,2,3,2]],"priority":655,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.a5928b22c84e0e79.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.a5928b22c84e0e79","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmVFIU1EYx79zHfNaoveuIoVod/OWYA8TF+FDei9yyQ2UHgqjlxIR68HoMWHCvcKgqz5MraCBZK9BD1EwUCjHnqQW9mj00KXAJx8mQUwaO517Fs62JYmbNTm/h/tt+874+P7nnO/e890JJ4ABOea7YFficcQRcx5inxpgT9w0PmdbuRKO28HRV/1JR4lY+lAE+7xQDgynOnAdQRXxAWCwg9hR51//ZRwJaTcP0FyY6FNZmpAlzjGjqgUeN0C2ltgi+dvptQ1A2DWkagkGGvw3CnWG6Mzq2cUfm6vKPQUYVYCB9QFi0lg3AROUdZdauWgpfN82GN/F63a0GgGkQyJkHGMd1UPm+7JoYMpbHkRwVGiz6fKspoXvxKLRzdXub4rX26c9NoUeviJF9cy0PGeaL95f8PtjH0dGLiXD0Wa/P9HkqUQwCy9cc4libOvsSMKWMbIobHq8PbynIlLO60/GvrQkToeSvelbkS3+pLjekuxt8oQrs9kwvjyurX3F0zxdItlEb3ia94UFVogYh5/c42z8WOjq+NhQZKqRKVINqO/azhEz/OgEGM9fTj07fqWOicJgMBgMBsPa2D53xluXzNcF3gV94wYT6f8ji7c/ZshpVP/d60j3q2UMFsdu2m8Wcudg3Jhvc9teFBIuVq2QWEcOOx3O1hRjBUCCHdoNl7V1YWXym823tLJc8LTuCqrlDPdQngt4OUOeM2FGc4mixGmaaUIPCURyDkiTAAhxoGl8GYIZWKHvMSxbU4KbpFiTdyMZytkpaW/otAPRS+0pi6hq1AI9lNJc7Cmlk4gOYLPt3AtVR671D8UrgB71C1bvZFdbd/HEs2J84BhOgAcIVo7YX/py77WMjqE/jF6rr6bc3gCfaXRYOuJBSimCvb64LK4pvcykln02SIIqR4quPKuqUCcjkRgTRBF4JBUP5gKStK9oaYCUQiolovfUX79hWraOFo8uVZXNPUT7CYN/7EU='
_TARGET_BITS_PAYLOAD = 'eNrtmVFIU1EYx89YOIJwDz4Jxe0h8jFphU9jFigMih6CXjMEg0rdg3qDgfeCA3uMfCgRsV4iqYdQ2BYXuVd7kGiiDwnW3XYXgUa1eyeW1zHv+Tr3LNS2JYmbNTm/h/tt+874+P7nnO/e893+LIAAedpnYFd8PmwR8xb8p1ZhTzwWTjqWrBKOh+GhSxOeXIlY4mgALSSgHAhZefwphiriDMDYHLFD2b/+ywA2XCkTYLkw0euq1q9qVq5blgs8KQDHBrFF8s/T6yKAsWtImTMEPPZvFJoN0ZkVHa1HahuVewowqgABiePEuJDIAyIo9Wm5ctHc6K5tELqP6u1omwZoh0RIH0IiXgPn0WZdQJTzJuiQq9BmE9UuSQo+8Hd01DZOH1MSiUnpJm9MmRUpqh961E6ev3L2TSzmPz08/MoT7FiOxbwryUoE41Dbs7Su+2veD3ttGQOtRm0yMWUmKyJlu3hj8ETc+zHkiboeBWrMz3p93BNdSQYrs9kQejkgNRxHPSZdIg5vNNhjLgQNVogYh5/846zvW+j5wOBooDfDFKkG5HOL74gZufUFhKuXe699fbHORGEwGAwGg8HVbZ07fUst/MUCb5tY94SJ9P/hQFsfneQ0Kv7uzbkm5DIG86EU7Tcb+XMwymy3uW0vDhmvq1ZIJOKcnY5la4qQAqDBDu1Gytq64Jzbm22hpam54Gk9HZbLGe622hlJWILayUO3lNZ1zZIknocpEojkHNH6ADC2QJLMMgQTkELfY3C2poQUSXFz241VKGenZH511g5ELxufOKKqsAH0UEpzsaeUTiI+gM22cy9UHfnWPxSvAHrUL1i9fTOL08UTz4rxgSNkAe5gaPphf5nMv9cS5kb/MLphrZpyuwCmM5PjRGyC5lYMe31ZDrRZeplp8X02SMKyRYqu2iXLsK5inRgedB1MrBUPtiKatq9oLgC3QiolpvfUX78hWra+F48uVZX5PUT7CcjyhOI='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_a5928b22c84e0e79_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
