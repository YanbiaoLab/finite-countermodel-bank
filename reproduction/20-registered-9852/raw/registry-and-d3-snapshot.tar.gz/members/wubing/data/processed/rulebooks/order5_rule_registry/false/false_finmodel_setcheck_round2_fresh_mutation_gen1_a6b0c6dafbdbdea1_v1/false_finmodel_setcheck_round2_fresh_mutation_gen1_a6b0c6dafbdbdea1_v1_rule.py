from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,0,0,0,0],[1,1,0,0,0],[2,0,2,0,0],[3,2,3,3,0],[3,2,4,4,4]],"priority":650,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.a6b0c6dafbdbdea1.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.a6b0c6dafbdbdea1","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WbFuwjAQPYfQBBUBQh0YKjVCDGxlZAKrYoB26daRfkK7V6qXbh0q1A/gUzL1F7pm6Z6RAeG2SYpUxQdEOO+EDPFhXu7id3c+XoQkCj36lXoyhslIZ8koKdMEyUVyudaCjBLppllBc2YFrRxGERInI04x4BTqkdPUOcWyx91xlVvS5xTS5zSc8RRn6FHOFMEtzUxxc4pl+mYwKJ0J8vD+v5/3yf37GBAvoU6kQhBZJWDPGDBKTWtiwKIUTWDQ1gnYGAOm9Nj1CCWx/vyq1VBoGz3sE+ihUXhHQFnpGweHNm/PXBhYdIp05GsFCKYE0rRYe0C0jQaCgcnmINGQG5KiSjzGodWpASRbE+nIARKMPoR3HsPINkSa1vGgZFNAut1D98h7bzHtdkGhSy0m7dlkAjLtdiEDnCOv2z4OTEJLhP4MiVZFgi3pDVezZr0ZVGZrSRIw41rQ6ucKCSYJGEbIR5pGezoxa6vVUbS7E6MurJr2tDuQ2E3p6nK3vmc1YO8rI+2yfsSrGmSbG+EOH/+8LJ8M+DLSbaltF730M5uS9pnNd8LLKPjYzCbb9osHxd79tIQsxGc24baso7FgZeSg7P8jU5Q3pKHoyFDT4eOuf1ge9AuT7cGUzvNTgSnYFCojU2Yd9OWjCeFydpSxbbYNEsiJe8A/pBLkJOOcOGSTGKlZwL3Zmc0UouRBU4WcklHFkAOcfOfc8Y8sIb4Bhy1sVg=='
_TARGET_BITS_PAYLOAD = 'eNq9WbFuwjAQNWJgzN4la3+hUz6FD6hQh25dXKl7+wll7NalhQFVhomRbgwIpVIHhgoBoiIpIb62SYpUxRdAOO+EDPFhXu7id3c+rrQi8kL6lWUyeslIH8moKNP4yUVyWRWajOKKuVlBTWYF1WJG4REnPU4x4BTyltMsOUV9xN3xmlsy5BQq4DSc8eRk6G7OFM0tzUyJcop6+mYwKJ3x8/DBv58PKPr76BMvnkhkQxCpJWDXGDBKTZtjwNwUTWPQqglYFwMmRTcKCSWOOD1ZrVBoFdEfEuihkfdAQKmJpxiH1py2IhiY+4l05OUGCCY10jRHhEC0igCCgckWI9GQG5LcjdPFoS1pASTbHOnIARKMznT47sDI1keaNgmhZJNAut1D98j5qNEej0GhSzY601anAzLtsaF8nCOfpwEOTEFLhGELibZGgtXpAlezZr0ZVGabKdIw42bQ6ucFCaYIGEYoQJpGOzoxVavVkVvciZFvVk27KQ4kdlO6fC3Wj6wG7F1lpF3W93jVgmxzwyvw8c/L8smALyOjmdx20Us/s0lln9l8J7yMgo/NbGpqv3iQ7N23S8hCfGbT0cw6GgtWRg7K/j8yRXlDGnKPDDUTPu4G++XB4GCy3ZnSeX7KNwWbg8rIlFl7ffloQkScHWVsm22DBHLiHvAPqQT5yjin99kkRmoe4N7szGYKUWqvqYOcklHFkAPifOc8Do4sIb4BxUQE4A=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_a6b0c6dafbdbdea1_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
