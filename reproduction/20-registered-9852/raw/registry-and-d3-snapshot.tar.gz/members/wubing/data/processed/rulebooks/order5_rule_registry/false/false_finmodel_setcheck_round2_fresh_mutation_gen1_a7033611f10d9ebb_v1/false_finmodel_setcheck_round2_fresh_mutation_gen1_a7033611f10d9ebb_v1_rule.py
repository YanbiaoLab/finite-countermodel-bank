from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,2],[1,3,1,3],[2,2,3,3],[3,3,3,3]],"priority":659,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.a7033611f10d9ebb.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.a7033611f10d9ebb","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgDhw4wMgwCugBJjAwKCiRpuVPd9Ev+3kCpGiRZ2D4x45NQgHGwG+cwwOBBsaE0dgaBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBgF1AUJL+DMA8wWDLbDyGsNDQg2kwNiIG44gH///yszCDo0/Gdl+fP///96Rsb//xlZGBRYaGHZAaAFMg1yMh/sDzb/BwGBB//tDzAzXGCnhW0R9rElF7sXzinq0v8S7Pex/xXnUeEudRG7RAFa2Pb//2m9KsUpwXEfW/6BAtJmYVXSx5ZD6hxMo5mNpMwGDDwLBxuLB/WN7OA04njgf30DO0MH/3DIbHAmOLMNo2iTsABT2IoNjPmpBwwyDHIYygZtsaoAcRlRpUYDUBnHEMpswPgSZGToADvZBRJ5DQJOQJJj6Gc2V8u/8v4v/nfHcTz9AiyOJ7gr9v/7z/5RkGXIe+0HA8MHe2BJyQiuU6Fi//mxZjbsUdlAgm0ARdh1Ww=='
_TARGET_BITS_PAYLOAD = 'eNrtmTFPwkAUx18lxoGkTIbEpd9AFycT7TchMY4OMEAYMFwXJsNHUIKLC4NuRqOtkthVNwalEAYHDWWyjYV7HkVhoDE0ESPN+w3tS3vXd3ev/3+TK0dEhrOhqhyJvyCNaD2H6xLLlpeNXTtMlxai5AbdsL6Dnx+nKzbjFaoWQRAEQRAEQRAEQRAE8btUkuNQ7Zt4F6GpMTaJB/pkIy4KSABP2NUZfHgxANA4B+AeWt48kqkiQYe1Owlj5wCG2AoYah833HlkOzVODtezqb1y7iFeO5czq+9bb7nG6+2xPY9sAJuPpeZ+rSoXpOFC1lOlI7mw3XAGJLZQYhOLZ+p1U9GKrv+O3KigMRfzvSiIbRz6YotQ2V5M/xRkG1P/pxTsYHuq2b+1VWs0splcg4lmzgKJTdSryzHvD/lqVDxmX4ujs/hiu7xfap0lIVt11uLCjtMXzYwErtz1Fn5qK4gJQzgl97+pX9egFyi24FKyENk+AQao+8w='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_a7033611f10d9ebb_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
