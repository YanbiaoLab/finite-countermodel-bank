from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,0,0,0],[0,0,0,0],[3,1,0,0],[0,1,1,0]],"priority":647,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.aad8c38063831b3d.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.aad8c38063831b3d","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgDhw4xckwCugBJjAwKCgxMDCRoOXP3X2/9r+RJMWW/2DAjymhAGMI4NXv8DRkimYKCzABCSmNxtkoGAWjYBSMglEwCkbBKBgFo2AUjIJRMApGwSigFkj4ywJjHvC3PGrPNBokQwH8+7/7b33+q//r/2n9BQ087kpPPf/vv/h3SVYaWHbg//9N/+Pj/s4P/7McPMzpv2bejf//P51cTguveQinigRKLOxQ01KcEuiS2OLE1SrBpSjC4ixAC9v+4wLso5mNFNCAMyCZaWDbB1yW1dMms+EA/EM+2iLsGYlW+2DR/Dg5RoZRMPCZDViMCDIydHCAOC6QMqVBwAm7YiVwKSMIiTiFFoFB7rd/efF/47+9+X/31Lzar/U3N8/3+rzs33/1o3ZsmGp/1G/flA5WvvzSnpX//3tu7B/M6fMHrnLEHktmo7i0AQBNnfy2'
_TARGET_BITS_PAYLOAD = 'eNr79/////r/xAF702//RwE9QP7///fv/v//lwQtzEqOrA7Cz0ixhQEMPmBK3Icx3uPVv19qdfa12b+BCejt3dE4GwWjYBSMglEwCkbBKBgFo2AUjIJRMApGwSgYBdQC85l+w5j2G45ZHfg7GiRDATAyuDA1TBBlCGC8ygQaeHSdMcuAkeEFx7NfNLDMnoHBl2HBQqaEFcwR4GHODcGJ6gwMvGYRtPDa9jezXq97Hld+8+q97HW751Xv/Vr1/Ou917/3vKeFbQy4wI/RzEYKqMcZkH9oYBs/LssaaJPZcIAPQz7alh/4R7Ra+diEhQ///R8FA5/ZgMXIu3//y7+DOLshZUr9+73YFd8FlzLvIBF3v/r9IPcb48QFTAs4hRmUTBObuBrUfBK28kQyMtywOvgTUy17g4fvDLDyCF3nMAaGbX4Fgzl9suMqRw5gyWwUlzYA/tR0cQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_aad8c38063831b3d_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
