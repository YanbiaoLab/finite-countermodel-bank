from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,3,3,3],[2,3,3,0],[2,2,3,3],[3,3,3,3]],"priority":634,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.ad09c6bf03fcfc9a.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.ad09c6bf03fcfc9a","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgDhw4wMgwCgYp+PN22+//Z2QwJRL+fgn2+9iPRYs8A8M/dmxmKcAYAnitdHgg0MCYMBr0o2AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAUjAHAisTs4RsNjFGCCf/+ZOBQYGBhZFBj+/P//v16BwQE09MxEE8sO/McFaDGG/aPy7///Z9b//z//Z+nN/8rr7535C/Jhz08xWvjt//+/23bv3n63vPz7P5CP7u7dXJ7+bF7xOeYhn0b+4Io1eRpY1vD/v3/9X/tfb5f/d4fYEvhn8c/wh//5aZFGPpT+/F+/SB1o55cnnf8759W4/AD5S/GLIG0yG0qY1g+jckTCCqcURrw9YJDlkBstekcBbWu2stt/69Pe/X/7alXu9/8zd+7KSn/277/5cQl2WtRsv14un/NIPvbL5dOL5xd11X/5pPEv8MRihX/ttPDaD2DBZQ8sKRnBdSpU7D8/iOLGVI2t5XeCBNsAvJ7KNg=='
_TARGET_BITS_PAYLOAD = 'eNr79/////r/xAF7+3//R8EgBcxCniwMxo8xJeYzca/ZyFeARcuD//8Zf2Az6z6M8R6vlfvl39f/mz8a9KNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBgFIwB8Q2KXfx8Nj1GACRgZ/n6/////v9/3/zMzMDA03P+/HzT0/Jcmltkz4AK0GMNmb2NiYDAOYGBIYOtSY7gToGjMBPJhMdtLWviNgYHJ08XFQ6mjg4MR5CMlJ5+OGZKJPYZ/hnwaYcYVaw9oYFk9A8OGBqYDrEIRDDsgtqxjjmFbIcfwgRZphL+LjaEh9gbQTm7pMoayxObd7CB/3eN+R5vMhhKmDcOoHHl+FKcURrzJ/3/0/eFo0TsKaFuzdaowNcwUZBASDZ3EwZDm5jp1hiQjwwmL5z9oUbOxikUkyz5YxK1jEpPQW9rAzXudcZ15zH3GClp4jR1YcB0AlpT/wHUqVIzhA4j6gqkaW8vPnATbAI/TpvE='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_ad09c6bf03fcfc9a_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
