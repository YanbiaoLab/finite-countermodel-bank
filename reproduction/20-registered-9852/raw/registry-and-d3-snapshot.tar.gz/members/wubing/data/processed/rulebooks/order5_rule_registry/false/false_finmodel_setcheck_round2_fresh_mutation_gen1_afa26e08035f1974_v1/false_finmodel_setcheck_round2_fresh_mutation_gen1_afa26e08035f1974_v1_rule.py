from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,0,0,0,0],[1,1,0,0,0],[2,0,2,0,0],[3,0,3,3,0],[3,3,4,4,4]],"priority":660,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.afa26e08035f1974.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.afa26e08035f1974","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WbFuwjAQPUNogooAIQaGSo0QAyNjJ7AqBujUrWP7CXSvVC/dOlSoH8CnZOovdM3SPSMDIqVOQKrig0Q474QM8RGen+N3dzZvQhIFLv1ZQ7eBbqmrW0mpx9cX+nITCzJaGLfMDnpk7qA1078fhcHGnGPEOdQz52lwjtWAG3GNu2XIOaTHeSqcI0rRwwwVwd2aUnEyjlXyZiCU9PhZeO/fz3vk7D/6xFsQa6sSxNYa7BUDRgm1FgYsTNAEBm2jwSYYMBVPmi6hLIq/f+p1FNo29oYEemgUPBDQ1ihVa7tGUguRzOgdiaYEkloUu0C0bQwEA4sNCUZVrNiiCQ6tQU2g2FrIiRxB18iXcK8imNhukNR6LlRsCii3J+ga+RwsZ/1+BSS25bQzn05B1O6X0sdN5F0H+NQktEQYzpFoNSTYij4cHFoXSU21JQkYuXYFye0WCSYJGEbIg4b/EycxG6vVUXj8JEbZrTFfjgcSuyn9VBk5sBqwT5WRdlU/5l27Qn1huYw8Mse7l+WdAV9GOm11OEUvfc+mpH1l8yfhZRR8bGaTJZRFih39rIQsxGc24bSto7FgZeSg9P8jU5Q3pKHwzFDT4+Ouly8PeoXFtjCl82yXbwo2hcrIRFm5vnx2Ne1wPMpYNofMBtlxj/iHVIJdpJoTeRaJUZoFpjfds5lClMzVVWhSUqkYckDlMtvlnVlC/AItKms6'
_TARGET_BITS_PAYLOAD = 'eNq9WbFuwjAQDWJgzN4la3+hUz6FD6hQh25dXKl7+YR27NapMKDKMHVkZEAolTowIBQQFUkJ+EqdgFTFB0Q474QM8RGen+N3dzZ3ShL5Mf3ZQre+bmmiW0mZJ9AX+rLqKDKa58zMDnpm7qAa078bhcF6nKPPOcQj51lwjvqQG/GKu2XAOWTEeTacw83QvRwVxd2aUUlyjnr6ZiCU9gR5+Ojfz0eU7D4GxJvvaFsTxGoa7B4DRim1GQbMS9EUBq2qwboYMOF05zGhzHUuL5ZLFFrFiQYEemjkvxDQaihVa/tEUvOQzOgWiSYUkprrxEC0igMEA4sNCUZrrNjcLg5tQXOg2GbIiexD18iVir9cmNg+kNTGMVRsAii3J+gauR422qPRBiS2Rmfa6nRA1F4bMsBN5NsU+NQktEQYtJBoKyRYnW4SHNoESU2EkhSMXLhBcntHgkkChhGKoOH/yElM1Wp15B0+iRF2a8yHw4HEbko/VkYOrQbsY2WkXdX3eNe2UG9aLiMPzPH2ZXlnwJeRSSj2p+il79mEtK9s/iS8jIKPzWyyhLJIsKNvl5CF+MymktA6GgtWRg7K/j8yRXlDGvLODDVjPu5Gp+XBqLDYmqZ0nu8KTMGmUBmZKuukL59dTSccjzKWzT6zQXbcff4hlWA/mebUKYvEKM0C05vt2UwhSp7UVWhSMqkYcsDmO98VnVlC/AIfVgX8'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_afa26e08035f1974_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
