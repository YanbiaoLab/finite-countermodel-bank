from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,0,0,0,0],[1,1,0,0,0],[2,0,2,2,0],[3,2,3,3,1],[3,4,4,4,4]],"priority":637,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.b721552a8e4d3d1d.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.b721552a8e4d3d1d","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrdWL9Lw0AUvkvP9rrYzCJ4xQ5dig5FcJFDHFwK7l0Elw76HwieoGjBqfgH1MXNSemcSXQL9B/I4B/g6FCIJcZfNC+m5PINviFwfCQf7+V97767c6YZ81gU7eipPxbi90JFi2h5zIgIShSyWiGAXpcA9Jj6VpkCfAowFBAnmRBD8pU6JwBJvaHJbzkUsP5Z0ZlUytSrcSpiBlBkqvwnToec+VZieOEKw8VbeABkC0+AZEFYA7JNQo4jMzWPhyUU2yuXwRost8fa5osrQGTeE7/Aya3ZPbzv7KBya/Vbo8s+iGx4dPO8oVCFfLijdyn7YrvlYonhxAYcWmwLSTYVG5CNtESFRKcEJNtHZhbbWZTYoO3vQwu5jSTTTBkcm4QWEtojCpradQMptoEAsu0xqao4sTnVhgsT2y47xZWyCe3IOv+3YkN2PzMuks2dig3H5mB3NmRgd7Y/zqITqzcaQbpnNXZvNK6W09msGmgzWkjFG1ZT89vIOVOmocXvK09bYqN/y9ReGoESmyhA+WQPmAJGzJBEBgXMkTNBDs+qsL3tGejwdKHHAgfpVDz6eJ9QySDnqOnRVZPZfqWcW2wq03au1Rw9lvJz3HxjoAgbmbttvi5IKgg/4kM9Vyw2h2fyfE6+8mq6h3U20zlPUSTZawlpODKnhXgHiCZIIg=='
_TARGET_BITS_PAYLOAD = 'eNrdWL9Lw0AUDnRw9A9wyD8gZFOcMhed3FzsHyCdhCoKnuB/UIcugkt3oYuDyOEiSAelS4dKTxDn1KXXer07S4y/aF5MSfINviFwfCQf7+V97767A8ut9W0Y7fDJPxbq90KEi3B5YolwJxTyOCKARpMA+DL1rTEFeBTAKCBKMiYq5Ct9QwCSeoOT39IUcP9Z0ZlUxtSrUSpqBhBkquYnToec+VZs+M6TxcWCcwZkc46BZK4zALKVHIMjYwPfOBMU26KR7gMst7XB7VKgQGT+qtnHya3bPN1oXaFy69Q65b0aiKxS3165E6hCrm/Su1T+Ytsy6sXixAYcWvYGSTYVG5CNtESFRGsCJDtHZhbZWZTYoO3vQQt5jSTjVjAcm4QWEtojApraTg8ptqoCsl1YKYY4selhL4CJ7dIe4UrZhXZk3/xbsSG737IAyRZMxYZj09idDRnYne2Ps2gp1xsNN9mzsnxvNHafk9lyNdCs/JaI93JNzWsj58yYhl6/rzzzEhv9W6b2kimU2FQByid7gBUwYiokUi1gjhwqcngOVd7bHoMOzwB6LNBIp+LTx/uYSroZR02DrppM9yvl3GITqbZzLubosYSfE2QbA0XYyMxt83VBMkL4EQ/quSKxaZPK8+ls5eV0D/N0pnOeokiy12LS0DKjhXgHxEspFA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_b721552a8e4d3d1d_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
