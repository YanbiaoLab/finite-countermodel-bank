from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,1,3,1],[1,3,3,3],[2,2,3,3],[3,3,3,3]],"priority":649,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.c1b81aa9c2308cb7.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.c1b81aa9c2308cb7","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgDhw4wMgwCgYp+LO+7Hf9PRFStMQzsv5jF8IiocHQBWEI4NXv8ECggTFhNOhHwSgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBgFDP/+/+dOYGBo/L+Q4c/////rNRj+/29kYGCjiWUHgDbY29n9+bT/T/d/ENB/9H//H+6PR8VpYdsPkA3+S///n2/+FcR87vsXZP++QCFa2AY0ev+vlVtu//+87B/Itj0r/wOZx8y9mEYTGSmgAZQKa2p+PK3/KQ5OI/FH/gOZj7r1h0Nm22WjyOgwXV0FktkUGF38n7gyKNEms0Ey1R99BiImiP5zO1CY2awgkVeqUIEuhWH9g3pZDrmhE2sLFMDUJAcGBXQpFozUqyLAwDGaiQdFZgvf/dc+/9X/9XVab78Bi+NN6ann//0X/yzJOuS99oNL44P9hIb/ogocCw78d2DiYGLg/PGfH1SQYMnr2NJjAwm2AQDv0pcK'
_TARGET_BITS_PAYLOAD = 'eNr79/////r/xAF7+3//R8EgBcwBnSwNiq9J0bLg3y/GH2+xSFz/XwphvMerf7/8+/p/80eDfhSMglEwCkbBKBgFo2AUjIJRMApGwSgYBaNgFIyCUfCfkYHhy/z//+sY4v4zMzAwNFz/z8BQ9///T5pYZg+04cDBg8y8DswlDCBwQZbBgfkLn9ULWtjGDrJhQxQDQ8IJLhBTYhMTyH7HdW9pYRvQaAfWMG8VBp5IRpBtzmEMQKblia1/RxMZKaAelAqbm9mlGthegNPIAmsGIFO25MJwyGyuh+/9259x4zYks93/t3uD9K7/d2mT2SCZivnCfyImiBi+7Kcwsx2FRF7X/XZ0KQzr5RsefX84dGIt/j6Yyt3//z661G+M1Hv7/f/vo5l4UGS2FS5MByaIMgQ0XhXiBBbHvjNmGTAyvOB59mvIe43963X+A/n1DK/uf4+3Z9j/9/vf/9/YGT6AChIseR1beqwnwTYAXJ/aHQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_c1b81aa9c2308cb7_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
