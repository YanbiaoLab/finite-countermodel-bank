from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,3,3,3],[1,3,3,2],[3,2,3,3],[3,3,3,3]],"priority":645,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.c554c0fee5b2f61b.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.c554c0fee5b2f61b","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgDhw4wMgwCugBJjAwKCiRpqWGUeCHPAdJWuIZWf+xC2GRUIAxBPDqd3gg0MCYMBpbo2AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAWjgLog4QWceYDZgsF2GHmtoQHBZnJADMQNB/DvvyVo/Lihm4Hhz////+sZGBT7aWbZgf/yTCBaAGgh0LL//MQPc5MBMm6nTg31WXpSTdpw692U9GduPr0zpAxNWwKFaGHb//9/WRQYGg6UOwDD9P9/e5aGzUAmAxNtMttLhUYWBiYhDwaFA8yWjLbAJOnC0EHT0KRbZvu/X0+og9PjQWcXAyiNzF/BcFFYganBgGk4ZLZdNgqMDu3qKpDMpsDo4v+AlUFpGJQjElY4pTDmpx4wyHLIDR2vKUAKfGzTLiwYqReojGMIZTagBwQZGTrATnaB+KZBwGlY1Gz7GDj+8LM8qGfkYFD4YC8AKhuZ/v1nHgZFJMMPLo0P9hMa/osqcCw48N+BiYOJgfMHsDZVwpLZGChOjwC+K2Nc'
_TARGET_BITS_PAYLOAD = 'eNrtmbFKA0EQhjemSJlOsToQa0vb1cJG7AUb7QSbiKgRBDdg4xsoWsTaQoQUQYJciBjBIsFKReJGUQTxvDRmJZfdcc+gKRIlUS+QY77mBvaGudmbfxZmFQAwaA1KFSCdIALAC+25rCs7VBRtueyqSuDNarLAPw37R3/TsJmK499CEARBEARBEARBEARB/pd435dJq6eQ8VFqjNVtadYHcX4gQLLu/JgtAgQJITGAm3nPglFSlO7T1gF1MFJqfcz9CzYHt+f2ElPDV/e58YGdrf7DxMLsQ+5sdd/yIhohPQ4HRjdMvaeEpB02oU2Q3oitl685IK0kcFrNqowuyRREPd3NjomNjJxb0XLSWF4Ct0ZmJmHomUuWl34Q29gxV+bK5XVNbFylDowKFHzQRx5Pvl1quJ8y4E7cdk9qvNbwm127OA3Vq18TXSQ2ncCLgujHJ6dq2TD7yBcn2yiIYMkxYkoAD6dttzfKAKn6oEVC6PUinI4w8sTFNCWmFBLKIX2aFpqIDf5cj++ORg3a'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_c554c0fee5b2f61b_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
