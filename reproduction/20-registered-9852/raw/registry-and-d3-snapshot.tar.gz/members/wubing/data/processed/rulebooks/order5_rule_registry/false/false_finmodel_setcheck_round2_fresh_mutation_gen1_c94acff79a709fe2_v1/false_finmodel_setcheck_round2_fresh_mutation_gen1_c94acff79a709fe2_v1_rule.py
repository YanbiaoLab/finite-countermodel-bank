from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,0,0,0],[0,0,0,0],[3,2,0,3],[0,0,0,0]],"priority":624,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.c94acff79a709fe2.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.c94acff79a709fe2","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2TFLw0AUAOB3aQpxakoFx4hLwcXi5CKJUsEt/gF3/4IQyQ0K8Rd0q/o/JM3gILjoP8hgoWPaKULI8xJB0OSktT0QfN+QHBzk5V3uXeCOAQCH+UQvTSB/lMfM1DJqOmIssWoPrp3mg42ajl553QYwf54Pk927q7PDY0en4SeEEEIIIYQQQggh5J/L8bOZIaKvNFiEllbcTQBebH+25t/m/oUUJWwV0cRzmz3gEZ6IMRUx1kWGDkBDSWqxLDVUES2TBbMUBOPS1FQMZSIL5qspNrSn7YMBjo/KYjtvo2gGO5eKik3+Gt9rYOmvufcx86pnHVEHvYuvxxnxtR+G1Q9PizFZoRCMrKXHPjNgM7HNYn5pOTY4JCPQoTyXE+szQ2TOKoptAcv/2dzJbHQf4E0a3D7hbCsYmvtv6D52H9D1+s9jsbD03WCYYfe1o0Hd+aOxQLR3+hQigA=='
_TARGET_BITS_PAYLOAD = 'eNrt2TFLw0AUAOAXAmaqGQt1yD/QRXBwSIP/Q+3WX+CBDgkN+Bfc/QNmEyya4OIkdRG6iBkFS9PJQNPc8xJB0OSktT0QfN+QHBzk5V3uXeCOI6KL87E3p0j+KJ8nRpzWdFhQ4tUeeDvXui81HYPy+oiY/Dwfmvf7x2fXl2FGw08IIYQQQgghhBBCyD+nwWdTBwBPaTAb4ry4J4husf05mX+b+xcMkIhURBPPnQ7QteFCjKmI8SoyDBFnSlKzZKmBimi6LFisIJgrTU3FUJqyYJ6aYoNofXzThdZVWWynYxBN9nCiqNjkr/G9Bpb+mncfM6961mGPwO99Pc6wjjzHqX54WozJCjmY6pPM8niKz2aUFPMr12DmotnGDMtzObE+cwAerqLYFrD8ny1oNtp7DA4NdrANjSfWSW7XINgZ7kLg97daYmHpB6yjw3BjlGPd+WO6QLR3Ul1Otg=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_c94acff79a709fe2_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
