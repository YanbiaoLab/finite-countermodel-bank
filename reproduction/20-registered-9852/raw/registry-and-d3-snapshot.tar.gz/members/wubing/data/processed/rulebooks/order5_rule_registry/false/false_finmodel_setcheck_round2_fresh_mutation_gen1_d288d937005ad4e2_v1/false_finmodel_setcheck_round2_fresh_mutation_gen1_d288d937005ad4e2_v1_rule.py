from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,0,0,0,0],[2,0,0,2,1],[0,0,0,0,0],[1,2,2,0,2],[2,2,2,1,0]],"priority":657,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.d288d937005ad4e2.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.d288d937005ad4e2","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2LFqwzAQBuD/7BRrkwIdOoTafYOOHgrx0vfog4RaQ4e+QdY+SdGjqNAHyOjB+CqXhi6hJIMgDf+32CDEwXG6gxMAHscJQUBnaiNuqM1JV2qRqXIHDpr9j/vzfhedlyemnoiIiIiIiIiIiDDpct4f+1dgVNUeuHvJFixoXcxflwKmYGqPX3OfPe2vrh3efOFSTlXXDo10BfIs5+Ocun1Ok+pyCvK7MA4qM0S7fx4+fIV2hI3VKtah9D0sNrkeW/sg0m3Lxc9jE9jPx9/N/j92055QvVjhlq2XsnqHGe0i9mLQ7FI7TpOmmLS8hIEzGLNbe69LmCYoCgPIkEZCnkbyBdEuYSA='
_TARGET_BITS_PAYLOAD = 'eNrt2LFqwzAQBuAzHjzmAQrVo4g+Sde+QYcOcsmD9D26ONDBY9+gdsnQIRB5k2ms+yuXhi6hJIMgDf+32CDEwXG6g1MADsexVkFnaqm+6sNJV3rVYvQHDrr9j//zfmO80yemnoiIiIiIiIiIiFDIdt4fu3ugFJEaeHvIFsxKH+evTwFTMBmOX3OfPak/Nx63LvqUU5GVR6dNRJ7lvJlTt89pMl5OQX4XxkFThmivj9W1G9GWGMy4Nr2dXI0By1yPrX1Rbe6m3c9jUwxXz7+b/X/soz2herHGO1svZXWDUA47U2tAt0jtOE2aWMh0CQOnCmGxck62CJ0VxABolUZCnkbyBXtDEBY='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_d288d937005ad4e2_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
