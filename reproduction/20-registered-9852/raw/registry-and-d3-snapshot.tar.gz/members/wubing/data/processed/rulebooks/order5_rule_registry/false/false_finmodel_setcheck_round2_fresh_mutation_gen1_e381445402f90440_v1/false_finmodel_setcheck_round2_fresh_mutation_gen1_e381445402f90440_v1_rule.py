from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,0,0,2,0],[1,1,1,0,0],[2,2,2,0,2],[3,0,3,3,3],[4,4,0,4,4]],"priority":635,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.e381445402f90440.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.e381445402f90440","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WTFv00AUfudca1eExo06IFGpVkil/oKoQ9Wcqgg1TPwExi5VYWPrMQBrVTrARP5BBiRYUOupUxlY6WK2jh47WBjHTiNB7rmOevnecJHvxf7y+d733rvLW6GIQpdGtp2PYT7Saj6q4qJOQX6RXyapIKNFacPsoNRlHDdXjCO88hjPDjNPMefQrzhPnXMM2gxH2uAcm9yzFMeEHJbKGOR6iorL3TqmIqccg+LDQKiYCZT83+H983iPJl8IiLcwza1GELvJwY4wYFRQa2DAogJNYNCSHKyLAdPACMlUBIwQoj9pN4lBIZKJ7ff7dVomlNgOv/y4rKPE9vng66ePILAoY9bpSRDa92Hn1/47HyS2bz+fPl6RMLG5RECxAcFCVC4ub4nmYodPgGBRLe7i0LbpzIGB6QZy1WIkGF0Idw2GGG5FGtYh0CNk0qIakBm9gMbIaftkr9UC6U2f9Jr9Xg9E7XnGbAn2Ip81l9o+qt6ofvBGEipLbvaREbmBLNoDOpY4tFXke9S+IgEj5ztegOO2i3yRioDMyIOm//J9tp9Y7Y6i0pMY9cHu3iBZL1e+1ZKuzx+WLmrbalKLO+Wp367qd3jWy2RbGyG/LLoAxLSR0teTU3RrbSTLbAQk7KLxJ+HzaPhOuZBTzb60XYQ0++v3nFGY2A1Jn0UT0s8I2mXHggXKfi0f/39kyvKGMnRtesRCdbTXxeINDa4H1eqgN7PYXprK+fRUYEo2M7WRhbIq5eJ7d9OS4zGPsLk9IFGQHXfML9IcbHGsOVElSIzSnCHVKDFJUVVCkqrN3dFGilYVGs59W4i/B8uTpQ=='
_TARGET_BITS_PAYLOAD = 'eNq9WTFP20AUduWB0SMbXmDtAFMnt2JpJQb+QTqVgaKutAPXja1FLB35CUwEVVF1QQwovwCJNDJSK3VAwaGpsMvF93DsNFKbe64jLt8bLvK92F8+3/vee3d5pyVRkNDQTvMxyEe6ykdZXPQpzC/yS9fRZDTf6Zkd5CSMY26RcQSLMeM5YebJ4xziA+fpc45am+FIF5zjnHuW5JhQylIZgcxPUEm4W0dU1ISjVnwYCBUzoVT/OuK/Hh/T+Ash8RY4uQ0IYnM52HsMGBXUehgwv0DTGDQ3B2tiwAQwQjIVASOE6JHTdD1QiGRiW9i+pBtCiW1vbXmljxLby/0XrzZAYH7GrNVQILTV9dbSp7cRSGzPH3/+fq1gYkuIgGIDggWoXFzeEs3E9r4CwfyB18ShndKzFAYmeshV85Bg9EQn32CIwZkvYB0C/UAmLRoAmdEBNEY221vHnQ5Ib2Kr0a03GiBqhxmzW9iLPOretiNUvZH1cEcRKkue15EReYEs2jV6o3BoV8j3KCJJGkYuSuMQx+0L8kVKAjKjGJr+y/fZkWu1O/JLT2Lka7t7A/eyXPlWS7p4+rN0UdtWk5rXKk/9dlV/wrO+IdvaCPhlEQUgpo1UkRifoltrI1lmQyBtF40/CZ9Fw7fJhZzs1pXtIiTYX3+cDsPEbkhGLJpWUUbQLjsWLJT2a/no/yNTljeUoXnTI+6qo+0Wi7ducP2qVgfjqcX20VTOJ6dCU7KZqo0slFUpFz+4m1Ycj1mEzZ8DEgnZcXv8Is3Afo80p6sEiVGaU6QaqccpqkpIUrW5/7SRulOFRvrQFuIeRLXdgg=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_e381445402f90440_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
