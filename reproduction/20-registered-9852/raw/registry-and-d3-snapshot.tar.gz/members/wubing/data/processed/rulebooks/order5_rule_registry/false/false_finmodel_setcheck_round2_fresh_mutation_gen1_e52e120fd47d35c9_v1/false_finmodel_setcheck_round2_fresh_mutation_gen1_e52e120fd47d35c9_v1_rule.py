from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,0,0,0],[0,0,0,0],[3,0,0,3],[0,1,1,0]],"priority":627,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.e52e120fd47d35c9.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.e52e120fd47d35c9","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgDhw4xckwCgYp+HP606/98yRI0fIfDPgxJRRgDAG8+h2ehkzRTGEBJiAhpdEIGAWjYBSMglEwCkbBKBgFo2AUjIJRMApGwSgYBaOAIGhoQrCZPJgUhpPf/v3/H/8tTW/9/9er/4IGHn9l/f//unPreQl2Glh24P//Tf/j4/7OD/+zHDzM6b9m3o3//z+dXE4Lr0WI/y25KL1wTt0q9SnBfh9bHnEfte9SF7FzFqCFbf9xAfbRDERSZsMZkMw0sO0DLsvqaZTZsAN+GljmMJsHRHFgk8IQifQNc+MhrAxPZrNkJFrtg0VznOQYR5P6KKBpzZZa+Tfe/83/0/c6nn6tt904w195/b//6l8F2TDV/vi/yTwJpFzn2eUTq///96xtGczp8weucsQeS2ajuLQBANv79/A='
_TARGET_BITS_PAYLOAD = 'eNr79/////r/xAF702//R8EgBcwmvKwOic9J0cIABh8wJe7DGO/x6t8vtTr72uzfwAT09u5oBIyCUTAKRsEoGAWjYBSMglEwCkbBKBgFo2AUjIJRQBDU1yLYf7f/vT+c/MbIwLCAc+bFAAaRECbQwCPrVAYGkTIvg+c/aGCZPQODL8OChUwJK5gjwMOcG4IT1RkYeM0iaOG15S+YuvWexCU3ht7IXrORr1r2i9WB0huvD+55TwvbGHCBH6MZiKTMhjMg/9DANn5cljXQKLNhBx9oYNn+lM8g6js2KQyRZZtW7vxMWBmezHbsH9Fq5WOT9z78N5rURwFNa7ZZbUwLNggzmCiWS3E1HPJL33AngJHhBte7n5hq2Rl8T8wFKb8sqWMewsCwral6MKdPdlzlyAEsmY3i0gYAcHZ5Nw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_e52e120fd47d35c9_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
