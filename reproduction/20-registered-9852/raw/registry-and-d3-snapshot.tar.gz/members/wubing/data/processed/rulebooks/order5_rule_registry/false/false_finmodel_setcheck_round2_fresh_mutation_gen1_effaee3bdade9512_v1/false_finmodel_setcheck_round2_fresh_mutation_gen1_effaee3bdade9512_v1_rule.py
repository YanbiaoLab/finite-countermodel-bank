from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,0,0,1,0],[1,1,4,0,0],[2,2,2,0,2],[3,0,3,3,0],[4,4,0,4,4]],"priority":663,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.effaee3bdade9512.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.effaee3bdade9512","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrdWMFKw0AQnd0sJZVCoycv4iJFevQLZOipHgTvXnL0IwS3goeCh1D8gB78kJz8jn6CRw+FGNIgSJ01IZsHOoeW5TV5ndl5u2/3iZgopyom1SfvBub7wFaDanhPQmwiCYkk5O5IAPhRetdAAjIJcBJQJ/lDrMVHlBKAWHqCxXdpCbiov9O9VIz0aA2YPcCKqe4ysfL/20vMen6WF6eEi48iArIVD0CyTTEGsm0LhSNzZWa4Ur4rSnFd8jY+TuUFJXDk5ZJ9Akttejs/W8LYrtVwAiNbX9ECx/a6tA7WI84s6FABxQaMSyRZniPZREvUSww1kCxFZkYTJJmDtn8GLeQMScY+vx48YmghoT1ioam9INXmVgbIdlPWEjdzMx3jZo6ZCFfKKVZs6t+KDdn95BIkWwKtJdL8eO6B/v7O9svVzzaoFjf+Q717DpraaAQ0fu5cAT1tZpHrzMALBVY9y9Iu7aUboMRmelC+2CKOw5vMtYis+tjZjLh4xsG3Peedz9CnkMQ/n4F7RGx/y+FnLZeP93HDW4AWczuXVXDQTJpxa7HZRts52xY95rGRSbdloA8b2bltvvZJyI18BvVctdi0auT5dLfzA8s9zM1MZ5ui1DRKN0lDd7UQn0NWOjk='
_TARGET_BITS_PAYLOAD = 'eNrdWMFKw0AQDfTg0U/od3jKh3joB0jJQehBsCv4ER5z8S54sKcy+AUeiwRZ8eJJUyg2lO3uGNIgSJ01IZsHOoeW5TV5ndl5u2/3jIk55iqy6pN2A/N9oKtBNbxkIYZbCdlKyNWbANC59K6NBCQSoCSgTvKHGImPOCcAhfQEie+yEvBQf6d7qRjp0Rowe4AWU91louX/t5eY9vwsjp4ZFwfRFsgWXQDJhtESyDaIHI5MlZnhSnnoOMV1ydHyNZUXlMARl0v2Cyy1xfXsaQJju3XrDEY2uuMpju14ohWsR5SZ8rsDig0Y90iyOEayiZaol1hbIFmKzIwzJJmCtn8CLeQcSUY+vx48CmghoT2ioamdINWmxgbIdlPWEjdzc1vgZo6IGVfKBVZs7t+KDdn9rHIkWw6tJdL8eO6B/v7O9svVzyCoFof+Q706DZraagU0furRAT1topHrzMYLBVY9ydIu7aXaoMRmelC+2CKKwpvMkYiM+9jZjLh4FsG3PeWdz9CnkNw/n4F7RGx/TeFnLZaP90XDW4AWczuTVfDRTJpFa7HpRts56RY95rGRebdloA8b2bltvvZJyI18AvVctdisa+T5bLfzA8k9TM1MZ5ui1DTONknDdrUQnwkqNv0='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_effaee3bdade9512_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
