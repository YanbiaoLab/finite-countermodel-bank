from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,2],[1,3,1,3],[2,3,3,3],[3,3,3,3]],"priority":652,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.f07c3934a107ac4e.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.f07c3934a107ac4e","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgDhw4wMgwCugBJjAwKCiRpuVPd9Ev+3kCpGiJZ2T9xy6ERUIBxsBvnMMDgQbGhNHYGgWjYBSMglEwCkbBKBgFo2AUjIJRMApGwSgYBdQFCS/hzAPMloy2w8hrDQ0INpMDYiBuOIB///8rMwg4NPxnZPnz////ekaG/0AmAwMLLSw7ALTBZpFdzKf9J7v/g4DRo//7T3ArXhGnhW0//sd/+d+98H9xl/4XkGWvOY8K//ovb5coQAvbgBboVylOufz/Y8s/UEDaLPwPZB5S52CiTWYDpUkBlMzGMTwyGzDwKl1qdjypnygOTiOuR/4DmU4d+sMhs+2yUWR0mK6uwgDObAqMLv5PXBmUhkG0RViAKaKKjQdKMgxyQ8drCpACn6hSowGobAjlwwZgfAkyMnSAnewCibwGAadhUZj8c7X8K+//4n93HMfTL8DieIK7Yv+//+wfBVmGvNd+cGl8sJ/Q8F9UgWPBgf8OTMA6hvPHf35QQYJlMpgDazolHgAAe3+JJg=='
_TARGET_BITS_PAYLOAD = 'eNrtmc9LwmAYx58l4kGySxQU4R9Q54Ii5iX6KzK6BUF2WHjo8ApRp/oX0ujQ1WMoMk2wU+AtodyMLhLlOpSTzPfp3aQkkJjQAsfzuewL27vvnvf5Mdg4IjJ0hixzJP6DGKJeHWyJTzn25zeMQZak+LvUeu5zQv8Sv99ODRuMJylbBEEQBEEQBEEQBEEQxN+SnPiW8keJX3ooNMZ6uqP2PsR5AQngDg2VAW/7ACDBEYREbLthJguH4lrhbDQyr4DF9QxEFl612bobbgFIBUGJwtFuOWiZjTcXn/xQK5wYbrgJg/KBtjUHoT3J2shiFIRcrpgdd5rNqknjR7OZ3mg2sXmH2f3V6cR23a6RzBIImYuXvdBsK0WNq5uVW7SbTefZ9HQGqx5I2/mVfXA0NsLVB7wfntD07sB3NDWYuGyI+pCJfDU4xu1HznaTx4ycJ4aJlCmN1NKToJyaU0ExjmMX2o4ErVCjPfShBd5uxvIxBo+6uS6D2hHvmGYAXqxB0udnsNm3Tp3zCdDy6AE='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_f07c3934a107ac4e_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
