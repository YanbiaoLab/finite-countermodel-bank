from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[3,3,3,3],[0,3,3,3],[3,3,3,3]],"priority":640,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.f587223285aa9376.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.f587223285aa9376","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmV9IU1EcxzfTIquX/iBSUNZDiFSYDyXRJhVBRIlQTAkdjEgSdNRkYmpnj5GCDwUmkXsJhCa7pbGLXe36EJZpLohlOueVqI2WunBsa3/O/XXPpXrZpN2H24Ocz8OPyz0/zo/f73y/98K9Wo1GY9P8i+cTJI693ayh/A/eu7xNg2WW9AUbzJjBzeekr6QEMcGLhekLizgmNMVCGaromUlxb2te+sJT+bif1HRVncrN0VSXa0nlzpv5rc1VF4u6/6ZVfL10v/hqrrS2fT89MwqFQqFQKBQKhUKhUCiUdU0jt+ziONZnbYm5Hi5NzftGyyz1/j7L9AYVii1CBAB4UQry17AEikmXEIcrarSWkmt5pTCaJGX0cmFjEG1ToZgN1kKNQf6ABGmFbP+dhYAR83KHKTikxiDJ2MC8IgUHJpcJM4ksFG5SodgYwCAY67DdkOqX51c50PcJYHWiX43Wfq51ano1qpGNGYhKwwzJM3UzJPYkjKqYDccEBCAmQyAgzicppAVWRF8S2tQyGwRmpJ5kaQL4SYd6oX2LWmabQZLm2Rb4UxjgPGa068BsPRhWgzDyWS+bDZkir6R7lbo8FYpVeJu4iempDH+HBueczjnrvUe9Dof1mrOr2tJ1o6bRYGgk6Z7LJ8oMZwfKx4/v05z5vVGuLQuzIRyFVEkmzyPcnliGuMHsDtoxHPGjIPC3dSTdwdZH3CIUhPUKBwAsLzJoYybPs2w9wkZYCnxIOQDO4W4MXu8QSY+Gr4segMfia+Vmy/yvxohjsWXetyLgDg4ZogPDMMyIyWSUpIsvfXxJ28d52KPQbCOHk+jLrkwv2BGTrjYKbxzHZNkUnNZFUF2pnaR7dj+7ZQLoLLLnKDOby0d0MNnAvWjwXpDE4JzrHT5qelc6rs1KNorNRnQAEAl/I2YbPelAUeAfQHFWsslXaDazrAMQFvpwBOEhe2WYEeFgRJ+dbJQ9bcaSIaKDjoggsGDlkKQLsXZ2yC8GspJNucI3W6usAwjfjTfPwgFm4Y5nRxKMW+M7s5KNQrP9Av3OnOE='
_TARGET_BITS_PAYLOAD = 'eNrtmV9IU1Ecx3/37G5tl0lTW2xFeJ3TbATNNEt68KZL7khrwwVCLzPChHoQNHrcSU0crpiCYcRgSugoEIsIosItwnowqRDpoSwoRPrzUhmluXXPpXrZpN2H24Ocz8OPyz0/zo/f73y/98K9yVQqFUj9i0OVJFbv+Zai/A92ue39DdOh9IUAlIbBKaymr2h4RiswC+kLBUjP9+tNGarEPRXMm57l9IUj8nEfHW0fv7+ymhqbSpLKHReWevrGb8y3/U2b3HL91NyVFWnt0yt6ZhQKhUKhUCgUCoVCoVAo65oBV57b5RJtwV69+0R+eZGtZjo0ZG0Olf1UoVgBcAAgMFKQv4ZpsV66BB1cVaM1jVzLLoUalpSJy4WjZvxZhWIBWAs1BrkRtKQVsv0mESxRJMgdauC5GoMkY4NwrhR8iFxqwySKsPBdhWLVAA0QHUb+mKZJnt9EY/N2gJzKJjVa27DWqcXVqEY29oBBGqZJnqnTQ2KrNqqK2ZCexwAMawIeu2ySQnohl7Gx0K2W2cBSKvUkSxPASjqM811f1TJbKZY0L/bCn8IAt5AnuQ7M1oogxwy12+Ky2XCE2y/dm0gsq1Bs0t7vqiwrz/B3qKHY6y0Onj7e4vMFL3vbx0LtF0cHYrEBku649nA6dqdxqurR69Td3xutBLIwG0YG0Mxm8jxGXdo80MXCTrMfwVMrNoNwLkHSfeIQ52Rg0RhXOAAQBcaDf2TyvCgOYRSFfMtOjQ/gNmpDYLfXk3SD8RLjADjG7FNutsz/aqJIr88TbLk86nThmKGxDuo8DMsaSDpzwCbMdu8ogrcKzVb7jMVb32d6wdZGEiMG2Ot7LMtm8V6Cw8MzfpLueHf4fASgY96/qsxsbhvRQcWg6+Cg/aYkBm9xS92TyO6ZqmRWslFsNqIDAM64mZit5oEPG0A4CXNZyWZJodnCsg6AL2xGHEb1/gmjh4EXXDw72Sh72lSzJqKDTo7nRQi6sKQLZqSk3spYspLNlMI3W4+sAzCe0fWVwEtP4VnHRxaiX3QfspKNQrP9Ak6j1EY='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_f587223285aa9376_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
