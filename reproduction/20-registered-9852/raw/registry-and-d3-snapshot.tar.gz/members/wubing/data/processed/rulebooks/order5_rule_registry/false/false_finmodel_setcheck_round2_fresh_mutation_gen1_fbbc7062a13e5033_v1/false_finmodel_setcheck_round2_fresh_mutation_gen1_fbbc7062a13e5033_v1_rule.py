from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[2,3,3,0],[0,2,3,3],[3,2,3,3]],"priority":638,"rule_id":"false.finmodel.setcheck.round2_fresh_mutation_gen1.fbbc7062a13e5033.v1","rule_key":"false.finmodel.setcheck.round2_fresh_mutation_gen1.fbbc7062a13e5033","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2TFLw0AYBuD3koinU66DUymXtLi4+QcM5YYWHAQXZ7Gjo4OTATNcIINkcHBxcisU+gsydOzq4OLvsNJ63tWlgyAWAyrfs1zu8sHLXQgXcgxACvJHpGXWKbX+5M483389KMIfSZEfDUP4dZ1EQI+FEEIIIYQQQggh5N/bWrnWnNZjXWmpGn2lblRDiLIXx12VaS5El0d1pB3ZiFzzZZCL1ToUUWzDavml92a2uQTYhsTcGHMlkXgp4NWykJUxaKLVTP3q2jhAC5WParOOtJfLhTHTkTH3s4sn0x49TxduhsVsp4608/Fwd699+3g2mIzvhsXJ4YM4HkzKU+7TC0QI+Y072+qeoujMaG1JP84D6fVknqLfESKSiQo0kNWSxlkQJraRYGCB3bLdaTFzZ34eT2yPcYRww3bQ9gJbuSzwbMn3vwPfATslUgw='
_TARGET_BITS_PAYLOAD = 'eNrt2TFLw0AYBuCzxfo7XBxcO3bILygUujm5ODgEh0BuqBAnB0fHirOL4CCkw1HiH3BzkTY5SieHXiY9Mcm93tWlgyAWAyrfs1zu8sHLXQgXcgZABPJHRP5g4nP+yZ1meL95F+Q/kiI/GoP86zqJgh4LIYQQQgghhBBCyL/3snLNNa3HuiJfLGIhjsRCKX+UpmMx4Fqpsc7qSLuxESHXyyAXy3mustSG1fJLb4M9awmYN4kmY+xEIqkioKplIT3GMMdsHpXeMXOAGbwS3msdaVunDcbaPcb2W2c7bNrbbjfcDIPWUx1p593+48P0cPdi2Oke9IOr2z11Pez4l7qkF4gQ8ht3ttU9RdCZ0dqSOA0LWY1kGCGeKJXJRBQcGNSSpk2RJ7aRMDCF3bLdabFxZ36VTmzPaORww3bQ9gpbuSyobMn3vwPfARFbHyo='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_round2_fresh_mutation_gen1_fbbc7062a13e5033_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
