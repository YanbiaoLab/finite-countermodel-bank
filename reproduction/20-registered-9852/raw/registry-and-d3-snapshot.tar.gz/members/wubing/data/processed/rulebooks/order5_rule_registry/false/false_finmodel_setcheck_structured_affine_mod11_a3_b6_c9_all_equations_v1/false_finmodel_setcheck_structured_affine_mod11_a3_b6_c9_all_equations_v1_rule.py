from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin11_structured_affine_mod11_a3_b6_c9","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin11_structured_affine_mod11_a3_b6_c9","model_table":[[9,4,10,5,0,6,1,7,2,8,3],[1,7,2,8,3,9,4,10,5,0,6],[4,10,5,0,6,1,7,2,8,3,9],[7,2,8,3,9,4,10,5,0,6,1],[10,5,0,6,1,7,2,8,3,9,4],[2,8,3,9,4,10,5,0,6,1,7],[5,0,6,1,7,2,8,3,9,4,10],[8,3,9,4,10,5,0,6,1,7,2],[0,6,1,7,2,8,3,9,4,10,5],[3,9,4,10,5,0,6,1,7,2,8],[6,1,7,2,8,3,9,4,10,5,0]],"priority":355,"rule_id":"false.finmodel.setcheck.structured.affine_mod11_a3_b6_c9.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod11_a3_b6_c9.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2E0KgCAQgFGVWbj0CB7Fo3n0gihUGl0JZt9bCbnRkfnJGoUY/Jh7VlbflLgnYHveqVXizA7hy0eLerXzbYLLvIRlypNckZNeUMuwee4ME+WicQpxsFk8vRMAAJgws1UNR/XJvo4y/PBbqI1M/XG1jBiTDbC+IPd82LKj9A0A2zsAbmQEwA=='
_TARGET_BITS_PAYLOAD = 'eNrt2E0KgCAQgNGjezSP4hFcuhgcC6JQSV0JZt9bCbnRkflJU4Mk/Fh8VtreZLknYHshNqvEmR38l4/m2tUu1AnO8BKWKU9yRU56Qc3DFrgzTGSyxsm7wWYJ9E4AAGDCzFY0HMUnfR1l+OG3UBtp++NqHjEmG2B9Xu75sKaj9A0A2zsA3g1sdg=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod11_a3_b6_c9_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
