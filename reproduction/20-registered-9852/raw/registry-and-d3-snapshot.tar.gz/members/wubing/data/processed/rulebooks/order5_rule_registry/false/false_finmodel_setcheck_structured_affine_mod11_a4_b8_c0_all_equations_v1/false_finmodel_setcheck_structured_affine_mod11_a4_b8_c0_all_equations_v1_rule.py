from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin11_structured_affine_mod11_a4_b8_c0","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin11_structured_affine_mod11_a4_b8_c0","model_table":[[0,8,5,2,10,7,4,1,9,6,3],[4,1,9,6,3,0,8,5,2,10,7],[8,5,2,10,7,4,1,9,6,3,0],[1,9,6,3,0,8,5,2,10,7,4],[5,2,10,7,4,1,9,6,3,0,8],[9,6,3,0,8,5,2,10,7,4,1],[2,10,7,4,1,9,6,3,0,8,5],[6,3,0,8,5,2,10,7,4,1,9],[10,7,4,1,9,6,3,0,8,5,2],[3,0,8,5,2,10,7,4,1,9,6],[7,4,1,9,6,3,0,8,5,2,10]],"priority":360,"rule_id":"false.finmodel.setcheck.structured.affine_mod11_a4_b8_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod11_a4_b8_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq1Wd1u6zAItpEv2J13ngBNfRAm7WKPZVWatMdemqaNE4N/ig+atrR2jIHvA+z9OHa3n5sE5/D54bL+fo7Q+oG3aauAOwlt82M26S5+fzy+9b0/xvd8gLNnPLwDxfhjAZeezykfSJl+PLwSnCLE2qS3/fEDTqaQuBZnax3VV0xx8lB6OLNw/rbLUEbF7+MgRIVyhZLgroAq03hHgTQkuNq71wW3PQdxnVh6jQzKdPzeteE8u/aArY77Ut0sg3BcsrgkwUfHrz5tuh60lNBGheOMhlUSgoBG3ieF17RBUJwmLIqLcSbzuOFmPM82wR9jFdx8jCOetI/K2wC4v4Izky31z172cyxTo2QLGiAF2PiyYMwimwLz4KsVoEE2DSMomGvlNtz3XyZ2OmxmL7Cx5e0KQ1jFfpB5aCLbdx37PJcDvprYBTwg6Cu1Ch+p2RUEbVaMhB11bbKt2uxkk/iSCqutSetQ2Uqvp8mQvDrk3j2zAzJFjtNA/+RvRxJvcGmlsuF8anuhPe9qOl+qbGo/ENFNl+BqdZTIzSRAyhK6b1U2YivZqL9D4GVf0dRG/oP+6P+iTybTGEZQvcyijzltJHWl+nbkYruNhMbx9gmqX+OZDboLl/XMdtEs4vnEvpEtYO/adrJt7MGOMsvLrGA7s4GCSFpWhDG89bSR11orDocYktGRqGZEKJBih43XO49CAXZ6suZifiwRhPDgrAuEs+/wP5TpE74zbe9+fubQ0XxtHhHRFLTKbeeqiOYmMs7DD+ccksbPt72VLQku5GZ7/grZBPSUbqNoVKbfhINgjFXbJW9uGoBIXYmf62SD7gsPNmaUGLV+x1PhNzPNVbJRT70YJ9v+p0gaqSciAwV8y0M+h19UjUCjrY9/khQR4dKTwldpiBLkVQyQuDNTLtErm5dhEzthV+3cQCxDfmStrspGCtaiGGO2k82B70jIsl3UT4DtzIYCawRt0uXgiK2oYg2kiyILrxf5A/6aP40='
_TARGET_BITS_PAYLOAD = 'eNq1Wd1u6zAIfuxJR6r8WLuYNB6kmniCzXfjwsI+aZo2Tgz+KR6atrR2jIHvA+z9S5BuPzcJKdHzw3X9/RzB9QNs01bhdBLc5vts0l3i/nh8631/9D/5AGTPdHiHi/HHAsk9n10+4DL9dHglJEUQtEm/++MXn0xBcS3I1jqqr5iS5CH3cGbh/G2XoYxK3MdZiArmCiWhXQFWpsGOAmlIcHVMrwttew7iOr70GhqU6fi9a6N5du0BWx33obpZBuG4ZHFxgo+OX33adD1oKaENC8cZDaskBAGNsE8Kr2njoDhNWJQW40zmQcPNdJ5tgj/5KrjhGEc6aR+V3wFwf4RkJpvrn73s51imRskWNEAKsIllwZhFNgXmIVYrQINsGkZIMNfKbb7vv0zseNjMXmB9y9sVhoCK/SDz0ES29zr2YS4HYjWxC3gg1ldqFT5UsysL2qwYCTvq2mRbtdnJJvHFFVZbk9ahspVed5MheUkEvXuGxGiKHLiB/inejiTR4NJKZaP51I5Ce97VdL5U2dR+wFOaLiHV6ihimkkAlyX02KpsCFayYX+HAMu+vKmN/Ob+6L9RdCbTgEdQvczCrzltJHal+nbkfLuN5Mbx9gmqN+OZjbsLl/XMdtUsgvnEvpEtUO/adrJt7KGOMgvLrGA7s7GCSFxW5DG89bSRl1orzocYotGRpGZELpBih03UO49CAXV6suZieCwRhPDQrAuEs+/oD8r0Cd+Ztp84P3PoaL40j4hkClrltnNVhHMTGeTh53MOcePn297K5gQXQrM9f4VsAnpKt6E3KtNvwlkwxqrtmjc3DUC4rsQPdbJx94UHGDOK91q/E7Hwm5nmKtmwp16Mk23/UyQN1xORgQK+5aGYw8+rRpDR1sc/SYqIQOlJ4Ss3RAmMKgZQ3Jkpl+iVLcqw8Z2wq3ZuLJahOLJWV2VDBWtejDHYyZY4diRk2S7sJ8B2ZiOBNYI26XJwxFZSscbSRZGF14v8B03XMak='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod11_a4_b8_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
