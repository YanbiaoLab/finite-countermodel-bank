from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin11_structured_affine_mod11_a5_b7_c0","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin11_structured_affine_mod11_a5_b7_c0","model_table":[[0,7,3,10,6,2,9,5,1,8,4],[5,1,8,4,0,7,3,10,6,2,9],[10,6,2,9,5,1,8,4,0,7,3],[4,0,7,3,10,6,2,9,5,1,8],[9,5,1,8,4,0,7,3,10,6,2],[3,10,6,2,9,5,1,8,4,0,7],[8,4,0,7,3,10,6,2,9,5,1],[2,9,5,1,8,4,0,7,3,10,6],[7,3,10,6,2,9,5,1,8,4,0],[1,8,4,0,7,3,10,6,2,9,5],[6,2,9,5,1,8,4,0,7,3,10]],"priority":357,"rule_id":"false.finmodel.setcheck.structured.affine_mod11_a5_b7_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod11_a5_b7_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq1WUtywyAMBY0WWuoILHoQcjPamd678aexMRKGSNF0knGwLT3xnhD0N+Sw/C2G6+flIm8XKZ8uNoNwsbR/8/IRzyNRe4SCYvk/jhBKPQLaI1x9nay83nm1HQq2UNTAHtoA1VBPUFiDCscjJEFZ56ZIUNZHkwoltrOCrfu43pdENEdGIm1uUb23zq5yD9LQvI8anWDnK6wrB6LVW+xyj0lj3FumJ5mxAYsi4ycMD2aQACK15Lmfu6wNlD7qCMHT1IKwA4KJ1N8bdMmGOQzXvgHb35aTOFSc6U9wqwxHe7yhDKvYcOTeYvaGUXtPaWTDRYgqTzgrp0cg3NGP516uiW0wd1ahw0wweXiGJ8uZOJVWkp5WtiLAyr7833qA1ROPkP1DK9s2qegKDVV/4NGBjOflmWFiV2+se05Nms1Zhd0fjirfou68T08ZceTWRrZ5xCB2lkaxEYoqKM6q7q9shCM/8dQ0fnVplvzFBjrRbMum0HXzm6vDmysb7cyk20Rafe9b0xQi3ycyktGd2kaW8AF76MUzfkBsvbXG2yHqFGjqS3IQG4BY2On14advfm6UIKk7jeiyoL3sRwf9jANnGtyhlS1O9c4muVFHyGJuTWtp7Au5QrKcaLm0kaxIi66RsYfYaGAHvEbGZBLbbAdt8MZHZpJESWzpEgdeOr9nW6pWbhgD9j1blnNcpByiXWwos6eNgopdbN/jbaRBAPpJOMzvywcPSMT5dO7qDrHxkKbM5Z9Ry9AHztD0fy2kNnUlGKtKVgs7knh3Lq1OsHvdhiYVdpKlXe7BUV9sQmEXzl63n7jOLYt6hPvy3s7bjy9tqhw3VT5XAXm0kS9m1oVdPRu5LyZq281nZrZ9XPRttvZAIV65JhZkEIHgpNhIGbpU0CwwJU/su2hzFGUYpc4cjOzFe/YH0UE5aA=='
_TARGET_BITS_PAYLOAD = 'eNq1WUtywyAMvXdnWm4WDtIFR9BSC42g8aexMRKGSNF0knGwLT3xnhD0q8Sy/C1G6+flIm4XKZ4uNuNysbR/w/KRzyNZewSLYvE/jlJCPcLaI1B9nSy83nm1HQq1UNTAHtoA1lBPUECDyscjKEFZ5yZIUNZHkwolt7NCrfu83pdENEdGMm5uSb23zq5yD+HQvI8anmDHK6wrB7LVW+5yD1Bj3FumJxmoAUsi4yeMDmagACK15Lmfu6gNhD7qzMXT1IKwA+KJ1N8bd8lGsQzXvgHb3xaTOBSc6Y98qwxHe7yhDKvYaOTeYPZGWXtPaGQDQYgqTjgLp0e43NEP5l6uiW0wd1ah80wwcXiGJ8uZOJVWkp5WtiDAir7833qA1ROMkP1DK9s2qeQKjVR/7NGBjOflmWEEV2+ge05Nms1Z5d0fjSrfou64T08YceTWRrZ5pCJ2lkaxIYkqCM6q7q9sSCM/wdQ0/nZplvzFxjrRbMum0HXDm6vDmysb7szE20Rafe9b01Qy3Ccyo9Gd2kaG8gF76MUzf0BsvbXG2yHpFGjqS3IQG7NY2PH14adveG6UOKk7jeyyoL3sWwf9jINmGtyhlS1P9c4muWFHyGJuTWtp7gu5QrKcaLm0kaBIC6+RgYfYcGAHvEYGaBLbbAdt8AZHZpJESWrpkgdeOr9nW6pWbBjD9j1blHMcpBySXWwks6eNAoNdbD/jbaRBAPpJOM/vywcPSMT5dO7qDrHBkKbM5R9Iy9AHztD0fy2kNnWhGKtKVAs7oXh3DK1OqHvdhiYVdpSlHe7BYV9sQmEXzl63n6DOLYh65Pvy3s7bty9tqhw3VT5WAXm0kS9m1oVdPRu5LyZq2w1nZrZ9XPZttvZAOV+5JhZkFoHQpNhQGbpU0CgwJU7su3BzlGUYoc4cj+zFe/YHezA3zg=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod11_a5_b7_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
