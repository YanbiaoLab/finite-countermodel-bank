from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin11_structured_affine_mod11_a5_b8_c9","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin11_structured_affine_mod11_a5_b8_c9","model_table":[[9,6,3,0,8,5,2,10,7,4,1],[3,0,8,5,2,10,7,4,1,9,6],[8,5,2,10,7,4,1,9,6,3,0],[2,10,7,4,1,9,6,3,0,8,5],[7,4,1,9,6,3,0,8,5,2,10],[1,9,6,3,0,8,5,2,10,7,4],[6,3,0,8,5,2,10,7,4,1,9],[0,8,5,2,10,7,4,1,9,6,3],[5,2,10,7,4,1,9,6,3,0,8],[10,7,4,1,9,6,3,0,8,5,2],[4,1,9,6,3,0,8,5,2,10,7]],"priority":354,"rule_id":"false.finmodel.setcheck.structured.affine_mod11_a5_b8_c9.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod11_a5_b8_c9.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt100KgCAQhmEVFy49gkfxaB69TKSfsXCRQfI+UBS6iEnGT60wWFwvq1TIz/p/n/7Adc0CgF46d8vSLrdbqgOpMTlRL0zFebe/mOOIqeudDRcfMlvSi41+G/siY6CGs7PlJxuxBGJzhxc8JQSAl2LkuTvL/fyaLIHRMbIuxiCHCAAA8OGZzcuocHdAA4ZbADsBBiY='
_TARGET_BITS_PAYLOAD = 'eNrt100KgCAQhuGje7Q5ikdw6ULU/pB+xsJFCsX7QFHoIiYZP1NGZzJfIWe7PKfvffoD3zQLAFqlpVtu7XK9mTJgKpMN9cKveOf3l3gciWW9s+FioLgmPan0W2mLjJYa/l3YfnJUS0CqO7ziKCEAvBQjz91Z7+fXZAn0jpFlMVo9RAAAgIFnNqejwt0BDehuAhF/axA='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod11_a5_b8_c9_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
