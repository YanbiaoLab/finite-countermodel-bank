from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin11_structured_affine_mod11_a6_b3_c9","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin11_structured_affine_mod11_a6_b3_c9","model_table":[[9,1,4,7,10,2,5,8,0,3,6],[4,7,10,2,5,8,0,3,6,9,1],[10,2,5,8,0,3,6,9,1,4,7],[5,8,0,3,6,9,1,4,7,10,2],[0,3,6,9,1,4,7,10,2,5,8],[6,9,1,4,7,10,2,5,8,0,3],[1,4,7,10,2,5,8,0,3,6,9],[7,10,2,5,8,0,3,6,9,1,4],[2,5,8,0,3,6,9,1,4,7,10],[8,0,3,6,9,1,4,7,10,2,5],[3,6,9,1,4,7,10,2,5,8,0]],"priority":356,"rule_id":"false.finmodel.setcheck.structured.affine_mod11_a6_b3_c9.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod11_a6_b3_c9.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2E0KgCAQhmGNWbT0CB5ljuYROnIIwqRkPyux3mfpJEKofZN3RhyQrU8fDDZFk75dgQ0HAAAmlpy3NBOPlbNUlMcWXtrfeGu0wl3E1pg3FcbbuhWR5qzPRp1edHZNjQsLwHDlypXeJ7Qa5x8TMAvpZQ0tXVadUAAA37ADyfMF7g=='
_TARGET_BITS_PAYLOAD = 'eNrt2E0KgCAQhuEjdwSPNkfxCC5bDDkhCKZkPyux3mfpJEKofVO0Qg1I1qcPhjJFnLxdgQ0HAAAm5iyWNOOPlbNUlMY2XtrfxNJohbuILT5tKoy3dCuqzVmfjZhcdHZNjQsLwHD5ytXeJ7Qa5x8TMAvtZQ3JXVadUAAA37ADgn5rSA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod11_a6_b3_c9_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
