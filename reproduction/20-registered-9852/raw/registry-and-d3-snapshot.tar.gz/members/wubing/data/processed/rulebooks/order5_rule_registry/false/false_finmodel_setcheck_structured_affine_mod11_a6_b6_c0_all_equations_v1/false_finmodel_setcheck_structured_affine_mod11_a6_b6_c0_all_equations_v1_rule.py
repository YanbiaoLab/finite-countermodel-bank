from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin11_structured_affine_mod11_a6_b6_c0","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin11_structured_affine_mod11_a6_b6_c0","model_table":[[0,6,1,7,2,8,3,9,4,10,5],[6,1,7,2,8,3,9,4,10,5,0],[1,7,2,8,3,9,4,10,5,0,6],[7,2,8,3,9,4,10,5,0,6,1],[2,8,3,9,4,10,5,0,6,1,7],[8,3,9,4,10,5,0,6,1,7,2],[3,9,4,10,5,0,6,1,7,2,8],[9,4,10,5,0,6,1,7,2,8,3],[4,10,5,0,6,1,7,2,8,3,9],[10,5,0,6,1,7,2,8,3,9,4],[5,0,6,1,7,2,8,3,9,4,10]],"priority":352,"rule_id":"false.finmodel.setcheck.structured.affine_mod11_a6_b6_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod11_a6_b6_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WUty5CAMBUpdRWXFYg7AIos+hqZqDpAjqRfZ5wh91Ik/iQ1IYBrZqlS622DLkt5DD/vToDH/zGww/0f2R/TTD5wOLyPGvJnM4voR8gFjjWB++0q4H/j5QWZzuJiTrhWkAZIGsiunoTz4Eet8M5TUcJcem4fi2fSE7dTIh+Lys9ZQ4LsqH5GpCpQ3aXfjyCYGp1G/VBTcNHfJPlBenvB7haeQahEDL9kaiAcBCrreKlf7Tki4qzrbV8/ZHEpodA22hKIpiRZVnclMnGFzS478GfUWZPRAvt7kme43J0ftimBiHVRNq6OA0mDeYJhsGLsQNeRQXGFFrjgdsrU7RChg8xrZHA9OOsiV42RzPFaoF8KdZLuxHNhDUo9sDDRTBTJUsTbZtG0P/lKDMMHEoNDZoKRCCVIyY9SOlyYSrnRGl4YWLvXmRInAkcWOsRuNJIq5leOuSLbzrd7xUxmJT0UZCWVF3O0UsgUWnDGcQTZiSkj6xA+7PursBWTDw614WEZSnQpWdUFdZSSzZwN3AtkWGckA4nh+e8j2kHGOPcvAcbJB2aEnfCqvabS7bd9qs6BBNstLBdBvha4uToIqbLC6r8guPVxEv0VEbUk7CknLqvwjob/e2cSm4lV1GRwLXUeXUfaQoqqgnQbZam0EVDdBrprjmCCeTnxAQtNf4s3Fwb2Jr6MHbSaQx5Ai5oWQH7qNPSB5dNZzwBv42FlP1CHbwXr6cbL543rADpGN30XFEzbnazxYgjp6dnbpC7CXbDaU9fTsbCiPUSfZnmXz/yiXqHnPlpKNIMDX/O3vz/QvmfxxSxGWQ5G7M9fuk43OxjznL5eo2CCba3GEdjOzrAnpaL4xIpmO4gs0BjbrCbYJhNAIftpS35NJT04zcm+Monn/pe08/50iQY1snleoWM5Gia49ZCuxxsCGOQRd4ug/rxU8iQ=='
_TARGET_BITS_PAYLOAD = 'eNq9WUty5CAMPWofIftZtI6UA0xVdIxeZMEBZsEqRVWrgIk/iQ1IYBrZqlS622DLkt5DD/tPxBj/xtlo/o/sD+OmHzgdXkZi/IqZmfXD5gMxRMHc9hVwP/DzA+LmcDEvXctKAyANZFdOQ7nzI8G7Ziip4S49IQ/Fsemx26mGD8XnZ62h0HdV3g1TFSpvMuzGkU0MTqNuqSj5ae6SfYK8PPb3Cjch1SIGXrI1EEcCFHS9Va72nRD7UHW2r54POZQw6hptCcVYEs2oOpOZOMPmmRz5N+rNyuihfL3JM91vXo7aF8GYOqiaVkcBpMF80TDZ0HQhasihuMKKXPE6ZGt3CFvA5jWyeR6ccJArx8nmeaxAL4Q7yfZkObCHpB7ZGGimCmSoYm2yadse/KUGYYIxVqGzUUmFEqQQx6htLk0kXekMLg3NXurNixKBI0sYYzdGSRRzK8dDkWznW73jpzISb4oyksqK+OcpZLMsOI09g2zAlBD0iW93fdSHC8iGh1vxsIyEOhWC6oK6ykhmz0b+BLItMpIBxPH89pDtLuMce5aB42SjskNP+FRe02B3267VZkmDbIGXCqTfCn1dnFhV2GB1X5FderiIbosI2pJ2FJKBVflHQn+9s4lNxanqMjoWuo4ug+whRVVBew2y1doIqW6CfDXHJkE8nPiABKa/xJs3g3sTV0cPhkwgjyFFzAsgP/Qce0By76zngDdyprOeqEO2g/V042Rzx/VAGCIbv4syJ2zO13iwBLVx7OzSF2Ev2YIt6+nY2VQeg06y3crm/14uUfOeLSUbkKW3+dvHz/Q3mfxmSxGWQ4a7M9/uk43OxjznL5co0yCbb3EEdjOzrAnpaL4xApmO4gs0BjbrCaEJBNsIftpSP5JJN04zcm+MTPz8pe08/xMMUI1sjleoWM5Gia49ZCuxxsCGOURd4ug/nVw0rQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod11_a6_b6_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
