from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin11_structured_affine_mod11_a7_b5_c0","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin11_structured_affine_mod11_a7_b5_c0","model_table":[[0,5,10,4,9,3,8,2,7,1,6],[7,1,6,0,5,10,4,9,3,8,2],[3,8,2,7,1,6,0,5,10,4,9],[10,4,9,3,8,2,7,1,6,0,5],[6,0,5,10,4,9,3,8,2,7,1],[2,7,1,6,0,5,10,4,9,3,8],[9,3,8,2,7,1,6,0,5,10,4],[5,10,4,9,3,8,2,7,1,6,0],[1,6,0,5,10,4,9,3,8,2,7],[8,2,7,1,6,0,5,10,4,9,3],[4,9,3,8,2,7,1,6,0,5,10]],"priority":358,"rule_id":"false.finmodel.setcheck.structured.affine_mod11_a7_b5_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod11_a7_b5_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq1WUuS4yAMBZUWLDkCR9FyjqXNVPVyjjyJY8cfSWAsNZVK2gYLI733JOi/idLr8/pKCd9fnz/FRVsuiJcL3AccW1sHF9GTj/3Htg2Fa8c6cariEdhtnieqF5vfxsrTx0UqrWVj9nUpSV1KUzuIk7F8sGzWdWYylyIcti4F4eqAtveTHhXQnCZi9DbQSLzod9QKIlIssGEZ0+O2vlQG2VVTeDPxy6RDIncN9VuzcLwEqik+JBNZBiSVGGTJQBTO1ANJt/3IhydAsREbOlMQVNh4G0hVO4QgeELqxpOCl/anS9efIjDebjhpQDarq6JwrkNG3s931KkFO3JLjdAHbIyWsY2V+igwA7JVww5uQeWe8JenZFMWfa5AagsimwEUhFBHlv2H5aLrvcw6mdlUUMiywCvPzfZPUe+4IocTEtO8kslTWK7OyNWpmsILSUDLoSRA4c7gA7IBPK8+BrDLsw88IVsH0bWkyDbgDuTQ2VbJBZ2HFKtajNxZNP+cweqF5L8nCuMoI+EXqSy4Q4+KTFcZqYETjM1pQGaTuxjy8ljHHabRYUYUbNAGdQ5fGjO/ZitmGsKQOmQv1qrFWbx7rDCf2Qy5rKF0oM+WmoyJgql9KCMVR1GKZVv+WMgGD0+7+xJBtqSeMwZNoMCOb9aSzijyIHm30IOFOhAkDM0IYEuU2Gq7Q0i2I/n9yaG5ppiZbTmOoYm6zHNAspxGFry+mUsn7ZNwibxP5eURaZyoRdxbDTbpU5QJihP+2zGE9d8RmK3g75LtatQoT9BDNrLUoXxfhroigtNkU85wl4xA42RQJvTFPPqnpt7iK8ZmYNrsl24imtnLAfPof7mDCmyKLQI4JBtbsqGXkT6ymUZKVUXJlXBg31KjFGRldEER3cud3AZKqAk7Sf+SEhua2OptZKtikIKH5RbrvC4nLxu4/Q8wajeW'
_TARGET_BITS_PAYLOAD = 'eNq1WUuS4yAMPfIsu2o2OtYsdRSOwJKFSjCJY8cfSWAsNZVK2gYLI733JOi/Ddvr8/pqjd5fnz/FRVouEJYL2gccW1oHF9FTj/3Htg3la8c6ccviEd5tnifKF5vfBsrTx0UqLVVj9nUpTV1KUjsQmrF8tmzmdWY0lyIcti6F+OqAtPejHhXWnCZi9DaQULzod9QKIlQsgGGZ2uO2vlRl2ZVbeDPxC6hDonYN9VuycLwEKik+RBNZBiSVGFTJQBLO1AOJt/0IhydYsREbOlMQVNh4G0tVO4QgeELsxhODl/avS9efIjCebjhpQDarK5NwrkNG3s931CkFO3JLjdwHbIyWgY2V/CgwA7Jlww5tQYWe8JenZFMWfa5AcgoimwEU4lBHlv0H5KLzvcw6mdlUUMiywCvPyfZPUe+4IkcTEpO8kglTWM7OyOWpmsILSSbLoShA4c7gA7IxP68+BrCrsw88IVsH0bm0yDbgDtfQ2VbJZZ2HGKtaQNBZNPycweqF5J8nCuMoI/kXqSy4g4+KTFcZqYGTjc1pQGaTuxj08ljHHbXRYUYUbMgGdQ1fGgC8ZitmGqKQOmQv1rLFWbp7rDCf2Qy5zKF0wM+WGo2Jgql9KCMVR2GLZVv9WKgGD0+7+xJBtqaeMwZNoMAObtaSzijCIHmn0IOFPBAkCs0IbEuU2Gq7Q4i2I+H9qaG5ppiZbTmOwYm6zHNAspxGFrq+mUsn7ZNwibxP5eURaZqoRdxbDTDpU5QJihP+2zGE9d8Rnq3g75LtatQoT8hDNrTUoXxfBrsiQtNkU85wl4yA42RQJvTFPPrHpN6CK8ZmYJrsl04imtXLAfPof7lDCmyKLQI0JBtYsqGXkT6ymUZKVkXJlXB431KTFGRldCER3cudmgZKqAk7Sv+iEhuc2OptZMtikIKH5RbovC4nLxu4/Q8cFjmg'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod11_a7_b5_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
