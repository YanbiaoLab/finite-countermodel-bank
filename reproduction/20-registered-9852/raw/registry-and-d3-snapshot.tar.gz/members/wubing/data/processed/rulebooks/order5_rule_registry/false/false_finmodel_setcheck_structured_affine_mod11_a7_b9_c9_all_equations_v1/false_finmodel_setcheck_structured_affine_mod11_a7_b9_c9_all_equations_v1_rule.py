from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin11_structured_affine_mod11_a7_b9_c9","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin11_structured_affine_mod11_a7_b9_c9","model_table":[[9,7,5,3,1,10,8,6,4,2,0],[5,3,1,10,8,6,4,2,0,9,7],[1,10,8,6,4,2,0,9,7,5,3],[8,6,4,2,0,9,7,5,3,1,10],[4,2,0,9,7,5,3,1,10,8,6],[0,9,7,5,3,1,10,8,6,4,2],[7,5,3,1,10,8,6,4,2,0,9],[3,1,10,8,6,4,2,0,9,7,5],[10,8,6,4,2,0,9,7,5,3,1],[6,4,2,0,9,7,5,3,1,10,8],[2,0,9,7,5,3,1,10,8,6,4]],"priority":350,"rule_id":"false.finmodel.setcheck.structured.affine_mod11_a7_b9_c9.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod11_a7_b9_c9.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2GEKwyAMhuFE/OHPHCFH8Wgefcx1oK2rg8Ho5vtQCK2tlFLihyrfoFuN9biO58uYSPZ2wKXUWmRJev8iImlyW+5O7Hht8nQUAOibT7Jh5zVvGozWRSWXUVOnrwCri6mmmPjId/s4GrcO0gQ9n8XEaSACAFwlRspbMfJj3pTQjYQXC4uez3SYB78uN0W7X9NkvG8SzmdadnsKAAAAf+IG+1MItw=='
_TARGET_BITS_PAYLOAD = 'eNrt2GEKwyAMhuGjezSPkiP40x/BZMx1oK2rg8Ho5vtQCK2tlFLih+bfYFvVelzH82WSe5R2QDzUGnxJdv8i7nlyW+xO0vHa5Gl1AOibT07DzpukaTBWF5UYRk2dvgKsTnNNMfrId/s4qlsHaYKezGLiNBABAK4SI/2tGPkxaUrpRsqLhcXOZzrMg18Xm2Ldr5l8vG9SzmdadnsKAAAAf+IGUR5ofw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod11_a7_b9_c9_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
