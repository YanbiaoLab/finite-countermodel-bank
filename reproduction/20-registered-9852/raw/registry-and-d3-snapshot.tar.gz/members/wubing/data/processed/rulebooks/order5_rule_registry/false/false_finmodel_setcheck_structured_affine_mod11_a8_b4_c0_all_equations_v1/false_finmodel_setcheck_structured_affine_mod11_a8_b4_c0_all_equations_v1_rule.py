from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin11_structured_affine_mod11_a8_b4_c0","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin11_structured_affine_mod11_a8_b4_c0","model_table":[[0,4,8,1,5,9,2,6,10,3,7],[8,1,5,9,2,6,10,3,7,0,4],[5,9,2,6,10,3,7,0,4,8,1],[2,6,10,3,7,0,4,8,1,5,9],[10,3,7,0,4,8,1,5,9,2,6],[7,0,4,8,1,5,9,2,6,10,3],[4,8,1,5,9,2,6,10,3,7,0],[1,5,9,2,6,10,3,7,0,4,8],[9,2,6,10,3,7,0,4,8,1,5],[6,10,3,7,0,4,8,1,5,9,2],[3,7,0,4,8,1,5,9,2,6,10]],"priority":359,"rule_id":"false.finmodel.setcheck.structured.affine_mod11_a8_b4_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod11_a8_b4_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNqtWVuO6yAMBYsP94+5K0DVLISR5mOWhSpdqcueNpMECHYwMVbVR0pxfDjHNvS/ieb9eJszBvcPn8vz/k1YPsR12MuSaSzs47dBm9n1FZZHYT/5rf8ov4jFe6x+A4YxX9xTdXdp978EWBgfSjwO2uyW396BCaW2GHd4Du7hAE8RSkbB1qGsF4AOxbgGnmCJKAq3wXQMs4OzsZECuPBArJszlw0zSC1CmT7ILfCYsfz1zGhL0bP7w2rBljC+idnrue+gC61YgxSYpdvtS4lj6pBMJnSpsQmBcBDzoIusBMeh1iS0V7SgC48XW+1ovxQEw/jF8a0UuJnC66ZQtWy3U3LXc387JUeCHRn9up+6TI2Kze3MS7Kkg3qxxb7ytytWIzZ2an+knzofvwF0QxN5vdi4xN6mzKAJ7Wc0sas0YPnEDmS0CPxMtg/NsmxexEht/ncrP0RiW7xNEhsQ7PFmpm2VDdlOpVPIh+xhMEqrYjSgYr+J6ZxGFbj2vSWxiqJdVDZZilIFZ9f2HMjs5LHu+K0ukYXz9A9WQpsrYhMw0p1tNGRi89T2iMQhasUWkqg6/H3wxqvayH8Dae+JVldKI/STYl3Z7gpvZRuZjCDXq1buxk5NT5ueyjYSZBSZsGf75DOMNcrumxKbQ9kGcobYfBI5+oMVjdPt2WCgaYz6NvLBZETf8jQogcTTdjQK24axNjLIBKDthQJ7zuir0GGKN5cBxbOzoUUrWvqnIp4PS25AZ+XHAzSPnuJAiyWcYhxaWFEnNmA8J7q700igqGyJgDBKup8JYqPop91r8yfh0E6vjaysbE+UUN0JiCAR28VOdKiy5blrQtoweXtoTv5aCC0q6mhj+eJ6SJJd+wBz1qN/W9LPs96QUArOEFsMkktpaGnL00iATj8wY8/GqMQ2IGnbkZwomn+uWIRQxAWusgWGa95MRxKoLTXbDwBRCoNcAOueTXj0Tx0OjrQNyCJE9AOPC/m5sl/VPzyJ'
_TARGET_BITS_PAYLOAD = 'eNqtWVuO6yAMXXalK1Usaz5GGhYyqljBDH/1BzLcNpMECHYwMVbVR0pxfDjHNvRfsun9eFtICfYP38vz/o1bPth12MtMaszt47dBm8X1FZdHYR/5rf8tv7DFe6h+g4kxX9xTdXdm978EWBgfij0O2uyZ3z6QCaU2a3d4Du7xAE8RSkYh1qGsF5AOJYUGHheJKAq3LnUMsoOzsZYCuPBArFtIlw0ySC1CmT7ALfCYsfz1zOhI0bP7w2rBljA+idnruR+oC61YA+OYpdvtS4mj6ZBMJnSpsQmBcGDzoIusxMCh1iS0V7SoC48XW+1ov+QEw/jF8a0UuJnc66ZAtWzPU3LXc38GJUdcHBn9up+6TI2KLezMM7KkA3qx2b7ytytRIzZ2an+knzofvwEMQxN5vdi4xN6mTKcJ7WM0sas0EPnEjmS0gPxMsQ/NsmxexEht/g8rP0RiW7xNEhsS7PFppm2VDdhOpVPIh+yewEqrok2oYn+y5pxGFbjxvSWJiqJdVDZZilIFF9f2HMns5KHu+KMukbnz9I9RQpsrYhMwMpxtNGRi89T2iMTBasXmjKg6/H3wyavayJ+BtHeDqCulFvtJsa5sD4W3so00SZDrVSv3ZKempzU3ZRuJMopM2LN98xkmJmX3TYktgGwDOUNs3ogc/cEKKej2bDjQNFp9G3lnMqJveeqUQMJpO2qFbcNYG+lkAtD2Qo49Z/RV6DjFW8iAwtnZ0KIVLf1NEc9vJDegs/LjAZp7T3GoxRJPMXYtrKATGzKeDd3daSRQVDZDQGgl3c8EsVH00+61+ZNwbKfXRlZWthtIqB4ERJCI7WInOlTZ8tw1IaObvD1MJ38tuBYVdbS2fAk9JMmufYA569F/LOnnWW9AKAVmiM06ySUztLTlaSRipx+YsWdjVBIbkLTtSE4UzT9XLEIg4gJX2RzDNZ+mI4nUlprtB5AohU4ugHXPJjz6pw4HR9oGYBEi+oH7hfxc2X93MjSt'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod11_a8_b4_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
