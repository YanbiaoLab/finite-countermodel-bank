from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin11_structured_affine_mod11_a8_b5_c9","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin11_structured_affine_mod11_a8_b5_c9","model_table":[[9,3,8,2,7,1,6,0,5,10,4],[6,0,5,10,4,9,3,8,2,7,1],[3,8,2,7,1,6,0,5,10,4,9],[0,5,10,4,9,3,8,2,7,1,6],[8,2,7,1,6,0,5,10,4,9,3],[5,10,4,9,3,8,2,7,1,6,0],[2,7,1,6,0,5,10,4,9,3,8],[10,4,9,3,8,2,7,1,6,0,5],[7,1,6,0,5,10,4,9,3,8,2],[4,9,3,8,2,7,1,6,0,5,10],[1,6,0,5,10,4,9,3,8,2,7]],"priority":353,"rule_id":"false.finmodel.setcheck.structured.affine_mod11_a8_b5_c9.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod11_a8_b5_c9.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2b0NgCAQgFEhFJSO4Cg3GqMrooFEQAqMUb5ngQaqi95PVFM/y3Zpv+DjVFjs7UEXb2VuPOiFs4ZIA8ADjpQr1x2b5OCzdmdyvSaGA1R6FSt4urE/zKapCwB6kWKKyr2INjNu0FXiu3Qs3lKboMLnoWrjGwAA+NPMZpt7XFmIF4CXuXIiyv84csRsOCt6oAbu'
_TARGET_BITS_PAYLOAD = 'eNrt2b0NgCAQgNHRGe1GYQRLCgIqooFERAqMQb9ngQaqi95P9HM/er1cWDA4Hxdze1ClW5kaDwbxrCXSAPCAPeXKecdkOfio3YVc74jhDyq9TxU839geJtvUBQC9yGWKKr2IpjBu0FViXC4Vb6lNUPHz8LXxDQAAfGlmM809rmjiBeBl6joRlX8cKWL2OwvR0WpI'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod11_a8_b5_c9_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
