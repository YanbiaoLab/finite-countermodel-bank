from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin11_structured_affine_mod11_a9_b7_c9","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin11_structured_affine_mod11_a9_b7_c9","model_table":[[9,5,1,8,4,0,7,3,10,6,2],[7,3,10,6,2,9,5,1,8,4,0],[5,1,8,4,0,7,3,10,6,2,9],[3,10,6,2,9,5,1,8,4,0,7],[1,8,4,0,7,3,10,6,2,9,5],[10,6,2,9,5,1,8,4,0,7,3],[8,4,0,7,3,10,6,2,9,5,1],[6,2,9,5,1,8,4,0,7,3,10],[4,0,7,3,10,6,2,9,5,1,8],[2,9,5,1,8,4,0,7,3,10,6],[0,7,3,10,6,2,9,5,1,8,4]],"priority":351,"rule_id":"false.finmodel.setcheck.structured.affine_mod11_a9_b7_c9.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod11_a9_b7_c9.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt10EOgyAQheEZwmKWcwSOwtE4em1tLY2jjaYxmv7fRgUSMJLxoXJOVUSnh9z3pOzTfTnRiq27NLk22zSsSjp+heOU4x5JXxav1na/Iy7L81KV0Png5FGrxI2R1G1D7zuiIlXeO3B9gsZnBICtsi4W0OHHUP2zzOYhxXibDSMrADjMM0bea9ejRJWVGNmCGGnESODvWRhkXqdT23nIBQAAAH7oBmnfB1E='
_TARGET_BITS_PAYLOAD = 'eNrt10EOgyAQheGjz9E4CkeY5SwITG1tLY2jjaYxmv7fRgUSMJLx0fycknubHkrfU4tO9/lEK7buIn5ttmlY8nr8Cscpxz1Svyy+mex+R1yWlqUq0eaDq0atHjdGarcNte+IilR+78D1CYTPCABblbZYQIcfQ9LPMluGFKMyG0ZWAHCYZ4y8165HicorMVKCGGnESODvWRhkXqdT23nIBQAAAH7oBuKSaeU='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod11_a9_b7_c9_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
