from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[1,2,3,0],[1,2,3,0],[1,2,3,0],[1,2,3,0]],"priority":324,"rule_id":"false.finmodel.setcheck.structured.affine_mod4_a0_b1_c1.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod4_a0_b1_c1.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmc1uhCAQx12zB45g+gBKaNLHAMJBe+ojbYwHvG3NPkAftYwYiFncsknXbJv5HTbiCOx8MIl/D0VRSFpkITtddcZcxNRyPl+2fLSEMc6NIc1QIE/Il/g0FWPu1wxispayhmszUE1eRxjXo+B8tvpUOstZtIMV1nDS9rout1Y+CcWNUKJSsnop2a5evXXBoTO4ByXofNNEXddlwsMYhDjRmzVpYMpAe3cPBn1NSh+peaO59sOj80adYH4562bSRKATeyxm0hzdFPhDzugGih7VP67F02RCen6MWugyMVYxpWHiYo758smrXd7w7CPITnxM8VRDv43nMq9HJw507Na+OS6dEpokxhtBEARBEARBEARBfpNFPk6IcYlbibf/m5LrSv6EF/vNbwvyAbJuv6lGPkLW3RRIyjzNJLFHDMVK/gTf3quw6jpEKbn/Wte+KbmuFBnw7bBrRXrpP1FreWUj7wvk5keSvLJ55kAifxHZcSjGRK3l9ej7uta+h+0bVtVfog=='
_TARGET_BITS_PAYLOAD = 'eNrtmc1uhCAQxx+1D9DYvcnBmH2knqoHAjxGkxL0ARrhyGHjuowYiFncsknXbJv5HTbiCOx8MIl/z9M0CTNlIRo2NJS+yqJVar5sVUms1kpRartqQp6QF/lGB63dL61kQYjRnWK0Msx+lTDuS6nUbPWpdJaDbCsiCVW2rVk/bq18lFxRyeXAxfA96l29+myCQwdwD0rQ+cYsv67LhIcxCHGiNzPbwZTK1O4eDOrejj5S80Zz7YdH540aqf1yxM00iUAn9ljMtju5KfCHnNENuDnxf1yLx4KG9PwYtdBlYqxiSsPExRzz5ZPXu7zh2UeQnXgv4qmGfhvPZV6PThzo2K19c1w6JTRJjDeCIAiCIAiCIAiC/CaLfJwQ4xK3Em//NyXXlfwJL/ab3xbEA2TdelONfISsuymQjHmaSWKPGIqV/Am+fQxh1XWIUnL/ta59U3JdKTLg23nXivTSf6LW8spG3BfIzY8keWXzzIFE/iKiUVCMiVrL69H3da19D9sF9ZwRlA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod4_a0_b1_c1_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
