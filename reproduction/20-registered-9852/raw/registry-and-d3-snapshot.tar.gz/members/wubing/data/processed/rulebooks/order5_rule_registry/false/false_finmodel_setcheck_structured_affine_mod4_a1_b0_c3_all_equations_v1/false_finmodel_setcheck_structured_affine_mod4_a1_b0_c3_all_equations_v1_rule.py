from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,3,3,3],[0,0,0,0],[1,1,1,1],[2,2,2,2]],"priority":325,"rule_id":"false.finmodel.setcheck.structured.affine_mod4_a1_b0_c3.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod4_a1_b0_c3.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmEEOgkAMRX9lwZIjjAcxmWu5MDJH4ygcYZYszIyCMTGpVQygYv7bsOgESmn/bxAA2w1ecEAqQeYm5R6nAzEP5dbRkH1/6frIcnntkQQ4AjtEsY81RawuuRZoJVT8moQQQgghhHyRNluwNoSsmJM12Y61eYtkFXKJ3xmNKciy+kKaVev02xYzOZtYadxTzzRsfpTBTm6bcL1POWrmJ7dNtPaBoB/mqRaEkIfO5m4SVWuD9VqjnaE2o/SzGxwk6PONls5WG078I9slP7JGPus10QuRYe317w3bZzkDjW9kLg=='
_TARGET_BITS_PAYLOAD = 'eNrtmEEOgkAMRWfiguUcgaNwtMG48FqTeBDnCCxZYL+CMTGpVQygYv7bsOgESmn/bxAAxxNesINvQebGu56sA8EN5dbR6FJ/KfrIcnnt4QXYAgcEsY9VXWguuXYoJTb8moQQQgghhHyR0lmwNoSsmI012Zm1eQtvFXKJ3xmVKciy+kKaVSv023YzOZtYadxTzzRsaZTBTm6beL1PO2rmJ7dNsPaBqB+WqBaEkIfOlm8SVWuDTVqjs6E2o/SzGBwk6vOVls5SG074I9slP7JGPus10QuRYe317w3bZzkDvwINCA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod4_a1_b0_c3_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
