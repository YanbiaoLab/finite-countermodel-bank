from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,1,3,1],[0,2,0,2],[1,3,1,3],[2,0,2,0]],"priority":340,"rule_id":"false.finmodel.setcheck.structured.affine_mod4_a1_b2_c3.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod4_a1_b2_c3.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmc9OwkAQxr/+wRYO0hKOBO1mH8ID0YbsoT3qk3j0YMJqOCw30vgAPAqPUt+AowfSugU0pjYYlBqU+R22k+42szs7bebrGigznxvFpRvjMLkElu26ncx4MOGM1ewlMVvC5rs8ITcrT0d1zsuFqdsTwIa3bZxxvpmVNkEQBEEcJYvceTPTXGPV6i3L382ldjai+H+TD6HLdCCv/tHS7pGtUrJIxXW9lNWclcTPmV+k0upDNwP0bqWDNvoYYEEF5kHzxJOIsUeeKDUVHd9nTAilvKFbx77JRHRiIVaOCrdDMVau7w/dgDZiJ8KYFTI3YhPlxtz3g3Uog7FHsSEIgljmxtbevaoPubUCl4WwatOWHDmW0zutrp2fdeOkWBS2dUeR+uJl08VP9SlHlNiQnAfMhFRKufvwNmU3odGs6ml0p/CuRTCWNproQP05zbb+9VN1LPNy9vmTWTEsz0nf/Tq8sdIAouXZJVnwoGTp1iwUoVlKaGh5FyEMKZLEfngFZK9jmw=='
_TARGET_BITS_PAYLOAD = 'eNrtmc9OwkAQxttw8Mgb2EfhUXgA03BjD0SXxINHn0SP7WFDquHgQ2y2SjgSWjxAK/3zuQU0pjYYlBqU+R22k+42szs7bebr5ijTauXFZeLgMLkHGrO6nbSl35VK1ezFzuYikbs8wTcrt/p1zitCptsXIEG4bVz+uJmVNkEQBEEcJU0jfjMtQ5PW6s003s2Gdtan+H+TD6EzdSDv/tHSLmGuUrJIxXW9ZNaclcTPaT1YPB1BN0OMr3mMGUYYokkF5kFzJm1XqXNpM9YR0yBQSgjGwkFUx75xW0wdIVaOCrcD0WNREAwinzZiJzxHFTLXVV0WOTII/HUo/V5IsSEIgmgY+dbevaoPvrUC54WwmtGWHDlpPH6urp1PdRNbaBZ2ekWR+uJl08VP9SmHayfgUvoqA2eMRfvw1lE3Xr6o6llOOghvhd/jCRaYgv05zbb+9VN1LHPy9PmTWTHMMEjf/TpyudIAYh4mJVlwwXjpVtsTXlZKaGh558LzKJLEfngF58INmw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod4_a1_b2_c3_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
