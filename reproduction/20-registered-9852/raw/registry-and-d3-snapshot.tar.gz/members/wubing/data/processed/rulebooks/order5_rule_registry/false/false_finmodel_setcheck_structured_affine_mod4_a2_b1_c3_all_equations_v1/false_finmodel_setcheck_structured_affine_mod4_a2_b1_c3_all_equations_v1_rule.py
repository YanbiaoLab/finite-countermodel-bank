from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,0,1,2],[1,2,3,0],[3,0,1,2],[1,2,3,0]],"priority":339,"rule_id":"false.finmodel.setcheck.structured.affine_mod4_a2_b1_c3.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod4_a2_b1_c3.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWNFOBCEMLIQHHvkEPoVPw8QPt52WwuVw9eFi4h6NnkpBdqcwnTbQtE8qjWJrlRJF+tZSKpl/xECUKXQZio1ebC3Xzg/BH4lS4U0C/5WovHaXlPjJa+P3SHiVQJUH8XUbq4mjGkg+GdHMEFaSXy9xkW+dEi+nVQl8waxAx44du6HlMNmjGRNncHHMjckkDFYREgipKm3roLCIc7cxTyRzNziFbtjZfmCbG9gnAyYYBH796klNsukzagx3QUKeWNmKTAvc6q5wCnxZUIanl2Wj5LTPnk1WxUYSzcs9zD3jpcGr54q8+rIhPDgCfmd+d2xG2OIIW/Ow6dGY56Tf/bJBzgpqoCiDDYCZsjQsi9Ia7oBj5Zy2XASLRVqvmmJ+Z4sxVCqoClgUtj4UHx/OSEEVNGUlf5XRmK74GsxCMetCIE0NhB8UxPaT3Pz3Fj4YgPxL1IA0pk+sdEVeF2rNUlcQQceh1mUjFDg+1aM5I+PPdb2HlUfVzny2WuEkgGPHjh079hcdLa+NoO4WpcLVFaoYU28i5CTf9Qdd4apvWegV7XOTCz1CtDub5j37X7u24Yc8nmbG0Q+zSsklI3nlNBJnf4+wxZhRK7LwAER9yL3NELQI2syO1ZQhHoEhv1fheNqQt2yQbIZwq7UxZYNLb9svtLufyt+LBslmaNM/3+4xisaHttY5lMfe3HpHCt0QuzA/ClBLBfuhZrmTZhdhOjVR0+07MX9v1o0EF3ZnvErb1v9m6LJ3/UCQEt4vuTle+Q=='
_TARGET_BITS_PAYLOAD = 'eNrtWNFOBCEM/HAT+TQ+hU/gkQcCtZ2WwuVw9eFi4h6NnkpBdqcwnbbTtA/KkVqMiSo1+tZqzYV/tE5UqAcZapFebLGkwA/BH5Vq5k06/1Upv3aXWvnJU+T3qHiVTokH8XUbS5Wj2kk+GdHCECaSXy9xkW+d0i6nJQl8xqxOx44du6GVPtkjGhMXcHErkcmkD1YREug1KW3roLCIc7cxTyNzRziFbtgZf2CbG9gHAyYYdH795ElNsukzagx3RkKeWNmKQgvc6k5wCnxFUIYn5GWj6rTPnk1WxUYSzcs9zD3jpcFL54q8+rIhPDgCfmd+d2xG2NoIW/Sw6dGY5yTc/bJBzgpqoCiDDYCZsjQss9Ia7oBj5Zy2XASLRV2vmmJ+Z2utJ8qoClgUxjAUHx/ORl0VNBUlf5XRmK74GsxCMetCIE0RhN8VxPiT3Pz31j8ZgPJL1IA0pk+sdEVZF2rNklYQQcc9pWUjFDg+1aM5I+PPdb2HlUfJznyxWuEkgGPHjh079hcdLa+NoO4WpcLVFaoYU28i5CTfhQdd4apvWegV7XOTCz1CtDuj5j37X7u24ac8nmbG0Q+zSsklI3nlNBJneI+wtVZQK7LwAERhyL3NELQI2syO1ZQhHoEhv1fheNqQt2yQbIZwq7UxZYNLb9svtLufyt+LBslmaNM/3+4xisaHttY5lMfe3EJACt0QuzA/ClBLBfuhaLmTZhdhOjVR0+07MX9v1o0EFwZnvETb1v9m6LJ3/UCQEt4vkzgSPQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod4_a2_b1_c3_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
