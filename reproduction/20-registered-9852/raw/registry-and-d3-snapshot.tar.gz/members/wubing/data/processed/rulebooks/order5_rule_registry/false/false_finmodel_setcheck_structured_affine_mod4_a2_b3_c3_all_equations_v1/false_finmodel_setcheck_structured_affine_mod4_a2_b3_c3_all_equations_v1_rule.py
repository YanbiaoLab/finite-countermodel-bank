from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,1,0],[1,0,3,2],[3,2,1,0],[1,0,3,2]],"priority":338,"rule_id":"false.finmodel.setcheck.structured.affine_mod4_a2_b3_c3.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod4_a2_b3_c3.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWVFuwzAIxcgf/uQI7CY+GpN28AEmjpd6ldpNUyfx1KaJg4Fg5xnTd4FHUSs1/cEC0KB4f+zwHFqppH0rCQggAUPXE8BndJF6UdSjSqAHVq3qH6k6ka5n1Z0tDOS31IrAq4Ko8wgre5zVfeAndbFFuIAdNcQWkQjyvSG27xDBu2JsA08uVSCRSCR+iLdBU0Za2IKrijGM07u22IVxuzIii57Z6hGNBMsSMvi/w6FgkKgMUmumb7LjMFRGD/Y7bsjWkXCgbpepjY1QUJxGaZjxtTKReM2XzSe1vgh4zufGNqPrnOtl+7JFjw6HUIN4hW7mP2Wwfy8//DbVnaM5R8ZpzcVj2HgZ0pPbYlRpJpvBk/2PH61r5lsBNfvsot40fxKfX5YNRyKvrhr5RzZv4uauipIc6SguHX0+68cJfySsTseqrS2GEMoiOncM4PGFuvh134b75wH3RBrH/M8FIJFIJBKJRCKRuOBjqcTw3Gh6reamSS8wytrRuNS2j53sUj66ln9AaNH6Zae7adrUz7c2jvLRdfubSCQS/wzxB61zoUzGsyIKtj7KSme9e9P0WH38E7uARkE='
_TARGET_BITS_PAYLOAD = 'eNrtWVFuwzAIPfikcTTfZByBT39YmAEmjpd6ldpNUyfx1KaJg4Fg5xnTd5BH0RpV/eEuUqV7fy7yHGpvpH0bgYAwCUrRE+FndJF60dWjRqIHVK3qH6k6gKJnzZ3tKOS31ArIq4Ko4AgrepzVfcEndaFFuIsdNcQWkQjyvSG27xDhu2JoA08u1SWRSCR+iI9BU0ZaXIOrujGM07u22IVxuzIigp7Z6hGNJMsSMvi/yKFgkCgMUqumb7LjMNRHD/Q7bsjWkXCgbZepjY1Q0J1GaZjxtTKReM2XzSe1vgh8zueKNqPbnOt9+7JFjyKHUJV4hW7mP2Wwfy8//DbVnaM5R8ZpzcVj2HAZ0pPbYlRpJpvBk+WPH61o5tuENfssoN5UfxKfX5YNRyKvrhr5RzZv4uauihIc6SgvHX0+68cJfySsTseqrS6GWPoiOncM4vGVtvh134b75wH3RJrH/M8FIJFIJBKJRCKRuOBtqcTg3Gh6reamSS84ytrRuNS2j53sUj66ln8EaNH6Zae7adrUz7c2jvLRdfubSCQS/wzxB61zIUzGsyIK1zLKSme9e9P0WH38E5DxKvU='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod4_a2_b3_c3_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
