from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,1,3,1],[2,0,2,0],[1,3,1,3],[0,2,0,2]],"priority":337,"rule_id":"false.finmodel.setcheck.structured.affine_mod4_a3_b2_c3.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod4_a3_b2_c3.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2D2OgkAUB/A3Qha0EMfaZJeJeweLTXTNFGLlVey2c4otsPUEHoVqzzFHmNLChGXQuMlKSDBgDP5/BRAG5vEGMh8wmnWoHQwjvSkqUGvqTxKnnijv3WjMOaulrl2nJ91xlTtUcNoXJ1pRlGexn8n/n4BP9sQLkUuDsgrY2/mpskMCAABolyR9vYy/aSZoNNohvcxUjI3WopFVO2aap2jbM0/T/DUtPKof5o0MkTfSTCvng77IkGYqQMvAE1jtFmIb+9lWzIeRlHE84KGY+6HbRLTl0K4vP22gPCznQkjph994EQAA93UsnYEfsxn6pr5gKp2Wlja++gAAqCTxTn1hQdd0uF7fF13Wqt8cAHCLX57ORAA='
_TARGET_BITS_PAYLOAD = 'eNrt2D2OgkAUB3ASC8s5wpxjK47iCWyl2GLs7PYqVmIxcTWx8A5rBk2sHbHYhQ04bxk0bqKEBANmw/5/BRAG5vEGMh8Ymp+oHZghPiwqEG90XLlpPVE+vvy11qaWuvqnT5msq9whwvO+ONGK/DyL3lzefgIR2RPfRAkdyiowm8tTZYcEAADQLq6zvY6/TiZsNFrXuc5UmI3WopGVp2yRp2jbM0+T/TYt/FUvJt4xonjHDRfpkkbEiBsRomXgHxj3p2rgRdlWzfa+lJ530IGaRUHSRLTJ3q4v322gPKzWSkkZBa94EQAAz9UpnYF3shn6sL5gwlmUlja++gAAqMSNz31hQdfUvV/fF13Wqt8cAPCIH62jLTY='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod4_a3_b2_c3_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
