from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[4,0,1,2,3],[4,0,1,2,3],[4,0,1,2,3],[4,0,1,2,3],[4,0,1,2,3]],"priority":326,"rule_id":"false.finmodel.setcheck.structured.affine_mod5_a0_b1_c4.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod5_a0_b1_c4.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmcFugzAMhinqIccE7QEgyqQ9RkA5wE7bG02IQ7h1qA+wR50NKBFaWlFNq1bp/w6VbMd2bFwO5pBlmZXZLmzXFJ1zGXgkvsynK5SiXzeYyXupKt24QTbieWS5HI3Ws9ULpbQmy8m0gzfeadH2TZlfivxhau1MbYraFk/5e6dDpG2eqdV6npxVKapjZ5Sq+PiqHGQfskfH1dyImlzoDBtJkMda4rkCAAAAAAAAAAAAAADAL1nXx4kd7l+sdc8mRG31uPg6J6rB/lQlFtepHIuZbscudCHSsdCXop9ciDrfnH09HZMJVWKvncgRWxHrIoFre5ti1E2L8kTXONGJ+341R2xFrIsEru21CFG3LUqt+8MDvpojtCLWRQLXdrjrRL50fP3ErO0bG3tbIy9+JNk3Nv+5keARsct3tsSs7XtH3/bWuu+f7Rsl6glX'
_TARGET_BITS_PAYLOAD = 'eNrtmcFugzAMhh91DzCx3sgBob3RdhocIshjTFoUeICJ5JhDRakNKBFaWlFNq1bp/w6VbMd2bFwO5jRNk3LTLlTVDJWUE3gknvSLHKylX1noTAhnO9PIwjX+K2e5z7Uxs1V4a40hy0HXhdBCGl+XTT9eivyqWyN1q4dWDd/jW2VCpG2erDZmnpxV6btjpa3t+PiqLFwZskfH1dz4llzoDBtJcMfW4bkCAAAAAAAAAAAAAADAL1nXx4kd7l+sdZ91iFqbfPGV0neF+qlKLK5TORYz3Y5d6EKkY6HsfZnJEHW+OfsKOuYSqsReO5EjtiLWRQLX9p7FqJsWjYmucaID9/1qjtiKWBcJXNvHEKJuW5Ra94cHfDVHaEWsiwSu7XTXifys+PqJWds3Nuq2Rl78SLJvbP5zI8EjopbvbIlZ2/eOvu2tdd8/2xkmlmff'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod5_a0_b1_c4_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
