from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[4,4,4,4,4],[0,0,0,0,0],[1,1,1,1,1],[2,2,2,2,2],[3,3,3,3,3]],"priority":327,"rule_id":"false.finmodel.setcheck.structured.affine_mod5_a1_b0_c4.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod5_a1_b0_c4.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2U0OgyAQBeA3ZeHSI7QHaeK1umgqR/MoHIGlCyNV2dSM9CdU0ibv27iAMCPiYFAAnA544YqxAhXjwzLdYXJcNdjQzJd+btkv/AWjADfgDC/pbp3x9ZSrgRNb86EREREREREREZW1HBFtafaIFoeu30rD5AZzcRxJpfGozb61ITVrTkfLPgWzcZwqlcaK5EbzcZxkGrsvGyL6e138SzHoejvqyrH1U+Oj+tkvO4jV/TtdOp3ecPz36idRXOXP1proD6LE1t7+3stW1h2syBHO'
_TARGET_BITS_PAYLOAD = 'eNrt2U0OgyAQBWCJC5ccgaN4NGy66LVMepD2CCxd2HlV2NSM9CdU0ybv27iAMCPiYFAAXG544QgzgHZjqzjd1eS6aPBVP1+auWW78CcYAQ7AGVby3drRhinXEU584EMjIiIiIiIiItpXPCJa028RLQ0d3kpjLA3m0jiSS+NRV3xrdW7WnI5WfArm0zhDLo0FKY1m0zjZNDZfNkT099r0l6LW9dboyrH2U+Oj+tnEHcTr/q0unU5vOPZ79ZMorfJna030B1Fma+9+72Xb1x2fqV9o'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod5_a1_b0_c4_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
