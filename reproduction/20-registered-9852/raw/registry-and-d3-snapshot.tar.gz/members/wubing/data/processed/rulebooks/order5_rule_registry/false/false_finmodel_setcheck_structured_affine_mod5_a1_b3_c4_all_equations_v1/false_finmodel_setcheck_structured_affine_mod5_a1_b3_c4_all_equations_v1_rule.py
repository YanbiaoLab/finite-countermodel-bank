from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[4,2,0,3,1],[0,3,1,4,2],[1,4,2,0,3],[2,0,3,1,4],[3,1,4,2,0]],"priority":333,"rule_id":"false.finmodel.setcheck.structured.affine_mod5_a1_b3_c4.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod5_a1_b3_c4.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWTtuwzAMJQUaUDOpRQ/AoUOPwQIdOvZIOkqPWpGSf3KMZGiMNuVDYCO2LAcU39Mjg9BDsuiJYoLzIEwZIgACJD0UBPhp6G8o73hN4DgeCBb3eGkct3NoeeBw/B6UHJaSlydY5vKLfQkAvbKUYZ/9DG9tIrribQESq3o2AplSgj6Y80Yhsw4I1HGuPRZuIqh/SXxiiUzdhXKLrdT1ROiERlSBaB0tGtdWAFyXHA7HzZHZPLFJVBTT/VTVhwFT3X1obZuw97sOh8Nxr/gANrumOijvzZVX7/Y4ud/J+tKZ+pM9iMfvbF9149LYn6TWT7ioZJ459gu0b7qzx/MgxK4kWtfFWVZrFAZvte2BokUvYKtJZQ4t6Qc13WWR/inuFrZwqZGQAVX/tJNQDzI5Q9a7DDybxTR2EnaI5mS7T2DQlORt3WDdEGwpgzxf6lIjzQn5r3c2QIpjCFek1f8+RrLlyiMW2LTlwnjhGl9S6GyiS5t5BuMyNXF4suPp7KwPCwl3OBx7ZKu9/Nq4H4yijeDa+occ5ruVTds9G51jh+MbXNweHw=='
_TARGET_BITS_PAYLOAD = 'eNrtWTtuwzAMPWqPoiN17FCgPEaHDjxA0WpyBYQQWZGSf3KMZGiMNuVDYCO2LAcU39Mjw9IDAuiJUpTzII5BkgiLRD0UZPlp6G8o73iN4jgeLBb3dGkctnNueeBw/B6UHIaSl4Msc/nNvmSRXlnKsMd+hpc2EV3xtiwRVT0bgUwpRR8MYaOQQQdk6jjXHss3EdS/JD6pRKbuQqHFFup6snRCA6pAtI4WjWsLIq5LDofj5ghontgkKoHpfqzqg8Kx7j60tk3c+12Hw+G4VzwJml1THYTn5sqrd/uc3O9kfelM/YkexON3toe6cWnsB6j1Ey8qmXdM/QLtm+7g8TwIqSuJ1nVxgNUa5ZO32vZAyaKXudWkMIeW9MOa7rBI/5h2C1u51EgIwqp/2kmoB5icIepdFJzNYhw7CTtEc7LdJzhrSuK2brBuCLeUYZwvdakR54T81zubMKUxhCvS6n8fI9lC5RGCbNpyebxwjS8pdDbRpc08J+MyNXH4sONwdtavhYQ7HI49stVefm3cn4yijeDa+peQ57uVTds9m51jh+Mb75VTFw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod5_a1_b3_c4_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
