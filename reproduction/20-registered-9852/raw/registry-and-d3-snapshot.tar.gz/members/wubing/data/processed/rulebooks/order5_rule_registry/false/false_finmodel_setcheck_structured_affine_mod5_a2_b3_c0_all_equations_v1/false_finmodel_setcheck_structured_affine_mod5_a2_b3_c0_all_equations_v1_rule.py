from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,3,1,4,2],[2,0,3,1,4],[4,2,0,3,1],[1,4,2,0,3],[3,1,4,2,0]],"priority":323,"rule_id":"false.finmodel.setcheck.structured.affine_mod5_a2_b3_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod5_a2_b3_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmUtOwzAQhsfWVDJZuYgDWFUXPYaFumDZI1mssuQIPSrj8eSBm5JAURVgvkrpy3LtZB7/nxoASFBA9LCAPXgetzV0MPyRhfvxCBDyoluAI944174sHxxA+3LXXTCv4CIg/y4GOZXf34pvneOX/tZ1hfJk5mYK3di7n7m/TDhwKAS5BmMo3qNxCYdrtAk5IWr0eijKsmQ7A0abO0CExucEk6I3Ufs42XJGJpwol1feKspXcE28Vtgp9E5ggymKhUNt42ysSn6SAEyoJ1P5CcVt7ZH06aVAZeOwe6Yw9F3B9GFH45yEqxkrl15qK4qyBiLZCUnVVIkYztOGB4kSaoplJR4+nXIlbYeqEPXEM78+DfcOpFc2ta8CHk7Lh1hN9LbMs3XST2Tkh7ntpYyM855tHS4u0YOCJEau7lLBHUyHDeYvrJXYmrhdoM5UudmzhdQ5tEQHN/JcbOMc55xUrZzVnsLOjEWIoigrBIvwQDP0P8fJXnTKWYbtS2eyU/0kaotRfmtnO/SWuZKRvvfbgy57olwxc546rGRrCVkXsoyUP+6SLM5v+3Yd+t3XylK14z/gHVXCIWQ='
_TARGET_BITS_PAYLOAD = 'eNrtmUtOwzAQho/aI7DsCvlIXbKokI/RRVX5AIh6FSx1ZA/j8eSBm5JAUBVgvkrpy3LtZB7/nyZENFgA8DiDI3oed050SPxRxPvxiujyoreIe1g417EsHwPi9umuu2AeMVgE/l1wciq/vxW/DYFf+qXrcuUpTc3k2rF3P3N/GXfgUHByDYZQvNsUDPTX6OJyQtTo9VCUecm2QbAxdwCLjc8JJkVvpPZxsuWMNDBSLm+8VZSvEBp7q7BT6O0wulQUC4faJURblXwjAWhAT6byE4o7xj3p02uBysbh9Exh6NuC6d2JxgUJ1zRULp3UVhRlDViyE5KqphIxnKcNDxIl1BTLSrx9OuVK2g5VIeqJG3696+8dSK9sal+FPJyWj7aa6GGeZ2uln8jID3PHaxlppz3bOlycoQcFibVc3aWCBxwPG8hfxCixNXK7QJ2pstizOdM6NEOHMPBcbOMC55xUrZzVnsIuDUWIoigrBIrwgNT3v8DJXnTKRoYdS2eKY/3EaotRfmtnO3SWuZKRvvPbvS57oVxJU57arWRrBlgXsoyUP+6MLM6fu3btut3XylK14z/gHfavT9I='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod5_a2_b3_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
