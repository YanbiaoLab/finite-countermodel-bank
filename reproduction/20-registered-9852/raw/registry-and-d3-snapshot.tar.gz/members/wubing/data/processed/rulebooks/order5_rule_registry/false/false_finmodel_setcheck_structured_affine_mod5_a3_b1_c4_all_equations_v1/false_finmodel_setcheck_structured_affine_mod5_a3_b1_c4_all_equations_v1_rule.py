from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[4,0,1,2,3],[2,3,4,0,1],[0,1,2,3,4],[3,4,0,1,2],[1,2,3,4,0]],"priority":334,"rule_id":"false.finmodel.setcheck.structured.affine_mod5_a3_b1_c4.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod5_a3_b1_c4.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWG0OwiAMLaQ/+MkRepR6M+LJhZUBZR8mJpqZ9WWJih1O2r6+1kEHOmDIFwPCzUGBlhNZPoRv/coTQjnrZ3mfZMld5ADi+kT+xKgeDC9GvC7kvxB0AJWdUG0UA1iYXQLoYip+Kxdrb2f3IKmIfEB1dIvXeTf1YvgWKklThJpsmMZk84pGHNRkizWzJ64zdxkMBsPnSMKscat+KG6KpSwFTeihb9Tsw2X0oMFg+AFqT+jCRBBA0peO0jtR+6Kqct2s3po8HqV58TunxmVVt7U8KGOCk/7mqB+u84KllUI3mvUO32m3+JPWuz+qwWCYkw3axAndJjkLdfZMLiSQ0xLf5/HBmA8BuaYlk5Zs2LKZZeaRuKq7bO3Puvc7crMHGS+vc4uhsnmZCE7W81JeIz2woGOeNvwjZBqZurjxYyWUMu3GGCm5vY/3QihRanog4nhLmAuxkE62jGNVPtAC5kbDp5VNata2Hu3IyOAXwYlDpJp0NPwzXnRnIpo='
_TARGET_BITS_PAYLOAD = 'eNrtWG0OwiAMPbnhZvYoPQI/+6OBCoMBZR8mJpqZ9WWJih1O2r6+NkoHRwFJFwjLzYGEy4ksH+hbv/IQymf9yO9dWYoXOQC/PlE4MaoHA4sRrAvpL5AOoLwTq408iYXZJcDRu+y3fIH2dnIPo4rIp1RHt3idd1Mvhm+hkjR6qcnGbky2oGgkSk02XzN74jpzl8FgMHwOV5jVb9UP+k2xLEukCZ36Rs2eLqMHDQbDD1B7wkgTQQiWvnSU3g7bF1WV62b11uTxzM1L2Dk1yKu6rYVBGaOc9DdH/XCdFyytFMfRrHf4UbslnLTe/VENBsOcbNImThw3yZmps2dyJoGUlvw+jw/GfCwMNS0BtWTjls1QZh4OqrpL1uGse78jNwcp4+V1bjFUtlAmgpP1vJTWUA8s8JinDf+IMo10XdyEsRKWMh3HGMm5vY/3Qsiha3rA83gLzYW4kE6y9GNVPtAC5kbDp5Wt1KxtPdqRkRQWwclDpJp0NPwzXtgKTpw='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod5_a3_b1_c4_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
