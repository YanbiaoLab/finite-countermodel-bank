from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[0,2,4,1,3],[3,0,2,4,1],[1,3,0,2,4],[4,1,3,0,2],[2,4,1,3,0]],"priority":322,"rule_id":"false.finmodel.setcheck.structured.affine_mod5_a3_b2_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod5_a3_b2_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWV1qwzAMlowLYk9a2QHM6EE86EOP5e2px9hRZylK4njZDy0rKdNHS01ijCVL3ye5CAAFVhB38AUOwPr7iHWAOgxwO+wBSDZ9BjjGK9c6IGQbnk83tULxBpSh2iCfZK683BQ+Ew2+uRYJ7Ij5x3n1S+C4X0RMcoBBU9lCMFt0yumixkC0NAkarEvwVk1j5rphNSDVbTfpTbrt0KZcCEaEeW2lX9i6H/gIsWFUSRAoi2WHFdLzCmkyxG06kiqxYAEKk2k8Rc9kGo2xQ0JmHYqzhMOxPbxoVmu+Bi4wV3NFng3lCYwiIDWKkkDu+axlRmR3q+NS5KCRldJQ4jf1RlVzyMdluzEpLjSSE2aNslcuPo4rykiNSI5zGWnxJFw4lpHR6hwGKqnviXFqp8YBul8djpVOS3ODacHommzxU/sV6sySrelY6dmyDYL71XEXKO/z+CHDoXu9S3LNMOKpwAlcSRyOu1C2LIrGqlTUKpNWh6/W66jEqXDpdEnv6M5z/AHs6l+CsSuskEp3ic2lhuEwHb/RnK002rVnkxySP8T0Qhqm23Wa8qsxVx5j6bu2jdn0D/ABZEchLA=='
_TARGET_BITS_PAYLOAD = 'eNrtWV1qwzAMPuqO0afNx+pDYT5IGT7A6PQ0BDWWZilK4njZDy0rKdNHS01ijCVL3ye5xMyBV5DP/AWODPr7RnVAOix8O5yYUTa9Yz7kK9c6Ekcb7vY3tULxyBi52iCfZK683BTYIQ6+uRaJ7Yjhx3n1i+y4X2RKcoBFU9lCMFp0yumSxkC2NCkarEvAVk0DgLphNSDVbTfpjbrt0qZcKUaEcW2lX9h6GviIqGFUSRAOi2WHFdLLCmkC5206EiuxUGAsk2kwRc9kGo6xg0JmHYKzhMOxPTxrVmu+Fgg8V3NBng3lCY8iIDWKkkDs+axlRgJ3q+NSxKKRldJQ4jf1RlVzjodluzEpLjeSU2aNslcuPo4rykiNSMhzGWnxJFw4lpHZ6hxgDKnviWlqp8YBuV8djpVOS3MDcMHommz5U/tV6swQrelY6dmiDYr71XEXCA/z+D3ysXt9TnLNMOI18J5dSRyOu1C2KIoGqlTYKpNWh0/W66jEqXDpdEnv7M5z/AHs6l+CsSusCEN3iQ2hhuEwnb7RnK002rVnkxySP8T0Qpqn23Wc8qsxVx5T6Lu2jdn0D/AB6CpQCg=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod5_a3_b2_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
