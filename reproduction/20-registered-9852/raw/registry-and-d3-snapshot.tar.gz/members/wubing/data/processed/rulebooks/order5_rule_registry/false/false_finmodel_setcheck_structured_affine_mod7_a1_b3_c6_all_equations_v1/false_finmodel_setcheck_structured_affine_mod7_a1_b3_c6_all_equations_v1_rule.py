from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_explicit","model_table":[[6,2,5,1,4,0,3],[0,3,6,2,5,1,4],[1,4,0,3,6,2,5],[2,5,1,4,0,3,6],[3,6,2,5,1,4,0],[4,0,3,6,2,5,1],[5,1,4,0,3,6,2]],"priority":335,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a1_b3_c6.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a1_b3_c6.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtl00OgyAQhWHCYuKKhQfgKHMEj0Rv0qMWpVpxJK2xLtT3xZigEyZ58wfWfHBsTgAZI8OT8Ec5Cb0cef9o7or9ZiDhd9uzK+FzUszygUYFqCbKSNyUqCH78EWGD6VJTinNfsXbfVMWAAAAAODGFMdQr349ii+ODrxMAQD+iJsvaHlTLa+EQZQNWNXOLhdtYdspm41ItTuHThk3DtGpTrasZFube2y4jPGzthFDzIsicVbcZfvjvhT9cNx5l2Sz11tquWNBR91hOL1p6ioSEZ36ZOOpTXrdPF0S0E4TMAr0AgCAi/ACSCkOIg=='
_TARGET_BITS_PAYLOAD = 'eNrtl00OgyAQhY/am5QjeQSOwgFcsDKzIANFqdZxJK2xLtT3xZigEyZ58wcxfQiUTgCnZIcn449y4no5yv4m3ZX4zcC6323ProQvSTHLBx4V4JooI2ZTorriw4sMH0qTg1Ka/Iq3+6YsAAAAAMCNEcdQr349xZfAB16mAAB/JMwXvLypyiuhs8oGrGoXl4tW2DbKZiO22p1do4y7gOhUJ1tRsq3NPUokY/yobUQQ86JYMytu2f6oL0U/HHfeJdnt9ZZb7ljQRncYym+euoo1iE59stHUJr1uniELGKcJaCz0AgCAi/ACBFdjFA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a1_b3_c6_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
