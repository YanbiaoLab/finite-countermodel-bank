from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_explicit","model_table":[[6,4,2,0,5,3,1],[0,5,3,1,6,4,2],[1,6,4,2,0,5,3],[2,0,5,3,1,6,4],[3,1,6,4,2,0,5],[4,2,0,5,3,1,6],[5,3,1,6,4,2,0]],"priority":342,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a1_b5_c6.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a1_b5_c6.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmW8KwyAMxRNx4EcZO0COkiPsSB59/ilVpoJjsIF9vw8ttcaWJnnwLNM7GvLJOvoUSWFEDwJbwEsZX50LQJKWqCu+CE1bOyJdEUlfWIpP+A/cqe3nkcjkC+6TYnPATCjAL5ttuXPkGQMMVBwAAAAAAABwZcpG6GGmOoNk41AdDNoY5H7qimfj6tZcf1daJ53fzMwMHTK3K2zcuJY0JZ21lA/LsIZA22yTvxzO12YLpff9t0/zQjreX7nl5e0hEPex0AAAwNa8AERRDDo='
_TARGET_BITS_PAYLOAD = 'eNrtmW8KwyAMxY/ukXaEHCUHGMOPwsRk/ilVpoJjsIF9vw8ttcaWJnnwrOg7ZPLJO/0UTmGqdwVbIEsZX50LQJKWqCu2CE1bO8xdEXFfWIRP+A/cqe3nUTXkC+mT4nPATCjAL5ttuXP4FgMCVBwAAAAAAABwZcpG6GGmOoPk41AdNNQY5H7qimeT6tZcf5dbJ53fLMwMHTK3KxLcuJYoJV2olI/wsIZA22yTvxzO1mYzpfftt0+zrDTeX3nm5f0hEI+x0AAAwNa8AAgvZPw='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a1_b5_c6_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
