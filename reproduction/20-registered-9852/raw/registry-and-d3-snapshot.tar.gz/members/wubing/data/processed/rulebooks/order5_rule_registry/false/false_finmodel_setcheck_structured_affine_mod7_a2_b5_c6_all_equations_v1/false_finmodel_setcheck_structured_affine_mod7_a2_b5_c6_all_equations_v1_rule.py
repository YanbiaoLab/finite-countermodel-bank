from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_explicit","model_table":[[6,4,2,0,5,3,1],[1,6,4,2,0,5,3],[3,1,6,4,2,0,5],[5,3,1,6,4,2,0],[0,5,3,1,6,4,2],[2,0,5,3,1,6,4],[4,2,0,5,3,1,6]],"priority":330,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a2_b5_c6.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a2_b5_c6.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmUtuhDAMhp3ICy/dniCLLnqMLDiYNaseuyGPaSATRpWmGjH9vw0QEsDw+yUcERlNiXZ09nUJn2Vznif+cPol8iDr247en/ekVyQS1w1nkW5P+f1IJCkTd6PgtVHVJAaXvn5SKa+6aGQ1uD70WdK6xANXqLKb3+2daOFyVbHN6rgMT1am1SM3vbjhIwIAwO9hzhHV58jqrE/6bgzza37QnwpiUv4hIAMA/g5fq1MZ6sE4RCQtnRBNghqiFgBHXIqz2Y22L/mhV+vqgdQdNt/sV4TecwE4ERqyfDXLWGq+8TX7pGGuci+ZRQ4SiQ47AIDnlZG8unZudzn5b/FgbvnKX3/r+NYU+3k9OmuGwaMJ4RpFb/20uGyLeiU5j2nWG7NsLNM32pmqaFr+Jd+njRTZ'
_TARGET_BITS_PAYLOAD = 'eNrtmUtuhDAMho/d1cgHY5FjdNFFTtB66YWVuCGPaSATRpWmGjH9vw0QEsDw+yWimZFNcXR09nXx72Vznif+iPwm8iDr2w7fn/ekVyTi1o1mkW5Phf2IMykTd6PgtWHmJIaYvn5Sqa66aGQ1xD70UdK6uANXqLKb3+3TbNFyVaHNarcMT1am1aM4vTjhIwIAwO9RzRE15MgaqU/6cQzza37gnwpiUv4hIAMA/o5Qq1MZ6kE3RCQunZBNghqiFgBHXIqz0Y22L/lhYOrqgdQdNt/sV/jecwE4EeyzfDnLWGq+CTX7pGGtci+ZRQ4SCQ87AIDnlZG6unZudzX5b/FgbfkqXH/rhNYUh3k9OmuGwaPx/hpFb/20uGyLejY5j2nUG7NsLOMv25nKaFr+Jd+k5Fxd'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a2_b5_c6_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
