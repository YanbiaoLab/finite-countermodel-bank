from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_explicit","model_table":[[6,0,1,2,3,4,5],[2,3,4,5,6,0,1],[5,6,0,1,2,3,4],[1,2,3,4,5,6,0],[4,5,6,0,1,2,3],[0,1,2,3,4,5,6],[3,4,5,6,0,1,2]],"priority":336,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a3_b1_c6.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a3_b1_c6.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmEkOwyAMRW2LBUuOwFF8NPfmFSFpBrBKW3VQ+t8iUkgUI+fjickhECl9D63W6xbSu6yEWK5Wb5jAzMYtMvby53eoi+3cCPcgmCoie8EaVy9cmgemjjsSRNTBiENfUJqdExjhNQB+npSnWJjieN2AhAsAAAAAAFLtnGNp+2RXJPLaym9b/UMZqQ+1jjLZ0LZjN1sGC2ntXakZNjgVbMB/BE9hVbbWyiju5Gc3sYsMfDb/nSN1Dh9GdJhhhk5sKI5kHjjHzlgvruv7iaD14kSYx113lSA4EKfLbLKRhZ/Zypqql8Uycg0A4GxcAWWPEQU='
_TARGET_BITS_PAYLOAD = 'eNrtmEkOwyAMRW9eH81H4QgsWSDbFSFpBrBKW3VQ+t8iUkgUI+fjSc0hm7F9D67W6xbiu6zkVK5Ub9TAzMYtMvby53fIi+3QCPcgmCoiesGaVi9cmgfEjjsiRNSBTHNfUBycE5jgNQB+nhimWBjTeN2AhAsAAAAAAGLtnFNp+2RXJOraym9b/UMZyQ+1jjLZ4LZjJ1oGC3HtXa0ZNjgVbMZ/BE9BVbbUyijt5Ec3sYsMfDb8nSN5Dh9kdphh5k5sKI5UHTjHzlgvrev7iSD14kSex113lSA4EKfLbLKRhZ/Zyhqzl8UCcg0A4GxcAebiYDE='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a3_b1_c6_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
