from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_structured_affine_mod7_a3_b4_c6","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_structured_affine_mod7_a3_b4_c6","model_table":[[6,3,0,4,1,5,2],[2,6,3,0,4,1,5],[5,2,6,3,0,4,1],[1,5,2,6,3,0,4],[4,1,5,2,6,3,0],[0,4,1,5,2,6,3],[3,0,4,1,5,2,6]],"priority":376,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a3_b4_c6.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a3_b4_c6.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmMEKwyAMhmPIwd7aN8jGHsRDL3srj33sodZNaYeFIWXl/y4ptAiN4UvUEJF3TCQE+uDI+RCVemb5YcbF2vg4/rqWpmBaK2n+li++hU+SO+/9ZEzQNLiwyyFhAY+SBwCcjM8m4mymSlsipaxkNX4Li7xeChPLIzbxMXd7foe65Un51iF3oMe0zNle5JftrFWXJB+SliKr4F9IR/FoV9VKvCHwtrL5+0IAANCfIbbn5KvFFgZKTXuWz7i5ukyo7S3MmACci96KC4XJFOd/nkX3hm/fXtTiHgEAAEDBCzhBDQg='
_TARGET_BITS_PAYLOAD = 'eNrtmMEKwyAMhh+7R99qlx58kLHlDdpbPYSYodZNaYeFIWXl/y4ptAiN4UvUq6qxosoK+mDVmhBJe2b57ufBufg4/7oWpeBbK1H+Vi6+hTflh+z9ZEzQtNiwyyFhAYOSBwCcjMkmkmymSlvMpax4NX4Lh7xeCh/LIzbxOXd7eYe65XH51iJ3oMe0LNleaobtrFWXpBySFiGr4F9IR/FoV6JKvCHItrLl+0IAANCfJbbn5KvBFQZKTXvkz7i5uoy17S3MmACcCz2LC4XJF+d/GZn2hm/TXtThHgEAAEDBCxQ/ZC4='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a3_b4_c6_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
