from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_explicit","model_table":[[0,5,3,1,6,4,2],[3,1,6,4,2,0,5],[6,4,2,0,5,3,1],[2,0,5,3,1,6,4],[5,3,1,6,4,2,0],[1,6,4,2,0,5,3],[4,2,0,5,3,1,6]],"priority":345,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a3_b5_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a3_b5_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNqtWUtu5DgMJQUNwM5KCOoAXPQix1B2WfaRlACznyPkqGP9LZNySZlxdyqRLUvi4+O3/mbv4PhvAMCiPT49gMFjAI88wDhAjgN3DOsAjAOE4WJKD1wAApum1CcIFG98wvUieIu//oof78dPsOVB2ZjypLh4feULTPwbKYAfHrj8LnmwftgkHP/iL26L1ZPbcs5jGHzalYoo+ZW0UJriuijxsN9t53+6KPl6lKft8iGfMy6RYLChPDEZoThkLgcqooQqyohX4JDROTBw512PiWkDa64Qcz7OI6vu+HjtolhbpOB6jvrktDjlJS1n4AftVV0ldiRpGNBJLTe6FM1cV4KzVlYuMlQPlV4Lw24+bxDObzj4+TXlr+cOACA3MYQkDszqZnOFZWPJqL+22coKG0BacK4gFWA0Wuw6MaEp6CKH2cEx0pdU+iba0MkE/odr6hA0LkfZwpRtcIP2aMxffVqV5L3Tz5xgQ6n4ZTA9zHwKj7ieDPR6Xr9ubFmgZNh4lixp80KbeMvKFcKGsU087J+G48co2QBb2CIQ97XDiP7LZPa7VIa5Gw68o0m80XTxqTB6okvd2Arm8dA0hD2SqDlX1WpU4k/GZ2MLTT1BuIhQTLA4YZk7bLr/r3RMD/puKQNpulW8TReTl4wtaYxkGHHUbxVdOlJYs0PJkhJp10s7eCG5xxx491z+iLmtWh8P6T2cEO6pEz1FbU5/poZ5GKkUffQRAmiVEnzr2oqxIYPu02PuGLe7bGQncqxor0Q2bbcUXu35LEqG3Nm54ihLZDPKfJeWPx85GptTDrWcFJmSxipARtqQmE2kx8aWcN8bW5zjndA+K/h6jSQ92odnuR9l1FF1I7li8CenI0K73covMb/+KTiV0kiUs8lO0kisK8yjOJfM3ql++2LBqWz4TCg4zdiektLm9xIZ/Fj9NO5gE9HOU5q1yIZGt31y9YOriOynudpiGpl3MlJH6CQyyq14D0ei4jNjk8H/W8oRvCw1fh1V+HIs8IUartbg7Xoos99U5/77cib7LI20it/GeAY8A5CcwBUr3vDIWCSyevB466n5ua76/bMwynmjCWosZ39PajampZotIW20vEgIHKddz+VdDZErxpaDCus44nCKbGzmyjHfdPJsw7INWUGR6KJYpqPBC05TfcbP0i9jzU0OMaZyyUenW6SVbnbJ2Gzp9KCQwyvgIurpkBv/vItsKbu7hDcn4oHsQI0e6WmW/J5WDKLQLtVH6WPlM1OYc3rN2KZ9RqidwQsJPfz8mjbWSoGWhar1t1Uk8UCrm4Vs1X9akvfR/X93gB8wTxV3yl+Xs3zT4OrdRNt1QvmZlWkEbQE5bdwm2vB/7dGpHi61lUYrirQJCvnMs1Ij3NVs1DqlYbBL25uedNcgCRtgZi+aHF+iZustBq+kdqiedzlFmHfCkzZH2sS9nQKgWTe2R41sYeil+IZjz25QcvB1qxt5WvtFZDrabCVe/rodDpHN1ciW2gmAPNeQ4m38Vodk+tUCS8tNTkCWCXxfMozGZvRmnNL6l19qbLr/0vpHfbdL6196m71Ku7T+WYYRpfXvWWHNjk9jmRcOlBxa//JLs+3I5qrWL4eUrX9uH+G+eTVvkICFph7Ri7C5+R2uFfxaY0lpkLjGNTPamOt5Ci6xe8XYUl5oUBZoJ8RqqW4USTZahD77wrcWcHrJ0hvk7aYGpN8Akk756tD6B9PThuMm1oH9sV0f17/w3oiI'
_TARGET_BITS_PAYLOAD = 'eNqtWUtu5DgMPWqOMPsBEh2pl9lFx8iiFzxAIdAqTWAEkWP9LZNySZlxdyqRLUvi4+O3/gbr+PgfmNmTPz4tc6BjwI88oDggiAN3DOuAg2Pi4QJMD5xhZJ+m1CfEGG+88fVC/oy//okfH8eP8eVB2RjzpLh4feWVQ/yb0LAdHrj8Llr2dtjEHP/iL2iL1ZP7cs5jaGzaFYso+ZW0UJriuijxsC9t57+6KPl6lKftsiafMy6RYPCmPAkZoTgEKAcqopgqyoiXAZPROTBw512PiWkDH64QQz7OI6vu+PjqonhfpIB6jvrktDjmJT1k4AftVV0ldiRpgMlJLTe6FM1cV+KzVlYuDFgPlV4zw242b2DObzj++TXlr4UOABM0MYQkjsPqZnOFZWPJqH+12coKG0B6dq4gZXg0Wuo6CaYp6CJH2MEx0hdV+iba4MkE/odr6hA0LkfZzJRtfIP2aMyvfVqV5KPTL5xgI6n4ZTAtz3wKjLieDPR6XrtubFmgZNh0lixp80KbeMvLFcyGsU087K+G4/so2QCb2SIQ9LXNiP73ZPaHVEa4Gw68w0m80XTxpjB6okvd2Arm8dA4hD2UqDlX1RpU4k/GZ2MzTT1GuAhTTLA4YZk7bLr/13RMy/puKQNpulW8TRcTlowtaQxlGHHYbxVdOlRYs0PJkhJp13c7eCG5pRx491z+iLmvWh8PaS2fEO6pEz5FbU5/wIa5GakUffQRAnCVEnDr2oqxEbDu02PuGLe7bOQncqxor0Q2bbcUXv35LEqG3Nm54ihLZAvKfJeWPx85GptTDrWcFIWSxipARtqgmI2ox8aWcN8bW5xjndA+KPhajSQ92ptnuR9m1El1I7lisCenI0K738ovKb/+JjiV0kiSs9FP0kiqK8yjOJTM3ql++2LBqWx4Syg4zdiektLn9xIZ7Fj9NO5QE9HPU5q1yEZBt3109QOqiGCnudpiGpl3ClJH5CQyyq14j0ai0jNjk8H/RcphrCw1/hxV+HIssIUartbg7Xoosz9V5/77cib/LI30it+meAY6A5CcwBUr2PDIVCTyevD47Kn5ua76/bMwCnmjCWogZ79MajbApZotIR20vEgIHKddz2VdDZErxpaDCug40nCKbGzhyjHbdPJsw7INekGR6KJApqPGCk5jfQbP0q/gw00OMaZyyUenW6iVbn7J2Hzp9JCQwyrgEunpkBv/vItsKbu7hDcn4oHsQI0e6WmW/JFWNKLQLtVH6WPlM6OZc3rN2KZ9Rq6dwQsJLf/8mjbWSoGWhar1t1cksYyrm5ls1b9akvfe/X93gO88TxV3yl+Xs/zQ4OrdRN91gvmZl2kEbgE5bdwm2sB/7dGpHi61lUYrirQxCvnCs1LD3NVs2DqlZrBL35ueeNcgMRtgZi+aHF+iZustGqukdqSedzlFmHfCkzZH2sS9nQJgWDe2R41sZuil2IZjz25IcvBrqxt5WvtbZDrabCVe/rkdDpHN1ciW2glMMNeQ4m3sVodk+tUCSMtNTkCWCXBfMozGFvRmnNL6l19qbLr/0vonfbdL6196m71Ku7T+QYYRpfVvQWHNjk8DmRcOlBxa//JLs+3I5qrWL4eUrX9oH+a+eTVvkLDnph7Ri/C5+W2uFfxaY0lpkLjGtTDamOt5Ci2xe8XYUl4YSBZoJ8RqqR4USTZahDb7ws8WcHrJ0hvk7aYGpN0AEk/56tD659DThuMm1YH/sV0f179bk+if'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a3_b5_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
