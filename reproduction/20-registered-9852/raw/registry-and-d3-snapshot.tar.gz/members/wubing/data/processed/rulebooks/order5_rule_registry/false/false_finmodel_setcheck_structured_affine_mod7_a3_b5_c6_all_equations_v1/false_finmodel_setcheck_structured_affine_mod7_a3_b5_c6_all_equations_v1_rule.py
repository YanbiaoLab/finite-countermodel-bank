from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_structured_affine_mod7_a3_b5_c6","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_structured_affine_mod7_a3_b5_c6","model_table":[[6,4,2,0,5,3,1],[2,0,5,3,1,6,4],[5,3,1,6,4,2,0],[1,6,4,2,0,5,3],[4,2,0,5,3,1,6],[0,5,3,1,6,4,2],[3,1,6,4,2,0,5]],"priority":374,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a3_b5_c6.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a3_b5_c6.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmFEOgyAMhlvShz6SZQfgKByN3WRH3QCZIuiM2YO6/4vRRRsyKn/7I9OIsBDYiw7XO9Hz7HNhstMpfZmyv/y7ZdIojUfzwLtJAtiV6HjUWDKQCPgVPq85F2WalqaE4YnrKLcrUOORRgC2iI0MF03ZqqrreMvnANs2TUfwVTkROuSDKNQlSj2JI9a28S6MtFraADimjUwLN9pIaW0kt9EqCzaSywhH6eKSq6DoXJM+lNP7T/MnetHSAADAJW1kLHyuU+u1NTIpivt2yNY//89GJvtno4dMncTUWdNQ34RLBOAUSPx8TsGkHWIUblGx5yJjx1U1rLeMN6QQgM17tvKxeGYjsvHIQjOhNNZ8CmtDKrIK9vMC21ERiQ=='
_TARGET_BITS_PAYLOAD = 'eNrtmFEOgyAMho+6m4yjcRQOsCw89qGh3QCZIuiM2YO6/4vRRRsyKn/7o+gICyvYCw3Xh+rt7HMR9dMpfZmyvfy7FaUojXvzwLpJAsSV6HjUeA2QCPgVNq85F2Waliab4YnrKLcr0GCRRgC2iE2DFE35qqrTeMvmAN82TafwVTkRNORD1dQliqyyU6G28S6MtFraADimjUwLN9pIbm2ktNHECzZSyghH6eKcqyDTXJPWlNP7T8snetHSAADAJW1kLHyuU+upNTIpSvp2yNc//89GJvvno4dMnSTUWSNT34RLBOAUcPx8riakHWIUblGxlSJjJ1U1rLeMT6QQgM17tvKxeGYjsvHIQgumNNZ8MmtDErIK9vMCcSBfrQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a3_b5_c6_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
