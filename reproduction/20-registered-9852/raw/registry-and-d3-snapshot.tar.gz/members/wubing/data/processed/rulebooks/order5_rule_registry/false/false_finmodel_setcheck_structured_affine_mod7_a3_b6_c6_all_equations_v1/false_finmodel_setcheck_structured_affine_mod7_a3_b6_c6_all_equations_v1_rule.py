from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_explicit","model_table":[[6,5,4,3,2,1,0],[2,1,0,6,5,4,3],[5,4,3,2,1,0,6],[1,0,6,5,4,3,2],[4,3,2,1,0,6,5],[0,6,5,4,3,2,1],[3,2,1,0,6,5,4]],"priority":346,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a3_b6_c6.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a3_b6_c6.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2UEOgyAQheEZwoLlHIGjcDS8eYHRNmoTUxYNi/9LDJHoSHDxRLYqv4pRUmtCkNaq319kTjKxXnKcBO+rk7VsH0Xsw/GKyQvWT13N44GLM5PcJ6S0RtX78mStXMa8nKb46XXFcehz8SoAAPxP8BTvcZbqPbvOEV/eXwIAAMCTcazy9FtoXoLV4nE1AAAAAKzD9sVLui1Zek8+9sFcEP4PruEFQ7MJ/Q=='
_TARGET_BITS_PAYLOAD = 'eNrt2U0OgyAQhuGbl6NxFI4wSxaEmQKjbfxJTFk0LN4nMUSiI8HFJ/IK9qtSLLemVmut+v3R5mQx6SXHSfW+MFlLtlGUPhyvmL1g+NbVNB64OBFLfUJia1S9L03WSnHMy2GKn15XGYc+Fw8GAMD/VE/xHmc5XLPrGPHx8yUAAAA8GccqT+9C8xSsUvarAQAAAGAdsi1e8mXJ0nvSvg/mqvF/cA1vCM1nOQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a3_b6_c6_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
