from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_structured_affine_mod7_a4_b3_c6","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_structured_affine_mod7_a4_b3_c6","model_table":[[6,2,5,1,4,0,3],[3,6,2,5,1,4,0],[0,3,6,2,5,1,4],[4,0,3,6,2,5,1],[1,4,0,3,6,2,5],[5,1,4,0,3,6,2],[2,5,1,4,0,3,6]],"priority":377,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a4_b3_c6.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a4_b3_c6.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmUsOwyAMRA3ywkvUE7DoQVKpB7Oy6rEbMOSH0m5Qv/OkiCggFjD2GOKISOmQQR/17oiR3NSEQODlnF24iRBJh7nitIn5JTwdNz2CxQcAdOJC4lPrGzMiHy3pJJa047Bm4GcQE7aLFHalF1sQbAyY2zABoCsnoitX/a1RXStyKRYhyb+DmTUpod36sZ4UtgLCIREA8FZGy0m6r6ssX/lagOWkJkNqSwrT7Ui4HvhCQszyDWTXeLISe/7MRe6udujhTLB1AD4Hzym0B6u6XYlgnp1t/q3jq4cduZdvjQ4AAPpzB0SBDs4='
_TARGET_BITS_PAYLOAD = 'eNrtmUkOwyAMRY/dVeSDVWoO0gUnqFh6YWE3TJlQ2g3q+J8UEQXEAr79DVEzIztkpEe9O5wznRrvDbycq/oTsxl3mMtNm5he/NNx08NYfABAJy7GIbahMSMLLiedyJJ2FGsGfgbOwlZnfld6SQ6CjQFLGyYAdOVmdpaqvzVEa0UuxSIk+XeICEUltFs/1JPCVkA4JAIA3sqQcxLt66qcr0ItwFJS4zG2JYXRdiRcD3wh3iX5esvXeLwSe/osRe5aO+hwJtg6AJ9DkBjaY666tUSwzM42/9YJ1cOO3Cu0RgcAAP25Awf/Ymg='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a4_b3_c6_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
