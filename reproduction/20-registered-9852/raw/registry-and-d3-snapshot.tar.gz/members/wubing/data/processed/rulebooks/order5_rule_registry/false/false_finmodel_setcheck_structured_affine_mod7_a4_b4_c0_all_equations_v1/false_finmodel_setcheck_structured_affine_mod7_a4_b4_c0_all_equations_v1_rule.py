from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_explicit","model_table":[[0,4,1,5,2,6,3],[4,1,5,2,6,3,0],[1,5,2,6,3,0,4],[5,2,6,3,0,4,1],[2,6,3,0,4,1,5],[6,3,0,4,1,5,2],[3,0,4,1,5,2,6]],"priority":349,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a4_b4_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a4_b4_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WUtuJCEMNcgtoV6xyAFYZJFjeKRZZNlHohezzxFy1CmKgoKyqU/cMyRSdxUfY/PsZ9x/gAB+A8ANACF4SM+pLQ8RbH5wqYemb+n/kcdADNC06eFZOsC1PQbKohAebYcDCsvUbqkimMq0tdnm+3fb4dtBpnmIzVTfScGls38L62am3titVVQxaS3fq5I709Rnp0rupLjVBCxmQVitvqpCJk/tzTKtgXZRxWxVmT/u0+lIp4J1k6sq1lVVe/llNUq9bkbCLDcs1sfYmBbzjimDKIuxW4PGzRum2cVWgAPrptrVw3b0xvIX2xC/QqMEypv9ubDiRrFB7gILN9iZQhq6UA+c2NpO8Ar6ubBOnw9R9c1oND+XNgwIPcjX0R4U0uyKNTpSPY4McLZR8WWzL6jZ3k3jbPV4vmlH9XlnT1C2YYQFDj/nhwqfdrYZBxFKZO0E9bBxqIxaC98gx4gdLO01zmYqRjw3IQpyrMrZZsoSQP0mb09jSZtjoeDVA/jZoHO2a6N1zlbZK3LJArM5lbNZJ6dGQvgXkrHrznYmzqyjo1U52ylSX6ld5Wz7gBFUv7+G2aTzZ6pHUjlbbjeZsiLzagWL1jTyeyCIZ70KiPS2w31mG1L75TRSoOlJ0L2T/+FB18KqUeRxckvTQSmtXD8sD1FM9Tlh15xasV0inPtRnHkD0EHS79v42WnC719XnQ19jUeCCYnHGadytpR4EE+hwgDoxvxHZ1P5gNnPiWlTbZh29CpmO5VsPXXOFgc0Jmj7z5htdnTjtzdUVYgcM1tK9XtUpgRXJ80u8x33ARSlaXKtJKEUiCSMvJjZfD455PmI5fEe9cxWsvzQ2ejRwSaY6gtl+K89i9ndAgmwOqPDFTah3uuW4W6H5Wh8srgiM5LZjzNazu7qe73y2YXDMsrXeInLaY5vwWaotQ9x3bXZYsRPqmPtpunTRxa6zXnFh4Xb7Gzu5Wlkj4rWxhvYpMuhKgFqCiRSWbaDTX5QMlsYZPmyyZTVyGq1Po28D/jyeSSNrLOf+2lkCsgCQ8NBjIb8I0VZCdsXMrMVR+pLq+7cDfUysyVBHCNGuHz7hXA2B1+x49sXYho5+GlhfmtjiRd2VspOf4HxfRhkZqM7G3FQByeO5s6GdMHZhMRDIIN6YsjfxYtp5Fz27K3w4AcplP4jevyqRDcP/xo7f2E24nQc5PvA3tGEg6vdUvq3fBAPUeGgEmaPfCSWigf75YoG5jgs/cexO/ql4sGxZvxggjkEgj9QPlX9+iuLAJscBD7YUb2Xvvzb2XsMEYd3tpqJsjSSh0N+aAQHh9mlkTTAmgAb4RVeSo7+AuL2ZyM='
_TARGET_BITS_PAYLOAD = 'eNq9WUtuJCEMPWqOkP0smiP1chaRxsfIIgsOkAWrFlJb4CmKgoKyqU/cMyRSdxUfY/PsZ9y/CIg+iOhJhGQdpefUlgdDIT/41APTt/R/z2PIWGra9HArHeTbnkhlUbL3tsMT2GVqt1QRDGXa2kLz/a3tcO2g2DyYZqrrpODS2b+ldTNTr+nWKqrEtJbrVcmdaeqtUyV3gtlqQgGzIKxWX1WBmKf2ZpnWwLCoEreqzB+P6XSkU8G6yVWV4KuqvfyyGqRePyNhlmsX66NpTIt5x5BBlMWErUHN5g3T7GIrwKF1U+3qdjt6Y/mLbYhfoUEC5TP8XFhxI9Mgd4GFH+xMIQ29rQcObG0veAX8XFinz6eo+mY0xp9LGwaEHuTraEcKaWHFGhypbkYGONug+HLcF9Rs76lxtno8b7Cj+ryzGynbMMISh593Q4VPO9uMA0MlsnaCeth4VEathW+QYyQMlnYaZ4sVI46bEAU5QeVsM2UJoP6Wt6exZMixUPDqAfyC1TnbtdE6Z6vsZbhkgdm8ytmCl1MjIfwLydh1ZzsTZ9bRJqic7RSpr9SucrZ9wAiqP17DbNL5M9UNqJwtt6dMWYZ5tYJFaxr5NhDEs14FRHrb4T6zDan9chop0PQk6NHJ/3Ska3bVyPA4uaVpq5RWrh+Bhyim+pywa06t2C4RzuMoznwT6SDp9m186zTh96+rzoauxiPBhMDjjFc5W0o8gKdQdgD0GP+js6l8IO7nxLCpNkw7ehWznUq2bjpnMwMaE7T9Z8w2O3p02xuqKkSOmS2l+j0qU4KrkxaW+Z77AIrSNLlWklAKRBJGXsxsLp8c8nwk8HiPemYrWb7tbHTvYGNj9YUy/M+excJugYRYndHjChtb73XLcL/DcjA+WVyRaSDuxxktZ3f1vV757MJ2GeVqvMTlNMe34DjU2lmz7jpuMeIm1bF2w/TpDAvd8bziw8Jtdjb/8jSyR0Vr4w1s0uVQlQA1BRKpLNvBJj8omc0OsnzZZMpqZLVan0Y+Bnx5O5IGwYff+2lkCsgCQ9NBjKb8I0VZCdsXMrMVR+pLq/7cDfUysyVBHCNRuHy7hXA2B1+x49oXYho5+GlhfhtMiRdhVipMf5bxvR1kZqM7G3BQWy+O5s6GcMHZhMRDIIN6YsjfmYtp5Fz27K1w5wcplP4NOnyvRDcPfx87f2E24HRs5fvA3tHYg6vdUvoPfBAPUfagEhaOfMSUigf75QoG5jgs/ZuxO7ql4sGxFt1gQjwEgjtQPlX9+iuLAJscBD7ZUX2Vvvzb2ZexBod3tpqJsjSSh0N+aEAHh9mlkTDAmgAb4RVeSo7+Aml7ChM='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a4_b4_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
