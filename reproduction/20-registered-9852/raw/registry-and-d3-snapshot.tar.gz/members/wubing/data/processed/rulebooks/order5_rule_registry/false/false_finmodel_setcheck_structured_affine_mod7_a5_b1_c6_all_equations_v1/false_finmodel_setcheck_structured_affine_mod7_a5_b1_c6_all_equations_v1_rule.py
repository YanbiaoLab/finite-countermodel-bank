from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_explicit","model_table":[[6,0,1,2,3,4,5],[4,5,6,0,1,2,3],[2,3,4,5,6,0,1],[0,1,2,3,4,5,6],[5,6,0,1,2,3,4],[3,4,5,6,0,1,2],[1,2,3,4,5,6,0]],"priority":343,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a5_b1_c6.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a5_b1_c6.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmFEKwyAMhmPwwcccIUfJ0Tz6Wluxqa7tYIyV/h9FrIhKNCa/gRqRyMo318C3sGJSSuVH7rPuXEo+7ZewxQAAAAAAADyLuOoFqbrB6QPzLWGRReBPpKlqlXHRq7+w7cxER08DCnP+1tnywOwhdHp84GwMIQ/ui65H2N5cUcndSFOZcz8IXz3+sXmPqb88abuAWIfV0zc+26/7EXAzlDeR0iAfmHpLOgsy2mcb4N6RbXEj2e+1taTEtYkcRTQXAzvyMpH0eU0aDDrPxnxhBiRCAADwMS+YQQ0m'
_TARGET_BITS_PAYLOAD = 'eNrtmFEKwyAMho/u0XKUHCGPPkjMWluxqa7tYIyV/h9FrIhKNCa/2RrJjMo318C3oGJSi+VH7rPuUEo97RexxQAAAAAAADyLtOoFqbrB6QPyLXmRReBPpClzlXHJq7+87axmR08DDHP+1tnCwOw5d3p84GwKIQ/uC69HmN5cUdHdSFMZQj+IXj3+qXkPsb88bbuAVIfl0zc+2q/7EWgzlDcR2yAfmHpLPAsy3Gcb4N6RbXEj2e81taTEtYkcRTQXAzvCMpH0eU0cDDrPpnphBiRCAADwMS+0MGQQ'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a5_b1_c6_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
