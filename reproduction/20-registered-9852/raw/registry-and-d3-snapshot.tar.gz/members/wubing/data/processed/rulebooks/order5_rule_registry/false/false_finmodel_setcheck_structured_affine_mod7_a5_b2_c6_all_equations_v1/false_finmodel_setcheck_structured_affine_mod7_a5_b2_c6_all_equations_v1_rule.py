from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_explicit","model_table":[[6,1,3,5,0,2,4],[4,6,1,3,5,0,2],[2,4,6,1,3,5,0],[0,2,4,6,1,3,5],[5,0,2,4,6,1,3],[3,5,0,2,4,6,1],[1,3,5,0,2,4,6]],"priority":331,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a5_b2_c6.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a5_b2_c6.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmEFqxDAMRSWhhWbnuYFbehAVZtNbeTnHbmxPXKdOGkoLk3b+gxBjgnEUfX05TETJhUjpUPi0rXwP08UEdnnhcDX7nbXiPAj7z8VHCO4b6bNIGS51UgJ0PnlJWCQqAD+GiWVUWvapIjC/CS+0EqSIGQBgiSrlfijXEiNOc1u5PkVftTLSlkRUAQDgj7SRpcZHvx3VwkYbWep6ftwXhvCNE3P1Dk3kPllL5xNBx4Nhnnrd8Bj5cCPBR/xPeP3yOVXSp+yhYarkyFYCxH7JQ3Aq2qr7ulqXyvWUdtEmyvlVdbfZOtDrAfCgxKc2THTm7g+zXDSuFK2hkq1gZIgsAHdFqcrQBs0ydzqO1Hzcehs/MiF0TcSiH7eVEiXd7yBwR94BIR8TqA=='
_TARGET_BITS_PAYLOAD = 'eNrtmEFqxDAMRY89S9+qm4HqIKX1Dca70UJIamxPXKdOGkoLk3b+gxBjgnEUfX055u6B1F38UNC0rXxP02UOdnmxdGL+nbXiPEj7z8VHCO6Ty6tqGS51UgJ0uVJJWCQqAD/G3HRUWvapIjC6CS+1EiSIGQBgiYjnfijXEnYLc1u5PuVftTLalkRUAQDgj7SRpcZHuh3V0kYbWep6fpwWhvCNE3P1DglONFlL5xNJxoNhnnre8Bj9cCPFR/xPUP3yOVXCp+zxYarkyFYCxH7JQ3At2qr7OnGXyvWUdpYmyvlVZbfZOtDrAfCgxLc2DH6x7g+zniWuFK2hkq3AzogsAHdFvMqQB82adTqO3nycexs/Mil1TcSiH+eVEqXd7yBwR94BK2Fdjg=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a5_b2_c6_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
