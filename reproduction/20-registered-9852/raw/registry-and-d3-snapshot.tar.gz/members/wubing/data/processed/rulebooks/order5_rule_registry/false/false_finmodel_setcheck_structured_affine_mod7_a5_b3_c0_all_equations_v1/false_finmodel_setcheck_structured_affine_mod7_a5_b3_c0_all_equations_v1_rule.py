from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_explicit","model_table":[[0,3,6,2,5,1,4],[5,1,4,0,3,6,2],[3,6,2,5,1,4,0],[1,4,0,3,6,2,5],[6,2,5,1,4,0,3],[4,0,3,6,2,5,1],[2,5,1,4,0,3,6]],"priority":344,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a5_b3_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a5_b3_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNqtWUtuHDkMpQQFYLwSjD4AF1n4GPIuyxyJNjD7OYKPOqW/VKSqVZ7IQXdUUkn8PH77Hwoejn8WAJxxx2cAsOaYwCNPTJwYihN/TOsErAcD0yBMC54Bj01xS10xgPHoDzgPhLf49SNvAmBXFsrFmDfFw+srn/lYgwxhWvD5XQzgwnQJH3/xi9phlXKXt0Z+OaRbsbCSX0mr6VjfWLGR2K9287+dlTweZbWNUOiMRyQxOC4rNrMSp0SFoMIKV1ZmeTFxPtJS5rfeemxMFzh7FjFlch7t+NeuFecKF1TpgFE8+XDMRzqKl560Vxi0CR3pi8B4qeUGl9CogiDQYGB7oMVKFLxPtMfbQiaV4S+NJX4DQWfKUN0tL/Zgdy9bKywbS5b6axekkDfdEKQD74ukuICyMm26Tix3BeH0vr0jxwm+01kJNjiYAJyhf38sHYKG5e4hNLR1MpejGPNn31YZeO8OxA5iQ6n4bWFGn+JUn0Je263RG/aNLTOUDNuMnEVPf4ZN4suLE/Ztcelh/zQ5/r7gjG/hhvrZPEv/BaQHIdVJBXs1nY0tESfjjaaLD2ldfqFL3dgK9ZFoROnXJx15X9VqVeAv5qOxcT/UnV0EFxMsd8rc4ab7z0mAjuuSgTTdKsGys0lbxpY0hopXx85U0aVHBWN3IFlSIg0WL43wAvLQQuodlz/L3LmisZnIEDoBDD11wqdSW8OfMK0qoTn66CME4C4k6NK1FWMzsMgBYu4YrxsevcuAY+8EohLZWHkhhVc3Mp0z5LOssJrtdmSz+m3H8eOzaGxe5iPSB1wrNLBUvDmWHMrdqMfG5gCvjS1lcF5on1AKJ2gg6dGe4QmbmEk1Eri25gNhcDoitDsh0Wtja459zkiCFlhMCe1aGmnq1esoTjmfIH9tQIUPW+hihQ/aAKUrEURYcIJN+jiINhcWFfZDG8PK/aOvH1RZpCB32jtpq89osFJHxkvJKI/iMzMD1VwZWyRYlhpfkl0O8pyfRxW+HQsCdxZ/TCsPZfeb6tx/badfJY10ipczkYbRClN6G86yohseOaeRS+y/9dR8rKt+fS+MUiZzITWSu78WNRvhVs2WRGilIbMUTtx2piv4MUQ+M7a0yZMuRzMhgoJwpGGwVPM0x/Pd8QXpokimoxyEH8G6Rs/SL7tOI905lUs+Oj1CycVOilciGym+HiUR1CpwGUD8/N+ryJayOzMZnJMBWnagZo/0NEt+TyeyKLRL9VH6WKbfZnRM7xnbss+YpZYTdQt/Zywba6UdlDmp9bdTLg6Au5dxtmql0h0K4vaQFezeKX99zvJtE1fvJrquE8xrTnobvCXIZeM2wYYmNPv/q7Xi4VJbacZahA2r5D0pNfiqZsPWKeWJAdebnjiIjaTi94VpcuIRaren9RY5wF5Vjfu19roTnhKiGTZAoHqybVt0+KiRjadeilbpKjy83upGDme/iEznTDXrTurn5XQyttzxdKUBBIbWfDjZHwy3OiTLnxZIls3JCXhh0HRdMszG1uOoFy5ibv3LHzVuuv/S+tdxfW79J2/jT9TfqLRL619pzSqt/0AKxu64MhrzQiMhObX+5Y9mtyNbqtlSy+DEtGj9U/vg6+bVukECDpp6RM7nsoS5g51vNJaUBolvWPuchel7nvLNnplCWMoLrZEF2iCxWqpb+F7+2OtksyhZetrQHgbFbsMNQeKQr06tf7B2bEGZNvHftetj/Aetc4p8'
_TARGET_BITS_PAYLOAD = 'eNqtWUtuHDkMPaqPMPsBHB5pltlZx/AiCx6gYWhlE4ggcUp/qUhVq5zIQXdUUkn8PH77XzSWj3+emV1wx6dh9uGY8CNPQpwEjBN7TOuEveXA00BKCxaYjk1xS10JTPHoH3wexO/x63fexAyuLJSLKW+Kh9dXXvOxgYDNtGDzu2TYmekSOP7iF7bDKuUub438gkm3UmElv5JW07G2seIjsS/t5n86K3k8ymobptAZj0hicFBWfGYlThELQYUVqKzM8gKEfKTHzG+99diYLnD+LGLM5Dza8R9dK84VLrDSwaN48uGUj3QYLz1przDoEzrSF3KwUssNLqZRxUagIfD2IE+VKH6baI+3mUwq8F8aS/wa5M5UwLpbXmzZ7162Vlg2liz1jy5IIW+8IUjH1hZJQQFlZTp0nXjoCqLpfX9HjhN8p7MSbGgwAT5D//5YOgQNy91DaGjrZC5HMebXvq0y8NYdiB/ERlLx28KMPsWpPgWttluj1+wbW2YoGXYYOYue/gybxJcVJ+zb4tLD/tfk+POCM7iFG+xnwyz9T5YeBFUnZfzVdDa2RJyMN5oufkjrsgtd6sZWqI9EE0m/PunI2qpWrwJ/MR+NDfqh7uwioJhguVPmDjfdf04CdFyXDKTpVgmWnU3cMrakMVK8OnWmii4tKRi7A8mSEmmw+GyEF5CbFlLvuPxZ5s4Vjc1EGtMJAO6pEz2V2hr+SGlVCc3RRx8hgHYhgZeurRhb4EUOEHPHeN3w6E0GHH8nEJXIBsoLKby6kemcIZ9lRdVstyOb1287jh+fRWOzMh+RPuBaoQak4sOx5EjuJj02Ngd4bWwpg7NC+0hSOEYDSY/2wE/YpExqkMD1NR8wg9MRod0JiV4bW3Psc0ZitMASSmjX0shQr15Hccz5BNprAyp8+EIXKHzgBihdiSDCghNs0sdBdLiwKLMf2oBX7p9s/cDKIhq5099JW21Gg5c6ClZKRnkUn4UZqOHK2CLBstR4keyCked8HVX4diww0Fn8Pa08lN3vqnP/tZ1+lTTSKV4uRBpGK0zprTnLCm945JxGLrH/3lPzsa769b0wipnMhdRQ7n5Z1GxIWzVbEqGXhgxSOHHbmS5jxxD5zNjSJou6HMOECDTCkZrBUsPTHM92x2eki0KZjoIRfoTqGj5Lv/w6jXTnVC756PSIJBc7KV6JbKj4epJEYKvAZQCx83+vIlvK7sJkcE4GaNmBmj3S0yz5LZ0IotAu1UfpY4V+W9AxvWdsyz5jllpO1D3/nbFsrJV2UOak1t9Oudgw7V4G2aqVSncoiNtDULB7p/y1Ocv3TVy9m+i6TiivOelt6JYgl43bBBuc0Gz/VGvFw6W20oy1CBtQyXtSasBVzUatUwoTA643PWkQG0rF7wsz5MTD1G5P6y2C4b2qmvZr7XUnPCVEM2wYWfVk27bo6FEjG0y9FK3SVXj4uNWNHM7+FJnOmWrQndTX5XQyttzxdKUBxAHXfDjZHzS3OiTLnxZQls3JCVhh0HhdMszG1uOoFS5ibv3LHzVuuv/S+tdxfW79J29jT9TfqLRL619pzSqtf4MKxu64MhzzwiAhObX+5Y9mtyNbqtlSy+DEtGj9Y/uA6+bVukHCjpt6RM7nsoShgx1uNJaUBoltWHudhWl7nvLNnplCWMoLfZAF2iCxWqp7/l7+2OvksChZetrQHhrFbs0NQdKQr06tf/Z+bEGFNrHftetj/A+e/uar'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a5_b3_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
