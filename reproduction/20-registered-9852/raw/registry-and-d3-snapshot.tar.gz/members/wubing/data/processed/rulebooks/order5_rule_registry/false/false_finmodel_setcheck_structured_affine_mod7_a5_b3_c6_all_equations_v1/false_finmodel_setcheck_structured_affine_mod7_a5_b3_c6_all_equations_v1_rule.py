from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_structured_affine_mod7_a5_b3_c6","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_structured_affine_mod7_a5_b3_c6","model_table":[[6,2,5,1,4,0,3],[4,0,3,6,2,5,1],[2,5,1,4,0,3,6],[0,3,6,2,5,1,4],[5,1,4,0,3,6,2],[3,6,2,5,1,4,0],[1,4,0,3,6,2,5]],"priority":375,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a5_b3_c6.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a5_b3_c6.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmU0SwiAMhQPDgmUWHoCj4K5Lj4SexKMKaaXQtOOmo1bft6klTBuZR36KoQ0cnWg3DHmXL1cCh8CMF/9i2mSPZN/uobfychfyu8/5R+q8yh6FfhAAAP6INMW/Egm913Gd28nMkvMzdiXCb95/ipu4GddM2cBJHA01PQVit/B++psBOgGHQ9T81LDrTSL/dswyGVZPIB0D/hA/xgRDKvKVmxS6IHObA4arXdJyRQEAG5st1D2TVMPJ3S6MZVpsi5Y2WzssJtgBu11GZolxV+3GIj4Z8q0kn8KEJMEuPVtR5KUWFEM13ecAONTZWrsJQgTgC3u2cUPLQYgtCcSEufhR2ceqby1xfSYAh8hsY4k0ncyobxFykDO3BXHt8MZiFX+cBzmVEq0='
_TARGET_BITS_PAYLOAD = 'eNrtmU0SwiAMhY/qSZQjuexOjsIBXGTJgoEIaUvBtOOmo1bft6klTBuZR35K4g0C33k3EvuQLxcGhyCNF/9i2mS3HN/uoY/y8uDyu2/5h+m8yh65fhAAAP4IM8W/Egm913Gd2slEkvMzcSXCb95/irO4addM2UBGHHU1PTmm8OT99DcddAIOh6h51nDoTSL/diwSJ1JPYB0D/hA/xoTEKvKVG+O6IHNeAkaoXdLzigIANjabq3vGqIaTul1oyzTbFi1ttg5YTLADcbuMzBKjrtq1RXwy5FtJzsKEJMEuPVtR5LUWFEM1nZYAONTZWrsGQgTgC3u2cUPLQUgsCSS5pfhR2Seqby12fSYAh8hsY4k0ncyobxFykLO0BXbt8CZiFX+cBxLrXok='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a5_b3_c6_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
