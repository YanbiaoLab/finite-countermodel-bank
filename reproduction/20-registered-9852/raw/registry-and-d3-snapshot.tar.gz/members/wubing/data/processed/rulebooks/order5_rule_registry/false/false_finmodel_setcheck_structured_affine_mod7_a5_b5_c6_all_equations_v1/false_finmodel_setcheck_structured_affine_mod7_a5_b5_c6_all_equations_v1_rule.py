from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_explicit","model_table":[[6,4,2,0,5,3,1],[4,2,0,5,3,1,6],[2,0,5,3,1,6,4],[0,5,3,1,6,4,2],[5,3,1,6,4,2,0],[3,1,6,4,2,0,5],[1,6,4,2,0,5,3]],"priority":348,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a5_b5_c6.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a5_b5_c6.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtl0EOgyAQRWFCE5YsegCWPcYcoUeiN/GoFZ1qB2jSlDap+l9iiKAQYEae1ow482Os2T9+T5NZIiLmicWQqyjf09ycymeDAQAAcEiCHA48Xkk3RanWQnDtGY2kR1+fu670melo8m4rC+lXX4py3KrJKJci22lvdt6eqVO1R2nZunUf40FUDpTJthRDlWwqRCSrO0KSnz8e56rvRmqnzSykJFu9PInbaXWizwcbR7pRe3m4+cLACHUAAAAAfF0jL5PUSKm8qEmPRs7/Rpx9y9Eb9tMlPz7ww1eHtorVOt2jkT6L8Y1eqnphl4g9AAAAf80d+UYOYw=='
_TARGET_BITS_PAYLOAD = 'eNrtl0EOgyAQRY/qTeRIPcIco0sO0AVLkpKBik5tB2jSlDap+l9iiKAQYEaeMU2E9GNi2j9+T5NZI8LmiVmXqzjf89JsymddAgAAcEicHA40XUY3WanWQnDqGY2lR1+fu6H0mflo8mErC+kfvmTluFWTUS7FsdPe4rI9c6dqj8y6dY99tAdROVAm21oMVbKpEJGs7ghJev54XKq+G6ltNrOQkmz18hhqp9WVPx9sGmnk9vJQ84WBEOoAAAAA+LpGnmepkVJ5UZMejVz+jSj7VuA37KdLfryju68ObRWrdbpHI30W45Ffqnphl4g9AAAAf80NUyti0w=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a5_b5_c6_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
