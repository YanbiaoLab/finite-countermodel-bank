from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin7_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin7_explicit","model_table":[[0,2,4,6,1,3,5],[6,1,3,5,0,2,4],[5,0,2,4,6,1,3],[4,6,1,3,5,0,2],[3,5,0,2,4,6,1],[2,4,6,1,3,5,0],[1,3,5,0,2,4,6]],"priority":332,"rule_id":"false.finmodel.setcheck.structured.affine_mod7_a6_b2_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod7_a6_b2_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq1Wc1u5CAMBssH9kb7BGjUB0FVD30sdrUrzXEeecNfYjDOJGHqSo2SEPxvf3j+KQ/KL3+o1IeK5EO6oEk3n/lGuXgDPt+gT5eFnCLkdFkcydA3GrbFnr4wVtVvAn1eGadvsHkDZYuFmWm+eSyrbz3nSMEpsErXrwmhsWw1ZWtt4URU0dop20mbVfFhuFc0Gw7fvAN8oRu8sCrL63vuoWwUFTWdKvkCTBVP31P6pfP7LwUDCVb6Xl2kOlmraCH7NanpB2YO7EkU3qkJ+qYStHu/6TbG8rKvzgWhu+6SGL/Bjz/gbjhOxWHJBe02gHvi7REoackHtmm1hW24D8P29vnMc14JVknGtsWG4NpvVJ/pVrHkO0diQcibhoYPUG7+Arc/yvhR7cvWcm2sOSGejtJSan4LkbeGn617G6Rl+YJBTbYMIhdXN6WiSuBH9ZQ5WEo2qcLmXQx11PYELyeblD1m7YW0W4WZqvWRW+coM+6rlZAUphsobuCDFP6GpRYaqb0Nq8R1Ki0LiI8g88Hqr9AGqWMxdpzeKee3vqzjoJUd6jYoJdu2vWt28qzWw8E4F9PeWCI50p1SLPAW7C6qRTBAXnU3fpT5DBVd72wlb83mFt+WmI612wtJeJ5s20a3pv4yq01hEdrZHNcjcKulOmJkY5v8LzzrbK5qNoQ2r0jr8v3mHk15eGa6VAT0fhjt50Wu/PmkUf1vpFB2F/vnKthSr7TNjPwRmc0Mt6XTxBiJnXtw7oB9L57vbAmcugQDbAlOfFp+Lne2Da+uIbmeBwdWu8HFtI6mIbZZDleuz2Neo/Ap6tE7nS29bSMxdzZklWO6swENat1E/XogbdS1crF9nmx+S7YEujZ5+eljqvTTGu+YmzHL0qLA68iHwkjNYmTkFDefbOshO/2zrez6lXZcOMQzYkgjkHK0M0Qj99LMLiOHEYqKyIt3Nv8l2PpIIjy22cY2NdE/1dneE17NjDKM9EWjoF5OcaRVgYe+ge3nLC9sNHFAYox9C0UzUDr8jFKrh7RVFN01eKCUM1sW2DUJwiWMLM8Zt6NUW77DaRTeD9aC0CUwqt6Og/A8CidNX69yDTRrTx95UDSBkB9WAt+DweBsrsmD22SaAYycSQEP9Ejd0H0MrCcGTRVGDopvdPpyrIJX1n8NwngxhZ/O47dQSss0jFTSJBy4tqYDZw1/090McwQxRPGBJ6pZxLBDcHb9zKbRiGfwmmwhS21nw/+hrBBjKXJK19QboymILv60kLO6zjynk7pIKo7+zfrIU730leJYOxvNV87Ns2bgZnqrOPr3jrH3bhBjZwJHHv3nuY/mks2c2aTR//NmcN6UoU48gH3E8QCoMiBxT/CskWFkovirj1b7eIDh1fOdLRsS9LAgYyfxKOvc8QQo00hjhehpNtej32L8idLyXcbtFa/u4QF3Q/YUT+X2fwlfbY8='
_TARGET_BITS_PAYLOAD = 'eNq1Wc1u5CAMfuQeR9rVLo/Vw6jiQaoRT9ByWw6WYcNfYjDOJGHqSo2SEPxvf3h+BY1BL38QwmeIpFW6gEs3H/kmmHiDOt+ATpeFTCBkfFkcydE3HrfFmr5wNtRvFH1eGadvoHmDZYuFmWu+eVtWP3rOkZQJaIOvXxMCZ9lqytbawomo4r0JtpM2q6LVcK9oNhi++UK8gxm8sCHLq3vuqmwUFXWdKvmCTBVN31P65/P7e8CBBCu9ry4KnaxVNJX9mtTUAzMr9iQKb8IEvVMJ2r2/fRtjedm9c4Hqrrskxq/S4w+4G45TcVhyQbsNwp54e4RBWvIJbVptYatuw7B9fDzznA6CVZKxbbEhmvab0Ge6DSz5zpFYEPKmquGDlJu+wO1PcHpU+7K1TBtrRoino7SUmr9C5K3hZ+veDmhZvmBQly0DwMX1TamoEuhRPWUOlpJNqrB5F0cdtT2By8kmZY9beyHtVmqman3m1jnKjNtqJSCF6YGBG/ggqd9qqYVOam/DKnGdSstC4iPMfKD6S7VBaliMHacvyvm7L+swaGWHug1IybZtb5qdNKv1eDDOxbR3lkgOdKcUC7wFm4tqEQyQV92cHmU+Q0XXO1vJW7e5RbclpmNt9kISnyfbttGjqb/MalNYhHY2w/VQ3GqpjjjZ2C7/U886m6maDaHNK9K6fL+5x1MempkuFQG/H0b7eZErfz5pVP87KZTNxf65CrbUK28zI31EZjfDbek0MUZi5x6cO3Dfi+c7WwKnJsEAW4ITnpafy51tw6trSK7nwYHVHngxraNpiG2Ww5Xp85jXKHiKevxOZ0tv20jMnQ1Y5ZjubEiD2jdRvx5IG3WtXGyfJ5veki2Brk1efvqYKv20xhvmZsiytCjwOvKhMNKzGBk5xcwn23rITv9sK7t/pR0XDvGMqNIIpBztHNHIvDSzy8hhhKIi8uKdTd8FWx9JhLdttrFNTfxPdbavhFczowwjddFIhZdTHGlV4OEfaPs5ywsbTRyQOGe/VdEMg1c/o9TqIW8DRXcNHijlzJYFdk0CdQkjy3PG7SjVlm91GoX3gzUldAmIqrfjIDiPwknT96tcA83a00ceFE0g5Dcrge/BYHA21+TBbTLNAEbOpIBGeqRu6DYG1hODpgojB8U3On05VuEr679HYbyYws/n8ZsqpWUaRgZpEo5cW9eBs4a/626GOQKgovjIE9UtYtghOLt+ZvPgxDN4TTaVpbaz4f8WrBBjKXJK1/QboymILv60kLO6zjynk7pIKo7+3fpIU738leJYOxvNV85Ns2ZgZnqrOPrXhrHXZhBjZwJHHv3nuY/nks2c2aTR//NmcN6Uqk48kH3E8QCGMiAxT/Csk2Fkovirjw/7eIDh1fOdLRsS/bAgQyfxKOvM8QQo00hnhehpNvej32L0idLyXsbtFa/u4QHzAPYUTuX2f0MhA6c='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod7_a6_b2_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
