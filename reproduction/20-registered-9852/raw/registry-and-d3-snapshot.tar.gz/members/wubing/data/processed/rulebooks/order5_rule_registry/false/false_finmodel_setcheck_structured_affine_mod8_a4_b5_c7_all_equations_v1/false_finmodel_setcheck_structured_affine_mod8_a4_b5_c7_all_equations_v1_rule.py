from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin8_structured_affine_mod8_a4_b5_c7","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin8_structured_affine_mod8_a4_b5_c7","model_table":[[7,4,1,6,3,0,5,2],[3,0,5,2,7,4,1,6],[7,4,1,6,3,0,5,2],[3,0,5,2,7,4,1,6],[7,4,1,6,3,0,5,2],[3,0,5,2,7,4,1,6],[7,4,1,6,3,0,5,2],[3,0,5,2,7,4,1,6]],"priority":379,"rule_id":"false.finmodel.setcheck.structured.affine_mod8_a4_b5_c7.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod8_a4_b5_c7.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmUuOwyAMhg1i4SVH4CgczSP14PWDOIwaZTWKNNX/SW0SPwKY5F84hcB3M1qfVMj+hSpTp0F2ekezX4TU27Ax9dA9qjy6Ki5DdPzWhXx5J5Un8djXpxeVPFxsmtUmvMWrnbUifuh28kn5UQ+LL5bP2hDNYXOxctUjUX1TLNzLotZJe4bk6P2sbb+v89cguhO6V0xFomqD1pM4epSG3dhoVVq30i9WrbJkg2I3PZm3/S/H4wsAeI7eUwvt/a35XkpKpxk5NPcQgVM4Uwm2xKWLKY1hAQAAAAAAAAAAwP/mRZWtPV1a9HDLas9embytG23tZdx623W1cyndnkLL6X0I6dtdW+Zab+LTdNE/vxwj3JFC4Xy6Nw4AAH8BFxO+0EJJxRsU39lUP1PxyqUpP6othWT65dwE0hT5Df7nKu4='
_TARGET_BITS_PAYLOAD = 'eNrtmUuOwyAMhg8+0vhoHIUjsPQCwV8/iMOoUVZVpKn8SW0SPwKY5F84E8l3U3srmNB/wmA0VOjpHV1/HjJuw2qRQ7Oo+eiqeFaS8Xsj2PJOBhdw3dcnFwMWTjrNoRPe4sXOUhE7ND15Z/6Kh8kWy2dtgFJ1LlqucSSKr5CGW1nEWrBnUIzeztq2+zp/DSQ7IXvFmORVq1hPYm1eGjZjx6q0bKVdrFpFySp8Ny2Zt/2fx+ObJMlztBZaqO/viPeSQjrVyK65hwicwhlKsCUuXQxpdEuSJEmSJEmSJEmSJP+bHwzW9vTs3sOdqz17ZbK2rre1l3HrbY/VzkW4LQXLaX0Iattde+Rqb+LddNE/vxzD3Z4Cdz7dG0+SJPkEPFX4XAspFK/Cv7OJfobizUtTfFRbCsn449wEUhX5BU2KRkg='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod8_a4_b5_c7_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
