from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin8_structured_affine_mod8_a4_b6_c7","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin8_structured_affine_mod8_a4_b6_c7","model_table":[[7,5,3,1,7,5,3,1],[3,1,7,5,3,1,7,5],[7,5,3,1,7,5,3,1],[3,1,7,5,3,1,7,5],[7,5,3,1,7,5,3,1],[3,1,7,5,3,1,7,5],[7,5,3,1,7,5,3,1],[3,1,7,5,3,1,7,5]],"priority":371,"rule_id":"false.finmodel.setcheck.structured.affine_mod8_a4_b6_c7.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod8_a4_b6_c7.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2bEOgyAQBmBtbEI3jvQB9MLgY4i5QdY+kTEOuNU+cYFB08Z26NTh/zZ+iEfI3WRZALzRfrgVhbqEoRyL88djo3Us1lnjOnM9Ed4NAAAAAAAAAAAAAAB+1fqBl6C8JVrF0P7foTNe5J4ikRA0NbPuU2RXkWo/JXNQRL1qvkUA/6nzvFjmbQYa7lP7xmZ/DMy54XPzc2zn6iBizqteua3r9834lTg0aTMunK5c6/P05EKp7Otk5UsQpTheoDuIDmpsm/Wsp1gqZmmhplo9AT3/Quc='
_TARGET_BITS_PAYLOAD = 'eNrt2bEOgyAQBuAnrt1kMMYn6orDRXwMB3L6AA3HVpKaaoFB08Z26NTh/zZ+iEfI3eSyArzxur2sa7ipdmnW+8djjTVM1lhnend9CN4NAAAAAAAAAAAAAAB+NeiWSxW0FSnIyf7foXea6JwiIqW8jJXvUmQLonk/RZUKIl0Yv0UA/6nXXFrmbQZG7lL7xmY/tcy54XPzc2zn+SBizqsumK3r9834lTg0aTMujJ/NoPP05EKp7Otk5UuIpDheoD+IDmpsm1Pl61gqZmkR6ik8AQ6BLk8='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod8_a4_b6_c7_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
