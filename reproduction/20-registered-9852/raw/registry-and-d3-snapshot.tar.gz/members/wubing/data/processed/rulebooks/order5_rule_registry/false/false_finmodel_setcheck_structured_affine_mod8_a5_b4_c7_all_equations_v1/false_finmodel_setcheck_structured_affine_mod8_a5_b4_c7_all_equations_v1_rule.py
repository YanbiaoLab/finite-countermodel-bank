from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin8_structured_affine_mod8_a5_b4_c7","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin8_structured_affine_mod8_a5_b4_c7","model_table":[[7,3,7,3,7,3,7,3],[4,0,4,0,4,0,4,0],[1,5,1,5,1,5,1,5],[6,2,6,2,6,2,6,2],[3,7,3,7,3,7,3,7],[0,4,0,4,0,4,0,4],[5,1,5,1,5,1,5,1],[2,6,2,6,2,6,2,6]],"priority":378,"rule_id":"false.finmodel.setcheck.structured.affine_mod8_a5_b4_c7.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod8_a5_b4_c7.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2TEKwjAUBuA/odXi0lqcNYYOPUIHQREHO+oJPII3MIODY49U8CI9gqODEAO6KQXBYov/NyQhCSTkwSMkAtQhJnzU1aHJVQJIV/YAD1HdPKGeu3JNxoaIiIiI6Id2lTm7W/k+A0qRYea6LhjzXIg6bpQnuYRJcmC9jLUGTg7P5WPb1SBVYiH8BKvRJpi6tjQedCOLLbZK+4FMo2EBX8tYCXWMChjDOLTZzYraUWu/+BZn7Lx21AkZEiJqj7L/yIVvUtN18poy30yzlh8IRH/uDriAJxg='
_TARGET_BITS_PAYLOAD = 'eNrt2TEKwjAUBuCAg6NH8CKCR+ro4BBv4BE8gY51KKLg0CN0KDE6l9ouUm1JfgN1UwqCYov/NyQhCSTkwSMkFtQhMq/r4eybqxQwrrwBFbKmeVY/duWajA0RERER0Q8thnLkbuXzEBjbEHvXNcCJ50LUcYkf+wYy9oH1JlUKmDg8l7ctg0uk7daWMYJkVRxc28gK6iuLbZdalYWJsrOHUplUWz3NPEjJOLRZT9jGUSE++BYnxa5x1MkZEiJqj/G1zoUvUlP/+JwyX0wTgh8IRH/uDpPxSh4='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod8_a5_b4_c7_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
