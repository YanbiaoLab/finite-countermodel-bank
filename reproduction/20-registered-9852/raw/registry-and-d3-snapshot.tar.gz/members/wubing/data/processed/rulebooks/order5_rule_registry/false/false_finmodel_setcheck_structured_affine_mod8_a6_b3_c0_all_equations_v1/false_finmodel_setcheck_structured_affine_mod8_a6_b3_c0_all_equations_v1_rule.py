from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin8_structured_affine_mod8_a6_b3_c0","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin8_structured_affine_mod8_a6_b3_c0","model_table":[[0,3,6,1,4,7,2,5],[6,1,4,7,2,5,0,3],[4,7,2,5,0,3,6,1],[2,5,0,3,6,1,4,7],[0,3,6,1,4,7,2,5],[6,1,4,7,2,5,0,3],[4,7,2,5,0,3,6,1],[2,5,0,3,6,1,4,7]],"priority":368,"rule_id":"false.finmodel.setcheck.structured.affine_mod8_a6_b3_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod8_a6_b3_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNqlWUty5CAMBUoLlhxBR+FoZDH3nraxQaAnjLupVBIMRn/pIf8r2bmcXXHO0ee/8+f47/MTjwm7Y07Hn3yufSbHigvu2OGPF+tL59bP03TP+/D16TFSlAuxLtA5CfVZqQdynyS5HEI/Icmz0kWV2i9Xd5YiOGH5Upe4Mtne5+tp1KIIgWPjsIkiVu8Ntw5HaapE/lJbX62ipKrM89WLL76JRde072ZRHAU3DW4m7TrMQhRA/pySsNHBA917jXE5EZ8npYs5aYZBi4cZymxFr/aRRS2622VHJ7io8aQBKV4wiUSLmum/mQ2W7+3ZVljSnEiDpYGl0CQZlATc7eWg6+jYDMDCGjwcm25OsvtufCIxYNsytnH+/EI21vaBCjYSQp1kRS1CHjZHEJKV4fCsBMhr515qpR1Atq8FrZA/S3X8LFrspk/IRtoWxRagPAablWH7kzCelua4LqBCyGALc7AF6UYs+CMplS5Tgw39bGC1RD164vRGz8BJcpknXXntGuSgjK5MhNittNb3LmkUS8arZBlOXaZYUdhhK6CHAxo1HVog2Lz7flzBxgkuIfb/zJT/nDrvYEtKa4cQ8V2w3fvLOti6P9CYe8ZECYONVkE3moK5nxUejF4xxG+VrZk+a2/k2TBSUA99YFXP7cp2FgNyuojtuGRy7ypbt6Zgx3dqAUWkh/mjoGAjHYcB+Bs72+2Caf8bRoIS2s0QZx64QRilumDFZ2c3DnDMrwit+BocJZ4q9RaMBL4GtAZKezBwCUPUwNI8US75wUlTt1MQh2fLVQniXeqFJupgI+DU0Q4DesDOtw1AimoQtWllrLhfjCRw93RlAYBIK6AxRzvUzDshAERIAWusMPFmX00FPkkaouziEb8HI/NwAhluA1xiFYqri7oCRNptnlUphbBhpHYb2CLAKZ/wZYQE7h60xsMJwQi2CJEwQhtrGAk7GirYNtFkk34kRBp7BB0QezTSfrCBm66hgK37hnvqA0Gt8T6NDIAfvdMa7dMA/Rx/7DtfD1m6IXi0BHRlAx7ZfUZQ7KIukMUEJSsYqbo9oG1YyaadC4U3xfdzaEedI6MzrggvK1ucygioLEVfR+krambj9kRwDCyzU7GLqeJevNIMrwpC2f4tjQ0YCTtNfqeBFpfdLgwjiz4WNCjzKyTEZiccFLvzmvwYXeG5G9nzbDCzlsyisPUSUS4pKtiGRk/RvR/Z6Bn650btZIxRzMr2otjtoJKHyvai2G0AvHZnK63RwgPk0K4W1EcNnFLSIjIKvMXAZA8eTQ3tx9Zygp8QUGQxSB3pfbCNxZKaprzd+3lDZQ627mh59si4cJt34/gI5+/0ON790l7f403WStfhoPeHYcNPdfRqkOiue8l4N/hIt11Ts/gKOKYocQUZsk/44T56dUFA1moJI60eLeGrYuA/FgV8xQ=='
_TARGET_BITS_PAYLOAD = 'eNqlWUty5CAMvfcswtE4io7AkoUKmLaxQaAnjLupVBIMRn/pIf9zvhTviyul8Oe/8+f47/MTjwmVY87HH3+ufSbHSknl2JGPF+tL59bP03DP+8j16TFClAuxLvA5SfWZqwdSnwS5nFI/IcizwkWV269SdzonOCH5Upe4Mtnep+tp1KIIgWPjsIkiVu8Ntw5HaapE+VJbX62ihKrM89WLL7qJxdK0X2ZRCqcyDWom7Tr0QhRA/pyysNHBA997jXE5EZ0nhYs5aYZBi4cZ3GzFrPaxRS2W22VHJ7io0aQBKV4yiUSLmum/ngyW7+3eVljQnEiDhYGl1CQZlATc7eXg6+jYDEDCGjQcG25OfPlufCIxYdsStrH//EI21vaBCjYSQp14RS1CHjZHEpK54XCvBPBr515qpR3Atq8lrZA/S3X0LFrspg/IRtoWzhbAPQablWH7kzSeFua4dqBCyGBLc7Al6UYk+GMplS5Tgw3zbGC1xD164vRGz8BBcuknXWXtGlygjMVNhKistNb3Lmk4S8arZBlO7aZYUdhhK6CHAxo1HVog2HL5flzBRgEuIfb/zJT/nDrvYAtKa4cQ8V2w3fvdOti6P/CYe8ZECYONV0E3moKon5UejF4xxG+VrZnea2+k2TBS0Ax9YFXP7cp2FgMuuojtuGQo7ypbt6ZgJ3dqCUVkhvnDoWBjHYcJ+BsV2+2Saf8bRoIS2s0QZx6oQRilumTFZ2c3DnAsrwit+BocJZ4qzRaMBL4GtAZKezJwCUHUQNI8US7lwUlDt1MSh3vLVRniXe6FJupgY+DU0Q4DfsDOtw1AimoQtWllrLhfjCBw93RlAYBIK6AxxzvUzDshAERIAWusMPFmX00FPgkaouzikbwHI/1wAhtuA1xiFYqri7oCRNptnlUphbBhpHYb2CLAKZ/xZYQF7h60RsMJyQi2CJEwQhtrGAk7GirYNtFkk34kxBp7JB0QezTCfrCBm66hgK37RnnqA0Gt0T4ND4Afv9Ma79MA/Zx87DtfT166IXi0BHRuAx7ZfUZQ7KIukM4EJSsYqbo9oG1YyYadC0U2xc9zaEedI2MxrggvK1ucygioLE5fR/krambj9kRwBCyzU7GdqeJevMIMrxxC2fktjQ0YCTtNeaeBFpfdLgwjnT4WNCj9KyREZiccFLvzmvwYXem5G9nzbDKzlsyisPUSUS5xKtiGRo/TvR/Z6Bn650btJIxRzMr2otjtoJKHyvai2G0AvHZnc63RQgPk0K6W1EcNnFLCIjIcvMXAZA8eTQ3tx9ZygJ8QUGQRSB3hfbCNxZKbprLd+3lDZQ627mh+9si4cJt34/gIl+/0ON79wl7f403WCtfhoPeHYcNPdfRqkOiuu/N4N/hIt11TvfgKOKYocQUZsk/64T56dUFA1moJI6weLeGrYuA/Nnv0Yg=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod8_a6_b3_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
