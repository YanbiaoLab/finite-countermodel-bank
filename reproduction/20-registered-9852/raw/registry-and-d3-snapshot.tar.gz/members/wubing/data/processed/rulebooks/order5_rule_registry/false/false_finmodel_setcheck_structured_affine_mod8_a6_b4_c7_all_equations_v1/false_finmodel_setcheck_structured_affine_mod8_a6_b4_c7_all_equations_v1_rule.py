from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin8_structured_affine_mod8_a6_b4_c7","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin8_structured_affine_mod8_a6_b4_c7","model_table":[[7,3,7,3,7,3,7,3],[5,1,5,1,5,1,5,1],[3,7,3,7,3,7,3,7],[1,5,1,5,1,5,1,5],[7,3,7,3,7,3,7,3],[5,1,5,1,5,1,5,1],[3,7,3,7,3,7,3,7],[1,5,1,5,1,5,1,5]],"priority":370,"rule_id":"false.finmodel.setcheck.structured.affine_mod8_a6_b4_c7.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod8_a6_b4_c7.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt0TEKwjAUxvEXK1hcWryA+ujgIQRLyJDeyEmLdEjXnqhH8QgdHaSxQdqSguImyvdbCv+8kpAIApg4UiuITkR7asTrsVzLakapTtWS5jtcGwAAAAAAAAAAAADAX6nt2n3u1tqzv9J26eCnrjzHB7ntRZ/sdrNB/1M0OUZn4aWrS4GXmmE3gZeDn5NmcpUppbk0JqmMGVcqzXxxacNSFSbcFrFLXCbM4xSzUsbEMhTv0nc8ALNoSlE='
_TARGET_BITS_PAYLOAD = 'eNrt0TEKwjAUxvEUB8cewaN4oq7NUKQ6eaNmCKGCh3AoT72AtEupYM2zQdqSguImyvdbCv+8kpBYBpjYcmCZN8x7Du3rsVSZ6M65ynXNtwOuDQAAAAAAAAAAAADgryzF2X1mQoi1vxJ0aeenrjzHB6noVZ/sNhdt/1M1OUbn6qWFS62XwmE3i5eDn5Nn5pJprSiWsoikHFciRbRy6URGJ7I5JqVLFBdE4xSR1lKWprHv0nc8AJkJJuU='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod8_a6_b4_c7_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
