from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin8_structured_affine_mod8_a7_b2_c0","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin8_structured_affine_mod8_a7_b2_c0","model_table":[[0,2,4,6,0,2,4,6],[7,1,3,5,7,1,3,5],[6,0,2,4,6,0,2,4],[5,7,1,3,5,7,1,3],[4,6,0,2,4,6,0,2],[3,5,7,1,3,5,7,1],[2,4,6,0,2,4,6,0],[1,3,5,7,1,3,5,7]],"priority":367,"rule_id":"false.finmodel.setcheck.structured.affine_mod8_a7_b2_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod8_a7_b2_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9Wb2OGjEQHhsnZ05RYhDlSXFWG4kyJVVinbZYulOeII9wZYpIcaREIR1CeQCKexCqPAePcGWKk4j/Fjhsk0PYHoldLQMexp5v5pvhBwgMKzBSm6uQ5kaoebi2D8D1Axb64QtEZN2LaXoXEcV4EVGIj7G1nitDQcUcgFchheSAGaCAhlBGg2st1bfqoAYhxIEFFJS5nfNcUdtGgpohxg3hAcW7bkc9V9xCvqP2vIDgQwUX+/p96SOrbwDDEWmdAf3Zg73ofpW+rDavoZz83fQKWtt8LWhsvXlV0NrDBpUzJpVn5Q7uHsG63MH9QZM1lDq51Qr9LAeA8bStfs1oIWtv+9N6MCgUlcu2mg6LbeTdbHQjcCmw3Uk8QP1yYNtZzp5T3u9b/pAfbFvPerfwOTPYdpRo/r1umrzWpruTGs1om9fYJ7V/+j7ZXuA+n7UaRuZ+ueVLkuQDG7IeacZ2kR1sHdUdxyhvUrkGTBXzQ4qqCkAU9E1Rvjx5TFgabS7KoDZCIVvpoZgDYsaQ48k5BWGkO4dv6sWyV1MupPaIK4tCNSzM0PdsAPi965bmzXAwyFvZFjs/Fm1V5a2oN2rjVBW1aXna9V84G9gU1pDCGbFgU00Wdv13BrAJE4xCr+7aWpEPbGO7kVCrXCmyky7XqGv/VAPOs4NNdk22ubDgjCCREKqTldT9N1XRkTdHypEBM1PRaEKzSGWjVEciOZgzJJehSvudIWbcFJAtR+pZGnIzFFRhGx/ZoqSllA2k8wwDkt2cJov8Z/TzkLQvXh/vfBN3Hy+ujmmvZG+VsBGX1bF+Tdb1m5SFZz462hqLJmmvGh3cArwEuE0MNgxyFlbNKMjE1dvRyGCqVlqRlisjTMLrGcKnuIMwWE+TWpbRSbgmRDzxeIEQIiFExDUtITxttlQFlISrJmVay02ulonS5hxYpJCZyBGNK3VpfIz+tWDH/dYIThSXK5eXA6pJIH2HljihQLghxbOA6tI/41l8hSeCzeyav1PC393AW6fB0PWgzP8O45Ffds6AxDEdfx0UCZsAUk4ZkBjxpyO3oXpwNo000vhkzqt54uwRG7ZWMAom5MMNC6HuhM7c/ctIWSx6Hh2kCGRTAU8fdbT2gLd8dc9p335FvHcJnEKo/wEGbHjh'
_TARGET_BITS_PAYLOAD = 'eNq9Wb2OGjEQRroi5T0Cz5GKB7mCB4gQXYgSKY6UIiWPkCeIrmOL1cmXijIlUlYbR7oSgRNFd77E2BP/LRBsk0PYHoldLQMexp5v5pvhNWABAzDSmCtG5saZebixD0D0g8D64T1EpL+JaTaPEcViFFHgT7G1fitDQcUYgLQhBSIgKMiAhjPKgmsN1beaoEZKSYAGFIy6nfNcUdvGg5qVEDUnAcWXbkc9V9xCvqP2vICLQwXB+/p9eZBWX4OAI1I5A/qzB3vR/Sp9GfS+Qzl51tsUtNZ7V9BYv/ejoLWLnixnDCnPyh3cpYR+uYN7Lud9KHVyg4F8VQ4Ai1nVvpywQta+Psya9bpQVA6rdrYqtpFXk+U1FqXAdoXEWj6UA9vOcvac8nnf8m1+sG0920zhQ2aw7SjR+E1T13mtzXYntZywKq+xj2r/9H2+vcBlPmsNLM39fsuXEM8HNmk90oztMTvYOqq7iFHepHIDginmJxVVxSAZ6JuifHnyGLY02lyUQW2EQbbSwwQBSY0hx5NzihRSdw5v1Ytmr6YEI+0RURaxaliooe/ZAPBi1y2N69V6nbeyjXZ+jKq2zVtRr9XGqSpq0/Ks679ENrAprEmFM27Bppos4frvDGDDJhixXt21tTgf2BZ2I6FRuRJnJ12uUdf+qQacZAcb6ppsc6HBGUEi4UwnK6T7b6aiI2+OREsDZqqi0YRmkcrGmI5EfjBnSC4rlfY7Q9S4iSFbjtSzNOlmKLIVNj6yRUnFGF0j55kAibo5TRb5z+jnImlf3D/e+SbuPn7dHdPeoc0gYSOO2mP9GmqabykLz3h5tDXGddJeNTq4BfgJME0MNgFoElZNGKDE1dvRyGCqVlqclitLwcPrGcKnuAM2WE+TWobRSbgmRCTxeIFzjiBExDUt4SRttlQFlIerJqNaS0yuRonS5hhopJCZyMG1K3VpfIz+tWDH/daISBSXA5eXA6p5IH2HljihQLghxZ+A6t4/40l8hSeCzeyav1PY393AW6fB0PWg1P8OJZFfds6AxDEdfx0ZCZsAUk4ZkBjxpyPTUD04m0YaqX0y59U8fPaITVgrQgYT8uGGhVB3Qmfu/mVkNBY9/xwkDmRTDE8fdVT2gLd8dc9p337LvXc5nEKo/wJGFPhG'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod8_a7_b2_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
