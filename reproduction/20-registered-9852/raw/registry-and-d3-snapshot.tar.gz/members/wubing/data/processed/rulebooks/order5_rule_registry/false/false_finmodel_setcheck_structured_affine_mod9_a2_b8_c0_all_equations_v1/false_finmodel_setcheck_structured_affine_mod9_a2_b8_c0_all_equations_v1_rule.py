from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin9_structured_affine_mod9_a2_b8_c0","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin9_structured_affine_mod9_a2_b8_c0","model_table":[[0,8,7,6,5,4,3,2,1],[2,1,0,8,7,6,5,4,3],[4,3,2,1,0,8,7,6,5],[6,5,4,3,2,1,0,8,7],[8,7,6,5,4,3,2,1,0],[1,0,8,7,6,5,4,3,2],[3,2,1,0,8,7,6,5,4],[5,4,3,2,1,0,8,7,6],[7,6,5,4,3,2,1,0,8]],"priority":372,"rule_id":"false.finmodel.setcheck.structured.affine_mod9_a2_b8_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod9_a2_b8_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNqtWUuy7CAIFcsBQ5fAUlwad/D2/Tox8QdE7bTV1ffGqHwPIP2Pk3MpOXbOhc9/5+f47/PB/HA8B3LHQ8oPxxvn3bEC+FxwvqA8G13Zdw/Is8eI2L7A/CKcDz7PsWsPAFf35lW+ntC9iNemUL5cXsnccELtplAJZkr3oMqBEAXK1lEUuue6Pel+BMf9Wf4SGd0wYszKTMcfKCxlVtEV7btOlNNyfjyLikmrilMjMDXzrV5CI9ixNNxrjXE5EZ1cxou5oMuXzcCjFUGsCxY1dLfL9k5wUaNBA9XKQtZBUnWY/pvIYDnq3tP7q1fnL4PFjiXfSNIM7oig2x+hNQIMQg8nRvdyfJDodduSbuP0+QpzymAo2AgIqluhqr91lfpGMu7sLn0gPTv3o1baI9Eyi5z6e2E2bNxfx+FoC54J8Ag2I8KmwgC6fb80wcaFT5D8oXRWv0AsWWAr0QE1HEK7lyfxYxYj+baCXwFM/DaA9CnL4IalLfraYQnQ3QGFWpx4f1o5cGbMDyGKy6b+M0P+3KA32KIqNW6CbWZRqOYJilxBro4WBZ6HM6riz1CUa4iXmc2o4VhMRSeKzi1g95kNV3a8ccnYniqSdv4KytxS7DLBpqDbj1PYeSLvhuOzjHzQWq0smwgevhPrZBcNPSqEtNS+N64y8s8IWJ37LZeRk9qB4kr+feEdxTFQD1EW2PBrrBW3UkJUFMHihVBdNvGWQ4fRxviGmq/3Zy0g9yldW0Z7ZaQ3whHLsItLQX6e2bzkKG5VNotgg75o7PoLoARjb4domIPNuGTLa9xP7mxRNwW03HJ9eAEJtu6HmnP9BGxXDEkaIf/sottg823zapSEewG9ooANgVMjxhRs8FaRmM8r1woeeIZpmbiTcwCOU08auWl1e4wy9ej2vKABu8/Yt9NI7QapwPFrZSQp+oExWFFc8QQwxYf7aGp1pUytFd3zzKamETmF39UhTYPEaNyeFRwp0uB6eFJUDIVQHItS3qvHp0pG7Lp6MKgwfYEtnN3ZSB7E6bcptMlszgIbdFnAP/eIF8BW616aKUym9r2rFueNLBWFFtN+wSHIAlup8klyx4ZkYV+sJrMpkpBRbr1qkKRa5QN1JY/UpBc/auhyxgdkcGE4iDsFSRyRha2FxmG+s1Fvdu/U1r8yxVtN8wtsfbIMhld1vZ9vWvPBBKVs/dPb6u74EQ7u8Njf/Zb613uVXrwOT9K1zbLhTRmZaxKBIU6L4Y/WA3VqfgW8d7EZJLVSYyeJYzVUlGIoUzTNPw+S/geBRljK'
_TARGET_BITS_PAYLOAD = 'eNqtWU2S7CAIvvdbDEfzKBzBJQtLfZ2YqAhE7bTV1TMxKr8fIP0PXM7OZcg5h89/5+f47/Oh8nA8B8zHgysPx5sc87EiwbngfIFl1ue67x6pzB7DU/+CyotwPsQyB7k/IOW2t6yK7QT2wl+bQv3KZSVAxwn2m0IjWCjdAxsHQpRUt46i4D3H9rj7MWXgZ8VLZMrD8L4o0x1/UmWpsEq5aj8zUU7LxfEsrCZtKnadwNjN93oJnWDH0nCvNcblRHhy6S/mgi5fMQOMVkxiXbCoUb5dljvBRQ0HDTQrC1kHSdVh+q9Dg2Wvew/316jOXwbzjKXYSdINYEQo74/QGyENQg8n+vxyfJAYdduibmP3+QpzyslQsBEQVLciVX/rKo2dZMDsLn3APTv3o1b6I8kyi5z6e2E26txfx+FoC5gJ8Ag2I8K6ygDlfb80wQaVzyT5I+mscYGYs8BWowNpOEz9XpjEj1mMhNsKcQUw/tsAwlOWwQ1IW/DaYQnQ7IBKzU+8360cODPmhxD6ZVP/mSF/btAbbF6VmjbBNrNoauYJilxBrvYWBZiHM2ziz1BUaoiXmc2o4UBM+SyKzi1g88xGKzveuKTvTxVJu3wFZW4pdplgU9Adxylingi74fgsIx+01irLLoKH78Q62SVDjwohLbXvjauM/DMCFnO/5TJyUjugX8m/L7yjOgbpIcoCG32NtepWSojyIli8EIplk2g5dBhtTG+oxXZ/1gIyT+naMtwrI6MRjkCGXVoK8vPMFiVHfquyWQRb4kUj6y8kJRhHO0SnOdiMS7a8xv3kzuZ1U6SeW2gPLyAB1v1Qc66fgO2KIU4jFJ9ddBtssW9ejZIAFzAqCtgQ2HViTMGW3iqSynn1WgEDz2laJu7knJSOU08apWl1e4wy9ej2sKABu8/I22modoNU4MS1MhIV/aQxWKFf8YRkip/uo7HXlTK1VnTPM5uaRuQUfVeHdA0So3F7VnCoSEPr4UlRcaqE/FiUwl49PlUyEevqpUGF7gts0ezOhvIgcL9NoV1myxbYEssC8blHvAC2VvfiTGEyte9dtaBsBKkospiOCw6BFthqlY+SOzAkC/tidZlNkQSNcutVg8S1Kj8hK3mkJqP4UUOX0z8gAyrDQdwpUOIILWwtNA7LnQ252WNWW//KFGw1zS+w8WQZDK9ivZ9vWvPBBKVs/ePb6u74ES7d4ZHf/Zb613uVnr8Od9K1zbLhTRlZahKBIXCL4Q/XA7XrfgW8d4EZJLVSYyeJUzOUl2IoUzjNPw+S/gfLKxhs'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod9_a2_b8_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
