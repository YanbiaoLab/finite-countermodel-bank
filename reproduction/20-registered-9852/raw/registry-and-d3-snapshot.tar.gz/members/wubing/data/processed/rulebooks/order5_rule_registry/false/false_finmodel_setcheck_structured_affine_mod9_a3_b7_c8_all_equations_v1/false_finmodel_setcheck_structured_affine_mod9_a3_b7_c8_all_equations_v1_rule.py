from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin9_structured_affine_mod9_a3_b7_c8","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin9_structured_affine_mod9_a3_b7_c8","model_table":[[8,6,4,2,0,7,5,3,1],[2,0,7,5,3,1,8,6,4],[5,3,1,8,6,4,2,0,7],[8,6,4,2,0,7,5,3,1],[2,0,7,5,3,1,8,6,4],[5,3,1,8,6,4,2,0,7],[8,6,4,2,0,7,5,3,1],[2,0,7,5,3,1,8,6,4],[5,3,1,8,6,4,2,0,7]],"priority":363,"rule_id":"false.finmodel.setcheck.structured.affine_mod9_a3_b7_c8.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod9_a3_b7_c8.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmU0OAiEMhUvDgiVH4CiNJ+PoFjoCHfEvMXHh+xY6QkF9TB8WAwGwpfZHfhIRqYg+5R4VoNh3KDHL22rGXHWhOFMhaSvG0G+QTYwQ8/725nO7yp52oV3ZoLf7M7ivWbG8uGUPjRySfjWmH7Fz1jkiu5HLCACAclnssq6J+cg6U3mVQGahOwOVI1PrzE0+JfZiG8MBnAXMeWV+Jvfu/7CzmQ7svn2Z5hYXMaqXLTnlTnYY736XAAAAAAAAAAD4uGaz00hOrToOUQuxo1DeNbWjNq3HmW6NdnDWXtM4ohzdNoSs01d3AAAAfkwKzf83xq72L/aHyWH+Ydtk8TI2gkSuc9kF2gnfFUr/FpU='
_TARGET_BITS_PAYLOAD = 'eNrtmU0OAiEMhY/OyUyPwhFYsiClFjoCHfEvMXHh+xY6QkF9TB8WqwCwJfRHfhJRJJI+pR5Vodh3iCXR22qWFHShOEkUaivG0G+QTIxa0v725nO7yp53oV3Zqrf7M7ivWbS8uGWPjByifjWmH7Fz1jkiuZHLCACAclnsMqyJ+cg6c3yVQGahOwOlI1PDzE0+JfZiG8MBnAXMeWl+Jvfu/7CzmQ7svn2c5lYWMYKXLTvlTnZY7n6XAAAAAAAAAAD4uGaz00jOrTquRQuxo1DeNbWjNq3HWW6NdnDWXss4ohzdNkSs01d3AAAAfkyuzf83xq72T/aHyWH+ddtk8TQ2giyuc9kF2gnfFQGBWqE='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod9_a3_b7_c8_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
