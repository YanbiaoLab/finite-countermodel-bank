from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin9_structured_affine_mod9_a5_b5_c0","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin9_structured_affine_mod9_a5_b5_c0","model_table":[[0,5,1,6,2,7,3,8,4],[5,1,6,2,7,3,8,4,0],[1,6,2,7,3,8,4,0,5],[6,2,7,3,8,4,0,5,1],[2,7,3,8,4,0,5,1,6],[7,3,8,4,0,5,1,6,2],[3,8,4,0,5,1,6,2,7],[8,4,0,5,1,6,2,7,3],[4,0,5,1,6,2,7,3,8]],"priority":369,"rule_id":"false.finmodel.setcheck.structured.affine_mod9_a5_b5_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod9_a5_b5_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WEuO2zAMlQQOoM5KBXoALmaRY3CALrKcIzEFCswyR8hRG9tqElukZFmytUgQUzFF6j3+/hoy5rcZF4yfJP5AP/yg4fEkYWeWC6ev4BOJNcqKWyF5WVRswl3TXOK0dwVNwJogmiIs/KFJPjVjvPYPCqRI3GgM6abQw6lLU9zSqdEUeDfmC4VbgfSQ9kVOomNokHqDId4RRu8Dv5wHphPHN5wEZwquOUm3ocKkAjgsXISzElZ5vTb1YKOrK469Zuk0GkQo4Jt0J2FJGzxN9ILRISFfkHC8jqEZl59M/xV0o11/bforKSvdtKhG2ozPs8vx8Pvc1zo1wpJxaALkYu1WskmWgRp8Ny+wsBqwge/chIb74+nAQVMEM5uCACq/jWyUHvg2P5nrSDZMDZyHTsJdydZ7+Sf8ylHr0qrNLvJ4NmqFRg7goY6EI5XxoaaFQ7U50PQNRP7VPbM5nXOLyPHeiWwHLWv84K2LO0JZJBt+pejZodgCr9Ht8j8EYzdGMqgFVfhp+LuvadcJ/u4gso2gpHVlpFRZYrEefW1Nc1Xivd56Jb71jYnw7I4k22fvvixPNjww5YCWcvaoVJiNG9s+Z2zYvRwKMFb5d6jBAWXXHy3X7FGp0MQxTMkG5jlGyWT4Kjz7Kbc9Ggie1c48u8h2T1uhytdwCe1kUwckSVLnTmQrVtB96jIutCy4buJQWUaCAnjoGlpc1sfzISFj49yCsj5eDAnvAaeN8T6PnllDTLYVKapfmGTRWwNS9Em423DRmwcktENzzvX32dAvBLWLstUXvYZstZkNm8lGqYHS6J8kXRXZPr7ShvQ+vbgb0mdcSbZbWmkLo3+6JWRjCHCN9WjcftXJj08XUSpC6WSu3AEWMptLN6UhCgtkcyWO8MtOqzYh81hQ5K8vZbYUazYof7BFIISC8e7NmNNs001q0JzQgaP5eHR/4/4PRoYc2bxQcAiwER496FpDthRrAmyER1BVHP0DEXRBng=='
_TARGET_BITS_PAYLOAD = 'eNq9WEuO2zAMPWqOkOUABRoeaZZZFBgeI4tZ8AAFqtVUwBCSGttqElukZFmytUgQUzFF6j3+fgQM4VcYF4+fKP4gO/zA4fEkAReWi6YvYxOJD8qKWzl5WVQczF3TXOK0dxlNAJogmiIs+qtJPjRjrPYPNKhI3GgM6qbgw6lLU9zSqdEU/grhnYRb4fSQ/kWOomNwkNpAJt4RRe8zvJyHpxPHN9wEZwquuUm3ocKkAjggXITzElZhvTb1YKOrK469Zuk0GkQk4Bt1J1FJGz9NtILRJiGfkXC8jqEZl99C/2V0o11/bforMSvdtLBG2ozPq8vx8O3a1zo1wmJwFAznYu1WskmWsRp8Ny/2vBqwBu7c5Ib7g+nARlPEM5uMACq7jWyYHvg0P5nrSDZKDZyHTqRdydZ72Sf8ylHr0qrNL/J4NmqZRg7QoY7kI5XBoaaZQ7U51vQNRP7dPbM5nXOLyPHViWwHLR/s4K2LO0JZJBu9p+jZodhiq9Ht8j8EUzdGAqsFlfkT4K2vaecJ/u4gso2gxHVlpFRZUrEefW1Nc1Xivd56Jb63jYnw6o4k20fvvixPNjow5bCWcvaoVACCG9s+F7zZvRwyPFb5d6jxAWXXTy3X7FGp4MQxSsnG4TlGyWT4KjzbKbc9GgiY1c4wu8h2T3uhytdwye1kUwckSVKHTmQrVtB96jIotCy0buJQWUayAnjuGlpc1sfzISFQ49wCsz5eDAnvAaeN8TaPnllDjL4VKapfAGXRdwNS9Em423DRmwckuENzDvX32dAvGLWL8tUXvYZstZmNmsmGqYHS6B8lXRXZPr7Sm/Q+rbib02dQSbZTWmkLo388JWQDNnyO9WjcftbJT08XYSoi6WSu3AEWMptLN6UhigpkcyWOwMtOrzYh81hQ5K8tZbYUa94of/BFIJiC8e47hNts00lq0JzQgVP4fHR/4/5PIOAc2axQcAiwER496FpDthRrAmyER1xVHP0DOwwvmA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod9_a5_b5_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
