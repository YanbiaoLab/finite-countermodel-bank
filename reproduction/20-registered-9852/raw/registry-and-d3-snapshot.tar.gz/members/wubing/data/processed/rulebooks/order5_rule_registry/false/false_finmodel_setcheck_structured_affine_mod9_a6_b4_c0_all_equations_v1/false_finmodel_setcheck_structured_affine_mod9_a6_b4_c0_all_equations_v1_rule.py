from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin9_structured_affine_mod9_a6_b4_c0","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin9_structured_affine_mod9_a6_b4_c0","model_table":[[0,4,8,3,7,2,6,1,5],[6,1,5,0,4,8,3,7,2],[3,7,2,6,1,5,0,4,8],[0,4,8,3,7,2,6,1,5],[6,1,5,0,4,8,3,7,2],[3,7,2,6,1,5,0,4,8],[0,4,8,3,7,2,6,1,5],[6,1,5,0,4,8,3,7,2],[3,7,2,6,1,5,0,4,8]],"priority":361,"rule_id":"false.finmodel.setcheck.structured.affine_mod9_a6_b4_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod9_a6_b4_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWUty5CAMFRQLlhyBuYknJyNVPfcefgYBT26ciatmERbpNFgt9PSX/9Bh6SAiQ/SitA7y6eNF2vp46APpeOhdPLEHKZOeTARk42d+9Fze9P+1PdiJCnWXKm0izh/KOP5gW5UxWHHTU7kjBbZJrjwef3GiCO2+8ZROWspCtxu10ypKvJYqECSZLTny+cFf8VrxWz8NiUyforBTKmQNw3ZKlYw+8mXZaSVLVPkuiaFWXBRXJdIus6dJFDLxbziykGYQBbAvogD2xMDVUbDCwAWadBLNIrFyGf/fxYgymRk1t4hB1nA1fGFZxdSrZ41HgS03P+NJsLO9JdovN6gTb3cCoL4mYVXY3kpayQBUpeq73F6THV2tzChe7jTt24iGglwBzw92tmU2nUhv8BYDwqbZsP3sG+aSm+6mYHho2jQbTuEGSkbBbjQyciNqlY/ioJm3PI4VZh6lQWh7ZIkR9oklB/on1osx8i3e2meYBccYmRYh1DPcHDPqz9nnmZVZgrXD5AHtq6D2D6bBwB1TCp0RdvVOgKx3jdyfVRuOSzNWD7KzYS+zE3zvSqInzKY4GwTs+83GFxz0IL3vkcowMIDZDKiooQ6ZkmJ1tobadI21sgRmcy8SyJnNDPo9ulAAgFUcB9zsstRdtIkAuKdSMbO5MbmJRfZegnuX2YCzDfd6z2NVpp0Y6TWLqsWxN3lYoYzcRy3c4KFWZ3P3UHP7PPx+ZkPdDWiemrN1wmakpSEqhwUXMbOBLgekdsijHJ9JJx9WXHRnFFrt4wn2egAAyKM3el0uR5c9IUANAIB4NCi4XJquWlOEGgAA8WhQTMq76JD3zAbx6AY0Ku+qUd8zG8SjG9CovIsyctNsLh1hVN6Ps/042//mbKqnD2fXeuUYM4gqAyBY2vCvh9SzSXNGsJUKf2mUuDdh4eWaGrLfuvV5DoDs1wrm6my4+reliykK8dD/bvZsxdmkdimNzdro49+7f3Fwm+3Wu+VpN1dQ6rSM99o8bB2PLeaR+sWpTE4jrQn36odqr1YWy0gwj80jrdz8djnaNOto1VY3ID37gVhGZkYZNXMCnBllZ7vk0UaVx1y3ypntiaglZrYnopac2Z4oEcTM9kiJIGa2J0qE+v4o29roKM6uURyNdU+DPcGKnNyb0T8Y66bIP0U0sNVm11sdfnE20Pshz1q3uhzA28Oc9OTR/xqQkSV91+g/McpztfLDgeS3RDdH/yCwp8gf0ADHiW17i7BeuEgdkIDAnl6YAJDB24BpLHjxgqUMSEBgBwEZvg1gcrQHmQcMdlLLSBCi8puZZPBVRxZudTmaI/BDFkiOPo0EtpZ+NRclLVWiLcCDH7JAksD4CyHSBKY='
_TARGET_BITS_PAYLOAD = 'eNrtWUty5CAMvfd0VThZxjcZjsCSBQUafgYBT26ciatmERbpNFgt9PSXf9Fh6SAiR/SitA7S6eNF3up4qBX5eKhNPLEHBZeeTARk42d+9Fza9f+9PdhJUHWXKm0izh/BGf5gW5UxWHFTU7kjKbZJpjwef3GiUO2+8ZROWspCtxu10ypKvFYoECSZLRnS+cE/8VrxWz9VicyforBTKmQNw3ZKlYw+82XZaSVLVPkuiaEPXBRTJfIms6dJFHLxrzqykG4QBbAvogD2xMD1UbDCwCiadBLNIrEyGf/fxYgymRs1t4hB1nE1fGHZwNTrZ41HgS03P6dJsLO9JdovN6gTb3MCEL4mYVXY3kpayQBUpfq73F6THV2tzChe7jTt24iqglwBTw92tmU2nchv8BYDwqbZsP3sG+6Sm++m4Hho2jQbTmEGSkbBbjQyMiNqlU/goLm3PI4VZh6lQWh7ZIkR9oklB/on1osx0i3e2meYKcMYuRYhwjPcDDPqj9nnmZVZgrXD5AHtq6D2T6ZBxR1TCp0R9vBOgKx3j9yfVRuGSzNWD7KzYS+zE3zvSqInzKY4GwTs+81GFxz8IL3ukcoxMIDZDKiEoQ6ZkmJ1tobadI21sgRmcy8SyJnNDfo9ulAAgFUcA9zsstRdtIkAuKdSMbOZMbmJRfZegnuX2YCzDfd6z2NVpp0Y+TWLhsWxN3lYoYzcR03d4BFWZzP3UDP7PPR+ZkPdDWiemrN1wmakpSEqhwUXMbOBLgekdsijHJ9JJx9WXHxnpFrtown2egAAyKM3el0uQ5c9IUANAIB4NCi4XJ6uWlOEGgAA8WhQTMq76JD3zAbx6AY0Ku+qUd8zG8SjG9CovIsyctNsLh1hVN6Ps/042//mbKGnD2PXeuUYM0goAyBY2vCvh9SzSXNGsJUKf2mUuDdh4eVaGLLfuvVxDoDs1wrm6my4+reliykK0dD/bvZsxdmkdimNzdro49+7f3Fwm+1Wm+VpM1dQ4bSM99o8bB2PLeaR+sWpTE4jrQn36odhr1YWy0gwj80jrdz8djnaNOto1VY3ID/7gVhGZkYZNXcCnBllZ7vk0UaVx1y3ypntiaglZrYnopac2Z4oEcTM9kiJIGa2J0qE+v4o29roKMauURyNdU+DPcGKnMyb0T8Y66bIP0U0sNVm11sdfnE20Pshz1q3uhzA29Wc9OTR/xqQkSV91+g/McpztfLDiuS3RDdH/yCwp8iv0ADHiG17i7BauEgdkIDAnl6YAJDB24BpLHjxgqUMSEBgBwEZvg1gcrQHmQcMdlLLSBCi8puZZPBVRxZudTmaI/BDFkiOPo0EtpZ+NRclLVWiLcCDH7JAksD4CyqubJA='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod9_a6_b4_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
