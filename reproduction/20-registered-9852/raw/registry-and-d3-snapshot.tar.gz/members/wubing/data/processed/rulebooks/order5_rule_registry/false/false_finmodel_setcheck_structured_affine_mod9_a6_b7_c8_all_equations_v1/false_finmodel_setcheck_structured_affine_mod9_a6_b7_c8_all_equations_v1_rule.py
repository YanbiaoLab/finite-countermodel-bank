from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin9_structured_affine_mod9_a6_b7_c8","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin9_structured_affine_mod9_a6_b7_c8","model_table":[[8,6,4,2,0,7,5,3,1],[5,3,1,8,6,4,2,0,7],[2,0,7,5,3,1,8,6,4],[8,6,4,2,0,7,5,3,1],[5,3,1,8,6,4,2,0,7],[2,0,7,5,3,1,8,6,4],[8,6,4,2,0,7,5,3,1],[5,3,1,8,6,4,2,0,7],[2,0,7,5,3,1,8,6,4]],"priority":365,"rule_id":"false.finmodel.setcheck.structured.affine_mod9_a6_b7_c8.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod9_a6_b7_c8.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmUEKxCAMRZOShUuPkKN4NBc9+MTY2gjClKEwM/AfLdVEW9D61cj0HCpXeksleLgeVru7PX38FXuH+mXUYAQPU9+2rJC23sxeitFi/8huQ1Vv/xFbplyst8UGcKaC5vsSpQugnMM0R9eQ13NIjrKXYIYa21Qz1AAAAHBvsZRO3dW4gpJJbsuluClqLU/LKlrI9DoPAAAAAAAAAI+hkovtTlqQ0J497qe+jVmYWCxVR3xQfQvEnj/KVN/+dHevQt2JYCIAAPwUiZv+L4TdT3hN/of489I0DoqOiSDR5AyzQAuHvQCyAhN5'
_TARGET_BITS_PAYLOAD = 'eNrtmUEKxCAMRQ8+C4/mUXIEly5Ck4mxtRGElqEwM/AfLdVEW9D61Sj6HMRneqs5eCTtVru7vX78FXsH+WWkYAQPky5blpVabxYvJWixf+RlQ5Vu/xFb0ZKtt9kGcNGM5vsSuQsgH8O0RNeQ12NIjrKnYIYa21Qz1AAAAHBvsVQP3aW4guJJbvOpuDVqrUzLKl3I9DoPAAAAAAAAAI9BXLLtTlqQ0J497ke+jVmYhC2VRnyQfAsknt/LJN/+dHevot2JYCIAAPwUVZr+L4TdT3hN/of4y9I0Dor2iaDq5AyzQAuHvQGab129'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod9_a6_b7_c8_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
