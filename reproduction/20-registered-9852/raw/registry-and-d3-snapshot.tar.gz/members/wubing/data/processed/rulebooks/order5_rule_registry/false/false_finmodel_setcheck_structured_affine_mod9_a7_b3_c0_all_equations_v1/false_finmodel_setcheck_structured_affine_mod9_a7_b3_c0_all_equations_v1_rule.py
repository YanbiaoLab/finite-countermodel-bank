from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin9_structured_affine_mod9_a7_b3_c0","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin9_structured_affine_mod9_a7_b3_c0","model_table":[[0,3,6,0,3,6,0,3,6],[7,1,4,7,1,4,7,1,4],[5,8,2,5,8,2,5,8,2],[3,6,0,3,6,0,3,6,0],[1,4,7,1,4,7,1,4,7],[8,2,5,8,2,5,8,2,5],[6,0,3,6,0,3,6,0,3],[4,7,1,4,7,1,4,7,1],[2,5,8,2,5,8,2,5,8]],"priority":362,"rule_id":"false.finmodel.setcheck.structured.affine_mod9_a7_b3_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod9_a7_b3_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWT1u2zAUfqLkWAECRwk8dChqQWABHyFDkRCFBqtTjtAjuFuGAGaHos7mGjmAjyKgQM+h3sCjByEOf5zIEUkhLkiiQ95A2STFT89+3/vTj4AAlH3gcivGUowwFCOh4nICU/4FSMAu9TYArVTbU/0CbGeGhc021C+U25HhlkvDPKwNjwX0m+mWEwakvWuFTYd9PDYsjAFS7RqJAcVEt4KiZNypSt3+QeluopppVOEy6CuqyAsuUHslEDMr9dHYA7PxCCCChH+L+GTv6SzcbEybs9g/JiQEL7IRYDM/YCBVO/UDVkm0wA9aLcCu/IBRqVrfD9paonmykQcBNvID9ka2N7L9b2TzBLQjm0ew0heru1MiN2SbeQSrwvWVP7RbePBnknTfX9Wundd+qkudO68/Qf/92hvZLioafvCF9q6xEBoOXCsZUkntATzVHTfuwL7uAQ2cE+EeLydZhjyRbZmfF3nuyUaumWZ389gT2pfzAp+decpHSJHd4SzzpNq4aApH97B7hTr+leeRU7AVLASAGJdCQ4dkGDZAC3zsmmwJgSACCigB9hFBBDEkQNygJShOKUgg3jWhvLWAwBH7PjdA4xWNHJONpkyPmPAmSszba4g49Jdx8gy0Is6p3Z1GWi6Mq87isLJcGNed+VVttzCmncUhtVwYd9dsa8uF8WVHgQW2c/XSfNxmJAAdpZEtGVyUIctorSrHjHuqV/ovGyyneuZOOE/4bKcP99jkPHnCZzmOU7SL1YpMlizgYduRTYRQjfSGCx6HrOZ8xlcLIhiwR6FgLwLtyKYrezeq39dtO8TRbMxlr+r3dduqQzpw8sSpgWytg9VtVfDpoDRSMktDNpWGhbKNzueH1CmR2EtYMtcyS/JdbzYvZQHJPzRI1DdX4KApZHyBBi6aQkfy8lO1vt8aI9Xh38CrwzoJnl1USzSv+GCiIXiev752juV/3EOq81RVQz1lCtP0gLz6EZbcB/I='
_TARGET_BITS_PAYLOAD = 'eNrtWT1u2zAUdqDBo29QnaNAAR3FBwhcb3GQoTSQIVt9hB6hU+VBKJigQ45goIQgFx06GIliBIgcS9QLf5zIFUkhLkiiQ95A2STFT89+3/vTWY0Bog1wORdjJEZYiREjcbmHGf8CuGaXoFeDVsLenX4BelPDQr9X6Rei3tJwy5VhHgaGxwL02XTLPQPS3jUkpsN+PhgWFgCZdg0XQAusW6FlvuhUJWj/oGg3EU41qnBZbxRV5IXEtL1Si5mh+mjsgdn4CFBCzr+VfHL7fBZpNmbNWewfE1KBF+kLsKkfMJCq3fkBCyVa7QctEGCXfsCQVG3jB20g0TzZyJEAW/oBeyPbG9n+N7J5AtqRzSNY5IvV3SmRG7JNPYKF1eDSH9o5HPkzSbTvrwLXzms/1UXOndf7evN74I1s1yGqfvlC+9NYCKrWrpWskKT2Gp7rjgt3YF/2gNbOiXBMRvM0pZ7INkpu4iTxZCNfmWYnk8IT2rebmNzeespHcJyekDT1pNoibgpH97B7hTr5mCSlU7AhjAWAGEdCQ4dkWDVAY/Lgmmw5hroEBDQH9pFCCQXkgN2g5bTIEEgg3jVBvLVAwRH7vjdAiyEqHZMNZUyPAvMmSsHbaxQ79JdF/gI0xM6p3Z1GWi6Mw87iMLRcGAed+VVgtzBGncUhslwYd9dsA8uF8VVHgQW2c/XIfFx/KQAdpZEtWV9HFctorSrHjHumV/odGyyneuZOOE/4bKcPx8TkPHnCZzmOI7qL1YrMRyzgEduRTYRQjWxXYx6HrOZ8xlcLIhiwR0FgLwLtyKYre/uq39dtO8TR9M1lr+r3ddvCQzpw8sSZgWytg9VtYf3joDRSMktDNpWGsbINTSaH1Cml2ItZMtcyS/xJbzZ/yxjyf2iQqG+uwEFTyPgCDVw0hR7l5VS1vg8aI9XhX8CrwzquX1xUSzSv+GCuIXiSvL52LuR/vKWq81RVo1tliqDsgLz6CbWVaUQ='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod9_a7_b3_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
