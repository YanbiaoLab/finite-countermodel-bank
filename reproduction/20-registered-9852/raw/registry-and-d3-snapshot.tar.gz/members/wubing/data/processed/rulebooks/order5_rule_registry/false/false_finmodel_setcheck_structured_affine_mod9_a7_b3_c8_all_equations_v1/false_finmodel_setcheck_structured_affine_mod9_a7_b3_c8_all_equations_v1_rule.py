from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin9_structured_affine_mod9_a7_b3_c8","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin9_structured_affine_mod9_a7_b3_c8","model_table":[[8,2,5,8,2,5,8,2,5],[6,0,3,6,0,3,6,0,3],[4,7,1,4,7,1,4,7,1],[2,5,8,2,5,8,2,5,8],[0,3,6,0,3,6,0,3,6],[7,1,4,7,1,4,7,1,4],[5,8,2,5,8,2,5,8,2],[3,6,0,3,6,0,3,6,0],[1,4,7,1,4,7,1,4,7]],"priority":364,"rule_id":"false.finmodel.setcheck.structured.affine_mod9_a7_b3_c8.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod9_a7_b3_c8.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2EEKwjAQQNHppNi4qV26s4jeo4seymWOoJ7Ao/RIXboQaoxQxUpAMSv/gyahCQzMQJg2E+CFFfXjTCSXKnqwHlcZWQMAAEiof2q33EDv9bVl8cijKfvE0YwzYS7904Wq7SgBkMJ2Pi43h7bNkwY7yT4ECOMxfBqvlRp8rlJbOz81oqK2EXf7taBiyQzw6zZyKKK7Hr0lgKjufo1cFtOt82ry6t0xLhrg710B2iIY6Q=='
_TARGET_BITS_PAYLOAD = 'eNrt2EEKwjAQQNGCC5c9Uo/iCdQjZOmhuug9FKk7l7UbU2mmY4xQxUpAMSv/gyahCQzMQJh2UOCFVfHjRbXXJnqwHlcDWQMAAEgof2q3TEbv9bVj98ija/PE0ZxxYW79U4SqbSgBkML2PC53q7LskwZb6DoECOMyfBrvhRp8rhFbGz9VKiq2UnP7tSBqyQzw6zYy66K7Hr0lgKjifo3MTtOt+WHy6t0xLhrg710Bck9YTQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod9_a7_b3_c8_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
