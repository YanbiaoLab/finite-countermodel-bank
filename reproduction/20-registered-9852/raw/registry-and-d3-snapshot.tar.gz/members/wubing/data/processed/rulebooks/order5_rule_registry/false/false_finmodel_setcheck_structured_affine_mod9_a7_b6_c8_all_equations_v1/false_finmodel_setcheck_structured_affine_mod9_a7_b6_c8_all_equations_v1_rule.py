from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin9_structured_affine_mod9_a7_b6_c8","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin9_structured_affine_mod9_a7_b6_c8","model_table":[[8,5,2,8,5,2,8,5,2],[6,3,0,6,3,0,6,3,0],[4,1,7,4,1,7,4,1,7],[2,8,5,2,8,5,2,8,5],[0,6,3,0,6,3,0,6,3],[7,4,1,7,4,1,7,4,1],[5,2,8,5,2,8,5,2,8],[3,0,6,3,0,6,3,0,6],[1,7,4,1,7,4,1,7,4]],"priority":366,"rule_id":"false.finmodel.setcheck.structured.affine_mod9_a7_b6_c8.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod9_a7_b6_c8.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2DEKwyAUxvFPkcRCIN6gIXToMVx7q6y5VY7UMUMgdWoDTZ26iP/fIOoTkTcoT6OaddJi/rTXXRouZ4HoZX0sKS3pwKltJKeQXTi8e0YAAAB1mfrDYOtJCAAcK+THp3Ccb+NIRop42UKUcZpkg1LXyskrKJIZoGjPvc1GE/71AGQt7c+yd71+TZ0t46IBqvcCX5UT/g=='
_TARGET_BITS_PAYLOAD = 'eNrt2DEKwyAUxvFCho45Um7VNbfq6jE6lJDcwEChJoh+cWoDSZ26iP/fIOoTkTcoz6iavaQu/mmvhzS+zwLGKThTUlrSgVO7Sl42u3D89KIAAADq0s+7QTOTEADYV8j3b+F4ew4DGSniZbNG0atXsErdIC8nK0NmgKK1lyUbTfjXA5DVLT/L3ut0mDpbxkUDVG8D7NxdOA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod9_a7_b6_c8_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
