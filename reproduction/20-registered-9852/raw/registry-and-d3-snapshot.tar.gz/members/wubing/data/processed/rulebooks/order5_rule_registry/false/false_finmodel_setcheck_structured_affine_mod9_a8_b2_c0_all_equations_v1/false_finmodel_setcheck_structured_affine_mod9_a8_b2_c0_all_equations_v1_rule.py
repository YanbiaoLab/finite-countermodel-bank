from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin9_structured_affine_mod9_a8_b2_c0","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin9_structured_affine_mod9_a8_b2_c0","model_table":[[0,2,4,6,8,1,3,5,7],[8,1,3,5,7,0,2,4,6],[7,0,2,4,6,8,1,3,5],[6,8,1,3,5,7,0,2,4],[5,7,0,2,4,6,8,1,3],[4,6,8,1,3,5,7,0,2],[3,5,7,0,2,4,6,8,1],[2,4,6,8,1,3,5,7,0],[1,3,5,7,0,2,4,6,8]],"priority":373,"rule_id":"false.finmodel.setcheck.structured.affine_mod9_a8_b2_c0.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.affine_mod9_a8_b2_c0.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq1WUuO5CAMNZYXnh3dmgOgVh8EjXrRx2JGM1Iv+8iTAEkosPMpiBdVSigw/rxnQ/0Dj+Ahynv89CF+EceHX+kB3PyAPj1EwTgOhTgTv+w2vIjBdQ6V74EtrEuGciArFgSjVt8OfE87eJNmBAdowQgjxJZFJQ6KnT6aYozLJkJlig/iWrPbSBx5RfwgJwws65f+Tqbkh9bQFC8gbEzx5XgpP0wa/wCEHfmENUbVXheXhiIVHNR7nlxTBTf/rNFqyiX2pdhUvbYcUYYOUfPXK3tlOloSvTaSAybAyLq9Cc/Ju7pTo7y3zysLabqVAVdZK7zyJ7Z3ghByELHI3vCw/jPJ8gdYwbnflg6FC21DoOdloprf2tCFtyeFa6zvQTt0g01jWL96jR+TUWKBkzJhx+Alwgg9YAPaCYQbpyjO/xvgxaihoGGobudz/RCaGt6Xkq+l5pfah1ZIfT5JTzLYtl+4MkwkR/HYsp3ywLbwKT38EmWOPlEvVbL8sY3QF/tRjKEmuFljYUstKHiFtPbvPNjWyKc6EC6H/mpli7EwR/CgXkculc2pFW6kYFkBzIO/UDTGXk7DIu1sXDt1vi6Hm0eFqQEbOjA2KfK3O3KqNLNr5spt+W5lzofZImdnZ9qcnHSXNlIxGmQu+dkDtvDQR7sq9QTXIp4hJ72yGagy0Sk8uV/Z3CmwbRXElN71ckfE13Vs8/0WnrXp4r02cEQb6Zocwef9ddRGmjZH7gHbesiOH7a7odoDG89HvjDbxpPvMPr2LkLJVw5WCIiDzhKtVjaOWUnny8azbSS6RVFqIz3cxpHzlZbJTjNvaIe03foFCbN9CdkyBBNuqJ51YQ+aSb5Nm44k0e8Z0y6+2sqEp44tCthW9rJS3TNNevrnGv/kQbNzZKlOH93U+W33Oa25GOxqkdSL2+gVN5b+PdZ5sMoX39VGKvGejlU4FGxI8nqx4TM++jgMohYH2k04thHqpk4iCmKK+AkNNJgtJ7ARq2fwBWxhULZ8g1UKWcycCWyJSMfYqP61kFC9cOeYvPTFFzU9X5B+Tce8qCXT51ZywmGHKpIAXwKbwkTC1b/w6hoMl5v8do5w9W96g/dOu9dKR8XgmiuDThu20Yj9YEvyQccVPyOvp7Ll/xOMSMi1wyTUXTiZ59tItmr2lIH0Apv6C3X8MwV47Vf3YuTeqHlLl6rCf8msWZA='
_TARGET_BITS_PAYLOAD = 'eNq1WUuO5CAMPXIvW5rRDMfqRWvEQVotDjDqZjdeWMaTAEkosPMpiBdVSigw/rxnQ/1gS2w5ykf8tCZ+IcSHP+mB3fxANj1EoTjOhbgQv/w2vEigdQ6W7xk8r0uaciArFoSiVtsOvEw7+JRmGMfkOQgjCB5EJY6LnT6aEoLLJnJlijXiWrPbUBz5InpHJwws65f+Tqbkh9bQFC9Gakyx5Xgp/0Iaf2fiHXnjNUbVXheXmiIVHNd7nlxTBTf/rNEayiX2pdhUvbYcUeAOUfPXKnsFPFqSrDaSAybAyLu9Cc/Jh7rToLz3zyszabqXAVdZK7yyJ7Z3ghByEKnIXvOw/jPJ8otBwbndljaFC31DoOdloprf2tCFtycFaqzvQdt0g01jWLt6DR6TUWKBkzJhJ9AlwjA9YGPcCYQbpyjO/2n4O6ihwGGobudD/WCaGt6Xkl+l5u/ah15IfThJTzLYtl+4MkwoR/HYsp3yAL7wKT78kmSOPlEvVbL8t43gK9hRjKEmeFhj4UstJHgFtfbvPNjWyKc6YC6H/mpli7EIR/DAXkculc2pFW6kUFkBwoO/SDTGX07DIu18XDt1vi6HG0aFqQEbOQ4+KbK3O3KqNLNr5srt4W5lzprZIudnZ/qcnHiXNlQxamQu+dsDNvPQR7sq9QTXEp0hJ72yBa4y0Sk8uV/Z3CmwbRUklN61ckcE13Vs8+0WnrXpgr02cEQb6Zocoef9ddRGhjZH7gHbesiOH767odoDG8xHPjPbBpPvKPr2LkLJVw5eCIjjzhKtVjaIWYnny8azbSS5RVFqIy3fxpHzlVbITguf5Ie03foFCYD/Ntky4mBuqJ51YTeaSbZNm44k0e8Z0y5e28pEp44tCthW9vJS3QtNetrnGv/kwbBzZKlOH93U+eL3Oa25GOxqkdSL2+gVN5b+LdV5sMor3NVGKvGejlU0FGyE8nqx4Qs2+tgMohbH2k04tRHqpk5ENGKK2AkNOJgtJ7AhqGfwBWxmULa8sFcKWcycCWyJSMfYqP61kFC9cOeYvLTFFzY9n5F+jce8qCXT21ZyzGGHKpIAXAKbwkTC1b/w6hoMl5v8do5w9R96g/eBu9dKR8XgmiuNThu+0Uj9YEvyjscVPyOvp7Ll/xOCSMi1wyTUXTiZ59tI8Gr2lIG0ApvaC3X8LQV47Vf3YuQ+sXmLl6rCf4LFF6Y='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_affine_mod9_a8_b2_c0_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
