from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,2,1],[0,0,1],[0,2,0]],"priority":391,"rule_id":"false.finmodel.setcheck.structured.all4x4.refutation171.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.all4x4.refutation171.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWEFrE0EUfjOMMKmX2RCh6mWyWUJUPLT6AybLNiTQQ9Paolexh0r14h/YlhXWEiFWA6UitKXgwSK4+AtKLtWLePQ/+B98M9lUD9vaQCIJzscShs2bHd7M9+a99xEACKGHiMEZOIxhNKhwbwNUxh+Kyw2gA31L5HFOzxcZMkphcvEt2V1PnCXgF59y+GJ2q9ISQ1l+r3/cCz47z87Dk/PMaJI328LC4txbusHaSoXedhy3FXWICwHEXFA++a7tyTajQLbrVKo8BxbH4IAE/YwAEVAuMd/lGHCJqYrgxclgRNsY5hUQBnUXF2owAZIqMGtajHWwmZIo9ARwQ03XxSzLIZMlEolEjTmGo8nCgybiIlZKHAQyBfKamiplZRYYmvXMhSZxOOYbGTFal1IHGzOFIQEXcAgsozoUihKizX+/QjeJnv7HK/Sahfih0LLUwsLCwsLC4r/H7Q8n5eszneWVmU757Xr33tVPsw9Xu1vF1iiEoT3vVZB3HPwNIt2TCqfo+kEkfFMiK8oVG+Jqn38mX25+/P7o9budH0+TO89K72vzL3euHd9omCpRpi0VsyT4CxYDZ67gVw5in88Vmnxf+MXI55eqgpl6OkO6PLMxPmWVGg/X6o7xKHanioVmoN16LnDIqmIUqz1J4vLl4ptlXCjZPWrd11u52t2UfPJVWGxnuek0T0857TN1g4rBBn3NRHdjYWp5Tstq8S+gvj5OTmrzF1OWHqxeWVrT5h3nVmmldjR9XBln39YOWu5UKeN2R0byvk6YanjB3WZuX5sXFivdBb4vpzctOSyGHGxVo/pxmQuBeERLcYHOoGFmotS6NjSAcRAOkYPr2px4ApMs9/CKJczIfhyHGA9YZkGqJss0D9Oc6oVFT2weXGr+BQpff0I='
_TARGET_BITS_PAYLOAD = 'eNrtWEFrE0EU/g/+B4/iRXsJ/QWygtSDUNqCWArRWjDUBUO7f8CLFnuIeFVa2/RQSEiXzfwAbQ+ihrDZnYtaMGTnYjPgMPN8M9lWD9vYQCIJzscShs2bHd7M9+a99ykA8KCHooBzMOvCaNDg4TqQjD8Ip+sgB/oW6+Ccni/UE1LC5OKqs7jhJDvALz5l9vHhaqPAhrL8wulx7wWin12IJxea0SRvtoWFRd9buiJWCPHCZdddITJREfjgcib55Lu2QFeEBLVclZR0OAjXhQQo6GcEKILkFPNdVwCnmKoUXpwCRrSNXoeAElCNcKGKYEAlAbOmxVgHmymJvJABN9SMIsyyHDJZQpFI0phjOJosPGgijrFS4sCQKdDR1CQpK7Mg0KxnzjSJvTHfyKKQVUp1sAlTGCqIAIcgMqpDRqRS2vz3K3RT6el/vEKvhYcf8ixLLSwsLCwsLP57fLg91fxylN/eOso3723k3n67efiqlFuNC6MQhhbCh34nSfDXL+qelCVxFPhFFpgSmUhOxBBXu3HJuf7p1pWXD+4uXX7mvH/aulPbf7T0dfpzxVSJNG2phCXBX7DrJwftoDHnBvygXebzLIiLAf9ZZ8LU0xnS5bmN8RmryHi4Vk2MR250ErfLvnbrCcOhqLNRrPbccZs/4vvbuJCzOFN4o7eylFujfPJVWGxnuek0z0457TN1g4rBBqeaie7GvNSyT8tq8S9Arr1wpmr7F1OWXpe+72xq83zysbVVmzmeboyzb5tzheiklXG7IyP5qU6Yanj+u3J3Xpu3dxu5PT5Pj9csOSyGHGx1o/px2vVAhUpLcb7OoF5motS6NlRAcGCJooPr2lyFDJMsD/GKVcLIfhyHGA9YZkGqJtM0D8su6YVFT2weXGr+BUIh8eU='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_all4x4_refutation171_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
