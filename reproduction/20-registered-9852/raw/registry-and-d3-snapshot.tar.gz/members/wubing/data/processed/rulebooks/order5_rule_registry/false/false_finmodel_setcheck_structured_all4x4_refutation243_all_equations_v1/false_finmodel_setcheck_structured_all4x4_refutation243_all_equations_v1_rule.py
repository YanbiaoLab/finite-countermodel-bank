from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,1,2],[0,1,2],[1,0,0]],"priority":393,"rule_id":"false.finmodel.setcheck.structured.all4x4.refutation243.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.all4x4.refutation243.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWMuu4jAMdSwvzC7lC0LFh2RQF3xWkFh0ySfPsZPScm/nId3R6CLFAiqS+hEnsX0cKGfao7scM430RhTjcyWJhPgrstL5kXkIx2saM2uWWWmAN/REpxuxUiGO5A4SUooEzarnQrnQkTRCeWDKNmefXxFz8KfgU0wGJC1LSTb/iaOUOm8KXmfENdXpxQ/6+0WeXEMq9hsXkza6Pg589lL7durUqVOnTp2+SHpAHTFZPv+LMqUIs72OuiAG5OrI3YHPikii10JKohTKtmxBddgKrpdyLO9XM8GGrUbzR1kqo06dOq1w0bHSYZJrus00hJEn0ZOkm4wMNDWVOniPXKEVwFOeaEbcyhpmjQPYga+GkBjACYwj2XS6E1jooga+8Id+RCmPTEHIFR3O4ARHUcMzrkiOEOdiCiIAUCE7hit2k9lAUWw6aNUxmYABqiyEZnVwBGXJ3j66onCO0eOtEMTHRLFILPoAEsSyMoEfWtwBFObNOhjgbjaYNVngGMi4gLcSG4hkR2kwwFCYYPjCAXHLQZnA9Ga0UIWctpgVcsILSocEmXUw2ZBzOBqEGA9VoYn2gBc8lMUaxPK1KnpkA66qZpVLcGxbke/Ta5oopCDtjVUH1lGTz2TmjdRc4euCmkgLvqyZzbdn8ZpZnTXTQeqxCRiE4CQ7mQ2qRrMTOup+XzRncvsUfhDbPLrUJSb9v8c/pYdjfmSQlnBq1jCXUawJx7xm53GnRZD9FMDusGHcZJ3qvoryMVx7M+41z2x4ldurULR4zf3OMXOol23jK1jlOgZ8YULYZDZpmP/U0pz02PaPKHtPxzs9tjsan82V12Pz7K20LtZabTQOf/j198fSY0pr/6jTmxIymwXdPViQbsVjPW6uJ5J799b3wWwknlGZluar1Dvpd9f70twiuCVtWtqmXMNrovWW6+YO8wsI6aH4rSmyJqubJC6bvWz1WvC1os1Okn44Sc9S0KP8ilO3h4L/2PLv1KnTe5eRVwdhO/XATvG3M5S+8dp+Aqu8f5w='
_TARGET_BITS_PAYLOAD = 'eNrtWMuu4jAM/WSWXSCRz2JRMfkQVPIFNDu8sBzPsZPScm/nId3R6CLFAiqS+hEnsX1cNEbdoyPfo076RpTzcyVJWeUrstL1EGUu93OaolDkgXSGN+imt5MKaVDJ6g5iJc0KzUTXoDHoXSlDeRGNNmefX5FI8SfjE0wGJC1LSTb/iSOEOm8KXmfYNdXpxQ/0+0XeXEMK9psXkza6Pg589lL7durUqVOnTp2+SPRAHTFaPv+LMiWwiL2OuiAX5Oos3YHPioiz10KkTFrCtmxBddgKrpdyLO5XM8WGrUbzR1gqo06dOq1w0bHSY+RzOg06l0lGphunE08CNDWGOnjMUqEVwFMcdUDcilQGyjPYga/mkgTACYyT2nQ6Klj0Qga+8Ed/ZA6HqIXVFT2u4ARHIMMzrojvEOdiAiIAUKE4hgt2k8VAUW46dNUxmoAZqiyERnJwBGXJ3r67onLN2eMtK8TnpDlwDnQAEsSyooIfWtwBWobNOgTgbjCYNVrgmNW4gLeSGIgUR2kwwFAYY/giBXHLQRnD9GY0a4WctpgVcsILpI8EmXUw2ZBzOBqEGA9VpYn2gFc8lOUaxOK5KjpEA65EZpVLcGxbke/Ta5S0pMLtjVUH1lGTz2jmTdpc4euCmqwLvqyZzbdn8ZpZHSnqg+uxKRiE4MQ7mQ2qJrMTOup+XyhGdfsIfmDbPL3UJSb6v8c/pYNjfmSQlnBq1jCXaa4Jx7xm53GnRRD9FMDusmHcZJ3qvoryMVx7M+41z2x4VdqrULR4zf0uOUqpl23jK1jlOmZ8YULZZDZumP/W0hz32PaPKHpPxzs9tjuUn82V12Pz7K20LtZabTQOf/j198fSY0pr/6jTmxIymwXdPViQTsFjPW6uJ5Jj99b3wWzKnlFFl+Yr1zvpd9f70tIiuCVtXdqmUsNr0vWW0+YOywsI6aH4rSkLJaubOC+bvWz1WvC1os1OEn04Sc9S0KP8ilO3h0L+2PLv1KnTe5eRZwdhO/XATvG3M5S+8dp+AqC18Ys='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_all4x4_refutation243_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
