from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,1,1,3],[3,3,3,3],[1,0,3,3],[3,3,3,3]],"priority":388,"rule_id":"false.finmodel.setcheck.structured.all4x4.refutation372.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.all4x4.refutation372.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmc9r02AYx980gQSFJYUedpCkaUHiyR0n1KWLzoqHbepVRv+EIR6cuiXrD1cqst52sbB1E4969CCY0svEy+ZpJ8lghyo7pFAklDSPSTbcYQ22wuthvJ9DCLxP8vDkeb7PG96HQggZ6G/sVIKraVKI8D+opapKQ9Bi5xaMToufNNUBj7j1qZ56HD+/kP9hZ2ez/IBHIGTAymbl9GZeYxAan/yzsIjG0Jl91hIMKi+QdBEIBAKBQCAQCAQCgUAgXHyuNV6nLsmJ/TtyKVVVSvPc1sQtuVRIcjEMzvKu3eKBX3EOoRmchjk6AuRRDtA4QnPrHqjH+wAbmV4bPuSul73g1KywzGFwZrxt0Teomx/vsgWWP2K6low+GbUc2uRxhGZDBDoObx4s9aW5Nnxd4PqBk1ou/d4DthNnMDgzAQyQRHeddounx5yiCbrdZHGE5sRnujq3BelAAyCXNK4s9EBiprEcjkZlDVgsYltcHbvKi7vyzxOxpdAcalP5Iyxie+FXiRQkz3+7pZ9UDZ64ArFFfkj6AogtAhyNJFtVGhWNG246FJ9JaKF5WfDVoilcITmat3HVNWh3uBRZhiSKgXlxjbX9FoBsdcTY9HfrHv98uBblfn74ZTsw7z5Qvu8BJA/WRhRb5KxmQPW+epJ8GpqLMfMyt8Sg3qg7W1gQ6r9W72iqNBL3b8fLQjjXCksg+EkQtGmBwTFUnFhxKNZhWde2LfaKJWUyho5sX/FYJpjerNSXfrWhfk9c7uoH2xta56W/szWnsOxs3w5X3xjiox26WWQfx57ZAlrI7qbRHp6dLaqPqDi8/QYoEJOs'
_TARGET_BITS_PAYLOAD = 'eNrtmc9r02AYx580lCCF5jC0h8GCp53cLuIupRE8eNSjuHWDetmtQyyd/bFkU+dBZH9CGV7VbQexTrNmFtxxnixCmyZ42KHQZKAkkDSvSTbcYQ02wuthvJ9DCLxP8vDkeb7PG97HRQgJ6G/MFv0rz7uI8D/IdwqtrC4Nzi0IybRxwMtDHqFz+3F5rH9+oXaFbew0jCGPQMCQlYXi6c2WZCN0dPBnYQMdozP7BqcLbk0n6SIQCAQCgUAgEAgEAoFAuPh8yz7s/FJ6Ux+UcqfQKm+Z84eflHK1aw4wOKvRbNoAY5WZgIx/GsaICBDlMuDgCI3OUSCPTQEsNuMpuFP/WqL8U7PqmonBmXA/7XxxP99+b1UtY9xOcAq6JeTraMHAERoLIYg4vFGwHlO3U3B904z5TvL19l0KrGTfxuCMBxBA1eglh66cHnNqPIhsxsIRGtPfTYjmPLR9DYBSlsySHgfV3sNyOBqWNbCwiG1j5fi7oc0ol0/E1kHbKOXWxrGI7YlXJaqfPO/tnHhSNXji8sUW+iGdCyC2EHA0kkahlS1K5mjTof5uTwrMS7qnFqllVrvRvB3JtODQo6WIE1RN880ryxbrtQDEyhFjE+8tUcbT0VoUffP1jTnfPPGmdXUaoDu5HFFsobOaIdX76EX3eWCuDfif5rqN4lF3tqAg5H+t3miqFHpvP/ZLejDXCkrA/0nQpT3dxjFUPFxlXIuxLJplOesHpzabgohYT/FYJpjUjhpTL6Ug905bS4iTc4tS8rG3s2X2sexs1yZWHgjaq1knU7FeDp6xOtpszLTRNJ6dLayPyDi8/QYkcN17'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_all4x4_refutation372_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
