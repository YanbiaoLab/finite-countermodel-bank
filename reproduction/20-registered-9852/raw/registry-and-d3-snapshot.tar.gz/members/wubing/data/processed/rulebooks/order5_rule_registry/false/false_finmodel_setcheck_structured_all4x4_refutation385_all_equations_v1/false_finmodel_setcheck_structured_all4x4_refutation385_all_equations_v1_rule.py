from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[1,1,1,1],[2,2,2,2],[3,3,3,3]],"priority":390,"rule_id":"false.finmodel.setcheck.structured.all4x4.refutation385.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.all4x4.refutation385.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmTFuwzAMRammaDIEcMcMAdIj5ARpjtQDBIiOpqPoCB41GGYlmJPMEhEgdDD+G2RAnwxNmeIQOnqFI/3kNRDtCfwDo1ue01AJXjbis3Z5yJN3lRBlI11qF9kIXAsHesvrB9E7fRKd6Fw2y+LLb0V5OboXla5EX+TxzQAAAAAAAAAAAAA2DT9NNXPpFyzyYKqZXb9oEztTZTv3Njx/m2pm6Bdt5L2pZly/aDPbKpu5NxLMggsltY7/ZSez4FKJhsuGy7bZy7ZkNimntZ46qGYtuSf5PIrHuhQ1s9iS+/L+o+KxnsGoZlNDo5FZzax4KKemmPmWRvOQXqjVvlu3TK1oX280MrlS6kE7Nc1sbmg0MkDTPJRTU8xCS6O5/VUP2qlpZqmh0Wz5sv0C/USoXQ=='
_TARGET_BITS_PAYLOAD = 'eNrtmTFuwzAMRWl40Ogj6Cg6mgLkAD1S2hP0CAmQIWMMdGiCpmIlmJPMEBEgdDD+G2RAnwxNmeIQJn6FL37La2C+MfgHprQ8x7kSomz4Xe2ylyc9KsHLhjvVLrIRqBa++Tevd+YfvjJf+Fw2yxLLb3l5OT4UlT+ZjxzxzQAAAAAAAAAAAAA2De1MNXPqF8zTbKqZR79oIyVTJTv3NiK9m2pm7hdtopupZlK/aAPZKpm5NxLMggsltY7/ZTuz4FyJhsuGy7bZy7ZkNiqntZ46qGYtuTv5PIrHuhQ1M9+S+/L+k+KxnsGoZmNDo5FZzaB4KKemmMWWRrOXXqjVflq3TK1oX280MrlS6kE7Nc1saGg0MkDTPJRTU8xCS6P5eFYP2qlpZq6h0Wz5sv0BTy3Iyg=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_all4x4_refutation385_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
