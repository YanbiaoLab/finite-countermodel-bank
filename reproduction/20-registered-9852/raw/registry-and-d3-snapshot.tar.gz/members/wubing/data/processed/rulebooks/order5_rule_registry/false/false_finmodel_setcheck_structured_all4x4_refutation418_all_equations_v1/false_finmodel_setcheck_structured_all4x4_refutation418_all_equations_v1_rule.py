from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[1,3,1,3],[3,3,1,3],[3,3,3,3],[3,3,3,3]],"priority":392,"rule_id":"false.finmodel.setcheck.structured.all4x4.refutation418.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.all4x4.refutation418.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZBgFowAN/PiPDPQnqShyCk5UUVFUmtSi4uKipNTRoaDUJODU4cEEVOzg4cAyGmSjYBSMglEwCkbBKBgFo2AUjIJRMApGwSgYBaNgFIyCUTAKRsGwAwf+j4IhCOarl1x0jTsi7F/jcsFVvFLQxb9jnoCt4hPhR53qdkovFnXv4VikDhb8xPnxiLC8IEg5y0VhkCDHz5YfHR8EHyof4ldk+aT0xPVEt0A8R+MLTpB0S42TQotdk8AvDqcXyhwL+xU4Pil3QOxkx0w9fzBdxkhpivwAMQdTogHTMnuK0/8/sDnyOJ2BDNiplNmYcTkDBVDsNQt/cDrgwHQGZrJhYuDAYkIDCbYBAKxwZ/g='
_TARGET_BITS_PAYLOAD = 'eNrt0z+KwkAUBnBlca2iZQrRI7ilhSwWew6X9QCKhThFUAvBZi+hN0gnJARXG1vLQDKJpUVIrDJC/JvYqKPFEptdvl85M7z3ZvhmfwC4kU5cWtQNy3cbhmHRumSoKqWE2LTjaWS8Ox2ejCcBngwAAAAAAAAAAAAA4N+pJOAP+tK/i8qo7Mh99U1ZDVxVJjVvZuWcfFufUrHa+mBVPVoU/EzZWbrh8aDohIvsVUqTrFsw39dWINCcUmp5Q9YV/XBb6mu2NO14KaaJJvts2kwwybnnhk/PCz/ZPm4is+c6/EaPb/YTO//JqM7y4RiXNk/6bNtHY1yJfbW5HOWA8WPwsdkd2J0KvV90OwKgAQk+'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_all4x4_refutation418_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
