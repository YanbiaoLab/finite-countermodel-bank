from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[2,1,2,3],[2,1,2,3],[2,1,2,3],[1,1,2,3]],"priority":387,"rule_id":"false.finmodel.setcheck.structured.all4x4.refutation421.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.all4x4.refutation421.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWTGOxCAMHCIKSp7A/gTty1Lcww87QIyYi6456bTyFFGwwQ5jk2II+A2+EHNFTRUhwvHnyEcqJ9CeUMoTMuQVZ9axPLu3TWuvUiIZn+3ZvbiWoUQdy/Pyoi/DS8ct0dG9fZm8xdQmHJKypKAfE7NMiGXMaxMiSpWvlZnN5nA4HA6Hw+FwOBwOh8Ph+Fi8jPC0yFLEpGpSiFOHCsBQuIwGdctUsgTdKYOhaO3qGDNponPKYT/m6GqZLsHl1EEX1q6oZa5NYCaipdEckwq7L1Hcur5HKGKs7ZIezTGpsPsSua7LjDtFlLVNWeQ5BhVYiwe8TdSFIsYaaRuW426gtXioyURdKGKskbZhOe4GWouHFO6oC0WUtb1tng/CWjw/bH7Y/udhI6y10EcLXc2lATH1+cfozYrFafZW52FjRErUtpf58YGaSA7rNHtLeLgk0aiNtEFQoSaWwzpNzcLTXY1GlduX/gmRmkgO6zQ1K3i4MtKobcuD2ZObSA7rNMWLTzdXGvW6XdKQmZpYDuM0xTvxcIGmUduWs2263URyWKcpXp6HjfyiNKo2vGm6zcRyWKcp3vHZh+0bMTqpag=='
_TARGET_BITS_PAYLOAD = 'eNrtWTGOxCAMfPgVedmJnyxPoKRAYQ47QIyYja456bTyFFGwwQ5jk2Ko+A2+UFJAyAG1wPHnSGeOB9CeUMozEuQVR9KxPLu3TWuvUiIZH+3ZvbiWIRYdy/Pyoi/DS8ct0dm9fZm8ldwmnJIy5qofU5JMKHHMaxMKYpCvlZnN5nA4HA6Hw+FwOBwOh8Ph+Fi8jPC0yFLEpGpSLVOHqsBQuIwGdctUsgTdKYOhaO3qGDNpomPKYW9zdLVMl+By6qALa1fUONdmMBPR0miOSYXdlyhuXd8jFDHWdkmP5phU2H2JXNdlxp0iytqmLPIcgwqsxQO+TdSFIsYaaRuW426gtXgI2URdKGKskbZhOe4GWouHXO+oC0WUtb1tng/CWjw/bH7Y/udhI6y10GcLHcylATH1+efozYDFafYW5mFjRErUtpf58ZWaSA7rNHvLeLgk0aiNtEFQpCaWwzpNzerTXY1GlduX/gmFmkgO6zQ1i3i4MtKobcuD2YObSA7rNMUrTzdXGvW6XdKQiZpYDuM0xTvwcIGmUduWk2263URyWKcpXpqHjfyiNKo2vGm6zcRyWKcp3vnZh+0HG0bHvQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_all4x4_refutation421_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
