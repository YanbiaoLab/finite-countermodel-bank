from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[3,3,3,3],[2,3,3,3],[1,2,3,3]],"priority":389,"rule_id":"false.finmodel.setcheck.structured.all4x4.refutation457.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.all4x4.refutation457.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgBJZ0MIwCOoIP/8GAFC1LOo26NHoESNHCycCgxASkWdAlFnRAxQKcWPAZoADFo2AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAWjYLiD/7gAOw0se4DTNlp47Q8uy+SHfKxNYGpQUBJgEGQVYGBo6nBgYBBgUBBw4mBgoolt/3AFJP+QD0gP4VSRQI6FHWpcilMCXRJbnDhaJbgURVgcBWhhW+6mNUpcyiIXU1RbNs1a0xPhsVAwWLGlKYGDabQgGs1sAwAOQPIxM5lVRf1g9lvmoh5gZlMBMVkEoHNl4ChzYGBkgE1/sDBwgCgXk0DOhSDlIkEaRwI4FipINA1mrwE91cFBpFoBQRAJU67YMpqfBwo4OCpwsjAwcShwNjAwqjAKKDA4uLA0EDOLO/gBAJxur64='
_TARGET_BITS_PAYLOAD = 'eNrt2bFOg0AYB/AaH8BH8A18AQefoFPHRpycHByIXiIh+AwODpro6KJ07EAoD2CcG61wbh0wnAuc8YRPqHQxQVsTLDX/XwJH4I4v310+GC4jIot+0mUEf2itNTHPkO7h3cFQF/MMSYj8NG/V1wc7rLzXc9V3L+DlAQAAAAAAAAAA/12rymsNwdYro9WR2mpVsKelX7X91OK+oOhNEJnMIxLEhSsprSXaStVEviz9RPafz0Jbauw+DvZs58Jw5dE4DkI1EHVEO2l3/Pgx3Dh/MNq7Hf2qr0XXgWFeyhQfIhTbAmx91vH7L38Vx03O7XRbz4ttVFwqUe6VTZbMo4ym2x+KZNE4t3aiFd3Dm+FmT2p8bDY5tTwpJmfsK6LiPO0eGKjnRfEGPFGUSp5YlI0ywclzlDXLLm7zfQCwA8F5'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_all4x4_refutation457_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
