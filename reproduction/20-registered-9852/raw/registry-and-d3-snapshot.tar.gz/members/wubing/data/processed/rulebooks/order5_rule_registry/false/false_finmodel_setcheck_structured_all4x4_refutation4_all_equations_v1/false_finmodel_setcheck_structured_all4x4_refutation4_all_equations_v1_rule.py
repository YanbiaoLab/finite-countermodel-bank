from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin8_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin8_explicit","model_table":[[0,2,3,4,5,6,7,1],[4,1,6,0,7,3,5,2],[5,3,2,7,0,1,4,6],[6,7,4,3,1,0,2,5],[7,6,1,5,4,2,0,3],[1,4,7,2,6,5,3,0],[2,0,5,1,3,7,6,4],[3,5,0,6,2,4,1,7]],"priority":339,"rule_id":"false.finmodel.setcheck.structured.all4x4.refutation4.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.all4x4.refutation4.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WVuy5CAIBcsPPl2CS3F25kzV7Hu6o4lRDubhrbFudd8YExE4cKD/UqLP3+eDyFP8fKbt//2CyJ0u6jJfvqhcH+OzhuuN7ak2mMt9P8yT1FfE8WV14+9c7h9xdQf+Pn0eoUxus902uU5+Z/v9vS/3w/AqiuU65PEG/aonGg6y7RD2o3B3lFC+8vjEVxipqkzDUcKuhXradhS/P9rdqEchr+SaWGXbPe66s4Y0MeJkWfUOJfJuwV6Ruwnn77wUirV/bGcZXjqVPVzvZvpvTmptDLQ2qsHKuXjwl2GmSJ/vaQyOAu1NQzLYUyktA9siRzBHrvIn5YstDDRZ9apnwwwIVYe+cwCeSn49XBVfRkXGpruGQVaGfDRqkBbi0fY+q2NwpDWflCKzj9AcidyIrc/K96czI2yRJSkPZLcEtrSbx2s/VnmkOYm82M1Xx9PPOgWrT+7xS1bLp4gRANjCCJYl968py+HgOwRqzR2QOmUGtgCzIApR4Z61+ApsRn4dplx6mdFGSqQTtgPJSmACuw/3wgGK2pJWiIxuk1eOFs8QYm1rOQsvr7nB4WShGZbprE41FY+P/B5sDGkpymxhUZF7ZvNKjyizObgb3/Z/d1Jk1mfL57x2E2xT9uAI01JNiIQWo5bUtwa4V3MYIZjaSXtMntJI8YY9HVn3XoMtTqPW75+lCL7FqzGWNKqfzm4TiN7yOzuzxQ5sobPxa7D5YMShjRBxhVf+GbOZNWGvwqbIJRpplqZRw4olrR1N3IzcDDSSZVGhv052kgsamVaNF6vPBR1JdUHsrcr1PtiOfkYAPpI7MHxXx0tyJROwsXO293Cg91U8AhsoJ4qEAXrl0vgzLVn63fIS0ooj8GEkr31El/puIZlKIzUoQWmOfq3aPKORB6UKgFf0BUd8HfivOlplTroTomUOB14MNqtHaFXgKxWA3d9rzcXDEJGWa7ZsNMyKNnxnNrQMYIInmQ03bkGIQqT5KdiOrp8oHWcQ/FZSwE4xIi5+k4LRUrj8v91IsxOuWxZbjFYe/USxZoMEZOgPhUjI8OkB2Iq3qjwq5yoqG+2gx5mtfGnTg/6VCwhHfD8FmTQyIkQ5iLF4H2wJM53GU05ioGWo1eXnDRJEoAT3lcL9xtJ9sCWtHjCVH9VV0Wz9F2PwGGiXeKvZ+tetn+tfieiinMvnkjrqzOYVc11r/WerZaV+MEG9r4c1WxHVKXSCgLyV+sDw/j7YNs0IgEjSakM9uydntcEGupGatDxsYf8DCdFaWg=='
_TARGET_BITS_PAYLOAD = 'eNq9WVuy5CAI3fdUzbizcSkuwU8+LGG6o4lRDubhrbFudd8YExE4cKB/iZfP3+dDJEn4fPrt//1CJJ8u6rJUvqRcH+OzhuuN7ak2mMv9NMwL1VeE8WV14++c6x/JdQf+Pn0esUxus902rk5+Z/v9Uyr34/AqCeU6uvGG/K0nGg6y7RD3o3B3lFi+3PjEVxiqqvTDUeKuhXradpS0P9rdqEeRpOSaWGXbPey6swY1McJkWfUOJfJuwV6Ruwnn77wUirV/bGcZXjqVPV7vZvqv82ptiLI2qsHKuXjwl2GmSO/uaQyOAu1NQzTYUynNAdsiRzCHq/J75YstDDRZ9apnwwwIVYepcwCeSn49chWfRkWGpruGQVaGfDRqkCbh0fbJqWNwkDWfpCJzCtAcXvKIrc/K96czI2yRxSsP5LwENr+bJ2k/VnmkOQm92C1Vx9PPZgWrT+5JS1Zzp4gRAdjiCJYl968pK+PgOwRqzR2QOmkGtgizIApR8Z61+ApsRn4dprJ/mdFGSqQTdgbJimACuw/3wgGK2rxWCI1u41aOFs4QYm1rOgtPr7nB4WSxGZblrE41FY4P9x5sDGkpymxxUZF7ZktKjyizZbgb3/b/fFKk02dz57x2E2xT9pAF01JNiEgWoxbVt0a4V3MYEpjaRXuMm9JISoY9s1j3XoMtTKPWn5+lCKnFqzGWNKrvz24TRd7yOzuzhQ5ssbPxa7ClaMShjRBxhZf7GbOZNWGvwqbIJRpplqZBw4rJrx2N8ozcDDSSaVGhf092ogsa6VeNF6rPRR1JdUGcrMr1PtiOfkYEPuI6MHxXh0tyRROwcc6293CU91U8AhsoJ4qEEXrl0vg9LVn63dwS0ooj8GGkpH1El/p5IZlSIzUoQWmOfq1aN6ORB6WKgFf0BUd4HfivOlpljroTomUZB14MNqtHaFXgKxWA3d9rzcXDEEGWazZnNMyKNlJnNrQMYIInmQ03bkGIQqT5KdiOrh8pHTsQ/FZSwE4xAi5+vYLRUrj8v91IsxOuWxZbjFYe/USxZoMEZOgPhfDI8P4B2Iq3qjxK5yrKGe2gx5mtfGnTg/5VjghHfD8FmTQyIERliLFwH2weM53GU05ioGWo1ZXmDRJEoAj3leL9xtJ9sHmtHjDlHtVVwWz9F2PwGGiXeKvZ+tetn+tfieSinHPnkjrozJYUc11r/TurZaV+MEG9r4c1WxE1K3SCgLyV+sDw6T7YNs0QgIjXakM9uydntcEGupGatDxsYf8DQq8W3A=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_all4x4_refutation4_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
