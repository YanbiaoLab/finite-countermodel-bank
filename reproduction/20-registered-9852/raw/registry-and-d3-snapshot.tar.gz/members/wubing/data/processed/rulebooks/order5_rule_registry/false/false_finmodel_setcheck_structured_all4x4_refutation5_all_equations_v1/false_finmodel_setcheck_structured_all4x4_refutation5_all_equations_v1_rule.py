from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin8_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin8_explicit","model_table":[[0,2,3,4,5,6,7,1],[6,1,5,7,3,0,4,2],[7,3,2,6,1,4,0,5],[1,6,4,3,7,2,5,0],[2,0,7,5,4,1,3,6],[3,7,0,1,6,5,2,4],[4,5,1,0,2,7,6,3],[5,4,6,2,0,3,1,7]],"priority":382,"rule_id":"false.finmodel.setcheck.structured.all4x4.refutation5.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.all4x4.refutation5.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNqlWU2O3iAMtZEX1qwYqQdAXfUYLLvskdxFpVn2CD1q84WQADYJfKCqM4QE//CebTx/IMLrHyAAAfht8pqdk31tmwQoJq8VAAYQKEc4HqgFQLxe8uUC718BuOPnOQ5ZSRK9/stbun0es0Q4X/DJirQ/FntJErR/U0kHovTDQTPC9b3Ui3hNfWuKz4Kzrj6Z8tJ51yApeg6XXsC8eu18GBgbS/aN3eEFHjQlfUXKLdsE4fJ/d/B57M0ZQXNiaXtR1hiitWXlqwOjCxxTGpuq86iwPn7TaihhFQOsjT6NDDswO7O/2f2gwmGxdgu2fHmEytOQkqJcmlBgtHqbjB1Gz64bEHYjRL9tHO24bRmJqM/DtV6TJxuezDuCdAdrcfu+dZzDe9rejZ/Xr//06lelbMRF+PcjbHpUGcayTrZ4wsxdLknPgg5PwTj3IaJdeVQszrJKTvvO/l2E7GIoC3KaGYfGUuBAcduNx5OcsnSIYmMrI7bZ/O2TjeGsWpR+rJ65ASA8kM3IryR27HX4jISeeYcDLa95BRuZSmMW2Q7yUwtJMUCmi7FZssmFNVRAc7XIYMtxo1SgMvJj+a0zPiITcDRKNykEsU4iVkFUR5upkQtN0sE72AXRSong6C7e1jFaVqufmJzNRgTw+vTphtojtWSOQzr5W17DkdPipzIybHs3OoveNvjVzBZ6IYq1Z4xHfqrSIzbDZX7UlJFuzTQptP3Qq1/V9NtqPfJ30/j78NubPr9WpLkrPBrVh1NcWSsjpYSKpqJXIRHxPiINlpH+szqxDh5+zADhpowMXKtqK0o0GJ7sGHpd/HVmQ+2soQzazWxpxettVIUaqkD6BvFEeiGKAdUlihfJ5ot+iDOuYlTVhvhe+mwbME5lC9EJxI9V3fhGg8RXZ8TZ0CXTuGigiaGiKwGG62Vk8pbRxytZE4ZjxXsNEq5YQzfS/BCtm7DwyAGJi/DP/T19ZQlVreZPrekxROEN2fzlKKxqQa9aaa53c53IbHbj1rxX4xoiY0khxW0jai4hkouIgY9lJE30OftlJPzW6NFH07uhjpOt2wn/6IDq8/Fs3HwZGTsuCzyChNs7m9GN5BI2UmROnGj2KLJJpx5AFaLjJZfuUgw+ZTY0myFN9BNjK54l25mK/VOjJ1qK0xTZAtid76GW+Zxx3Tub0Xs1HgnM3ONyZhNdqgW7IFoh99H6J/Oimx6FCjarrX/7L1dGhg6jx8T9MjJ2sKakyduUPsnmOl0/IyC/rtVoHDxNks3qDxr1gEW2Gczw2We1utNNPeCg89e4Uar/B9pFV/8='
_TARGET_BITS_PAYLOAD = 'eNqlWU2O3iAMPWqP0OVIXdRH6rJLjtFVxQEqDauRFxZ284WQADYJfKCqM4QE//CebTw/xMnrn7AIiYRt8pqdk31tm3gpJq8VERQBKYc/HqgFYb5eCuUC7l+JxOPnOQ5ZSRK9/stbxn3uskQ5XwjJirQ/F3tBErR/U0kXovQjSjP89T3Ui3xNQ2tKyIKzriGZ8tJ51yApeo6YXuC8eu18GOgaS/aN4+EFHDQlfUXKLduE5fJ/d+B57M0ZSXNiaXtQ1hiitWXlqwOjCxxTGpqq46iwPn7Tqi9h5bysjT6NDDs4O7O/2f2gwmGudgu3fHmEytOAkqJYmlBgtHqbjB1Gz64bEHYjQL9tHO24bRmJrM8jtl6DJxuezDuCdAdrbvu+dVzke9rejd/Xr9/06kelrONF+PcjbHpUGYawTjZ3wixeLknPvA5P3jj3IaJdeRQszqJKTvvO4V2E7GIoC4qaGYfGUOBAcTuOx5OcsnSIQmMrI7bZ/O2TDeWsWpR+qJ7FASA8kM3IrwR27I38jISeeYcDLa8FBRuYSmMW2Q7yUwtJMECmi7FZssGFNVZAi7VIb8uJo1SgMvJz+W00PiITcDRKNygEoU4iVkFUR5upkQtN0sHb2wXRSokQ6S7e1jEaVqsfl5yNRgQI+vTphtojtWSOQzr5W17jkdPCpzLSb3s3OoPe1ofVzOZ7IQq1Z4xHYarSIzTDZX7UlJFxzTQotP3Sqx/V9N9qPfJ90/jv8NubPr9WpMUrPBrVR1RcWSsjoYSKpmJQIZH5PiINlpHhszqxDh7+zADhpoz0WKtqK0o0GJ7sGHpd/HVmY+2soQzazWxpJehtVIXqq0D6BvEAeiEKhdUlChfJFop+SDSuYlTVhvxe+mwbMFFlC9AJJIxV3fxGgyRUZ4TZ0CXTsGiggaFiLAHG62Vk8pbRxytZ44djxXsNEqxYQzfSwhCtm7DwyAFwi/DP/T19ZfFVrRZOrekxRPEN2cLlKK5qwaBaabF3c53IbHbj1rxX8xoiXUkhxW0jai4hEouIwY9lJE30OftlpPzU6NFH07uhjpOt2wn/6oDq8/Fs4nwZ6Tou8ziChNs7m9GNxBI2UGROnmj2KLJBpx5gFaLdJZfuUgw/ZTY2myFN9ANjK5wl25mKw1Ojx1mK0xTZvNid76GW+Zxx3Tub0Xs1HoHM3ONyZgNdqnm7IFoh99H6J/Oimx75CjarrX/7L1dGhvajx4T9MtJ1sKakwduUPskWO10/IyC/rtVsHDxNks3qDxr1gEW2Gczg2We1utNNPRCl89e4Uar/B3IsGTc='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_all4x4_refutation5_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
