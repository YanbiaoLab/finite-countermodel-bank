from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin6_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin6_explicit","model_table":[[1,1,1,3,3,5],[2,4,2,3,4,4],[0,1,2,3,4,5],[0,1,2,3,4,5],[0,5,2,0,0,3],[0,1,2,3,4,5]],"priority":394,"rule_id":"false.finmodel.setcheck.structured.all4x4.refutation773.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.all4x4.refutation773.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmN0KgzAMhU3xIpd5hD5KHi2P7pYxprJoI1S2cj78g1KLJyfEhqZD9HHOfoATONaw+t2eF/HHcvIuiQYMOgMAAAAAAABANyQ/haBaZofcBbJs5OT6Yq8d/lR4PD+YN4GCoX1rSPQTaLqWbPye65rOu/B450Q3jqJVANYz7FtgGWnYJdnuXKyOq6PdXNk4iBxtUklg8F9NNm4qYC39e4WwA1EiW9TIKS2V0bLWkQ5G46aPBmBINPMj+2eVewFrAwiS'
_TARGET_BITS_PAYLOAD = 'eNrtmN0KgzAMhR89j5ZH6SPkMhfS6JYxprJoI1S2cj78g1KLJyfExuZD+HFOfoATNNaw+J2eF/HHevIuiQYIOgMAAAAAAABANyQ/xaBaZofcBaNs5OT6Yq8d/lx1PD+QN4GCoX1rSPgTaLuWbPqe65pOu/B454Q3jrJVANYz6FtgFWnYJdnuXKyMqyPdXNk0iJxtUklg8F9NNm0qYC39e4awA1EjW5TIKS2VkbLWkQ5G06aPBmBIOPMj+2eVewHhbmik'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_all4x4_refutation773_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
