from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[3,2,3,3,2],[4,2,3,3,3],[3,3,3,3,3],[3,3,3,3,3],[3,3,3,3,3]],"priority":384,"rule_id":"false.finmodel.setcheck.structured.all4x4.refutation833.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.all4x4.refutation833.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2bEJgDAQhWEDgqUjuIMLCE7gRtrYiCM4gGM4iiOktBCiKQT1TIyt/F91kAePXHsqAm7Gocvbfh+qMo7UYqzaPmg7qSM2mbOCvQEAAAAAAAAA8CfXQ8CZkmEZqr+1La6yhwvELFPptzbn1xKZXYMW4DE722S2CVqAz+oqy2RWBy3AozHAiw3grBvK'
_TARGET_BITS_PAYLOAD = 'eNrt2bEJgDAQheFACktHcBTHcABHEBsb3cgJBBdwB0ewFISoKQT1TIyt/F91kAePXHtmBW6yvByqYh/abllNpKzGPsR2MkcsVWc9ewMAAAAAAAAA4E+uh4AzI8My1Hxri1xlDxeIRKamb23Or80yq4MW4JE422S2DlqAj3aVjTIbBy3Ao1bAiw1rxVVs'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_all4x4_refutation833_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
