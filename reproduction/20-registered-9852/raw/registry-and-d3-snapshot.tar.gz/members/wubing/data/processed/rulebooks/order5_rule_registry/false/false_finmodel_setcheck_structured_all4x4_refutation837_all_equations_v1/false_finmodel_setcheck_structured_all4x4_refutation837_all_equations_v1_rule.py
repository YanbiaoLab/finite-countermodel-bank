from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin5_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin5_explicit","model_table":[[4,2,3,3,3],[4,3,3,3,3],[4,3,3,3,3],[3,3,3,3,3],[3,2,3,3,3]],"priority":385,"rule_id":"false.finmodel.setcheck.structured.all4x4.refutation837.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.all4x4.refutation837.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZBgFowAN/PiPDPwFXUUCORZ2KHEpigS6KLY4cbQKAJksjgKuLBD1DUJKo4E2CkbBKBgFo2AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBQMM3Dg/ygYgmD9HL1Tmk8uulq22uzSWD7BXb/lEWerDVdTzYtFc5zkYqcEn1gs7vSxxUmO1dGuJNBPsR+snHthhZNif5OCfJWiiL/Gk0CBJ84Ija0BNgsnuDtO4K91FBCxcwwQkHcEcliZGv8sgNjJTlSC+ofpWNJS5AcSNGFJvfKk2faPBE0/MG1jJiezEacJ07J60rwWYQlKB8o4ZB1QeA8wkw0LabYBAIbcY/o='
_TARGET_BITS_PAYLOAD = 'eNr7938UjAI0wM6ADDa82/V63fe48rtf771et/te9d7vVe+BzN/73u/6DVFf//buaKCNglEwCkbBKBgFo2AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAXDDNgzjIIhCAKSL5pek9bbdazqsOv1iPwdF6plv1Ud/lrbLB6bvPfhouw15jEv9vJV7334a9/B7nUb7xWAlX+Ja997r6D2/oPWe683XJde9156D0Jj1frDcfk79uV/aNr3/vXBfevfP9gH5Pz6W8ccD7HzB1EJihHTsaSlSH4SNGFJvQ9Is42RBE3smLb9ISezEacJ07IG0ry2/BgoHdzBIbsfhSePmWx+k2YbAMWVDTw='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_all4x4_refutation837_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
