from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin6_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin6_explicit","model_table":[[3,2,3,5,5,5],[4,3,5,5,5,5],[5,5,5,5,5,5],[5,5,5,5,5,5],[3,5,5,5,5,5],[5,5,5,5,5,5]],"priority":386,"rule_id":"false.finmodel.setcheck.structured.all4x4.refutation838.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.all4x4.refutation838.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2SEOwjAUgOE3WDIJNyAoHAKFG1kQOILkBhwAhWECHIIrzKLQqFpuMYkkqAmykiEhTfpSFPk/UdO8/OnSqUYCfDhfm/W0PCyyuCXji3RF8sG6v3nshtN5s3dsFnMbFftVNpvEIhFfDQAAAAAAAACA/2LsW/t7p7Yetrpa5RoyPjHb0dWcQ5VXTfcuUjqHvGKp7mhP11DpVUtUsdwqBL8m3RWxNPj+14pa8qOfzU/w0SpFrBdcewEEpMYX'
_TARGET_BITS_PAYLOAD = 'eNrt2SEOwjAUgOEuiCmCRO4W2Co0CssVEDgQw6A4ADdAEhyCLMxNIXAowg1ALhnskSEhTfpSFPk/UdO8/OnSqdYCfBj0mnW4nmyy6ilFX24i6Xl5WbRnp/222Rs3i+0eR9NVtjtUIjVfDQAAAAAAAACA/2LN2+N7JzIe5rpa7BqyPjFz19WcQ7FXTfcukjiHvGK57mgt11DiVStVsdQoBL8mdRSxPPj+R4pa+aOfzU/w0WJF7BpcewFH3KsQ'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_all4x4_refutation838_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
