from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,2,3,1],[2,0,1,3],[3,1,0,2],[1,3,2,0]],"priority":329,"rule_id":"false.finmodel.setcheck.structured.etp_order4_refutation482.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.etp_order4_refutation482.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWDtuwzAMfSIYQOmkFDmAEHTJLRQgQ7rlSGqnju0NetSaH9spkHRqESTlA2xQMi1LNEmJLwHoewIWAHMtGGGN1vGKwA3gabF+y4ffGauCTSiDiJzVLZikTUgid9ebdMtdG/c5LTb0eObBsW5qWm1bwQE7LMMNA4FbQq29SfrKw16HrLlMktyAzJbcpJE16/XhUVZ16cw+Qvfcly0fTu8HAoFAIBC4Ybyv9ZT/sOenullkwrLmmsIugcCN4xXESnIBXI3ZMDqjyimfSrezvtUDTSSWA79dqudnfvJr6vhnWAJr4FPlN6+MmhjkqOLe+SRNm9ZY+5s7raH49J9MaHShZsOL12xaksFqN6/ZxjLOiClTePlWoM01mzCc9qWpnLsueleerclEqdl8k96VgxvEMk9fFURd9EaPlF5bEWCbVLrokaV2eVa00s1qgurOrmQfez2cdLyCourSOf2vNBlyFGJnvC+CZDs7J63SCcUpB6JzTvVB/LMPNMp0ganmxOKFrHQMVfV19ewzOXoIlWaJumAmoJtHNPs1dVwbhYsGm9xSPt1ZkgRb91izddAQR10W24B5/smCa15uuhhtxGK9ZrGafCQeA5zMqhXObg0ToTGHjImELPvQeHPlQCAQ+BN8AcywL68='
_TARGET_BITS_PAYLOAD = 'eNrtWDtuwzAMPWpv0I6ZUh0pWzMEqG7RpQh0gKDR1AgIQb2aH9spkHRqESTlA2xQMi1LNEmJrwNIGwaOAFGpGGGNnLBE4Abwftwt2vp3xiogE+ogojV1C2JpM7rIyfUm3XrXxn3pxy1/nHmwKtvS92+5Yo1XHMINA4FbQikpS/pqw16HprlMktyARpbcpNE066XhUVN16Ww+QvLc1ywfTu8HAoFAIBC4YTzt9JT/uaH3sj02xqG00sMugcCNYwkmJbkAKsZsGJ1R5JTPNdlZ3+qBLBLJgd8u1fMzP/s1dfwzHIAd8KDywiujLAZZqbhxPknTpjV2/uar1lB0+k8mZL5Qs+HZazYtyWC1m9dsYxlnxJQpPH8r0OaaTRhO+9JUzl0XKSnPlmWinG2+Xe/KwQ1inaevCqIueqNHSq+tCLBNql/0yFqSPKta6TY1QXFnV7KPvB7uOl5FVXXpnP5Xnww5CrEz3hdB8jY7J+/7CcUpB6JzTvXI9LMPZG58gammTuKFpHQMF/V19ewzOXoIlWyJumImoLNHNPk1dVwblaoGm9x6O91ZugRb8lizdfAQR0kWm4F5/t2Ca15uvxhtTGK9bLHafSQaA5zNqgXObg0T4TGHjImELfvweHPlQCAQ+BN8AX/BQYc='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_etp_order4_refutation482_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
