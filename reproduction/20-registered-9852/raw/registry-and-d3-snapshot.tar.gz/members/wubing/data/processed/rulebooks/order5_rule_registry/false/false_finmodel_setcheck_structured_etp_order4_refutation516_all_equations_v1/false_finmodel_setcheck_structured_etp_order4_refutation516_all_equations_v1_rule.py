from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[3,3,0,3],[3,3,3,3],[3,3,3,3]],"priority":328,"rule_id":"false.finmodel.setcheck.structured.etp_order4_refutation516.all_equations.v1","rule_key":"false.finmodel.setcheck.structured.etp_order4_refutation516.all_equations","rule_version":1,"verdict":false,"verification_mode":"setcheck"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgBNbMAZEHTnEyjAJ6gA//wQBTouHrZX/Lo/ZMmDJ/wDrsMSUevP505L+LPxZbIJbwY0qsmNNl1NoDZAQ4sTAwRljGTgk+oQySKAj0U+yHK3N4GjJFM4UF6CohJQaO0VgbBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBjG4D8uwE4Dyx7gtI0WXvuDyzJ5GljWsP70///Ctj//1y9S9//j/+WJ8iGQVRwL+2nhtQ+4vFZPC9v+4bKNnwaWHcCZRhhpYNsPXJbZj2Y2kkBN7L//81+cBOWBykfAPCAvCEo17hy1LLTIbDi9xjya2WiW2SgOgAj7v1OC/yzurquq/BLs97E/Tu6oPVelyJH/AlhS76L5cXJg5dPdP/Y7ybF+tGehXWb7Q2lpA52r+Xe99cVJYVA90KGg/+i/vdMLZWypt1SxCqzcTulE94///QK/SJyDIaVm+0BpaUNSZvtHaWmzoe6X5vIf7uJ/v3x6sXzOI/m9Nl31Ip80Ov4rYkm9rvZ7bcDK9fsfybfacD2q56BdZvtBaWlz4PrTzv+d8/6s5744Wf2fetUnQce4I//rWy64Y0u9r52+PAEpr3GZIP7xv7ziF0Ha1WwPKC5tAO1X58E='
_TARGET_BITS_PAYLOAD = 'eNr79/////r/hEBwMoi0N/32fxTQA/AzgAGmRD2XzoZjVgf+Ysowg3UcwJSQF+G1Zti9AYstEEs+YEqEJ5eerSoGMtbv/f3/3/Jji7LXmN8BSfSv23ivAK5sv9Tq7GuzfwNd9fbu/++jsTYKRsEoGAWjYBSMglEwCkbBKBgFo2AUjIJRMIwBAy7wgwaWyeO0jRZeY8Zl2QMaWFYfYMLA8OYQG0ND7I0NzBu4pe/Ygqz6HldAC6/x4/JaAy1sY8Rl2wcaWGaPM438o4Ft7LgsOzCa2UgCzYsYGRLEzUB5oE0WmAcevAOlmh3fm37TIrPh9Nqf0cxGs8xGcQAsP8CUvYY5pqSxtY17zUa+goUPrQ58bXttzfAeS+qNTVj4EKw8Ywdfwd6Hv/gO/KZdZmOmtLSBztUwalSJm70B1QPl9y/IMhzYK34HW+rtutcKVn7wrnkJO0PBe1YS52BIqdn4KS1tSMpsjJSWNv6NrNci2He8YOLmFY9Iln3gdLi04TXv9XKGe1hS764DTofByi8UyD6oOvxVtuE77TIbO6Wljb2GVBlDWSJzwBe9nBuMN1p53+1baM3QUK2/A1vqFdnLLQ1S3rw7/wUfw4N73O9oV7PJU1zaAABfGolm'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_structured_etp_order4_refutation516_all_equations_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
