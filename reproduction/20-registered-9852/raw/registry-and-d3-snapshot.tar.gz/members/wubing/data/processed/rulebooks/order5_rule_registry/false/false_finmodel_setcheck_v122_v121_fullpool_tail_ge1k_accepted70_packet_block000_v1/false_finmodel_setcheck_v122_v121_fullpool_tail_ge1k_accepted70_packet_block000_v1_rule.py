from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,3,0,3],[2,3,2,3],[2,1,2,1],[0,1,0,1]],"priority":840,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block000.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block000","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWUtuwyAQHSMWZGeiHgAjIuUYyGIRusqRqJSFvUutHKBHLR/XbW3c1FVIm5RRZEuQ5Jmx37zHuABZwKeQGrnTSXwYewAx+tbvxeNaC0ojl7PvdrxtyHTCdGqtlVoC8iKe1ZrSyMymFV3TXGgpoBnEErvv/MkuiKPRUrA7HWcublls/JEZgUYTJezskbiP+eL3YU5Cjhw5cuT4x9Grr9PmqhWcK9U0Ja0OJUpnAjyQVWp1aAilnB/KOgWY1HwAcuJvl8VrZcFICrStHoC8zPeprEkSBxbsjAdybqMOqaxJlQKsd1UeyDmyPpWkwinQTmIA8o9mSCWpDpmsmWz3H5ZseNhDaG/rabpN3FXJ1m/o3gUn1C0rNlnZMtnuP04CEQbScUBCQex+nblteJEzs7wBg23yVpiBeAJsGuJSadKAyVUAohKMKI0rx/62oTtI5GxXLIWznG/OpXCWQdkiN0kmELv5VmUKsZvtmMKVxC7HD8kWnzi+Gb5a4Zym75ANimiiCDM9B2yBNpdR1j3a8biyFIKGLjwGSzYrQLcW/SujSDGJlM7I0LIWx1YPJaqYFmQ4O5S0xXFTNjKwALqxArB2Ykoib4mcebGOKbtOu2cLz1rc/Uxsw/QPGEdLyeZL1FlmlRKit+2Pus5XZPK4aw=='
_TARGET_BITS_PAYLOAD = 'eNrtWUtuwyAQPWoPELnZxQtL5UhZlSyQxTEiBWEOUAXvwgLhKR/XbW3c1FVIm5RRZEuQ5Jmx37zHuAPawaeg2LjTin0YewE2+tbvxfMRMykjl7MtdnxTqukEKsgRE7IE5IE9kqOUkZnDhhVleaGlABYQS+y28Ce7IG5GS9HutJ65uGVx8EeBmBlNtLCzR+U+6IvfhzkKOXLkyJHjH0evvk6bmw3jnJCybGVTtSadCfBAVqlJVSopOa/aOgUYxXwAcuJvl8VrYsFUCrQ9HoC8zPeprFUSBxbsjAdybqMOqaxVkwKsd1UeyDmyPpWq0SnQVmwA8o9mSKVqqkzWTLb7D0s2PewhsLf1Mt0m7qpk6zd074IT6pYVm6xsmWz3HytmlADqOEChU3a/Ltw2vMuZWd6A0TZ5Jy2APYFGpXKpRGnA6CkASQqItciVY3/bzB0kcrYrlsJZzjfnUjjLoGyRm0QTiN18qzKF2M12TOFKYpfjh2SLT6zfDF9NdE7Td8gGXTRRSqCeA7ZAo8so69bseFxZOiZDF16DJZsVoFuL/pVRpJhESmdkaFmLY4+HEtVNCzKcHUra4rgpGxlYAMVYAcRmYkoib4mcebGOKbtOu2cLz1rc/Uxsw/QPBDdLyeZL1FlmtRSit+2Pus5X53+4vA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block000_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
