from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,2,1],[0,2,1],[2,2,0]],"priority":842,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block002.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block002","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmEEOwiAQRQcyi3HXI2DiQVj2WGPiATyytLQ22NpqAir1vwVNoGHCh9/OcKYJppcIrwllQg7ULA54yofG2frGUA0ETVx42DbDXI77lfO1a21+db+DJGKBOlAdziSkqMts3HzObEdlO9jbFg/mTjGKPHxUysA0rqx8LFIcXPDH8JTqyJYzkEP8Ct67cfM03Zlm/kcwaym9gZgAAADAfnh+exBTBIFEANTIJbh3sHfqYk+GqXXapfU2VAeSFHlr9QRE3RmydD5Q8gFQzGzmfh8zG9roeuui+wZecAw0'
_TARGET_BITS_PAYLOAD = 'eNrtmE0OwiAQhY/sAUycY3XJQUzkCOycxQRG+meDra0moFLft6AJNEx48NoZTjoh+hLxNdZM8FXd4oDRfFA/W9cErYGoiY0P32SYy0q3cjm0rc+v7nfgRCxQB0TDmYQUdZlN3OfMdiHxg7198WD23Efhh49KGUTHlZWPpYSDC/4YmVId3nIGcohfwRg7bh6lO+Pmf4SwltIHiAkAAADsh+e3B32KwJAIgBo5RvcO9k5dbDSINpbatN7H6oCTIm+tnoCoO4OXzgdKPgCKmS3c72NmQxtdb1103wDuAWUC'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block002_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
