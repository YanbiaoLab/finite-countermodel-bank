from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,3,0,3],[2,2,1,1],[2,2,1,1],[0,3,0,3]],"priority":843,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block003.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block003","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWc1uhCAQRuOBvYFPgIRN+hjEcFh72keiiQf3tjV9gH3UMuDaVsc2pmI3KV82mLDKyDjf/PGSkxFvCkbdfJr6Ap3pEm4jvSZL96zEU6NejSkQWY28KCnXrHXuT/LS0fkftjdlYwzyyJtyz8iN9rIhzuGV8pP8/Vo3lcEF0fPxAKOY65n5kf60siXavaf2v2JnDTnDcduyqu864q2SoB94IxwvJKfkakrOGdh+4ZTDYNsJq2BLXWYFOeUZJY0gmZA5qFIkzTw0gpdugWyeA1Ia03Wsplkcso2CwDvXpu0o5zWtYgi7uZ3dBUGQcNvilXTCoji0EG+8IB+rgipp1UYhWwh7XlCjOGwLVFm1LE7ICqwuGBGHQoA7Bh9pE3sS2f4Gu5Jt5/yw/2A1pG+D32pZlFT2uRwFedMMqmxZHUPYkPiPHGDBbzn7T2R74MiWkJCQkJAQGy6yLcSwHhKIEOw2TCNzijYoNIFWBuRh2dASSvg2jfTFIQJhldPf1UCxyHlOUoLyWGSDNBIjW4TMcrEhryOUccvnAjF6JovHEyRGGRdqNqSKEfuUcVEbJEFruI3MlIt8926Fqx4OSezsxAv5mi4iTFd2Lg2iQ4oN1h/SEKbLqVEqrqc3QzCYTkE7kVf/Xo/381nE/BDXiUyta3HcyTZzJgjZsKl1LY53TSq24w=='
_TARGET_BITS_PAYLOAD = 'eNrtWc1uhCAQftR9gI3d23owKY+0p7oHYniMJkuQJxBu5WCUMuDaVsc2pmI3KV82mLDKyDjf/PHc2RFHDiMrP019AetZA7fZjNmle1biteRPlLaIrFKcuRBr1rpkV3HOzfwPktGmpBR55MjdM2KjvWyIS3il7ip+v9aB93BB9Hx7g1HO9az9aH5amVjm3pP5X7uzhpzhuG0RnuW59VZp0Q+8EW5n2xl7oo1SGmy/dcrRsO2EVSANa/rWXrve2FLaXooOVCmTZh4awUsXQDbPASEozXNdmT4O2UZB4J0rWuRGqcrUMYQd3M7ugiBIuG2pWjhhURxaiDdekI9VQZWmLqKQLYQ9L6jkCrYFqqwLHSdkBVa32sq3VoI7Bh9JEnsS2f4Gu5Jt5/ww+2A1pG+D3yp0lFT2pRkFedMMqix0FUPYkPiPHNDBbzn7T2R74MiWkJCQkJAQGy6yLcSwDBKIEOw2TCM7gzYomIVWBuRh/dASSvg2jfTFIQJJuNPfiUKxqFRnU4LyWGSDNBIjW4TMcrEhzyKUccvnAjF6JovHEzZGGRdqNqSKkfuUcVEbJEFruI3MlIt893yFqx4OScjsxAv5mi4iTFd2Lg2iQ4oNxB/SWM2aqVFyxaY3QzCYTkE7UdX/Xo/381nE/BDXiUyta3HcyTZzJgjZsKl1LY53/0e6RA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block003_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
