from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,0,3,1],[3,0,3,1],[3,2,0,1],[3,0,3,1]],"priority":845,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block005.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block005","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2SEOwzAMBdBvy8BlXk/gVQU7RkBBd6uEDVbTDryCSSMlk9qB7T8pJAGRnP9RBPvJMaAQ0J/I16Jdp2pL0RPUE0W7Ce4RmeWgYj1wnwctvRhKdo4Q1Wn6iWeN3rNVSCKymqqhImLdZ8aIiIiIiIiIiIiI6FyhmwcF4u/vD+ek6CuKZ7MBczaHJwQDJtyQdshtF8nFDFcLoI1r2g0eJ6nbkd9qwSfNeAKuPRAR'
_TARGET_BITS_PAYLOAD = 'eNrt2SEOwzAMBdADT1PhWHOrFQTkGANV5xN0ZjWw7L+CSSMlk9qB7T8pJAGRnP9REvuRURFI0J+Q16Jdp+pdiwfCBC2WCjNVkXZQsU44D1O0OR1NFoNmRK0/8aw6m/QFKVApHuEoUF33mTEiIiIiIiIiIiIiuhfE5kFD2vv7wzgp+opm0vuEQXqDCRITKi4QP+S2W0rnjqsr0I9r2h2mjyzbkd9qwSfNeAKeNGEl'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block005_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
