from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[3,3,3,3],[1,2,3,3],[3,3,3,3]],"priority":846,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block006.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block006","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmU9o01Acx19sXToUU+mgCqN19lAFcR4n1EWLUPBSYQcFWSuCBy+yw2B/nCbMwep26EGhINLabtiDQsUdBv5bRYpTD1rmYD1sS9VCwR3abqtpm/RnmsMOtsXm8ATxfQ7JC78HX34v3+97gVAIIR79iVlf7RqPU4jwN8iBSn2B315yn0ywu+or0urr8sLGwfqCkC1MHD/rbqACqLM6STcoPPQhvTo471TuB3p2CgNoH2J2nk4LRp66TN4WgUAgEAgEAoFAIBAIBMJ/ADSDxiAmNFXD0ZrUTMyKQYyf+Wh6bjw14jRH7O6sc+u7bfylIWI3hP04Wst1VwC4K0ov7mMx+HEnwZWVMSv7T+BQqzZbSAaDWBzgGXg9cuiCFFVF3E+CKwCF91EcrYkj/UVYfAybU6XBFNhia75lUwW8e0sdmMI29IL7uQzcurqm6/MAVz/dr4R0/3zYxjqrYBXeAOgcPQLH04zqGhqN4RDjlQzDEluCQNSudvTttjQNYJDxhA3EDIAZIA/pAGS8EhvmChCSoB1T2Kw5hCYhTdU2MG5YcU2a4nFETQ1bDV2r7v0NTpvaRVa+1yfZWnNvJOSx1KbPBFx5v9OyO8/qtalx87Fq94221o6KhUupudr0Yt+1tS8AsyvvNIat6b+aBu61D3aNqtN7Dy9OHxodN5YNGk823YBotbTqXopB6vS4jqcBKFF72JqAY9d6eqt8NCq6zPJWIRt98NX6yjHFdRSO+KALS9iue2VvcQNWPwRvbnOpudC5zUdVsCd623CELZlp7/cFHeE9ybuqBfaf8eiTponPLiwnGy3kWAcPzDDi34Kyo1iQQwQmrnzXNXBbIwNqMeUvmODaHA=='
_TARGET_BITS_PAYLOAD = 'eNr79/////r/hEB0OYi0t//3fxTQA/AzgAGmRD2XzoZjVgf+YsowKzmyOgg/w5SQF+etvrh7AxZbGP4/Zqz4gUUivvz/bzBj/V4g/fw4XKL//8f/H+C8/fLv6//NH42tUTAKRsEoGAWjYBSMglEwCkbBKBgFo2AUjIIRABhwgR80sEwep2208BozLsse0MCy+hiTN67vD7XtfRF7Y4P4Xm7pO7XO32NvfI8roIXX+C+wMDA0zAX6ZcPlAAaRMqsGViD7AFPBeVrYxogrID/QwDJ7BgZfhgULmRJWMEeALdkQnKjOwMBrFkELr7G3LeJkMA9h4Cll61ZjuBOgWK71hoVhwWe21zTKbB0uDRxaDA0K4DBV8GBgmGWQypLwZ8hntubHjAwP5O0YGP4cPi7fUP/jAzjV/PjfTAvL6oF5mEHnABtDRsQNsI9kaphLGBi+M9EmszGwSzEwvGBg4GOQy2CQWsB8IK6BlyGBmeEbjTLbA/7//ysY5P6BCrCGdmCqkftXT4usBs5sIPCH2NSLBhpIs235AabsNcx3iEu9sQkLH4KUx2Ts4CvY+/AX34HfpNnW4BHAeKHlJ3FVhcMSNR+Qcs410xS1GRii1S1IzGw452qwpN4b3fdawcoP3jUvud9a+571O4k1259+9gcPiU29/z78Byu3/1P/g4HhHzvpmQ0HoEWp5d/Iei2CfccLJm5e8Yhk2QdOh0sbXvNeL2e4R5PMNnEB0wJOYQYl08QmrgY1n4StPJGMDDesDv6kRWbTk/q2qDzxcNwXvRxwEni3b+FvvTfV+jtoUrP9kOc/cLie4UP7/3obBmCJ8vD/YXaGD/bAdh2W1IYtAZKSKAGzkZcL'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block006_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
