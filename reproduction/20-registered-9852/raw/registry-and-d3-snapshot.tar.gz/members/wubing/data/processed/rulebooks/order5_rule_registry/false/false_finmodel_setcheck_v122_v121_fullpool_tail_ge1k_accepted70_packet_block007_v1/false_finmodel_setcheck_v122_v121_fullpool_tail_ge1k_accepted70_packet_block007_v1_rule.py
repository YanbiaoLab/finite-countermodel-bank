from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[2,0,1,1],[3,0,3,1],[2,0,3,0],[2,2,3,1]],"priority":847,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block007.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block007","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmU2KwzAMhWXjgrtzfAJjPDDH0CKLNKdKd+2uDXOAHHXsuHTRaTr9DcS8b2ECwnpIjkSsCIqwoHtgfds+hPv8vEYrNwTewVen5NUjNeOq/3Wgzk+y7EyJbkaxIRxrW1Uzqf2EvvFeohoAAAuhtSJU5PbB+8+LceO2ys8VmhbFntpAh/TJ0Kec2rjsdsWE1vVTlnBkRsECAAAAoDhWU4Y8SmowXwBgibg85LWNu6xhqd3VDd1y7mxKjs1J6DzsPsfDJC7n3y+HZWK+og+hTPIlSUUBQ+5DsbVZaJ+EDFMSHjUL4Hvq/w/bTV3/eUlx+Qbg6WITIbaP1A5zq7rZQeSaid167GvytOshfgH4Lxrs'
_TARGET_BITS_PAYLOAD = 'eNrtmU2KwzAMhY+aA5R0du2uOVWaRRY6xkCN8Qkc72qosTV2XLroNJ3+TAMx71uYgLAekiMRK4EjFPgRyN63V+IxP+/R+j2D/+DQOH/zSM242j8duMuTLztToZlRrBLrXg/DTGorUXdSelQDAGAhtDqIgdVGSPl5MerUzsm5QrOh2FOr+Ct9MtQppzou220xoTX1lEWsiVCwAAAAACiO05Qhj5I6zBcAWCIqD3l1p65r2Ft1c0OznDub82NzCjYPuy/xEIfr+ffbYZmYr+gjOJN8eXZRwLD6UGxtFtokIUOchEfNAvie+v9Det/3v15SXL4BeLnYgojtI7XD3KrudhB/JCZ1HPuaP+96ih9UQlZK'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block007_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
