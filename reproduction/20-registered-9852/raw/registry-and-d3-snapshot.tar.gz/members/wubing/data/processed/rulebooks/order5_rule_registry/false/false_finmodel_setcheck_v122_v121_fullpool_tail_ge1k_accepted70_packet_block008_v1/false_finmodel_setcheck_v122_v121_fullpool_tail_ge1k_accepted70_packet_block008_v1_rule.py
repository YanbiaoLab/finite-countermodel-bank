from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[3,3,1,3],[2,2,3,3],[3,3,3,3]],"priority":848,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block008.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block008","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmW9IE3EYx3/Xrbb+0CZKCsmu4YvVm6J6Y7B2OtO9iSb0ot6k+UKiVynrhcvqDkIMtbbwxXxhihbYi0AseiOJZypKBjZCsl7EUROvDJrzFra2e/rdmRHuII66XtTv82Ibe57bw/Pn+3tgPwohxKNfcb9bfRUEahMi/AUSwWEJIv5cAx8ep4D26DySmUmmR3uKcg3i4sUYuMI6jzAIKVb8btlouNfddqilA3+o9mFbUWkxTwu0amhAO5H9h1uZ6OCps6RbBAKBQCAQCAQCgUAgEAj/AQDtCheSuRPLYQUwbF+TD2DczZjxh6EInAAWuzJFSWNqMEDILgJbJtJmpJaBlfRozzxER/K+qsEO9lbVZCHwoWSHCcF4gEoIe9LsQJdfS+1GtacPYCxip0yIlgCryOHm0WpNMbT2HWPSjODBWCxYkfrB78yq0QorACqcm+u8FhOCCQDcmXitZxmmWrVCynFgY/k+xW1GaqtQK0N7HwTbDshqsKWtk/lpYLx1DnPE9ml/8+Hoy6upOVVs3JVHzcHUxOtzHfQ/ILaH6dGb89B5+7vYolXHsdieukwSGxyZZIcliK6JbSEGEPGXZ0wSG/eW63fDkg+Potq2Y5HCZWBccp45YvuppjjYxtT/rNhm3/djKWd7T07faVfsIdm3t+c5wJ7pVr3pXSxISqr7iKPNLQNrS7oMiq20OMEK16ARNTUIgOxOJNCrYEerCOX0TeSKkVNzt6IELgqNvAazhwePlUH3Z6i/MKFesJx+NnDrFEBn2qYz/xnu1e4h1X3Xyvn4HMBd7xODYlu7q1Fm98VjldDqueQqCEjAOeIVetMb3BbS3Gts2mlj+WLwtLmMa8ngk3KtUOvDYtWfXlYrPbN+AhlWCN/7Qs0Ib7aIvzDLJKUWbbOVm7TZGktFjrfCO5QQeaCcHsRb1c2WoEwRW30oWxv4CDNvri+kuKNDXYGSQQXcqbwtZmw2I2L7/c2mtZ7X+i3A+rbT7gC353rbdH5h2kC0b3hmtBA='
_TARGET_BITS_PAYLOAD = 'eNrtmW9IE3EYx5/bWtLOuSDrxBVHL8qQWEKGouaJ4ZsoEXqRUIrmC/dC2kolkeCusvmiob2K8IVpb+pF4KI305zeGuSbinpTeyHrhoGG4i76s9Wu+/W7MyPcII66XtTv82Ibe57bw/Pn+3tgPxUhxKNfcaJDe+U49Ssi/AWcgQYGvKFsA++rUUGJ5njEWu6w1bUvZhvYomtuiPtyPCIhRKXxe2aj4WRH79P+bvxhIoxti3MLvMIpmmEYvUPyD7dZNsmrt0i3CAQCgUAgEAgEAoFAIBD+AwB6KMFPC/cLfBRgxNbBMEBNTDLjD0MWBA4yMlWpMrVaMEBIZkGcZRUzUrNCvq2uvQQ89aubtGDP2ibHLRDcPv/ehGA8wBT4ojaxuTOkp3Z+ItoKUOuVVROiOSHNCrh5ilZTjKJ/J5k0I3gwipbzmRYIJSxatKVpgOnEl9FIxoRgHIBw2zUWLYDKPr2QtAtE90qYipmRWh6M0dDTCoHe57QWrPBT1YoNpMho0hyxbX0x8MSz75K9VBObcPnoQMBevedmt/IPiO2Yre5cCXSd+S42z+QDLLZDcZPEBo+rxAYGPGtiK3YDeEMzVpPEJuwSWmJQGMajqLXtoXepAKQ4vWqO2H6qKQ62MfU/K7ayHS1Yypa2exWneyjZT4dftR8AeF3Rl2t6i5YdjOZen+yN0SCmHHGDYptbcIrcRRhCg8McIDmBOCUPZJSHUFbfWGEBJXT3NHLioigoYjB7OH6EaoptgZHr1doFy52DzWfvAnTZUjnm3yrsfdOoub/Nv+EqBTgVOWxQbGt3NVTZS5d7CvqiV+PLQQaEpGs61/QGPvp19/GUftpkNhs8ba7gWkr4pFwr1PqwpHNPr6iXXlo/gQwrhG/br2WEN5s3tGSRHEy/vtlmTNpsQ3OswKdhJ3KyPKiJKOLT2mZzqqaIbcRvGQtug/LdF4rtwqPGzuB8EwUx++pnMzabEbH9/mbTW8/r/eZgfdvpd4Afsr1TOX6hwkC0b9QLvRc='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block008_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
