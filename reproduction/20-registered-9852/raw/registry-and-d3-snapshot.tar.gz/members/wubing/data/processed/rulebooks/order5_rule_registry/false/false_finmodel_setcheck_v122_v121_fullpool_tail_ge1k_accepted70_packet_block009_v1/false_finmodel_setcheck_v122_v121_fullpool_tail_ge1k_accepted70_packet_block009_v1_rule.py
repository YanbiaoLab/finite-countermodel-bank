from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[3,3,3,3],[2,0,3,3],[3,3,3,3]],"priority":849,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block009.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block009","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmU9o01Acx1/SjhX8s4loHRM62WE3i3iYB9cMi+cigtWDm3SHgZfuMGFqxwsyBN1gF2FowR6GDDYlKwoeZG2ZbKBOiiCYHlx76Tak6FxtTNYkP19SEHENo+ATxPc5JHm8H/m+3+/9vsnhcQghEe3Gs1fWNZPhEONvsAk2OyfE71nhRS5dZx/0hUAVlw7tnCjo5cnjSrSOio/jzOZWhNy/T8zb2z17aeLcGTePjpyylV1DaGQI7UctP8N6C60id4XtFoPBYDAYDAaDwWAwGAzGfwA40UxBrOCoRiM13UnMR0FMLGcF0EFbT4AAGxFYg0mjvdr9Gb7QSG0zoQIk2gAEITgFxbNyXCN55WMDe2momU6FbKEglgG4g2dT+vR4Lm6LnAz2jRntj96HaaSmXjcAViRSTO1aDjql1RUyBjyhHaZjtvTWXRjORf2SXdM3c1q4U7qt9vP/vtkEkpGwSN4+rhax5t3yWxl6YQ+NkweReBiEHg282112RsItfRxgY3qSmtmgzZKpmS1tm02PUjKb5yi5NXO1Dxgmz3yB1vFNptYQrgY8/yu4MbUR0J/GjfY6ywhDbFQb7K529/eX8vd6Bkp4bQ6nUlZ4XPIr0dcPTyiCqzE1LGVN382mOp7H0oNQwhCUT08uLiQBluZDRjr8dsYKr1x4vCoDROSZBs3meFYT0suVou9yKR8bTeLgt7Ek3O8yte0tKzyVktPHbizK0GAnxdxu1ddbbxnYjXjPpiAiHvWSPXQhMuARZ4dzqIN8gbidp0a7ms0BFw2zmbU+MEjVEh9rVTuvTCShjYrZ+uw+gIWrgVEF5LnnkcqyCd6XgSYaZtPWrT44/TX7YQoPJ3G5smTue3dw2Ryk8mfzWH0gwgHk6cgA6QqEOJX8sTvI/c+r/QAaCSYs'
_TARGET_BITS_PAYLOAD = 'eNrtmU1oE0EUx9/uphsTE6MEaZtLUg+JIEiwKrRY8oEHQUkXTaFIDxGiFLwEEgUpskOiFuyhuQg9NJh60AgiPUsl23qwB5F466GYgKVGEVs/IKFJdpzdgIhJKAFHEOd32N1hHvuf9+b9dw+jYoxlvBtnT2pXn0/FjL+BDXRaJ+Q9XuW0299mH4TgsgHZP7ZOOAVL7I0p3UalpKpcdQvj2u8To/p2jz2MP31ea+D3L3Xl+iyensVf8PbPsLxzS1bvs91iMBgMBoPBYDAYDAaDwfgPgE5UKYg5O6rRSE3oJFaiICZbvAoIIPZFQIHeDPRDjN8wrB6A/TRSs0WMAJFNAEVZmgTHM09UJHm5UvPfaKhxnQq5TUHMB3AdjQWEiYQ7qou8WlqY4jcuHsnRSM14hwcYlEgxxbtuWJcGBskYUFz8QMdsfus1mHGnC5Je0+NhMbcu3TBmG/++2RSSkTJC3p4wOpBYtha0DMvwncbJg0w8DMqKCOWeNT0j5aaQAOidiFEzG2xqMk2z+XWzCWlKZqu8I7eq2vyAIfLccNI6vvE1G6Lehed/BXWnNg3CuSi/0WYZOUglxblVw2o2a3ddXZm3o/4wCgS08KhUMKVPXHptUurdqSHJy5Vu7bTxPJIuL0Z4xXTw/KNgCGB4dJH3546Na+HmxxcGPAAZz3iXZut4VrMoWMyO0gO7K5UMoaW9UyG4ssaJPVYtPBDw+N/eHvFAl52UqtWMpXy7ZaAablRsiowbOE/2sI7JoIFVPVzFRfIFUltPjXY1WwfqNMzGNfuAJ1WLHGpW7YkpHoJNKmZb0PsAgveWkybwhM9kzEMclE8t79Awm9in9cGLfd7Dk2gmhCzmYe7r0U9D3ByVP1tF6wMZPuNK0QekKzBWjeSPXST3P6/2AzJ3Swo='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block009_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
