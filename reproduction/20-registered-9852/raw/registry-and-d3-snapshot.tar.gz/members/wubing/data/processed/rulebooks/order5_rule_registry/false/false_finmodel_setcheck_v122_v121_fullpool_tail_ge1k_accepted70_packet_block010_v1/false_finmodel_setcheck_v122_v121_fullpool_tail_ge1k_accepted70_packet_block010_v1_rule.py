from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,3,2,3],[3,3,3,3],[0,0,0,3],[0,1,2,3]],"priority":850,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block010.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block010","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWc2uoyAUBuKC3hU28wBImKSPQRoWdVZ9JDNxYXf3mvsAfdSBg4g/2JrYTjsTvia2iniO3/njUIwURjF8yzacZObz9jijE3nUs67yS+/zvD0Jcdyb86bxIz8vsu3OxtIOSBomK2l+flq2hLgr5QOV8QGGIgIsqs4oaj8dqRGhZhxmK4TRCioKOPJq4d7q3nx3g0IJCQkJCQkJW3Eo3TrCrDLWriMSYviBWr9SgoVhnncDfGcOQHJDE00JCdth2kXolUqtT+LS0DwXQmta1PwihTDdlK7dxZodP6G1srGpfVvZNCwvxJEWWYhS4dsSM2XaBeleUClzO9M+vqgZCLKpk7mL7EjX9Sg3+ttzGwTZl9EaHl+z3/NeL5Zt+vfQ2uvf5x2j36T9/rXvBY1ZW1IPb7CaKkUvaMxanzpD5/u8yqbAmmPWQK9Rjg7KhYm9Axnjv9L9r84PIqyVvuAE60fcZhAIfmKgomYktjcTY21e2YJeN2UsB1vCg6BwMI8Ef/ah+4xg+7tYTELsGcEmF4cetwPYw22sxewJeYdX21LwvLLtdLQYWeexpQEPInkjzgTUj9lTMr8xSB9lQwI88Xm15QtuQ0aV+52X6hRnTKHKegpToHnm9AV2x/ux5iTzbtPdxwfLEEs3H26+ztkvqgWK3CXKp6xhNJbhnS0ig6CE54C5YDOeMgu2rAu2gfVnOce617pt/RdUtsUIZSczSvCdS8Fh1yS2w859y3ja5ZOksxEFZEGXtSDG/x/UXRYgaRfkX1pGlmIXD7bIv5XsXny8F/4AAcqELQ=='
_TARGET_BITS_PAYLOAD = 'eNrtWc2uoyAUftT7ABOnu7owEx+pq7EL0vAYTYYgDzCprKYsDHDhIOIPtia2094bvia2iniO3/njUKWx0jH8IFk4ac3n7XHQR/moZ32Qn+jSNNmR0tPFnOe5H/mzJ1l3NpZ21sQwWRLzc2fZovSulH+6ig9wHRFgUXZGwZfpSKGlMOMwG2ulV1BRw5GVC/eW9+a7G7BOSEhISEhI2Ipz5dYRZpWxdh2REMNfnfmVEiwMm6YbYFdzAJJzkWhKSNgO0y5Cr1QhdKT7XDQNpQiJumB7QqnpplDhLhb8tIPWysYm8m1lnvOmpidRtyFKqW9LzJRpF4R6QRVp7Ez7+LrgIMimTu4u8pNY16Pc6G8PWRBkXwYheHzBf817vVi26d8DIa9/n3eMfpP2+/elFzRmbUk9tcFquKK9oDFrfeoMne/zKhsGa45ZA71GOTooFyb2DmSM/0r3/3B+EGGt8gUnWD/iNoNA8BMDFQWXsb2ZGGvzyhb0uiljOdgSHgSsgnkI+LMP3WcE2//FYhLizwg2sjj0uB3AHm5jLWZPyDus3JaC55XtiqLFyDqPLQ1qEMkbcZCgfsyehPuNQfEoG0rgic2rLVtwGzmq3O+8VBeq5ViX1lM4Bs1bpy+wO96PNSetd5vuPjZYhli62XDzdc5+XS5Q5C4JNmVN6bEM72wRGVInPAfcBZvxlFmwtV2wDaw/yznWvdZt67+gsi1GKD+aUanuXAoOuyaxna/um8TTLpsknY2oIQu6rAUx/n1QdFlApl2Qr7SMrOg1HmyRfyv5vfh4L3wCSrbs+g=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block010_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
