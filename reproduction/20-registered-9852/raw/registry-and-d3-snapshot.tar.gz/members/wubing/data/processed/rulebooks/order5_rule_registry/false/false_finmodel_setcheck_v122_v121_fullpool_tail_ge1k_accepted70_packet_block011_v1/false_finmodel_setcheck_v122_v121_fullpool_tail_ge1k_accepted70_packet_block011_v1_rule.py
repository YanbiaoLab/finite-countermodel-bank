from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,1,0,1],[2,1,2,1],[2,3,2,3],[0,3,0,3]],"priority":851,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block011.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block011","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWc1q4zAQHgkX5J5k0wdQjBfyGCL4YPfUR9KCF9JbavYB+qirkRQna0ndhHjMHjoUpbHifJmfbzQz/sU1gB44WPnd4qoZrjC6VbsVXqBl+EZz97GpbxoOkXy2H11dVfEG/Hhvp+MxsbEf7D1dEW/ooXlvmyZxy2sNaXmbMhuG68w9L5k7QBVSA0vt7AxwkdoQLPNdGlRmh4P4UpXYzmZytjrFdvaqmHaKVXEv7Ukvzex/sGKR+SX0qBD+GVzwnfGfxeviSrXIY+jPEb0tq11z6EZ5EEAgPnAckDNG03SdxTxkvfCQ+Ph1QOgTq9ZRVNVB7CjAAo0cUD04tdCUYldQoHk2O6C+eUe10JRiN1KAmambgYa28hFytGCSAu1tugBhaAZTjpJToL3WM5ALTW9KG/8UYN9k+ybbf0k22EY82dg2YPlahI5sxUZo2cqMhmwsXdYADdmc85AD9GChMNtIsqUuiTzDgLVfiVWkdaAhZblmFyB0oCRl+R5atp0hn9x62iZSPsNrz7dAG21XpGw/YJsJoQz2FhwKIAoUI6+ACgkIbACIPCn5BcgEtWS2p3tUDldAMqiFmDRkE1dA3KulfatHIIIh0FaSbdQpJDTZyIFNyBbQtrCm8V2+OE8MaDWUCyDaXMl9zpjRSONFe6BiVktSoolgvxrI+HxLGUnRxuXnjBRtXHbcqQnauNCzJXYo2rh8z0YxM8kObtV5lLEi2cNIOyHzKGOLMtLNYy0HANCUq5aRabKtXvDlJ+F1r7jmZQdHkMz+u0byHHNHqAPq1U8BFTTQwRqjJ5NlkAOyP2TNilJmT5dShSl8t16qzj5a8OP+dY+EQLZEMkmkzsSl++aJ+2FOUSxOyPDPS/cdRE/nFBXFCE/k6HJ5CdOMunna8cWzmiIK1rKVS3sxxnlR3FqEegwTf7PKhc3fl9Q9gZR/cpXJ0Q8dBtkHaOkc/eBh8HyOtUSNkM7RS1PeMQ8LedalqEWG0cATOTpyruvwbgQUlxS1zDBlnKNFIsbuMe0fZVTrsw=='
_TARGET_BITS_PAYLOAD = 'eNrtWc1q4zAQftQ+wOLNrYEaVo/UU+2DCXqMwBpHD1BsnWpBjTSrkRQna0ndhHjMHjoUpbHifJmfbzQzftEcgFcarPxoceUGVyjdyt0K79AafMO1+1hRd52GSJ7an00/DPEG/H5ui/0+sXGs7D3NFG/wqntuuy5xy1sPaXktMhtM88w975k7QEySg0ntnBholdpQJvNdHERmR4P6UpXYzqxwttrFdvaqsLaIVXEv7Y4vzex/sDCR+SXUqBD+MVzwHfOfxevqSrXIY+jPEr0th1N3aEp5UEAgPnAckDNG1zWNxTxkvfCQ+Ph1QOgTq9ZeDcNBnSjAAo0cUF85tdCU6jRRoHk2O6C6e0a10JTqVFKAsaKZgap28BGyt2CSAu21uABhaAZTllJToL31M5ALTW9KG/8UYN9k+ybbf0k22EY82cw2YPlahI5s00Zo2cqMhmwmXdYADdmc85AD9GChMNtIsqUuiXxAhbXfiFWkdSAjZTk3FyB0oCRl+RFas50hP9262yZSnsJrrbdAK21XJGw/YJsJJRj2FhomIAoUJq+AJgkIzACIPCn1BYgFtWS2p3tUDldAMqiFmDRkU1dA2qvFfatHIMog0FaSbdQpJDTZyIFNyBbQtrAm812+Ok8MaDWUCyDaXKl9zpjRSOOFe6BpVktSoqlgvx7I+HxLGUnRxuXnjBRtXHbcyQnauNCzJXYo2rh8z0YxM8kObsV5lLEi2cNIOyHzKGOLMtLNYy0HANCUq5aRabKtXvDlJ+F9LTTXYwN7kMb+u0byLHNHqAOqxS8FA3TQwBqjJ5ZlkAOyP2TNilJmT5dRhCl8s16qzj5a8OP+dY+EQLZEMkmkzsSl++aJx2pOUSZOyPDPS/cdRJ/nFBXFiE7k6HF5CdOMuHna8cWzmikK1rGVS3sZo/U03VqEegwWf7PIhc3fl8Q9gZR/cpXJ0Q8dBtkHaOkc/eBh8HGOtUSNkM7RS1PeMQ8LedalqEWG4aATOTpyruvwbgRUlxS1zDBjnKNVIsbuMe0f5x2FdA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block011_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
