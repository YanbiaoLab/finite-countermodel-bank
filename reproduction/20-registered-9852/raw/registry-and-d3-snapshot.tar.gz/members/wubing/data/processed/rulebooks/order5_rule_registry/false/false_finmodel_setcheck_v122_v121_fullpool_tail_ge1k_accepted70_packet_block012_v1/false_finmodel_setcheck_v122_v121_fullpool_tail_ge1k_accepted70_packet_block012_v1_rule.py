from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[0,0,2],[0,2,2]],"priority":852,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block012.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block012","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmTFOwzAUhp/TtISqRR0yVIIhA0PHThWjFyTGjAwMOQADRzBiYeQIHIEjlFt0ZOQY2HHjxvGLE+IiVeh9Q5zmNY7t9/9O9cpAEkMHMaQ5AAd4YUD8PQvdTFdy0dm4FhC62RbysJzZKdrfA5BbfWW6WS/lYTKqR/a53E4ANs2Ep/u4vDuBYi3PZhMViHRY1MY6U1cXlDSCIAiCIAiCIAiCIIj/TGtZMOdM17EOrN7lYZwOf1jWGilLYnaNUpWtxGfA1DzF0bGcjH1FRAABM6vqewi1GlwFUtL7HZ6i3Qbgo5HUS4BdiEYibzTNHdmEwP1he9XsSuoAkvaQU4/FZHMks+kHumYL4VTMJuYAj/YlrHB9HLOZyTTMFsIpmW1j9b0rRkcxG7KxK1eLaGqtA3eGlzEeiTL11yY3cZfZEK0pV5d/jdSziCT6C64qvQmjhYXXbMjGXr7Z3G8n4W82ZGNHzAZrJNFi9GT0VoUi7jebqzXEbCX37UN/0L1tbzvMpqbI4o7fA4hsFHfm7Fx/fJPS8ZlNrUDhurpbNonZZFm1Ad7Amd9s/NndwHrKZoDZlAtEQw+9ZJOZMRrxH/zQZrY5EuonG/Gt29eLHnP7Aa8bO0o='
_TARGET_BITS_PAYLOAD = 'eNrtmTFOwzAUho/ByNhb0CNwBI7AyILwERg4QAYGxoxILB5Rp44dGDKA1CFDRKsS2jR+2HHjxvGLE+oiVeh9Q5zmNY7t9/9O9SpAUkAPBaQxAAe4FUD8PZluVjO56GLTCDDdjCN5mC/tFO3uAYitvhLdTOfysN42I7tcjtcAk3bC011c3p1DNJVny7UKlDrMGmNdqqsZJY0gCIIgCIIgCIIgCOI/01kWjLnQdaw9syt52KSHPyzpjFQlMbtGqcpW7CJgap7i6EZOxr7CSoCAmdX1PYRGDa4GKen9Dk/RbgJw2UrqB8AoRCOlN5rGjmxC4P6wvWp2JfUA8u6QU4/FZHMks+kHumYL4VTMxhYAD/YlrHB9HLOZybTMFsIpmW1i9T2KtkcxG7KxK1ezcmWtA3eGlwhesir1byY3RZ/ZEK0pV1d/jTSziCT6HN5rvTGjhcxrNmRjr95s7rfz8DcbsrEjZoMpkmi2vTd6q0Ml95vN1Rpitoqn7qE/6t7GLz1mU1MURc/vAUQ2imdz9qU/Xkvp+MymViByXd0vm9xssqLeAF/h2282fuduYANlc4DZlAtYSw+DZJOYMRrx7/3QZbYFEhomG3am25vPAXP7AZ1WNew='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block012_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
