from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[0,3,3,3],[2,2,3,3],[3,3,3,3]],"priority":854,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block014.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block014","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZGBgaGAgBLacBJEHDjAyjAJ6gAvbbudtMi7GlGj4DwbsmDJ/uot+2c8TwJRI+PvB2e8DPxZb5BkY/rFjs34DOLpXRfYEOrEwMEhYgG1mLmCoKGDgY0CY5PBAoIExgYFjNL5GwSgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCoY9yN39dtvu3dvvlpV/3zb7zZk7d/caF6c/m1d8jpkGlj34jwvQwmt/cFkmTwPLGnB6jRYB+QGXZfW0CMh////Hf3PTWf//dedfkCU/vP4DmUvPC7DRwLIDOAOSFmPYP0AGn1/////8/1/BlpwF+bB+308xWgTk//8delqKU4JdElv+gazhWSjg9LGlSYmDiQaWJfz9cpn/P3/dj5f/D/pbHrX/VS/wn+Mf4w+aJEj6ZzYLBxuLB/WN7GBLHA/8r29gZ+jgp4XXPhT+AJoOjDx+hQcN/xnlOMCpRp5BgYE2mQ0lTGmSoeHA4Xbe7pPnznBiymy6tW7drbLJc2euXl2Wtq4norinMDI3PDwXpPxqqLVxuNsay2MWQBNIzWzYfIQ7zyMDEiP3/6I5//rVWbA5Y5G4k+VfeX+NJ4EnFgMTTw3L3/qL3AtBykU+aTy5+P+/gl0TqZkN11yN+N8PHx60z3kgb2PTUC/wiaPhf2N3XUUFWLmc3AF7jkqWA6RWfzVAT2DNVw/AgfvBHpaUmGEcmHIyStGGbXdB6eB01u5dWbd9gYlh3a2ZO42Szhoeo0WBTOeazRWUDl78747jePql3mbhBHfF/n//2T8KstCiZvv1EJQOYr4cPtwsX9RU/+EDwz/HE8o4pvIortnAUd8Ajm9YAvsByUPAVHEATTW2qcADJNgGALxL/j4='
_TARGET_BITS_PAYLOAD = 'eNr79/////r/hIC3GYi0t//3fxTQA+h7qkz0PdODKVHPAAY/MGWYS3pZDyS+x5SYz8S/ZyP/Byy2PPj/n/EHNuv9wdEduqx43d7f//8/Pw62+U////b+/x//I0zaL/++/t/8/99H42sUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAWjYNiDSS5Cni4uHkqdHRyeKcLGykpOZ3pmSCb2GP6hgWXyDLgALbzGjMuyBzSwrB6n12gRkPy4LGugRUAyMjAs4Nx5OYBBpIwJZAn7VgYgM8rg/U8aWGaPMyBpMYbNDjLYIICBIYGBC2yJEciHDY5sL2kRkAwM5Rev3stes3teNSPIms9x7/fyVdfe/f6XBpbNZ+LW+cDwoZFdjMFuwzGrA6wN7xm+M/5jp0mCpH9mO77/8HH5hrofYEv22TM01P/4X/6BFl7j72MHmg6MvA/35esZ/j38Dk41D/7f/0+bzIYSpjTJ0HCwX2Wii5mh8TdMGV/VwEDVzpyktJCQzpmBxct7ivuWTVqxYhJIudaqI2dW7Aw+ZnkcaAKpmQ2bj3DneWRAYuQyxCYzFtz4jc0ZsS/2HmN6sOG69DrzGGDiaf7N1KD3JQ6k/DXvdWk9Bob7B2tJzWy45mpeMPHzy1ckyz84fLi+4T3v93qGupLG9naw8ocP7Q98b/ttT2r11wz0BNZ8JQ8OXP4DsKT0B8aBKSejFK33VAKlA5OpLq5TVTYBE0Ogaprb2blG5yxpUSDTuWbbBUoH4gwlC79LcTccjsvfca+AkeEH37vftKjZWOVA6WAxt41NzYPe2gZ+/v+M+8zv4JjKo7hmA0d9PTi+YQmMHZKHgKnCHk01tqlAexJsAwCQJnLp'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block014_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
