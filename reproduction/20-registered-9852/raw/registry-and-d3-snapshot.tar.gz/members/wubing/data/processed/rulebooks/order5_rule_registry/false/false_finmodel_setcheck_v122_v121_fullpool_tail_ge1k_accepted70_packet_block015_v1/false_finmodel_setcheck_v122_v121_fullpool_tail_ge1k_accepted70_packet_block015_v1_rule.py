from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,1,3,1],[3,1,3,1],[2,0,2,0],[2,0,2,1]],"priority":855,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block015.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block015","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2DEOhCAQQNEBjaFSjsAxtthiSu/jBTyqR/AGu+AaLYiJJm6h/lcwCUMoJmEIGLmaahoHI9gliP+FqDx363U7S50B4KHGrQu5/3RUBzfXF1N45Zl3fjDqfFVDCQEAAADgf282qym06fM6PdLCktF8cdg1BQC34UzpdSMlc99cGqF1GlunceLjlM7JI77QPghy'
_TARGET_BITS_PAYLOAD = 'eNrt2DEOhCAQQFFv4BE8qhfwPpZTbOExOAJrRYwLI7hGC2KiiVus/lcwCUMoJmEIBP03wzxWQXGIUfsN0Xjt1tt2njoDwEOVexdyXTRUBzdXf+bQ5ZlXfjD6fNWbEgIAAADA795sXlJo0+d1eqSZNSP5YnNoCgBuw4XRyk5Kl765NkLvJLbO4NTGKVmSZ0x8M2jE'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block015_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
