from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,2,3],[3,2,2,3],[2,2,2,2],[3,3,3,3]],"priority":857,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block017.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block017","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmbFuwjAQhs8tUpha1IkBNVHFAzAyoJKBgcfgERg7IOFH4JH8KH6EjEyYJK6qEp8tW7E6VP835BCX5HLnu7N0FhTDhJbtVREVBP6AmRVv+6FCil4o4SzE6Vua54HiYMVRieEjpRXKuB8w/fV7TvrH/MPL6/47V0QVSawZAAAAAAAAAAAAwL9G+BSX+ombY43i4NWsdXspFlmtnbwaaVq3m21OY9IbSN3N3hbHrK41Xmt0K/jB4AhuJqw1JmMolSmD2paMs+yrX9XNY/U5ayBN8HWdayWKLabYggknu0C+otgiqK3YV46LM7fzM5tBRbtJvLW5FVwvdEuazU8t4q0FDkmYNd5mKTbmrIZcP9jNQBbpxeYcGfEtc2SxWTF1NUzaLC/OXR+0S7C28uUDF7WXtfPXO20SrH3arDpHRY277ZrQaJQvH7i06Xv0I1/UJO9sffPldjamRw/dTWk0d1MCY2E='
_TARGET_BITS_PAYLOAD = 'eNrtmbFuwjAQhs3EmEfwo/iReAQjMXTkEXgMBoZQdWDkAVCVVAxMFe1EJFpfkxihEp8tW7E6VP835BCX5HLnu7N0NhTDlQ7tVRE1BP6AsxXv66FCm14o4yzE4ibF10CxsmKpzPCR2gol3A+4/Pp9Ink3//Dysv/OPVFFGmsGAAAAAAAAAAAA8K8xPsWs/ObmWKNYeTU72V6aY1ZrC69Gi9btYpvTmPYGUnazt+Myq2uF1xpNGn4wOIKJCGuFyBhKJeqgtiXjLHvqV3XzWDnPGkgRfF3nWo1iiym2YMLpLpAfKLYISivWlePi2e38zGZQ0eYab+1kBdcL3ZJm81OaeGuBQxJmjbdZio05qyHXD3Yz0E16sTlHRnzLHFlsVlxcDZM2h5lz1yttEqztffnARe1z5/z1Ri8J1p5tVs2josbdNk1oNMqXD1za9D36kScqkne2vvlyOxvTo4fupjSaH/lvDdU='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block017_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
