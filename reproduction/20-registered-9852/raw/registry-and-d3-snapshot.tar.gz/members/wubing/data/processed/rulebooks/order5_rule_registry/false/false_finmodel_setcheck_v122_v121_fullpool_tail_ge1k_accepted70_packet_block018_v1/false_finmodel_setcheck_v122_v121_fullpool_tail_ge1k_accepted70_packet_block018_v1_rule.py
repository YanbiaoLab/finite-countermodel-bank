from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[1,0,0,3],[1,1,1,1],[2,2,2,2],[2,3,3,3]],"priority":858,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block018.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block018","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmUFqwkAUhich0JFSzGihuxqnKekRXIgGmVJd2QuUXsOCNClkEVda6VLsVUJXPYYVD2B3WZROM4ktVJO0wQSMzLfIQF7k9/3xPScvDyL4YaKBWHQA2NXHYAwSUjGpEBq46KiPhEibAceYU62BQRqYol4CueJ6tbbFf3+kvlrv1gNK4K400tcj37dkw37ZP8JddqjW9e+sNnVtwMkLJjVYJbrUo8N+m1jMUG1JD9jCxCp7ZqRDqeEtHyw31lqXmWZY67IubbFiG5ESQhgTYttyCwpZqJ0P1LEdCI3bGLeIZUOEWrCahdiMPjOhT89Go9Tx00JV7IlJWahNtGlvfvZS7vZJbz4Ywgpq4D5xq1Y2xUapJ+QXG22+ozdKr6whbFoyb0Sc/SfYzjqs2LgZuUHv4IK3+H84KtuLIoGbwuFwOBwOZ1aP2xLoJzeLS27S7nEfO+uR3Ns0xZxg9hMVLVMjvw8FxfjwItUNsxI5CGFjBF0spOrjExhDJbSqS4IE2ngAAUIikFIZTpvx7zEEFaWZmhz5nf3zXnrsBUta/DFXNXPcR4LRf4iboY/6cM+yzytmokn/SMpTbqeJGmpxOzE9SesT28p2aiuxo5DQYeTVv3hNoPYFk8V3lA=='
_TARGET_BITS_PAYLOAD = 'eNrtmUFqwkAUhqd0kV09gFiP0VXJVSouS6orswg0KUK9RukF6iopDRLFhUdoqB21u0LNREpxCiGZZhJbqCZpgwkYmW+RgbzI7/vje05eLl3yQ90kiRiE0KvfiEBSMpOBFxl4VMcXuu5sBnilAswBJFkgu4ZFCsXdatXcf39kuFqv1wPT0F2nYaxHvm/Jhv12cMS77NCoG9xZs8aJhFEUZKDQSuSAj0p/m9DNUa0EPulCxWZ7ZiQPgOIvhzQ32lpLuWY46tIuLdFia+gWQhDquijaPezlofbUGgtiKCRoEPZ0ScQI9fAkD7EqOKNCB76NiqUGaaEJ9MWcPNTqZq1TeT6dd9t6p9Jq4hkawLbOTaR8ig0AXygoNtA/QscA3EtN3Jds1ogY+0+4neVpsTEzCoOhwqW/BH84Y7oXRR4zhcFgMBgMRnWYtCUwXm/LD8yk3eMqcdbjcDdZivHh7CcuOgdKcR8KFsnhcqYb5mnsIISOEQx3mamP50TA08iqtjyHaLCFCUIucTIZTsvJ7zG8McoyNTv2Owfn/fToC5as+GOuKhe4j4Sj/wg3Ix/18Z5lX1TkVJP+hlOk3F5SNdTFdmJGmtbnatPt1FZi7xGhj9irf3GSQu0LuKz5kw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block018_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
