from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,3,2,1],[3,0,1,2],[2,1,0,3],[1,2,3,0]],"priority":860,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block020.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block020","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt0T1uwzAMBeBHQQHUTGyRAwhFhh6DQwaPPZKayWtuHFIy5E5BgnZ8H2Doj6ZFWgC0jFeccerjuwAmMSupb9TazIfcYMixpR7wONdynFO9pSxzZWotUkIURSPr9uADuPikrWPcqSoSJJlfxEPTPIj6/LLfffG1bb71Ug4zaF3kuueqI4WW+GpkSra/9+kbdhnjE8zwE02CNJTci0LrJ1cU7xSkNGSvFH9xPpzWsuBfVGyN1bhrKVW3NvQGj1884masgoiIiIiIiIiIiIiIiIjotztSIBJv'
_TARGET_BITS_PAYLOAD = 'eNrt0T1uwzAMBeAbd/WU6EgdPWTgMToEgQ4QtJwSARHEV1Iy5E5Fi2R8H2Doj6ZF2gCkiv8449rHLwPEYlZa38g5iQ81QVBjSz3g91zrbU71rVWbK1FJkRKmKBpZtwefwMknaRnjTlXRYE38Ih7a5kHU55d974uPbfPeS3nMoGW1w54rjxRa4quRqcn+3sU35DTGPxDBMZoESyi1F4XUTw4o3ilYSaheKZ5xflyXsuIlMrbGaty1lKxbG3qDxy8ecTNWQURERERERERERERERET00zf6UV7H'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block020_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
