from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[2,2,1,1],[3,3,0,0],[3,3,1,1],[2,2,0,0]],"priority":861,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block021.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block021","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmDEOgyAUhoHYhG7iCZQw9BjEMOjmkRgc7NaaHqBHLQ83i41Dbaz5vxhIeIM8eMr/w9nx8cIW6cjDjLuccTdNa2y0Ftu9peJTn80DOWtCK+nxn9Y1tpYBAAAAAOyEh4nypGidO1pqXVCG10G2Ril+sNQsL8+hMyEvTxuYb5rhpTV35zI2xkqhkS2L5eTJb9yyKO0Fs+HFTCl8qQAAAMAKnuHMLpLnJl2Y1ST4hiFXla5llX1BRi5cw0VlGXWYUlo7J6seewMASHo20WifjEhqyOVYrNIqzxa7d/ObsPqpIdfTHzucDes821KgEdgK8HtsGwvPMi4T6mdWlEKW/5TbC4bdJ/I='
_TARGET_BITS_PAYLOAD = 'eNrtmDEOgyAUho/aAxjbrQ4OHMlNB9JwjA4EPYG4laQGKA83i41Dbaz5vxhIeIM8eMr/4/zxYVb06Ugm813OuJqmlTdK2e3e0rqpH+eBwTehNfSwT+saW+EBAAAAAHZCJqM86WvOj5ZaFZThtTC11NodLDXhukfoZMiL0QYOm2Z4r+WZ89HnsVJoZMtieTLyG5cxSnvrRXix1xpfKgAAALCCUziz++S5SRdmNxJ8RTHoVt1MO35BRi5cw0VlGXWY1kpxbtoSewMASHo22yiWjBhqyOUIrNIqzxa7d/ObsPqpIV7SHzucDes821KgsdgK8HtEHQtPeGcS6mdWlNZ0/5TbC8WUSUQ='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block021_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
