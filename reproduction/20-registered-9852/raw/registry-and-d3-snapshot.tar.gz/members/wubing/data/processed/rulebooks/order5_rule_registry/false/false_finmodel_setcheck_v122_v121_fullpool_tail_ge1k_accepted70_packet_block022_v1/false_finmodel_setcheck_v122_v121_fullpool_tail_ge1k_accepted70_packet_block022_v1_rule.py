from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,0,3,1],[3,2,3,1],[0,2,3,1],[3,2,3,1]],"priority":862,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block022.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block022","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmbGKwzAMhiWhwd2SPkEaMvQxTMnQbH0kD7d0uzvuAfKolePkKEdTWhIftPzf4oAgfyzJMpGYDO/oETzft/f62d627ALJYxpgbfqm9DNRYZIlbw4pK+DiDAFj+j7W9cFWclRQlU3tQ8VVFsSNqksqQvoejjzRsbals+1UZ3to2+jKXFis1AIVov8KHw8H53Old1dCkjLEjwcSAAAAAAAAAADIxW7OMPxv21+qwEcAvB5989Vuy/KGJXb0/dSgXImfZmx7KuXvRobx86MQxyZh1hZaIbFnl4SSSs6JiBA3lFr0mqLD75KR+2d2It3Smy3M3l1T7gDwf/iunilSVxMjWmti5DZDcWf9W+KHidGvylijl1a0C6IHHPk='
_TARGET_BITS_PAYLOAD = 'eNrtmbGKwzAMhh81D1Da227p4Ee6LR3C4ce4IaR5giZbPQhJJ8dJKUdTWhIftPzf4oAgfyzJMpFEDR/0Ebzctxf0Ud22HJ3yYxpgbYq68zNREeUlb3YpK+DiDAET3R6a5ttWDdprm01tTxxaC+KZKCQVVnoPR37pobGltO20n/ZQVdGVubBYkQXKRf/1Ph4OyedKH66EOGWIHw8kAAAAAAAAAACQi+OcYfjftr9Uho8AeD2Keleduu6GJXb0/dSgXIlNPbY9SfN3I934+VFIYpMwawut59izS0JJJedEhFVqTS16StGRd8nIn2d2wuXSm83N3l1T7gDwf/iymSlSVxMjXWtiFM5DcRf6W+KHidFFZazRSyvaL6pqVD0='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block022_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
