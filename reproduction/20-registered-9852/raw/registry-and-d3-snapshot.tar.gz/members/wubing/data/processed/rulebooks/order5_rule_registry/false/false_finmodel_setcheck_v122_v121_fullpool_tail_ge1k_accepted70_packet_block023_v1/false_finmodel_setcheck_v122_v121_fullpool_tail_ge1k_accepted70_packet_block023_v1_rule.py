from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[2,2,1,1],[3,0,3,0],[3,0,3,0],[2,2,1,1]],"priority":863,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block023.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block023","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2LFuwyAQBuDDYqAboD4AQVTqYyCLoe7kR3KlDGRLeYI+agFbldw6zdAgNdb/yfKQU3J2kO/wMbo3rzRwuRUY6aWjfRjnG2x8O08P5WxOztp1YM4urn1/Ip+v0NeDEwAAQPtNgCbHltZ1XnrP9y52M16YN26JS08T15GkNMb7qVF7fh5qb3Upxr2t2gc/B2KUhCGvGacYJZmye2jikVJZPJ1PdWOoFJ4bAAAAgPvcRrr3S+Om3UwAAaCtKQU9hLBVRuwpisEpdbB9OEZxOMo/ZxtT/dWNSE1URhkh5DdilZOhiv1iHpBQGQCt+Z+rWd/+AZrqLwWkJ3brZH7ovkrUOpILjO2ufrSUmV6w//dHfgKLAyrN'
_TARGET_BITS_PAYLOAD = 'eNrt2LFuwyAQBuBH7RPQbGGIVD+Sp9IBWTxGpSLCA1SGrQzIXAFbldw6zdAgNdb/yfKQU3J2kO/wJbo3zySi3wr09DLRPvTzDTa+nbePcrZHbcw6MGcP177fkcpXqOoRCQAAoP0mYCSdltZ1WHrP9y52MyrYp2goekVdHDl5b61SXaP2/Cpqb9WM872t2kM8SErEgiU1pkice7Jl99DEO7GyeGM+1Y2hc3huAAAAAO5zG6kfL42bdjMBBIC2OiZHIeVWGTFHHoR27mwGeeLhfPJ/ztaz+qsbkZqojDKkzG/ELidDFfvFPCChMgBaUz9Xs779AzQ1XAp4RenWyZSYvkrUOpILjJmufrSUmSGk//dHfgLBbkZp'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block023_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
