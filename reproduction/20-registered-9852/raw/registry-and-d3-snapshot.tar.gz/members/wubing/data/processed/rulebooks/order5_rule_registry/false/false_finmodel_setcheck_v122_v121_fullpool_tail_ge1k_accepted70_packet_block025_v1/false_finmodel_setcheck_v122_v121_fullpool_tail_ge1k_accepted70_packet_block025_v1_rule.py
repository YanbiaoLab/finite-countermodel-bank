from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,3,1,1],[3,2,1,0],[3,1,1,1],[3,2,1,0]],"priority":865,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block025.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block025","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmM1uwyAMxw2iErnRPgGLMmmPwSGHdKc+EocdyC2L9gB71NkQSJp10rRmUrf6JzXNR2tjauw/FbDGVRb+JKcxvulGiPMH3jgQarpQyycKDhSxxENHUe/FbYRi5OLiyjFZGNxkzqulXdgJZeBa4wzDMMx9c0qt5XNL8SA1T8/3eTo2r237QqexcUt8aZpBR7e6ug+aBI5Sm3h77JsxhAGFgTAuOyHF0UkRQFs8r1EmBe7098tzXNW2BwkKk8RTgki4nH/a+pQ/P80XRxayI6wc6BiiT7Rd1LCBS2p+G738i+x8GbzMaw3SqsbDEYOxMt9s9lg6G/p4iafO4boSdigmHtbO3mFos6ODSDXElgnCXzPVEJNqNFUbsirzDmEe3OyjbKwsGF4WDMMwzL/mDVXIF2Kmor8NKx1bc+qLfhJGnueNYW4bP7Zn24p5lXe0i6lo0zPrcePW369B8SQyDMNswgd3aCRt'
_TARGET_BITS_PAYLOAD = 'eNrtmM1uwyAMxx91DzBluYXDDjxST2sOOfAYkxZlPEHLLUhF4NkQSJp10rRmUrf6JzXNR2tjauw/DbBGjRr+JLsqvtk+hPMH0igIbrpwyycODhSxx0NLUR/DbYRi/OLiyjFpqNVkTrqlXTgFZ+Ba4wzDMMx9s0ut5XNLkeAtT8/3ed33T133TKexcXt8WZpBRbfaoRGWBI5zm3h7a/pKiBqFQTAqOyHF0fogwGo8H1AmCe7098tLXNW6AQ8Ok0RSgni4nH9Wy5Q/P80XRRayI6wc6BiiT7Rd1LCBS2p+G738i5xkGbzPaw3SqsbDHoPRPt/sj1g6e/p4iWfI4aoStigm3tfOHqDusqNDSDVElwnCXzPVEJNqNFUbsurzDmEe3OyjbKw0GF4WDMMwzL/mEVXIF2JmpL8NRxtbc+qLchJGkueNYW4bWXVn24p5lbe0ixlp0zPrcaPW3x/A8SQyDMNswgfVCUzJ'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block025_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
