from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,1,3,1],[3,3,0,3],[1,3,3,3],[1,3,3,3]],"priority":866,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block026.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block026","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2DFOwzAUBuBnK8NrJ7vKwARJZFXlCEyEKEPXblyAC3RjqgdXssoEM0PhBByhM6fgIAiT0gJLpFYIq636f1Ksl/hJv6L4LRFEZAkOnhHKM7dszLPMGpItOx2iou05DWi2KtRyYU4slet7SeK3L1tfAAAAAAAAAAAAcOw+wk/5HkKYRA1bvHa+S3s37t4mUdOG+iYd8ZPvd/N0VOeu4ulJUyZXKkbaebH8b6t0UxazgfvKyF2kV5ub+7qndbPWzjx4r3ReVLVTFcdISxM5lJk1iliVPRKSSvKeiDE+e2wRzraf6qZp1f5X1xdi66l+e36sTgW+0O7ZcPl/R2Cjl7HEETg8nxDhOh0='
_TARGET_BITS_PAYLOAD = 'eNrt2DFOwzAUBmAjDsIpmHsETlA6MMNEZake3ImtF+gF2Lp2iEKYegQqZCWhE0NUe2rfENmPlBZYIrVCWFDxf1Ksl/hJv6L4LQnMrBmOnglOErVs9MpSG/YtO2vmvO05z7m/LdxmIao1Z7t7z+Grr9xdAAAAAAAAAAAA8N+diM/yVAgxjBrWOV9/lPp2tLqro6ZN7bia0KV8XhXVJClUSoPXpqwfXIy0p3zz39bZpsz7c/WeUahIr9YzN8nS2mZNlLmW0tkiTxPlUoqRVtV+6kttHJPLlhw8ZywlM2F8/rCOeDl8qpumbft33c/CwVN91r1KFwFf6Pdp8fhzR2Cvi5HHETg+bzufNxk='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block026_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
