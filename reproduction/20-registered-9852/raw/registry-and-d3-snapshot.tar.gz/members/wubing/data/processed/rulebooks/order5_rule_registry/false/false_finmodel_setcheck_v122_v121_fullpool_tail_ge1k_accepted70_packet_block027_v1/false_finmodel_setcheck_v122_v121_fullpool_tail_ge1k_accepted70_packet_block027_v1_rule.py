from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[1,0,0],[1,0,0],[2,0,0]],"priority":867,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block027.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block027","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWUtuwyAQHRALvDM+AUaOlGNQi0XcVY5EpCycXWr1ADlqB3BdpXHcVnGaj+bJCg6OGDGe94CXDYcB7xVMwr4Ajz/rVsZwmAPLpnpzTozEasyuMmaWIJ7bAh4K6y42s+T5UCkLDERuvz9ZZKLz2J6kP4cVfspw+am8atBC25tkKBXOturadu8KpYxxrm3zWrJrRFvshkDhndRu20qlalkC4U9M7FzROLcyu1Y2lVJlSmW5zSk3d4wnJtsBZ/YZKJQmTitUpSzFNaKlpbMeOJBSifVPZCMQ5iZb3EgGDlAyHgaW6QybCpcWH15grhglhUAgEAgEQn9mG3lyjWPcWbvT/s8x7mnwWoRTaNzNjZi+Z3xgwn2QLbfAgUsbDGGGtxJ35qddM5GtBiZA6n5cEUa2p10XozdI4qjRINHWeh8CRTAxq1Gy7pITo0HpTGjuHIZVgEHiXAIv7Oxk21Q6MUuCUvrLzfcPXJHLJjaDmBwLMvzYReb9LeA7cbRM8ynlp8VgwiBpjEcJREGUiQNJDnW/+4k6CTl+D2rCpb6UbHovBDQoUzr+IYuj54r5xCyrMxkVGUkWAo2pcgu/l9EPWICBcg=='
_TARGET_BITS_PAYLOAD = 'eNrtWUtuwyAQPWoOULnZxYtI4UhZ1Vkgl2NEioU5gfHOLBBMB3BdpXHcVnGaj+bJCg6OGDGe94CXjYMBLxVMQryDiz/LdlI6mAP7onrl3I7EKuSqknKWIMyJBh4K2yw2s+R5UWkBHmwrvj85dDZj2J6kv4Udfppwsam8KlBWiZtkKBXOusryfMkbraXkPM/b0vhrRDushkDhnZR8nRutS1MD4U9MzHhTcL6Tq9wUldZ1SmW9bik3d4wnJtsCZ/YZKJQmTitUpantNaKlpbMcOJBSifVPZCMQ5iZb3EgGDlAyHgbCqw6bCpcWFl5gqz0lhUAgEAgEQn9mG3lyjWPcWbtT/M8x7mnw1oRTaNzNjZi+Z3xgwn2QrRXgwBkRDGGPtwZ35qddM5GtBG/BqH5cG0YWp10XozdI4qjRIFFCMBYCRXg7q1GyzZITo0CrzirHOYbVgEHiXAIvxOxk21QqMcuA1urLzWcPXJH7IjaDmBwLMvzYReb9LcAye7RMuynlp8VgwiApJEMJREE0iQNJDlW/+4k6CS1+D2rijLqUbGppLRQoUyr+IYujt9qzxCyhOhMVGUkWAo2pcg6/l9EP8/HvtQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block027_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
