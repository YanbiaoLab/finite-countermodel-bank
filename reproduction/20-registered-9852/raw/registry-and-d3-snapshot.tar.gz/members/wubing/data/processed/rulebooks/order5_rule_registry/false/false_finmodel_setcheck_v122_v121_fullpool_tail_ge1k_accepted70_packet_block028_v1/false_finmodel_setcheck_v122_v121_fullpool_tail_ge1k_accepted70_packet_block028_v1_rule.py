from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[2,1,0,1],[2,3,1,1],[2,3,0,2],[0,3,0,1]],"priority":868,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block028.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block028","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWEFugzAQXFs+uDcT5QEuciWeYVUc4JYnUamH9NZEeUCeWjAmIbWhWDjQRDsHLAXhidfr2Vl/wBVb89QgwQ9NzMAgHrKSCT8XD55r1w6l86Kyo7uuT6BmxTUMH4H/gS4mRYS5zirR/l17nTlzZfNlDWSLspEKEBFQrZQtiJkqrQ55zvpaeke8fanjfv+tazWm/N6cEkSTkg1RQ1iXATFY/+bjVBPJXr15osMmxqsEYr4l2pR5zqW1KZFc2KAH4PLRN247+laRB17aDgrqt7rKkzau6KU0hI2Onnl6o2SzbbS+o/x6spywVv/dvzFVyQJEtrWRooupdqN2XTvrCIW7D78+BG/MJbPb4xScCxG7WZmYziEBgUAgEIilcf7DrpRR2diQ/9HwcimKWBCn2EgS2EByDNr6h00d8k2SjDcC0XBSxyJN3ylhwGWfU0PzU1yyyl75mJaaNYdYW4/PfTIwvS/y92zUtNRkGbWgQJ41I7MgcZhbDMav/jkK/+TDNlxgEQHQZToQSyOd7SV2NI3hrYwQ507SCHLsgv0DQHMpKA=='
_TARGET_BITS_PAYLOAD = 'eNrtWEFugzAQfGoeECW9NYdK5Um5wQFVfgZSLeoHRMG3+mDZWzAmIbWhWDjQRDsHLAXhidfr2Vm/wxUn8yTAwA+izSAhHopUcj+XCJ7r2A6p8yKxo7uuN1BmxTUMn4b/gS4mWYS5NrQi/l37mjlzYvNlDRSLsukEEBGQrJQtiJkqTfd5Lvtaekd8vtLd4fBCajVW4t6cDHiTkg1RQ1iXAT5Y/+ZjWxOxXr15osPGx6sEYr4lOqd5Lpi1KZFc2KAHEOzRN+40+pbqB17aETLlt7rUkzau6JUqhE2Nnnl1o2SzbTS5o/x6slzLVv/dvzFVyQJEtrWRvIspcaN2XbvsCLm7D78+BG/MmbTb4xScC5G8WRmfzsEAgUAgEIilsfnDrqRR2eSQ/yHwfSmKWBCn2Egd2EAKDNr6h43u83NVjTcC0bClu6wsP5SWIFifk0DzU1yyxF75mJZaNoeYWI8vfDIwvS/y92zKtNR6GbVQoJ81I4sgcZhbDMav/gUK/+TDNlxgEQEgaTkQSyOd7SV2NI0RrYxo507SCHLsgv0DDA1IDg=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block028_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
