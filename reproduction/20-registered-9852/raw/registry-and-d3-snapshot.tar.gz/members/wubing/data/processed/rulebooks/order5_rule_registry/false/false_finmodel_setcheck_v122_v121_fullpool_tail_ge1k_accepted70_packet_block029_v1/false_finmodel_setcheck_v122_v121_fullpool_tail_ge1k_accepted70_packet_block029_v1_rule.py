from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[2,1,2],[1,1,2]],"priority":869,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block029.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block029","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWcFupDAMDVEOmT0F1A8AlErzGRHKIeypn8RIrERv01E/oJ+6Tswwu5NkNbSYw6o+FFGLMXb87Gfzi5mCGRbkKfw1Llzedbjpub8I5u9MYfAmIx85BWuKjOLYZxSz4YRwVuik4oW59pBSDGfDDzalGQWXddIV/Warskxonl/1ZZqSrsAzVqRcaV912yYe+Vn1uiwTsVF4qVzkCkZFmSp2JejBociVInNqzyFaNTwTqf78kePt7u9YDeje1U22pxx3tZbNXwqZD2wnedc7GhsgSw67WcsWBBLp+EGrvU7OuHpgfDew5UobiWQrLA3YcoWeBmwX17Y7ndtwsVVv7U6uzS3LA6A+kafKD2xHHt36TZCDLVzE2ZhBVBM52MLheQyc6VMTOUAwRJ+aNRAXsMAdwz4gGWXBfGIXx5mpIJ6hD5RlkoRt2tnkgoE9Olt/xQAtyrGzAapbrs9GDJKVrGUjaWcDQzaADQxzsKlorMlD8IhVUioDB8eBJ0tGZIw1Jwb0HA3B3GE8gy6o2nit0ZCra0hNdKsmY+nY2TrfcFz7OkkPNmtlQ5Ilc2cLhvwE1bSdHScwRnJwL5ebIT/IWTtNqgRjJAeHM2Ew5EnXiKEcVUcCNhxNgyHfcBSGUnWSjkaOS2ebQ9lJkiaANHLpbB2GspMNIY1cMDCHUjbiG2zfYPv/wZb90bMnfPEe62tgy2r4lfBtKGMOwoYXgrn6NG0Ktpy1kCSZdeHnwZY9Tw1kIbO1/KxkF7dhXvSqYTskmAJeP6kRZ4Gbyw3rF9LI1HmKhfBtxyyRRibBBoYqByxPbMYs8wsSioqcXZAECrvbggTHOF2GMW7YtLPlwAbTFbuS9M06W6JWhHW/UMvssUVU56HC1ZE9FVf+RDPwCbuis12jFnvXx2/W5473UbAVWKKidE9MUn50jfYC68CW+1azpuc+DjZ8w+qBeCS/Eq1bkNz4wF1BJlmQLHzg7jUSTUF8LUP8gmThA3fpD/8rHqmbKzA/fxlNvGGidKooACt3APMHWl+i7l4jUTr5Q7H9h/wGeJvNIA=='
_TARGET_BITS_PAYLOAD = 'eNrtWcFupDAM/dT9gGrKrUhFGj6ppyWHCOUzRmrE8AEV5LSTQxSyTswwu5NkNbSYw6o+FFGLMXb87Gfz6sTkhAvyEf4KFi5PMtw01l+M83diEniTkR85hTtPGcWpyShmwwmxbpJJxZtj3SWlqAthLzylqYzVfdIV+cyHcUxo3l/koSyTrsAz3KRc6V5k1yUe+Tk0chwTsVF4GVjkCkZFiSF2JejBociVKXNq7yFaPTwTqf78kdPt7u9Y1eje1U23p5x2tZbNXwqZD2wneZI7GqshSy67WcsWBBJp7UWqvU5OsL52djew5UobiWQrLA3YcoWeBmwH1nU7nVt94EPD+U6uzS3LA6A/kqfKL2xHHt3y2ZCDLVxMIURthpIcbOHwPAYK+tREDhAM0admD8QFLFjmsA9oR1kwP9yBWScGiGfoA+OYJGGbdja9YGCPztZcMUCLcuxsgOrOykKYWrvRda4i7WxgiAewgWELNhWNNX0JHrlBayXg4CzwZO2IjLnz0QE9R0MwdwjPoCeqNt5LNMT6HlIT3erJWDp2ttY3HNa9lNqDjXN9JsmSubMFQ36COnctr0owRnJwb4ebIT/IcV6WagRjJAeHM2Ew5ElXhaGsVEsCNhxNgyHfcBSGUrWajkZWS2ebQ9lqkiaANHLpbC2GstVnQhq5YGAOpT6bb7B9g+3/B1v2RwtP+OI91tfAltXYK+HbUKochIWdjGP9sdwUbDlrIUky68LPgy17nhLIQmZr+VnJLm7DvOhV9XZIEBO8flJjCoObyw3rF9LI1HmahfBtxyyRRibBBoYGBizPbMYs8wsSioqcXZAECrvbggTHODmGMa7etLPlwAbTlbuS9M06W6JWhHW/UcvssUVU56GC9ZE9FVf+RDPwCbuis12jFnvXxG/W5I73UbBNWKKidE9MUn50jfYC68CW+1azpuc+DjZ8w+GBeCS/Eq1bkNz4wF1BJlmQLHzg7jUSTcF8LUP8gmThA3fpD/+bHqmbKzA/fxlNvGGidKooACt3APMHWl+i7l4jUTrtQ7H9h/wG09akBw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block029_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
