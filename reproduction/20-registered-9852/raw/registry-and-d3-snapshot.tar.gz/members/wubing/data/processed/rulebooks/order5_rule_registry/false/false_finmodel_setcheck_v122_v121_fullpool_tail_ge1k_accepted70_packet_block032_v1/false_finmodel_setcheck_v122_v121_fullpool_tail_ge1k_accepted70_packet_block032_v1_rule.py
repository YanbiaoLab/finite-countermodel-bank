from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,0],[1,0,0],[2,1,2]],"priority":872,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block032.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block032","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNprZECAKYwMeIEDhGJhIBn4MvBgl8jwZDDAbld00mxGNgaqgAaGoQYEIBRTAvFaTKC0BLqEggok1iZgaCEQ3UyDOYQ0mBlGwZADDWYOoDwtkWBND9subIOk8IThF5AO0gnajDwMOdtlZSFFKztNM5unykQXlxZeEPsAzf2m2qkyqaMDR2lGbbBAdWKokKDgttt5aWwM4DLFgIa2TdGd5KGkdIiBWYbhRloDI9BCNmD00ciTDduOhnnHuNzI271b8jaPAcODvGMMYDtHwSgYAYBQc3YUDMqajUEB3FwVGA2KUTAKRsEoGAWjYBQg9dl48Eo35z4YDaNBCG7hl6ZuL9jhNt7BY6bbQzggeelpmYLKBHzBTOVB4hYWIQ8FJqzdAkYWBg+FRg4GRqp16xom0DMgBRg4FOhnGxPDsAV4hv6xlCE8owXvoAANw9hvUtAiiihfU1oIOHjgkqHFyDUHhMJS5rJx41RNNgAAl7Uypg=='
_TARGET_BITS_PAYLOAD = 'eNqr+48A2f/+4wX7IdTv/ySDTf8/Y5eYvu3/eex2LZmb8u/nf6qA+v9DDbyHUH/nE6/lNJR+ji5x/zYk1vIxtBCI7r+DOYSu//k/CoYcqD+5H5Snn88/Qg/b9D0hKXz+8AvI/U/mX/n3+f9kj0ePIEXrD5pmtm2383bvrv4EYtvT3G+3ym7nlpfjKM2oDeJv5a16++6dp8rEmT//g8uU8zS0LftS7va7d23//3n8X31m/T+ghT+B0UcjT9Z7Wq3csni3+kQXl2cqn8//l59o+R9s5ygYBSMAEGrOjoJBWbP9vw9urr4fDYpRMApGwSgYBaNgFCD12T7jla6ZJD8aRoMQqOKXpm4veL8K3sHjvypDOCA/0dOy+7fz8QUzlQeJq3+/3X7/L9Zuwb/f/7ffr/v+/x/VunX1+fQMyPf/v9+nn21//w9bgGfoH0sZ8nm04B0UoH4Y++0ptIgiyteUFgL7t+OSocXI9XcIhaXM/fkFp2qyAQC0vD6Q'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block032_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
