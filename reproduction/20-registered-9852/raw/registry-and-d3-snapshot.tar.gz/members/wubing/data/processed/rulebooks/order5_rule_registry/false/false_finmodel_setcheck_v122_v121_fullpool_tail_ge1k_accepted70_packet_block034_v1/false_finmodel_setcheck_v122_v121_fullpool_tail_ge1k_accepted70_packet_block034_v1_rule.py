from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[1,0,2,3],[1,0,3,2],[0,1,2,3],[2,1,0,3]],"priority":874,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block034.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block034","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWVFyxCAIFYcPPz2CR/Fo9Oa1xhpThRDTbjOtb2YzO2sERJ4g+0amAo1PzxgNg48BSK+hcembTR9ngOrQDJIgnzWbIjGBNoGhsUsFX6zAfY7bBDZrhJAVHiTH8t5z4H1evs1egO23MCkrbLtzcPHmqLJ31M9Bvdd/CW73hz+O2JEHyoMkkcKCAfSWIU2z4c+DxA2gtJVuOemJZKskG5INzJckcH5WSWQTU4obnvxCUlCdjlZH7S5NXQTmyXGwDpgzX7KcGkXQbwpekaVOWS4rwmNgLHxHSTR0J45jWg0gLtaCmQ1JzSsvABY7YHedFS32dyrZ19aH3O4TezIJVDxjqbX64sa1ETWDWBUJo+pcEs/JNg5a9k5AKgZLZaRXzbhdRhb+2qjYb+qNWjXswsLCwsLDEPYkHEeJ1HX5XJG02SIC8Ufrnf8De+F66VOpvi6PzyBbJVk8rVqhJZufIRvXOIjqUlxfuNKmyHH1OKoPD11Ic50Yzh2KlVh+oCrC4xrojsuegM/Wf/c/z9Ab7maHomn94+rsz+Oj9Q/sRXVv/eNylYzYUBgGQe26o+E075JENhy3DLiDI17XseMdwlwk3A=='
_TARGET_BITS_PAYLOAD = 'eNrtWVFyxCAIvXk5mkfJEfz0gxFr1RpThRDTbjOtb2YzO2sERJ4g+wahAoONT2MCg48Biq9hcPGbjx8XCOrQDKIgmzSHIjECssCtsUsFW6zAfY7LAps10pYUHiSb8t5zYG1avk9eoPzbNilry7tzcHF2VNk76Oeg3uu/BLf7wx5H/MgD5QGSSGHBRHrLEKbZ8OcB4gZA3Eq3nPREslWSDclG4UsSOD+rJLKJKcUNT34hKahOR6+jdpemLgLTZDNYB82ZL1kOjSLqNwWvyFKnLJcU4TEwFr6jJBq6E8cxrQYBF2tbmA1JzSsvABY7aHedFy22dyrZ19aH3O4DezIJVDxjqff64sa1ETUDUxUJo+pcYs7JNg5a9k4AKgZLZaRVzbhdRhb+eqPYb+iNWjXswsLCwsLDsO1J2IwSqevyuSJps0UE4o/WO/8H/sL10sZSfV0en0G2SjJzWrVSSzY7QzaucWDUpbi+cIWsyHH1OKoPD11Ic50Yzh2KlXh+oCrC4xrgjsuegM/Wf/c/z9Ab7maHomn94+rsz+Oj9U/sRXVv/eNylQzTUJgGQe26o+E074JENhy3DLiDw1zXseMdihVMWg=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block034_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
