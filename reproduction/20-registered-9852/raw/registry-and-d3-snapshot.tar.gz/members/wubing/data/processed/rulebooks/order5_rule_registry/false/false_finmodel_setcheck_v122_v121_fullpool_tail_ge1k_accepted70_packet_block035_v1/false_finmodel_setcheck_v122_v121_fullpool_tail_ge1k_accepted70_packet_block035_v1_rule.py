from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,1,3,3],[2,2,2,1],[0,1,1,1],[0,0,2,0]],"priority":875,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block035.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block035","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmLFOwzAQhs+Oac2EhRgZrKp9B0YLdSCwZGNC4jEYEDJSJGCDLLxORhbEK+QR2NgoTsIAKtc21D211X1DIuWU/PI5d/ZvAQ5+U7a3/OezA1gfbrCAUUjAi1J0FLHYt2B0C1JHGorEAhkW8M9qzqsdaJNi/XQmm6sGhmEYhpnH++RN0ql9TgiHVurqTpANTgvKaTuToMjEqn47eXuWQk01iXQgDVfnUvSgT1hsR5VPAA7rzW5S9xXO//+4JFXLKcV84UAo0CRtBLLC2V0yM3Qq06ERNrhMUMaBr23aynq008H9ha8/1kLB1hqw0Ggy60zOKYjDMaWY+96WbGMidyjFqtETodr1xey1KIm6sn287qfjMeoNhhDTHWTFy+Dhns/5tqrYEk7QosWGevqTOhJ5e2nQA/WwlQW7yUuDa5vSH+MrsOQuwVWKWcfzGa2TmQL93SznphM9vMXEL2nXlpm2i9i0DTv6+gIiyi4+'
_TARGET_BITS_PAYLOAD = 'eNrtmLFOwzAQhsvGxiPkFRBLx7wOS2ADpEhYiIHHQGJiywJhqJBH3qEV8sCIkJlwi2MfTsIAKtc21D211X1DIuWU/PI5d/ZvDxJ+k7a3/OezV1gfLrCAtkhA+NR3FFHYt2B4Ds5EGorDAgUWEId2zqsdaJOixHQmm6sBhmEYhpnHXm/f0ant9AiHlprkzJMNznjKabtzYMnEknE7ee+KQs02iZTgNFfnUkxgTFhsT4moAF7qzW5V9xXO//+4JlXLKcVEJsFbMCRtBIpMqg8yM3TvypH2KrhMsFqCqG3aynq0NMH9ha8f10LB1mpQ0Ggy60zOKYjDI6WY/N6WbGMiPynFkuERodrlzey1qIq6su0evJWDAeoNRhDTHRRZ//nklM/5tqrYKk7QosWGevqHOhJ5e6nRA/WwlQW1yUuDbJvSH+PLsOQuwVWJWcfbGa2TmQL93RTnphMTvMXEL2nZlplRi9i0DTv6+gIptkL4'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block035_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
