from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[1,0,3,3],[3,2,1,3],[2,3,0,3],[0,1,2,3]],"priority":876,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block036.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block036","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmE0SgyAMhQOTRZY5Qo7iEXoke/Naf6agxVKLjtj3jS5kRhYhyePlTqs03cuzNaZyCB1AW3IzR6T9M0ZnWizKsD35psBeVv7UwuwAdcM4xgqJjswjHuCD7DHiAcB57pgQXbArttF0VFJsMppHsbACe5ljDWvMR0bT5naNVyIwfN+CX2Ojx8ubl8/1g+7/MlLINNEuZdEQn/Gxdmsurxl1ibZ8pQ29SZvllMJ+LbPLK9tBU526PVte58WtHeyIJnXIRemnCNWZcKlWq6lRUE4fgSG5Ej4lL5YS9RzRbhHYC/HV6L8uv6ImXQlgMF4ZD5qdDUM='
_TARGET_BITS_PAYLOAD = 'eNrtmE0SgyAMhW9ej9QjeJQcIcssMpBaf6agxVKLjtj3jS5kRhYhyePlZqu03auzNbVyiB1AU3Izb8b9M0ZnWizKsL25tsBeVP7UwuwAdaM4xgqJjswhHuCD7CniAcB57pgQXbArtNF0VFJsMppHobACe5lTDmvMRUaT5nZNVyIwfN+DX2Ojp8ubl8v1g/7/MlKMONEuZdEQn/GhZmsurxl1ibZ8pY29SZvllIJ+LbPLK9tBU526PVte58WtHewIJ3XIR+nHCNWZ8KlWy6lRUE4fgSG5Ei4lL5QS9RzRbhDYC/HV6L8uv8IkXQlgMF4ZD7HUY/M='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block036_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
