from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,0,2,3],[2,2,2,3],[0,1,2,2],[0,1,1,0]],"priority":877,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block037.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block037","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWc2OgyAQBuKB3ROYfQAkNPExiOFQ97SPxMGDve2aPkAfdQWs/cOt3Wq3buZroqmoHzPMB8OIkcYohq06+pO0v6fHB1qTqd61U18m5TzSstqopq4jDbk/Wue2z5HeekVlvIGF06U5truk0/OWBBG6f1qPo8/8UVj0S7fZ0BUEAAAAAADgXuRlyCPiWQZgNN5Qs8+UfGIYTecAAMD92KpmLWWRlsas5aamnEtpDM2qOchsY3qiUnGeycJUdUvGZtlXNgeijXJm1TXjLRmZg+097YnaPagzy7myYsUcZLqUPZFbcFhwJSvofCtbrBt+NE/cKVy/lhP+u8GWS5tvKhEMiC098Rrfl3DEy8W9ESJILP4EGvvhUbgLAdYPm5+23EDapdqGhxrYQ8U2YQWwx1FhLQIqJl7ZfpwX3NKAp2MbXsGwYpNHYyATwafXenZ4YAkIAeL9Na74elfYZL5i27tIn3mtfbcepU47q0oB52KjIq4onLBQhU/aQGJBIWRJpuljFZwarcdcEjd9RMi7s8KPsA0fPo8k/0wmVTcLEArqXJDYSjIgNrcDJ1fTL/HEtn0DIotHAw=='
_TARGET_BITS_PAYLOAD = 'eNrtWc2OgyAQftQ+QOPurR488Eh7WnsghscwWYI8wEY47XIwQAWs/cOt3Wq3buZroqmoHzPMB8NoLDE2hjU9+tO0v6fHm93qqd61oi+4FiLS8rGhSZpGGkp/RM5tryO99WXzeIMMp0tzUHeJ1OctjdVq/zQZR1/5I0f2l25DoSsWAAAAAADAvSjzkEfEswzAaHzaZJ8p+cQwms4BAID7sabJlrGizjHesk2qhGAMY1Vlc5ChBPdEORWiYgXO0pZMzrKvTA5EG+rMSlMpWjI9B9t73RO1e1BnlnNlJos5yEjOeiK34MjgSlmo+Va2WDf8aJ64k7t+LSf8V4MtlzbfVCIYEFt94jWxL+Hw74t7I0SQWPwJiPHDQ00XArIfNj9tuYFES7XNDDXIh4ptwgpgj6PCWgSKT7yy/TgvuKXBTMc2vIIZKiePxkDGg0+v9ezwwBIQAsT7a1zx9a6wqXzFtncROfNa+24ySp1oVpUCzsWmeFxRppGhCt+0gSSDQvSSTCPHKjg1moy5xG/6iFB2Z2oeYZs5fB5p/plMsm4W0ArUuSCx5XpAbG4Hrq+mX/yJbdsBKfUqMw=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block037_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
