from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,2,3],[3,2,0,3],[3,0,3,3],[0,1,2,3]],"priority":878,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block038.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block038","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt100OgyAQBeCZCQuWk56A3oSjzaIH7wgiYDVN3DRt35f4E2Ukggk+JjiQyEjWc4njHW5XfcvjjehFG/mGl2TMMwAAAAAAXPCgm6ehLDF7KuJIyp6GQklSy858Zy0YebRS0uzngeL+QbrFqNRqXpjlmri4dVC6Wg5WnzFa206JJ/WKqe8jKrkXjs2N2svMea8MwHvyb99I5DJ6Qa2m6zTN0F4on004nZZeiRwLAACfWtnqIiWHi9np78hFdww4AAD8lCfUvQ2E'
_TARGET_BITS_PAYLOAD = 'eNrt100OgyAQBeCDdzFHm5uUEzQsWZCZ6QgiYDVN3DRt35f4E2Ukggk+NTgQjEzWc0njHW1XfePxRvKijXzDSyrmGQAAAAAALrjZw9MQS2JPRZosqqehXJLUsiPfUQtGHq2iRfbzbGn/oLjFqNBqXhBxTVzaOihdLQeqzxitbafEE3rF1PeRKNwLx+Zk7WXmvFcG4D35t28kaRm9HKmm6zDN0F4un00+nZZeiRwLAACfWtnqIiWHi9np78hFdww4AAD8lCd3tGOy'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block038_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
