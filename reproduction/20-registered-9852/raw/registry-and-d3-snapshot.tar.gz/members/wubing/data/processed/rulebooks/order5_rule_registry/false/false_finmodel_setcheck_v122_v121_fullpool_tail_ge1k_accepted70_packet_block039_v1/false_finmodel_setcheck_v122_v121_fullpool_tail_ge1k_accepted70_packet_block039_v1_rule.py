from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[1,1,1],[0,0,2],[1,1,1]],"priority":879,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block039.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block039","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZHBgZMAGpqggcUwYWBgGPQhg8GCillkLVCa6CAkKYpFR7VSZ1NFBHVu8hDxVBAWxhP+FbcwgCtM7DfMhEeEgRAXrVTlBpEKnipISqoQBmNRiYBDAq7+BwQHoQgcwGgLpYxSMglEwCkbBKBjEQMMTXLdSr5UxUoEIwyRYSwncMMTanBsFo2AUUA6mqEzyUFJyEvJ0cfFQ6uzgEBRUUnJx4VBsoYVlDZNc4BaBelCKSk4uLR1AywRo0q+chLAI1FdycenoEBAEWsZEC9sgfUKwRcA+KMhboKBsEXCihWUOnkpwi0AVjgAkKAWcOEZT9GhmG/5gNLNRCeTufrtt9252TAlalMgP1D/+/29sjE3Kg/pl8p//n09p78M13sah0EDVmu1/PShX45LGMVxIfs12I232TEnaWzQKqAl0V6/Z1LUSy4irgAMDIwMThwKDAwMwVTIyMI2GFRHNSGzFCA1altBmJI7MRoeWJe2Aw20+cFmIKbPp1rp1UqhCkbnh4byoQgoMLiTY9sMTQqugF1AH/mPE5oP/GJMbowDRjATnAsyRJixTQhNwTIeNArpnNk8meBGFKgPqFDARFIIWM04cg7B+BwBH0oMp'
_TARGET_BITS_PAYLOAD = 'eNrtmb9Lw0AUxwMOLuLgP9BFcXRyFqFLhw5FcdVBXEp0shk6xL+hm/+AdHMyGY5wf4AFQRSl4ZpJF0mCDkbQ5MwltTXm4s+7UvV9CAm5R/ptLvfevXcXURxRHnX71c0xfaRjzyE1Q1G/tW5vI9fzOJZuw1Y1TYzKkWvYnsfp/4XKE7vkX0ffSD8EdgXId+/Z2WnYhGQNJ8n5nFL/3ed1iuN/iJPjF4wPAAAAABhjLoxkbhWXZfxXbqj6kikliSE3nQMA4OfUbdUkxHINhEzS0ALPIwShoNeUIaaraCDEKqgesVBTi8V8KXWlOhRitRJCmuZ7sVgoQy2tCROhuAZlr8W6sulbMsSwQQZCbMLx0670rQBGNDjb3wecTRCt8kylXH7IG2RE5NLltKJ0OjyTKT4mTyhTi2fLRettgaMLndmUPebVReaC5cLvz2zz+5tb1/KFAJGcrq5Ud9c4K64+phENA4diGo/KiIbQV59II3lhREJm2U8jC5xtBJmlPPDsbRIL85bqXK12lW06aLXbd9kmh6IvqE0a6dV+G6CWlNzXLCm5zQ1gmEYmXpBfaeJsCe0UbIcBI3c2IxyEqKyFFQXhh039MGMFYzi/PwMEru3+'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block039_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
