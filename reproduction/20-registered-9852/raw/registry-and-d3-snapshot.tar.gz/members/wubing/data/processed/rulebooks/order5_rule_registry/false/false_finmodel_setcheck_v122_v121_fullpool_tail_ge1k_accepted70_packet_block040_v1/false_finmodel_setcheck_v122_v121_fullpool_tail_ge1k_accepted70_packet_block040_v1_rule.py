from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[1,1,2,1],[3,3,2,3],[3,0,2,1],[0,0,2,0]],"priority":880,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block040.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block040","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmU1uwyAQhQfEAnVlrByAWkTKMViwMLsciaWzc1EO0KMWsJVIjWlaGawmmW/hWSDx+BHDG0zgRzRPYQfPyRk8L9UXJ9k1lA7on/o6+hSamwbnWQp1l2XSvbsy0yg0IAiCIAiCvCLOmzYYpr47DdzK2mqzP7RKCIJrv4IDUSIaWHoxsqyi2t6pIDQaIKnu0CaI4f4hLwInrNGQqWyL8x6K7rmEpdXF5JQ2KJdPt2su7BlhEB8xQmxAhkTpquWthl6F4qtJEIaoifxr9iflh2FpP3VbXOxTfZhWiI2mdla+77qlFELtbBrKZbNoI60xG03t6JNfXUrV8UOYxNc9BHlAaO6CjrcrsLHoPwRtcw5rIXXSfqUdO9gUQuX2fRgbpk4EufCWaxhvXxPcWkM0H7Zeul8ctgfjC8PNKXg='
_TARGET_BITS_PAYLOAD = 'eNrtmU1uwyAQhY/aA0TUu3jJkbLDCxYcI1KQywEq41XFAsEUsJVIjUlaGawmmW/hWSDx+BHDG+zhJsKk8AnPyQ6IKdWX8dk1VBTcn/o6kBTGqwZKbAp1l2XSvbsy0ygEIAiCIAiCvCKU8CEYpq7ft4ap2mqzP2RSa49rv4KjlzoaWHc2srai2onKINRw8KnuEDyI4f4hL4LxdhSQqWyL8xGK7rmEddXF1JQ2nFFPt2s07Jm3EB8xQhxBhURJq+Wt0V2E4qtJEIaoifxrTntJ2nZpP8VQXOxNvvNB642mtpOk6/ulFOLYbBrKZbNoIxnnG03tQJJfXUrV8eOtwtc9BHlAXO6Cjrcr2KboPwTBcg5rIXW6bqUdO7IUQuX2cxgbpk4EOfOVa2iuXxPoWkM0H7ZO0V8ctgfjG4ikR74='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block040_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
