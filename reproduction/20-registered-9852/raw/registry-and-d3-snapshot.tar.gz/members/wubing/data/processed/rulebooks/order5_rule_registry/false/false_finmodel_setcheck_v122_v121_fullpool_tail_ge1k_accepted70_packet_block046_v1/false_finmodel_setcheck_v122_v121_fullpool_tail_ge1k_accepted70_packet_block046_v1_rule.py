from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,2,0,0],[3,3,1,1],[2,2,0,2],[3,3,3,3]],"priority":886,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block046.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block046","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmbFOwzAQhs9WkNwtDuyklpE68BAmZEgEAw/AyMrIilwpgyuWElUVG30Mxr4FK4/QkQ1iJ0SiTUMqEqmp/A31cIn+3F3uYl/HGEpmHGoRAPrqE5jDjlzJp2rDKObPYehUaMVswhmDNpBYeNArboo1wo1vOUf5Olg3LPKsOq5YtxR3wEb4XfNL9jlCo9hk9n7+osDSF+SrqcTPU6RAJ9BnuEO11cNYL1+XcHdogVx6HwwRuOWATGtdBaTTYtNdOuGpUtPQo5SxMFTKDQjqQu1sUgqlEWNBmChCaUCGXYgtMs9+hLzYuEWHLBNzulCb8VIoYhPtlg4lGSadFFsalkIxp9otHcph4tpGZDl88u2s0DVgg9EbxIWvt7A8+7RInUCXIhsUi8VisVgsC163JRDHdsO3lzzWWp236zbFlu9HNaMlATE4vQ3kFaC6h+ctFxvdYnHN6YoIR7Z5ZkujypmgwJnPxJd6ao2z3LUx7pIp1I0fkdPqoMTFxK+2GF+QeS1b44+5quxxH8lH/xVvQOVRnxyY931F7jTpn/aqO+/0f6j/z3mGiItPWKM2sK3nNKUon8FmPvBg69W/UNC8jX4DtnxPbg=='
_TARGET_BITS_PAYLOAD = 'eNrtmbFOwzAQhtkYeQRW3qIjj1E2VFWhC6qHSLVYGVkZeQAGqnQIwQ/BUAnLCTvE2WqJyD5iJ0SiTUMqEqmp/A31cIn+3F3uYl9nEkrGFGohAPrqDxjBjszxdbVh6dEr308rtDw2pYxBG2BJYugVj8W6kI1veVX5ulo3DPOspglZtxR3wEb4E/Mr9jlCS89k9m50icDSF/CFqcTjd4VAJzBiskO1k9uZXo6e4f7QAjmIT5kS8EBBmdZ6EohOi013aZc6CE38mHPGfB+hJBCqC7W3aSnkLBgLfBcJzgMRdiE2zDz7EYo94xYPWSaWdqE2pqXQgk21WzqUInQ7KTbHL4U8yrVbOpShm9hGZDl88u0s0TVgg9EbyEukt7A0+7RgncCEKxsUi8VisVgsQ1q3JSCfdsO3l9zUWtPzpzbFBmdfNaMlAh6kvQ3kHFTdw9OWi41vsSTmdCVIits8szmLypkgkZnPIsJ6ai2z3LUx7sIO1I0fVdrqoCSRIqq2GF+UeS1b44+5Ku5xH8lH/xVvQOVRXxyY930F7zTpn/SqO+/0f2j0z3kG8YpPWKM2sK3nNKUon9VmPuRq69W/QNC8jX4DlfUhyA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block046_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
