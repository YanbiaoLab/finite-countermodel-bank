from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[3,3,3,3],[2,1,3,3],[3,3,3,3]],"priority":888,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block048.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block048","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmV9IU1Ecx891MxdBGlEaPsznCKz2oGFtVpQvhUTZlCjLQMHwTwzMcvPswYciQUP6Y6IjIgQ1559QdOwPhCvROaEi02ZK/qmYTk2n697dX+fuoRcnsYfTS+fzcOByftwv3/v7fe95OBxCyIj+xqtBaXU4OMT4F4z2TBR3qXSbN4zd7pT+J9YwfRCsah5792zemIKVN7CaGUZFyXFiTFyYjY5Qu1tyqs+dkCOUkBpSlpWi8lK0E8X+KUufijNyV1m3GAwGg8FgMBgMBoPBYDD+A4osCz0WS6+n7NZ6T4N3+LPHqtIVzDXpRmQUxKaCP92V69jGz/vcGssne4C/DnPeRh2k0bAmWG08XvwIvEf45YVObcn8oisIGqdhBwUxI7g1ABAAE2hAKIE5qAk2ACyCj4a1pe5xH9RfApyiu9EFGWca69Mq1gESvh6goSYCH8S5C+ATh4PEI/TlFvhESF5/uI2CmAPgHm6xCc/vf2qQxEB18kpVMPHFey0NaxuSgtsMpG1rITWX5BDbAntpqAHY/Rbwe0ow+X6EL+aAtsD3iM+lEjYikAwlIrE4FLIGK2ASt/OgohI2WWUAlA7AgswxjcvRUuw3kwAxQMMZCdtW0JBbkiYiEE/W5WlJQ3MsQFZTLWynE7bUoxyX/lgmR4IkjDgUO3MKJVH5+6dPFFsGR4bDGOkab28fL6trrG9tLctvr87WVd/MKdJqi6TyD1lpKu3ptiPOVPKGCNRSeT1JdWKYzO/mLxgCp+O7U3KzvK64Y9eqDXP3DC02qbzBvN+ff7fpoFMdYW+x2S0qK6LDZB6bn2aaghr/j5fZ1k6AgY7MoF3rapbK1y62TY4B5I01Rxq2re5qSOxWZ2rgu0mvr8XLoHwGDwDfvhMqV6vf2jegZhQUkanp5fINZbgvP4XlKEqxpDGiKNIZkcSBPEQhLlTOkSEC4JA8wrD1eKQ5GCq09BdOnCXD0D5e33c4z3XISeNSsdQfmoNM7/m12cTLw5P6rM6Uk6tVh/z7FDTCdiU0B2AtVBv8MNbam7fmFCH+tTqaysk2K82BAEPv6jRiM15ZPi4OAK4SM6icbAppDoywCymSHECmAiFuA2KlHwmFvv0GwT3zIA=='
_TARGET_BITS_PAYLOAD = 'eNrtmV9IU1Ecx3939zadpk5H5Z/QXP6JClxTrEkwN6Yo+WemgkTEFLM/RAqGPfiw42aZMPIPCQpZGqHLIka9VFhuJunD+gPRs3uQtIg0CFdt3tO5e+jFSezh9NL5PBy4nB/3y/f+ft97Ho6IMbbiv3GsUFr1ehEz/gV55VkDlV7H5g1rhWah5IwxTB94o0dAqs+bNzIg7gjEusKo+ESR+7EaZqM61O76ifaHzwMYL8+HlIN9uKcPf8Nrf8pmMlat4m3WLQaDwWAwGAwGg8FgMBiM/4BBU1K5yVSm7r0WXd6syt+rNnodwymNjkNBCmIZsu2armhkEJKVGrcpp1gu3IQUVZMD5mhY440GASXuA0HNb1NBlbM/OVErA7fO9p2CmBU0bgCQgwXcwPdDCrTJmgESQUnDWkJFthJa7gJacNyohCePm1rmuqMBlne/p6HGgSBDY0mg5PJlxCOUjg0rOXgXff4nBTE9QAeqN/AnL+U0S2LgnR7vlC2dOOCkYS1KUtCYgbQtJqSmlRwig/wTDTWAYoUJFOp+RL4fYY9Z7hxWnhPGqISNCLyDfo5YLAhZgziwcOsCeKmELdglB58eEB/Up6MenLC2y8LDD6DhjIRtK2jIJUgTIV8ha3y6pOGelZPV0grrdMI2/1IUZ84GA5iXhLGI19Ke4UUqf/+ZrAFT4aH8MEYqs2tqsnsvNLXU1fWO1LRPOtqvTww6nYNS+f6pOa/zae0r3Tx5QwRq84KdpHopTOa/CPdt8qcrFQtjUyrt6uytdltKh63eIJU3mz8oRi43vtV5IuwtMms4X/evMJlH5tMui8yt2HF80lgFUFTtkhU7tQ1Secy92sxcgNHchkjDttVdDYldbFob7LTY7a0oHnyn4CKgq1dC5R7P4eIoaMsDf2Rq9kAgyhfuy2egAN7wJ7iteIN0hiNxIA8bWAyVi2SIAEQciDBs5WppDgqGTCVDWY/IMNRkt5S+HtW+0dG4VOxThObApXoQk7p0Jz/TPlW1MB3b+Ubx0U8jbOOhOQDjkMemgNy6stEYHQcrRz2/qJxsqdIc8FBw8IKba0Bx8S+4IkCd3BMqJ5tfmgMrfMX+RT2QqcBYjII16UdCoW+/AYs0fgc='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block048_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
