from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[3,3,3,3],[2,3,3,3],[3,3,3,3]],"priority":889,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block049.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block049","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2LtOwzAUBuDfdqK6HWioYEPERUiwsTIgJUggscEbwCN07BYLFsZurDwHC36UDDxAxgxRjNMsSI2FGMxFnG+olDrRL1/OiRQGQOMzjWXu1xgG8h0qu7Y5oPuB0dAWdbLNgbJ/ZGDrblncjmYD8bX9KD3d08I8iAWWC2xhug8jsHR35WWi2R3tFiGEEEIIIYQQQsg/YH1GAcJKb1qIqTW+sDRAmPZOTQRIq3xhRYiFbH1p0wBhxruQIb5h176wjIqNiu1niu3lbM7yp6PD9ZoWil1cv13iIEj39xcb+cWKeKdOr4ydJNFN6U5IxHTUuCayXRax5MdVtsI9ct5aoWX1yiPW3Y5zKOa6aB7V9oRpBa4wc8dNjCGlu1y5qoJyf3IkCfCIvpzm9Gb7m2+2SXcOtN1V8tnYnEuOce3m5RrJQJwc6rJfSHsH4dfPbg=='
_TARGET_BITS_PAYLOAD = 'eNrt2LtOwzAUBmBHGTLmARjyKGbhOVjZOrKAnK1jHwHeADYkkEgkBlY2kBB1EBuopAyto8T2j9ssSI2FGMxFnG+olDrRL1/OiRQLQOAzMbPul3ML8h1StrY5IPqBZmiLVsrNgax/ZGDrjm0bNbOB+IR9VF0/Cc0P9ATjCd4wfwTXGLu7iqwW9oh2ixBCCCGEEEIIIeQfYD5NgLDMmxZiarEvrAoQJrxT0wHSUl9YHmIhI1/aPEAY9y5kiG/YiS+spGKjYvuZYtu5mtpi7+5+vaa5tBenW+d4CNL9/cVGfrG8fUmqM84WdXeSuRPSWdHFrom8ZnmrzG1ajnCIwkRMC5Vum86ubsclpHVdtOgSdmOFhJGYueOml1DKXY5cVUG6Pw3qGthHX05TerP9zTfbYnUOBHuWapezwiiDZeLm5RrJQJwa6rJfSHsHapqhuQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block049_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
