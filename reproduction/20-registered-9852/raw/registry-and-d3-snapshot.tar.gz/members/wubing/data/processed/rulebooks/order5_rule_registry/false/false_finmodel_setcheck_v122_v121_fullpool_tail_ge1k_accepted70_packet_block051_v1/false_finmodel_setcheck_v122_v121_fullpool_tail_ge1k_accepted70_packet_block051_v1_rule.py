from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,1,1],[0,1,2],[2,1,1]],"priority":891,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block051.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block051","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtWM2OwiAQHiYc8EZ9Amw4+BgT00O9+Ui42YN7U+MD+Kg7QLfWtFV3ZVfd8MVYkcIwPzDzIYBgEAfQp4aEF4BOONfR7ioQoGtAQm67tme2BlT8xPDpQIENT/53e6MU/LYq7i32U2/ou19BXOethhDh23jv/tTBBjIyMjIyMjISYC5yUk0CGeorGu3NyMhIhIPd12W5mC6rqi6ZhRQF8hbzRGltDdgd+UbBfIH7thUWMPWjqpbX8Ajervy+Fj125HosaF95QcqsHQipeVbyL/FI40A6q0PDL0DHE4Du4S0rrMu1gqUX9MGzsmDQYQYZFof6NB1NhYzSBvSgDlccpYALEFZ7PXj5ulELT6cVJfUaTYyTCDYIwqhWkNlwSHVOcO/ObJ4hOzvdRJeaVnlkY4WwaQ1iPmQZzbrp8NXGzgafLfxNNFhIONiz1Xm0BTXHrghuMvIh7B7yAU8dJt/8sOdXCfTlTfrdK5OMa5stxoEc631liL8UdvzTAvk9wcl3M9xe4mQwFBSnBJjYQiSMlRWSuVAeu7S64SlK/lvxrYQM5yw2522roWtP2U4VIJqI+ummmbn2xMAhMz92d2YMQ6Maif1Ywna7mmKs580ndSSN1i66bqq7hJluri6mocTJYdbxgb5arr3UTstXIC9ZRk5ClA1lEEpC0x6IT9XMNfc='
_TARGET_BITS_PAYLOAD = 'eNrtWM2OwiAQflQfwKg3PWxWHmlv9tCYeYw9kMoTWG5yIMPsAN1a01bdlfVnwxdjRQrD/MDMhyOgQUxJHxuWXgA64VwTOS/JkS4IAbkt2p7dmtDwE8OnA0MyPPnfxZVS8MeqiPfYD72hb34FcZ3XGsKFb+W9+1sHK8rIyMjIyMhIgE+Xk2oS2FBfwWhvRkZGIkzlrKiq7X5TlkXFLKSukbeYJ0prqUjOwTdq5gvctyixpr0fVba8hkfwduX3teuxI9FjQbPSCzJqLchZzbOCf4lHKkFWSB0afgE6ngBwC2/5wKJaG9p4QUuelQWTDjPYsDjUx+lg72yUNqAHdLjiKAXckpPa68HL141aeDytIKnX4KCERZJBEEa1gsyGQ5pTgntzZvMMWcj9KrpUtcojGyuETWsQtbRVNOuqw1cbOyt8tvBX0WAh4WDPVqfRFtQcuyK4ysjTsHvABzx0mHzzQ55eJcC3N+Fvr0wyLm22GAd2rPeV4e4pbHLXAvktwcl3NcTM4mEwFAynBDrI2iWMlQ8EdaY8Fml1w2OU/Lfi2zgbzllszttWQ9Gesp0qwDUR9dtNsxPtiYFDZn7s7swYhkYzEvuxhO12NcVYz5tP6kgYrV100VR3CTPdpzmbhhInh13HB/piufZSOy1fgbxkGXkIUTaUQSAJTXsgvgB2pTs/'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block051_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
