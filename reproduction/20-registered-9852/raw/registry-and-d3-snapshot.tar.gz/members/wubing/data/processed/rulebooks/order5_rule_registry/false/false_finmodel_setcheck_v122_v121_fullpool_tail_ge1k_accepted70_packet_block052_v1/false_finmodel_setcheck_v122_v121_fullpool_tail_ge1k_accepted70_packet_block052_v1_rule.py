from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,3,2,1],[3,3,2,0],[0,1,3,2],[2,2,0,3]],"priority":892,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block052.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block052","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmUuOwjAMhu3Iiyw9nMCgWcwxspgDcKR0x3KOPORBQh+AKlEJxP+pUp9Koz92k99lIop0k0A00LsTheiLn9QYk7i0d3nbiD9VOxCvecE368n7fKijG7a38Luur3Y50MfPWRUDAAAAAAAAADYxdGfHwcWM0djXmXbbYiTNm+TH/ZWzmRtdD1035mxPtY7IpOTg8uhwvNQcyuC55j+7v5TW2AcLKaJNFZtmBkksEnK18I5Ym64TY8+fnWzO5W7HRR3JhXpVqcWnXN2fSPioCBJqLS3Owl99j2gt7eRWhxrxN8sw1vMBgLWoHVOA60+KJJ8DcFfCz0v/2HpiSAXAO+EkZXUYchZzzmBJ/0EWJ+WwOHvZ3VMAXnhm09FiU2i+ugOvxz/yYxUW'
_TARGET_BITS_PAYLOAD = 'eNrtmUuOwjAMho88S3bNkTgAixyDBZrxCRgvs7BiQx4k9MGgSlMJxP+pUp9Koz92k99VM3P2EG822LvjxOxX/6kxNYlpH/O2EV/M9G265gUn5V0I+ZBHN+iH/GFdX+l2wM+foyoGAAAAAAAAAGxi6K6OQ4sZs7GvI+62hUyaN8mPhztnMze6AbpuzNWech2RSckh5tFRd6s5lMGLzX92fymtsQ8WUoSbKjTNDBNXJNRq4aMpN10nxl4/O9lizN12izpa9PUqW4tPubs/kfBZEcTXWpqbhT+HHtFc2smtDjXiH5ZhqOcDAGth2qcA52OKpJAD8FzCL0j/2AZTSAXAOxElZbUfchZrzmBJ/0EWJ2W/OHvRn6cAvPDMxqPFpth8dQdejwtaDlwg'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block052_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
