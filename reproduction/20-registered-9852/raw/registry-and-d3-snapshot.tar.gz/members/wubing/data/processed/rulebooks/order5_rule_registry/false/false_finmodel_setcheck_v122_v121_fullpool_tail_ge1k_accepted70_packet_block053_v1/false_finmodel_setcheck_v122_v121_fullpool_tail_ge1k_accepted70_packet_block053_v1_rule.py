from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,3,1,3],[3,1,2,3],[3,1,2,3],[0,1,2,3]],"priority":893,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block053.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block053","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WUtu4zAMpQUt1J2SE6iBB+gxhMCLZFZzJBfoAOmuE/QAPepIlCxbFulPEkeLFAktU3r8PbJ/wSqwgOsDPy0Y/+cbhDJOaFoQIMFoJ1H4oARmGVZStYzgrZLaUoKomFjhR1MKdJC4N44EbVChUJrtlfi2XIrrp/7XuG9XD4F7o5NqMPjgL3cs9839GgCC1m8T3VUGUgjbEoZJCnEbHPGwA2ncBt0NvEJRZVcJf6zQI3TCVUC6z4hotMaPxOMQtnnF45ju2bGN2gi3igfQBepyaBQLz1yqeqY21n+3WNFgT1of6MZPWhFG9RxtbELYZB373EJF02OXHSna9oZv53rn0lNdpLZNFpthNww2USb67YItKDIp3W8UDr7sJUUyVZ2NMoueiflHBxt3jA1SpwUuQebs4UHBxlKi/QZuEzgAVWA3cBsTvIQI5WqJ29ibg210jJJZEm6zLhPwlU1yFHYGgJsqG2FNCoB1Jh3S1MwysRgMLUOS7MKkmofCKq6yEcGWVdx5HZagkbmi/NG8JyBK+6QOxdBInV1mCrV2hY5qItiWoaaX6yjz4Xd9PR0Ox/25aU4H97rdLqYo81kfDkgfLip2N19NUdovly7YUm7rnTQ0REEYcLk2SVGeolBR3mQRpZ3UEcRhCwRhwOXPFRWdvaJPJ2ua7tGSEBGlndbRN3r9vdAAv9mesCRERI4mdSQohvdCx3hBRQtR65PApI4Exch4PI0kKhsiPQJg91rqSFBAbrwJGkmhVvbmpI7egXLjTdBICjXCbSgdyYFy46XZDCxCjQAAVgUbSyMp1O4NNi16RfOo3Rtsx6cGGzsH2iLYFDuOIlCjJlBmTbBVcwx6THaUvINGTu8VL0N1qobqrvmG5FtPhWgOC+K736BvYHRdId4TdC1AaCoFL/XOGcB6g5iJQexyGol+QN3MoQbv0vvABXB6SFCElYsd3OJNTEZlW29CrbhWc/4INuwlWinzBbJl2jiyZ1k0jWRoJDGPRY9J8TcKEEkyOruQRiJqoQFok9tgMhm+xXY6WprR5ajzk/AtJjJsZSP4+P0Dkj1X2W5u4+aDrUzsUfdj+Thb2bguRizXIZn0fjKFebQqI6v4pwa+s02yKiCgZ0b/FZ2QT3lG88VAEY8tHtqEYDNUTevKWG+jMtjaVf4yN/qXt48M1o3+ewfRbPN70+gfUdDLRld3DJjjgESfXLWcjeM4ONFzw6uJyoa2EJjYM1PbqaHhwAFXMJTYsymGZonxXEuAOKcEoPJis6iy+fJVjgwobxbK+rBIJaIidUzg/B9pyNC7'
_TARGET_BITS_PAYLOAD = 'eNq9WUtu4zAMPWoPUGS6a4ApUB9pVpMsjEDHKDBGqhMk2lULQebIlCxbFulPEkWLFAktU3r8PbK/QWgQgOsDPwXI7s8rWC2dUFZgwYBUTqLxQQPMkqykrRjBV2uUoARBMbH8jzIXKC9xb5wIKq9CozTZa/BtqRTXS/Ordt92HQTujU6qQOKD/9yx3Df3qwcIqm6b7a8ykoLfFjGMUgjb4ISHHUnDNuhv0Cm0bXIV/0dYNUHHXwWM+wyIBmu8GDwOYZtvPI7sn53aqApw63AAlaFuxkYR8Myl22dqY/23xAoGe9L6QDd+0gow6udoYxNCkXUacgsVTY9dYqKo7A2/Ds3VpacmS21FFpthCwabzRN9uWDzimRM94XCoSt7UZGJVadQZlELMf/oYOOOUSB1CuASZMoeHhRsLCW6FHAbzwGoAlvAbaT3EiKU2zVuI24OtskxcmZJuM22TMBXNsNR2AUAbqpshDUpALaZdExTE8uEYjC2DEmyM5MqHgqhucpGBFtScZd1CIJGporSR9OegCjtszo0QyNVcpk51KoNOtqZYFuHmlqvI8+Hr83ueD6fLoe6Pp7d667XkKLke3M+I33Y69DdvNVZad/v+2CLuW1wUt8QeaHHZVdHRWmKQkVpk0WUdlKHF/st4IUelz87VHToFL07WV33j+aEiCjttI6h0RvuhQb4y/aEOSEicjSpI0Ixvhc6xg8qWonakARmdUQoJsbjaSRR2RDpCQDX71xHhAJS483QSAq1vDcndQwOlBpvhkZSqBFuQ+mIDpQaL85mYBVqBACwKdhYGkmhdm+wKTsoWkbt3mA7PTXY2DlQiWDT7DiKQI2aQMktwdYuMegp2dHmDho5v9f+jNXpBtq75huGbz01ojkuiJ/dBnUDo+sL8YWgax5C2Wr4aa7OAKIziJwZxK6nkegH1M0cavBpOh/YA04PCYqwcbGDW7yJTKhs1ZlQaa7VXD6C8HuJVkq+gamYNo7sWVZNIxkaScxj0WNi/E0CxJCMTqykkYiabwCq6DaYTMZvEb2OimZ0Ker8JLzERIatbAQfv39AcuEq281t3HKw5Yk96H4sH2crG9fF2PU6DJPejzIzj9J5ZGX/1MB3VlHWegTUwui/pRPyMc1oXTHQxGOrhzY+2CRV0/oyNtgoD7Zqk78sjf7N7SODbaP/wUEU2/zeNPpHFNS60dUdA+YwIFFHVy0X4zgMTtTS8GqmsqEtLCb2xNRibmg4csANDCX0bJqhWXY617JgDzEB6LTYrKpsXfnKRwaUN1sturCIJaIldczg/B/iqaBs'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block053_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
