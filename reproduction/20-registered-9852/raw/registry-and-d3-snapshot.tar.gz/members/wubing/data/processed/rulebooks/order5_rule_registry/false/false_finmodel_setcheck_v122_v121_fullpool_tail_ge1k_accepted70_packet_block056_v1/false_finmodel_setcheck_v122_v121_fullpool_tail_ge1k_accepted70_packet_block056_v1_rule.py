from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,1,2],[2,0,2],[1,1,0]],"priority":896,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block056.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block056","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtVztuwzAMJQUNzKbkBERg9BwcOvQYPYq6+Qg9biXKieW/2wZo0vANQWwZpESK5HsIIhFm4H2Ax0IIwN1fBg/uuhDTwxG/ZYtZgzITAsRsuazKxXP+ISreXX52kP35DS+u7FE/jSA79hVjTNYpvBcHFRoMLZHu6/Ote0frxg4AZwccfXVSV8JXH2wlSvW3BoPBYDAYfo6OR+A5ERqZjPnxAE7URj+PFrgxGq8EKDOalrAEqOdYOwmXAeAE9Jo44kebLlysqB8MYxosUs+LTi66GcF0e2dJBGWzevEOXIsdVrl3uYn+Jt5Cp/N8rytpyb44Ar/dV2hVE/rlfj6sMXVEvGx0S5yJqKNc1aorR44c1apwXzZ5c7LNZQXzOTBuTTae7OeZi02jBiVqrk8Pj25M4hBhOPsshH8BKQmYKzbJ2aG6MnQVVxqYlHowDvOvkCabu2TXSRlnVe/DF23MlnSD4cEQIOYSDr7nalyKHZuqzMPaeMb7PJqcFlnttFUdD9a+DIZf0Ei88gGu+UDY0ot3jy8nQyS1'
_TARGET_BITS_PAYLOAD = 'eNrtVzFuwzAMfG6fkK16Sp/RoQPfURgBX5BoCwdBZCXKjmXHttI2QJOGNwSxZZASKZJ3LABOFhCCl8eC94L9X5Qg8bzg0sORv2ULUYOyEALmbLmswuA5/xAV7zE/R8n+QsNLLHvUT53AFftyziXr5N+Kgwod+x2R7uvlvX9H28ZOIvso6EJ10ljCVx9sI0r1twaDwWAwGH6OnkfwPhEauBjz8wGcqI1+7ixwc3RBCVBmNDviEqCRY11JuAwiB6GPxBFfd+nCuYr6yTSm3iL1vOjlYlwQTLd3lkRQNqsX74S12EGVe8NNDDfx5nudF0ZdSWv2IZKEdl+hTU0Y1vv5tMbUEeG60ZY4A1BHuapVV84cRapV4XXZxOZkW8oK53Owa002vNjPMxebRk1K1OKYHpzdmMQh/HT2WQj/AlASsFRskLNDdWXoKm80MCj1YBzmXyFNtjhkN0IZZ1Xv409tzJZ0g+HB4MXlEvZh5GpYip27qsz91njm+zwaHFZZ7WWrOp6sfRkMv6CRfOYDWPMB39KLd48vJT1MgQ=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block056_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
