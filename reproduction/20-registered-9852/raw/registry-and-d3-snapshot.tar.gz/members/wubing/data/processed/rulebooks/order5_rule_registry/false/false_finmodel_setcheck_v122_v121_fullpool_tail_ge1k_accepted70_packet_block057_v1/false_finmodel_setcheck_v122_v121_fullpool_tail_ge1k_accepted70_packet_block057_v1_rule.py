from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[2,0,0,1],[2,2,1,3],[2,2,2,2],[2,2,3,2]],"priority":897,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block057.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block057","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmc9PE0EUgN+WJSxiwg6YNCZGuuOaeqLGkxdC2UxNe6o3TxXjiaNHiCS7ktVM5WAhJlxMQf8LG5U99NDEC/4HGwJJDx5KT5iQPme2UAsh+KtrKO53mdlM2pd5mXm7880zFcCBNtcKcCbel0HZmABcg99iFtTWUOyUgblclhZP+zfPttZwNwO9wBFzJAr0ESWABBUtU3/5J4uKvj8hEnn15EQ3TKNoUqqWIH1iBIcLrbX4KYlJHHX0s9dD/c7b53NWNq3++wzdrXS6DXeS5SGiD3DQvifbR2Jxo2AC0twILVoDh466vow2cHES6SHaymVINKavOHJqo4M+TuvghbTZnporjKk5k5C94uTjFGOc68Rw9VgY0W4WzVXOE7JoybAu1wih1NWtMIL5uP5gjBDzPWNVmcg4MZoWE8G0MKK9SZbnt28sTVZqy1uZ+AJp0p1MbVmf1ZRQNhtifpFt7doLRE5t9mEVRXd7xIgKUcTFp+tzdt6Kv0tGGekH0i9v0eDTk4DD6SVDhYSrR2mJiIiIiIj43/HrnXOnN17Rp44fnvzhAi9HSTp/tDBwk04R4EAcR20A40XXcG8/8jyc6D4H4+jx0XE8uWz6CDGdwdvgeHhf5BQxUEBpgHD0lv91hUlBssJYNVnhH3Vi0C5B0mMD9NpczVK6JAVQSYalNHBNljYzpqiQpUURVYEYYz8c9Z/joH09x1hpRwQKBAlzayOEWFooguRJeX67+Eqr1GnKihek9ynFjZS1aKjhbDac3iMz8g4l2GxSAe1meMrt/zrSpf5/vnqjl8E54fASrn3Xd3iv5QROt/1A25UkrfWhnfwE2sGo6tuKJo28Li9UYy0ccKCxCSoE93KiPiuISroHgiRnjYmq1THyM21DLqpWp3QmZIXmmtEDcbKfrzc3P3Bc3+cbn7FJeVmf+ob5WrLaccssz8sHmNwZ//t3wXdaWwfM'
_TARGET_BITS_PAYLOAD = 'eNrtmc9PE0EUgF9DIqfSg4cmENL/QC4mPfSwqKn/hULjhcRAPWAnusHdBANHj5yM2JM3e2pjJ8sSLp6M5WTjOluMiWkizJKILGHpPme2UAsh+KtrKO53mdlM2pd5mXm7880jD1HDNp+KeCbKlX3ZWIjExd9iGb3YXuuUgaVyhRVO+zdFN6ZguIq9QBNz5D72EXnEBhMt9X75J/O+M7ghEvn55EQnLLtgMebl0TwxArvF2FTzlMQ0jjrO2esh+eb2wyWjYnr/PkOvs51uQl2nJYzoAzTQX8n2mVjcINhAk9ihRUvA3lE3JaMdXJxEKgC6/xUbidUvmpza9n4KVh1UQtpsj60ZSr2yxflQYf1pjVJCHG6rTiuMaO8L1jQhDVm0ZFiVuJwzpjpGGMFSMPlii3PrJqUZmcgmt+MGFcHcMKLdqecWRz/MrWfTs2PV5gKPs5FqetZZdv1QNhtAaZ6ODesLXE5t+XkGRHd0x44KUcTFp+tzdtFo3qpHGekHzPvvWPDpyVEj7JvtYUN1orRERERERET876SSnXOnspl11o4fnlK7RZKLknT+iEHgJrUC4oA4juqI9oOu4d5+5Cmw0X0Ohu3jo5twctn0EWI6+29RU+ClyClAoIBMxHD0VuryDJWCZIbSTD1LrjvcZl2CpMcG6K41XWFsTgqgvAzLWOCaDHdly/ewwgoiqo8tSn846j9HA/1jmdL8iAgUCBKqpnc4N9xQBMmT3OJo4Z6bTbKa0SxK75Nv2jVj3vbC2WywOsRX5B1KsNmkAhqukpra/3WkS/3/fPVGL4NzwuElXPuu7/BeSwucbvuBtSuJ6fahnbyG7sC2l9J9Vxp5R16otmJwoGFiHD0M7uVEffYBfLMHgqRsbImq1THyK21DLqpWp3Q2ZIUmrt0DcTJYSsbHbxCYHCQTVyHOSM5ZuwSldD3Tccu0RHIDUB/Z/Pt3wXfyFmlq'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block057_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
