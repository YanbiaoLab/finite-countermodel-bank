from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[2,2,0,1],[3,3,0,1],[3,2,1,1],[3,2,0,0]],"priority":899,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block059.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block059","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmE0KgzAQRieSRbqL0gOIpOAxZuGi7nqkdmd3VTxAj1rjL2IWChLb8j3QCAmZmATyJg/aTG1oNxR54E48xhLNE4815/bNEX0Zt6oreYe++r+VdiLkvsOcugt8z1CamzLLpKdol6epioIAAAAAAA73w6Xq/ryncCesra7aDz1zTJ4nDULS1Lx3/QG9lFN25B/zQPOmY8YwibRcH0MdO5FvetnBOnZK7tg2y3XwJtcAAADAupPNlFkUhp6i1aa6JonrgivI++NeY00AAAAA8D+kQmp2V023I/EgRIqJ45NqhCi2ZiS2RvsAjxwZGg=='
_TARGET_BITS_PAYLOAD = 'eNrtmE0KgzAQRo/aA4h2V3ftkbqzCxdzDKFBcoCi2TWLYKb+i5iFgsS2fA80QkImJoG8yZU3EwjeDc0euDGNsWz9yLHm1b6p4C/jHnYl7dBX/7emmQiz7zCn7irfM5QlIkpT4yna8yLCOGYAAAAAgMP9cKm6P+8p1Alrq6vNh5o5Js2TBmt4at67/oBayik58o95oHnTMWOYRNqsj6GPncgTn5vBOnZK4tg2y3XwJtcAAADAupNNRGlRlp6iBSJ85LnrgqtK+uNeYU0AAAAA8D9k1ihyV023I3IQIk1M8q1rIZKNGdmt0T69VVgc'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block059_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
