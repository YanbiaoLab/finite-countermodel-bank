from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,1,3,1],[2,1,2,3],[0,1,2,1],[0,1,1,3]],"priority":900,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block060.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block060","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrdWEtywyAMRQwLutMR6E00XfVYLNp71yY4tgLCED6LMplMHBKEPk960q8itb/2ZcJ7fPhRyu4P7rHjwg6dP8ssJ20okDYsKMxukHials5CacMfOiU3YRpzVTB8G0zA/vPplbbxJjZVxbMT7UUVo+IuXlSBw2zPXaYKpapIVoheMcmGM+GYjNfAl712VeLOw1krTlx2qTRYKSw6bNEyMqDGL7/Ua7hUmj6jxEwXRqsERbAZjEkH54emmGEngk1fYe4mg42eCQzmgo0Lcv8KbAvX4soGK20JK1Oya3CeHwC2eudhP9jK11gENj8PbE5QRqe8DLrAJrFlgZd1pTV7aoRVmDc9yQIk59kqQXoQ2KAmbOhtsNnUI4bpHDhET2lnlc2wEAgtmH61Wujh7NtgCxoFQT6qioJxH4Jchym/NkG4C9Kb1Wj3DOwfC01QR4IhexG0eWQTrOgZDZRGivPtzf89jSR2gnmGpMGbqKRCtok0Mo01gRD5Er7g+KNrpZFwxReeDy8jgqZsc8xmEqs5lmD0+WBf9cjkFJ9PEzKNzE40rvSWZxuXquVzYGOC+E+RXTnDo4syUOjZpAGMZp4RDCDK0FJlwyqrmawBJBkkVLas1SBrNVMvw7YOSMYyaHebZ8b2bAtnQx6lA4/SCgNVRPmcM/aGUUpdtPHg7pSKVH00TRZp5GMeO7iBFGmkp7fq8g3YpEn4jB78Z6vV8cacRc3owSPYGIvyEzLITWXLfVXXk0IJbEJlc1XdpH0HbN+Zre80UKizS453+6jL/LazQIBktYwa5Dob8qbRf3fhaRn9d6dnPzNtiCFNzdfrqGwaqsqQ7jMv2XBZW1f0qJONxcoGVWpkal1bc/oHU5BAPA=='
_TARGET_BITS_PAYLOAD = 'eNrdWEtywyAMvXe74FhddXSTcgTtyoJB1CY4tgLCED6LMplMHBKEPk960ocHv7/2ZcN7fPj03uwP+rGjww6cP8ssLW14kjYMecxugHiak85CaUMdOiU3YRpzVTB8G0zA/vOjvDPxJiZVRbETzUUV6+MuXlShw2zPXaYKpKpIVohescmGtuGYjNdIlb12VeLOw1krTlxmqTRaKSw6bNGyMqDGL7XUa7hUmjujxE4XBqsERbBZjEkH54emmGEngs1dYa4ngw2eCYzmgo0L0v8KbAvX4spGK21JK1OybnCeGgC2eudhP9jK11gENjUPbFpQxqW8jLrAJrFlgZd1pTVzaoRVmLc9yYIk55kqQW4Q2KgmbOBtsJnUI5bpHDhET2lnlc2yEAgtmHu1WujhzNtgCxoFQSqqioJxH4J0hym/N0G4C3Kb1WD3DO0fC01QR4IBcxG0eWQT7OEZDZBGilbtzf89jQR2gn2GpMWbqIRCtok0Mo01gRCpEr7o+KNupZF0xReeDy8jgqZsc8xmEqtplmDc+WBe9cjkFJVPEzKNzE40rvSWZxudqqVyYGOC+E+RXTnDo4syUOjZpAGMY54RDCDKcFJlwyqr2awBJBkgVLas1ShrNVsvw7QOSMYyaH2bZ8b2bAtnQwqlA4/SSgNVRPmcM/aGUUpXtPHg7hSKVH00TRZp5GMeO7iBFGmkgrfq8g3YpEn4jB78c6vV8cacRc3owSPYGItSEzLITWXLfVXXk1IJbEJl01XdpHkHbF+Zra80UKCzS453+63L/KazQJBktYwaoDsb8qbRf3fhaRn9d6dnNTNtiCENzdfrqGyOqsqQ6zMvmHBZU1f0oJONxcpGVWpkal1bc/oH+OEw+g=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block060_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
