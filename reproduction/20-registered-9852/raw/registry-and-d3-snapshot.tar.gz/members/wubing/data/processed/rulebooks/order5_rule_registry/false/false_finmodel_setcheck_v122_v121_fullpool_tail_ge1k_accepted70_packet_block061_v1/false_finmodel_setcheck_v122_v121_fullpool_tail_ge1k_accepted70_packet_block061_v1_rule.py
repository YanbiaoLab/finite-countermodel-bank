from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,2,1],[2,0,2],[1,1,0]],"priority":901,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block061.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block061","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmTtuwzAMQCmDKdQiA9OxkxDkDJ015Dg9hLJ5zBGKnqRHqz5OSDe2C1RxawN8g0GAMhVL4k8xABBgANykpx/R/iPPAG9YxCNKBRFBAyaJDjCKF0IctjNDtg4stlYqnOubYB4B9g0sj4Oh1tr72HLXJU0PYfW6wDwuj13igiiKoih/wlmkhY92eqw/1s7WlIyTctE2mM/JsRZM0P1RlN9X3P1Ke05842PlDS66bMhhBHUDVgDyNp19r0mYgVBCf47q1steZQ6I8hQWua+0uuGKsnpiGZni1ukSVHL1ytqBMhI5At0Y0/VUajPbO8tPXt5PZu3m1b3cM7OV007d+RbHeJvFh25aoxujKLXO5rOzWXY2Ks6W3evU9TokEk5NZuN6HOME7MFu7IWfLLqpnm1U1d58xa42moz+yxHi4tnvPxo1Ly8js8k+fvbrBGI38vFM6B3COvgCXzUZUg=='
_TARGET_BITS_PAYLOAD = 'eNrtmTtuwzAMQI/WkxQ9QkZv0SF6nAyae4ag0NQx4RC0QkNYrEQ5odzYLlDFrQ3wDQYBylQsiT8lEJGhAfCcnnZE+48ciJ4xizssFQBALYUkOsIoXjBx2DEM2dqL2PhS4VzfhPBB9NrS8tgHaLy/jy13XdL0KKxeF1jG8dglLoiiKIryJ2yKtPDYTI+1u9rZ2pxxUi46mfAwOdZTMLo/ivL7irtfac+JbW2svMlFlzUcRlA3YAWgbNPG9pqEGTA59HNU97bsVeYAgKfwKH2l1w1XlNUTy8gUt7aXoMLVq2gHykiUCHRjTNdTqc1sTyK/2/J+krXnF/d2z8yWTzt057s4xicWP7tpg26MotQ6m2Vn8+JskJ2N3Wvb9TpQJJyazCb1OMYJxIPd2As/WXRTPduoqrn5imNtNBn9l8PExfPffzRqXl5GZiv7+NmvE0DcyMYzoXcI6+AL7TxX5A=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block061_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
