from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,2,3,3],[3,0,0,3],[1,3,3,3],[0,1,2,3]],"priority":902,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block062.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block062","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmT9uwyAUh99DDGSjVg+ALIYeA0Uekq1Holu6RVYP0KMWHDfGxSQsSfPn9y0Gi2ceYBk+manAK5Gjp+XbMgmiPpaFGifCnAxRaUVU9ZK28lUR3l9l+IoAAAAAAAAAoMSX7Tdtu25CcSN49AcZpenTtu1kN1F59lJo0i6UZTANzUGvdrvpUeZ47WKcpMySfN81264byvxHkLLMho6iw/nYWBTdpmhW74cQZUNKK5losSedh6ljUsu6OOarax3xojgyMR/jx8EkaupyizW/a3paVl3JH9+GQG9n7hubuma2lMNrs5r1E1vrF077yKa0WAcAgDvAi9LH83DX8pnNCvwHiqfd02WHCr0QYGpWUGBmHwctphPhfPFZ6sUAV3OSkTcwNPdhaEvqIf8a8Ln/PveLxD4Cboof5gEdjg=='
_TARGET_BITS_PAYLOAD = 'eNrtmT9uwyAUh4/aA1RWt2YrR+qWDFbFMTIgiwNULlsYEO8FHCfGxSQszb/+vsVg8cwDLMMnExf4Zpb8b3lRxJ65iWVvx4nQZ0NsWvFVvaStRFWEEFcZvmUAAAAAAAAAKPGqmk3XffWhuPE0+oOL0vSuum6ym6g8b84bNjKUXTANQ0GvVqvpUfp0bWOc48ySRNP267YdyvRLkLLMho6iw4nY2BfdpmhWn4cQq0JKO5dosWCTh9lTUsu6OOZrah3xT5GsYz5ajINJ1FTmFquPa3peVmXJH7dDoFAz941NZT9byuG12c36ia3ND6V9ZFNarAMAwAMgfOnjebir6MJmBW6BpWn3lNmhwiwE6JoV9JjZ58H46UQ4X3xyZjFA1pxk3B0MTX5oXrN9yr8GdOm/z+PisI+Au2IPZnBTqA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block062_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
