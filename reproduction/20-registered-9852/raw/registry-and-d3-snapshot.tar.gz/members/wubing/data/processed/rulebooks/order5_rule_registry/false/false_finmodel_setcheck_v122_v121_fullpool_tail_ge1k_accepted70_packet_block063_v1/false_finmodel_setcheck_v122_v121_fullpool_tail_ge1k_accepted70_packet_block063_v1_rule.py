from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,0,2],[2,2,0],[1,1,1]],"priority":903,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block063.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block063","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2D8KgzAUx/EXyVA3jxAkQ8cewVE3j+BRMjjE1cGhp21VaMF/tKBB5PtZDPyGh0+jSZRMZXJukV4JSqvkIpLHeKuzwKXxcDVxgEYLAAA//LKqcNWe9rKNvBd52vgbbxTOsuL+DnVydLFMzPg9+VQ2PAEAABCW3jxVrJzac0nkutq23i8k/YbArWQA/p9s78m9nAy7b02HACCUF4r3DQM='
_TARGET_BITS_PAYLOAD = 'eNrt2D8KgzAUx/HTdnDo2gwOOYpH6FZHj9DRIYQcwc0OoXlahRb8UxQ0iHw/i4Hf8PBpNEmQoUKO7e1ngrsJchLVs7/VUaBt3V1dHaHRAgDAgl9WFq/axZy2keUjtzf14o3CUVbcv6Gv9i5WiOu/J9/KjicAAADi8n9PFTMdtlwS6SQ1V6Umks+GQM9kANZPtnZyTyfd7tvTIQCIpQHBemQz'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block063_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
