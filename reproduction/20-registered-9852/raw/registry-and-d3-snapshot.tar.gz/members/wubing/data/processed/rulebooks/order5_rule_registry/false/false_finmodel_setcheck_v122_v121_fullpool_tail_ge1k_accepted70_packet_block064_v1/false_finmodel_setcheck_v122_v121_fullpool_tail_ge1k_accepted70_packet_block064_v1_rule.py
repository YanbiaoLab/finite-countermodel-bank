from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,3,1,3],[3,3,3,3],[3,3,0,3],[3,3,0,3]],"priority":904,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block064.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block064","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrt2DEOgjAUBmDbNLFxolzAtulBCHkD3IqBoY4SD+BRPJYbFqmkicZoAiaY/1sKL4U/bd9UtoH/dnZHypX65pNrn9q+mamxvwAAAAAAAAAAAAArFa+Pu8raMq+JvM+UsaU0Yom0k5uCKnvwUilriaRplwhrOpqCaqeGZVHrQ1i2/mPbcanDwMIp6ebF0mcNu/Qwi/1Pe0Tc+6AYX3gsDr2vx0cWSzKWk7YRsfxQpP/lzzkAH7gBPg9tqg=='
_TARGET_BITS_PAYLOAD = 'eNrt2DEOgjAUBmA2j+VRPIDB0Q4M3AqGF8JBmrZegDKZmjStFqmkicZoAiaY/1sKL4U/bd9Uf4X/tuMH6rT+5pNNlrq8mamwvwAAAAAAAAAAAAArFa+P81qIpquIGOu1FI2Rdom0PZ+CanFkRmshiIwslggrc5qCKq6HZVHBQli//mM7O6PC4MMpqfLF0mcN22Ywi9NPe8Te+6AdX1wsDr2vxkcfSyaWk7axsfzQpv91zzkAH7gBDnEDjA=='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block064_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
