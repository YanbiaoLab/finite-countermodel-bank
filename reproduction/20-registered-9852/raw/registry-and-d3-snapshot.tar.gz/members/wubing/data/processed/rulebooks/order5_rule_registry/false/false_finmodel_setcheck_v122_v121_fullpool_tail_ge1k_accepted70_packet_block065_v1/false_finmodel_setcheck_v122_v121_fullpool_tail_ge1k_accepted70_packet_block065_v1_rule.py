from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,2,1,3],[2,0,3,1],[3,1,2,0],[1,3,0,2]],"priority":905,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block065.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block065","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmVEOgyAMhqHpQx85Akfp0Tj6Jg7mHEVmdDPL/z1gpKatJv1b1TsD9tOqqWFxIR99XRzlNZbTU7nHkqYh5AweRn5sfiGha1BuWA73LGc5BuB/IEtxUu/qdhFvonMcqYUZFyo4WVfCuN6KC0cjCiA16VRdloS1oRfJUhHjcSzx3Ufk28q/6Q0AAMDuzsZutJPFAW9mZ9PqQV6jhnc911ZeNJIGAGMEe8igwVkEQwgAV+xsUpqIolDBz0n9kYXj1vj0WWebowU2+h6vRyszvdB/CQcAY6QaluePFD4sGjG1azUrCKX8GS66Q+UEAAD2cwOcNQsZ'
_TARGET_BITS_PAYLOAD = 'eNrtmVEOgyAMho/O0XoUjsAjD01hEwdzrkVmdDPL/z1gpKatJv1bNWUDTtNKTrHkUI6pLVnK6uvpqdxjRdUQSgYPIz82v5DQNag3HA/3HM9yDMD/IJbiuN7VehFvQnOc2ArTL1Rwsq6Ecb3lF45GFCC2pF1zWRMmRS+cpSLG41iSuo8o6cq/6Q0AAMDuzsZ5tJP5AW9mZ6PmIb5GDe96TlpeMpIGAGMEe8iQwVkEQwgAV+xssTYRQqGCn+P6Iwv7rfHps842Rwts9D1ej1ZmeqH/Eg4AxkgyLM8fKXxYNGHRa7UoiLjyGc7nQ+UEAAD2cwOwPGYd'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block065_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
