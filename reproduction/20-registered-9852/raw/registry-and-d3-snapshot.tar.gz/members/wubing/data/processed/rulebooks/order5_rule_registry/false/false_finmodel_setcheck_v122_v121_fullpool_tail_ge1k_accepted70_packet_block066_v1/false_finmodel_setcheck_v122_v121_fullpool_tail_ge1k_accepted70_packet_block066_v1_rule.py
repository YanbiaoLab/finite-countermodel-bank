from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[2,1,0,1],[2,2,1,0],[2,2,2,2],[2,2,3,2]],"priority":906,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block066.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block066","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNrtmU9u00AUxr+ZGI2DUGKXDUhWO7WMYAUsvajkofIiXXGEVpyAZSWQMkFdOAiJtOIAnAMJZG7QI/gALLzMovIwxo2bhqiAlBFNNL/NjPQif5o3//K+GTmARMO9ADeS56RuIiBz8U8cwqkYXRJ40h3wcbZM66V4p144WAVSf8YnWCMmAA91m/59At4Sb7qjp+Xh4kA/R3wUcepMIBYiCelWzF/yLT7reDdKisKT5Oj/ZOhB3HZfo4c+LGuAVEnbV5odo2qlYrNuUat1NieRuTpsElrnVKPXv2tOLX7TnAj6NCrHT189g1G1R+PoLAMfRyGi0zQ9yVzfD8MTz4hYoT7+WhZxnVONXjGluaF9YL1Yp7IXS5wTdkxKFCTvgBrabIowBzlhXrPZHOzh+LdbwGLZSOb+zsZgktmMrAPifXu1yCy8u+vYlFgsFovFYgGOiqs6mMS6qLle0SHAtk3S7aNSbfdCl6PDhfBq6/v8yluaGSTzUTJcXDZrhBo2Hi+tc6pqS42bEyt+jGbTkz/+kn3FdbUVWxeforNBSGVtAE3SLd/nNE2zDPsQWzo6CMfNz9J0FWJSJb3mxGjdyNycR/h8Oy6kLkULUMGC4o6ELkn7poy0SrFATxkLRLPZPNReE8gGnCNz1v+fV6+9DG4Jl49wzcvh5buW9PY3Ymzf4F70nWJIXPAy8WpXnlaqI42IiQNBD4QTnQqBbkR83WTwfbhG9va0OyiTTKr7rsu/K05dF/5U36a7Rsb2E4dhnjg='
_TARGET_BITS_PAYLOAD = 'eNrtmU9u00AUxsfqIksvOMAcgRtggcQ5OABqg4SwFxWZSCB1yQlQe4SumoVVxhILL4EVCMudVpFgQ+1EiHiE4/k6xo2bhqiAlBFNNL/NjPQif5o3//K+6ZUAQ8P3IW7E81TdJEBQ4J84QOnIakng42Qg/GCZ1iF/Tt6UWAVMfyZTWCO6gEh1G/59Al6ovHOqp+XL4kAfJaKXiKrsgi9EIjVxZLbkW2LWyW+U5DRnav//ZOhr3HZfYYwRLGsAI1HbJ5pTo2oukbMurdWmm5NIjxw0Ca1zqtHrvzCnFr9sTgR9Grn+h9fvYVTts59sBxB+kiLZCcPdoMiyNN3NjYhR8uTXsojrnGr0inHNDe2pHMc6leOY4a6Se8oFVd4UlaHNRpQs4SmZN5utxFvs/XYLWCwbydzf2RiSSZuRdYA/a68WFqQ/TkqbEovFYrFYLMA+vaqDVayLmusVHYY4s0m6fTik7W7pcrS/EF5tfe9deUszg2Q+qvqLy2aNIP3G463qnJLaUhPmxOid3mx6vE8Pgwe4rrZi6+Jxsj1IK1YbQN3wPMtEFYZBgGPwcx0dpH7zszBchRgj0bg5MVo30jPnEb47iynTpShFxeWQ/mTQJenIlJHmEDnUUyaHvNlsOWqvCWoDzpE56//Pq9deBreEy0e45uXw8l2L5ccbMbb7KLZGJe2rAsKN8tqVrxwyZUbE+BGvjniZ7HCOSaIy3QTIMhRG9nZnMnCjgJFvRSHuEVEVBbKOvk1PjIztAsUQ0u8='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block066_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
