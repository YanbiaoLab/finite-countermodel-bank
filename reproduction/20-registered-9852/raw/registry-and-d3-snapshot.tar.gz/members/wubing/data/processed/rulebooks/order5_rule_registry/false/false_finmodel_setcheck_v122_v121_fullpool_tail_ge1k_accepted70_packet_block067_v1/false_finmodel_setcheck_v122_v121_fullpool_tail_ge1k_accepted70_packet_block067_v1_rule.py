from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin3_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin3_explicit","model_table":[[0,1,1],[0,1,2],[1,0,2]],"priority":907,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block067.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block067","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WUuS3CAMBYoFs6PmBEpVDqKaVR/Lqersc+TwkTEYyabdplkk5cZGH/SkJ81fhU6hSuuZ/kUF8T+rjAsPDhZlwkP8DR3mHWGBuKMXYcMp69kNEsys/CP0Gz7v6O7EZZUVd5sdm07DfpdMybvaNqbEJx+/SQ5aTydTFmvW3XC6q0yxPr4bvvFB+fzZj/oK31S7QYH4mSILDO5VXjxZZPZGZlOU7XwGWR3mbn4ldWC9U/GOdHXWTmZ1Kag+uZz+pDQxfmcsurAPrWeIAfiUsBqJ85eYEKasKi/Z6cJwB1v/AbBlQaj0dLAJGXYi2L6TIB1D0yuYDLZUUWJRoHQ/CQ6LR1ME2VJ1Jl2fP8H8vetHVGNCfKIYES17uAlsIiVKu0CM4KYckzkAp8aEsJGBpSeEzVNUo2eWb4eNXNmsVCpOHHCpsjG3ueOv+R5eulIjvem56CVj4DLYste8DLbWayCEjR8Dm+JLKBWDLnqt4ACz0/+ARvreGMZrTGlnZDg5gIAEuS5F6c6YVq9zGcBEuXG8GgsfNkWvC7hb/BbUrgNbpg+b10rFpc7rKo0EFvNt5ggVl1Ink/SGKr1JL0Gf4gshqnN0SgKtA1xRTq/uhhEauffaakz5MQpKlh3KMKva2N2tSCMxHviAHmxNI1QDoZIhBZBIIx/FmM1rPqXO1g6KrS1VunKbep9hZBr5VXvNU47uRgSVDF9kkJmQfWa2WKfZTHxu+QBsxqxY/tc4QO8BbTZ3L7typRuwMXyAmWgwYCsct/pwNXOzC9bAMI8iaKEv6dUoCMtxXnE8mpexTVUoKNcRy08W9KcfwCRBrhxnWELEyiiuqO0yuzmQ7b1mWq8xDuBkFFdUduV0r3+X6zn1GjeBYmQUV3RBqY95EQqF9yKNtIc9uHE4zDsHluXHkIQ/Mh2GWqERGikR0ZxWoM4aNwxIHPA8OwjSIU5KqN/RbYiDW1CWv6M3rESn+gqyEhJ7d08q0sg8j8VTrv8SKxFp5IIjB+MVsDGTcDOhr7fqu4n1UqCwocl3TSOToAcUPrCShMtt3DnY+sQuNb/+tK/QRwMS4U8L7dxQHTUkEue3QkThEIQNS9peSDA0+tdj0hy+l1cy2GAIRghvjjHq0f+pR94GwiujfyZsLg1I/Easr48Uh3u24E0zqp65Lo4GJEYP5doNae4KQ8HcTjhhdmL6ppHebXPpMNhSCe1HBpxjI9hCSi0sVrNRfODn/14pg2A='
_TARGET_BITS_PAYLOAD = 'eNq9WUuS3CAMPXL2mar4WL3q0kFSFZ1git2woIDwkTEYyabdplkk5cZGH/SkJ81vD9qDT+sr/Qse43/GWx0eNC7ehof4G2jIO8JCccctwob2RrEbJJhZ+UfsN1Tecd2Jyyor7jY7Jp0G/S6ZknedaUyJTyp+kxy0nk6mLMauu+F0XZliVHw3fKOC8vmzp/8J31S7QYH4mScLLOxVXhRZZPdGZlO86XyGWR3mbv4ldXC9U/GOXHXWTmZ1KeA/ubT7pDQxfmcsurAPra8QA/gpYTUS5y8xIUxZVV4y04XBDrbqA2DLgsC76WATMuxEsH0nQS6GpvI4GWyposSiQOl+EhwWBbYIMqXqTLo+dYL5e9dTVGNCfIIYES17uAlsIiVKu0iM4KYckzkAp8aEsJGB5SaEzZeoRs8s3w4bubIZqVScOOBSZWNuc8df8z28dKVWelNx0UvG4GWwZa8pGWyt11AIGzUGNs+XUCoGXfQawQF2p/8BjVS9MYzXmNLOyNByACEJ0l2Kcp0xrV7nMpCJcqt5NRY+bIpeF3C3qC2odQe2TB82r5WKS53XVRqJLObbzBEqLqVOJukNVXqbXsI+xRdCVOfolARaB+iinFvdjSM0cu+11ZjyYxSULDuUYVe1obtbkUZCPPCBPdiaRqgGQiVDCiCRRj6KMZvXVEqdrR0UW1uq1OU23T7DyDTyp/aaohzdjQgqGarIIDMx+8xusU6zmfjc8gHcjFmx/KtxgNsD2m7uXnblyjVgY/gAM9FgwFY4bvXhauZmF66BYR9F0EJf0qtREJTjlOd4NC9jm6pQUK4jlmcW9KcfwCRBuhxnWULEyiiuqO2yuzmQ6b1mW68xDuBkFFdUduV07/6W6zn1GjeBYmQUV3RB6Y55EQiF9yKNNIc9uNUwzDsHluHHkIQ/Mh2HWqERGikR0ZxWsM4aNwxINPI8OwhyIU5KqN/RbYiDW/SGv6M3rATt+wqyEhJzd08q0sg8j4VTrv8SKxFp5AIjB8MVsDGTcDuhrzf+u4n1UqCgocl3TSOToAcWPrCShMtt3DnY+sQuNb/qtK9wRwMS4U8L7dzQHzUkEuc3QkTBEIQtS9peSDA0+ndj0jS8l1cy2HAIRoBvjjHq0f+pR94GwiujfyZsLg1I1Easr48Uh3u24E07qp69Lo4GJNYN5doNafoKQ4HcTmhhdmL7ppHebXPpMNhSCe1HBpxjI9hCSi0s1rFRfODn/+5I7cc='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block067_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
