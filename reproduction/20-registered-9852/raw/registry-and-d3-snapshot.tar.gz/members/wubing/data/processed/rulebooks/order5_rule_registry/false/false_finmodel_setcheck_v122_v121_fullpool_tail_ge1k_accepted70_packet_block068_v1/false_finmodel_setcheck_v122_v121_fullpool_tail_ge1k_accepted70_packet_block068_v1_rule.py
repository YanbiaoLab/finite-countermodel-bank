from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[0,0,0,1],[1,1,1,0],[1,2,2,2],[3,0,0,3]],"priority":908,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block068.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block068","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNq9WbGO00AQfetsiJFOFxMFQcFJxkoRiRM11WU5UlyoKOmOT4Ae6baA5q6BiA/IB1DkAyhc8Qtp3SBRpkwRnS/xRpEgnsSnbN4o2sg7tl/eet7MePNVGSBtYGmnxZgWI9rFaNzBEeLioDic5wqlluXNcgcuG4JjFgmO9DoUPGfCPMaSw36SPEeSY9QROKIuObrSvYzEBIHkmK5Asg0qdenSFRW94Ri5rxJCbiY2+n9H+M/tQ6xPiCFbmhdWA8VmBdgVBwyOWpMDljk0xUGbF2A9DpjNe5oVIQsV5ZM/Vw9ZaLd5+Bd1Elg6eY4ThGCJrRbT1hGXT8KYBpa9iZSGJqH9vEmuu18iktgefw8eKZ7YGuDZbU4ESyeKiDaLiGB4kRDBstq0x0M7xcuABmabzKc2ZoLht2o8m9LE9gqW1iHgKTNpoUZkhg/UGPnRGV4kCUlvdthvDfp9ErV3Q0Psft62wOt+zOt40fuwsmR3wIzIOrNoj/BN89DazHW0kYGikYsCYvjjnLmQhsmM9m7obMdOzNxrd5Rt34mxv7xS+3yyXR5eS7ptbs9aHa9JbbyjYPtV/ZnsOoZvbaQyM7v4HLPaSB3Z9S66tzZSZLYEUn7R5J3wQzR8bSnkTGvgfZfGir/+IliGid+QjEQ0pRev/MYvOxEsNv5r+er/o7IsX1KGsj1TzXv38G6qFb1wz9roxPaxrJxvTsVlyeZebaRTVqWT9+6mtcTjEGGz3iChvHGP5Yd0AHuw0pyqEiSl0rxHqjFqnaKqhCSqze1oI1VShUawbwtxBwr4epc='
_TARGET_BITS_PAYLOAD = 'eNq9WbGO00AQ9SlFypRING7zC1Qu+IAUfEA+AOVo7hoo9iR6+ASuo6QiV+RgcxU1OqQUkbF0FCCi4JxOwiEb7yPxRpEgnsSnbN4o2sg7tl/eet7MePPcaiCaYmnXxRgVI0bFqN3BHZLioDisBRalFgaTcgfOp4KjngqO6DQTPFfCPFqSQ72SPHeSoz0UOGImOQbSvbTEBLnkaKxAwg0qM+nSFRWz4Wi7rxJCbibR5n9H9s/tM6xPSCBbFBQ2B8XqBdgZBwyO2oQDFjo0y0GrFWB9DpgK+oYVIQsVBc2HZ79ZaEdB9gAzEljU/IobZGCJbZ7Q1hHnP7KEBhZeptbAkNCenMSngxcpSWw/j/Nflie2KXh2FBDBoqYlotVTIhi+xESwcN7o89Cu8TmngakJ86m1mGB4ZKffGjSxfYKidQj4zkxamBOZ4Q01Rp4OOxdxTNKb6vTG3V6PRO1dRxO7n/dj8Lof/TFZ9D6sLDnoMiNyxizabTwzPLQRcx1VqmFp5NKcGP74wFxIzWRGezd0tmMnpua1Owq378Sox16pvbzZLg+vJV1Ntmetodek1tpRsP2q/kp23cK3NiKZmVp8blltpEnVehfdWxspMlsCWb9o8k74IRq+kRRyetz1vkujxF9/kS/DxG9IpiKaNYtXfu2XnQiWaP+1fPX/UVmWLylD4Z6p5q17eCfVil62Z210YntdVs43p5KyZHOvNtIpq9LJe3fTRuJxiLBZb5BQ3rhb8kM6gP1Zac5WCZJSad4j1Wi7TlFVQhLV5na0kTauQiPft4X4C0GI9pA='
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block068_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
