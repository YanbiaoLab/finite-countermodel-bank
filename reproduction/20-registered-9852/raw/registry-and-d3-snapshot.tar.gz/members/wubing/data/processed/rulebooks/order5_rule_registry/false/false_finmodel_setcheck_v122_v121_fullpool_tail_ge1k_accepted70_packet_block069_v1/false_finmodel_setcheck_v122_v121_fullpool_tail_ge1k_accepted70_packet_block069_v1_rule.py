from __future__ import annotations

import base64
import json
import zlib


_LAW_COUNT = 62576
_METADATA = json.loads('{"certificate_family":"finmodel_fin4_explicit_v122_v121_tail_packet","certificate_generator":"fin_table_decide","certificate_mode":"finmodel","coverage_kind":"source_target_sets","model_family":"fin4_explicit","model_table":[[3,1,3,3],[3,3,1,3],[0,0,0,0],[3,3,0,3]],"priority":909,"rule_id":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block069.v1","rule_key":"false.finmodel.setcheck.v122_v121_fullpool_tail_ge1k.accepted70_packet.block069","rule_version":1,"verdict":false,"verification_mode":"setcheck+remote_smoke"}')
_SOURCE_BITS_PAYLOAD = 'eNpjZCAGmDCMAnqCC9uYsUs0bOelni2KDCwCDdgkDMCkFgODAF79DR5MQNLBw4FlNMZGwSgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCoY5yN39dtvu3ez0sexB7uf79eXldPLan//fb2XvE6KPZQ3fz5vdPnOGTl77sO/n6/X/OUaT7ygYiaChyUGIg4HFQ4mzgcFThVFAQcnJhaUBKE4T2wSYOBSAJnMoMDAyMLIoMDiA7GFkGA5j5w63+UAUloJk061166RQhSJzw8PRJjEUSLKt4jYOiQPht0NCGVGritW5q1aNpnTsoIVBwIGBCYsEMJ0ygQgWSBJlYhAAqWSEKIem29FaAwGuuVo+FfHHEiIFF131W4pOac4LOLF4grtif9MPDiaKM5unk5Cni4uHQid6OTXJQ0mpSWVSRweoIGvp4FBsERhiAQkAsilKGg=='
_TARGET_BITS_PAYLOAD = 'eNr7958YcPr/KKAn0Pf8g12i3uMT9Wy59//3+3psEufB5NX//9/j1V+//S+Q3L99/+/RGBsFo2AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGOZgkouQp4vLD/pYJj+JR6Gho4NOXmNm4FCd4viWPpbVcxicVDE2ppPX+B3ZRAIYvo8m31EwEkF97f633///3n73W/3/bbf/vb9/d+/u3/VAcZrY9v7v9/tAk7/f///v/7/f9//vB9nz7/9wGDvfr/IRRGEpSHxVAwOfogotm7RiBdokxn2SbGtXwSFhv0Jl9ap/qFVFyKTQ0NGUjh1U/3+///9fLBLAdPoXRPyGJNG//9+DVP6DKIem29FaAwE0dx2Ter0BS4j06+26UN1rei1xvXlM/o57BbXs3/9SnNm27X27bffu7ffL0Mup3O1379bezi0vBxVk1eXf71W/H2IBCQCaSCcc'
_EXCLUDED_BLOCK_PAYLOADS = ()


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(_SOURCE_BITS_PAYLOAD)
_TARGET_BITS = _bitset_from_zlib_payload(_TARGET_BITS_PAYLOAD)
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in _EXCLUDED_BLOCK_PAYLOADS
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def false_finmodel_setcheck_v122_v121_fullpool_tail_ge1k_accepted70_packet_block069_v1_rule(source_id: int, target_id: int) -> dict | None:
    if source_id < 1 or source_id > _LAW_COUNT:
        return None
    if target_id < 1 or target_id > _LAW_COUNT:
        return None
    if source_id == target_id:
        return None
    if not _bitset_has(_SOURCE_BITS, source_id):
        return None
    if not _bitset_has(_TARGET_BITS, target_id):
        return None
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets, target_id
        ):
            return None
    return json.loads(json.dumps(_METADATA))
