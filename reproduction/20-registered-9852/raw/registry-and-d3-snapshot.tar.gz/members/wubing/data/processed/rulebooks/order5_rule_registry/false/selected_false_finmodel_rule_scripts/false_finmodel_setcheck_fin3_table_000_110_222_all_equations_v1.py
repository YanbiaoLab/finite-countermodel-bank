from __future__ import annotations

import argparse
import base64
import json
import zlib


RULE = json.loads('{"coverage_count": 127233088, "excluded_block_payloads": [], "law_count": 62576, "model_family": "fin3_table_000_110_222", "model_order": 3, "model_table": [[0, 0, 0], [1, 1, 0], [2, 2, 2]], "priority": 294, "rule_id": "false.finmodel.setcheck.fin3_table_000_110_222.all_equations.v1", "rule_key": "false.finmodel.setcheck.fin3_table_000_110_222.all_equations", "source_bits_payload": "eNrtWTFr20AUfrKMrYAVKSFDS0odhAoZCy0hUyyKhihTf0IoJVMC6dYh4INS4mwmdCnp4J9QWsisEOjU7u2mbBk1ahBRpZNoqe+eIpPzo0MeWEZ6uvvuHe+7e9/pveYBhF0o7IhfQ36FFX71ypseHPIbT8//0kwDqUWZJXdANkQcSabLHWHWR5psIc8hRoYF7A3WpIc5Ji7W2ZMFxLGO9eUZmKd1Wyjp9ISy6kE0REJZHAihlH/ur860pwSZXAgOg48sf9wGu7hrFw/N4t2iyeu/L+7mP7vqK8y46UBiCQcb0oBBGZpFAxaVaBoNWsrBBjRgrAytS4MWl2hEOXLDwfo0YPdkuyfb/0Y2IqCKbIRgIRWr60ui+ZBtSAgW6fGADu0IbuhSklmE84iXunOxb1r3UUxGts2I6Y+p0B5QLlqgM0Jq71JGBh/c023HaRGR7dRfDnyfKLSXeWQnI4MIbWc5cJeWiPjtBc6J6zhEoa0HlBmJCvV52ATGbTq0Fcp5ZLYHGllwdstYY2SxvaCcSA/WCNEMytBuKSMVC+OoVhxGioVxWisOU7XCmNWKQ6ZYGNdrtlixMN6qEViFolMqskI8sqRfHJ8orcTwMnJxM9STq2OlKgsdeniVj2OQqt3Z0JPwouB7dXawt6e0jMQWz6Lg2//643tPIdnQcnX7iwns4FxpFWajaObzsfb5ovNMJRoKxo/7N37CHMiWWlKyCUumJdshms91Uq2FkhYiq2WvRbOcwJU9HiJkm+o4FvAjLZ1hpZlUzJKQbV/oJhDyk41GHx82R2tXZYlItnemNG3+tbH2dIbQ8C9XIDkUSu64GaAf0EB2KHTXzaCammNh0OzSapA2ub2Fxtu6p/1ZoqZM8olPkjYAvt9cO1dlpLkhhNZZbZA24LJr9qnxRP4GEUAGrA==", "source_count": 2104, "source_slug": "false_finmodel_setcheck_fin3_table_000_110_222_all_equations_v1", "target_bits_payload": "eNrtWTFr20AUVtCgUWO3aEv2diqUaA409Cd4aOlSgrc4lMIZMnRrIJlCKfkJmaoMosiZQmihY6BCxKGlGUIiRYbKxrJepZNoqe+eIpPzo0MeWEZ6uvvuHe+7e9/pdeYB2EMobItfbX6FS371ypsBbPMbL83/dC0DqVlaJHeA1kUchpbKHbbWR5ocIc/BRIYF7B3WZIA5Wj7W2bdfiOMU68tLMM/ktlD06Qll1QOri4Ry0xNCKf/8pdG0pwRprQiOhI8sfzyGsLgbFw/j4t2iyfu/L+7nv7Dqy9a4pUBiBgfr0oBBGVpEA2aVaBkNms7BejRgrAxtSINmlmhEObLAwfo0YPdkuyfb/0Y2IqCKbIRgNhWr60ui+ZCtSwhmpWaPDm0LFuhSkkWE84iXunOxx9nwu0lGtmOLpedUaBeUixakjJDa+5SRwSt//TAIJkRkW3evHNclCu0gj2yjkxChfbxy/OtrIn57TrDhBwFRaKcOZUaiQn0e1oL2mA7tknIeWehBRhZcOEnOGFlsnygn0oMzQrSEMrRbykjFwtiqFYeWYmGs14pDXa0wZrXikCkWxvWazVQsjI9qBFah6JSKLBuPzOgXxydKKzG8jLw5tlNjcVOpykKHbi/m4+jpanc29CS8KPg+vNjZ21NaRmKLZ1Hw7T59+GigkGxouXq4FgPbWVVahYUoWvy5nT1bGX1RiYaC8eP+k2WYA9n0SEo2YcmMZDtE87k2qrVQ0kJktew1a5YTuLLHbYRsUx2bAr6V6TOsNK2KWRKy7QrdOEJ+sk7n5c/maOOqLBHJ9iaWps2/1s6+zhAa/uUKJIdCxh03A/QDGsgOhe66GVRTsykMmj2JGqRNbm+h8bbuZX+WqCmTfOKTpA2A6zbXzlUZGZ8IoY1+NEgb8NkD9rzxRP4GO0Bqig==", "target_count": 60472}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in RULE.get("excluded_block_payloads", [])
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def rule_record() -> dict:
    hidden = {
        "source_bits_payload",
        "target_bits_payload",
        "excluded_block_payloads",
    }
    return {key: value for key, value in RULE.items() if key not in hidden}


def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets,
            target_id,
        ):
            return False
    return True


def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem",
        "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000",
        "set_option maxHeartbeats 0",
        "",
        "def submission : Goal := by",
        f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>",
        "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend(
        [
            f"      | _, _ => (0 : Fin {order})",
            "  }",
            f"  refine ⟨Fin {order}, m, ?_⟩",
            "  decideFin!",
            "",
        ]
    )
    return "\n".join(lines)


def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])


def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {
        "verdict": "false",
        "source_id": source_id,
        "target_id": target_id,
        "rule_id": RULE_ID,
        "rule": rule_record(),
        "code": render_lean_certificate(),
    }


def _main() -> int:
    parser = argparse.ArgumentParser(
        description="Standalone finite-model false Lean certificate for one order5 rule.",
    )
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()

    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True))
        return 0

    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False))
        return 0

    print(render_lean_certificate())
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
