from __future__ import annotations

import argparse
import base64
import json
import zlib


RULE = json.loads('{"coverage_count": 133176220, "excluded_block_payloads": [], "law_count": 62576, "model_family": "fin5_explicit", "model_order": 5, "model_table": [[4, 0, 1, 2, 3], [4, 0, 1, 2, 3], [4, 0, 1, 2, 3], [4, 0, 1, 2, 3], [4, 0, 1, 2, 3]], "priority": 326, "rule_id": "false.finmodel.setcheck.structured.affine_mod5_a0_b1_c4.all_equations.v1", "rule_key": "false.finmodel.setcheck.structured.affine_mod5_a0_b1_c4.all_equations", "source_bits_payload": "eNrtmcFugzAMhinqIccE7QEgyqQ9RkA5wE7bG02IQ7h1qA+wR50NKBFaWlFNq1bp/w6VbMd2bFwO5pBlmZXZLmzXFJ1zGXgkvsynK5SiXzeYyXupKt24QTbieWS5HI3Ws9ULpbQmy8m0gzfeadH2TZlfivxhau1MbYraFk/5e6dDpG2eqdV6npxVKapjZ5Sq+PiqHGQfskfH1dyImlzoDBtJkMda4rkCAAAAAAAAAAAAAADAL1nXx4kd7l+sdc8mRG31uPg6J6rB/lQlFtepHIuZbscudCHSsdCXop9ciDrfnH09HZMJVWKvncgRWxHrIoFre5ti1E2L8kTXONGJ+341R2xFrIsEru21CFG3LUqt+8MDvpojtCLWRQLXdrjrRL50fP3ErO0bG3tbIy9+JNk3Nv+5keARsct3tsSs7XtH3/bWuu+f7Rsl6glX", "source_count": 2206, "source_slug": "false_finmodel_setcheck_structured_affine_mod5_a0_b1_c4_all_equations_v1", "target_bits_payload": "eNrtmcFugzAMhh91DzCx3sgBob3RdhocIshjTFoUeICJ5JhDRakNKBFaWlFNq1bp/w6VbMd2bFwO5jRNk3LTLlTVDJWUE3gknvSLHKylX1noTAhnO9PIwjX+K2e5z7Uxs1V4a40hy0HXhdBCGl+XTT9eivyqWyN1q4dWDd/jW2VCpG2erDZmnpxV6btjpa3t+PiqLFwZskfH1dz4llzoDBtJcMfW4bkCAAAAAAAAAAAAAADAL1nXx4kd7l+sdZ91iFqbfPGV0neF+qlKLK5TORYz3Y5d6EKkY6HsfZnJEHW+OfsKOuYSqsReO5EjtiLWRQLX9p7FqJsWjYmucaID9/1qjtiKWBcJXNvHEKJuW5Ra94cHfDVHaEWsiwSu7XTXifys+PqJWds3Nuq2Rl78SLJvbP5zI8EjopbvbIlZ2/eOvu2tdd8/2xkmlmff", "target_count": 60370}')
RULE_ID = RULE["rule_id"]
LAW_COUNT = RULE["law_count"]


def _bitset_from_zlib_payload(payload: str) -> bytes:
    return zlib.decompress(base64.b64decode(payload.encode("ascii")))


_SOURCE_BITS = _bitset_from_zlib_payload(RULE["source_bits_payload"])
_TARGET_BITS = _bitset_from_zlib_payload(RULE["target_bits_payload"])
_EXCLUDED_BLOCKS = tuple(
    (
        _bitset_from_zlib_payload(source_payload),
        _bitset_from_zlib_payload(target_payload),
    )
    for source_payload, target_payload in RULE.get("excluded_block_payloads", [])
)


def _bitset_has(raw: bytes, eq_id: int) -> bool:
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))


def rule_record() -> dict:
    hidden = {
        "source_bits_payload",
        "target_bits_payload",
        "excluded_block_payloads",
    }
    return {key: value for key, value in RULE.items() if key not in hidden}


def covers_pair(source_id: int, target_id: int) -> bool:
    if source_id < 1 or source_id > LAW_COUNT:
        return False
    if target_id < 1 or target_id > LAW_COUNT:
        return False
    if source_id == target_id:
        return False
    if not _bitset_has(_SOURCE_BITS, source_id):
        return False
    if not _bitset_has(_TARGET_BITS, target_id):
        return False
    for excluded_sources, excluded_targets in _EXCLUDED_BLOCKS:
        if _bitset_has(excluded_sources, source_id) and _bitset_has(
            excluded_targets,
            target_id,
        ):
            return False
    return True


def _render_false_certificate_lean(model_table: list[list[int]]) -> str:
    order = len(model_table)
    if order < 10:
        table_json = json.dumps(model_table)
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "import JudgeFinOp.MemoFinOp\n"
            "set_option maxRecDepth 1000000\n"
            "open MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f"  let m : Magma (Fin {order}) := {{\n"
            f"    op := finOpTable \"{table_json}\"\n"
            "  }\n"
            f"  refine ⟨Fin {order}, m, ?_⟩\n"
            "  decideFin!\n"
        )
    lines = [
        "import JudgeProblem",
        "import JudgeDecide.DecideBang",
        "set_option maxRecDepth 1000000",
        "set_option maxHeartbeats 0",
        "",
        "def submission : Goal := by",
        f"  let m : Magma (Fin {order}) := {{",
        "    op := fun i j =>",
        "      match i.val, j.val with",
    ]
    for row_index, row in enumerate(model_table):
        for column_index, value in enumerate(row):
            lines.append(f"      | {row_index}, {column_index} => ({value} : Fin {order})")
    lines.extend(
        [
            f"      | _, _ => (0 : Fin {order})",
            "  }",
            f"  refine ⟨Fin {order}, m, ?_⟩",
            "  decideFin!",
            "",
        ]
    )
    return "\n".join(lines)


def render_lean_certificate() -> str:
    return _render_false_certificate_lean(RULE["model_table"])


def solve_pair(source_id: int, target_id: int) -> dict | None:
    if not covers_pair(source_id, target_id):
        return None
    return {
        "verdict": "false",
        "source_id": source_id,
        "target_id": target_id,
        "rule_id": RULE_ID,
        "rule": rule_record(),
        "code": render_lean_certificate(),
    }


def _main() -> int:
    parser = argparse.ArgumentParser(
        description="Standalone finite-model false Lean certificate for one order5 rule.",
    )
    parser.add_argument("--source-id", type=int)
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()

    if args.metadata:
        print(json.dumps(rule_record(), ensure_ascii=False, indent=2, sort_keys=True))
        return 0

    if args.source_id is not None or args.target_id is not None:
        if args.source_id is None or args.target_id is None:
            raise SystemExit("--source-id and --target-id must be provided together")
        print(json.dumps(solve_pair(args.source_id, args.target_id), ensure_ascii=False))
        return 0

    print(render_lean_certificate())
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
