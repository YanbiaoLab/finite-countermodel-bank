# False Solver d3

d3 以 d2 为基础，加入吴兵维护的完整离线 False 冻结库：9,450 个
`selected_false_finmodel_rule_scripts` 主模型，加上直接注册规则中精确去重的
402 个模型，共 9,852 个有限反例模型（countermodel）。d2 文件保持不变。

## 模型口径

- 9,450 个主冻结脚本包含 9,450 张互不相同的乘法表。
- 475 条有限模型 manifest 精确去重为 402 张乘法表。
- 两部分完整乘法表 SHA-256 交集为 0。
- `selected_false_finmodel_rule_scripts/` 根部的 6 个代表性脚本都与 402 个注册
  模型重复，不另行计数。
- d2 原有 145 张 W31 可物化表与本次 9,852 张表重叠 51 张；因此 d2+d3
  实际包含 9,946 张不同的可物化有限乘法表。d2 的结构化有限模型和无限结构
  冻结证书继续保留。

这里的模型身份是完整 Cayley 表精确 SHA-256，不是按数学同构类去重。完整审计见
`false9852_model_audit.json`。

## 运行时

d3 仍是 formula-only 单文件 solver：

1. 先尝试 d2 的 W31 False-244 模型和冻结证书；
2. 再把规范化 source 公式哈希映射到 order5 方程序号，并从紧凑倒排索引中选择
   False-9852 候选模型；
3. 对每个候选的真实乘法表重新穷举验证 source 恒真、target 不恒真，只有验证通过
   才返回 `REFUTED`；
4. 未命中时完整回退到 d1。

公式序号完全由公式文本计算，不读取输入 case 中的 Equation ID。source 覆盖 bitset
只用于候选调度，不能直接产生结论。5,105,642 条 source→模型关系采用压缩二进制
索引嵌入，避免运行时盲扫 9,852 张表。

## 构建和验证

```bash
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d3/build_solver.py
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d3/validate_solver.py
```

验证器执行确定性双重构建、9,852 张表逐张 SHA-256 校验、完整 source 索引重计数、
62,576 条公式哈希复核、跨两段模型库的语义抽样、d2 False-244 全量回归、Equation ID
不变性检查、d1 fallback 和 `python -I -S` 隔离运行。

## `run-prover` 边界

当前可信 Judge 编排只把原始 `SOLVED` 当作 True，并以 `verdict=true` 校验。d3
继续返回 `REFUTED` 和 `judge_verdict=false`；在 `run-prover` 增加 False verdict
编排前，本地验证不能称为新的远端 Judge 评测。
