#!/usr/bin/env python3
"""Build d3 from d2 plus the complete frozen 9,852-table False library."""

from __future__ import annotations

import ast
import base64
from array import array
import hashlib
import json
import mmap
from pathlib import Path
import runpy
import struct
import sys
import tempfile
from typing import Iterable, Iterator
import zlib


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def find_repo_root(start: Path) -> Path:
    for candidate in (start, *start.parents):
        if (candidate / ".git").exists() and (candidate / "members/wubing").is_dir():
            return candidate
    raise RuntimeError(f"could not locate repository root from {start}")


REPO_ROOT = find_repo_root(HERE)
D2_PROVER = HERE.parent / "d2/solver.py"
RUNTIME_SOURCE = HERE / "runtime.py"
OUTPUT = HERE / "solver.py"
MANIFEST = HERE / "manifest.json"
MODEL_AUDIT = HERE / "false9852_model_audit.json"
FALSE_ROOT = (
    REPO_ROOT
    / "members/wubing/data/processed/rulebooks/order5_rule_registry/false"
)
PRIMARY_ROOT = (
    FALSE_ROOT / "selected_false_finmodel_rule_scripts/primary_nonzero_model_scripts"
)
EQUATION_GENERATOR_SOURCE = (
    REPO_ROOT / "members/wubing/src/math_distill_stage2/order5_pair_dataset.py"
)

LAW_COUNT = 62_576
PRIMARY_MODEL_COUNT = 9_450
REGISTERED_MODEL_COUNT = 402
PORTFOLIO_MODEL_COUNT = 9_852
REGISTERED_TABLE_RULE_COUNT = 475
REGISTERED_MANIFEST_COUNT = 476
SELECTED_ROOT_REPRESENTATIVE_COUNT = 6

D2_PROVER_SHA256 = "f044c640a31106f3cfea4840c9024230eb4b26b32d2c54350afef6165c15df12"
EQUATION_GENERATOR_SHA256 = "e7da6489f8c36f91d48f69f41928885c9f37b28e371f3d5ac1fa3bd6db0d2d36"
EQUATION_VECTOR_SHA256 = "7fb9c0e85bee412baa7030bafec311c65a75502a2c25bdd0b94171b324585b1d"
MANIFEST_VECTOR_SHA256 = "84d6a43b1f180aac0e9591c53740186f7aed0f10673b7ce702334f2b4244e10e"
REGISTERED_RULE_VECTOR_SHA256 = "fb0e6eea56051baa6c0f695fbbb820f76c2e3a9699cfae5f1911866d1766f769"
PRIMARY_SCRIPT_VECTOR_SHA256 = "adb9a620da8c2ef707fe1e8a65bd34683855043477db1ed1a7b01a9e2a95ab28"
SELECTED_ROOT_VECTOR_SHA256 = "cf3a6350d73a6fd8cc47bf784c0c5570c08ff6371f48bed62c43d84bf503bddf"


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def path_vector_sha256(paths: Iterable[Path]) -> tuple[int, str]:
    digest = hashlib.sha256()
    ordered = sorted(paths)
    for path in ordered:
        relative = path.relative_to(FALSE_ROOT).as_posix()
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(sha256_path(path).encode("ascii"))
        digest.update(b"\n")
    return len(ordered), digest.hexdigest()


def primary_paths() -> list[Path]:
    return sorted(PRIMARY_ROOT.glob("*.py"))


def manifest_paths() -> list[Path]:
    return sorted(FALSE_ROOT.glob("*/*.manifest.json"))


def registered_rule_paths() -> list[Path]:
    return sorted(FALSE_ROOT.glob("*/*_rule.py"))


def selected_root_paths() -> list[Path]:
    return sorted(
        FALSE_ROOT.glob("selected_false_finmodel_rule_scripts/false_finmodel_setcheck_*.py")
    )


def verify_pins() -> None:
    scalar_pins = {
        D2_PROVER: D2_PROVER_SHA256,
        EQUATION_GENERATOR_SOURCE: EQUATION_GENERATOR_SHA256,
    }
    for path, expected in scalar_pins.items():
        actual = sha256_path(path)
        if actual != expected:
            raise RuntimeError(
                f"frozen input drift: {path}: expected {expected}, got {actual}"
            )
    vectors = (
        (manifest_paths(), REGISTERED_MANIFEST_COUNT, MANIFEST_VECTOR_SHA256),
        (registered_rule_paths(), REGISTERED_MANIFEST_COUNT, REGISTERED_RULE_VECTOR_SHA256),
        (primary_paths(), PRIMARY_MODEL_COUNT, PRIMARY_SCRIPT_VECTOR_SHA256),
        (
            selected_root_paths(),
            SELECTED_ROOT_REPRESENTATIVE_COUNT,
            SELECTED_ROOT_VECTOR_SHA256,
        ),
    )
    for paths, expected_count, expected_digest in vectors:
        count, digest = path_vector_sha256(paths)
        if (count, digest) != (expected_count, expected_digest):
            raise RuntimeError(
                "frozen library vector drift: "
                f"expected {(expected_count, expected_digest)}, got {(count, digest)}"
            )


def normalized_formula(value: str) -> str:
    return "".join(value.replace("*", "◇").split())


def table_sha256(table: list[list[int]]) -> str:
    return sha256_bytes(
        json.dumps(table, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    )


def parse_json_loads_line(line: str) -> dict:
    expression = ast.parse(line.strip(), mode="exec").body[0].value
    if not isinstance(expression, ast.Call) or not expression.args:
        raise RuntimeError("expected json.loads assignment")
    payload = ast.literal_eval(expression.args[0])
    value = json.loads(payload)
    if not isinstance(value, dict):
        raise RuntimeError("expected JSON object")
    return value


def parse_literal_line(line: str) -> str:
    expression = ast.parse(line.strip(), mode="exec").body[0].value
    value = ast.literal_eval(expression)
    if not isinstance(value, str):
        raise RuntimeError("expected string literal assignment")
    return value


def read_primary_rule(path: Path) -> dict:
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("RULE = json.loads("):
                return parse_json_loads_line(line)
    raise RuntimeError(f"missing RULE assignment in {path}")


def read_registered_rule(path: Path) -> tuple[dict, str | None, str | None]:
    metadata = None
    source_payload = None
    target_payload = None
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("_METADATA = json.loads("):
                metadata = parse_json_loads_line(line)
            elif line.startswith("_SOURCE_BITS_PAYLOAD = "):
                source_payload = parse_literal_line(line)
            elif line.startswith("_TARGET_BITS_PAYLOAD = "):
                target_payload = parse_literal_line(line)
            if metadata is not None and source_payload is not None and target_payload is not None:
                break
    if metadata is None:
        raise RuntimeError(f"missing metadata in {path}")
    return metadata, source_payload, target_payload


def decode_bitset(payload: str) -> bytes:
    raw = zlib.decompress(base64.b64decode(payload.encode("ascii")))
    expected = (LAW_COUNT + 7) // 8
    if len(raw) != expected:
        raise RuntimeError(f"bitset length drift: expected {expected}, got {len(raw)}")
    return raw


def set_bit_indices(raw: bytes | bytearray) -> Iterator[int]:
    for byte_index, original in enumerate(raw):
        value = original
        while value:
            least = value & -value
            bit = least.bit_length() - 1
            index = byte_index * 8 + bit
            if index < LAW_COUNT:
                yield index
            value &= value - 1


def first_set_bit(raw: bytes | bytearray) -> int:
    return next(set_bit_indices(raw))


def merge_bits(target: bytearray, source: bytes) -> None:
    if len(target) != len(source):
        raise RuntimeError("cannot merge bitsets of different lengths")
    for index, value in enumerate(source):
        target[index] |= value


def canonical_equations() -> list[str]:
    source_root = REPO_ROOT / "members/wubing/src"
    sys.path.insert(0, str(source_root))
    try:
        from math_distill_stage2.order5_pair_dataset import generate_equations_up_to_order

        equations = list(generate_equations_up_to_order(5))
    finally:
        try:
            sys.path.remove(str(source_root))
        except ValueError:
            pass
    if len(equations) != LAW_COUNT:
        raise RuntimeError(f"equation count drift: {len(equations)}")
    digest = sha256_bytes("".join(f"{value}\n" for value in equations).encode("utf-8"))
    if digest != EQUATION_VECTOR_SHA256:
        raise RuntimeError(f"equation vector drift: {digest}")
    return equations


def encode_formula_index(equations: list[str]) -> bytes:
    rows = []
    seen = set()
    for equation_index, formula in enumerate(equations):
        digest = hashlib.sha256(normalized_formula(formula).encode("utf-8")).digest()
        if digest in seen:
            raise RuntimeError("normalized equation hash collision")
        seen.add(digest)
        rows.append((digest, equation_index))
    rows.sort()
    payload = bytearray()
    for digest, equation_index in rows:
        payload.extend(digest)
        payload.extend(struct.pack("<H", equation_index))
    return bytes(payload)


def encode_tables(tables: list[list[list[int]]]) -> bytes:
    payload = bytearray()
    for table in tables:
        n = len(table)
        if not 1 <= n <= 255 or any(len(row) != n for row in table):
            raise RuntimeError("invalid square table in frozen portfolio")
        payload.append(n)
        for row in table:
            for value in row:
                if type(value) is not int or not 0 <= value < n:
                    raise RuntimeError("table entry outside carrier")
                payload.append(value)
    return bytes(payload)


def native_little_endian_bytes(values: array) -> bytes:
    copied = array(values.typecode, values)
    if sys.byteorder != "little":
        copied.byteswap()
    return copied.tobytes()


def build_library() -> dict:
    counts = array("I", [0]) * LAW_COUNT
    model_memberships = array("I", [0]) * PORTFOLIO_MODEL_COUNT
    first_sources = array("I", [0]) * PORTFOLIO_MODEL_COUNT
    first_targets = array("I", [0]) * PORTFOLIO_MODEL_COUNT
    tables: list[list[list[int]]] = []
    hashes: list[str] = []
    hash_to_index: dict[str, int] = {}

    primary = primary_paths()
    for model_index, path in enumerate(primary):
        rule = read_primary_rule(path)
        table = rule["model_table"]
        digest = table_sha256(table)
        if digest in hash_to_index:
            raise RuntimeError(f"duplicate primary table identity: {digest}")
        hash_to_index[digest] = model_index
        tables.append(table)
        hashes.append(digest)
        source_bits = decode_bitset(rule["source_bits_payload"])
        target_bits = decode_bitset(rule["target_bits_payload"])
        first_sources[model_index] = first_set_bit(source_bits)
        first_targets[model_index] = first_set_bit(target_bits)
        membership_count = 0
        for equation_index in set_bit_indices(source_bits):
            counts[equation_index] += 1
            membership_count += 1
        model_memberships[model_index] = membership_count
        if membership_count != int(rule["source_count"]):
            raise RuntimeError(f"primary source-count drift in {path}")

    manifest_table_hashes = set()
    for path in manifest_paths():
        manifest = json.loads(path.read_text(encoding="utf-8"))
        table = manifest.get("model_table")
        if table is None:
            continue
        digest = table_sha256(table)
        manifest_table_hashes.add(digest)
        if digest not in hash_to_index:
            hash_to_index[digest] = len(tables)
            tables.append(table)
            hashes.append(digest)
    if len(manifest_table_hashes) != REGISTERED_MODEL_COUNT:
        raise RuntimeError(
            f"registered unique-table drift: {len(manifest_table_hashes)}"
        )
    if manifest_table_hashes & set(hashes[:PRIMARY_MODEL_COUNT]):
        raise RuntimeError("primary/registered exact table overlap unexpectedly nonzero")
    if len(tables) != PORTFOLIO_MODEL_COUNT:
        raise RuntimeError(f"portfolio identity drift: {len(tables)}")

    bitset_bytes = (LAW_COUNT + 7) // 8
    registered_source_bits = {
        model_index: bytearray(bitset_bytes)
        for model_index in range(PRIMARY_MODEL_COUNT, PORTFOLIO_MODEL_COUNT)
    }
    registered_target_bits = {
        model_index: bytearray(bitset_bytes)
        for model_index in range(PRIMARY_MODEL_COUNT, PORTFOLIO_MODEL_COUNT)
    }
    registered_table_rule_count = 0
    for path in registered_rule_paths():
        metadata, source_payload, target_payload = read_registered_rule(path)
        table = metadata.get("model_table")
        if table is None:
            if source_payload is not None or target_payload is not None:
                raise RuntimeError(f"non-table rule unexpectedly has bitsets: {path}")
            continue
        registered_table_rule_count += 1
        if source_payload is None or target_payload is None:
            raise RuntimeError(f"registered table rule lacks bitsets: {path}")
        digest = table_sha256(table)
        model_index = hash_to_index[digest]
        if model_index < PRIMARY_MODEL_COUNT:
            raise RuntimeError("registered rule unexpectedly overlaps primary table bank")
        merge_bits(registered_source_bits[model_index], decode_bitset(source_payload))
        merge_bits(registered_target_bits[model_index], decode_bitset(target_payload))
    if registered_table_rule_count != REGISTERED_TABLE_RULE_COUNT:
        raise RuntimeError(
            f"registered table-rule drift: {registered_table_rule_count}"
        )

    for model_index in range(PRIMARY_MODEL_COUNT, PORTFOLIO_MODEL_COUNT):
        source_bits = registered_source_bits[model_index]
        target_bits = registered_target_bits[model_index]
        first_sources[model_index] = first_set_bit(source_bits)
        first_targets[model_index] = first_set_bit(target_bits)
        membership_count = 0
        for equation_index in set_bit_indices(source_bits):
            counts[equation_index] += 1
            membership_count += 1
        model_memberships[model_index] = membership_count

    if any(count == 0 for count in model_memberships):
        raise RuntimeError("frozen model without a source-formula membership")

    selected_root_hashes = set()
    for path in selected_root_paths():
        selected_root_hashes.add(table_sha256(read_primary_rule(path)["model_table"]))
    if len(selected_root_hashes) != SELECTED_ROOT_REPRESENTATIVE_COUNT:
        raise RuntimeError("selected root representative identity drift")
    if not selected_root_hashes <= manifest_table_hashes:
        raise RuntimeError("selected root scripts are not duplicates of registered models")

    offsets = array("I", [0])
    total = 0
    for count in counts:
        total += count
        offsets.append(total)
    cursors = array("I", offsets[:-1])
    candidate_bytes = total * 2
    with tempfile.TemporaryFile(prefix="false9852-source-index-") as handle:
        handle.truncate(candidate_bytes)
        with mmap.mmap(handle.fileno(), candidate_bytes, access=mmap.ACCESS_WRITE) as mapped:
            def add_memberships(model_index: int, raw: bytes | bytearray) -> None:
                for equation_index in set_bit_indices(raw):
                    position = cursors[equation_index]
                    mapped[position * 2 : position * 2 + 2] = struct.pack(
                        "<H", model_index
                    )
                    cursors[equation_index] += 1

            for model_index, path in enumerate(primary):
                rule = read_primary_rule(path)
                add_memberships(model_index, decode_bitset(rule["source_bits_payload"]))
            for model_index in range(PRIMARY_MODEL_COUNT, PORTFOLIO_MODEL_COUNT):
                add_memberships(model_index, registered_source_bits[model_index])
            if cursors != offsets[1:]:
                raise RuntimeError("source-index cursor accounting drift")
            candidate_payload = native_little_endian_bytes(offsets) + mapped[:]

    equations = canonical_equations()
    formula_index = encode_formula_index(equations)
    table_payload = encode_tables(tables)
    hash_payload = b"".join(bytes.fromhex(value) for value in hashes)
    identity_vector_sha256 = sha256_bytes(
        "".join(f"{value}\n" for value in hashes).encode("ascii")
    )

    sample_indices = (0, 1, 100, 1_000, 9_449, 9_450, 9_851)
    semantic_samples = [
        {
            "model_index": model_index,
            "model_sha256": hashes[model_index],
            "source_equation_id": int(first_sources[model_index]) + 1,
            "target_equation_id": int(first_targets[model_index]) + 1,
            "order": len(tables[model_index]),
            "library_segment": (
                "selected_primary" if model_index < PRIMARY_MODEL_COUNT else "registered"
            ),
        }
        for model_index in sample_indices
    ]

    return {
        "tables": tables,
        "hashes": hashes,
        "table_payload": table_payload,
        "hash_payload": hash_payload,
        "formula_index": formula_index,
        "candidate_payload": candidate_payload,
        "candidate_membership_count": total,
        "identity_vector_sha256": identity_vector_sha256,
        "equations": equations,
        "semantic_samples": semantic_samples,
        "source_membership_min": min(model_memberships),
        "source_membership_max": max(model_memberships),
        "source_membership_sum": sum(model_memberships),
        "registered_manifest_table_rule_count": registered_table_rule_count,
        "selected_root_duplicate_count": len(selected_root_hashes),
    }


def render_b64_constant(name: str, payload: bytes) -> str:
    encoded = base64.b64encode(payload).decode("ascii")
    lines = [f"    {encoded[index:index + 100]!r}" for index in range(0, len(encoded), 100)]
    return f"{name} = (\n" + "\n".join(lines) + "\n)"


def render_model_section(library: dict) -> str:
    values = (
        "# === BEGIN COMPLETE FROZEN FALSE-9852 MODEL LIBRARY ===",
        f"_FALSE9852_LAW_COUNT = {LAW_COUNT}",
        f"_FALSE9852_MODEL_COUNT = {PORTFOLIO_MODEL_COUNT}",
        f"_FALSE9852_PRIMARY_MODEL_COUNT = {PRIMARY_MODEL_COUNT}",
        f"_FALSE9852_REGISTERED_MODEL_COUNT = {REGISTERED_MODEL_COUNT}",
        f"_FALSE9852_CANDIDATE_MEMBERSHIP_COUNT = {library['candidate_membership_count']}",
        f"_FALSE9852_IDENTITY_VECTOR_SHA256 = {library['identity_vector_sha256']!r}",
        render_b64_constant(
            "_FALSE9852_TABLES_ZLIB_B64", zlib.compress(library["table_payload"], 9)
        ),
        render_b64_constant("_FALSE9852_HASHES_B64", library["hash_payload"]),
        render_b64_constant("_FALSE9852_FORMULA_INDEX_B64", library["formula_index"]),
        render_b64_constant(
            "_FALSE9852_CANDIDATES_ZLIB_B64",
            zlib.compress(library["candidate_payload"], 9),
        ),
        "# === END COMPLETE FROZEN FALSE-9852 MODEL LIBRARY ===",
    )
    return "\n\n".join(values)


def d2_table_hashes() -> set[str]:
    namespace = runpy.run_path(str(D2_PROVER), run_name="_audit_false_solver_d2")
    return set(namespace["_OFFLINE_FALSE244_FINITE_TABLES"])


def strip_d2_main(source: str) -> str:
    marker = '\nif __name__ == "__main__":\n    _main()\n'
    normalized = source.rstrip() + "\n"
    if not normalized.endswith(marker):
        raise RuntimeError("d2 main-guard shape drift")
    return normalized[: -len(marker)].rstrip()


def build() -> dict:
    verify_pins()
    library = build_library()
    d2_hashes = d2_table_hashes()
    portfolio_hashes = set(library["hashes"])
    overlap = sorted(d2_hashes & portfolio_hashes)
    if len(d2_hashes) != 145 or len(overlap) != 51:
        raise RuntimeError(
            f"d2/False-9852 overlap drift: d2={len(d2_hashes)}, overlap={len(overlap)}"
        )

    d2_source = strip_d2_main(D2_PROVER.read_text(encoding="utf-8"))
    runtime_source = RUNTIME_SOURCE.read_text(encoding="utf-8")
    model_section = render_model_section(library)
    generated = "\n\n".join(
        (
            d2_source,
            model_section,
            runtime_source.rstrip(),
            'if __name__ == "__main__":\n    _main()',
            "",
        )
    )
    compile(generated, str(OUTPUT), "exec")
    OUTPUT.write_text(generated, encoding="utf-8")

    audit = {
        "schema_version": "false-prover-d3-false9852-model-audit-v1",
        "status": "passed",
        "identity": "exact canonical Cayley-table SHA-256; not quotient by isomorphism",
        "directory_scope": str(FALSE_ROOT.relative_to(REPO_ROOT)),
        "library": {
            "primary_frozen_script_count": PRIMARY_MODEL_COUNT,
            "primary_unique_table_count": PRIMARY_MODEL_COUNT,
            "registered_manifest_count": REGISTERED_MANIFEST_COUNT,
            "registered_table_rule_count": REGISTERED_TABLE_RULE_COUNT,
            "registered_unique_table_count": REGISTERED_MODEL_COUNT,
            "primary_registered_exact_overlap_count": 0,
            "selected_root_representative_script_count": SELECTED_ROOT_REPRESENTATIVE_COUNT,
            "selected_root_new_identity_count": 0,
            "false9852_unique_table_count": PORTFOLIO_MODEL_COUNT,
        },
        "d2_composition": {
            "d2_materialized_table_count": len(d2_hashes),
            "d2_false9852_exact_overlap_count": len(overlap),
            "d2_only_table_count": len(d2_hashes - portfolio_hashes),
            "combined_d2_false9852_unique_table_count": len(d2_hashes | portfolio_hashes),
            "overlap_sha256": overlap,
        },
        "source_index": {
            "law_count": LAW_COUNT,
            "candidate_membership_count": library["candidate_membership_count"],
            "source_membership_min_per_model": library["source_membership_min"],
            "source_membership_max_per_model": library["source_membership_max"],
            "source_membership_sum": library["source_membership_sum"],
            "runtime_contract": "formula hash selects candidates; every returned model is exhaustively revalidated on source and target",
        },
        "semantic_samples": library["semantic_samples"],
        "anchors": {
            "d2_prover_sha256": D2_PROVER_SHA256,
            "equation_generator_sha256": EQUATION_GENERATOR_SHA256,
            "equation_vector_sha256": EQUATION_VECTOR_SHA256,
            "manifest_vector_sha256": MANIFEST_VECTOR_SHA256,
            "registered_rule_vector_sha256": REGISTERED_RULE_VECTOR_SHA256,
            "primary_script_vector_sha256": PRIMARY_SCRIPT_VECTOR_SHA256,
            "selected_root_vector_sha256": SELECTED_ROOT_VECTOR_SHA256,
            "false9852_identity_vector_sha256": library["identity_vector_sha256"],
        },
        "payloads": {
            "table_raw_bytes": len(library["table_payload"]),
            "hash_raw_bytes": len(library["hash_payload"]),
            "formula_index_raw_bytes": len(library["formula_index"]),
            "candidate_index_raw_bytes": len(library["candidate_payload"]),
        },
    }
    MODEL_AUDIT.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    output_bytes = generated.encode("utf-8")
    manifest = {
        "schema_version": "false-prover-build-v3",
        "name": "false-prover-d3",
        "status": "draft",
        "architecture": {
            "base": "false-prover-d2",
            "single_file_runtime": True,
            "standard_library_only": True,
            "formula_only_input": True,
            "equation_id_used_from_case": False,
            "finite_models_fail_closed_revalidated": True,
            "d2_fallback_retained": True,
        },
        "model_bank": {
            "false9852_unique_table_count": PORTFOLIO_MODEL_COUNT,
            "selected_primary_count": PRIMARY_MODEL_COUNT,
            "registered_unique_count": REGISTERED_MODEL_COUNT,
            "d2_materialized_table_count": len(d2_hashes),
            "d2_false9852_overlap_count": len(overlap),
            "combined_unique_materialized_table_count": len(d2_hashes | portfolio_hashes),
            "source_candidate_membership_count": library["candidate_membership_count"],
        },
        "source": {
            "d2_prover_path": str(D2_PROVER.relative_to(REPO_ROOT)),
            "d2_prover_sha256": D2_PROVER_SHA256,
            "false_library_path": str(FALSE_ROOT.relative_to(REPO_ROOT)),
            "false9852_identity_vector_sha256": library["identity_vector_sha256"],
        },
        "runtime": {
            "path": str(RUNTIME_SOURCE.relative_to(REPO_ROOT)),
            "sha256": sha256_bytes(runtime_source.encode("utf-8")),
        },
        "audit": {
            "path": str(MODEL_AUDIT.relative_to(REPO_ROOT)),
            "sha256": sha256_path(MODEL_AUDIT),
        },
        "output": {
            "path": str(OUTPUT.relative_to(REPO_ROOT)),
            "bytes": len(output_bytes),
            "sha256": sha256_bytes(output_bytes),
        },
        "run_prover_compatibility": {
            "prove_entrypoint": True,
            "transport_with_judge_v3_off": True,
            "required_false_judge_supported_by_current_worker": False,
            "reason": "current required-Judge worker maps raw SOLVED only to verdict=true; d3 returns REFUTED with judge_verdict=false",
        },
    }
    MANIFEST.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return manifest


if __name__ == "__main__":
    print(json.dumps(build(), ensure_ascii=False, indent=2, sort_keys=True))
