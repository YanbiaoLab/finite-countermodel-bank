# v97 False Solver d1

d1 是从 solver v97 False 路径剥离出的首个独立反模型证明器（countermodel
prover）草稿。

## 契约

`solver.py` 定义：

```python
def prove(case: dict, config: dict) -> dict:
    ...
```

`case` 只需要 `ordinal`、`source_formula` 和 `target_formula`。命中时返回
`status=REFUTED`、`verdict=false`、Python 复验后的有限岩浆表、目标失败赋值和
v97 同源的 `judge_lean`；未命中返回 `UNKNOWN`，异常返回 `ERROR`。任何候选模型
都必须再次通过公式语义检查，搜索失败不会被解释为 True。

搜索顺序保留 v97 False 路径的相对次序：

1. 早期显式 rulebook 表；
2. affine 模型 portfolio；
3. affine-n9、principal-feedback 和 fin6-sparse-decode 表；
4. F2^3 affine completion；
5. Fin2/Fin3 穷举及 Fin4/Fin5 有界随机搜索；
6. v97 cheap counterexample families。

原 v97 的 Equation ID bitset 函数仍可能存在于机械抽取的可审计源码片段中，但
`prove` 的可达调用图不引用它们。模型 portfolio 只按输入公式的实际有限模型语义
选择。

## `run-prover` 边界

当前 `run-prover` 文档中的可信 Judge 编排只会把原始 `SOLVED` 当作 True 证明并以
`verdict=true` 校验。d1 因而有意返回 `REFUTED` 和 `judge_verdict=false`，不会伪装成
`SOLVED`。它可以通过通用 transport 在 `judge_v3_mode=off` 下运行，但在
`run-prover` 增加 False verdict 编排前，不能把远端结果称为 Judge 验证通过。

## 构建和低内存验证

```bash
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d1/build_solver.py
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d1/validate_solver.py
```

构建器固定 v97 源码 SHA-256，生成单文件 `solver.py` 和 `manifest.json`。
验证器只运行有界的语义、来源等价、确定性重建和隔离进程 smoke，不启动远端评测。
