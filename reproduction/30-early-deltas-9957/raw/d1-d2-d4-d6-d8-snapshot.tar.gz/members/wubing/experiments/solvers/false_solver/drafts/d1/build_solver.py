#!/usr/bin/env python3
"""Build a standalone formula-only False solver from the frozen v97 slice."""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent


def find_repo_root(start: Path) -> Path:
    for candidate in (start, *start.parents):
        if (candidate / ".git").exists() and (candidate / "members/wubing").is_dir():
            return candidate
    raise RuntimeError(f"could not locate repository root from {start}")


REPO_ROOT = find_repo_root(HERE)
V97_SOURCE = (
    REPO_ROOT
    / "members/wubing/experiments/solvers/baseline_solver_v5_vtd_iter/versions/v97/solver.py"
)
RUNTIME_SOURCE = HERE / "runtime.py"
OUTPUT = HERE / "solver.py"
MANIFEST = HERE / "manifest.json"

V97_SOURCE_SHA256 = "b48147f11410346dd64d8da97f49016db1ae6711f953e4b3b67cca09fa450e97"

# These are every v97 FALSE entry point used by the v97 coordinator.  Their
# transitive top-level dependency closure is extracted mechanically in source
# order.  The ID-indexed selectors remain auditable but are unreachable from
# the formula-only runtime appended below.
FALSE_ROOTS = (
    "make_false_code",
    "find_rulebook_affine_n9_micro_orbit_counterexample",
    "find_rulebook_principal_feedback_counterexample",
    "find_rulebook_fin6_sparse_decode_counterexample",
    "find_rulebook_explicit_table_counterexample",
    "make_rulebook_explicit_table_false_code",
    "should_try_rulebook_affine",
    "find_rulebook_affine_counterexample",
    "make_affine_false_code",
    "find_f2_3_affine_completion_counterexample",
    "search_counterexample",
    "find_counterexample_cheap",
)

V97_FALSE_IMPORTS = (
    "import base64",
    "import collections",
    "import json",
    "import os",
    "import re",
    "import sys",
    "import zlib",
    "from itertools import product",
)


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_text(value: str) -> str:
    return sha256_bytes(value.encode("utf-8"))


def top_level_definitions(tree: ast.Module) -> dict[str, ast.AST]:
    definitions: dict[str, ast.AST] = {}
    for node in tree.body:
        names: list[str] = []
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.append(node.name)
        elif isinstance(node, ast.Assign):
            names.extend(
                target.id for target in node.targets if isinstance(target, ast.Name)
            )
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            names.append(node.target.id)
        for name in names:
            definitions[name] = node
    return definitions


def false_dependency_nodes(source: str) -> list[ast.AST]:
    tree = ast.parse(source, filename=str(V97_SOURCE))
    definitions = top_level_definitions(tree)
    missing_roots = sorted(set(FALSE_ROOTS) - definitions.keys())
    if missing_roots:
        raise RuntimeError(f"missing v97 FALSE roots: {missing_roots}")

    selected_names: set[str] = set()
    pending = list(FALSE_ROOTS)
    while pending:
        name = pending.pop()
        if name in selected_names:
            continue
        node = definitions.get(name)
        if node is None:
            continue
        selected_names.add(name)
        referenced = {
            child.id
            for child in ast.walk(node)
            if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load)
        }
        pending.extend(referenced - selected_names)

    selected_node_ids = {id(definitions[name]) for name in selected_names}
    return [node for node in tree.body if id(node) in selected_node_ids]


def render_v97_false(source: str) -> tuple[str, list[str]]:
    tree = ast.parse(source, filename=str(V97_SOURCE))
    nodes = false_dependency_nodes(source)
    segments = [ast.get_source_segment(source, node) for node in nodes]
    if any(segment is None for segment in segments):
        raise RuntimeError("could not recover a v97 source segment")

    selected_locations = {(node.lineno, node.end_lineno) for node in nodes}
    names = sorted(
        name
        for name, node in top_level_definitions(tree).items()
        if (node.lineno, node.end_lineno) in selected_locations
    )
    section = "\n".join(
        (
            "# === BEGIN V97 FALSE ENGINE (READABLE TRANSITIVE SLICE) ===",
            *V97_FALSE_IMPORTS,
            "",
            *segments,
            "# === END V97 FALSE ENGINE ===",
        )
    )
    return section, names


def build() -> dict:
    v97_bytes = V97_SOURCE.read_bytes()
    actual_v97_sha256 = sha256_bytes(v97_bytes)
    if actual_v97_sha256 != V97_SOURCE_SHA256:
        raise RuntimeError(
            "v97 source drift: "
            f"expected {V97_SOURCE_SHA256}, got {actual_v97_sha256}"
        )
    v97_source = v97_bytes.decode("utf-8")
    runtime_source = RUNTIME_SOURCE.read_text(encoding="utf-8")
    runtime_tree = ast.parse(runtime_source, filename=str(RUNTIME_SOURCE))
    runtime_names = top_level_definitions(runtime_tree)
    if "prove" not in runtime_names:
        raise RuntimeError("runtime.py must define prove(case, config)")

    false_section, extracted_names = render_v97_false(v97_source)
    generated = "\n".join(
        (
            "#!/usr/bin/env python3",
            "# Generated deterministically by build_prover.py. Do not hand edit.",
            f"# v97_source_sha256={V97_SOURCE_SHA256}",
            f"# runtime_sha256={sha256_text(runtime_source)}",
            "",
            false_section.rstrip(),
            "",
            runtime_source.rstrip(),
            "",
        )
    )
    compile(generated, str(OUTPUT), "exec")
    OUTPUT.write_text(generated, encoding="utf-8")

    output_bytes = generated.encode("utf-8")
    manifest = {
        "schema_version": "v97-false-prover-build-v1",
        "name": "v97-false-prover-d1",
        "status": "draft",
        "architecture": {
            "single_file_runtime": True,
            "standard_library_only": True,
            "formula_only_input": True,
            "false_only": True,
            "fail_closed_countermodel_revalidation": True,
            "equation_id_used_by_prove": False,
            "id_indexed_v97_selectors_retained_for_audit_but_unreachable": True,
        },
        "source": {
            "path": str(V97_SOURCE.relative_to(REPO_ROOT)),
            "sha256": V97_SOURCE_SHA256,
            "false_roots": list(FALSE_ROOTS),
            "extracted_top_level_names": extracted_names,
        },
        "runtime": {
            "path": str(RUNTIME_SOURCE.relative_to(REPO_ROOT)),
            "sha256": sha256_text(runtime_source),
        },
        "output": {
            "path": str(OUTPUT.relative_to(REPO_ROOT)),
            "bytes": len(output_bytes),
            "sha256": sha256_bytes(output_bytes),
        },
        "run_prover_compatibility": {
            "prove_entrypoint": True,
            "transport_with_judge_v3_off": True,
            "required_false_judge_supported_by_current_worker": False,
            "reason": (
                "current run-prover required-Judge orchestration treats raw SOLVED "
                "as verdict=true; this prover returns REFUTED with judge_verdict=false"
            ),
        },
    }
    MANIFEST.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return manifest


if __name__ == "__main__":
    print(json.dumps(build(), ensure_ascii=False, indent=2, sort_keys=True))
