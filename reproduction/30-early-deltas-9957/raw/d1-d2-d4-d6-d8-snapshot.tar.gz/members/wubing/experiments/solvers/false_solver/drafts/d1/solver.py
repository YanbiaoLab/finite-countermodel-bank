#!/usr/bin/env python3
# Generated deterministically by build_prover.py. Do not hand edit.
# v97_source_sha256=b48147f11410346dd64d8da97f49016db1ae6711f953e4b3b67cca09fa450e97
# runtime_sha256=996e712f19fad5088c438082df5e670b921ad453ab56a75aad9ac015d358f8fa

# === BEGIN V97 FALSE ENGINE (READABLE TRANSITIVE SLICE) ===
import base64
import collections
import json
import os
import re
import sys
import zlib
from itertools import product

def make_false_code(n: int, table: list[list[int]]) -> str:

















    if n <= 10:
        s = "[" + ",".join("[" + ",".join(str(x) for x in row) + "]" for row in table) + "]"
        return (
            "import JudgeProblem\n"
            "import JudgeFinOp.MemoFinOp\n\n"
            "def submission : Goal := by\n"
            f'  refine ⟨Fin {n}, ⟨fun i j => MemoFinOp.finOpTable "{s}" i j⟩, ?_⟩\n'
            "  decide\n"
        )


    def _col(row: list[int]) -> str:
        s = "".join(f"if b.val = {j} then (⟨{row[j]}, by decide⟩ : Fin {n}) else "
                    for j in range(n - 1))
        return s + f"(⟨{row[n - 1]}, by decide⟩ : Fin {n})"
    op = "".join(f"if a.val = {i} then ({_col(table[i])}) else " for i in range(n - 1))
    op += f"({_col(table[n - 1])})"
    return (
        "import JudgeProblem\n\n"
        "def submission : Goal := by\n"
        f"  refine ⟨Fin {n}, ⟨fun a b => {op}⟩, ?_⟩\n"
        f"  decide\n"
    )
_RULEBOOK_LAW_COUNT = 62576
_RULEBOOK_REFUTATION4_RULE_ID = (
    "false.finmodel.setcheck.structured.all4x4.refutation4.all_equations.v1"
)
_RULEBOOK_REFUTATION4_TABLE: tuple[tuple[int, ...], ...] = (
    (0, 2, 3, 4, 5, 6, 7, 1),
    (4, 1, 6, 0, 7, 3, 5, 2),
    (5, 3, 2, 7, 0, 1, 4, 6),
    (6, 7, 4, 3, 1, 0, 2, 5),
    (7, 6, 1, 5, 4, 2, 0, 3),
    (1, 4, 7, 2, 6, 5, 3, 0),
    (2, 0, 5, 1, 3, 7, 6, 4),
    (3, 5, 0, 6, 2, 4, 1, 7),
)
_RULEBOOK_REFUTATION4_SOURCE_BITS_PAYLOAD = (
    "eNq9WVuy5CAIBcsPPl2CS3F25kzV7Hu6o4lRDubhrbFudd8YExE4cKD/UqLP3+eDyFP8fKbt//2CyJ0u6jJfvqhcH+OzhuuN7ak2mMt9P8yT1FfE8WV14+9c7h9xdQf+Pn0eoUxus902uU5+Z/v9vS/3w/AqiuU65PEG/aonGg6y7RD2o3B3lFC+8vjEVxipqkzDUcKuhXradhS/P9rdqEchr+SaWGXbPe66s4Y0MeJkWfUOJfJuwV6Ruwnn77wUirV/bGcZXjqVPVzvZvpvTmptDLQ2qsHKuXjwl2GmSJ/vaQyOAu1NQzLYUyktA9siRzBHrvIn5YstDDRZ9apnwwwIVYe+cwCeSn49XBVfRkXGpruGQVaGfDRqkBbi0fY+q2NwpDWflCKzj9AcidyIrc/K96czI2yRJSkPZLcEtrSbx2s/VnmkOYm82M1Xx9PPOgWrT+7xS1bLp4gRANjCCJYl968py+HgOwRqzR2QOmUGtgCzIApR4Z61+ApsRn4dplx6mdFGSqQTtgPJSmACuw/3wgGK2pJWiIxuk1eOFs8QYm1rOQsvr7nB4WShGZbprE41FY+P/B5sDGkpymxhUZF7ZvNKjyizObgb3/Z/d1Jk1mfL57x2E2xT9uAI01JNiIQWo5bUtwa4V3MYIZjaSXtMntJI8YY9HVn3XoMtTqPW75+lCL7FqzGWNKqfzm4TiN7yOzuzxQ5sobPxa7D5YMShjRBxhVf+GbOZNWGvwqbIJRpplqZRw4olrR1N3IzcDDSSZVGhv052kgsamVaNF6vPBR1JdUHsrcr1PtiOfkYAPpI7MHxXx0tyJROwsXO293Cg91U8AhsoJ4qEAXrl0vgzLVn63fIS0ooj8GEkr31El/puIZlKIzUoQWmOfq3aPKORB6UKgFf0BUd8HfivOlplTroTomUOB14MNqtHaFXgKxWA3d9rzcXDEJGWa7ZsNMyKNnxnNrQMYIInmQ03bkGIQqT5KdiOrp8oHWcQ/FZSwE4xIi5+k4LRUrj8v91IsxOuWxZbjFYe/USxZoMEZOgPhUjI8OkB2Iq3qjwq5yoqG+2gx5mtfGnTg/6VCwhHfD8FmTQyIkQ5iLF4H2wJM53GU05ioGWo1eXnDRJEoAT3lcL9xtJ9sCWtHjCVH9VV0Wz9F2PwGGiXeKvZ+tetn+tfieiinMvnkjrqzOYVc11r/WerZaV+MEG9r4c1WxHVKXSCgLyV+sDw/j7YNs0IgEjSakM9uydntcEGupGatDxsYf8DCdFaWg=="
)
_RULEBOOK_REFUTATION4_TARGET_BITS_PAYLOAD = (
    "eNq9WVuy5CAI3fdUzbizcSkuwU8+LGG6o4lRDubhrbFudd8YExE4cKB/iZfP3+dDJEn4fPrt//1CJJ8u6rJUvqRcH+OzhuuN7ak2mMv9NMwL1VeE8WV14++c6x/JdQf+Pn0esUxus902rk5+Z/v9Uyr34/AqCeU6uvGG/K0nGg6y7RD3o3B3lFi+3PjEVxiqqvTDUeKuhXradpS0P9rdqEeRpOSaWGXbPey6swY1McJkWfUOJfJuwV6Ruwnn77wUirV/bGcZXjqVPV7vZvqv82ptiLI2qsHKuXjwl2GmSO/uaQyOAu1NQzTYUynNAdsiRzCHq/J75YstDDRZ9apnwwwIVYepcwCeSn49chWfRkWGpruGQVaGfDRqkCbh0fbJqWNwkDWfpCJzCtAcXvKIrc/K96czI2yRxSsP5LwENr+bJ2k/VnmkOQm92C1Vx9PPZgWrT+5JS1Zzp4gRAdjiCJYl968pK+PgOwRqzR2QOmkGtgizIApR8Z61+ApsRn4dprJ/mdFGSqQTdgbJimACuw/3wgGK2rxWCI1u41aOFs4QYm1rOgtPr7nB4WSxGZblrE41FY4P9x5sDGkpymxxUZF7ZktKjyizZbgb3/b/fFKk02dz57x2E2xT9pAF01JNiEgWoxbVt0a4V3MYEpjaRXuMm9JISoY9s1j3XoMtTKPWn5+lCKnFqzGWNKrvz24TRd7yOzuzhQ5ssbPxa7ClaMShjRBxhZf7GbOZNWGvwqbIJRpplqZBw4rJrx2N8ozcDDSSaVGhf092ogsa6VeNF6rPRR1JdUGcrMr1PtiOfkYEPuI6MHxXh0tyRROwcc6293CU91U8AhsoJ4qEEXrl0vg9LVn63dwS0ooj8GGkpH1El/p5IZlSIzUoQWmOfq1aN6ORB6WKgFf0BUd4HfivOlpljroTomUZB14MNqtHaFXgKxWA3d9rzcXDEEGWazZnNMyKNlJnNrQMYIInmQ03bkGIQqT5KdiOrh8pHTsQ/FZSwE4xAi5+vYLRUrj8v91IsxOuWxZbjFYe/USxZoMEZOgPhfDI8P4B2Iq3qjxK5yrKGe2gx5mtfGnTg/5VjghHfD8FmTQyIERliLFwH2weM53GU05ioGWo1ZXmDRJEoAj3leL9xtJ9sHmtHjDlHtVVwWz9F2PwGGiXeKvZ+tetn+tfieSinHPnkjrozJYUc11r/TurZaV+MEG9r4c1WxE1K3SCgLyV+sDw6T7YNs0QgIjXakM9uydntcEGupGatDxsYf8DQq8W3A=="
)
_RULEBOOK_REFUTATION4_SOURCE_BITS = zlib.decompress(
    base64.b64decode(_RULEBOOK_REFUTATION4_SOURCE_BITS_PAYLOAD.encode("ascii"))
)
_RULEBOOK_REFUTATION4_TARGET_BITS = zlib.decompress(
    base64.b64decode(_RULEBOOK_REFUTATION4_TARGET_BITS_PAYLOAD.encode("ascii"))
)
_RULEBOOK_REFUTATION5_RULE_ID = (
    "false.finmodel.setcheck.structured.all4x4.refutation5.all_equations.v1"
)
_RULEBOOK_REFUTATION5_TABLE: tuple[tuple[int, ...], ...] = (
    (0, 2, 3, 4, 5, 6, 7, 1),
    (6, 1, 5, 7, 3, 0, 4, 2),
    (7, 3, 2, 6, 1, 4, 0, 5),
    (1, 6, 4, 3, 7, 2, 5, 0),
    (2, 0, 7, 5, 4, 1, 3, 6),
    (3, 7, 0, 1, 6, 5, 2, 4),
    (4, 5, 1, 0, 2, 7, 6, 3),
    (5, 4, 6, 2, 0, 3, 1, 7),
)
_RULEBOOK_REFUTATION5_SOURCE_BITS_PAYLOAD = (
    "eNqlWU2O3iAMtZEX1qwYqQdAXfUYLLvskdxFpVn2CD1q84WQADYJfKCqM4QE//CebTx/IMLrHyAAAfht8pqdk31tmwQoJq8VAAYQKEc4HqgFQLxe8uUC718BuOPnOQ5ZSRK9/stbun0es0Q4X/DJirQ/FntJErR/U0kHovTDQTPC9b3Ui3hNfWuKz4Kzrj6Z8tJ51yApeg6XXsC8eu18GBgbS/aN3eEFHjQlfUXKLdsE4fJ/d/B57M0ZQXNiaXtR1hiitWXlqwOjCxxTGpuq86iwPn7TaihhFQOsjT6NDDswO7O/2f2gwmGxdgu2fHmEytOQkqJcmlBgtHqbjB1Gz64bEHYjRL9tHO24bRmJqM/DtV6TJxuezDuCdAdrcfu+dZzDe9rejZ/Xr//06lelbMRF+PcjbHpUGcayTrZ4wsxdLknPgg5PwTj3IaJdeVQszrJKTvvO/l2E7GIoC3KaGYfGUuBAcduNx5OcsnSIYmMrI7bZ/O2TjeGsWpR+rJ65ASA8kM3IryR27HX4jISeeYcDLa95BRuZSmMW2Q7yUwtJMUCmi7FZssmFNVRAc7XIYMtxo1SgMvJj+a0zPiITcDRKNykEsU4iVkFUR5upkQtN0sE72AXRSong6C7e1jFaVqufmJzNRgTw+vTphtojtWSOQzr5W17DkdPipzIybHs3OoveNvjVzBZ6IYq1Z4xHfqrSIzbDZX7UlJFuzTQptP3Qq1/V9NtqPfJ30/j78NubPr9WpLkrPBrVh1NcWSsjpYSKpqJXIRHxPiINlpH+szqxDh5+zADhpowMXKtqK0o0GJ7sGHpd/HVmQ+2soQzazWxpxettVIUaqkD6BvFEeiGKAdUlihfJ5ot+iDOuYlTVhvhe+mwbME5lC9EJxI9V3fhGg8RXZ8TZ0CXTuGigiaGiKwGG62Vk8pbRxytZE4ZjxXsNEq5YQzfS/BCtm7DwyAGJi/DP/T19ZQlVreZPrekxROEN2fzlKKxqQa9aaa53c53IbHbj1rxX4xoiY0khxW0jai4hkouIgY9lJE30OftlJPzW6NFH07uhjpOt2wn/6IDq8/Fs3HwZGTsuCzyChNs7m9GN5BI2UmROnGj2KLJJpx5AFaLjJZfuUgw+ZTY0myFN9BNjK54l25mK/VOjJ1qK0xTZAtid76GW+Zxx3Tub0Xs1HgnM3ONyZhNdqgW7IFoh99H6J/Oimx6FCjarrX/7L1dGhg6jx8T9MjJ2sKakyduUPsnmOl0/IyC/rtVoHDxNks3qDxr1gEW2Gczw2We1utNNPeCg89e4Uar/B9pFV/8="
)
_RULEBOOK_REFUTATION5_SOURCE_BITS = zlib.decompress(
    base64.b64decode(_RULEBOOK_REFUTATION5_SOURCE_BITS_PAYLOAD.encode("ascii"))
)
_RULEBOOK_REFUTATION5_TARGET_BITS = bytes(
    byte ^ 0xFF for byte in _RULEBOOK_REFUTATION5_SOURCE_BITS
)
_RULEBOOK_REFUTATION852_RULE_ID = (
    "false.finmodel.setcheck.structured.all4x4.refutation852.all_equations.v1"
)
_RULEBOOK_REFUTATION852_TABLE: tuple[tuple[int, ...], ...] = (
    (1, 2, 0, 0, 1, 0),
    (1, 3, 1, 5, 5, 1),
    (1, 2, 2, 5, 1, 2),
    (5, 3, 3, 0, 0, 3),
    (2, 2, 4, 3, 0, 4),
    (5, 4, 5, 0, 5, 5),
)
_RULEBOOK_REFUTATION852_SOURCE_BITS_PAYLOAD = (
    "eNrt0zsKgDAQRdGXYGHpElKkcBlZ2pSpXYFL9QOChUT8geg9xTAwqd5MnEbJdIdesigAV75RdEtrscuZRE5qiAA7AgcDAAAAAEc4X5wmJTL6O18VpyYjo/cJ0262NzbXevUOeF5LBMAXDXO8B1E="
)
_RULEBOOK_REFUTATION852_SOURCE_BITS = zlib.decompress(
    base64.b64decode(_RULEBOOK_REFUTATION852_SOURCE_BITS_PAYLOAD.encode("ascii"))
)
_RULEBOOK_REFUTATION852_TARGET_BITS = bytes(
    byte ^ 0xFF for byte in _RULEBOOK_REFUTATION852_SOURCE_BITS
)
_RULEBOOK_REFUTATION773_RULE_ID = (
    "false.finmodel.setcheck.structured.all4x4.refutation773.all_equations.v1"
)
_RULEBOOK_REFUTATION773_TABLE: tuple[tuple[int, ...], ...] = (
    (1, 1, 1, 3, 3, 5),
    (2, 4, 2, 3, 4, 4),
    (0, 1, 2, 3, 4, 5),
    (0, 1, 2, 3, 4, 5),
    (0, 5, 2, 0, 0, 3),
    (0, 1, 2, 3, 4, 5),
)
_RULEBOOK_REFUTATION773_SOURCE_BITS_PAYLOAD = (
    "eNrtmN0KgzAMhU3xIpd5hD5KHi2P7pYxprJoI1S2cj78g1KLJyfEhqZD9HHOfoATONaw+t2eF/HHcvIuiQYMOgMAAAAAAABANyQ/haBaZofcBbJs5OT6Yq8d/lR4PD+YN4GCoX1rSPQTaLqWbPye65rOu/B450Q3jqJVANYz7FtgGWnYJdnuXKyOq6PdXNk4iBxtUklg8F9NNm4qYC39e4WwA1EiW9TIKS2V0bLWkQ5G46aPBmBINPMj+2eVewFrAwiS"
)
_RULEBOOK_REFUTATION773_SOURCE_BITS = zlib.decompress(
    base64.b64decode(_RULEBOOK_REFUTATION773_SOURCE_BITS_PAYLOAD.encode("ascii"))
)
_RULEBOOK_REFUTATION773_TARGET_BITS = bytes(
    byte ^ 0xFF for byte in _RULEBOOK_REFUTATION773_SOURCE_BITS
)
_RULEBOOK_ACCEPTED80_BLOCK019_RULE_ID = (
    "false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525."
    "accepted80_packet.block019.v1"
)
_RULEBOOK_ACCEPTED80_BLOCK019_TABLE: tuple[tuple[int, ...], ...] = (
    (1, 5, 4, 2, 0, 3),
    (2, 5, 4, 1, 3, 0),
    (2, 5, 4, 1, 3, 0),
    (1, 5, 4, 2, 0, 3),
    (1, 4, 5, 2, 3, 0),
    (1, 4, 5, 2, 3, 0),
)
_RULEBOOK_ACCEPTED80_BLOCK019_SOURCE_BITS_PAYLOAD = (
    "eNrtmUFuxCAMRQ1i4SVH8FE4GpXm4LXjDDgJlWbRtJr2v8VEAQIYwwc8ib4PKdujNsp0H1q3tiPe1EwDX3pFHZJuqbqQNPeCOiBhqN+RB2WWZU4qQtLVyaweFupvZ1rNux31MnHrxZrM7ao0Zru8rEu2AsTXBcXh2ipmiomjGM1WeY78odg5FwDwg7QmulZXZ4zcbAdkKmyLVuhlsfinRxEXwDx++KB4aYjiUyr74XQ3pTKI6zx21N80rXtXmIINPbzkaEKOPZeTGRT3oXoeQAAAAAAAAAC4787m4WMLEurzGQy0O8oiyUJt0vfAmSXaHSht73uZTjSy/RPyTL/2PEKtMr69KfbVa2iojP4hkA1CfOFDJ+dqAja7jLPd7nPDMIG/CSfT/4Wwb3+YqH4O8U/LJC/fxkbAdMgMu4CtsU+/Ohzd"
)
_RULEBOOK_ACCEPTED80_BLOCK019_SOURCE_BITS = zlib.decompress(
    base64.b64decode(_RULEBOOK_ACCEPTED80_BLOCK019_SOURCE_BITS_PAYLOAD.encode("ascii"))
)
_RULEBOOK_ACCEPTED80_BLOCK019_TARGET_BITS = bytes(
    byte ^ 0xFF for byte in _RULEBOOK_ACCEPTED80_BLOCK019_SOURCE_BITS
)
_RULEBOOK_ACCEPTED80_BLOCK005_RULE_ID = (
    "false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525."
    "accepted80_packet.block005.v1"
)
_RULEBOOK_ACCEPTED80_BLOCK005_TABLE: tuple[tuple[int, ...], ...] = (
    (0, 3, 4, 6, 1, 2, 7, 5),
    (4, 2, 0, 1, 6, 3, 5, 7),
    (5, 6, 7, 3, 2, 1, 4, 0),
    (1, 7, 6, 4, 0, 5, 3, 2),
    (2, 4, 3, 7, 5, 0, 6, 1),
    (7, 1, 5, 2, 3, 6, 0, 4),
    (3, 0, 2, 5, 7, 4, 1, 6),
    (6, 5, 1, 0, 4, 7, 2, 3),
)
_RULEBOOK_ACCEPTED80_BLOCK005_SOURCE_BITS_PAYLOAD = (
    "eNrtl80NwjAMhe0qh3IzEgNETJIjY5lNGBXyAyVyaCsQIsD7DmmrtJblOvYz00c5EJ3idUckW/oGNtPtfqAfZSS5rEyhYw+Ti3HReseltfyassfpAwAA+BM0l8FcAn215U3VTKXezVjqiyE7q9ZpvnfY396Wpo2ZRwC6RfJ5jbkfjC4yuSzUEnKCMMZwhWvUpFUe2EhLv2yUEVcAWjOblsojjZktmFMU1pgE4GkZOTVKp1W6HR803sWEGwLCCgB4G8yjW99zWclhtgUAGNWtRURLY4KtJ92wavaFHgcvcAZIvgzD"
)
_RULEBOOK_ACCEPTED80_BLOCK005_SOURCE_BITS = zlib.decompress(
    base64.b64decode(_RULEBOOK_ACCEPTED80_BLOCK005_SOURCE_BITS_PAYLOAD.encode("ascii"))
)
_RULEBOOK_ACCEPTED80_BLOCK005_TARGET_BITS = bytes(
    byte ^ 0xFF for byte in _RULEBOOK_ACCEPTED80_BLOCK005_SOURCE_BITS
)
_RULEBOOK_ACCEPTED80_BLOCK049_RULE_ID = (
    "false.finmodel.setcheck.non_affine_all4x4_remaining_current_20260525."
    "accepted80_packet.block049.v1"
)
_RULEBOOK_ACCEPTED80_BLOCK049_TABLE: tuple[tuple[int, ...], ...] = (
    (0, 2, 0, 4, 0),
    (3, 3, 3, 3, 3),
    (2, 4, 2, 0, 2),
    (1, 1, 1, 1, 1),
    (4, 0, 4, 2, 4),
)
_RULEBOOK_ACCEPTED80_BLOCK049_SOURCE_BITS_PAYLOAD = (
    "eNrtWUFOwkAUfVOKLcZIS1gSbSdjwhFcGG1IF9aVR/AIujdxNC7qDokH8ChdeY4egSULQu0UVLQFRTuN6LwFLfPLvPz350//Zwg8vEcUEXFpB3NjW/g9OATGzSLDkCz4Bb9YmeSRuXeM0gLLXqM8VzTd6mI1V2aex1cl0BMtc9XLGUwIywagw1o6g/M2FxQUFBQU/iWGifFyGycpalLZJsnr7Tglu5JKFiW7FQo5kizde8xJN0mFPJJKFteGR9W5dolJtiSFntN6aVKptH8GT8ToDKsii/ZjXttB+nGAzjk30MQODhZXxAoLcJZKmF7Osy+GbLYHNjim9IYNwrDvt2ybUt8PQ6tnyogbH/itwPczIkHb829D07Z7pivDtdOU4i40KwrbSStgtl3RavcCKtrczD9B606ldG8tlT+/GO0Ax6JDD4C+ruT4PnrY7DoEmulBtzzZycYdmDC7Irfqafgc4vwZISVX4B/KyKRZIds4IUutpXYffGkFzkVjVaLvcz2bwvqgZnQWZYYo9WKIYj1Src6nyUYbCAot4u3KGXOpeMvycmo/Szv1SOHhQb3dB4jugOtooIVw3YSMpttI0bHMKP/XSdFjSfL1inc02wtVR/hD6Nm69mDlTnm0eu7hay03RBwVggwb29Mlmd9yI/L5yKpl5L3+skV9ACuYmq1ViJ4BXzR5Yg=="
)
_RULEBOOK_ACCEPTED80_BLOCK049_SOURCE_BITS = zlib.decompress(
    base64.b64decode(_RULEBOOK_ACCEPTED80_BLOCK049_SOURCE_BITS_PAYLOAD.encode("ascii"))
)
_RULEBOOK_ACCEPTED80_BLOCK049_TARGET_BITS = bytes(
    byte ^ 0xFF for byte in _RULEBOOK_ACCEPTED80_BLOCK049_SOURCE_BITS
)
_RULEBOOK_AFFINE_N9_MICRO_ORBIT_DATA = (
    (57407, "048561723615237480372804156156372804723048561480615237237480615804156372561723048",
        "eNq1WUuO5CAMBcTCSx+Bo7h3cyzPSCP1so885AsBG0jBoFaqU6HAn/f8IX8Nme1vG36/Xjd2v8HzSdinUZqWzz1H"
        "OD8gXtzjiU3/+scDOOc9p6eNDZYPtqlgpIGlPNfgctdMmID783IEG+RfbKrIi4GTxdqEsrY2RBx/DFBczUmqXD8l"
        "LlRJBgtPVY4PV24TQLD7Pr5yr9VWvkSGY1uvzj1mk9GcjLWLneKQ4QEJPyxITqWfZe+PDqv/yJVODTipWoCHirnS"
        "ES1hd8jTuKQCSPVY0sdKyLwNiU/0eZKsNmxIlqiu2oHezH4TEO6wUxCLZtzmDA5rjYK5X40oqbNaIKz0CLpqQyr/"
        "0jba1fqGWdMNRtjDdL6abafIpjLEb4bbyRZWqeYNotESW/Wdn4M/B+Mi0FjbCPMAgSz5GF6RTYvu/nPkmQbuZBk5"
        "i6C3HV5p0pQU/IASU6qdsUnBHTdv34+vZFCH3AHkdGbLpXatLPsuPZtmepczZFhryDvGxws+1iZeoIuS2ajSzK4A"
        "RUk274yeinEh9s3RZPjTPVDDwH0coJQyku5likIbzPJhD/fQVSXipY5ALAoiovEN2X5vS0PagE6lqEe9D8gGBnXk"
        "0VqMsFfDUZSAv59fxfqElTA6xJSfhDUyvYjspsmWAS+08t6K7Sj3vO+lsVm3nWXk/whRahkZJKC4BX6SezaSVXOL"
        "yWZ9QqQLmT0t8OGmZSWrYd6RQUK8rTfxLKHkRfbDzH7W9mfP1SSRbHBvdOzmuOWjGdgQppY6tvEuuU1wFoiN9gsK"
        "QsSFxVSUZG6ApWqV5sKe2FtBNMX/kHHOmU7XYmfrVt+pf20pGU5UDhyaxzYnbEZLoJ4gVy/tlZLWvyoUbJdsqkD+"
        "PO15ImbmkJB0gQT4wWS/ASoxvcxa4CmygZebQxpozt+SzYZWDz6dywYrXDGpudkDEm4SZ22NgIZIjuIp+/hljY36"
        "aiHcF15WkZAa2D2Is4lrx/vmfR3VpMCuHGHx2LRGVBMCu9CgUV1tsnLQ55plpFJr8eoyUlttKyN7pd4HByQ3aR++"
        "BVTiVZ9/QZMLc2T6Tix0s83N9RKz6mzEgOwE14Xx7HO+GQWNh7YsI8s3RknVgSR0nkYKWNvOllGwA35a+sfxD6xb"
        "TEI="),
    (67003, "075264183318507426642831750426318507750642831183075264831750642264183075507426318",
        "eNqtWVtu5SAMBcQH/aOzAuuqC/FI/eiyrEoj3WVP3kBsAwlxq7YXCMGPc2zcfwbN/D2LNybMH5aPX8vQMQPmmPHr"
        "2Ly2FDjWp0Wr2OlrE1dM/KTl8TOfwLSnCcUzTtpnlmjomKB8gta3R35onz9dqIJptFTlY9/TmJcTVPHsXIjp7/L1"
        "TjBicRg870iLMSX1/brOswmwyrk2n4BszWN+P6L329qzhNJjxLWJ2W7cxbckZB4rd3YuG0PlSBdFjd8UpNxud2Vz"
        "2KwffkuWLmQKQkE9lONJEJ/0ItB8u8vf+l5NIaP6g7YQY0C/LyohrC8kZjCqI6Uuzh/7nO3ozkNhGuLqXVAY64c7"
        "sQAqyO0GW0yxYtmRT8w5KRcqlNYWlWGFkPz25hGwRZlikIOtTFOZ/XsUzAKcmjxiNchfAJsSUiAf2NsRsKnELmSY"
        "MOg2twYjVQjtbvhJYEMFaRB1896VH43YScnRHAPU+MyDlxO7lLN5MZaZ1u7LdVPD6h4vuwfv06GW2Ug0ACoRNQq2"
        "Q/fC/wDMkNBM2H2Zrc4wxclGQvLXBBT9BscPSno4GIIEbtU6ycD2RYTZGZqWo747K4RYQ0bkLhqCthXK8yo0RypJ"
        "0OsBeJ61fBEDLTMPZm3KYsC2UgDgII9EIC1lsSsRTueKrIykC1nvTzVCYmHId7BjVxt06rkiZ+BJVXg1rhE3wRZ4"
        "2NjBG+JHWSrUqXZSjd49VUeljHRi7gtClL5cq6avy1c6T2wBefjuO23gg6w9MMePg21Fj0ORjs55PBg/dmdzGv1h"
        "s8q9UUZOmXQPCH9WiJ5k4/U1e+FBXIlonhVbRwiygmikugO1zxgLOnOpIHL3weDTO4JEepYpiD2bKmDzaYtPK3Z7"
        "ngnGYoNg1tBsnnLojU4PEZZH4ygGMK/o3ZlE6OHw3zKbADZ/vbjvBhvzEPESdbQ/UumEu0fSi5rZ3qHnzuY7AsHU"
        "wYaNHpOesy9xWF66lQ9a2GvGIrONNkhCf+tn8KqB2a/TBTTwGEQpLn0/R26t/wVsVBJT4KoF0+XeCtiscmOfx2JY"
        "trPZ0LliucKZYNXoAqlAHm6QKOawvIsx2pGhXC1O9sG0mlhXMxso2I7cm6OW3Jr5ju2zEPLSJIzJePJ/kLrhXrmz"
        "Ibfa3By0A72mkCwUBfLDU6OI2fYCrif5DysyS+8="),
    (93372, "048156237372480561615723804723804615156237048480561372561372480804615723237048156",
        "eNrtmF0OgyAQhFlCE9InjsBRONr25o0rYttBXzSptPO9oLAS+RsGxJFziHNy+6U2lUPFZACCC8USHFzLkzrQLSAN"
        "07SULfGtGY3pTXH96lZN0nn6xFsVBXsyz38A0RDpXb6qtNlKDzhJvO8KYcTJlLjUCLka4iR1hT2Z1JWlREzIFpsT"
        "dmWXvUqOWs6obetuTqXgBtzJWs2KclKSE2xknZERDjyTIcoYDTZSa1RcLSEhZHOxmfA/8MyGNw66dQkh+eXLwJ4l"
        "5Kv4un/Cpqk8QxBC/p43Xbyj1wFB3bmPJmQ0no/9DJ8="),
    (9330, "063528741306852174630285417741063528174306852417630285528741063852174306285417630",
        "eNrtmDESgyAQRRdmiy1JTsBkchALm9yKSZUyRw4KKAZImhRB/6sYZZhx3e/fryIiRwFmAr1yVeYh8puzbFqY7/ss"
        "St81XvNz12iioXp387511hS63G5QT9AV1gb3k6n9Ze731MTlpVkorn3YUFXNMXjGx69bkDlt6jTm1TLtQgIAwE64"
        "rcvLufARGRHAwD2OD1y4oJq80kWD7TF2+Xhq2+ORkHJ51GAfMCxlg1cjox4xs3EzaKm1kDpOV5qUwVAFdpTZlqXz"
        "/S3v2UE2Xxj+GNkAAP/jbMHrg3510ngyr0X4jL8EAACwK17oZQ7C"),
    (18909, "063852417306285741630528174417063852741306285174630528852417063285741306528174630",
        "eNrtlz0OgzAMhW0rg7uFnsCqepAcLd04NigEASUpDCyh7xsQ4idSHNvvmYkoUgHnCDTEm32ves1aNt/44+8MoQdn"
        "ibmp2Iuo410uceEXqa/Gp5L0loTnEtPe7WpQOuZm98bTocfy0W73pUm7claVdAwqdktESKnSMca3YS1LShyJtN5P"
        "FPEEANwKe/x8/elXclnyEGAegnyYrYSNF1kpxv5R8hvheLQSxBW0MbNZtln87cdTmo+NQ+CiALik2GJtipmGX9uU"
        "oIeQANCIjZzMn9+IpWRhXQo/1zcjYACAv2IAxl0PPQ=="),
    (97801, "057138246381462570624705813462570381705813624138246057813624705246057138570381462",
        "eNrtmc0NgzAMheMoh7SnCHWAHDh0DEZgpIzQERi1aRtSggOBiv6gvo8DiFiRbGL7WZD4BOQvIawA+0AvNXSI1eb4"
        "NHHS31u2ckw+Tt1bZ2gk4gjAkmS7ccosnX0aEbem8Q7hRYVggm16bxceu7TXPmp6X9kPsdYXt7wgquB1womTyh9O"
        "k5S+ZsJasyprmXCEdATguzRR6eQmOzcaItSg+4ypf843es5GqbprozNrh96qJCPve6vMzMaszW5mNjco7DLxTXMn"
        "TCJR5mS3RfYBAMD6zqbVzPBnWR8EAID/wQwlPZVUPq344wXeyBUTIAxH"),
    (37096, "075831426318264750642507183750318264183642507426075831507183642831426075264750318",
        "eNqtWWuO7SAIVsIPfrIEl8LszExy933nWE9tC9gHNZNOjloQ4ePVf0nS5y+nlDBxaj9S+5G2P0r7IXXd1l7h9l5K"
        "0J4l1favv7QZy66qF6j/5+NC3/phW/cr0NdxWR2DFcM+qjk7hBzHWEchZyH97M6nRdFvCPczqxOAlvsrithc6ld+"
        "cERBOB6hjHWxtFIaLVInOAqGlmrHNupG1KYyb1kbknDSijXU7w9aiBM7qzti9fv4O2G29tIJN9d+myIINW/2SFV/"
        "aa8w6w5ka7QDDjk9HzjIkAYaVcW/eJTgiCpL+H45WXFjbQ9tikzN1q39eNpzHUIzG/aO/3CAJ32t9iEjDOXo2obQ"
        "5FhvYBDMT5xvw3c2fuY0ygna743iEV3mcrbiyHOw5ZLsiJdJWX/tYXeuQJqBDWdCwxEsIa31kEXOCXXo2ecONxUK"
        "yx59MS1CtUf96qsa2+iO0Yhr6qiPSxgFWydtB+zqZDBzhJxFNsu0izLSEsVA8bK9BDbtEDec+lmp03hxd9SNrUBJ"
        "c2ePEnT/PAdKhlcdMgBPTAtkNytB8xf/ZkRRJ3oHbJZo7MH9+cjdO6CJw73YUoLMytYy6cwgOMgNF6Ewr7TJvbi6"
        "VlhswxZPwZbbbRUHh+D6gkdgQ57kfC1Mx+9vV09MHBopLUY4C7tuxEgjSVLoYgm8OAqfZKC85/o3aaSGtmUiHAZb"
        "8fJxPR3Ox9GvmbQwUW6flgM4+sjH6eHeOD2K5vwXG2FpSSwPUjnxNc1d0ujvsg1SulidBWu2/C2pyYg48FZN0wk0"
        "tGa2rUfSqyMPqigqIUq7qWhgm/QZl2vbdWDwJbBBvlr8YgxsU9Tu7o45iG8el1ZmfubNBonRuE16Kmz+4iukqpIw"
        "3iBxnU6r4uRpdTa3OKWQ1qDU3chYzeb2tcGwXiwxr4n5ekfJCAb3PFt1w5LVw6VogwSrc0SvD1JCYGPPgzjFIYbA"
        "NvJ+ON5aPVynnLuaE7CVtchtD1w/ftC1XtKd7k/eqEJOCrTPVD3a2J3UsmwOjWfGkKN5K7ptpaz421+JLjX9Rxrp"
        "2PmlL0Z3I5s4RC59MXoU2VqKgNohWxUeKsUfZnI5iWyWYxdnN17bNrmXzGrTtS9GaGRmvt3+B8MjS5c="),
)
_RULEBOOK_AFFINE_N9_MICRO_ORBIT_MODELS = tuple(
    (
        model_idx,
        tuple(tuple(int(digits[9 * row + col]) for col in range(9)) for row in range(9)),
        zlib.decompress(base64.b64decode(source_payload.encode("ascii"))),
    )
    for model_idx, digits, source_payload in _RULEBOOK_AFFINE_N9_MICRO_ORBIT_DATA
)
_RULEBOOK_PRINCIPAL_FEEDBACK_MODEL_IDX = 38258
_RULEBOOK_PRINCIPAL_FEEDBACK_TABLE = (
    (0, 0, 4, 0, 0, 3),
    (1, 1, 1, 5, 2, 1),
    (5, 2, 2, 2, 1, 2),
    (3, 4, 3, 3, 3, 0),
    (4, 3, 0, 4, 4, 4),
    (2, 5, 5, 1, 5, 5),
)
_RULEBOOK_PRINCIPAL_FEEDBACK_SOURCE_BITS_PAYLOAD = (
    "eNq9Wc1O20AQnt04xISIOFEkKhWVxTJSbvTIjaWyVKcnyBNU6gvQO1I2kVCBS1PEA0S8QN+ghEufI4+QI4cId39M+PE6IsXjPdhO"
    "JsmX2Z1v5pvdU8IpjDdAjRN9HQt9a7nqyrv6RQ2YekE5kbdZvA3WMYl/2w0Q98CxGu7ib/ZvjOOtjN/6I4GshikB5tsM4jtQD4jF"
    "UnPZnvW3RkFfBFbLziph4FkMbS+6tn6DX7hQtlouaTV0mM2V5PMpR0Xd3NOO1vR6gVNPucL1LThIoXSIsYdAnxvcZ29EED4s3uj5"
    "50jy34VZMT1KogQFjDsN1gOfFoFmXKvfFuLaxKDtHBQBJtmsxg1tEBcfTBjXPqtnz0Qa4pgaNM1Bgu7bvQbbEpvSKyaQwRKyrRnO"
    "P2EhKtk+QnFk+3kLBZJNh8dKQWTbh/cECiNbpZB5lGT7MX/ux310slUfkffRybb1oB4EHEMbu7LNJZEnAsdBJltv/tg6cyNksq1N"
    "b1S20lnfCK9DPLQTuNexX53rJYE3mWI38UhCxmscm2yJ1JXCbNJDp/ZfUtmcSlZL9cNBygSGWWzGexNR+gBcAUhtTLVIQJMJ7yoM"
    "iCcLtiT4LXpSLg1KDKQ2kE7pvsPDBPvKtUcKaCxd9J5KhfzHVXAZ+VKMS7INw2ajgYkF4jJsdsKQq0A0sJjjUEKcn7kahHSS/oth"
    "oX1pdoJG40ClKk02XXmwppJ3/PPA9/VEJm0txyNbu8PYqmw7pX/bvIlNNtOoM+WffwgMF2zEh7JSO2ruRGCkCSK5W25wlABFlCbN"
    "OtayidZR2Dj1qCo41TZDTpJD/6J97X0yU5jsguBhdkOl5jgpB9D2GsmbaGTrMr9s0giUferhTmRUlR4JDeT9og5Rbg0RZeSi8HNn"
    "9TwnNXufMel7co2XWUwWLJUjSnnuLYh4f0EXKiDYzjORTRc2hyMe8jwra+bGLcC67Ojq+crICogzu+nMlR1dFUNG2uLDk0J2km8C"
    "K1F33R4fCqjOgedYgLJ3wrXyGgS5lp6rwBFg6564EnwZtv8mG+0H9jiIBqq8+olqyKfXGfo0I1OUWzIx8/Ch6c8FLfNoQW/3+13B"
    "tFv5qLDk/Gi2mz5ksYSGNQmUl9ggyc7y6dW0JoFoKbKp6zE4L3WBJRL51JKyl5ORZvFE+nu11Ic7nrVEvH4EetJ5WPWcV/yz1CnR"
    "8hskkGyQvDSljlXuN97IuWkSHGHas1S3OI7fGv8rBmWQdi19YrQH1DKRS1R13p+nqJfraTni45Y4XSaHRtUMvSrSJ0aP8vapPlpG"
    "sPwDqlkNog=="
)
_RULEBOOK_PRINCIPAL_FEEDBACK_SOURCE_BITS = zlib.decompress(
    base64.b64decode(
        _RULEBOOK_PRINCIPAL_FEEDBACK_SOURCE_BITS_PAYLOAD.encode("ascii")
    )
)
_RULEBOOK_FIN6_SPARSE_DECODE_TABLE = (
    (0, 0, 0, 0, 0, 0),
    (0, 0, 0, 0, 0, 0),
    (0, 0, 0, 0, 0, 0),
    (0, 0, 0, 0, 0, 0),
    (0, 2, 0, 0, 0, 0),
    (0, 0, 0, 1, 0, 3),
)
_RULEBOOK_FIN6_SPARSE_DECODE_SOURCE_BITS_PAYLOAD = (
    "eNrt0KEKwlAYhuEzWJhomEWjHu3uCnTbQVj0CvQ+HNMj4xQxKBiMuw+TYUUsegtjYVVZWBj7xSYIdvF78ptejQF8aLQYCzXmfI1O9M7GNQAAAAAAAAAAAAAAgH+yIjWgy6ag9dY4lpYVZrXbnkgFoqTY06fVoe3mKjuTFCNeyaQfvvKuL/KUbB6ZRHYvGBdcObOY5LyZ1Lk55P6Dot3EUFfPFB3XWKREUneX+p3gBz0BwB/9XQ=="
)
_RULEBOOK_FIN6_SPARSE_DECODE_SOURCE_BITS = zlib.decompress(
    base64.b64decode(
        _RULEBOOK_FIN6_SPARSE_DECODE_SOURCE_BITS_PAYLOAD.encode("ascii")
    )
)
def _rulebook_bitset_has(raw: bytes, eq_id: int) -> bool:
    if eq_id < 1 or eq_id > _RULEBOOK_LAW_COUNT:
        return False
    bit_index = eq_id - 1
    return bool(raw[bit_index // 8] & (1 << (bit_index % 8)))
def find_rulebook_affine_n9_micro_orbit_counterexample(eq1_id: int, eq2_id: int):

    if eq1_id == eq2_id:
        return None
    for model_idx, table, source_bits in _RULEBOOK_AFFINE_N9_MICRO_ORBIT_MODELS:
        if (
            _rulebook_bitset_has(source_bits, eq1_id)
            and not _rulebook_bitset_has(source_bits, eq2_id)
        ):
            return model_idx, [list(row) for row in table]
    return None
def find_rulebook_principal_feedback_counterexample(eq1_id: int, eq2_id: int):

    if eq1_id == eq2_id:
        return None
    if (
        _rulebook_bitset_has(_RULEBOOK_PRINCIPAL_FEEDBACK_SOURCE_BITS, eq1_id)
        and not _rulebook_bitset_has(
            _RULEBOOK_PRINCIPAL_FEEDBACK_SOURCE_BITS, eq2_id
        )
    ):
        return (
            _RULEBOOK_PRINCIPAL_FEEDBACK_MODEL_IDX,
            [list(row) for row in _RULEBOOK_PRINCIPAL_FEEDBACK_TABLE],
        )
    return None
def find_rulebook_fin6_sparse_decode_counterexample(eq1_id: int, eq2_id: int):

    if eq1_id == eq2_id:
        return None
    if (
        _rulebook_bitset_has(_RULEBOOK_FIN6_SPARSE_DECODE_SOURCE_BITS, eq1_id)
        and not _rulebook_bitset_has(
            _RULEBOOK_FIN6_SPARSE_DECODE_SOURCE_BITS, eq2_id
        )
    ):
        return [list(row) for row in _RULEBOOK_FIN6_SPARSE_DECODE_TABLE]
    return None
def find_rulebook_explicit_table_counterexample(eq1_id: int, eq2_id: int):

    if eq1_id == eq2_id:
        return None
    if (
        _rulebook_bitset_has(_RULEBOOK_REFUTATION4_SOURCE_BITS, eq1_id)
        and _rulebook_bitset_has(_RULEBOOK_REFUTATION4_TARGET_BITS, eq2_id)
    ):
        return (
            _RULEBOOK_REFUTATION4_RULE_ID,
            [list(row) for row in _RULEBOOK_REFUTATION4_TABLE],
        )
    if (
        _rulebook_bitset_has(_RULEBOOK_REFUTATION5_SOURCE_BITS, eq1_id)
        and _rulebook_bitset_has(_RULEBOOK_REFUTATION5_TARGET_BITS, eq2_id)
    ):
        return (
            _RULEBOOK_REFUTATION5_RULE_ID,
            [list(row) for row in _RULEBOOK_REFUTATION5_TABLE],
        )
    if (
        _rulebook_bitset_has(_RULEBOOK_REFUTATION852_SOURCE_BITS, eq1_id)
        and _rulebook_bitset_has(_RULEBOOK_REFUTATION852_TARGET_BITS, eq2_id)
    ):
        return (
            _RULEBOOK_REFUTATION852_RULE_ID,
            [list(row) for row in _RULEBOOK_REFUTATION852_TABLE],
        )
    if (
        _rulebook_bitset_has(_RULEBOOK_REFUTATION773_SOURCE_BITS, eq1_id)
        and _rulebook_bitset_has(_RULEBOOK_REFUTATION773_TARGET_BITS, eq2_id)
    ):
        return (
            _RULEBOOK_REFUTATION773_RULE_ID,
            [list(row) for row in _RULEBOOK_REFUTATION773_TABLE],
        )
    if (
        _rulebook_bitset_has(_RULEBOOK_ACCEPTED80_BLOCK019_SOURCE_BITS, eq1_id)
        and _rulebook_bitset_has(_RULEBOOK_ACCEPTED80_BLOCK019_TARGET_BITS, eq2_id)
    ):
        return (
            _RULEBOOK_ACCEPTED80_BLOCK019_RULE_ID,
            [list(row) for row in _RULEBOOK_ACCEPTED80_BLOCK019_TABLE],
        )
    if (
        _rulebook_bitset_has(_RULEBOOK_ACCEPTED80_BLOCK005_SOURCE_BITS, eq1_id)
        and _rulebook_bitset_has(_RULEBOOK_ACCEPTED80_BLOCK005_TARGET_BITS, eq2_id)
    ):
        return (
            _RULEBOOK_ACCEPTED80_BLOCK005_RULE_ID,
            [list(row) for row in _RULEBOOK_ACCEPTED80_BLOCK005_TABLE],
        )
    if (
        _rulebook_bitset_has(_RULEBOOK_ACCEPTED80_BLOCK049_SOURCE_BITS, eq1_id)
        and _rulebook_bitset_has(_RULEBOOK_ACCEPTED80_BLOCK049_TARGET_BITS, eq2_id)
    ):
        return (
            _RULEBOOK_ACCEPTED80_BLOCK049_RULE_ID,
            [list(row) for row in _RULEBOOK_ACCEPTED80_BLOCK049_TABLE],
        )
    return None
def make_rulebook_explicit_table_false_code(table: list[list[int]]) -> str:
    n = len(table)
    s = "[" + ",".join("[" + ",".join(str(x) for x in row) + "]" for row in table) + "]"
    return (
        "import JudgeProblem\n"
        "import JudgeDecide.DecideBang\n"
        "import JudgeFinOp.MemoFinOp\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n"
        "open MemoFinOp\n\n"
        "def submission : Goal := by\n"
        f"  let m : Magma (Fin {n}) := {{\n"
        f'    op := finOpTable "{s}"\n'
        "  }\n"
        f"  refine ⟨Fin {n}, m, ?_⟩\n"
        "  decideFin!\n"
    )
_RULEBOOK_AFFINE_MODELS: tuple[tuple[int, int, int, int], ...] = (
    (7, 2, 6, 0),
    (7, 5, 2, 6),
    (7, 2, 5, 6),
    (7, 3, 1, 6),
    (17, 7, 11, 0),
    (9, 6, 4, 0),
    (11, 8, 5, 9),
    (17, 2, 13, 0),
    (17, 8, 7, 0),
    (17, 2, 9, 0),
    (17, 9, 2, 0),
    (11, 7, 9, 9),
    (11, 9, 7, 9),
    (11, 6, 6, 0),
    (17, 11, 7, 0),
    (17, 7, 8, 0),
    (17, 13, 2, 0),
    (11, 5, 7, 0),
    (11, 5, 8, 9),
    (11, 8, 4, 0),
    (11, 7, 5, 0),
    (4, 1, 2, 3),
    (4, 2, 1, 3),
    (4, 2, 3, 3),
    (4, 3, 2, 3),
    (5, 3, 2, 0),
    (7, 1, 3, 6),
    (7, 1, 5, 6),
    (7, 3, 5, 0),
    (7, 3, 5, 6),
    (7, 4, 3, 6),
    (7, 4, 4, 0),
    (7, 5, 1, 6),
    (7, 5, 3, 0),
    (7, 5, 3, 6),
    (7, 5, 5, 6),
    (7, 6, 2, 0),
    (9, 5, 5, 0),
    (9, 7, 3, 0),
    (9, 7, 3, 8),
    (9, 8, 2, 0),
    (17, 14, 4, 0),
    (16, 4, 5, 11),
    (17, 6, 12, 0),
    (17, 12, 6, 0),
    (17, 4, 14, 0),
    (17, 15, 14, 0),
    (13, 5, 9, 0),
    (43, 32, 22, 0),
    (41, 5, 39, 0),
)
_RULEBOOK_AFFINE_BLOCKED_PAIRS: frozenset[tuple[int, int]] = frozenset()
def should_try_rulebook_affine(eq1_id: int, eq2_id: int) -> bool:
    return (eq1_id, eq2_id) not in _RULEBOOK_AFFINE_BLOCKED_PAIRS
def _strip_balanced_outer_parens(s: str) -> str:
    s = s.strip()
    while len(s) >= 2 and s[0] == "(" and s[-1] == ")":
        depth = 0
        matched = True
        for i, c in enumerate(s):
            if c == "(":
                depth += 1
            elif c == ")":
                depth -= 1
            if depth == 0 and i < len(s) - 1:
                matched = False
                break
        if not matched:
            break
        s = s[1:-1].strip()
    return s
def _split_top_level_op(s: str):
    depth = 0
    last_op = -1
    for i, c in enumerate(s):
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
        elif c == "◇" and depth == 0:
            last_op = i
    if last_op < 0:
        return None
    return s[:last_op], s[last_op + 1 :]
def _affine_term_signature(term: str, n: int, a: int, b: int, c: int):
    term = _strip_balanced_outer_parens(term.replace("*", "◇"))
    if re.fullmatch(r"[a-z]", term):
        return 0, {term: 1 % n}
    split = _split_top_level_op(term)
    if split is None:
        raise ValueError(f"cannot parse affine term: {term!r}")
    left, right = split
    l_const, l_coeffs = _affine_term_signature(left, n, a, b, c)
    r_const, r_coeffs = _affine_term_signature(right, n, a, b, c)
    coeffs = {}
    for v in set(l_coeffs) | set(r_coeffs):
        coeff = (a * l_coeffs.get(v, 0) + b * r_coeffs.get(v, 0)) % n
        if coeff:
            coeffs[v] = coeff
    return (a * l_const + b * r_const + c) % n, coeffs
def _affine_equation_holds(eq_text: str, n: int, a: int, b: int, c: int) -> bool:
    eq_text = eq_text.replace("*", "◇")
    if "=" not in eq_text or "≠" in eq_text:
        raise ValueError("not an equality")
    lhs, rhs = (part.strip() for part in eq_text.split("=", 1))
    return (
        _affine_term_signature(lhs, n, a, b, c)
        == _affine_term_signature(rhs, n, a, b, c)
    )
def find_rulebook_affine_counterexample(eq1_text: str, eq2_text: str):

    for model in _RULEBOOK_AFFINE_MODELS:
        n, a, b, c = model
        try:
            if (
                _affine_equation_holds(eq1_text, n, a, b, c)
                and not _affine_equation_holds(eq2_text, n, a, b, c)
            ):
                return model
        except Exception:
            continue
    return None
def make_affine_false_code(n: int, a: int, b: int, c: int) -> str:
    if (n, a, b, c) == (43, 32, 22, 0):
        return (
            "import JudgeProblem\n"
            "import JudgeDecide.DecideBang\n"
            "set_option maxRecDepth 1000000\n"
            "set_option maxHeartbeats 0\n\n"
            "namespace MemoFinOp\n"
            "def affineOp_43_32_22_0 (i j : Fin 43) : Fin 43 :=\n"
            "  ⟨(32 * i.val + 22 * j.val) % 43, Nat.mod_lt _ (by decide)⟩\n"
            "def scale16_43 (u : Fin 43) : Fin 43 :=\n"
            "  ⟨(16 * u.val) % 43, Nat.mod_lt _ (by decide)⟩\n"
            "end MemoFinOp\n\n"
            "def submission : Goal := by\n"
            "  let m : Magma (Fin 43) := { op := MemoFinOp.affineOp_43_32_22_0 }\n"
            "  refine ⟨Fin 43, m, ?_⟩\n"
            "  constructor\n"
            "  · have hc : ∀ u y : Fin 43, m.op y (m.op u y) = MemoFinOp.scale16_43 u := by\n"
            "      decideFin!\n"
            "    have hf : ∀ x z : Fin 43, m.op (MemoFinOp.scale16_43 (m.op x (m.op z z))) z = x := by\n"
            "      decideFin!\n"
            "    intro x y z\n"
            "    rw [hc]\n"
            "    exact (hf x z).symm\n"
            "  · decideFin!\n"
        )
    if n <= 8:
        table = [[(a * i + b * j + c) % n for j in range(n)] for i in range(n)]
        return make_rulebook_explicit_table_false_code(table)
    name = f"affineOp_{n}_{a}_{b}_{c}"
    return (
        "import JudgeProblem\n"
        "import JudgeDecide.DecideBang\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n"
        f"def {name} (i j : Fin {n}) : Fin {n} :=\n"
        f"  ⟨({a} * i.val + {b} * j.val + {c}) % {n}, Nat.mod_lt _ (by decide)⟩\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        f"  let m : Magma (Fin {n}) := {{ op := MemoFinOp.{name} }}\n"
        f"  refine ⟨Fin {n}, m, ?_⟩\n"
        "  decideFin!\n"
    )
_F23_I = 0b100010001
def _f23_tree(text):
    text = _strip_balanced_outer_parens(text.replace("*", "◇"))
    if re.fullmatch(r"[a-z]", text):
        return text
    split = _split_top_level_op(text)
    if split is None:
        raise ValueError("not an F2^3 affine term")
    return _f23_tree(split[0]), _f23_tree(split[1])
def _f23_leaves(t):
    return (t,) if isinstance(t, str) else _f23_leaves(t[0]) + _f23_leaves(t[1])
def _f23_app(m, v):
    return ((m & 7) if v & 1 else 0) ^ (((m >> 3) & 7) if v & 2 else 0) ^ \
        (((m >> 6) & 7) if v & 4 else 0)
def _f23_comp(a, b):
    return _f23_app(a, b & 7) | (_f23_app(a, (b >> 3) & 7) << 3) | \
        (_f23_app(a, (b >> 6) & 7) << 6)
def _f23_sig(t, a, b, p, n):
    if isinstance(t, str):
        r = [0] * n
        r[p[t] + 1] = _F23_I
        return r
    left = _f23_sig(t[0], a, b, p, n)
    right = _f23_sig(t[1], a, b, p, n)
    return [_f23_comp(a, x) ^ _f23_comp(b, y) ^
            (_F23_I if i == 0 else 0)
            for i, (x, y) in enumerate(zip(left, right))]
def find_f2_3_affine_completion_counterexample(eq1_text, eq2_text):
    def equation(text):
        text = text.replace("*", "◇")
        if text.count("=") != 1 or "≠" in text:
            raise ValueError("not an equality")
        return tuple(_f23_tree(side) for side in text.split("=", 1))

    sv, st = equation(eq1_text)
    if not isinstance(sv, str) and isinstance(st, str):
        sv, st = st, sv
    if not isinstance(sv, str) or isinstance(st, str):
        return None
    leaves = _f23_leaves(st)
    counts = collections.Counter(leaves)
    if (len(leaves) != 6 or len(counts) != 3 or
            set(counts.values()) != {2} or sv not in counts):
        return None

    tl, tr = equation(eq2_text)
    variables = sorted({sv, *leaves, *_f23_leaves(tl), *_f23_leaves(tr)})
    p = {v: i for i, v in enumerate(variables)}
    n = len(p) + 1
    wanted = [0] * n
    wanted[p[sv] + 1] = _F23_I
    for a in range(512):
        for b in range(512):
            source = _f23_sig(st, a, b, p, n)
            if source[1:] != wanted[1:]:
                continue
            left = _f23_sig(tl, a, b, p, n)
            right = _f23_sig(tr, a, b, p, n)
            delta = [x ^ y for x, y in zip(left, right)]
            for c in range(8):
                if (_f23_app(source[0], c) == 0 and
                        (any(delta[1:]) or _f23_app(delta[0], c))):
                    return [[_f23_app(a, x) ^ _f23_app(b, y) ^ c
                             for y in range(8)] for x in range(8)]
    return None
def parse_equation(text: str):
    seen: set[str] = set()
    variables: list[str] = []
    for v in re.findall(r"\b([a-z])\b", text):
        if v not in seen:
            seen.add(v)
            variables.append(v)
    lhs_str, rhs_str = text.split("=", 1)

    def _to_expr(s: str):
        s = s.strip()

        while len(s) >= 2 and s[0] == "(" and s[-1] == ")":
            depth = 0
            matched = True
            for i, c in enumerate(s):
                if c == "(":
                    depth += 1
                elif c == ")":
                    depth -= 1
                if depth == 0 and i < len(s) - 1:
                    matched = False
                    break
            if matched:
                s = s[1:-1].strip()
            else:
                break

        depth = 0
        last_op = -1
        for i, c in enumerate(s):
            if c == "(":
                depth += 1
            elif c == ")":
                depth -= 1
            elif c == "◇" and depth == 0:
                last_op = i
        if last_op >= 0:
            left = _to_expr(s[:last_op])
            right = _to_expr(s[last_op + 1 :])
            return lambda env, l=left, r=right: env["op"](l(env), r(env))
        s = s.strip()
        if len(s) == 1 and s in seen:
            return lambda env, v=s: env[v]
        raise ValueError(f"cannot parse: {s!r}")

    return variables, _to_expr(lhs_str), _to_expr(rhs_str)
def search_counterexample(eq1_text: str, eq2_text: str, max_n: int = 5,
                          random_budget: int = 30000, time_budget: float = 8.0):











    import random
    import time
    lhs_vars, lhs_l, lhs_r = parse_equation(eq1_text)
    rhs_vars, rhs_l, rhs_r = parse_equation(eq2_text)

    def check_eq(variables, lhs_fn, rhs_fn, n, op):
        for vals in product(range(n), repeat=len(variables)):
            env = {"op": op}
            for v, val in zip(variables, vals):
                env[v] = val
            if lhs_fn(env) != rhs_fn(env):
                return False
        return True

    def try_table(table, n):
        op = lambda a, b, t=table: t[a][b]
        return (check_eq(lhs_vars, lhs_l, lhs_r, n, op)
                and not check_eq(rhs_vars, rhs_l, rhs_r, n, op))


    for n in range(2, min(max_n, 3) + 1):
        total = n ** (n * n)
        for enc in range(total):
            table = [[(enc // (n ** (i * n + j))) % n for j in range(n)] for i in range(n)]
            if try_table(table, n):
                return n, table

    if max_n < 4:
        return None, None


    rng = random.Random(0xC0FFEE)
    deadline = time.time() + time_budget
    for n in range(4, max_n + 1):
        for _ in range(random_budget):
            if time.time() > deadline:
                return None, None
            table = [[rng.randrange(n) for _ in range(n)] for _ in range(n)]
            if try_table(table, n):
                return n, table

    return None, None
def _check_eq(variables, lhs_fn, rhs_fn, n, op):

    for vals in product(range(n), repeat=len(variables)):
        env = {"op": op}
        for v, val in zip(variables, vals):
            env[v] = val
        if lhs_fn(env) != rhs_fn(env):
            return False
    return True
def _structured_tables(n: int) -> list[list[list[int]]]:

    out: list[list[list[int]]] = []
    for c in range(n):
        out.append([[c] * n for _ in range(n)])
    out.append([[i] * n for i in range(n)])              # left-projection
    out.append([list(range(n)) for _ in range(n)])       # right-projection
    out.append([[(i + j) % n for j in range(n)] for i in range(n)])
    out.append([[(i - j) % n for j in range(n)] for i in range(n)])
    for i in range(n):
        out.append([[i] * n for _ in range(n)])
    for r in range(n):
        for c in range(n):
            for v in range(1, n):
                t = [[0] * n for _ in range(n)]
                t[r][c] = v
                out.append(t)
    return out
def _search_structured(vs1, l1, r1, vs2, l2, r2, max_n=8):
    for n in range(2, max_n + 1):
        for table in _structured_tables(n):
            op = lambda a, b, t=table: t[a][b]
            if _check_eq(vs1, l1, r1, n, op) and not _check_eq(vs2, l2, r2, n, op):
                return n, table
    return None
def _search_linear_zp(vs1, l1, r1, vs2, l2, r2, primes=(2, 3, 5, 7)):
    for p in primes:
        for a, b, c in product(range(p), repeat=3):
            op = lambda x, y, a=a, b=b, c=c, p=p: (a*x + b*y + c) % p
            if _check_eq(vs1, l1, r1, p, op) and not _check_eq(vs2, l2, r2, p, op):
                return p, [[(a*i + b*j + c) % p for j in range(p)] for i in range(p)]
    return None
def _search_bilinear_ext(vs1, l1, r1, vs2, l2, r2, primes=(3, 5)):
    for p in primes:
        for a, b, c, d in product(range(p), repeat=4):
            table = [[(a*i + b*j + c*i*j + d) % p for j in range(p)] for i in range(p)]
            op = lambda x, y, t=table: t[x][y]
            if _check_eq(vs1, l1, r1, p, op) and not _check_eq(vs2, l2, r2, p, op):
                return p, table
    return None
def _search_quadratic_zp(vs1, l1, r1, vs2, l2, r2, primes=(3, 5)):
    for p in primes:
        for a, b, c, d, e, f in product(range(p), repeat=6):
            table = [[(a*i*i + b*j*j + c*i*j + d*i + e*j + f) % p
                      for j in range(p)] for i in range(p)]
            op = lambda x, y, t=table: t[x][y]
            if _check_eq(vs1, l1, r1, p, op) and not _check_eq(vs2, l2, r2, p, op):
                return p, table
    return None
def _search_cyclic(vs1, l1, r1, vs2, l2, r2, max_n=12):
    for n in range(2, max_n):
        for k in range(1, n):
            table = [[(i + k) % n for _ in range(n)] for i in range(n)]
            op = lambda x, y, t=table: t[x][y]
            if _check_eq(vs1, l1, r1, n, op) and not _check_eq(vs2, l2, r2, n, op):
                return n, table
            table = [[(j + k) % n for j in range(n)] for _ in range(n)]
            op = lambda x, y, t=table: t[x][y]
            if _check_eq(vs1, l1, r1, n, op) and not _check_eq(vs2, l2, r2, n, op):
                return n, table
    return None
def _search_zp_zq_product(vs1, l1, r1, vs2, l2, r2, n_range=(4, 10)):
    for n in range(n_range[0], n_range[1]):
        for p in range(2, n):
            if n % p:
                continue
            q = n // p
            for a1, a2, b1, b2 in product(range(p), range(p), range(q), range(q)):
                if a1 == 0 and a2 == 0 and b1 == 0 and b2 == 0:
                    continue
                table = [[0] * n for _ in range(n)]
                for i in range(n):
                    for j in range(n):
                        rs, ss = i // q, i % q
                        ts, us = j // q, j % q
                        table[i][j] = ((a1*rs + a2*ts) % p) * q + ((b1*ss + b2*us) % q)
                op = lambda x, y, t=table: t[x][y]
                if _check_eq(vs1, l1, r1, n, op) and not _check_eq(vs2, l2, r2, n, op):
                    return n, table
    return None
def _search_near_miss(vs1, l1, r1, vs2, l2, r2,
                       sizes=(3, 4, 5), mutations_per_base=80, time_budget=8.0):

    import random as _r, time as _t
    rng = _r.Random(0xDEADBEEF)
    deadline = _t.time() + time_budget
    for n in sizes:
        if _t.time() > deadline:
            return None
        bases = []
        for tbl in _structured_tables(n):
            op = lambda a, b, t=tbl: t[a][b]
            if _check_eq(vs1, l1, r1, n, op):
                bases.append([row[:] for row in tbl])
        for base in bases[:10]:
            for _ in range(mutations_per_base):
                if _t.time() > deadline:
                    return None
                mutated = [row[:] for row in base]
                for _ in range(rng.randint(1, 2)):
                    mi, mj = rng.randrange(n), rng.randrange(n)
                    mutated[mi][mj] = rng.randrange(n)
                op = lambda a, b, t=mutated: t[a][b]
                if _check_eq(vs1, l1, r1, n, op) and not _check_eq(vs2, l2, r2, n, op):
                    return n, mutated
    return None
def _search_backtrack(vs1, l1, r1, vs2, l2, r2, sizes=(3, 4, 5), time_budget=10.0):

    import time as _t
    deadline = _t.time() + time_budget
    for n in sizes:
        if _t.time() > deadline:
            return None
        cells = [(i, j) for i in range(n) for j in range(n)]
        nc = n * n
        table = [[None] * n for _ in range(n)]
        vals = [0] * nc
        ci = 0
        while 0 <= ci < nc:
            if _t.time() > deadline:
                return None
            i, j = cells[ci]
            if vals[ci] >= n:
                table[i][j] = None; vals[ci] = 0; ci -= 1
                if ci >= 0:
                    table[cells[ci][0]][cells[ci][1]] = None
                    vals[ci] += 1
                continue
            table[i][j] = vals[ci]
            op = lambda a, b, t=table: t[a][b] if t[a][b] is not None else None
            eq1_ok = True
            for vv in product(range(n), repeat=len(vs1)):
                env = {"op": op}
                for v, val in zip(vs1, vv):
                    env[v] = val
                try:
                    lv, rv = l1(env), r1(env)
                except TypeError:
                    continue
                if lv is not None and rv is not None and lv != rv:
                    eq1_ok = False; break
            if eq1_ok:
                if ci == nc - 1:
                    fop = lambda a, b, t=table: t[a][b]
                    if not _check_eq(vs2, l2, r2, n, fop):
                        return n, [row[:] for row in table]
                    vals[ci] += 1; table[i][j] = None
                else:
                    ci += 1
            else:
                table[i][j] = None; vals[ci] += 1
    return None
def _search_random_fin(vs1, l1, r1, vs2, l2, r2,
                        sizes=((3, 19683), (4, 50000), (5, 50000),
                               (6, 10000), (7, 5000), (8, 2000)),
                        time_budget=20.0):
    import random as _r, time as _t
    rng = _r.Random(0xC0FFEE)
    deadline = _t.time() + time_budget
    for n, attempts in sizes:
        for _ in range(attempts):
            if _t.time() > deadline:
                return None
            table = [[rng.randrange(n) for _ in range(n)] for _ in range(n)]
            op = lambda x, y, t=table: t[x][y]
            if _check_eq(vs1, l1, r1, n, op) and not _check_eq(vs2, l2, r2, n, op):
                return n, table
    return None
def _parse_tree(text: str, vs: list[str]):

    s = text.strip()
    while len(s) >= 2 and s[0] == "(" and s[-1] == ")":
        depth = 0; matched = True
        for i, c in enumerate(s):
            if c == "(": depth += 1
            elif c == ")": depth -= 1
            if depth == 0 and i < len(s) - 1:
                matched = False; break
        if matched: s = s[1:-1].strip()
        else: break
    depth = 0; last_op = -1
    for i, c in enumerate(s):
        if c == "(": depth += 1
        elif c == ")": depth -= 1
        elif c == "◇" and depth == 0:
            last_op = i
    if last_op >= 0:
        return ("op", _parse_tree(s[:last_op], vs), _parse_tree(s[last_op + 1:], vs))
    if len(s) == 1 and s in vs:
        return ("var", s)
    raise ValueError(f"cannot parse: {s!r}")
def _gauss_null_basis_mod_p(rows: list[list[int]], n_cols: int, p: int) -> list[list[int]]:

    if not rows:

        return [[1 if j == i else 0 for j in range(n_cols)] for i in range(n_cols)]
    M = [list(row) for row in rows]
    n_rows = len(M)
    pivot_cols: list[int] = []
    pivot_row_of_col: dict = {}
    r = 0
    for col in range(n_cols):
        if r >= n_rows: break
        pivot = -1
        for rr in range(r, n_rows):
            if M[rr][col] != 0:
                pivot = rr; break
        if pivot == -1:
            continue
        if pivot != r:
            M[r], M[pivot] = M[pivot], M[r]
        inv = pow(M[r][col], p - 2, p)
        M[r] = [(x * inv) % p for x in M[r]]
        for rr in range(n_rows):
            if rr == r or M[rr][col] == 0:
                continue
            factor = M[rr][col]
            row_r = M[r]
            M[rr] = [(M[rr][j] - factor * row_r[j]) % p for j in range(n_cols)]
        pivot_cols.append(col)
        pivot_row_of_col[col] = r
        r += 1
    pivot_set = set(pivot_cols)
    free_cols = [c for c in range(n_cols) if c not in pivot_set]
    basis = []
    for fc in free_cols:
        vec = [0] * n_cols
        vec[fc] = 1
        for pc in pivot_cols:
            pr = pivot_row_of_col[pc]
            vec[pc] = (-M[pr][fc]) % p
        basis.append(vec)
    return basis
def _cocycle_eval(tree, x_assign: dict, p: int, a: int, b: int):






    kind = tree[0]
    if kind == "var":
        return x_assign[tree[1]], {}
    L = tree[1]; R = tree[2]
    u, cL = _cocycle_eval(L, x_assign, p, a, b)
    v, cR = _cocycle_eval(R, x_assign, p, a, b)
    out: dict = {}
    if a:
        for k, c in cL.items():
            out[k] = (out.get(k, 0) + a * c) % p
    if b:
        for k, c in cR.items():
            out[k] = (out.get(k, 0) + b * c) % p
    out[(u, v)] = (out.get((u, v), 0) + 1) % p
    return (a * u + b * v) % p, out
def _build_cocycle_matrix(vs, lhs_t, rhs_t, p: int, a: int, b: int) -> list[list[int]]:



    rows = []
    for vals in product(range(p), repeat=len(vs)):
        x_assign = dict(zip(vs, vals))
        _, c1 = _cocycle_eval(lhs_t, x_assign, p, a, b)
        _, c2 = _cocycle_eval(rhs_t, x_assign, p, a, b)
        diff: dict = {}
        for k, c in c1.items():
            diff[k] = (diff.get(k, 0) + c) % p
        for k, c in c2.items():
            diff[k] = (diff.get(k, 0) - c) % p
        if any(v % p for v in diff.values()):
            row = [0] * (p * p)
            for (u, v), c in diff.items():
                row[u * p + v] = c % p
            rows.append(row)
    return rows
def _search_cohomology(vs1, l1, r1, vs2, l2, r2, eq1: str, eq2: str,
                       primes=(2, 3, 5, 7)):






    try:
        lt1 = _parse_tree(eq1.split("=", 1)[0], vs1)
        rt1 = _parse_tree(eq1.split("=", 1)[1], vs1)
        lt2 = _parse_tree(eq2.split("=", 1)[0], vs2)
        rt2 = _parse_tree(eq2.split("=", 1)[1], vs2)
    except Exception:
        return None
    for p in primes:

        for a, b in product(range(p), repeat=2):
            if a == 0 and b == 0:
                continue
            op_g = lambda x, y, a=a, b=b, p=p: (a * x + b * y) % p
            if not _check_eq(vs1, l1, r1, p, op_g):
                continue
            try:
                A1 = _build_cocycle_matrix(vs1, lt1, rt1, p, a, b)
                A2 = _build_cocycle_matrix(vs2, lt2, rt2, p, a, b)
            except Exception:
                continue
            null_basis = _gauss_null_basis_mod_p(A1, p * p, p)
            for f_vec in null_basis:
                hit = False
                for row in A2:
                    s = 0
                    for j in range(p * p):
                        s += row[j] * f_vec[j]
                    if s % p != 0:
                        hit = True; break
                if not hit:
                    continue
                f_table = [[f_vec[u * p + v] for v in range(p)] for u in range(p)]
                n = p * p
                table = [[0] * n for _ in range(n)]
                for x in range(p):
                    for sv in range(p):
                        idx_xs = x * p + sv
                        for y in range(p):
                            for tv in range(p):
                                nx = (a * x + b * y) % p
                                ns = (a * sv + b * tv + f_table[x][y]) % p
                                table[idx_xs][y * p + tv] = nx * p + ns


                op_e = lambda u, v, t=table: t[u][v]
                if _check_eq(vs1, l1, r1, n, op_e) and not _check_eq(vs2, l2, r2, n, op_e):
                    return n, table
    return None
def _search_twisting(vs1, l1, r1, vs2, l2, r2, eq1: str, eq2: str,
                     time_budget: float = 6.0):







    import time as _t
    deadline = _t.time() + time_budget
    plan = [(2, 5), (3, 3)]  # (prime, k_max)
    for p, k_max in plan:

        for alpha, beta, gamma, delta in product(range(p), repeat=4):
            if _t.time() > deadline:
                return None
            op_base = (lambda x, y, A=alpha, B=beta, C=gamma, D=delta, P=p:
                       (A * x + B * y + C * x * y + D) % P)
            if not _check_eq(vs1, l1, r1, p, op_base):
                continue
            for k in range(2, k_max + 1):
                if _t.time() > deadline:
                    return None
                n = p ** k
                if n > 64:  # carrier cap
                    continue

                base_tbl = [[op_base(i, j) for j in range(p)] for i in range(p)]

                def decode(z, k=k, p=p):
                    xs = [0] * k
                    for i in range(k):
                        xs[i] = z % p
                        z //= p
                    return xs

                for s in range(k):
                    for t in range(k):
                        if s == 0 and t == 0:
                            continue
                        if _t.time() > deadline:
                            return None
                        table = [[0] * n for _ in range(n)]
                        for x_enc in range(n):
                            xs = decode(x_enc)
                            for y_enc in range(n):
                                ys = decode(y_enc)
                                z = 0
                                mul = 1
                                for i in range(k):
                                    zi = base_tbl[xs[(i + s) % k]][ys[(i + t) % k]]
                                    z += zi * mul
                                    mul *= p
                                table[x_enc][y_enc] = z
                        op = lambda u, v, t=table: t[u][v]
                        if _check_eq(vs1, l1, r1, n, op):
                            if not _check_eq(vs2, l2, r2, n, op):
                                return n, table
    return None
def _search_enlargement(vs1, l1, r1, vs2, l2, r2, time_budget: float = 4.0):




    import time as _t
    deadline = _t.time() + time_budget

    base_sizes = (2, 3, 4)
    for m in base_sizes:
        if _t.time() > deadline:
            return None
        bases = []
        for tbl in _structured_tables(m):
            op = lambda a, b, t=tbl: t[a][b]
            if _check_eq(vs1, l1, r1, m, op) and _check_eq(vs2, l2, r2, m, op):
                bases.append([row[:] for row in tbl])
        for base in bases[:8]:
            if _t.time() > deadline:
                return None
            n = m + 1

            new_cells = [(m, j) for j in range(n)] + [(i, m) for i in range(m)]
            nc = len(new_cells)
            table = [[base[i][j] if i < m and j < m else None
                      for j in range(n)] for i in range(n)]
            vals = [0] * nc
            ci = 0
            while 0 <= ci < nc:
                if _t.time() > deadline:
                    return None
                i, j = new_cells[ci]
                if vals[ci] >= n:
                    table[i][j] = None; vals[ci] = 0; ci -= 1
                    if ci >= 0:
                        bi, bj = new_cells[ci]
                        table[bi][bj] = None
                        vals[ci] += 1
                    continue
                table[i][j] = vals[ci]
                op_p = lambda a, b, t=table: t[a][b] if t[a][b] is not None else None
                eq1_ok = True
                for vv in product(range(n), repeat=len(vs1)):
                    env = {"op": op_p}
                    for v_n, val in zip(vs1, vv):
                        env[v_n] = val
                    try:
                        lv, rv = l1(env), r1(env)
                    except TypeError:
                        continue
                    if lv is not None and rv is not None and lv != rv:
                        eq1_ok = False; break
                if eq1_ok:
                    if ci == nc - 1:
                        fop = lambda a, b, t=table: t[a][b]
                        if not _check_eq(vs2, l2, r2, n, fop):
                            return n, [row[:] for row in table]
                        vals[ci] += 1; table[i][j] = None
                    else:
                        ci += 1
                else:
                    table[i][j] = None; vals[ci] += 1
    return None
def _search_greedy_latin(vs1, l1, r1, vs2, l2, r2,
                         sizes=(3, 4, 5), time_budget: float = 4.0):









    import time as _t
    deadline = _t.time() + time_budget
    for n in sizes:
        if _t.time() > deadline:
            return None
        cells = [(i, j) for i in range(n) for j in range(n)]
        nc = n * n
        table = [[None] * n for _ in range(n)]
        used_row = [set() for _ in range(n)]
        used_col = [set() for _ in range(n)]
        vals = [0] * nc
        ci = 0
        while 0 <= ci < nc:
            if _t.time() > deadline:
                return None
            i, j = cells[ci]
            v = vals[ci]
            while v < n and (v in used_row[i] or v in used_col[j]):
                v += 1
            vals[ci] = v
            if v >= n:
                prev = table[i][j]
                if prev is not None:
                    used_row[i].discard(prev); used_col[j].discard(prev)
                table[i][j] = None; vals[ci] = 0; ci -= 1
                if ci >= 0:
                    bi, bj = cells[ci]
                    pv = table[bi][bj]
                    if pv is not None:
                        used_row[bi].discard(pv); used_col[bj].discard(pv)
                    table[bi][bj] = None
                    vals[ci] += 1
                continue
            table[i][j] = v
            used_row[i].add(v); used_col[j].add(v)
            op_p = lambda a, b, t=table: t[a][b] if t[a][b] is not None else None
            eq1_ok = True
            for vv in product(range(n), repeat=len(vs1)):
                env = {"op": op_p}
                for vn, val in zip(vs1, vv):
                    env[vn] = val
                try:
                    lv, rv = l1(env), r1(env)
                except TypeError:
                    continue
                if lv is not None and rv is not None and lv != rv:
                    eq1_ok = False; break
            if eq1_ok:
                if ci == nc - 1:
                    fop = lambda a, b, t=table: t[a][b]
                    if not _check_eq(vs2, l2, r2, n, fop):
                        return n, [row[:] for row in table]
                    used_row[i].discard(v); used_col[j].discard(v)
                    table[i][j] = None; vals[ci] += 1
                else:
                    ci += 1
            else:
                used_row[i].discard(v); used_col[j].discard(v)
                table[i][j] = None; vals[ci] += 1
    return None
def find_counterexample_cheap(eq1: str, eq2: str):

    try:
        vs1, l1, r1 = parse_equation(eq1)
        vs2, l2, r2 = parse_equation(eq2)
    except Exception:
        return None
    families = [
        lambda: _search_structured(vs1, l1, r1, vs2, l2, r2, max_n=8),
        lambda: _search_linear_zp(vs1, l1, r1, vs2, l2, r2),
        lambda: _search_cyclic(vs1, l1, r1, vs2, l2, r2),
        lambda: _search_bilinear_ext(vs1, l1, r1, vs2, l2, r2),
        lambda: _search_quadratic_zp(vs1, l1, r1, vs2, l2, r2),
        lambda: _search_cohomology(vs1, l1, r1, vs2, l2, r2, eq1, eq2),
        lambda: _search_zp_zq_product(vs1, l1, r1, vs2, l2, r2),
        lambda: _search_twisting(vs1, l1, r1, vs2, l2, r2, eq1, eq2),
        lambda: _search_near_miss(vs1, l1, r1, vs2, l2, r2),
        lambda: _search_backtrack(vs1, l1, r1, vs2, l2, r2),
        lambda: _search_greedy_latin(vs1, l1, r1, vs2, l2, r2),
        lambda: _search_enlargement(vs1, l1, r1, vs2, l2, r2),
        lambda: _search_random_fin(vs1, l1, r1, vs2, l2, r2),
    ]
    for fn in families:
        r = fn()
        if r is not None:
            return r
    return None
# === END V97 FALSE ENGINE ===

# This appendix is concatenated after the mechanically extracted v97 False
# engine.  It deliberately uses only formula fields and never calls the
# Equation-ID-indexed v97 selectors.

import hashlib
import signal
import time


PROVER_NAME = "v97-false-prover-d1"
PROVER_SCHEMA = "stage2-false-countermodel-prover-result-v1"
V97_FALSE_SOURCE_SHA256 = "b48147f11410346dd64d8da97f49016db1ae6711f953e4b3b67cca09fa450e97"

_DEFAULT_CONFIG = {
    "safety_wall_seconds": 295.0,
    "use_model_portfolio": True,
    "use_affine_portfolio": True,
    "use_f2_3_completion": True,
    "use_bruteforce": True,
    "bruteforce_max_n": 5,
    "bruteforce_random_budget": 30000,
    "bruteforce_time_budget": 8.0,
    "use_cheap_families": True,
}
_BOOL_CONFIG_KEYS = {
    "use_model_portfolio",
    "use_affine_portfolio",
    "use_f2_3_completion",
    "use_bruteforce",
    "use_cheap_families",
}


class _SafetyWallExpired(Exception):
    pass


def _safety_wall_handler(_signum, _frame):
    raise _SafetyWallExpired("False prover safety wall expired")


def _arm_safety_wall(seconds):
    if not (
        hasattr(signal, "setitimer")
        and hasattr(signal, "SIGALRM")
        and hasattr(signal, "ITIMER_REAL")
    ):
        return None
    previous = signal.signal(signal.SIGALRM, _safety_wall_handler)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    return previous


def _disarm_safety_wall(previous):
    if previous is None:
        return
    signal.setitimer(signal.ITIMER_REAL, 0.0)
    signal.signal(signal.SIGALRM, previous)


def _parse_runtime_config(config):
    if not isinstance(config, dict):
        raise TypeError("config must be an object")
    copied = dict(config)
    result_save_mode = copied.pop("result_save_mode", "minimal")
    if result_save_mode not in ("minimal", "full"):
        raise ValueError("result_save_mode must be minimal or full")
    nested = copied.pop("search_config", None)
    if nested is not None:
        if copied:
            raise ValueError("nested search_config cannot be mixed with top-level fields")
        if not isinstance(nested, dict):
            raise TypeError("search_config must be an object")
        copied = dict(nested)
    unknown = sorted(set(copied) - set(_DEFAULT_CONFIG))
    if unknown:
        raise ValueError(f"unknown config fields: {unknown}")
    values = dict(_DEFAULT_CONFIG)
    values.update(copied)
    for key in _BOOL_CONFIG_KEYS:
        if type(values[key]) is not bool:
            raise TypeError(f"{key} must be a boolean")
    if not 0.01 <= float(values["safety_wall_seconds"]) <= 3600.0:
        raise ValueError("safety_wall_seconds must be in [0.01, 3600]")
    values["safety_wall_seconds"] = float(values["safety_wall_seconds"])
    if type(values["bruteforce_max_n"]) is not int or not 2 <= values["bruteforce_max_n"] <= 5:
        raise ValueError("bruteforce_max_n must be an integer in [2, 5]")
    if type(values["bruteforce_random_budget"]) is not int or values["bruteforce_random_budget"] < 0:
        raise ValueError("bruteforce_random_budget must be a nonnegative integer")
    values["bruteforce_time_budget"] = float(values["bruteforce_time_budget"])
    if not 0.0 <= values["bruteforce_time_budget"] <= values["safety_wall_seconds"]:
        raise ValueError("bruteforce_time_budget must fit inside the safety wall")
    return result_save_mode, values


def _case_formulas(case):
    if not isinstance(case, dict):
        raise TypeError("case must be an object")
    source = case.get("source_formula")
    target = case.get("target_formula")
    if not isinstance(source, str) or not source.strip():
        raise ValueError("case.source_formula must be a non-empty string")
    if not isinstance(target, str) or not target.strip():
        raise ValueError("case.target_formula must be a non-empty string")
    return case.get("ordinal"), case.get("id"), source, target


def _normalized_formula(formula):
    return formula.replace("*", "◇")


def _parsed_equation(formula):
    return parse_equation(_normalized_formula(formula))


def _normalized_table(table):
    if not isinstance(table, (list, tuple)) or not table:
        raise ValueError("countermodel table must be non-empty")
    n = len(table)
    normalized = []
    for row in table:
        if not isinstance(row, (list, tuple)) or len(row) != n:
            raise ValueError("countermodel table must be square")
        normalized_row = []
        for value in row:
            if type(value) is not int or not 0 <= value < n:
                raise ValueError("countermodel table entry is outside its carrier")
            normalized_row.append(value)
        normalized.append(normalized_row)
    return normalized


def _equation_holds_with_count(parsed, table):
    variables, lhs, rhs = parsed
    n = len(table)
    checked = 0
    for values in product(range(n), repeat=len(variables)):
        checked += 1
        environment = {name: value for name, value in zip(variables, values)}
        environment["op"] = lambda left, right, t=table: t[left][right]
        if lhs(environment) != rhs(environment):
            return False, checked, {
                "assignment": {name: value for name, value in zip(variables, values)},
                "lhs": lhs(environment),
                "rhs": rhs(environment),
            }
    return True, checked, None


def _countermodel_details(source_formula, target_formula, table, metrics):
    normalized = _normalized_table(table)
    source_holds, source_checks, _source_failure = _equation_holds_with_count(
        _parsed_equation(source_formula), normalized
    )
    metrics["assignments_checked"] += source_checks
    if not source_holds:
        return None
    target_holds, target_checks, target_failure = _equation_holds_with_count(
        _parsed_equation(target_formula), normalized
    )
    metrics["assignments_checked"] += target_checks
    if target_holds or target_failure is None:
        return None
    return {
        "order": len(normalized),
        "carrier": list(range(len(normalized))),
        "table": normalized,
        "source_verified": True,
        "target_counterexample": target_failure,
        "validation_mode": "exhaustive_finite_table",
    }


def _affine_countermodel_details(source_formula, target_formula, model, metrics):
    n, a, b, c = model
    source = _normalized_formula(source_formula)
    target = _normalized_formula(target_formula)
    if not _affine_equation_holds(source, n, a, b, c):
        return None
    if _affine_equation_holds(target, n, a, b, c):
        return None
    table = [[(a * i + b * j + c) % n for j in range(n)] for i in range(n)]
    target_holds, target_checks, target_failure = _equation_holds_with_count(
        _parsed_equation(target_formula), table
    )
    metrics["assignments_checked"] += target_checks
    if target_holds or target_failure is None:
        return None
    return {
        "order": n,
        "carrier": list(range(n)),
        "table": table,
        "source_verified": True,
        "target_counterexample": target_failure,
        "validation_mode": "v97_affine_symbolic_plus_target_witness",
        "affine_parameters": {"n": n, "a": a, "b": b, "c": c},
    }


def _early_model_portfolio():
    return (
        ("stage1.9_rulebook_explicit_table_refutation4", _RULEBOOK_REFUTATION4_TABLE),
        ("stage1.9_rulebook_explicit_table_refutation5", _RULEBOOK_REFUTATION5_TABLE),
        ("stage1.9_rulebook_explicit_table_refutation852", _RULEBOOK_REFUTATION852_TABLE),
        ("stage1.9_rulebook_explicit_table_refutation773", _RULEBOOK_REFUTATION773_TABLE),
        ("stage1.9_rulebook_explicit_table_accepted80_block019", _RULEBOOK_ACCEPTED80_BLOCK019_TABLE),
        ("stage1.9_rulebook_explicit_table_accepted80_block005", _RULEBOOK_ACCEPTED80_BLOCK005_TABLE),
        ("stage1.9_rulebook_explicit_table_accepted80_block049", _RULEBOOK_ACCEPTED80_BLOCK049_TABLE),
    )


def _late_model_portfolio():
    rows = [
        (
            "stage1.91_rulebook_affine_n9_micro_orbit_table",
            table,
        )
        for _model_idx, table, _source_bits in _RULEBOOK_AFFINE_N9_MICRO_ORBIT_MODELS
    ]
    rows.extend(
        (
            (
                "stage1.92_rulebook_principal_feedback_table",
                _RULEBOOK_PRINCIPAL_FEEDBACK_TABLE,
            ),
            (
                "stage1.921_rulebook_fin6_sparse_decode_table",
                _RULEBOOK_FIN6_SPARSE_DECODE_TABLE,
            ),
        )
    )
    return tuple(rows)


def _stage_code(stage_name, code):
    return f"-- stage:{stage_name}\n" + code


def _base_result(ordinal, case_id, status, stop_reason, result_save_mode, metrics):
    return {
        "schema_version": PROVER_SCHEMA,
        "prover_name": PROVER_NAME,
        "v97_false_source_sha256": V97_FALSE_SOURCE_SHA256,
        "ordinal": ordinal,
        "id": case_id,
        "status": status,
        "stop_reason": stop_reason,
        "result_save_mode": result_save_mode,
        "certificate_valid": None,
        "verdict": None,
        "judge_verdict": None,
        "metrics": dict(metrics),
    }


def _refuted_result(
    ordinal,
    case_id,
    result_save_mode,
    metrics,
    trace,
    stage_name,
    countermodel,
    lean_code,
):
    result = _base_result(
        ordinal,
        case_id,
        "REFUTED",
        "COUNTERMODEL_FOUND",
        result_save_mode,
        metrics,
    )
    result.update(
        {
            "certificate_valid": True,
            "certificate_kind": "finite_magma_countermodel",
            "verdict": False,
            "judge_verdict": "false",
            "stage": stage_name,
            "countermodel": countermodel,
            "judge_lean": _stage_code(stage_name, lean_code),
        }
    )
    if result_save_mode == "full":
        result["trace"] = list(trace)
    return result


def _record(trace, metrics, stage, event, **fields):
    metrics["stage_events"] += 1
    trace.append(
        {
            "seq": len(trace) + 1,
            "stage": stage,
            "event": event,
            **fields,
        }
    )


def _try_table_portfolio(source, target, rows, metrics, trace):
    for stage_name, raw_table in rows:
        metrics["model_checks"] += 1
        details = _countermodel_details(source, target, raw_table, metrics)
        _record(trace, metrics, stage_name, "hit" if details else "miss")
        if details is not None:
            return stage_name, details, make_rulebook_explicit_table_false_code(
                details["table"]
            )
    return None


def prove(case, config):
    """Search for a finite countermodel for one formula-only implication case."""

    started = time.monotonic()
    ordinal = case.get("ordinal") if isinstance(case, dict) else None
    case_id = case.get("id") if isinstance(case, dict) else None
    result_save_mode = "minimal"
    previous_alarm = None
    trace = []
    metrics = {
        "architecture": "v97-false-transitive-slice-formula-only-v1",
        "model_checks": 0,
        "assignments_checked": 0,
        "stage_events": 0,
        "elapsed_seconds": 0.0,
    }
    try:
        ordinal, case_id, source, target = _case_formulas(case)
        result_save_mode, runtime = _parse_runtime_config(config)
        _parsed_equation(source)
        _parsed_equation(target)
        previous_alarm = _arm_safety_wall(runtime["safety_wall_seconds"])

        if runtime["use_model_portfolio"]:
            hit = _try_table_portfolio(
                source, target, _early_model_portfolio(), metrics, trace
            )
            if hit is not None:
                stage, details, code = hit
                metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                return _refuted_result(
                    ordinal, case_id, result_save_mode, metrics, trace, stage, details, code
                )

        if runtime["use_affine_portfolio"]:
            stage = "stage1.9_rulebook_affine"
            model = find_rulebook_affine_counterexample(source, target)
            metrics["model_checks"] += len(_RULEBOOK_AFFINE_MODELS)
            details = (
                _affine_countermodel_details(source, target, model, metrics)
                if model is not None
                else None
            )
            _record(trace, metrics, stage, "hit" if details else "miss")
            if details is not None:
                metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                return _refuted_result(
                    ordinal,
                    case_id,
                    result_save_mode,
                    metrics,
                    trace,
                    stage,
                    details,
                    make_affine_false_code(*model),
                )

        if runtime["use_model_portfolio"]:
            hit = _try_table_portfolio(
                source, target, _late_model_portfolio(), metrics, trace
            )
            if hit is not None:
                stage, details, code = hit
                metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                return _refuted_result(
                    ordinal, case_id, result_save_mode, metrics, trace, stage, details, code
                )

        if runtime["use_f2_3_completion"]:
            stage = "stage1.93_f2_3_affine_completion_symbolic_search"
            table = find_f2_3_affine_completion_counterexample(source, target)
            details = (
                _countermodel_details(source, target, table, metrics)
                if table is not None
                else None
            )
            _record(trace, metrics, stage, "hit" if details else "miss")
            if details is not None:
                metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                return _refuted_result(
                    ordinal,
                    case_id,
                    result_save_mode,
                    metrics,
                    trace,
                    stage,
                    details,
                    make_rulebook_explicit_table_false_code(details["table"]),
                )

        if runtime["use_bruteforce"]:
            stage = "stage2_bruteforce_fin_counterexample"
            n, table = search_counterexample(
                source,
                target,
                max_n=runtime["bruteforce_max_n"],
                random_budget=runtime["bruteforce_random_budget"],
                time_budget=runtime["bruteforce_time_budget"],
            )
            details = (
                _countermodel_details(source, target, table, metrics)
                if n is not None and table is not None
                else None
            )
            _record(trace, metrics, stage, "hit" if details else "miss")
            if details is not None:
                metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                return _refuted_result(
                    ordinal,
                    case_id,
                    result_save_mode,
                    metrics,
                    trace,
                    stage,
                    details,
                    make_false_code(n, details["table"]),
                )

        if runtime["use_cheap_families"]:
            stage = "stage3_cheap_counterexample_families"
            candidate = find_counterexample_cheap(source, target)
            details = (
                _countermodel_details(source, target, candidate[1], metrics)
                if candidate is not None
                else None
            )
            _record(trace, metrics, stage, "hit" if details else "miss")
            if details is not None:
                n, _table = candidate
                metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                return _refuted_result(
                    ordinal,
                    case_id,
                    result_save_mode,
                    metrics,
                    trace,
                    stage,
                    details,
                    make_false_code(n, details["table"]),
                )

        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        result = _base_result(
            ordinal,
            case_id,
            "UNKNOWN",
            "COUNTERMODEL_NOT_FOUND",
            result_save_mode,
            metrics,
        )
        if result_save_mode == "full":
            result["trace"] = list(trace)
        return result
    except _SafetyWallExpired:
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        result = _base_result(
            ordinal,
            case_id,
            "UNKNOWN",
            "SAFETY_WALL",
            result_save_mode,
            metrics,
        )
        if result_save_mode == "full":
            result["trace"] = list(trace)
        return result
    except Exception as error:
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        result = _base_result(
            ordinal,
            case_id,
            "ERROR",
            "PROVER_ERROR",
            result_save_mode,
            metrics,
        )
        result.update(
            {
                "error_type": type(error).__name__,
                "diagnostic": str(error),
            }
        )
        return result
    finally:
        _disarm_safety_wall(previous_alarm)


def _main():
    request = json.loads(sys.stdin.readline())
    result = prove(request.get("case"), request.get("config", {}))
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


__all__ = [
    "PROVER_NAME",
    "PROVER_SCHEMA",
    "V97_FALSE_SOURCE_SHA256",
    "prove",
]


if __name__ == "__main__":
    _main()
