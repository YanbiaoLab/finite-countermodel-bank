# False Solver d2

d2 以 d1 的冻结单文件证明器为基础，加入 2026-W31（2026-07-27 至
2026-08-02）离线挖掘并经 Judge-v3 验收的 244 道 False 所对应的反模型
（countermodel）。d1 文件保持不变。

## d1 评估结论

- 244 道由 189 道有限载体和 55 道无限结构组成。
- 189 道有限载体共使用 146 个冻结模型身份；d1 的 66 个静态模型身份与其中
  145 个可物化乘法表的精确 SHA-256 交集为 0。
- 只启用 d1 的显式表和仿射静态 portfolio 时，对 244 道的公式实际命中为 0。
- 这次评估没有运行 d1 的动态穷举和随机搜索；结论针对“模型是否已经在 d1
  静态 portfolio 中”，不是对 d1 搜索能力的耗时上限评测。

完整账本见 `offline_false244_model_audit.json`。

## d2 增量

d2 新增：

- 145 个可物化有限乘法表，覆盖 188 道；运行时先按 source 公式索引候选模型，
  再逐赋值复验 source 恒真和 target 失败，只有复验通过才返回 `REFUTED`。
- 1 道 625 元 `ZMod 5` 四维非交换 core 运算模型，保留冻结的 Judge-v3 accepted
  Lean 证书。
- 55 道无限结构模型，保留冻结的 Judge-v3 accepted Lean 证书。

后两类使用规范化公式对（normalized formula pair）精确索引，因为它们不能由有限
乘法表穷举复验；它们不是对任意新 target 的泛化模型搜索。所有运行时选择仍只读取
公式，不读取 Equation ID。未命中后完整回退到 d1。

全量本地回归结果为 244/244 `REFUTED`：188 道经有限表运行时复验，1 道结构化有限
模型和 55 道无限结构模型经冻结证书命中。

## 构建和验证

```bash
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d2/build_solver.py
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d2/validate_solver.py
```

构建器固定 d1、Wrong Book 2500（错题集）False-244 账本、有限模型审计和 accepted
证书来源的 SHA-256。验证器执行确定性重建、244 道全量公式回归、有限模型语义复验、
公式输入不受 Equation ID 影响的检查、d1 fallback 和 `python -I -S` 隔离运行。

## `run-prover` 边界

当前可信 Judge 编排只把原始 `SOLVED` 当作 True，并以 `verdict=true` 校验。d2 因而
继续返回 `REFUTED` 和 `judge_verdict=false`；在 `run-prover` 增加 False verdict 编排
前，本地回归不能称为新的远端 Judge 评测。
