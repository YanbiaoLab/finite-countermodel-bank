#!/usr/bin/env python3
"""Build d2 from d1 plus the frozen 2026-W31 offline FALSE model bank."""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import pprint
import re
import runpy
import sys
from typing import Any, Iterable


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def find_repo_root(start: Path) -> Path:
    for candidate in (start, *start.parents):
        if (candidate / ".git").exists() and (candidate / "members/wubing").is_dir():
            return candidate
    raise RuntimeError(f"could not locate repository root from {start}")


REPO_ROOT = find_repo_root(HERE)
D1_PROVER = HERE.parent / "d1/solver.py"
D3_SOLVER = (
    REPO_ROOT
    / "members/wubing/experiments/solvers/FT/drafts/2026-08-04/d3/solver.py"
)
D3_PROOF_MANIFEST = D3_SOLVER.with_name("proof_bank_manifest.json")
RUNTIME_SOURCE = HERE / "runtime.py"
OUTPUT = HERE / "solver.py"
MANIFEST = HERE / "manifest.json"
MODEL_AUDIT = HERE / "offline_false244_model_audit.json"

R475_BASE = (
    REPO_ROOT
    / "members/wubing/artifacts/eval-inputs/candidate2500-atp-llm-judge/"
    "v97-r475-20260723"
)
CANONICAL = (
    REPO_ROOT
    / "members/wubing/benchmarks/open-wrongbooks/candidate-2500/v2/"
    "candidate-2500.jsonl"
)
OFFLINE_90 = (
    REPO_ROOT
    / "members/wubing/benchmarks/unified-saturation-kernel-research/"
    "wrong-book-2500-1664/excluded-a-false.jsonl"
)
OFFLINE_154 = (
    REPO_ROOT
    / "members/wubing/benchmarks/unified-saturation-kernel-research/"
    "wrong-book-2500-1510/excluded-new-false154.jsonl"
)

D1_PROVER_SHA256 = "e4c8d2168bbb5569a6d4db7cc1a8c9517426d10721f297b0370e59cf495c9cf0"
D3_SOLVER_SHA256 = "73d352891f2e6d4c3655065d4f614dfe73b4cf99f4e012eff44cd86461277a6a"
D3_PROOF_MANIFEST_SHA256 = "4eb7b701934decbec46a3552bc04ac76069d7a0c42c1a1dd639e52652638f42e"
EXPECTED_OFFLINE_ID_SHA256 = "e811d5a36041e2f6ccca7ce7146071a6f4fd94b0c483c7c870ae094b52969cd1"

PINNED_INPUTS = {
    "members/wubing/benchmarks/open-wrongbooks/candidate-2500/v2/candidate-2500.jsonl": "435f2cd6684cd08089d57808cf8a25b50d90c6274b484c9072458bb486f26e71",
    "members/wubing/benchmarks/unified-saturation-kernel-research/wrong-book-2500-1664/excluded-a-false.jsonl": "eebea28e1c167cfd1ccf22af730e7a77a83f28d52042c37f9da9696f967a902f",
    "members/wubing/benchmarks/unified-saturation-kernel-research/wrong-book-2500-1510/excluded-new-false154.jsonl": "863e4811a803dd51e38f7cdcfc583223371ffa17b4803a7ce41d13ee50e2bdff",
    "members/wubing/artifacts/reports/wrongbook2500-known-countermodels-20260729-v1/final-audit.json": "e69ed29592199586da7a8c5927c1f619e2ba6fa12e69ac43c2da927acb6f100a",
    "members/wubing/artifacts/reports/wrongbook2500-phase2-fmb-fin5-batch01-20260729-v1/audit.json": "b939b2e999d4a50ffe4c728a78ca9eafd761e4ff62a127e9e8d2d3e398075032",
    "members/wubing/artifacts/reports/wrongbook2500-phase2-fmb-fin5to7-coverage34-20260729-v1/audit.json": "59f04103c88ce7eb0f3339ec2ba4528be4d9b0c15275189cc4c253f524ea0771",
    "members/wubing/artifacts/reports/wrongbook2500-phase2-fmb-fin8to9-coverage13-20260729-v1/audit.json": "6586bd37fd32a54507baaa8e60dc3f0ac14b9cb10092717c9993fed3cad8c091",
    "members/wubing/artifacts/reports/wrongbook2500-phase2-fmb-fin13to20-coverage6-20260729-v1/audit.json": "0702cda5fd4c713544fda258c1041da9683e0f8a4091d45c9543c65deb45316e",
    "members/wubing/artifacts/reports/wrongbook2500-fmb-countersat25-20260729-v1/audit.json": "2e3cc4403ad002b790a5a8f9558ede7dda5024c054e293f2bd0f0c48f6430801",
    "members/wubing/artifacts/eval-inputs/candidate2500-atp-llm-judge/v97-r475-20260723/wrongbook2500-fmb-countersat7-judge-v1/coverage-assignments-2.jsonl": "ca3a52d9bf43ffe47c15d47c16086852efec88661fdf42bce1d2e23d044500c0",
    "members/wubing/artifacts/eval-inputs/candidate2500-atp-llm-judge/v97-r475-20260723/wrongbook2500-affine-mod17-coverage5-judge-v1/affine-models-5.jsonl": "86edcb8a66519d279e512444621d09b074b51e68f5bc436e623bd94de13f97c8",
    "members/wubing/artifacts/eval-inputs/candidate2500-atp-llm-judge/v97-r475-20260723/wrongbook2500-affine19-r310-judge-v1/affine-model-1.jsonl": "e58a6fbf2009e42e1fbf4ef64d55eb3b7280d8ea8e59a95d242a12e34809a3f0",
    "members/wubing/artifacts/eval-inputs/candidate2500-atp-llm-judge/v97-r475-20260723/wrongbook2500-history3-affine1-transfer1-judge-v1/affine-model-1.jsonl": "1de67462f86fd5d4b2d40136206442a5e1fba33734182462f79f3a1d6e112903",
    "members/wubing/artifacts/eval-inputs/candidate2500-atp-llm-judge/v97-r475-20260723/wrongbook2500-extension-field-matrix9-certificates-v1/models-9.jsonl": "3f0fac18eba269ddc20d3d7297a88e3946d6a577d8fc898a27e7237bfd486857",
}

AUDITS = (
    "members/wubing/artifacts/reports/wrongbook2500-known-countermodels-20260729-v1/final-audit.json",
    "members/wubing/artifacts/reports/wrongbook2500-phase2-fmb-fin5-batch01-20260729-v1/audit.json",
    "members/wubing/artifacts/reports/wrongbook2500-phase2-fmb-fin5to7-coverage34-20260729-v1/audit.json",
    "members/wubing/artifacts/reports/wrongbook2500-phase2-fmb-fin8to9-coverage13-20260729-v1/audit.json",
    "members/wubing/artifacts/reports/wrongbook2500-phase2-fmb-fin13to20-coverage6-20260729-v1/audit.json",
    "members/wubing/artifacts/reports/wrongbook2500-fmb-countersat25-20260729-v1/audit.json",
)

COUNTERSAT7 = R475_BASE / "wrongbook2500-fmb-countersat7-judge-v1/coverage-assignments-2.jsonl"
AFFINE_FILES = (
    R475_BASE / "wrongbook2500-affine-mod17-coverage5-judge-v1/affine-models-5.jsonl",
    R475_BASE / "wrongbook2500-affine19-r310-judge-v1/affine-model-1.jsonl",
    R475_BASE / "wrongbook2500-history3-affine1-transfer1-judge-v1/affine-model-1.jsonl",
)
EXTENSION_MODELS = R475_BASE / "wrongbook2500-extension-field-matrix9-certificates-v1/models-9.jsonl"


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                raise RuntimeError(f"blank JSONL row at {path}:{line_number}")
            row = json.loads(line)
            if not isinstance(row, dict):
                raise RuntimeError(f"non-object JSONL row at {path}:{line_number}")
            yield row


def normalized_formula(value: str) -> str:
    return "".join(value.replace("*", "◇").split())


def source_key(value: str) -> str:
    return sha256_bytes(normalized_formula(value).encode("utf-8"))


def formula_key(source: str, target: str) -> str:
    return sha256_bytes(
        (normalized_formula(source) + "\0" + normalized_formula(target)).encode("utf-8")
    )


def table_sha256(table: list[list[int]]) -> str:
    return sha256_bytes(
        json.dumps(table, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    )


def vector_sha256(values: set[str]) -> str:
    return sha256_bytes("".join(f"{value}\n" for value in sorted(values)).encode())


def verify_pins() -> None:
    expected = {
        D1_PROVER: D1_PROVER_SHA256,
        D3_SOLVER: D3_SOLVER_SHA256,
        D3_PROOF_MANIFEST: D3_PROOF_MANIFEST_SHA256,
    }
    expected.update({REPO_ROOT / path: digest for path, digest in PINNED_INPUTS.items()})
    for path, digest in expected.items():
        actual = sha256_path(path)
        if actual != digest:
            raise RuntimeError(f"frozen input drift: {path}: expected {digest}, got {actual}")


def target_ids() -> set[str]:
    ids90 = {
        str(row["wrongbook2500_id"])
        for row in read_jsonl(OFFLINE_90)
        if row.get("classification_source") == "offline_false90_known_countermodels"
    }
    ids154 = {str(row["problem_id"]) for row in read_jsonl(OFFLINE_154)}
    if len(ids90) != 90 or len(ids154) != 154 or ids90 & ids154:
        raise RuntimeError("offline FALSE 90+154 partition drift")
    result = ids90 | ids154
    if vector_sha256(result) != EXPECTED_OFFLINE_ID_SHA256:
        raise RuntimeError("offline FALSE-244 ID vector drift")
    return result


def canonical_cases(ids: set[str]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for row in read_jsonl(CANONICAL):
        problem_id = str(row.get("id"))
        if problem_id not in ids:
            continue
        source = str(row["source_equation_rendered"])
        target = str(row["target_equation_rendered"])
        result[problem_id] = {
            "problem_id": problem_id,
            "r475_ordinal": None,
            "eq1_id": int(row["eq1_id"]),
            "eq2_id": int(row["eq2_id"]),
            "source": source,
            "target": target,
            "formula_key": formula_key(source, target),
        }
    if set(result) != ids:
        raise RuntimeError("canonical Wrong Book 2500 membership drift")
    return result


def frozen_code_bank() -> dict[str, str]:
    source = D3_SOLVER.read_text(encoding="utf-8")
    prefix = "_FT_OFFLINE_FALSE244_BANK = "
    start = source.index(prefix) + len(prefix)
    end = source.index("\n\n\ndef _ft_normalized_formula", start)
    bank = ast.literal_eval(source[start:end].strip())
    if not isinstance(bank, dict) or len(bank) != 244:
        raise RuntimeError("could not recover exact d3 FALSE-244 code bank")
    return bank


def proof_rows(cases: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
    manifest = json.loads(D3_PROOF_MANIFEST.read_text(encoding="utf-8"))
    rows = {str(row["problem_id"]): row for row in manifest["rows"]}
    if set(rows) != set(cases):
        raise RuntimeError("proof-bank/canonical FALSE-244 membership mismatch")
    for problem_id, row in rows.items():
        if row["formula_key_sha256"] != cases[problem_id]["formula_key"]:
            raise RuntimeError(f"formula-key drift for {problem_id}")
        cases[problem_id]["r475_ordinal"] = int(row["r475_ordinal"])
    return rows


def explicit_table_payloads() -> dict[str, list[list[int]]]:
    result: dict[str, list[list[int]]] = {}
    for path in sorted(R475_BASE.rglob("*.jsonl")):
        with path.open(encoding="utf-8", errors="replace") as handle:
            for line in handle:
                if "model_table" not in line and "derived_model_table" not in line:
                    continue
                row = json.loads(line)
                for table_field, sha_field in (
                    ("model_table", "table_sha256"),
                    ("derived_model_table", "derived_table_sha256"),
                ):
                    table = row.get(table_field)
                    digest = row.get(sha_field)
                    if not isinstance(table, list) or not isinstance(digest, str):
                        continue
                    if table_sha256(table) != digest:
                        raise RuntimeError(f"invalid table payload in {path}")
                    previous = result.setdefault(digest, table)
                    if previous != table:
                        raise RuntimeError(f"table SHA collision for {digest}")
    return result


def audited_table_assignments() -> dict[str, str]:
    result: dict[str, str] = {}
    segment_counts: list[int] = []
    for relative in AUDITS:
        rows = json.loads((REPO_ROOT / relative).read_text(encoding="utf-8"))["final_results"]
        segment_counts.append(len(rows))
        for row in rows:
            problem_id = str(row["problem_id"])
            if problem_id in result:
                raise RuntimeError(f"duplicate audited model assignment for {problem_id}")
            result[problem_id] = str(row["table_sha256"])
    if segment_counts != [90, 25, 34, 13, 6, 2] or len(result) != 170:
        raise RuntimeError(f"finite audit segment drift: {segment_counts}")
    return result


def affine_table(row: dict[str, Any]) -> list[list[int]]:
    parameters = row.get("parameters")
    if isinstance(parameters, dict):
        n = int(parameters["modulus"])
        a = int(parameters["left_multiplier"])
        b = int(parameters["right_multiplier"])
        c = int(parameters["constant"])
    else:
        match = re.fullmatch(
            r"\((\d+) \* left \+ (\d+) \* right(?: \+ (\d+))?\) mod (\d+)",
            str(row["operation"]),
        )
        if match is None:
            raise RuntimeError(f"unparsed affine operation: {row['operation']}")
        a, b, c, n = (int(value or 0) for value in match.groups())
    table = [[(a * left + b * right + c) % n for right in range(n)] for left in range(n)]
    if table_sha256(table) != row["table_sha256"]:
        raise RuntimeError(f"affine table hash drift for {row['problem_id']}")
    return table


def decode_digits(value: int, prime: int, degree: int) -> list[int]:
    result = []
    for _ in range(degree):
        result.append(value % prime)
        value //= prime
    return result


def encode_digits(values: list[int], prime: int) -> int:
    result = 0
    scale = 1
    for value in values:
        result += value * scale
        scale *= prime
    return result


def extension_table(row: dict[str, Any]) -> list[list[int]]:
    field = row["field"]
    prime = int(field["prime"])
    degree = int(field["degree"])
    order = int(field["order"])
    operation = row["operation"]
    left_matrix = operation["left_matrix_rows"]
    right_matrix = operation["right_matrix_rows"]
    digits = [decode_digits(value, prime, degree) for value in range(order)]
    table: list[list[int]] = []
    for left in digits:
        output_row = []
        for right in digits:
            output = [
                sum(left_matrix[i][j] * left[j] + right_matrix[i][j] * right[j] for j in range(degree)) % prime
                for i in range(degree)
            ]
            output_row.append(encode_digits(output, prime))
        table.append(output_row)
    if table_sha256(table) != row["model_table_sha256"]:
        raise RuntimeError(f"extension-field table hash drift for {row['problem_id']}")
    return table


def add_assignment(
    assignments: dict[str, str],
    tables: dict[str, list[list[int]]],
    problem_id: str,
    table: list[list[int]],
) -> None:
    digest = table_sha256(table)
    previous = assignments.setdefault(problem_id, digest)
    if previous != digest:
        raise RuntimeError(f"conflicting model assignment for {problem_id}")
    previous_table = tables.setdefault(digest, table)
    if previous_table != table:
        raise RuntimeError(f"table SHA collision for {digest}")


def finite_model_bank(
    cases: dict[str, dict[str, Any]], rows: dict[str, dict[str, Any]]
) -> tuple[dict[str, list[list[int]]], dict[str, tuple[str, ...]], set[str]]:
    payloads = explicit_table_payloads()
    assignments = audited_table_assignments()
    tables: dict[str, list[list[int]]] = {}
    for problem_id, digest in assignments.items():
        table = payloads.get(digest)
        if table is None:
            raise RuntimeError(f"missing audited table payload {digest}")
        add_assignment(assignments, tables, problem_id, table)

    for row in read_jsonl(COUNTERSAT7):
        add_assignment(assignments, tables, str(row["problem_id"]), row["model_table"])
    for path in AFFINE_FILES:
        for row in read_jsonl(path):
            add_assignment(assignments, tables, str(row["problem_id"]), affine_table(row))
    for row in read_jsonl(EXTENSION_MODELS):
        add_assignment(assignments, tables, str(row["problem_id"]), extension_table(row))

    finite_ids = {
        problem_id
        for problem_id, row in rows.items()
        if row["carrier_class"] == "finite_countermodel"
    }
    if len(finite_ids) != 189 or len(assignments) != 188:
        raise RuntimeError("finite assignment accounting drift")
    certified_finite = finite_ids - set(assignments)
    if len(certified_finite) != 1:
        raise RuntimeError(f"expected one structured finite certificate: {certified_finite}")
    if len(tables) != 145:
        raise RuntimeError(f"expected 145 materialized finite tables, got {len(tables)}")

    by_source: dict[str, set[str]] = {}
    for problem_id, digest in assignments.items():
        by_source.setdefault(source_key(cases[problem_id]["source"]), set()).add(digest)
    frozen = {key: tuple(sorted(values)) for key, values in sorted(by_source.items())}
    return dict(sorted(tables.items())), frozen, certified_finite


def d1_assessment(
    cases: dict[str, dict[str, Any]], finite_tables: dict[str, list[list[int]]]
) -> dict[str, Any]:
    namespace = runpy.run_path(str(D1_PROVER))
    d1_hashes: set[str] = set()
    for _stage, table in namespace["_early_model_portfolio"]() + namespace["_late_model_portfolio"]():
        d1_hashes.add(table_sha256([list(row) for row in table]))
    for n, a, b, c in namespace["_RULEBOOK_AFFINE_MODELS"]:
        table = [[(a * left + b * right + c) % n for right in range(n)] for left in range(n)]
        d1_hashes.add(table_sha256(table))
    overlap = sorted(d1_hashes & set(finite_tables))

    config = {
        "result_save_mode": "minimal",
        "search_config": {
            "safety_wall_seconds": 30.0,
            "use_model_portfolio": True,
            "use_affine_portfolio": True,
            "use_f2_3_completion": False,
            "use_bruteforce": False,
            "bruteforce_max_n": 2,
            "bruteforce_random_budget": 0,
            "bruteforce_time_budget": 0.0,
            "use_cheap_families": False,
        },
    }
    hits = []
    for case in cases.values():
        result = namespace["prove"](
            {
                "ordinal": case["r475_ordinal"],
                "id": "formula-only-audit",
                "source_formula": case["source"],
                "target_formula": case["target"],
            },
            config,
        )
        if result["status"] == "REFUTED":
            hits.append(case["r475_ordinal"])
    return {
        "d1_frozen_model_identity_count": len(d1_hashes),
        "exact_materialized_model_identity_overlap_count": len(overlap),
        "exact_materialized_model_identity_overlap_sha256": overlap,
        "d1_static_portfolio_formula_hit_count": len(hits),
        "d1_static_portfolio_formula_hit_r475_ordinals": sorted(hits),
        "dynamic_search_not_run": True,
    }


def render_model_section(
    finite_tables: dict[str, list[list[int]]],
    source_models: dict[str, tuple[str, ...]],
    certified: dict[str, dict[str, str]],
) -> str:
    rendered_tables = pprint.pformat(finite_tables, width=120, sort_dicts=True)
    rendered_sources = pprint.pformat(source_models, width=120, sort_dicts=True)
    rendered_certified = pprint.pformat(certified, width=120, sort_dicts=True)
    return "\n".join(
        (
            "# === BEGIN FROZEN 2026-W31 OFFLINE FALSE MODEL BANK ===",
            f"_OFFLINE_FALSE244_FINITE_TABLES = {rendered_tables}",
            "",
            f"_OFFLINE_FALSE244_SOURCE_MODELS = {rendered_sources}",
            "",
            f"_OFFLINE_FALSE244_CERTIFIED_MODELS = {rendered_certified}",
            "# === END FROZEN 2026-W31 OFFLINE FALSE MODEL BANK ===",
        )
    )


def build() -> dict[str, Any]:
    verify_pins()
    ids = target_ids()
    cases = canonical_cases(ids)
    rows = proof_rows(cases)
    code_bank = frozen_code_bank()
    finite_tables, source_models, certified_finite = finite_model_bank(cases, rows)

    certified_ids = {
        problem_id
        for problem_id, row in rows.items()
        if row["carrier_class"] == "infinite_structure"
    } | certified_finite
    if len(certified_ids) != 56:
        raise RuntimeError("certified model accounting drift")
    certified: dict[str, dict[str, str]] = {}
    for problem_id in sorted(certified_ids):
        row = rows[problem_id]
        key = cases[problem_id]["formula_key"]
        code = code_bank[key]
        code_sha = sha256_bytes(code.encode("utf-8"))
        if code_sha != row["code_sha256"]:
            raise RuntimeError(f"accepted code hash drift for {problem_id}")
        finite = row["carrier_class"] == "finite_countermodel"
        certified[key] = {
            "carrier_class": "finite" if finite else "infinite",
            "model_family": (
                "ZMod5^4 noncommutative core operation"
                if finite
                else str(row["model_family"])
            ),
            "certificate_kind": (
                "judge_v3_accepted_structured_finite_countermodel"
                if finite
                else "judge_v3_accepted_infinite_countermodel"
            ),
            "code_sha256": code_sha,
            "code": code,
        }

    assessment = d1_assessment(cases, finite_tables)
    if assessment["exact_materialized_model_identity_overlap_count"] != 0:
        raise RuntimeError("unexpected d1/new-model identity overlap")
    if assessment["d1_static_portfolio_formula_hit_count"] != 0:
        raise RuntimeError("unexpected d1 static portfolio hit")

    d1_source = D1_PROVER.read_text(encoding="utf-8")
    engine_end_marker = "# === END V97 FALSE ENGINE ==="
    engine_end = d1_source.index(engine_end_marker) + len(engine_end_marker)
    engine = d1_source[:engine_end]
    runtime_source = RUNTIME_SOURCE.read_text(encoding="utf-8")
    model_section = render_model_section(finite_tables, source_models, certified)
    generated = "\n\n".join(
        (
            engine.rstrip(),
            model_section.rstrip(),
            runtime_source.rstrip(),
            "",
        )
    )
    compile(generated, str(OUTPUT), "exec")
    OUTPUT.write_text(generated, encoding="utf-8")

    audit = {
        "schema_version": "false-prover-d2-offline-false244-model-audit-v1",
        "status": "passed",
        "scope": {
            "week": "2026-W31",
            "period": "2026-07-27/2026-08-02",
            "offline_false_problem_count": 244,
            "finite_countermodel_problem_count": 189,
            "finite_frozen_model_identity_count": 146,
            "infinite_structure_problem_count": 55,
            "infinite_frozen_model_identity_count": 45,
        },
        "d1_assessment": assessment,
        "d2_additions": {
            "materialized_finite_table_identity_count": len(finite_tables),
            "materialized_finite_problem_count": 188,
            "structured_finite_certified_problem_count": len(certified_finite),
            "infinite_certified_problem_count": 55,
            "source_formula_index_count": len(source_models),
            "formula_pair_certified_index_count": len(certified),
        },
        "interpretation": {
            "model_membership_identity": "frozen Cayley-table SHA-256; structured models use their frozen accepted certificate identity",
            "d1_static_portfolio_scope": "explicit and affine portfolios only; dynamic search stages were intentionally not run",
            "finite_runtime_validation": "source and target are rechecked against the selected finite table before REFUTED",
            "certified_runtime_validation": "exact normalized formula-pair lookup backed by frozen Judge-v3 accepted FALSE Lean code",
        },
        "anchors": {
            "d1_prover_sha256": D1_PROVER_SHA256,
            "d3_proof_manifest_sha256": D3_PROOF_MANIFEST_SHA256,
            "offline_false_id_vector_sha256": EXPECTED_OFFLINE_ID_SHA256,
        },
    }
    MODEL_AUDIT.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    output_bytes = generated.encode("utf-8")
    manifest = {
        "schema_version": "false-prover-build-v2",
        "name": "false-prover-d2",
        "status": "draft",
        "architecture": {
            "base": "false-prover-d1",
            "single_file_runtime": True,
            "standard_library_only": True,
            "formula_only_input": True,
            "equation_id_used_by_prove": False,
            "finite_models_fail_closed_revalidated": True,
            "d1_fallback_retained": True,
        },
        "model_bank": {
            "offline_false_problem_count": 244,
            "finite_problem_count": 189,
            "finite_frozen_identity_count": 146,
            "materialized_table_identity_count": len(finite_tables),
            "materialized_table_problem_count": 188,
            "structured_finite_certified_problem_count": 1,
            "infinite_problem_count": 55,
            "infinite_frozen_identity_count": 45,
            "d1_exact_identity_overlap_count": 0,
            "d1_static_portfolio_hit_count": 0,
        },
        "source": {
            "d1_prover_path": str(D1_PROVER.relative_to(REPO_ROOT)),
            "d1_prover_sha256": D1_PROVER_SHA256,
            "d3_proof_manifest_path": str(D3_PROOF_MANIFEST.relative_to(REPO_ROOT)),
            "d3_proof_manifest_sha256": D3_PROOF_MANIFEST_SHA256,
            "pinned_inputs": PINNED_INPUTS,
        },
        "runtime": {
            "path": str(RUNTIME_SOURCE.relative_to(REPO_ROOT)),
            "sha256": sha256_bytes(runtime_source.encode("utf-8")),
        },
        "audit": {
            "path": str(MODEL_AUDIT.relative_to(REPO_ROOT)),
            "sha256": sha256_path(MODEL_AUDIT),
        },
        "output": {
            "path": str(OUTPUT.relative_to(REPO_ROOT)),
            "bytes": len(output_bytes),
            "sha256": sha256_bytes(output_bytes),
        },
        "run_prover_compatibility": {
            "prove_entrypoint": True,
            "transport_with_judge_v3_off": True,
            "required_false_judge_supported_by_current_worker": False,
            "reason": "current required-Judge worker maps raw SOLVED only to verdict=true; d2 returns REFUTED with judge_verdict=false",
        },
    }
    MANIFEST.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return manifest


if __name__ == "__main__":
    print(json.dumps(build(), ensure_ascii=False, indent=2, sort_keys=True))
