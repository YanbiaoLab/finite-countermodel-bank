# False Solver d4

d4 以 d2 为基础，保留完整的 9,852 张 False-9852 有限反例模型（countermodel）
乘法表，但删除 d3 的模型 SHA256 向量、62,576 条公式索引和 5,105,642 条
source→候选模型关联。d2、d3 文件保持不变。

## 结构

d4 的新增运行时数据只有：

- 9,852 张精确去重的有限乘法表；
- 9,450 张来自 selected-primary，402 张来自 registered；
- 乘法表原始二进制为 352,146 字节；
- 内部 LZMA2 EXTREME-9 数据为 83,360 字节；
- Base85 表载荷为 104,200 字节。

模型 SHA256 不再存储；只有在命中反例时，才从真实乘法表现场计算并写入结果。

## 运行时

d4 不读取 Equation ID，也不要求 source 属于冻结的 62,576 条公式。运行顺序是：

1. 尝试 d2 的 False-244 模型和冻结证书；
2. 顺序扫描 9,852 张 False-9852 乘法表；
3. 对每张表重新穷举验证 source 恒真、target 不恒真；
4. 未命中时回退到 d1。

删除倒排索引后，文件更小、结构更直接，但未命中或较晚命中的题可能比 d3 慢。

## 文件大小

| 文件 | 字节数 |
|---|---:|
| `solver.py` | 3,049,000 |
| `compressed_solver.py` | 231,551 |

`compressed_solver.py` 使用外层 `LZMA2 EXTREME-9 → Base85 → Python 自解包启动器`：
LZMA 数据 184,636 字节，Base85 载荷 230,795 字节，启动器 756 字节。

## 构建和验证

```bash
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d4/build_solver.py
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d4/validate_solver.py
```

验证包括确定性双重构建、9,852 张乘法表逐张 SHA256 复核、7 个跨模型段语义样例、
Equation ID 不变性、完整扫描未命中和 `python -I -S` 隔离运行。压缩版另行完成了
无损往返、内存编译以及与原始 d4 的隔离运行结果一致性检查。

## `run-prover` 边界

当前可信 Judge 编排只把原始 `SOLVED` 当作 True，并以 `verdict=true` 校验。d4
继续返回 `REFUTED` 和 `judge_verdict=false`；在 `run-prover` 增加 False verdict
编排前，本地验证不能称为新的远端 Judge 评测。
