#!/usr/bin/env python3
"""Build d4 from d2 plus only the 9,852 frozen finite-model tables."""

from __future__ import annotations

import ast
import base64
import hashlib
import json
import lzma
from pathlib import Path
import runpy
import sys
import zlib


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
D2_PROVER = HERE.parent / "d2/solver.py"
D3_PROVER = HERE.parent / "d3/solver.py"
RUNTIME_SOURCE = HERE / "runtime.py"
OUTPUT = HERE / "solver.py"
MANIFEST = HERE / "manifest.json"

D2_PROVER_SHA256 = "f044c640a31106f3cfea4840c9024230eb4b26b32d2c54350afef6165c15df12"
D3_PROVER_SHA256 = "cc308b53daeda267c64c527f33990969b0a9d0d8dedffc0e10d747508869c033"
TABLE_RAW_BYTES = 352_146
TABLE_RAW_SHA256 = "a1135cff6df0d55f714401ae90b9cba2e385c33ce2e3c31ae623130e0124cda8"
HASH_RAW_BYTES = 315_264
HASH_RAW_SHA256 = "f95383970f2c22717075d9293e798ebaa9b873c4c509454433ab06e8c6639bf5"
IDENTITY_VECTOR_SHA256 = "0e39adb599a9c7162bede403a32ae3901c5b87f6c33d1a5d2108a5a2a4cc32f4"
MODEL_COUNT = 9_852
PRIMARY_MODEL_COUNT = 9_450
REGISTERED_MODEL_COUNT = 402
LZMA_PRESET = 9 | lzma.PRESET_EXTREME


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def extract_ascii_constant(path: Path, name: str) -> bytes:
    chunks: list[str] = []
    active = False
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if not active:
                if line.startswith(f"{name} = ("):
                    active = True
                continue
            if line.strip() == ")":
                break
            value = ast.literal_eval(line.strip())
            if not isinstance(value, str):
                raise RuntimeError(f"non-string chunk in {name}")
            chunks.append(value)
    if not active:
        raise RuntimeError(f"missing frozen constant {name}")
    return "".join(chunks).encode("ascii")


def iter_tables(raw: bytes):
    position = 0
    for model_index in range(MODEL_COUNT):
        if position >= len(raw):
            raise RuntimeError("frozen table payload ended early")
        n = raw[position]
        end = position + 1 + n * n
        if n == 0 or end > len(raw):
            raise RuntimeError("invalid frozen table payload")
        flat = raw[position + 1 : end]
        if any(value >= n for value in flat):
            raise RuntimeError("frozen table entry outside carrier")
        table = [list(flat[row * n : (row + 1) * n]) for row in range(n)]
        yield model_index, table
        position = end
    if position != len(raw):
        raise RuntimeError("frozen table payload has trailing bytes")


def table_sha256(table: list[list[int]]) -> str:
    canonical = json.dumps(
        table, ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    return sha256_bytes(canonical)


def load_and_verify_tables() -> tuple[bytes, list[str]]:
    table_b64 = extract_ascii_constant(D3_PROVER, "_FALSE9852_TABLES_ZLIB_B64")
    hash_b64 = extract_ascii_constant(D3_PROVER, "_FALSE9852_HASHES_B64")
    raw = zlib.decompress(base64.b64decode(table_b64))
    expected_hashes = base64.b64decode(hash_b64)
    if (len(raw), sha256_bytes(raw)) != (TABLE_RAW_BYTES, TABLE_RAW_SHA256):
        raise RuntimeError("False-9852 table payload drift")
    if (len(expected_hashes), sha256_bytes(expected_hashes)) != (
        HASH_RAW_BYTES,
        HASH_RAW_SHA256,
    ):
        raise RuntimeError("False-9852 build-time identity vector drift")

    identities: list[str] = []
    for model_index, table in iter_tables(raw):
        actual = table_sha256(table)
        expected = expected_hashes[model_index * 32 : (model_index + 1) * 32].hex()
        if actual != expected:
            raise RuntimeError(f"model identity drift at index {model_index}")
        identities.append(actual)
    vector = sha256_bytes(
        "".join(f"{identity}\n" for identity in identities).encode("ascii")
    )
    if vector != IDENTITY_VECTOR_SHA256:
        raise RuntimeError("False-9852 ordered identity-vector drift")
    return raw, identities


def render_b85_constant(name: str, payload: bytes) -> str:
    encoded = base64.b85encode(payload).decode("ascii")
    rows = [
        f"    {encoded[index:index + 100]!r}"
        for index in range(0, len(encoded), 100)
    ]
    return f"{name} = (\n" + "\n".join(rows) + "\n)"


def strip_d2_main(source: str) -> str:
    marker = '\nif __name__ == "__main__":\n    _main()\n'
    normalized = source.rstrip() + "\n"
    if not normalized.endswith(marker):
        raise RuntimeError("d2 main-guard shape drift")
    return normalized[: -len(marker)].rstrip()


def verify_inputs() -> None:
    for path, expected in (
        (D2_PROVER, D2_PROVER_SHA256),
        (D3_PROVER, D3_PROVER_SHA256),
    ):
        actual = sha256_path(path)
        if actual != expected:
            raise RuntimeError(
                f"frozen input drift: {path}: expected {expected}, got {actual}"
            )


def build() -> dict:
    verify_inputs()
    raw_tables, identities = load_and_verify_tables()
    table_xz = lzma.compress(
        raw_tables,
        format=lzma.FORMAT_XZ,
        check=lzma.CHECK_CRC64,
        preset=LZMA_PRESET,
    )
    if lzma.decompress(table_xz) != raw_tables:
        raise RuntimeError("internal table compression round-trip failed")

    d2_namespace = runpy.run_path(str(D2_PROVER), run_name="_audit_false_solver_d2")
    d2_hashes = set(d2_namespace["_OFFLINE_FALSE244_FINITE_TABLES"])
    overlap = d2_hashes & set(identities)
    if len(d2_hashes) != 145 or len(overlap) != 51:
        raise RuntimeError(
            f"d2/False-9852 overlap drift: d2={len(d2_hashes)}, overlap={len(overlap)}"
        )

    d2_source = strip_d2_main(D2_PROVER.read_text(encoding="utf-8"))
    runtime_source = RUNTIME_SOURCE.read_text(encoding="utf-8").rstrip()
    model_section = "\n\n".join(
        (
            "# === BEGIN TABLES-ONLY FALSE-9852 MODEL LIBRARY ===",
            f"_FALSE9852_MODEL_COUNT = {MODEL_COUNT}",
            f"_FALSE9852_PRIMARY_MODEL_COUNT = {PRIMARY_MODEL_COUNT}",
            f"_FALSE9852_REGISTERED_MODEL_COUNT = {REGISTERED_MODEL_COUNT}",
            f"_FALSE9852_TABLE_RAW_BYTES = {TABLE_RAW_BYTES}",
            render_b85_constant("_FALSE9852_TABLES_XZ_B85", table_xz),
            "# === END TABLES-ONLY FALSE-9852 MODEL LIBRARY ===",
        )
    )
    generated = "\n\n".join(
        (
            d2_source,
            model_section,
            runtime_source,
            'if __name__ == "__main__":\n    _main()',
            "",
            "",
        )
    )
    compile(generated, str(OUTPUT), "exec")
    OUTPUT.write_text(generated, encoding="utf-8")

    output_bytes = generated.encode("utf-8")
    manifest = {
        "schema_version": "false-prover-build-v4",
        "name": "false-prover-d4",
        "status": "draft",
        "architecture": {
            "base": "false-prover-d2",
            "single_file_runtime": True,
            "standard_library_only": True,
            "formula_only_input": True,
            "equation_id_used_from_case": False,
            "finite_models_fail_closed_revalidated": True,
            "false9852_selection": "full sequential table scan",
            "embedded_model_hash_vector": False,
            "embedded_formula_index": False,
            "embedded_candidate_memberships": False,
        },
        "model_bank": {
            "false9852_unique_table_count": MODEL_COUNT,
            "selected_primary_count": PRIMARY_MODEL_COUNT,
            "registered_unique_count": REGISTERED_MODEL_COUNT,
            "d2_materialized_table_count": len(d2_hashes),
            "d2_false9852_overlap_count": len(overlap),
            "combined_unique_materialized_table_count": len(d2_hashes | set(identities)),
        },
        "payload": {
            "table_raw_bytes": len(raw_tables),
            "table_raw_sha256": sha256_bytes(raw_tables),
            "table_xz_bytes": len(table_xz),
            "table_xz_sha256": sha256_bytes(table_xz),
            "table_base85_bytes": len(base64.b85encode(table_xz)),
        },
        "source": {
            "d2_prover_sha256": D2_PROVER_SHA256,
            "d3_prover_sha256": D3_PROVER_SHA256,
            "false9852_identity_vector_sha256_build_time_only": IDENTITY_VECTOR_SHA256,
        },
        "runtime": {
            "path": str(RUNTIME_SOURCE),
            "sha256": sha256_bytes(RUNTIME_SOURCE.read_bytes()),
        },
        "output": {
            "path": str(OUTPUT),
            "bytes": len(output_bytes),
            "sha256": sha256_bytes(output_bytes),
        },
    }
    MANIFEST.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return manifest


if __name__ == "__main__":
    print(json.dumps(build(), ensure_ascii=False, indent=2, sort_keys=True))
