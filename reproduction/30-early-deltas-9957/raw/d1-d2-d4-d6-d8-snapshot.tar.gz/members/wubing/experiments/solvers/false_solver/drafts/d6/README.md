# False Solver d6

d6 基于 d5 的纯有限模型库和顺序扫描，只重写 False 有限模型证书生成器。运行文件不包含模型 SHA256 向量、公式索引、候选模型关联或 Equation ID bitset。

## 统一模型库

构建时继续物化并精确去重三组静态模型：

| 来源 | 原始数量 | 与其他库重叠 |
|---|---:|---:|
| d1 静态模型 | 66 | 与 False-9852 重叠 55 |
| d2 物化有限表 | 145 | 与 False-9852 重叠 51 |
| False-9852 | 9,852 | — |

d1 与 d2 交集为 0，三库交集为 0，最终仍为 **9,957 张不同乘法表**。运行时对每个输入顺序扫描，并重新验证 source 在模型中恒真、target 在模型中不恒真。

## d6 证书生成器

d5 在阶数大于 10 时仍调用 `MemoFinOp.finOpTable`，其中 `10` 会被逐字符解释成 `1, 0`。d6 不使用 Judge 当前不允许的 `ZMod`，也不生成 `native_decide`：

- 标量仿射：载体为 `Fin n`，运算为 `a*x + b*y + c`；源码恒等式使用 `Fin.ext`、化简和 `omega`，反例点直接归约成两个不同的 `Fin n` 常量。
- 零常数向量仿射：载体为有限个 `Fin p` 的乘积，矩阵系数使用自然数重复加法；生成器只为源码正规化实际出现的系数生成整数倍引理，再用 `abel_nf` 验证。没有完整乘法表，也没有题目索引。
- 剩余不规则表：使用单字符 Base36 载荷、历史已被 Judge 接受的 `MemoFinOp.base36TableV2` 和 `decideFin!`。不展开大型 `match`。

曾验证过 `ByteArray`/`String.get?` 直接字节索引方案，但代表题性能反而接近或超过 300 秒，因此最终保留实测更稳定的 Base36 解码器。

对 d5 的 81 个 Judge 拒绝项，最终证书分布为：

| 证书类型 | 题数 |
|---|---:|
| `fin_scalar_affine_symbolic` | 65 |
| `fin_vector_affine_symbolic` | 9 |
| `base36_compact_table_decideFin` | 7 |

81 份证书全部成功生成，最大证书为 **3,521 字节**，远低于 20 KB 限制。

## 正式评测

最终 `solver.py` 通过远程 `run-solver` 做了完整刷新评测：

- run ID：`false-solver-d6-rejected81-run-solver-v3`
- 结果：**81A / 0R / 0E**，全部 verdict 为 False
- Judge：81 次调用、81 次实际执行、0 次缓存命中、0 次错误
- LLM：0 次调用
- 配置：64 workers、每 shard 1 题、Judge cache mode `refresh`、Lean timeout 300 秒
- solver SHA256：`8523c05a2ffa81a87ee3cf0615d3df5b122a261de8991c7c2a2e720ec27c8c9f`
- 输入 SHA256：`a5a8c69e980e26ef4ab63ee7c471711ec809c55644d5bcb4e1d11e14676fbe23`

评测产物位于 `members/wubing/artifacts/runs/false_solver/false-solver-d6-rejected81-run-solver-v3/`。

## 文件大小

| 文件 | 字节数 | SHA256 |
|---|---:|---|
| `formula_solver.py` | 137,970 | `486fc2fc95131b99853b24867257261ffef5bc98dfbd87afab46b89922350360` |
| `solver.py` | 138,673 | `8523c05a2ffa81a87ee3cf0615d3df5b122a261de8991c7c2a2e720ec27c8c9f` |
| `compressed_formula_solver.py` | 114,984 | `873a7d380345083a7c1ccec50bac89df2ccbbe35c2100cd91186e50539fb0e27` |

统一模型表原始二进制为 367,581 字节；内部 LZMA2 EXTREME-9 数据为 81,788 字节，Base85 表载荷为 102,235 字节。外层压缩文件的 LZMA 数据为 91,384 字节，Base85 载荷为 114,230 字节，启动器为 754 字节。

## 构建与验证

```bash
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d6/build_formula_solver.py
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d6/build_solver.py
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d6/validate_formula_solver.py
```

`solver.py` 是单文件 Stage 2 Solo 适配器；正式评测使用 `run-solver`。`formula_solver.py` 用于内部构建、回归和压缩大小观察。
