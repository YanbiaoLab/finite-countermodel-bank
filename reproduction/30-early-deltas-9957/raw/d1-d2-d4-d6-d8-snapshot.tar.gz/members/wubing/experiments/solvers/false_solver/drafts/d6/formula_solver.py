#!/usr/bin/env python3
"""Minimal formula-only finite-model False solver runtime."""

from __future__ import annotations

import base64
import hashlib
from itertools import product
import json
import lzma
import re
import signal
import sys
import time


_MODEL_COUNT = 9957
_TABLE_RAW_BYTES = 367581
_TABLES_XZ_B85 = (
    '{Wp48S^xk9=GL@E0stWa8~^|S5YJf5<H!E*{#^h805k9SleYcurgo_*5}L;zu*Z9(wHM3pLM1+@#7MtRp*Eg7$gYn5W~L};GN~f;'
    '3pK6{{C?Gf%@pFY^+fGmdWXN`hZv`(3O1DzD9w>}^LBHfa7zYye}W>Cv2&|%Ja<+~bSk!Mj^+wdHLuYCt^o=yr_K}|QOj|GKW{0i'
    'M8IDJ?=j&HQ1Z3Nd%-xst&MKIzLxcT4kC|PUr8uYWTOR)SwG*Cj0j&(c%pjN=@BhlKj;xVu=n2x_va{|lIt@2rBiRweE4)VBZ^C-'
    '0y|PD7ZiKq7a{>X7aaY7P32!Wq6=-jRn)IpIQgKOPo}k=v9{Jp+=>68A27)-ZgWbD@P~|dVl0OjRu*y!%hX{C(5iBdd-(T|Z7qIO'
    '?5pC22_e6vH<P~$yh0dVy93aldeof2#kKlWj%40h+?_7Gu!)Gr)MXzA#j{p0L<)iPRHG@&_zzAmGj*g&6q?5lUfz##t3&z)DuwPa'
    '4@rSNU$zRfMrWELOcV^<4EJDMaZJ9EW9zv6>1FM-I=6Z=HH~Sr&>ImLEmTXfX7v}ga=oM#RLilpvybecM2T8RMP{E853hsq#D4sk'
    'IbQ>s>Q@C=qe<Vzswl)XIPWKMSBpJI6$o{thg~P;*h1+ug-^07#~jSnK*yL0g`F|8dfZ$^Ws<T9!WAjFL@HSnG!!pH@-moldiNJ1'
    'Z$r%ggA3b&liQ=^g+B=KC=^!iCQO|Wbd8R9U8!zaAdDKhPrb(bZg{k|=EdpwXN1FO#)grn90*TA5OL}akvU7oT2>v~p{;yvJej#N'
    'zLp*5n#q^2`3BQyxzs{EW$hNL&TiJazaL8?YJT7->O!rZA0!@~UJ**xxP_NeeJ4Pyi006avU%zz2XDP2G6@lhCdOHEFnG&Q(zf!j'
    'l`v6a(R*znvIPN9LZ01xeX)da_>0d#V^1+C;ec6qVj8Xp-R{OVYR~AW$3<JN5T`A2f}tNKj}P3VU}!qxh37+vtgguh{Pw;g#-U}C'
    'GA0b^tl0OD9G|a4lG-wBSmkgf9nV+ZA3m}|EF+^Csg~Y3>AICLS@1{S4mYRl$Q)r??~=qX#!fO{mXv|_U;;1vvf7}Mg^mBqA<Y)L'
    '%d#x>0+Es+t^lrW4uoazWY9Wb6xbVXseHxdmGN`4Lt{?qg)DbO`R%fN5n+-S&rZ@Z)LRAqt-<%b$cOESiP#tOYIw!g>Dy1eUFmsp'
    'RDh^c`;Xh;N*LNGAsL1JVy#Ow4M++DcvxveQlcGG$>`(Z-FkP;ih;RpG;qFHTsWp7vxM=L!#{hSo>gejA!%gPloiES#rf1r`fhOZ'
    '6^9)X2{Ync#E(@*5w>FNjWjB{d4`d9iJh}yA_vk~d{t$L9X*J#;j0Hm9SDsocu$Lp=h+|K(6z2qq(*%vnD8<GHqW|@uPW*V4ti3A'
    'd`vJ{3LU`3;r{h)jz_VzMX-Cyv4t+2acS;X%waiCS*6|$r@Wq6=ji0hy}3M`q4taAn&ft}JGx!h7IrBLvMrs#UH>c=dh(a-9(&$6'
    'uO@Qq!_lcN`5P*BPoV+i#pCZCu%5bN5kj9xx;e1l0CJ1Cth(pEZ?n)fOkvhr<LIPK(XJ4SiEU{i#l<;6-IB@+p_Clk{l>$p*L#GV'
    '=CaKNx#Qt+bcs4SkM+B+$){LsQLju@75%H(LhlrCI$&%OFFYZ+T88y}&m~fEr_D~yigRt*v;`esoJuSJa7p+jMj$+wuLismR@5LV'
    '9uzMtn>Y`GVv7);esi0=)dxXWoLmgbZ{GrNvm5ab+g_pdNRkcWR8$4_#y;dpb_R+UPu6mTVL}X%OMi(TABtpWrx4U)`*7WV4}qJA'
    '4qy{R3<X{uT)VE(;sx)5{io0LR19&(m7;h5_X45|%$bQ(9Z&z~Y})vOAbvss;vC)Wi{8v@#GFb^=a>H3_(^9lc{}R3MQWK{LnsUU'
    'Fq-Fgm{;3T$2x^26?;r)F23fnn|3y)3{Gog_-GOgPz`V0xEliMYpmc*>O`Tf`uim{!gq3sUB}`RLbIsEVmk5qJ!UgsWRe~bb@!sa'
    '{`E;qtE7&$l_7QSQN{pLOUiXi@TMMz-xZLa(LL|m(@GqDKZXBfRhhak;00BtxkLVU*ZT-PO72kYyX!xYk(A^ABrKNbQPtO4OPu_k'
    'x?to_ZRvTCbNMvG4D34AOe6Qh;o$ur^aTAWPtn?hF3y`((6^95I#;}Hl^@%}4R}O@X2LnQy+ec8OcLY9$%h|9JCUy0b7_f!QUNOx'
    '$d2q{$@3oO7ck$KCXadBMREb-5QnbW{3mTTLHu}!$`t&9hGm$;qfNsftURJgWnVWG)7nSucohZ^Sdw`svX<dvY7SM}mf(<c&P{8T'
    '@2`9d>LlR!6>$3TP(FxK{p?D)YU+h|cejjsH$kd<!RnJ!FlqVZ{A(h+)9?4iKy&;#9KiThpX=l-`8Q+>d$liXyIV7()W>ki4U%c~'
    '_&?D`hJ6*P=AYQH28EJ-2HibbwOaBqLgGE#CPI1TT=_VjV#oIr+q46WSeR+Ss!z|a>+KUh*cAr3z<vHBpMIRnDIeMEIxHc`YPh;k'
    'Uyf;*?zj-gj|GxbvL~t`l3G)fKC(xHbP?UGk@KX?J3Mxyg-zw^8-2`#1jYKQH6X07x;MaSYxsS2_B>kKHb<)2zLATtR7%|LLs_GB'
    'Yc~~a&_c-RF+c`EfI?vD#J1m~DG&$$K1C$cg$B`xG!vG}k<A~HD!%{p2*#9C<F54%Ex;P1Wnx`CBNF{9w4Ld)9b=Gin_0jZWKQ|H'
    'JxLb(`y61DF_G?+W}iaH%zj=z1zpBYzz4oJsT#wwPaCkK;NW*P0k1|fHhyXChBy$tr<dj0IxJ&JNk!OHE^Xyy<f{)gD(_&>6=_G9'
    '#l)dsD=-3JEfjgz=$KhBBFCF&Ep^TZ*Eclu2}`w?7Y6|D(edgsAm#8r)G@o&+5)UeW2UO)zxztX9CmEt-pE|*4~2nBqs<+Lsb#`{'
    '6^aN~TiV`v2@NDFCWZHBXLbm1r~q2pb0wUb>kXlHrRZs~3{`Yl_Wwy}v{c%gk6YAotyn34-WGM>;*;7BSLfLoILz(6hBoIqrBXhT'
    'L8K4c6HqaK#L9~4B0&&T<vp(f6F`gqaDt3WU1&d-?4D(X<4#ho@my>h+&Gk;ruCgq6q<PzHuyDw`IVR#V=Q^K3*uT0U)g7<3xNSi'
    'xVK7moovMz@je+-^MUkNJLlhuR0!iE9?lo`rXtCnI-Jc>uJiCuScmWl3|-`>8qzJA77Gsq$;u@dEZ88YH^X>nlpS<%Bk?n{0921q'
    'hlFPj6l@lNF-66k_9YYPt&q_P$2%*Z7574>7Jm8^AdH66NlN|WF7)?`NSHi;Vy3ECjZ<c6qfAM4ZEm7D5M>wZ6+tEzG_nU@l9~^T'
    'u#4(*ofnjcNpiA2d`KK+d+%y{O&r=R$^8#hd6j)}h7E*J?vK-~<9FSHTi$xaELXUXpLZK&bx8PJXW3!$ZS_Ud>hYC|AQY!>2ba0)'
    'wB8^HPJGxVy!s`6)#L@aQd=<;gPh2iD*Lg-k5rSV?8jl4`{i!bRJ%~;=c*yvWS)Q#)I#N6qINAw+upq7IM5In*!j(VxF?IQbG9B8'
    ';~1^}(G_8=P7(>obk!&0b)SW@5tW*SH2DB$w!><_JCb6@4KMr!KZ`9(d&>Cnhm@7>?M=U#b?FuI2nXa6eQl2$^3KN^qyk{w6Tj(O'
    'S|O61=fw6gk36biIDgw(u%WlOJn8f|cOiKpsvfad%G$ME>;~76X%zvQN`wJdO4tq~_N*_iZ8#HyH943)>?IgRA8M8mBZ8pLvyDaf'
    '0tlQ8+olG}R8Ywn{b=5byc~_Eg<*@i9jp_6s8uYk)U0!?kI`h2UR``tBLy!VnX1Zobtt0#QM!?lS*}yp-ISr|e+_~=BQ3&f6GnEw'
    'Yy>Q0u*LQqDIqZ=XW4Mb*Xik)AVjt?u@V`~%+m^X$~LjGt!wDH%FS0$hHT7fL;+~kpo-hjOE@8%U7SiGAtC{bKLu_w^VfdIfyzDa'
    'DQj%jz4s1t#wGKTHP|(gGLRi*kz<HHc5VAYG4*5ia&2=@8QTf4^rb3`cZ!#%iqaerd_`d%G<%lcLH93Y%NgPmPOQ?61)map;-;ZJ'
    '$(8qmQ1YhtZKC(=fx5!ys47wIUjiY6qLs}6arXs_^9=@8mU%3{EjX72*%%$H3Nfr?3(CGXo>9mZ%61DGu~?E+ruzT=E&G=)a40Pn'
    'GF%BWx6Mh{(d@OLSyImT%YPG1i(vnW0!%`syE?yNHePz2yYFe!xgPj~4tR+)ezjbYw@zp<>1-$^2=$9HbLOPg!vj9QP_%Iv0z%DR'
    'NFOpzW;oy?>SFDEr-OeIRD|`1+oU@{QM-^D@o3o59!|nH{-qI5wnvV!k#hRN)^kOzNCQ!qL4_umxgkTwpep-YcvxIXEX{A=nW0zZ'
    '(*CaV5WVdW-3A7QJPsfFd<mJz{X0z+`gVS(6t(kY<~6Jd?SST^Rv`q>>0pQ<!)Iw!6^wADHN;lGl#9#EKoBICo;?L#3Wrnc)w-}H'
    '=KC$4KGk_7H|Y?_6l;_jgR^_Ykg?buyf>?4nk|>hscG>G-trQp(Y>Uxz{;6xSL>x5e;4)<K191)U0|YQufIFS@~$0&l=X>;MGftV'
    'X8H@&&O7FF0*4iS6sGal)RzzC|7!P<z;?n0l~YU;o~H#m0fUWM1<2?bBofdH2e;t2ulo!EKTo#oy}xVEavKOItiYsse!G~7I4~wN'
    'mY2M&Qb*9*Q@$$<=w}>qAZIS;8H2bjSm8M=icXu+K&~;5!%kXcOVt`NylX2%uBK#UYVah;%vtK(yrdfmJaS-QV>LzaeFpbbr_CIf'
    'e0vvyVo#+lB?_ny>uL~7io(F~w|s@0hPFaBM*Sl3oPQ$g%Hi=XD#c>*K9{+xH{pQz@uvh$dz5QS*0Z3d^Jp%?oiOHDrF0{Lpw{pi'
    'a1kOKp#R1Df!Fy9{UsAG#w^MJ=E_W#J%{0FST!;1YYS!#4W?D&n#=e&R-UhegGA1~xX#9XC;JWtz`R5;0Gw6G%|GO<5-UE-70Xmd'
    '^tB@a^kyCqFe9|LH)KZ&+L0BRtD`7?ZTZ#S542$vv#!{j(L%E>Hzlq-r^;{mneuSpRp0r!CC}vPKws%$ZP2LgxnuVIJFyg!djpV8'
    'tc<o3dRe?KSne+@z%IU?C`56H<*0SsFiKy40|L!RbePg64s)fBL*8dR8YVHdj^f{}B(t35^>;MFeN2Rkc6f?l4xAUv*LRQPcaIPE'
    'DzDE$pOM-_^hg_;FYDF_DuRW!U=v;EX!GdleXKT$zI+`b@;w@tqJ^P%TWz-g{O6dyX7Z*9lX8}x+$OC<h--HQ{(y6op@6?LcM^ui'
    'RcNtllrjO%fb+w4w|sUN4+ghAd6ui-GXkC1iV(U%SPRa^CXg{`?P}dO_li?C?3jQO-?X(T-C1b)4>a7ZWkte(7gYYfNCQ4y>=ZTo'
    '>?kU8ivLb4J9Vg1^z6lNyMQ_9y-lrmt#S5I@<^zUWRh1S9ng+<s)bc!+MQ4^^xLuDqj>OP?^WiJxm$U6vZWh0A1l!zW=!2_nQU=h'
    'xba~2<du>sSKnp`CjP(49<L*^b3A@_E9itXa^ZQBB3wTLU@@#_3Y!=zfjNJwyT^Hpwy59&Om0ZK2zuW@XgK`Q@i7ZwB>EUc{||UT'
    '_M0Hsh@AUm38Hpkf&EEB40&>EWEWwFb1%Ny0CFyYjl3M2@J@zr!!0yigl=z6a|jY%>L8|aDx}q+7XNltGSDcySaJ<oHgJnH1^4@i'
    'D)P@(z^C<{M~25ig#IVQSe)I|IxKEJ&13@;=Ml{8m^QLHj&3(YllJP=P?=Aex9&B82k+fWZmHIjkh9xo`9Ijq<iO^~E%||Fb~qUS'
    'Y~Y;HM54rxXyS}#%B%btV@6VbIKwy0M!A&<a$qP_sK^|zv6d8n;X|<wEKu(dvc4%zM7llW2`HWFZ4P^c%beiwz>+5nb<N~LHf_Y_'
    'TC&#hC}X<d|AU-5pMEW`DV?oE$P$owzE(tG5KX_sAw#tp_oc<gok~x$gFLR3T_S0z#CKG#8A1hxhd$(c8llm*)ghGZ6zyfjgg)_W'
    'J1(oh!^Yg~)o--`(m)IVgMR+rb`cn9`1c<c(Z{AIPAN4${SRW_HNl)&V_s}2QqK|8uQp!;O4ul|n+Dbp-DJPgj9AZjPx#t;#lJC?'
    'wKi(Ah5KS_g93u!GlJX*ndjF0BY3oFIeV{s2Z6;4cRwnI(o1J|l_svUJTu8dLfe2JDSv}n_tW{Wg3;%FMvkqZu>#mq(#{E1@I{7D'
    'F5GP-y0j>REkoJ9v#>6xkZO1q>*3CVZ#fqH`h;;R)=vg10O)3#$OK;rVuwiyM13EccE)&kZLn-&Z0EW52v{Z`qVK0)*pQosb}u>h'
    '$by0JoE=uUg3sk;i+jjX(iT3=_XoB!69UoaZL4UuN_jOE6_2`gv_u2U9Oxnl^jU`7^!nC<3K^YpH#j77k!Ki+*Z{Lj>XQWtZV7CW'
    'jLMkuEuDe$p(AP2hqTZX=8#IH?y{ihJzDGrpmCX7XF^Hw5Ox=AkAx!Nek`!s;V2xB2yKpDBdeJL__Rkc=o8ll!Wh!w+6KG}96`vZ'
    'O&oBI+2flUE=kxGl}rdBm3_Z0kiwV1gfg_B@PZ?p+Ewy3fZ9LbL#a`%K%`hyeZaGnAm!AR-E!_OP!lxMe`>@zilBsu@4fZE-_x|)'
    'SISJmate!r0uz3@oxl%oSYTQlke>|Nt_@pCvX6o{$}n<vxLBV!5UEKzz;6!5@M}o=>4Gwpnj<9Fkt3M$Pb3ULABRJ@(S<)|ZYXn-'
    '2T=rY{ib~guJ$DsdP;D=45Ai2IXeemNJ_O+UOn>dHF<Si-v*U-#2=6b$gqi;5$lo|m>&BjBibU+J1DSt!`1AkHR$5s8>oPVMBy<6'
    '_?}yaEDA$hde|UM<Dzt-UqcPK#knlZxCC!@>e6b2%;{5w6#gD~pvc#DT&P`6`p54BPKCE@S<<Cq;w1RF`yGxv5KbitD!-WpPW$<S'
    'YC2E}aL-47uuk##VzPTdp!abes%1`ew(?5Bkam+UH_gS@>8a^50ZeY|g_MrjOFlwVv@vp?{dmViXSktQ4id&>Ri5M^L)k$?OJ_kG'
    '{Yw?dilGa;_KHyn*mS}(Je7fBmj?wauCt<Us*?mTIUuds^nO|y&jGuWG#1Mq8<=-uG=l`v#~%%hh}Dm>rtzQ}!o(c*iy`qDAZ-|r'
    'VSb!}5k&_?VST-zH2+*un-tB(`KS#7DMaNOs*nEPstV-lGn8k+XOl705#47HN^**aX~F&=kHtOG!c?7?+?AIYjgxd|OX11be9Z4!'
    '-eC~qpkUK-eIz-@&q!QDR9CkO4g#<{DBq_Oy+c=Fz6gb?P~yfK7jdo)M*&2Vcv*@xmrS~KZ4H+vB4x$Hb^_43rjZ4+#aD}%{eoPJ'
    'j0QjZq%^(&_#^b7w%9Yr%H>+^nBGu?;F5Eua}&T17TI-j_t+Le5J?V>14%)pJU<`e>|RB5jSdqUeOkTFqI+01=Uh_hh@!PVf7i!J'
    'RL2&O$=NUg?tdbM-i_+fXPk?v1!>{s;<F|Gq|zeArvKBX)r?($M8(`rqBPR?JUl9e&^m;^@&C>tLv>K<kIv^H*#0h{s^|5LcF^h!'
    ';W5HdK`(`u#J?S5(sRSukGFEzQXfn40GQrrOTJZr1K0k_m9Q4j!}=jysqBQp3tpb77ghIM8)=i!XS;O0rGlOf6o1?OVPf*Fui>r-'
    '7F|wEEHdd+l}jE^kg}dhK*qZ;Ljm^qoNGU+%{*nxTY^2c%T>QXq9vC*4GLx&K>D{CHDd$?V!hW@{vNYne|U$pB8(DQ)KxiCy}O7*'
    'BepCkR2EBM2}|?>(^ta_MCv8i47euE0UzYP)QrTQyRl9i67KAE*z2%vY5*W6!E_7@jYxo{cw{gfn>vDN@+MGg7pc}4>KqDrFj9iR'
    'jPKMUE^P?b^;+5qmFGd>!3V2UC;=84!tNKhNNYAcJA0b?K!59CT&K-Sm5cxGmYtda>SuxcN=b2H0hD2Z4NU8kJ`xk*H{CY1OF7Zp'
    'Ax!_DnLc|kl~v?iH5nA4j^;y_6gq}eHDSZ(nX}H>5<Qg%u`IO-IIveAIj@3)icy*_0-c5VSnm;cSG<PZ&zUdxJMi|y+b;#y-kv@3'
    'Ty0%R)^t*>(fH<Y-Mb0R2ze6^FDGl2dASIlv=kA*`Ubs2o6hWA4=7{ll$8?A2FSq+zrg8mSIG}IaU7!8Q&9xfUkn9P_fA!9sc_B9'
    '?;0BOgHztQq@f~SpX0DyAQJ(zWQCT{QB(}<z&G+hX>szV(<60PXh)FzDukh-=Jx{vP{oz4Dm#5z>yzyyQw`j~!&BH1q8e5%O&CX<'
    'q_**V%Wl&P%uxUy)9iNsHyO?2xH8Z^qmw>u)Luwd^vs~4LG9w@D+sO%rLvt=3J|nwr!(7Eh*$^gSY#3EhU3z7C4(j#7;g55{ur*~'
    'ctQM}TeGaXDyP|Y`&$OeNWxCI*N}85RjmU(u!{(uiBdiqw(l`q&ARp>CI$NLg5Hu;XtK5d<*~C^A98}`j@is>jEe!_gkBI5lW-S9'
    'yrGi~7gDao#XN2oLmI5P8~-vHcIs4<QisAl(f=m$S^P`G*4ZplYK0YKLILJehJ&lSZ#4@UwA?saKzdL-haMtcR6E*?Ph-M9`fS3>'
    'IcQ#Ep=@WI0)GZBH$<(zGq}e25Q3~B_W2Um){d{7!cg^KoAJ|*1LuCrAhh)Y9$i0oE1ZQ%PVvnEKrXK5KYW7vR8_B)=s3hbWHwEi'
    'Y4Nj35aG*yKMIj{x+H~fZ2Ewf937{vlJHnsU#2yhnD_}1=~OP9pe8*<9x>x4$uV7N20uL2t?mN0fFYLey(3F)zX;@-qX{>hUnK?9'
    'bc=NHk^5T~`edynHBW+vzEW1a?f_;2nb$U7r9sJ*7%EE0$7wiiP58sDfrGI1X-cix07^T~t_WPA(k8Yrgx`*xL_q2tDmCw^WX;c6'
    'x?f^W@jF@=Mf7D*Lwz?#r~?i(a9k?7RL=r2y=hwDP%b)X?V>CSU)h;E@^I`}^Ovr{%>ctT8c^ig5&ms86J+Ni_e2+zPo;vLcbVDA'
    'macs1UWISK{=#=+va-|pkRt-!KlR##mm4JP%}WyLfQP+D-hcz_LPIwMHrx~Byci$AEKbyocqrrbTCh^?O2@mYEk}I<+9_Wnadl~c'
    '+@~ceIRK@Hr_UqM{r%6!qW>^t%GzBRz17S>9|hD&ghpB2(0ybSe0>V-=xz=##EvHn#N;V#nmX<$si+=hUFzs4su#jY^NeXvw!oFV'
    ';2V9^efR(B2(b>rwp)TucLf~HXO1Gxf9>?=7vMcTQPs*FuHy<^R!v{mhgw>RLFR0{+Im#g8T8(qiw0@8N6(5sLWsP(5S_q>I;Ibt'
    'ET;sm?4jpvGecPV#WHZ__2JniWIuT>{<&jDJWj^6vn8o!q_o)N@-{E;NZ#xs1wC6=q(E_%J|C|~F)hyGg5RxjD6_h4hkUa*b1kla'
    'b+V4ZjDpUDPcv&-{QtC-3J^h-T@oU+uYLuy5eh#aMHkU#eK4GJY5OpIsayUA?l_EFI)f(I`OO_kl5sXOk4lU5`=*SMbW^QMamkCv'
    'V6f`=?WhwH$9MU9?ED(upjpY1&kis_Jxz6<S9Nn&%1uRr2tP8ez8`z;$228<hSY+*OsFTHbuW+oz!@BUg3Sss;h$<UtnL|X@}Z5#'
    '>1^=;nsvz=bO(iC$QqQ5{UJhpjam+hzN841Hc0JTbauC(0kY86{Bo^%g_NLIQs~_?UH@lP6Df+SP8D1#ZGuk1+yRS9h;cVaGcI0A'
    '!yNUfMttG)saS%h5f!3@KmNZ-5wwA3U{@|Pa^3qJ#gH(NI!!4m@R<$b|4%-y-_W*!RVa8=0$_wA(^(`pm1%YClVDE_Dzn_xS<<uu'
    '7#bi$6zEmcUF<UERbZrDaMZBUuCdf^%0=|qe>MD6!X<k2f>9K%%FSvngl&2~HWQ&K$^S)rrq!3itrv6&$(fT#x8zZ2M;@Zpv3SQX'
    'h1H_a;k!YU6uE4bH`@s|FC87&Ij*_wXjzO)sO2M#yiyhbT2$T^Q?exUA8ln(4P7~vz3-3QFutYg_r<lbnc<NTmU|dB6f^u{R@edO'
    'V5j6M^*^ftIb#I1CoxIvu*5f((p1{XyQ<1dFg6$0UVv|Bpq?z7lYGsjW6uRmT>gpn8wH}#Yr6`v9;g{Fl%KN@1&z(&ZT9Lf_20YU'
    'sLUBMHT8;gI4alaPA647e~&tq+<@E87_DfSPW%;zD(WZQt6Zi3CL~R0EEo#N;w+*2VJzp#2Es;b(R>}$rifRuu^-c5$0^>Gt*B2{'
    'PLu;TSC4FUq*zqjcn0F54RvP$N7|TkXs3|r4z%ocCTRPf?pvXT4|&bIWoHbZmZt&f$aGSCWn?sqFW%BB>lPf~&!pH{;dX^XCcEF5'
    'Pc;d_i=f`9dg8gd)>EMdrN2YCv9*X)_yjE2G5PGyO53<ffJk8?-3%8h&fdLl552U4xfrygB4ZaN<UQXdwla@{A#6dUVGkgLa8^k2'
    '4b7j$|7y;N;n<h#?HLy|VdHQzc8TQ|ARQO0*JneRah3?muS<S}ZyZWO=7wM;b9d0PB<dxJh<;l)c%*fiY3^T7MQBadMTi>mKEhiF'
    '3#HnViKkD753kcadwvOgyB_AX|8z>G<%wHDRnDEToK?@#JsJ^zes5INN}QA|(GIN$K}{qotc`0$7b9CiHjJh$@T4D6UZW@vh8KZ='
    '+0KAIjx1Jd62?54xcNwHf$XaGUmsvK`s<_a$?xvQUp>m}yNvc%#np*yu<*MY^_=aXtk5fuA08`!ZTr|b=LiZuOJ~>Y6NqYkSY}@G'
    'f1aWFNq4QDYy0Ym*f$TeN#Qb*e8=6^>W6|GZ3DmY;UooG1jDTUSNTBJBd175zlJG--hIm4imb9`QnI=B^YMArSx$@82Mz|;Jh_#q'
    'q2ILuE~e~(<`WA;<bS4N0k^Wl$I+CbenB=`JHenMcki6`L3&NLL9bG#_%7%XKF<(vTk^6Nq0--9tOkFQy>m2y6$Mn}lXXi_tzQw+'
    'WR9cmgr`rY$-$LGXP=glpQcJ(jy;yQw3!23w-FUj`@Gac#$+HBSFweB!q1<D6w7MaYVaYq_2%xnBJIvI6~{Tu^kJ?Gd}v!#@BI9o'
    'w&f<ou8q9j8?LjhBdu3Xn3~ZH(x%%bG+yhg^@5>YqhXC>64DHTuvWJ$C42mhFlx59vK_3;av7EfSFWP%hUZ^4ft+@Q;U)=u`Z~LM'
    'gH4LuplL-%kM|`8D&ygU%P_FxmoMOF{h{uKjBf`e_X#2b(s;n7K2EHLfMw5PEl!kxQmyf1fAb41z3H%I+qP$>S|k|~RX4-3E50`f'
    'h$2q~kP{_t?KXglJ=zgXA!9wSf9Sy*oh$G*-q>ym9&W<C<EA7`3T8IHivl;dcHMoKzGGYJ3`)A+fzev!<jlpnIgsDeo?9`tw~tH@'
    'alv1Z74(_~w&P1Ysp*veNBGr$GA62eD`7nium@)x@oTen9$3;CMty>uCJZRmVWtF%2uZ6m8(5`0;LG0CdWmRDZxk^i8v8*+SlS*4'
    '%A)*s#KRiM8BdObeFc8L@U$b{mh7;<inpTuZ}m7tIWlTCGNXSFTpV|ok?-%a^FKl<=Frt;oFB|a0}H;x*|nZHU{D057MYMP^}cOS'
    'O3E1>%F)Thtu#ISzdq5PBWqWU*grC-B_5I}k6~Q+x>a=JPs2LcV)pFnX1(T>j$!X<v<Y|1!>n+5RcC^0eJl8mE4t6`R;uJ};PbA_'
    'K>9GBqv0qBkf@vTz@=nIJz-XS9Z&Ow5vt?D_>T&RN0u2fjH*2G^%OR1>Xt?$0@34DMDlZokWG{GPu(fB%l$Gus-arD!TK*9tcuUg'
    'J=C#D;(zoR61FU9Wu7Q~;ok_1N>9;7=@B+{AElMI!q7i+zX0^v2_6u^LqB12UKN352l5tA>J6Me1%?uMk39;>%D})BkefR9^&ZGj'
    'R7QLZdeR?p@DU=aSBt<LYiOMFT@tcV*p8Y&<7FtVMIi~iH<%N^Z8fPRP0C3m2&je6lVnnRi_41s^NbDOJvsENUKmW@y~fBM>VUFg'
    'yZ+Xf-LzA!!V3I^TP4ABhV0by<l4aMMWZpKV>!aaW$-WxxTIskhM6s~foz0KFlPz|x$!4;<U@2;_K)Vc@+bw5{}$ga<wP!ZXj2C4'
    'EZCZ|It8o<XhOutYbIvv@dvV9iyud`EqDi^+@YwK^9(76cj`M6&`vKK&`~8WAVJ~ykW^KuHmFe#Vpr4-t&3&P{JPUheZP=Cns)B7'
    'Y}!XenSDEUwt`}<5HEq$+rxl|4XbAO#vk<RRmeGZt7K#0?o`}ZQC<TPfx$NIZh2N1Qi?8^*5*6I+>JfG&l^Cp<@4+6p(gJTEtTVX'
    'j7}}*ms7La8xv+iTQtF9EVdy4{XqPV)v185wO#+8m^81RR+iAwV1DwjZXa|A-)u5@@*FcRAiGQ_vN3nf<dM_8yi}R2PZ~O|Zm2Wh'
    'irL8G#?RoeP8*^f#O7NNl&;u5Tw;m1v3<HiKh6f8Jh2?ip4|9m)KWc0Mh2S65B)4)t(O460)^+9Jw3Tk{wRn6fuKr7x+tRx0*`1C'
    '!zhLf3ud<APNelFoZ^eRU@JA<Tt<lYzP>k8L1HNAj!MqMZae-id}C>1Z+s~WXb@oxX6iEHu{5OO_Ui&s1X~CrZRPpe%`6pmFYCMA'
    'gL}wD<@dW=(at3aOzT@GH7Z-o4bWw~Q>%B8aS34(NF@@b6H@j0l7|KWKMoRpO(Hi%xc$4W6J>#q_uB$C;wLB_Z$ALeSApF<w#p?v'
    '>&KbS9nMYHX<JF8Mh2@h5NfVmX`5_%ZQR07N%Z%oCEP8gKqCrP`|7hZYoip-GhwCzGK*8OC`%t$GwG9A-LjFBRCPw^7u@Ej%?Qb('
    '&7%L&>ZshV&Myk7Pd9K_4TMCgH({ub+%14SC>%h5XW8szkk5pRyJr9th;sh|Y2Uy`gJHi5ULa?%J>8tA!gK#PX7C4^n3=%sK;$Jb'
    'mz9Sjf=5x^>l%jtNY^Vo3ePM~5$OI6K^ccbVBVL0+X1$>{QhYz&+ocqvwcbLhQxzo^p${7)YC=S7XJV1n7CreBk}|s0H^cCMsB7g'
    '@~%=k9>fLpi0f)5r(vx`a~g@1i9A=8Or7KVnsihy{nK}9FLDX>oQi(455!-JN?8GHCiCH#!?;!Vn|N65uIVP*;DYILMg_bwK;QLy'
    '6hs8{pOHe_(9wm9zK{rX)?Dgg*=O&IZ$Gs<5;TtTSdd{R3l-IOX(j;;lCbDr+F}q?yK(H$EV)Ye0}`B?!E5g)sl-8|sTmbW)MxQE'
    'VLA@tonFJh+z2UDI7HnVx5S#As9G6Va>As!2T_!lENkP$T3N<WWd6oQ!lmWhwhj?w6Sl{1Y(5qf%Ci~x2*#ce>4*}uCAzS9ZtG)2'
    'oF2K+)MEkfFkBRi{h_flst>?eMK4;sAvo3g|B&q2%$z(R1eiyhTu^8?t9~1-4$ig1W}V=)n2NVhWiQYhUwv!=pI1@RZ;y1SprsjI'
    'Up~*%=tcb9?XC0G8mZU#KZ|KzZ(}152_9gfOV*$b8lx9*YtiPe5h0pp@*s7gLJIRc(65suJve@Rd=b9TIu^xl_CBc&EHv$_rbd0}'
    'bN424hwlQ#Zg5$7WlTD$M6X<w@7hJ;kOHXovy@QIGbit-&k+2I!Y&!T?+6)J5q4~F`IO!E6bKT_0hSLjB*=AfmDVNVeh<sZ*@<jl'
    'MLbey2%F$f?fmfG6*S#Qtc({aWGd#;<#wWgIH%#a)wwcbo}>-8v`ospetN8d3*{558mNfvdHzrbMSh?cGfB!Yc(I;Ldp<@U6cbJ&'
    'Hy>LKZ^g+Jb1~{VwEwUQAh_i~6k&@%-8V~c_)hUr>wdl1lS8b~GD%BU*z}8~=-+B*RI*Mq(gL~c3ywTnh+LZy6gB_giLKcsVO36o'
    'wP$jV)=RHOfrYZqavbxm!P?jn9Z@xUCW$_E3-{naosNpdzM&V1()aVT!VzY331Ds8BGD0=UBXKu5J?>uKkLiw-9O%TDk3-CdK&k='
    '%{GMEhSUV@g_Bz3i`|Pt_kOq%lgc`mmgggLeA@(a$aS>CFJAzJ$9Ji%)Pr%}yfYVsLtw^J#C4(^=kS;`AwfjWqwDovhk}mX5GYjQ'
    'AatjF!B)dCy^j{u<Ah|EsmMyT=)=(bu!ZI2vtn*_B%zr4fDQ52Vrxc;xN6goH)dk87^;TWgE!ks9e~~?mZH&Nrsp+#<K?POv$h*g'
    'F04VK^wRE4B8u*NnN2I6++W)}7(^?XoqexhSR`Hap`CWr9_ODb{q_4e9i;uxdyW-T(|v2VvYu3uyK`bSfz7zRV8dP!K`${*6I)zx'
    '>{Pli@Cs)0PTK;o1Q8pXUYGL_d|+&RP6w*V+h9&5{)^-`>{y}ZBb47-=%2{bhe0juH`AWJj@Bm}Yh-O4zt)>jxQ(BOOI#S~h9@zV'
    'Otj2)Ev3JovaHi#6mUdl)Q}NxV$-f}#IW5|11XCbm~bRg(dVko(S;4x18cg$IOK(_D*aW9$mSO_5GNetiRX0*N!Z|u?}Pe+l4_}f'
    '?l{7!;8~kW=Xz_b_AT#&CIYxQZrs7c0kzd0MF>%6ah47?jVImt7}Y&Udr_D-nTI+Wx)4I`EZxK#r+r`E@|1Ij=2S!R)xd#g;U2t6'
    'nM(^JqlO5z>H^;EE(=nEAt9luPx92BC~;t*uprF(2l!`Bgbxh}$zgvpVR3yNUUNN;=g2+6GS=o(zH+FH#W6xUiJX_gMNW2aC_B&{'
    '4+#6e(on#(w*!eO{1V*bO7GD<qXrCzvJ-;Hez*WP`z2bHNDO(UR5&0f^VukjLRj-!Cjc#G3p}ZMbrc`Ofo^~AB1un8K;vt5uX&=8'
    'r<dK@;e3haRoEMzq@?ANJu9Ki3DiYU;8?D{T_Tn<fWkCEQ5bAa^0Iz^D}f%aY)h7$yGx9HPD-T%M#f!A>_l@c1j}<bNoAn3z3d>I'
    'VVA}6K(l&Sj?&kExx%e)%YR9t6+^COIb<o_&PZQiNQW08XsotBK91A#CbWJ#2BiVPP_3J&^z$b{I>Z7^95HhqK}q!S>?yE#g|8qU'
    '37SjEj4REr@w_{&h@f@~)!ajLVTM>s(1v+aXaP1UOt&dS%$nFuK-!BjO=A`+Chy$#dszQf>8dXm4EhOm#dy*jq0ff1B57_So6}AN'
    'g|mhg!8!VO2<nZmm|#wO>M+_E08$-g$*amqu)Ifm7Z-yv(@n-5mP)%zaAVI5t{WmIC=24h{jqBW5##^tQ@9X$UpDUEL4W(#YIf!;'
    '1B^qAU09-QN)bI(Cu@W%lgZOKOit7vQh5M*kI?xD(C^#L7b3t0ki)XrcvMN$k{xdK$WR`=%ZhiQQyChW>`z3m%_A=+`BmNV&?~=5'
    '<XWP2St}E(zN69bnJQ$vK{T{hbvx-7DiU6!WUSK^(lLS5v5tCy(gbRmY(reGKeGu<d6G-%1(!+T{MutTW}!Sd0@2V>#KWph+aBGX'
    'Z74b^pl{3Ocd?l5tO#zhXGNl)n^lYYttjP84Cl_sNA`O22_S7s9lmp77v*K3Xd)atlTo9Qi(|RyZ9{#O2)1HT4r(AwkBoiB48-0<'
    'o=Sj-cJA6+M8u{=9ABv>eM@FB0uM`foHW#6C8v7+QGkZxID)5v{QmpfdaV5U_~~#Mtdg%#p8OWh8Ox2otyiwkGB^90Mvz3m-%~Dj'
    'iL(Z4l{8X(KhBs+;>?#XeA{)E8?>+{oELkZr#T8=CNwleu?_w&vsqS&#Pl~NBhe(VjYD$ZGw^!?a$o@#=ABoT!A+}~vo_kaT|h>M'
    '4)m1Gmj|P21gR4)>rC@60pS>Ga2B*K{J5p#DO`7>rztlf3$f<NNep`9lhm1K!XD1YJMTUn!%GS5wV!5Ax!HRsGK<yI9D|Q_6!83+'
    '2o)RghvIE6%p&qUQ$udLKuz6h(NW(9Wx*TFou&n&X!5`{KTcfYTU_g+(fPy=*jJ%^nSORD?8yJ0lA}xe<GVi$GGO<$ITr}Snm`mw'
    'tx+(sA$mLJ_A!~Q;@Cms1E<{f-`0Od**v@KhH1`-+_vIq)BTu-?I6Fac4RkY`To#FmFLq|nz<=sG0}C7l+z*SK&LbHabw3-e@#Az'
    '6%y}Gb<^Hy=)`Qy#jVqy5_>6<Oi9piyqj#5t78(LOJj`}*a>KC^wRQa8hb8?BO|YOj0xXZ%t)0NLyux<vr{f(B`%ZE^v`xgD|OBg'
    'A|&~-W|a1X;(#{u3(vV*h-o@%w)+XqRe^|gbFdTNbS4+7^d^pqImSKnuq=<Ff4pZ85t#KHz@#_ay*0pDahVwI<EB}@gG<McRtkv@'
    'uv39W_{RRoE5_GC{Rd8vnL^jO&pN08ajQ|3?@dgyG5VsTJ}C~BMxT(@IFSPC&Ds~1Z4(1@!{>Z$QvR9PTC4f}YwpJxlp=_%jCMU='
    'ygp)n!<rhdOcX1$i0W?o+SJo?v7So&RFS~@2zsqpdzHS2a@n-+*ET9bB++?HUQRBt?eIrey4+GjFl>cxUO`i_dH^sUg*PQ==U>Dm'
    'ZH-Cht9}3A(x;t#Do{`69o=9GjAG#AWhY(Oo>{Fr34KTFH}&iJ2Wk|)X1d7Vj)KZ|*`T29Sf9aR|L5ya-J8EL)B#~!*wHtD(Hq4-'
    '^&ikt4``VloCOSvdcAW69XZ|j2ofHmDv$ru=}geP?Qobvfaz#Cm<z2}M;LfY!*Jqnq!1Do8pQX&)!dW|j<{4rSBPV!-S}l$0{Bm<'
    'c=62JNw;Ka&89>u<K616z18GX0LSztxUsh_tMv6liKz!t@np4Y@-q2$ot}7N2w^&eVPG#~Ye@(lIYVFyv^k(zVDX*-PMno!`H53g'
    'mo4#uE(LnEjX(%tl&rkq3-&u0qQHg#F#5+lX>SAPewUxkc2V?MJPLX(Gc6%72KZt?@9vU8SW|SlVQVzzk}VFgNvU4qNSRo~JpaP2'
    'RFB`UMdw*mr@Q!d0a5+;%AzCLFq+glL8CE;KN<Fgm>0r?3KA@^Vb7$dNWGtxI0yAA#kKS}uR1;km=L&%b=smhcH=bltF8r3aXum{'
    'mwQ=Xu?*elC#gpN^ZkpoAV2}-Q+)|o#^ZK|E#h<H(6gPA0ck$rOHA>oz0wr`))@jQeo<Rm{Z!O6Hof69+GGh3X0xp^8=h<D`*tkQ'
    '(FX70cOMt2daq+%n{wgtypP*u3?1ITLmId)c%}=WV6Vfz$)vsylZ|IavF!I;oGIdKEfprlfakfuM`)5$P~*+<{+Q8%Zg<KPs;T`^'
    'Mjt(_F^v8${HerAWDsbM%pedchU6;Mf4aZZnDY)Z#%j-Q-w$5&cI+mq_x69uk+eVvMo$wWdVUT&8|aZkRsPEz2rDl+A|M6;tfSE|'
    'g<4{=J4v|@Ba1kfLl7~sDt6}JO=fcVK&|VAMLABB{?ig9{Gg`4NH~o+9n5<VH5UbSp<=wvUD(FF#KF0&VZP>%A8l)1AN=a6#K%Ur'
    '>Ws&uv+~GCms#w8)CKy<A9mzo$pG>0KWX>M0A%@WT^52Nsmtzk5Qhm}pUrO{MX)K{g)~8j>alreXtXMPvGX;`bn4Lt_+WACknq2-'
    '^B}NIHB?0!!4XKj+C9YE9}iCSI!p|vD6iqaEGT05lL<yu;6L`ltn-I2)0knI5af_Z-`48UA)a!dt1(hwdFN@6;E2WX+FtO|ci#Z1'
    '%>CQ0vC$ko)Lpsfgiyn*o{FmLMU_dlvw$@1OC0d~MG-l`Zv+kXW=1!K*H|QX5nQ1qKCJ6`>{h>7<NzpnfT(pW;$hHaeVOOALHh7F'
    'xDJ@FH0w?$5}HKwo^u8z_c;6)@?X~-i->q;#~MbLT6b@v3q3|^Klo#ZehQPAg5JgB!v1FRWNE(Hen5#(W6+$ST)N~PLYUoXeAJ?A'
    'oHP7C6wgVS4D(-O=Lxg~J%O*bFrclp754y1(`n*vk<r_*S2N8Hh513!Kvpp2rh}fJ(;xd=X!$gWsLqsA5;wcEX!C*fmWBz~XE$(>'
    'cII+OJp+NQGZQ^fv=RP^;O?!Yc9wLxLR~$=*l>DS(hMvL8>_)WqnvJS(PX1!#2Ad7-@O`d6K>_==E;iD$CGvpY=8}NyT6TP+Nu)S'
    '5pTD>nB)}O19YePovsOF(^bk;ApTGdP#hsrknc`0?b;w3qTpzYK4IF1{Q9XQHFPQYKID*(*@Tqg84r}T@6x2DGTOP(HH($x28rN;'
    '75-sul~F+ue;41akc7RNl-Y-3{uCw`Ri#+Zs_N?E4e>D^C*Hrhwag4NC}{FK6^{l=es5?lKjOms8x*&*DM(~FO9W)~0@y4o(eGAY'
    '3JN;3a22#d8TGs=pUdHsEjYcz#8GN=+&YFbbO&<ky$n4B_Y$#MF>=1<uWY+ma9#u_1tjKGk}Af($eJYMHazz>UFzhNk~791Stnli'
    'PafXr%Oh&Z#qrfCRWF=n#$L&{xBYv6-RsPMe`nU`2kB5d=;yuP7_|srrwDMc0#<D3eZV<W?2r$P>E8b6hZ*7D#=_MvgPl<*ecOv;'
    'uBzyZ3BszLcg2|P0qj+*l^hV$uGcVo_cTnni^pDmP;yQJbw&V9IWOMiRVL-{|IE?q2rU1*PMey>eiPWp+d#b51GQa&D?yb85jqVw'
    't5E)z7zdCB+``W+lb2D~?_HI^lIJmh(pn{@Exq|MzJJAxcgnI~mifj>rhK~dla76oEgv&;w%~UJn8i%{<=_33KpIh!Jt+uV3xj<r'
    'azyh54*7Mmh&U+$`4El)<AdfzcdUWuiLG1J@6&F>ROD_MS4xH!2;gf{I|oiwz6GWHk9wo%8nCPu4@h9MWJ}zBNa<sa_nzgHbz%k6'
    'sOXvG!7><_5tTaK!>&*Jc&#-JSc`})X}8PfMgU&RTOfv}tKW*yQ$5ua-CmgwU3NA$dtqN4m(r0t?y%il7#T*cKU`MuyqGLxZJsrI'
    'bo>|5x2qBJf5xh2WK?S;z&<-3a>GQQRfo0Sq?@fuhr*nv&tadtI2K1!e#1;wk9BfhQOzSP#p@AzYa)R6EviMPXYPIb!?-UW!H!y%'
    '=;a7Cn7tq9{X8TA(1H=L1_LRY(!-v>SN8a<7E>vdQx1}vWzXzg05Q~4ADr3d=!}_`mY$g3SDZ0+I?<RFaD=A%3yigLHV{=|dv%Bi'
    'g#}CT$2YS;7Elh{$Q(Nyd7+kSC}r7BOfByAbG}Gp5{P4;%ptU0B`VTAs9SSu)Sp1(mg1Ry>{g`i@!9*brJvMHl+lPLW2*n`7NQf5'
    '<;TMIRc`o56s1Jv9cq-zXmVWXHkxdfKmobdk>A&<$XW420K{@B44`&w-EhV3fBumMxCMM6McUwI<{{mn@5%H}=xq`03O;OyldSB6'
    '<MbI?>-LV~-kaFBQdXitRd!{T{D<JX)EiesmSY`eUiS7e;L9lG<4>DjFE{SLqg4h;yEqZH);rXCWpjo4#h;!1bHFV*ZrXRgJ8f#V'
    '1#_Zyw-BO|?siM)?MkX~P5}lV%iCFr+gPw?KHDD)2<lte6o19Qq)v*p2|iJ7HCI{w&{AxL!_f!gMw8r2EUWpMbtH{1Lv(R5?T>dR'
    '6-Oy-4fvl3*+3$|z*C~vQP&7j*k=t6Q$xIq2sD-j>+^EQ0_oLh<C6_1?|z%4F}$C0y2Mtsi>GlF&pNm-VIMf3@~ab&FMx-U*+z{}'
    'YWEGxtchZuE+Rhx;;1&Rhf-$jM-u{F`j#e>_En;{|F#ACl>vWw*`}2}8CLC;`*rqe-&Yl}1J#y6hUd4F=IUa<#2IQ}Ed=~5eO!`8'
    '153|pr%PAqv=13JI)od#tO5V-_p3T3?cIME?@+Cb5jZrY;6zm|G1Bhq9sr5ot$)fxKi3?Y1Y^L7g2hG{r5mXnh~8WxM9oS`xpADY'
    'gtb)wo7HSIYJ$Yw17dIYe*%~h1EQrU+d3ps@CSW5jr>0{cdL6MT^64WfQa%j#zhL8VbT*@ZE=Y~RNdup1cjDDv2A~YLLgp$r4&LO'
    'FyR)qVqpahQ{2_93&XDa9cVkXkcGzQ%5Nw$qGTB4vHhYzDAY-vNNhxQA5<jTnbl=|R7L~KoI8@wtbi{KMd~azHH2a|pf0Ubn)eB$'
    'TWyhx^hz`s-)Wq*a81<bu0@lv>Nei<4M1yxEt^t34{!!5;wOfe1oI&u8j+sa%O!77N~<fftvnb<PD1sC@eJ?<?oMIRhEmTVVWRxn'
    '>;pj`N)<-=_mnvQfxDWB!F3N8`&R!3wsKn(hKh^N<~m{gel`)v!=08e>?r+ajG^lZnW?<46qHRgSEyP=%Y({)9lJF%*|I4yzi+W$'
    ')LmF}Po}>_ufu%u{#r8&wVL8Yuc3y943(N6ohXHw)ZU>Z#J;q%8c{IG4QenAidJY-HG#E8v`!z0wk0tqf%&D~#x@ze&cv;70Jf$W'
    'wT&T#UiMkiggQEPHCEvC$V%}Dzs(392abL^DounTvl{C~g&nsS`bSrMsjiZgzum%d)ZgxU=T>kLj2Oa9!35&iu*cgaahlC1@@x*l'
    'WC>i3rZ0LUn^TBR?GE7?`7#FHb$04h#f$TI?Oa=5>(8%d<9U5MoBv9=tye1Bs>bJ==P;(BfU}Ti<xMdu)HkXK-|&c1XEI)D;{pK%'
    'KIR34bG!K%#D)#PcT@v)#+bPTWanvb<QV9*NFr;Q9?S8$vf_)$un_e&-Iz4XeJ(Y8q^nq-e#REzMYr&<L3lKHgZW02b8e(Ud=#T>'
    'r0<|?cq>uH<~d#*6=?JVmt3x0UPrFYrl!GkNgdzvkNT;PWk&qX-rBT+u1K|PhnQiloDGMtL|qXUHDuXe*i{(K%&T*bMZLpT!JgDw'
    'Xhd+iL$e3Kw2B%~QNilI0U8tweb=7qwE(SXfKy0m5^340S!q}<U!8h?Dl$>BI8>MF*eosvsVj^hN$$CUQuN%laz{#aKj?tM+H)*~'
    'ilr#RZNmJ9dpOL-n34js>~~VSy5`^Mx+ZLn0I{gX*RDaHGIxv8T2XWyEkY98WZvXkN6yj1nI2yo-O0M1c**pJh7S3rMIBIyomOvU'
    '7<$*V{%a;XJOC5tq6I=-pGD+{>?9i|L>O`E#Y%OGXpYe#;wb#Gy;J(9Z(`3%nhIxi7YbgorVU0~ZT~WG@a~s6u{XSqEe`7di;H?9'
    '$ydj6qn>u5;bYJIAlR=Ca256x4rUdy-U>LX?H^;`$9YY5$BxI9(s0a@;D-J@*86G(4ByxgQxtV*V%WM7j0MQ${raq6QSk5A2`>_T'
    'g^7fx`q%a_fn;j%Q#TBCnbD*oiEz-D30|3zN5~Zztl*mKyxpC%AdX}jYsCOF;A_lYW=eZtk3q<dok5ejBRLO!!%v<38Paf_C6ADo'
    '!JSN9G-p-JTx&?YQQ?xm)8%XEF%ad&(4Bm8oJHDJVt5du#`F2+>Lf2ZO@HZz<ZXRB^WDa1QPZj*dgp4OsmOXys;a&zd<{AbyAAtn'
    's-mAI@FNP^kR|Z6jqEVFO3TYAmpg?eKKEBw%OEL{e3;^1^ZA<^d$DS%GyGhA=u`b#+k;V8T;(3zhyTvYIF)*2&2mW4c*DW+CFLOB'
    '+nn7bP>S85b@+CpRl`bgpA2Pmp+Uy>(3N%PgER6kenUr!2b_et^MXsoXzv8RB4bz`_HfbdZ*f*xN#Jiyy0)ifpo6+rQ5qxd^5v5)'
    'x$*%-`be<7woxGFKG`)#JGIE3ie*q~=Ie=houlhCF2?8AY#NhEmq#93_;io?+bM3Fkq#*TT5c{{Egwpw+iO)EK*^TX5EJZ$Ib!&>'
    't`>o|a*I0zepNg|gZKMipaJmfl6QkU4_%&!sa*RDbifxZ`wG-Y>K-V=fmH$6S?B8r(l60b+a+Dz1lCn!p{9|iRKwwb*f1N(onzw~'
    'ddehp3t|#<a+*|9vCZX>TY)7;IAhf*(xf)h25EW-3!S_r3d)GsW8={4ih*ONuFA8xZj*X0>@DtNRHn~S4fr~(guKz+$ZHx>Hb1Ue'
    '$x&Y#vdWq3;72{`Hcge4bW|!>F9a9|wDpjEU)hTf2Qaq}vAK`8-A^GOOI=OR1k#LwB<16*5-jl6di&u|O-7(CAS7wND8(|_6?cm^'
    'yXn=9G*l$|XN1>^yS%QV4GQHb6-}aBMjjfmg;)fEppZTw1O^j0Wg!GFn2b6<ms=qsAFBF9`zj5<`9P}42)U*#)qnDpvYO*2XJ#X)'
    'nqgl?-!rc>F`)kL0bbEGZ4x-F*PkKS<PC8i4>QwB1!!|d!mc29IOv~FPPrx?Y_oz8^r?a+@F!91POE9;KaV)#XRB2pL_h$I1i-d~'
    '(}Rq`dS~jltAE7(yQa6sQfn_})t`J!RK)|mKD-Oy+O!HyP_oG1A}3ZCqwJ+R`iDq8>TT5x8t=VLCiGru%!nJO<qSr8g>d<@_>5S<'
    'X(ILN>_Up}Wh&$W!T99Pc{2mIUvuDIo-Z|6VPGIvMJ`Gl%t$d8<bslL3&?-PRzBlKU{jd!0>1a@vqhz3p{3O6yUie8FL^MJ64r4n'
    '4oXda$s#eIA?((|c=t%$J?adJ2y6y}Df@f+W_sa>X135*-c@=z;m-mjx1PU`-8>T~_7ouY{0bd#ZVIKW7;CpKU328&9kU^xWbdjZ'
    'RsI_<e*o%>tcm&YJOU4fMfzX>eNPx=FWvHtuRTcse}}Qs2l-}lF_&srV-w;Qd`6yBX*VK5uwlXzhAd*5t(MmAKXcl|rL+u_JnjY^'
    't(ytFR`mUx2)6fpoV%wP4ZR&)w5wyo6WFsiE$G=dlGv;XG`a4b_AoNYETiF-FdT8i0E*c^J-YFPywCAeKcHvq)GB!igu)oTQ#G&{'
    '=JXzz8lX=5ex}~56oKp`ehzN7wd4r-SqV=PZ!EK&axTigFpe#3JoD@(Y*S!Id=xqP_xSPK2np&M8bCY~?u5QoZ*{L$U^A$h7KDq`'
    '25>=Uv7xN)zVb6(r_u;uCzR{TqDQeZl0K4^(Xs)YEeGYpfIFKav`{Zz1FlW##!(rwUQyU$uoGcSlOt893Vmv8PIR;-3h`r~F})SB'
    'K*x7kUqC=n)E^!JK!l~J)-vzk2)3e*Qot8e4lB6^8M^$DuJLX<?i29cW(Q>%f1IH}9Zrep8A><nEwwLU85&HGs$y@FhGJFXvEyd|'
    'AnI%#C72@_`BfUYTw&QPRIveh3A3=8KU}^P*hh0igzhfPD+jn<Y6MJ_F4^or;Mf^+n+PRMv|P)S3{7E<G0oKv#>ERVrdTW&I#8%s'
    'y4O5Po3$Q3F&^wh=<e};)zMxY150s&0&umQ3J>sTJ1mZyxd1;R#YDv${G;_1jcN<p(PNQZ!if0;bzMt0JI?hS*3`PmBhTVF{&GC~'
    '2!)>{^OXTI`4N!#6XH5>CI*Y!;@k{H3{MSj(ko|2ArO1lneCzLvI^5$nECWD61pjG2G=1~&Umh4r_YOHt^Y+2Bh-}8&?!CU;EIdm'
    '+E4!KU#ESt!H1QeLoV}XKC*ak7<d?LlV6%FjwW^JCztM^OpM?<6VE3}7_kf<Jjie*etl1#2EsGuMRtV|`<nwMjEyMslEi9F7jLs<'
    'mT7pqGxn2I^t8A&RLS#AnJ0auQm0;FC0wUmzghkQ(A~-APjGHx@7qquhomx4u%G@S!N5vc7p8Ie0TD9dRb48xWR3jsi$b>^0ry|-'
    '<-nhRK(Sf|jbo`{>ehA1ePUuMxpL2zRb@9{NM>R+DfmgpoN7U~=eMy58zdOPnCK(~2_Xg8`0l2y9*nrpE>Lg)E%z(i(ngcv-Oj!K'
    't`D~<DE2h-{<fE~((AGL_(b&HlG|^2n@l@EMD+0*vDhi_$B*8xe-*}z)0dZPV<j+}MEp9(AoY8GJVI@jU`@w5Bkdx<d`^HFLq_4I'
    'MbUjka%}KJh5e=u$F2&<maU+r{@pxWW1J#hAd7sCL>nW{f(QB&bApDnYwG@aQ|VmRecQK=#s!f3^0(PE@()}|O*Z+OqQbUyNPG+t'
    'eZBq&(gVrq-$%GKTKl`0ve8Tnwb&XA^t+1?ZZ8p68%R2LP8lfmn+xacdIklk)EfZ8Gu2Kbk%_*PsY&ZWHQ|m4*Rw{MBo_jk<O;YL'
    'O5qxn=(}UfK`1v0IYcY;|G|{NUotc(C~eP{sZ~%5$<CaF8(#IH%2h1(lHK3;81wOHpCdm`t<n$WLErE-VF}jT`!3AXaDZ_-<SHe&'
    'wQvE96UMZ-<=k)*#LxKR8<L2@`p-^Nkf$rj{^{G(6<MW)+V=IG7mR`CExFfD%(|zhYfB7w-5%F+J4}bi1+)yBj$aIS<KqzqGQ0%u'
    'u~r8>S2N%+gsUjs-@t|-*Eu<QvKgedhzDV3bW#jNSfn~fIle9~Urwjp(tWe$v~Ju=$_K8DZr>W)wtIGxiXpc4>c+g$(9AcH-QaPt'
    'v}!yHgNz5Xb;dPF{S7yD|Mgs1Jw6LKY{6>nk?mFVCXT`yp)DJFd@9|e`5WH6m;w%p@^GJe?A#OTs?(Y<3R&&WR*o@``YlqWo1Lxi'
    '8ieE8*WBzx<>KC+#mfqwm=Px>7C5si&>A`KSGmIh>Cts|L=3?S!4y|_AA5jv1=F>|ftBIR<?JerzGY{S+76tIB)`~R6tyhB;LvH6'
    '^GrXtvsl%jg3sknZQf2*_#yEnZ2z=_q_pBg`K}M|e%SK`#zQPir91#A7UH8qFWP|+qVv+}h5id;!C_llsfz}4e_`(Y=#+}=q|W)_'
    'y&StRGN;}rid69PpL)0QjbVv;mQ*A=fB95u5quy|@>}U<+>*&%a^2UeC#++e#GkjLeQDqORH>ukR{@5CBaVnH%BMeH4is#i%E~it'
    '_LjqsZV!3pv#T%}1sw#s!%CPgo#O}-qvZ=l+qDM63b|0Lw^aHqWcGod2dlwogN9-W5~jo&pLS#iie93Sn*f#KG+O6}7#n~!j(z>='
    'LPtp#prpP<+v$PGhW?UEY?R}P9l1ixcTrH2GR>#v+DGMm4^>|vhSJ*ncJlX8bitQ)H32F}E=s5+e3~lp$q{1L&KP27PdUh3YOqgK'
    '6t!a6A{}we8b+0lDpD2I-|WTX+nv8??#)cV!u<pPMdwbd*&M&MEXlsz#kSS?*eWDzKBjp9exVzX(x*u_;KFr=)huHzm^+qJ7A2FC'
    'AtOb2@iU2RgkQV{6$e*N#p}aC<>6D+LTFo{_?ba1Xb^Hq?rmSh(P@TMGp#Y2X@GY#j2E&b7cwK`yTBDuVCuL}5>*a`zg(cVfhx$W'
    'tXK*)%1(X|{Y0{BuQUP)9j-YtP#}WvX5jAjS|DinY?{?%NNZ-+wXMpEYl{uvY9Kiavp*@f{XZzp$;3p;^S+ijU<xikIF>sUc5rtP'
    '$xw(0Kcj`ZvFwm3M2YWA`T-2dk+6>kZ`(Ps82h(G2HE(%8CmNx>zpbPe0|+eTtunTME?Z}@7gBoW%TMAd-H)yq##YvPz2--kUfn@'
    'ddwH0X{OR3sI=H3IXQP^O#3-yvVrZhFM-lpG_g+LC^=wGt-fjx%VD!wDYK8h%Z`=xyJV67?#W6g#fCm0(3h1{)pd&M^XG*B+8~4D'
    'GoJR#DN^L3Bj2)5gQ|a%Oo^fJebd9eqLq(cA`42tu~_>Nuv)sI9UaS?hDFxubhUHq#KbG4U~E|GXr5l31Wr8tW1Ua_X%pg3?FZmt'
    '`UxQ~yZU6-KNMV8$nxs>fd67QWZsEBoRF+k=$&#^gTGP|koy&YQj4yF6$8R$bRKnX4*V8sNzm7;#S)?9L?im^J!Yrfp|N*${7B!+'
    '=$Fy8kPd7LPR7_r3H=skPU|`c;$cTpj(ZR_L76mU>@M_1?^Ka)1az+*k?Y4oSLgp94;t?bsZS3N{s(PuTBPb(=e}b_7-W?qM-oSO'
    'lIoXT`xoUHxQ5zhfMN8MAMRP=9m4A6q)0pnu14vt{e-W<8zX%0Eg6pZjxps1-5m|uqw&Wxr*`sDn#wO|H3d^m^9p%zcm0V7risUn'
    'Cbucamh8KUCNIMQm429(r@Gmsu><SWJ#^m^)5w1Hy$S-An2KtkC-Y;Ejx3ia@m4i<@*T9d5OlY_;Ty==fFQg)M4%Ph^mZb1_+{A_'
    'm-0xr8o}~VE@H*CM0ZRzWj#=RkTa^@yIEoAif3-Xw4AkcpvUWoVX4xE4of21V^OA9g`C@_z#2JQ`jhK@f4L#!VwlhL0P0hl=hppA'
    'h<T7|5~LT$|32FrtrJ_(I|zv2C)?O1wKuh~A4)2jo5UlAB{^m+DqU&>^*0cvKw;B$0}gT{drU;&NSmh~!!f!8XOE*6qk`H|0JLZ^'
    'e$cGn7dFMnyZ84x8$YrZNI%p%=hR<bR{%pA_b!6q;ck;P7oi>T6f|S2WM(a`rgef_E#nhvxZ3e0H2Tl^V3wpr1cvE9irJ<{xNrAk'
    'T%oJzSI;6XiG%N09JcN%eiP&a9~g`lcjz=Q0cr1b(GL&o&;%j1txAtSCra$<X18;*iT<Q|yjk-Vv1_yXsSpXe*umB=V_O`#A!T(V'
    '&zeD|OZckrbv;19BvvF1#oR*G(f@nKcCFR8Y0`eAlC72P$7)7!TXxaB{Hg*OdT~gPWHUs*P>eSQSGtO|?Usk>IwuLl1dOM$R}|w_'
    'dTt6Xl+EI8@Mhcckl3IPh3{Ourc=!Ns1;5RVZH!ptY;Y)XERBS_rYG(ISuR$EFj&vxOp7r?$k-@b5qVHSv(v+Yr$~_H7M?At>WAF'
    'I#F})OkE;?XY%JbON|;1JNsFM8?^tZ{9Y)CeBBZ`{r={6oiyjur6n;cKn(+pU-GAYsI}P~U(euYR|R20&eUO=i07|lS@G%JGPDDg'
    'O7)L4Os`g<w(NJKyLAm4mdm=-=a(CSts^vnfLe>y2SkyzskgwF0IFGE9@{WZRZ-JnrPUm^Z};Psjl8)ZxI7~+K8@mP2TI{d#qe5D'
    '^>cqj{?G_ng#F~3$xv_AnFBsA^6w;M!bAV6PDaZ-UkU9oDGkHyOerRU?$|9&4A2dgk;amiHej$Ww`7pZBG`gr9p1z#dbCC%AS}FL'
    'I8`^8uNtJ3w7KaMeUvVne=!$FMG^Ekgsw-odfOI8bgs3?@3?J$g-k*SO`<!0krptzsb2}{?){AIh&)nS-S<fozhUABY{knOq2s?r'
    '6m#9ItpEAv`JM@}`6mHqDH6s*f^DXaN8TbVK^mfDpP-y?yCAw?oxW4*oBvrd?cA~o`Xgc2d*)YV3t0_BG*_(1<vt5o-FNGmTaa7Z'
    ')<SlJC@ZloV|S|DW`Dv+r0ld7`Sde;DiJGQxP}CIUk|S<@#q6b7w>HJEO(%tpxy?N3&(+hy9i;?8Io(XMoZ`TF98%LVK-+9{4D}j'
    'bAJn?3%L7XW4eV~XvT44)oeu^i%_X+tm`?9xu-WjbeM7&s|!Uo;I(LR-a8-S(Gg2M;V2F4XT2C{%=XOaPjoGTPi^D=x#+}t$jbD3'
    's`gEwEeq<#QXH+(4^@?(n*#Y_)?!c>W<j7A9L20F=W&Zuvw)e}sS+yaPiVt1{bzju*Kzc*eJx;9fmS1+x+*+bh(`>Ds$Qhm&v=Si'
    '@ACFRg0Om6zc#N%cw~g!cgFXMRt6S8%}Zz3$8sOlKR4{DK1EU2789gUEnJNoRAJB_Rqn31p3N=^OHyaemNJ*dU5U=)nhKEUw_-^4'
    'e9mFb0O647L4U{3sk>SiUdy2bK<n(Zyii!B){`=Q*9N3MF4~LM%l`<3Hkh2n^9+Z#xYcDyFr&kx=P@=xa7ZvDSnpF;6!2uKN|50Y'
    '$_Ml=I`}ADyd>ouE0I*CU67M$dE2LT^h4FFT++jQEdc}??l@u{ljpPMfH-y|!|j)T&yd<c3{U|F0|sv5NHLrc=Dt@`+*d)-SBqNM'
    'V}V9GU~q~#Lx}AuNR}$%TJ3wzZ7vH3?H8yb?{3cAmM;YFT1Ajebjx|c|1$8=`}?|qSJqW!u#sKTNT!8-*iV}AsNom(<?K%p^_}EX'
    'a9wPQ!w2W?FEQEn0NbZ2{*m`uwY;$nCVPs26ExRXcQlAKN}4`uLVqnCI_NIBU;m6>{&Hxqe-%x4WZL)8S(DEy3~v>q()PYL41rtB'
    ';W3zZhUWwG2RL|%C1Jz2%_a*~%{fnCfRjrg;EJnhuY3NEpd=Y)gR{m_;x5R0ocsCZuV;K?H5-xWSJzY7*w-npxpGor+@XM6ZZI8g'
    'ldWdhFIoi~z4bnd1*&ykUka#~!3|AEPPVQAvrG5toA-CJ{MlD)n%jbH*fT@-KhMPr|9#ZD!!f{_@KC6i>d_Z|vkvb8;2z3<PjXKo'
    'A8TT=8ugxE-LWYZ1zgQKOokJ@XnYb5Wb=P2<7qmwn50nl4!_i~Yv$TA>w&!s<v!TUMn%3_a0H$o8Mt=$!`T-UGn=qp5(woE?0tCH'
    '$vg<D$6bxpYyb^!ZIMdQM8xOMQK?^Mh0Sxr4G>QBOV`3LfYmBJLi!8U4>eZ@=ji3PX%sy^@!rMB_=5}pgHM*K_wrX9c}gywsRK-F'
    ';4Yr$w0g}^w%28hxsgdW;cMxf)JpHJ?djt;Hxug5-o`$#_6zNhtcfqW9l#Bq-Rc~kq%yN&eZk;1@VQ5-vN?iiydFN8?}5ej3Nu`T'
    '!j=-#^t7#-#qT}NOgXo_`XE|AUDnzIC-`1WxM_-@Pr7z4a=}GuZuwC=4>nQ3%Kqziq1lHMN+GOcCem~={X|O{Xh%gS)cfCSFS^<a'
    '5?;r_rs<_Kg0OcK7Kcct+BEtFIrzi0VU$k!1f*#TVbw2rvg4te)!}Z%PR4ZQ=#c7qrhj$h1Z79Ll#(G8;=f_QQ?rjJ%$_yD<V;Ok'
    '*+GbTOLNq>nj6s%O+n-W-+J=5QqP-8l;)OykxZUlNRR{wX=OUzL2qr^hx##};w{8}%nPc6n@$PMZLfG(p^s(42wRGn1{=5(6cIQ+'
    'BdGRMry6kO1d6U+N4_iYJF$ag6p`N>rF(RR!?SB);}b@#<WhXtIZ7PMvaxryr$P|+tt=%c@~gObY(b*Se<gS2FFVsik+uVY<gu{8'
    'dE`(yVuEOM01fU(l;_ZZ<Vu{JaujfSCujGz5M;vXTtfy;Z+dyCocJsSGt!pw>Ok$q#5(@o;p&C<ZMsvnFHTuek~y%9BI+|AKJD+#'
    'SaZdh6QwEIg_?)@-zVSkb$Z@xLby{h1@*oKu_nkUP{VH~Gjj!fLG_>~t4*cZAl~sY`i(nFR@TlS<i_TG^~_4?=U3b!q2%`y8rc)l'
    'SR6E10^wn(A}tb4q1M%Upz`Ud@sIw_Ck{j_3+N$!DpVO!BJ^7zdY>=O6ER(yB@36yD9!O>cFouVSr?&sgcVWV)t&oA&)YazMBPC-'
    'GR?waD1xKiE<;9q9jFO^rnv0JvD?8@PWkDlvgHmvk46X#Ui#eK`#t(ouAtnZ-KB^6-h=2R9DtVvB^Bb@+xk@{1OjK7UL&C%MoepC'
    'MMB-1O#7`J8+|~M$K|Ve;&}l*Hyes-)7(OH;3y8rSKcJ~xt$(~1|wUi#6~hW_37=?ca)ADf9K0P+F_4ms+r88HZft)=<4=pM0s@%'
    'qt~Tv_@y>t`N1eGLn!<OWD7{?CfFA}2m2GZDifH)dKT4RAn+1~s|_7pkBfVvSH1TgHD2$c7QEHN>DQ4B=IcTQi^k;uhdx__i@vt1'
    'ew<0Ko9dIepp7HS^AI0K>Gb~)Yt+<dupk~yi8rS!Bp?uAmrWbxRj>H(m#ryy0k1vBxo3iQ+YdH^@Bd(6J<n^2z)M)7z+t)m;cLr;'
    '6}2zy=uVNyqSbI)%DsVN-Jkj!y!lr7NadmG$hvr|BW$f>4V3WFSOOX_JH$NmRXM9h5XYNDh|rcUM9=zV0ienRnlrw|{Qsc?^^08T'
    '?%t4P+dmFe>)<d4N6eAOHgS|NUUPHDD1m0+6li82aRbJKZ-C<|gq2{!HLRH_Hm|m;vH3fIWN8qHQztx+V^X!ug@K|p!3S(<Zw2re'
    'Yf!xHr~bzZl270;N^vCD2WM)|O|<&62Lno3n1<01&eMARRzLo$N<FW$BBT!Vy%SLI;T4gknEuQt?;HsS$nLqh6QWVO%V>9TLhHZ^'
    'W7z<6dt+m4B5VNSj_=|5{IfAHs#EFO#mj{~0AC>0n!ng<-QDRY{CH7V>COI!L8j{j8lvs&x%I&=5QBO}FjuBPEO!nEA3p;ImNd^V'
    'RePa(k?^Q=Ph%t<g~dhq4&ym@X;(=>;4w6iJD)V#scJ6zh}%dwhPJ%74{u$x$|4kh*AAG-cC)B1#g!2jE$Jt_9&18{q5-7C*5CtT'
    'Qyj)J(6Z_o?{ml{O%wdKC7aDE148>R$Y!%n9~i=6pP*fUj(eYtVCzyS{f&;X7iM*_&Kr6H>^|SA-%>9gj4^%h0!>P~K6f1YVmZtk'
    '^HZFkFSeV2herCY-k=&Z%24Emx=P!pawwL2d38Wn0={HxZxbbPWYd#k+n)RxDeQR464y+b{e92$kTNK;?Q|b;Ct$Ye-Bj9D#4Iz9'
    'b9V27-8K7$_Tk`-yjITc1JcbAP~_IfQSy5I$lgXA$(nCn7w;KHr{4Lh5wZjv8(E_et++v-O!o_Jn~D#|%MpM}S`9wx;4}jbWCYdN'
    'TM-_S4Vyid(DviY>b!F|6xHAUeP`Krqo)U@<P4E4QIZ74E-DV&WSoU?MMCBic}?ijL~`9o!Re`0;c8s>jl*<av_n~(!WquOr27MQ'
    '2e$<Ne-e%y!aY0%)W91-|F+K~L#%no9^3)UeTyi9FyV1dTpT%da!nPcEjctdF<x$^q9F%W#g`W&EEiwAZp&3FTwLuxh81$`oQtx2'
    'OqUbXD=d1ZhLTSaMMT|T1nyjmGRRgQ^y-sSon#5Oj-8ti31D0K1L-j}&?c`*%R(eAx0dW|n?hD?IfCZ-w=5qBfEKlUPc7Or(QQ0u'
    'Z|MezC3b@DgwmM$u957eJ-EDiV0n|!VetyBd9ryF+uQo&ND?d`0I4h#amalX;68odNe|uDX*+ON7nLBv;x&z-u9;DXG})D`j!Xbx'
    'g7x>Awlxv$YcE!4vbJjkNdo6D>~kmO*V2IJ;+PYlxXxzX46pX-zNALauRyD&z^nwmfNFu>EW_Q!k`1oFSfbqeoUNqmTV!D_x6{vV'
    'tC38P61Y|X{t=9m634YC`7}$1+JS^1KPXOwRnhVNtWu+cBtB-QE4u4pGUBiS!)epYgGNEd00%T@oRu&|*Ey6g)XP6?zP9>~=kfb$'
    '@`LT#i2&poZ9sST^QO_jdcKlw6UE3lbg+h3jkOG*YL6A=+>9ciPvL_0xWVea1|?XTBr_D?=~$`U#6QK{aNa6+V|=UTwnVn|T3><G'
    ')kgiaHQ{XBRwZ$vD6f-LPF8@h5aHW=jk}%l2uryMVsp)-jNsRic$+s?n<2d7Y=$n3<SHyYC5|*dY7^T3W%ohIgC47?Y)Q&7NKgq2'
    'Oj5cP`ZaOGb#e46fUG6m6h*AFK|`7s#}m0wY)4ukZ>g;n6XdsBou7z@OH%;~bcGq{W}rIr;`Brzh0swa{(0pH`aT^#{JnK@%^jWu'
    'BJt5q5(Rf+R5w}e02m#Iz1uX8LR6q3LSS1c#;)r-q!{FW*6-S4iScGZak4WUx5s1NBe`Yy4cpg?tq(l1(9akkTBy}ah{uv*7NY%|'
    'd7g^dVUCKlXHcaqybaf~qUt*5!(Vkio1m_hDuT<V*n{MWOOQ7-a$){&3Z#)NG;c7PiP~vzP1tNdFq8&lcTnxQUx-?~5yfCrS_0Dk'
    'J4k_@UAcs1^*uo5zlA%}1`Mf$S|<$t!;7su@v7?Qa;n>Uil1nIxw#`Ku5Gl*2}I<iH)SKgVWr{RSLWwVE3m^zna3GSt4Hw}>eRG5'
    'gv#>02^subNM^XL&Zh;c{}hVEY@EL*^sl%t$Ej5oc|{l=TfBrSZ()Xd&j7W5S*fa)L+F16RM-T&3g2@SLy76j=+Vx6PDu&MpP@-('
    'GGOrmk=E9MfD^Ln^Z&fBmIV!J26Pw<oj3ll@|~BmxbvDsuJ=Msq<f4LUt5b2r=gi-F{I8dEmSwaw8m!XnV|Aw%y8idy=-2G(s?Mf'
    '^9>{LLG}b<29xTDU&4VJc;T+SB9QWb+&+4reI-Y}s7|U6SFn^;CE0bU$0h_&M_?Vl^;)IQp-V8#Q}%)H3*Q@S#h+iWA<jeg(Krg5'
    'ZiyV1ydKD|7#){&X6m^P%hw}~?ODU?RvR}nL8#m`^`R1Qjx>8Z?*zgrU~u^cIXqW?emh<<JoOnErAPTq{cS3o$_c!lOx6DsVSqYm'
    '%6YAU2s1d}*eQzq?zU5UC8{`M``}Rmi-eBfBMUQ8yEJc9m%OH^eI`qM8n|*7;Cn&Fc8q4l#CaLb<V`y1z<G@cTti)P<H%yXD+I37'
    'v%Nu;h2gr~jV;p3$+j2%+GUd{3HU|+WM^WnEM7~jfm$1MC(yjdou#p4Gz2NrqsPO+T9J$2a-4G4H~=X5S0`!_hy&tz7gwFS7s?lh'
    'QVLcZw(;=xLX;vvXVR(7O-I=k|4NW<Rt3MR+0U>!2AtmRRbmCKeoHKy`MEd1Fq||OBp4_chuRq%h)!HN=4vIFgglONir`1$)rx*v'
    'E|8*&kbo-HkGmN2xj)O|+4J#(t;{kpie}++=97{@G_vf$p_=PSy--LN-BD3e+%!*qEJxaZ@~uD{q0VYhNCdTveLg)b%m>Ak2yrbl'
    'NQAg$@6R{oif$AX-}Xt5N9ywS_jaG2rJAgyz=q4XS0$_{k@uqbE%5i|n3^)lHQg^on|nLpkUcicL2L`s{0Gb#2uK>f=sB1a*TbU+'
    'N3skq=?6E)SVjrsO&v|J^g4nL0H>yw@(!YI^3JWHQho4Gn5?Mm2<T#12fTiM1Qr_d@|W<;3DJxc<m;GOs9=cG4@krav-@W|+#6y`'
    're^aO7G?3bn+OItNOwNb=b52b)fc9>YN3|1sK#c`(m1(Ry|l4(PwItecmGhoBKc@w*^@ibr1E8uE`Zh@f!axzot!|7^@@EOGl)f8'
    '82I^Z8q9h8;Dj^zcqHJO^MMGC$wotSKHVbj5zJBft<=>|Z4VRw_MED*XfJt(He|JUA94PjmN1SwX6V(i{UGHguvOwf)Pz*TR+Ycx'
    '1}KZg7bqqKbDZaaDKE{3owVmh2*4sAyej_&5ar_W3yB7NkdI=MX0^ysj!m-wT_B^RXt4_CQ{u`Qv{ZaJ2I7S8upG&r9wX5!3T{;K'
    'J@LN8WIoFNGbA&Xu0F2S9Rw8wQoH(FdSg;olSOR;wMGTsx5FLmftm_a?m#%m0_|YF5Sz%VhWKd$MbdvghCLck-URNCvPzl*#JQ;e'
    '&89B)+NpB6l6&gXo2Y#<CJO9~+HUEh_L=yjzF}a#@oNmC9JCHEt~kokSx*Hu5Bhrm6hm=PYi8G+VmhY&)V`t|oEvXM|MCW*1%muI'
    '%#R4U>u4zZ?|{_KOHAZ$dqw-R>TXkvi5pnrI^CIBC;h?td@&~ht`kJ}3r<RUchGxJDt74EC{~(9YGbxN@zTmgqtC6<YX$@u)7wdE'
    '^icJKTHptfLaka-SaZ)e9wj_*hKSimr!-S}e95MYv}vV!929Mqm}7-90agwNrs~I8=$oPxD!v!_HpiN_pBmVX3&u4KSFW-}yZ;5?'
    'x&YV(0Yw9oQ8C?-&sU|f7*1L<JrDeC%(ib|86j^D5%h|}`4WSr95rEpk49eZ`zoD9jpjNTSIHo>+f*kF5nyXatmfnFk6k?UILuWq'
    'wYq(mps&PvG7e_{P@_3D!|;Et0o{&P$WdhvQMzET6vgWip1DZJ7qc205CJ9KO>2QphNmIVsJ$*Rfr2WFk+2R9mpb*lV)tpab=Fxx'
    'P=xx)#Q6*VLynMw9FPCYaZ_CBnX{pF&s*5~#`QZjnIaP+g+x;44h!G&z-P{!`RUFHtu0km&;XyrH~7Z35hiKEq&oeQ)v98@KR!r`'
    '7@0ozuUj(%5RB~{=S!Cxl};M2A=|?9pkZO?saNtLH`X&e0tl6qSm@*)OXFgl=_0l(glwLBl}SVNM_eP*pM|s59>$YGLpZn1MI|r0'
    'Qj#*cZJA{d`Lco%=Hx<{R_#xNTk}ORD~c(xggmMqy4~ygcQEA?b16`o@vqFc{EwUj9tHUVt;~~-=d(Tym;_f=MQ?GC-f?ty(MqUJ'
    'U@Wl*3Zvj}-Y{&RgWoCST8`J6zmqQS<EIJtUM0gZ7S)8;+dc&2GWF`Qm2csd{mkP6Py0TT!9J7X+?bm`n3-20Nov?rg^<M21any{'
    'w6y<A`#%%aITLNRQ8w()U_9mYlhlBo=LI4$wsl;0)q@IRumhLs;>5dkFu3L~Oz4?VfKos`bK>Ezh{k^CT_DxhBFRuoIBY~=nwKN}'
    '{_=+T_436h&iX>XX5F=O(g+8V#;zC6mYL@u{ya0z3}I3u6(P$Fj=n7&LBx=g5Lpi)iDJj*6PM@)cflTN=Kev!-V)Qbp+yS&47i|Z'
    'ij?47$m*R531>YD24MH^w~;{rj?NvguYp3gNsOaNpsl6vs7l@5O&vv5LsqYo51o*SYC5;&sN$roErOcGo>h|=fN{AiWxKFTy{X?{'
    '4M^sCvfapM!SH@DDoT-c_@o$j4e>4w$;_;-At_gxqOBD_OOe9d3OggDBFNeS%+^M7S;b8K+e%K3<&#G_HaE@<?quujC8~wSUF?Rm'
    'iLigZ7mol&+Lh-MZa;Usz~wcy_o2u;4yFvRb(k<<xbejJ&6$7v!D0Qo;&}H|kO&T$j|x-)I3{2Wei#cWP-Y8^V;s3xc8g3GUT<bP'
    'k$Hh8`Esq%npTQ<3JP2PEBRO~(a0@;@k?`fZL+wQHoE~snhiKgBVHcR26Du~D(OQNtoF%dogKHz&lLQ!0WV+CIG1a`t_S|mza^Dx'
    'L1ZNEgv0m=Ae<MuJsJ~Br0ErjqaJA_BvI^`M7e+G91fTlVI515MTEaW0mcxXh;r38X*!VhBe2Hghu_UJKo<8ebkr|;<6g_hr2>bx'
    'sz=$%Mj&gs=-Gb%-tpdW<Coz+<~Hfa<bK%d@8b~CV@K^ma6xtFA$9<Ucesz;3V|vR47L1H97Zg7!rDls$^$=o&hFe1`;g%bmVzv?'
    '*8CV883vb%K*M_!2tId49bGHt(`~X0MD1|Jq>bmiUwNQNG#C6L(+t%fagq!ZjVWC<!FIePDid!$zB1LXxl16THS@#wann5S7lDL5'
    '!mYopm$|;IDAos1nKGinLN`fT>tD{jeQ)l}L$gX<90Hq)rbRO|u3`0~jF8<o@uiBFDNliq6g!1|voJKckL8ih-=J;nvOb4tshM5?'
    'MwoY)kRQj_NW(7Lz=)eKP~Q4);>S%qh+-0m-^%ai`@h3iK<EOwf|vaaFu^s){4)?x*A}VAi%6N>-Z9#gf*fr7&sBvBFJ^XLY));n'
    'tw8ahBf3q7`<Q8|{0P-_PN+-2FFVR`EMq*=`c8;Nw8aEIHIdC2VOr~mXV^oV&9u;r{F@q?Z6qPNMk#n<o`?P(e3BlVH*LFNBSBP9'
    'g`hN>jYEC9)17*nd;%O8i@}Kzdi0q7{AFV6XIYsp8{{iWcRa)&;nObpxr@MP^I?|U*#8Pj$jw{iH(JV%lFgzU@$3N+IGi*f`n=3Z'
    'Q^ZRqMJ{3vOKv9USI;tCPRF?7ARH_3p|0Di{eZZg3tb{xQ3U`DzFU3X$Ij8<8M!x!xiTn>aN>58?evh)@n3jX3^Pr_tIO-I>f#Vp'
    'ERK>V`Ha|LEO7@%$m-nW()uS+qIg9Ya@iQiln??N2w4=J<GCF1B_DsF%i7-m0;Gy-%I1hhsV4$@^Qo$PRO|{$$LaWK^7~YCm)y$N'
    'npk*2dpj@Sn?>Z7hrnTMA!}#o!$YZ%8&Aj9`g@Cgq<92?DW#>c>v#>~P5S<KmX$H~d`=)H<Sc|BJMRVtd$xY%Rx7rzeD;`W<Yx>}'
    'M88d%t5u*MmtXAx!kw8uyvCM>zc7$^<&Q6&7D2AT@cNANuiX04U1CJaUw#(-^35PP5C=NV@BJzE%~2&yoFDz85iiu5Gw-CN(EyS('
    'P@9zeYfuhU1cL;76T>(-u)cIp;%OLYvsB4JS(FUk3}OP+CG<Z;FIU4_(cGI75StzF3Q*sB*J$6Lps|~V8eiNFgc-(Gs4XG%>2N7;'
    '!9d8kL~`s=RvTV>#Zz}<RGiPIEvUdda7G!aAV?$Cb|0vQoJ8Sz2Jy;FE?+RuyF)$6{8YdLt1lr_lJ!Svw7+^A6Sn?0=VCUT5RZe8'
    '#s#QrO%gnHj|%=TAH+(55<<L$D2gZ7OE8hC`Y^u~vqi*#=)dz3b;;^7r&$k)1`j1mUE)iF{WwnNGn`W%B8(7Z<Cm)x3Gx)@mh5(V'
    '%_K<EY;FzH-9cp*L7Ib7sVO)<Hs4k|G=i55qY50#0Uc8I+lYxxv_E#Y2ovxijPL2#k>lVm3#O&nUm#T5`hlg@YoaNC;B>4&f*vV+'
    '8Jq1pmv{bTUVcmVG$5Oy_W0bCF@+Kx0-eBB$D{shYGHc?d8TRhe%ytyewqxaSBg2DLg)4_Zr#s#Az~n&X{6+)QOj$K>16Nbqw@(6'
    'Dz?YBqZr-&-NXU111P}c7%w?KnSs4!U}uB+px><pgYV*eH*K|WKla9REnSO{nM-i>?iB`paf~mooHBwZ0pRZLi&F=^u<OIcnV$;6'
    'T>yx^j1S>`3f)&!kAOjvjP1pC``Zh17bp_z%vs?7ix*TZllMAvUwiiSiPT@GL@7=zr}zh==@<_Gk=KfH<GRDG7t<MsqT8Z)t;N`V'
    'mWY`W*o<3nq<hsTe+ih4jbYPi7|aT#$ZT;gO=E<pP(mf?yenjacm4H-V}^H2WnOh9Z@DEL8@P7MtdxZc-X@u9ZLX5T2}n^P?c~W)'
    'cib2AR)AIyV>-N6UgZPLnlbC^Y78m?Gl%xeor7;$#?wH3KwY3+r*hT)YEw*$xn&LSzVMm|HOSelE!eQ|nB#Hxu}uv?G5kFQ(=Hy}'
    'Ik*xikLyFCEL?CeLS@DwXbk!BRX26DHGs}fvM0NgU)!8d=xYJJdF71%IP+DK8!WeiE}(@gy?)kHkw0JhTy%relcoch6l(x8i5kvv'
    '{ymL^;W?kcQhT~`gHI%j)`z>VV{b}k*#Kv8zhAXAB-Tw?AOBLNY;rRFm|3B)Ghu7Jr*g!8UhbB9VmleuB`;9|Dn*DbNSn<wL_bW;'
    'h`r;}{qBI->Q%fGOhtCw6*|flv>agglB}}Q@XEhM8Hatr5wFp;9Z@>_+w0dU{jAa1qaYysxF4c9WdyXJ$08h_Wutk%5vPRex+!1`'
    'A=4Q-h4OTL*)So&MjF{UJ~N#{>r&$walOn7tjbW38PX>fW#}nCRE`>ke^Si_RwjP=f?{3QQm?@ZtRAp|^?5uzBro+nozQZ-Fl$ND'
    '^I0m7n5Illzp{l^Z9Hv(5GE-+@YQ7*mjPmIOrD_uJbL33gb$JKc7C67J3MOI20r5JXgpDV6F@w`4SYBz%k7Sf`iI$CZ^sJ<v>ZdD'
    ')vgxUtHK&8DJRIa0LZd-QiQkjI5`lMQWX-vRegUIs{`x>x=a>hZ82`p%%1@6{srkaFqBFaLszly0HJ1$v6>Ov4u))FOiS1`%Qm8v'
    '*dtP0eQ_&u2P82F)dfm}<$4$^6BBIk)USN#45X|b#Xgr+oMk?}$cIJ}k*qW6Qf&Ns(xqZOh54*V3vwhcbP6fqIjs(oaFjeJuq_uQ'
    't~3D#9-IGAWpeQHQ?&v)u>?REG$nCAQqlQ*SxPZdmCmvB)=k+{a=6iIi~~>T(LT}HmO(&Sz*3q~L7QO=t+TJ%vKvq1Zb3=w{rtd6'
    'oqB9d(h+A&;ZB2(3Xy+f&&#zKZz!j~)kO9p*z1K=ntNz&Z&<Vo?YugM?gT$CABP|Sfp&PcWsn{WR<|e>nYCmq`+PVz^BsR@#?`lh'
    '&BDRfa9T9Urx`sQpQ3M`5|&7~<nlg!N-lw=TJ<Ug+|X1K+--Azm*&7~&4G9l#!XY5&{L_ZB9re`+k$bZ=&cLrXV>MEt05hkXw**J'
    'K?4v4jBEWw{B7nK9VM_gTx9^pK6QF2OG5|o)@mEwqO;&{Jt%$c=4&1NuqC#Tl!_w4IhKuj1?K?zYICs+PcsA%T9mv0=Qw{S3ow^p'
    'Gq=8kKIe^}b)<Zkk|iXy89!OyN~OzE$L-eo{scJM2vB4W{X9=39e40Is9s=kwB_m%_Rg&9EAHVAJ7YWs-%hj0i+i7#;Vj40#@pQ%'
    '_qfqBjtT1|T#G-~1Kd9$^tL{%-r?u4v3SzaWogR@(lhH}IhD0j26~Dleo%Pq!g^3XYEW8k)H%Sgloy~v9s@!u_|7!!oWYMFD<>}9'
    'Y~kBs58;>RrDI>+rDX(5kdbnh58=pY4xXT=y4_&TQ)a3U7B?`N!;6hNjj0bNp^@Y}iwTt9@|^`*=n)@HTna)p>jn5MgZ?o4H`E?M'
    'E!4x~BmNw|W%TjVR*^wrtkm|6Mv&t#gp{DV;5{r*gf=P^MNVZLgW^bPQ95=Iyn<>$385v~#GsI+wwYR^ux-^nqP7p&3MtX-q2?NS'
    '@?~Q2L=Gk(vf`TzFSXcABf>y6<eq!hgs|%XQrdIRPn!2U&~IQMv-^S$GcvYbop#qLk?r01$)OD<L;#ZGt?hWqSO6%(rI{o9QiZb?'
    '!%&wmJcIV#N%CDtb0Huh3Q>Pt+QS;UmI|U2eZRb)X*LXx)_sj1fG}Xt%1d(sph{*vb@m#1NJ&)q8{&iNV!*n<&Z`7blC+jHcF}$c'
    'sO;o$h-UK>PrNUyb%ay~j#gSWp2?JVjBh3DhkpQ#(+P{;Erz6ZY2}Z<zbboJ;)4;mJ?i?l@fM?duTA1o+93GZ_MgKOBNoAEg;$Nr'
    '-Os;*4$%fuWqirEg%P^0NXm`)H<>DPS&vlpeM3z$gycO5h+su^EP}^YvE(bazPG_UyK=21r9veoKgT2_a`i8M1tM-p5Bl>e1e}1i'
    'g`c{O3ZSIng%@hjGgLA|No>=EE}Fgg0K=?2lGK6tb$WaePW69hG8JDg>uLc2vtUZZQ9f@t7h0iGn|t3kK;)pJ3d5O$TJ%a=7&u$?'
    'Gj@p1U#2&^Alu}^BU>W3@=mv)i>OOU#O5px4^k<0DsuyGgM@NI{&CG<Xbm9V-sdZVA9i5(;8|+tfx=N*!txAJQHeKyg4OhjXD&p0'
    'Wk_aN>I(FhumQi=mN)j^AK+4^oHG{FHCyPF67on16K<aYvYJQ2mqrA*t!^tKlIF}t->X7)CKmWtgL`kf#FA{lyn3HFpHo`D-b^ff'
    '?1__5B|#xZ&eD$2=S}S8cn5-FY$Fnw;q<;gl?`6gyDr14V_d3qz<Ir!VZ^jM2Lu}x=_~wU(TM$wV*(&4uauX_aKSdK1G5bpG>=iC'
    'dD11GAO)V_UD!f^tQHP&MR8cbshJ-&FAJl5MDsyYR&Ea<ly5{+?@q^s`gtPp+lo|!c@Ge2%FFNcVdz1hU1ttt;xUYmuHN5Lf!m1U'
    'Yl)-I7{2hYc{Q6TQD5SL1~o>OSL1DzP*X@mr=%Xa3cNfgmlmOxTVFL8RpFzdR|sw(mNXGo53^=FR$&kO<a~09IKQt2{th{XA)o-D'
    'hOz(u;!V-ejIu86x6&#+-K9NwR56N8Gey3MdwL0MI+O<zg+WKL9STcbM%;A(U{d`hO|WFTYnP!t8S{4LG;i=MrNBm0aRiCa&AhOy'
    'PFQW@!tt4wpsorwNU5Ad_;r56QP7ARO>65rnzAzi@y?WoC-x!jmrD1PC4Vy9PMW{O#HBxQqV6XFVO2EAENlx$?-n9{+`WXENbDh4'
    'Uz!R~91Qx*{ujpx5Cw$;G?46_J@f{=0GL=EEj<oucE4>EttS;S46T&`UBehV7}tVwj}z7B0h#HfA#}QBt*<o_eA-G&F!4pNWPr`q'
    'w&EHjXps|325+7v!G}%UD(NtvLo3bNH+`IgZ7BO~H>9`*%vAP!JT0@9FAkGLWs8n!*2^r8-V@)oQdi5I+#?{IJy$PIQa@B&kWzyk'
    'z#6KCh&~>Xk+Z4~;5@;KwHIvX(}J28E79q4pY8wQY9n2zY+a-}l`K$>d<1Xlj%722Hjuh!OYWQM0uo5Y0#*xQH`N+Syf!flw(p?*'
    'kGgegU}xT*DPmLVO=@I;R8B-p))8OE^J(rp;(w;ma2n%FUNfoibF~u4rDEymtk002$7b}{atsKg7@WCYkY$77Ln9MXwKG0dEq6pH'
    'ayv;>v#=oo7$<sbktC=~^mSDf$oA9P*Q>@wI4zbdr;opT=5Yhcn6m$fCrZbT$>039&yr+M(<XsqL!?nVsC$gOWzi8}G{gKIsdA27'
    'LSz+}mMo0AB&uG^d5fx~=2sn!H~c7UwzM#a9pO?un6Y{lA5#Y|Bzy;mU3bg;|Jc9YQ=%k#WiF6DO!q)adg1>mlM6CI<2#yiyVjE&'
    '2U)DkC2hZ=Y#941IkXl@rj_1KU73*LW5L_@Gt+>}G|lJrVYXx#K1cF4jjlN~P98`bvk;TTDPWsI@C?vkodpOH1Q;}AtU3y{Grcr6'
    '`|t;#N`uMF$ffFk>ws4l$Gh3kj<ol361mcN1JGmY(#!>(Hg>q_-7khmwX;GA^0*?&bGYrTNCZ{mc@5(QXb^&QoaP`iF8tL5QAIjq'
    'nZml>TgKS5qa~dO-!sC9lEHEx2A7#g3_Kts=WVM7ghj_-FkT5}lI>O08vb^o@6ZGh_`8v(pXv4|g?c{`UACl(t#cr4kTpwfrQkRd'
    'kyZOlAqoC(6p4ej>hetU;w+!~rMb$iyJT))r%DxDhCzeP`c_SBiJ)t8-kj3pE$79-Fa%@=sr7h>#Z;uY@E^k7HPD(DQ}JgkzH*$X'
    'WyD&cy+N*`a<Y@^g0|V2%9y=-HI>HvIm+O%ySHQAmt414-GKqyyufFexvmO*+ng`2yr9d50XUtV=EYtVN8jkG8PTY9r?V)#t!=I^'
    'O@15;r+DoKy}v6Hlug>U4x|}kWtloD$7HTpr3-S$CUSBP`D23Rrk`VZeB@Id5k~0y6!)WoDV)=^$fgBggOQ5y2ZZI8{kd}@;%ZHC'
    ')ROlXm~?fwa}(0JfQ_YE%fORLne@9}LgUyGnIyHHiLP9@wzI?fsWqA2rr0Ib%xXF#91XXL9fk!1{rQ;2SF(+0tF9~CM)55gBjZ!#'
    'eEYS?QH9#`cNOT8xbb{46W=*)Qp~Rx1R;=E!4I?B6fx~R&kT3W@bnz!7XLm$I?H-@;XJ*^%zo^K6JQ7&SpzsS0UIX<k$Jm(k)z~n'
    'M6bkjvqF)-s|k4Cpf{mj+1lFxo=OS`n0^>r-167h>oj^b)<N5gP|Oi#dMS#cWb@tQjYhxxg};9za~U$d_-}j_kO@P3kgv4RqsG%B'
    '%}bd7<#e44?yN!;_RN*}urQ>Sjo>y^bMh3d8t##B!`}A2lnsl%J4<|D_(1^vnW!X{mr9Sv9<!?gXq1IC=Z@p(wwhnmgq{Zvkuit2'
    'qwA+j8bcP)IfEO21K<R8Yfa-~5398!p?`1$D`e>B=n>u4dtkkgW-<O%uKu?c3lyLKlaS4Map)F~T=+wME{;w97rBdBn7ZdFkCeRU'
    '1@57=nL7n6)@kFysW7FT;-BF0AISxAMa@j`5X?+|GmzLZ<UinEtj0@KNBxC9Ok4-Mw@B23!&Z$zSSJiOaeiaJ!}em!DcIQ2XIkOr'
    '!?o?-ezl~G;F~)5C&f~?!kL0wbB&pXV~e0#`AQ@&7(pEpgLlfgmCq$Pzk!c`_YYRYa<}8lw&k0k3}-=S#yow5fVI=jDM)4*?pG91'
    'VkGMFO}xlPQbqR!qBVq{5pp}Q>hI|h;TbXx+_nyTb+FDEt#<$RfS;nr-^M87EaQ$zXf@5>>SwCUQ1C678?Fo@Om8<x!hlp|fge#a'
    '9w4NiX}kN1-51f!KN`pWg25~xmT}C3d^_o0u=MsDul5xzXBgHEjbN;jx7;RVg7LlX;8bRjy;!`GWX&t&Jf->=`5n$Mim!?^I%#VU'
    'A_br?zn!6PkE0OxuB@qBma4Ta3JiTWDvsRCOHin{(|~JVwvT_AtBS_ys^f0)=mkA{C5~Wv#lYQyt#ykfZd7FWv;b6mdllc57Yqvw'
    'QdLII1-J15YBa7JtWjv(N;7AnMdiLd4jTy9IV&dWO$fL0Coh#<QWRZJp7|0pl@KgeGzX2?QE4Kktj!wmbc>XCJQ5n+vQ*GOuEwuu'
    '&4LZ^LOwymInol@1|T{NDO`**Iu<D3i!NSbb*-PPjsAF5Tk3sX<ueHACw95)Ti&irsT75R6(~wwadT^sZQ)690{0TwU@}$3CQL60'
    '{Zy}jBq#}vWEWq6JrTO0^^#(@k5H3{&?=<NK9OYUIfhp_3u}p|aZ8V3X!`-3pOn7b{PB3jO8<rrKL4sVC&T`6y_Jpb%1eC9om=4('
    'uBJH8>xW9q)^f)bzrZj?YNwY$@C!HmsAI#1Is&-qVD#d5ZbU^W55ZXN#gr{S!0^wvIhY#2%NK_eE%(VWXT`8{CJy$vpT<#6a{X#M'
    'fV7nDqMu*ngT3H9rx#>u{c^y;rpmNmy^L`wqVg%>&K%YLCurCV$0H$oKW_}g0M$EqWGm#sFGruez-kuE2?&RDcIIP4Hh0_?H3DFO'
    'oFcD~*jdr~V^`Ybzd=R~kQJ(%>ZapR5|BskkR|;<4a~q#c~J`*B!qHhJ2?>&>wWaW?8yoQNqvq^6?b{kljEJKMCoTFFOa$C!hV+G'
    'pJzrPj%Vdk8?#@`)u_?CFtQ~!h;%qiUsn(a!30V}-jz_$MuLSP9fN~lW9FTXigEG})M_kNNf`v*HhCBbXvRZYx{qoO(5w&Ac^GJk'
    'MF8`)g|HJ8dF@xaxW7|HmwPu9;gv1Y8xW>rcmVWA!Q~~lq<zC%V{xt@hE7?dS~n0V@>Zq8HJx?HoDG_F8a{LbTjzhhk?cj+3>laR'
    '-qC>)MAD*HqPrtJj`mT;(&Q86^a;=|kThTX;A!F?bw$yCsaNNF%<cXUSy)?7jEAP|wmavXdReQ>NTC#SImdWT0%i1L|J(%qI%C|>'
    '6&X<{d{Rdx<in4Q?20%*e{;5!bIPx)o7|X}sjOtw`-FLoO&r=);JmlWW3SgsB@(OUmHnyhbI&nAYQ00{W*3?^@Ft+5T-iLtq!pIt'
    'ygCZ>uCJs~$WHIgD7{fxZ$$V8+!wR-=8q$P<Wod?k?Tn9K>X56K$DB`3O?hY=+yU?hZ*jZ2yB_cxTF^05yQmEJD{7HtKiKW;DWQn'
    'Z`3&gECmH$f}&6@<klL-sAh$a={C)LDit*h8Z*R+spe665}+#r%i3wJ;WP>4%}hP`xm=T6emCf01W~a^_mXTa7C-8E@pPEV(CebX'
    ';6Rqj!s+rD(KeC<dWMMD`gjDJC9!<6kY6y@2GTP#v~@tMr?FrgG^;NX9S?l8ApO5$DsKCl`J4fumgt3h1#uRs6OgTv8tH_qg{hqp'
    'f=chm@<(=TRA0`NNDGx5jNk&ITZ(OmGj$0QcOsj61*?TpK!D#Vzrt{_3F=Ss<e>w5^Bc$8ua#0amWkdLIP`=|g{8zAVFNLvzDfmt'
    '12iqu9xw8vM=@KXF}9TG>ohBxlj~Zqa*}B0Ild|CKq}x+yI=<^){!-Qq)VPQ#jR~x^ivsg^tcE1apop1q|JQ8-VMUN4j1^ool@Ns'
    'pcnZ7S8Wyx@Y-B-p%c<V@@gRaLDL<xTQHvKA9P11lGA_D+8M(q=rVa)R8i|5=R{gUd3nfLD3gsunuoq4H<#SZAlnHh1tUa@2Wm}b'
    '`{Zlew=+Lo$0utma%Wy{k0OXV2MiSGvXNLV2~Ij)a|<69XlT9}Mm9f|u*!`<6b%!rs26+7OZW7QdOw1_*c4Yh1lfz`>_EL0EHR=8'
    'B|{_(5v=xYF+8G5BzY&8M!HxhxumA`8hk;$QykSJWJ$txWXDQ6u|dGIM=4OUA`2ut$ya-1R&I{xj}6H|>AC9U<GVDsL8bG$p)Xg6'
    'a&K_P#>tw=*Gn?U+Igfnjfo}Sg~nDrEivtw*_`wr%Fz8+;;4zRM=0f<1t{!BkAJ3ET8*+YB;p7Cimt^_t9KdXE0{|2uD(QrKc^>n'
    '3t<NzeH{B#u=5{h*Q(Usrz|QLkW_&JSVK<-yOoT{-iK`)ByD2IMsst{G6+?#v~ASKcsDS%*~*p0NoW0=gqTo%gY}l&KY(j@l!k7i'
    'xQc7vTw%8<842udq=n4DDWDfYaSpD-I}DBQrc&rf^77OePuuiY*K&;767kI#Y%Q1P2g<UFcPIOHXWnsM-=mawpQ$P@NWSeW3se!~'
    'z@lILFdn`M8UlK9hbZaf9kas`w41}5>&0`ARJYlR_NVAR=P7x)k{O$UVsa#w!^wXK_~H5y-29-IKc$;f5u**hXM^pffF1ArGrqu}'
    'kIC^1@Gv7%A}ZOZS>ye5gZZp9AG})~++#w?Ubc+NXs;c&O?&pFrUeV1n3P>c_cP$19v?%jnHROx88;qk(zV}cBPQ1rDy&ugY*nqy'
    'Ie`{N9jM{l5%zgD4GX#j;OGZu)jiWz>c;%u^6f-Ied#l%p(-%8^{q;zQ~lDr;Ft7YYqI4~?@6fA@>T)OMaoB8WV#?Fadg+bW*2RY'
    '0oKGxT`|#7NN)EZxAB!HFKC9EtW)4XA~p=JsJYyMr2dX;vGTE_;Z68<u;>iH6}){l7%i593i>8ivcs~vfffr!C18(9<W{R32ly&I'
    '#M~#YlRbM*j>)U-y&D$S#~AXPY4r|aga1udAv#s%_g<>5#Jnpx8<~xPyN(oXq}=k3`S592QoK{*MvU~KxWJZhjT%++b5_AY(lnZo'
    ')><KF<=PA+q7wj16$JW3=@IK>XIk}7Vr@KwVDFwh1FD?fxg95TTu})=?WJ87VT}5L5+a7=VbX%d*MmCh0`PDJDWLcU?)PG@kjxtO'
    't19^DHQ66Nq#&-%nDH09c`SUuuLnN>P%`fjDy1i}U>52vS?W*eY!jZ8jo;8+_}xv}dsTrn3DOYoQ+|?UR%Yf{yy>1}AQCUEVGN$J'
    'ZeOkr>BCz{dWfOhg&~XSy;bX>rjVn|GH+RZn|W)nV)!$aUK3(XX00U|SJw&E@_xfHo^~oyikLcXo6$ZxCzNl}5iPii)h$kNx2Teh'
    'n9&k}WfqW^N9_`8j~MP%rKY4uFnCL(-SmjRWB(&TYktFS8j*GSF*jcn=sAaRA~;pq?+K2Zd7Y0%-cV0&X5PO08$27yimueB62Q^2'
    'c{poT@uimsgnXJ|Ak(2-G%xA$(F?)@Jsb{K#|w)LRl54di%fhF2>gbIp>h)RBgTB3>>d<Wjj{}L9&diqr?UY7mC2faYx6Zch&QVe'
    'kKSF%Sj*3!Bg3wih3BKtj8;bb1P4*jEhYOQo_2&yuCx#12T4w@iCi9;E$#q$<YH*7u25g+(*!S&vDK#$(rGSKw7<@_da=8l7mJzB'
    '4vJA2s_^q%$<IOUiJQJ}GeeDx97I!&rPeq-EuR3kHlnmM5|^Qr1(C__N(y1Q^a+<;&sb1}^~jq}_J`CrFq10qz=bp)H7HR%oXPDQ'
    'A%kaix8O;0I6;w>jArq_du-9f1hhvASv+Bqot~J}ALD>Z*7+&>il5RTR0@r{Rkvzp2SF|XQeKxlTCF}Co`8AVeIQwtt}<=r5azbW'
    'x0$^i0i{-#%)>Q^VC{ndnBo_q@y*J)ecyaSD+!^ad`ZT-%|+i~Mt1OABY##_se|GX=SE2~6V8GVme=s~m*q&RT4lEC-pLuzua+6B'
    'a31sL_5&`fn;cU#{S4lyEf)(znSq=rS>~fLsvIg5*>~}}z;2%KtkZ52sL-6<h^Z6>W0?xb^G0F#&$BHK3U?r%Gm1**v7%ihqG-z*'
    '+|33<M!RH6>ai^Gix`RA6jcA21BbF{3oe^^ePdps0;VLKfEi32LJfXU8AYZrUvzP~Tb%R?Z|8V%RchVwk<=TmsT6&iv-sNj`)f)R'
    'cJ<ydC;>P;NnFs<9lB7gw~v=1kVy!zP5C<`r!GTFZ3b|Qk$Mz6i|>tFp}D9AKZTu6EK0*zn7vL<rH+&qe8^e)qSSF;Ll{%fS*gZo'
    '9CT5Gwe5oQFNbkt_Rj*!mPIF2P7f}%^v(YwOvu=X)}40(f(ZUX!=|10rq`%XMz5ln8!k{3BcO`7^X-pn(?Z_rVLj9`XL3e6ta|i{'
    'np+kXr=*nzOlZfCeVT5coa}`x=b^z1rI?*jXq6P`N-bt@b5jc_u;-*Hgi9q^(Tx8GR>grr5(e=5tMB_*b|{KCJbkTChS?@9mL0St'
    'xf{`bOLY8ux*CvYH=Dzt-A<kGD@Pj2ZQnwFvCicdZ$Jnt$UO#0U5<5Ym8H`6BG`I`BVQ71mJL&5X|yiUd|Dw7yoNJ^G}TKmh*`!O'
    'pgA~Extc{M>(WUUF0tw+4PEHu-B(`aw@$Hsb1-P6aQ8KJvNWzW0aPK0Sq~PaMqAw>%VEboPmm&W;pnw^ATk}7I$mYj+3(zROO}jB'
    'qt-saVA4*Oe32$r`!h?y{ee@u_Svrv@kqtqN#qv0M!(=vV{^qmcdnmq>a-tj+ci?dZ&pV0k<9Nz`|P<$Yq}d6SjXQ@&c`tCPcEY0'
    'obD)VsJw_s)xlsJQ@XV-BIxnCo`Tt5Y}g<W=7}(w>@LRUK93-34b1zzaKr<9Zn1Bizpa>?Sk3)1hMFStB$Q7j+kzO+=Wi=KTAGs6'
    'Cj-;O>_t||`ewsD3hHRl;?|01k_Z4{>mILIF>uz4%Ij`MS`P7tW@>IK2aPi%<~i>iWgmaq2v5`zKVTk#W2wP$ul~@23lzc8%VMm2'
    'bD}_-b9kX>ECF|zLKS32ZsOyU$#3X;S*Em|dY85uJ5}j3%|=8PFO;bt^I!@5Ey3TGA?bs{Rz+BtJQ)CPqFAfa<C*dX4#Xm1B)p)b'
    'nd#Snttr0a$;wsAoTDP6*4)Ry2X5=4|31(HG3md>%h(6IU;GEHN#11~DQ=r7E+HMT5L0`9_1dy}o90spHIn*@Fb%B6f9<6X%uj}l'
    'Ko*<MM`1L?Phm*I!AKAgn*{&BK_^rWu}nVi*T?qA>b)+&ecsI&H*+;%Fm2i9>a_^Zz@tmcVcIMVnfL8pr*QTbt>4bFk!hrP>DR?O'
    't%@`-e`vq+SBE{A>Ga*(BmNDU#>AR#k@3ELFn6e8^6bRPDmf?|8iLz3&4Fe@8o+!)@BVeBE9(9@*Q<t^N~~azfqLwdUJ)?4$DuIY'
    '8!Y5ayy5f$h0%~+a~=7I+DX04bN(-kw^|p>Ke9VulhO-pta)2&m*3#zJA9jMv&h}wPqQhE*=R$jXwB;tPy$%c(t5+xfW5lc4%1y%'
    'Q+Tg{L&6rN)mvaMzhAXJ&tXsq0&ndw;10XFXy2r*K(vVw_e{hb?d8x1yd7Z*IuQWMttc_<6ORBg<<Z<rN}^5LS%zE`q9FwaP0S9N'
    '`Hq>$wbu_0Q}sw_yj`350E4#2j87dqfEhxL%!OLmr<0CEHA#qWaPkp2#P0BVt#c{*Z|x=-sON||pwyP$>{qXB<674T@g0l+Mc725'
    'cz5VsP#lpQaWgTf3=q0qF_3opo14a`OX2{V{BQ;i$ptWUV)p!4#SUaL|HzD4*B^w*v*b|KiZ7#{%kD$~eA&D!+r^Z26H@rc^3JN9'
    'S#cKTI3wEU5GV)lwA?-yn?S$t0SwV{ap&K(wLG~CqgB1AD*$O}_m8C@mtIpWeL~32g|zV{L;B`<o#6&%7Z+KHau&`{uu>J;X*(o-'
    'w4)~cNEbP78(ZotewjG~P@}$-26#Nb2Cf{XFQGqs{%|-zmXKSmH2qYJfnC^aCKw5v9y6P%x#LFOH##JlRpr)AAfmpW*csp>D1Dl{'
    'nMYr<3^{D7n)N1~=DYPFAEEAX)Y^(YdEQCi1{oj`J)$B%*5D4#W5}ZyG6Yo;@sp8Qa@%yOMXR)j5c-8|do^ef>p**Vme#`w1uHYo'
    'R%Z|EG?7%rM)_qoNrx$@`-EJ_b&7P!#Z0p4YKR0MYTTZRvt<u6aJK~MvBH{qV^b8qeOC(<GYF;F1`q!ml;QAp13M1lRfrupb%#v4'
    'IxxL_Vz*_>Qe`AZtQ;Kc&()76EwP3<ga;v>K5I9*ofO}(uKpn|39+6DG4OYf<~3pu66-S2*x@(A!abwRo7aZ!`WMdq1$#G%Ow%Pg'
    'wdboF$HnL1i-<RpV9~(P>ud)wgB2$yd~e#OFpRkjDU}MQqX(GkOK@g1*-gCF=84#M7A`%$Ve#;L!O8AGA)FxTUYr26m5!T_XYh2Y'
    'f{Fkf>tLiOuFj4F_Y5_L=~av+Faqo3%i)+y=3uN^s49TOK(I(9r|n*?9`&cjgRT-xV!97Fxem*hZaWJ6r<jdgjD`{8!^J>|BEGI{'
    'WBxs;th;@B4rB1PGhp1QXJAS_KO)ZrS=iHbog!xTO0uBwdGhDoRLF{Rc>rU9*FvbfFGW^Fp-1@nJq6>WyKD;zNUv#61&dglj?J+o'
    'V0CBbF!ve4TKhA3GfhmskhT8gI^heaFydOGpr%joD~$6}3=J-n-7_Mn&uyv7&igU1@){a-t6lZ{sop5~3Dh5Aop3gHxJ227f|rPP'
    '^Rcq?3IoGrcHjg$K4GZ!&@V<1ccb_zj<&P7h-UR6jPQ!i+>b~|a@2o)LCmL0^E}r`WW12lzgL6YojB)>(a7`%7P}#Y#ioS0@|6mi'
    'Vtj(^9?m^+o=%Bn3t|iofz8>s^c%!wWmnlnCF8(m4Q{%iPe67=<xYt9s`~x_VsVYy>qUY!dV_A&eVciKGPIqCn}awd1viPoStM_-'
    'MrwHgon^8z_cP5yOG)s4yC4=Y0wADsJbM;~(>!r`<4b;(loA-WMb~_n8UG@)9vAtk3Sw)3V-z~xG|Ec=+)nZ>;J!$|L4+wU8!4q|'
    '%IC%@tqyJl;T6imPdh*I22J__W(^uRSvK!@sJvyCw?qMKDR7IKJM!E`VS6CG@rM`h{HTB&pS7t1C;0*v?h>OtLdW(4Z!azJr=AaU'
    'if<(3LG<T{)*EL02G#iX(`YW45{3h_u*@YVvs#)p7a-CjnRXLUNWAk(_unwU!Z;7VDiz528XckQtuXMRm3#l?3@-N4Fmb|WVxHb0'
    'X|7oG!!Ev`MLP%-lew25rB{fs2V2Wga6FiG?JV7S?a99`ObvZ7p!Pk=(Z9k(R4pGI+m^xHCA()+!9kQ_^DA|AbofEQuNhVvBf+>z'
    '0_#l-q`7di9L_kN2NjXr7wqBAcjFWdu&rQAr)a7t(!V^6p2O1Fzu321B^XwOZ$}=wrL=i{=h~w&-wyOptEIiRf-XJys8V~`<W;b0'
    'k|QOJ3}O9%PEuhIli>ZT6qQz8y;VF|zh#IpWOCfvj-4#draQj3xt97Lv$liIStX6g+kjZYY4%i86vN7TU!9?|L2CxP6U*g!yE4Yd'
    '<)^mpVaKKCQ#=)4EHydEAiHsPtH9!>n&@*Rs<&1+C?F&tB`5RolYjkA7Udc;w3L6smJQbd|FiT8hQCdF=DP}&$k(}+6Q%M*?l<_@'
    '_u+dXj|Mdau=X1n(;rBMi86}<_x`AOHX1rv=|6{02XjT3k=bT2cPMMb;jfttM|xA>QQ&GXUE}qp!DrKl<cU@DY8lej$Q(o`$-zq6'
    'R<6%j0r^C&+o?coQk){ubP5OV%&NBCTRZ>SR8BFgH0wMGkZ2i3&Y<n-K>uzG0&;e2Ni#I~zsrM$4Mr4>nVaFf$-SWg=`!;S^g}7~'
    'gCY}J&um&RHuF*Z{@LQJYUCSL=<$XKvoEl^Zpim$BU;cTV)QvOhJTriHM?*@QfwZbN3B0)PzCk59acPAn%}z=lOU!1ie0rQO);NL'
    'jBD^$DlqdCIC)wI4tvGqCdimw$7g>(tj)}uR&nTU8tfVAFOa5z5z+5&qUL2WbF5TxuKZOGHy4=kLNE*0KNwYWAQB=+u-YMFzO0=Y'
    'ny?4}&&7(asE8}cAGJo=6lFtR>Y{V|T{(hc#j>tp7+FpyClnXXrHrjxGK2Q;wai}J;3W=qu}Ii-*8j`3kmWlul5}h!NL00kPA9ml'
    'wV^@^u6=KQZH4vqIBsvHqtuMzA_xxQO+4ttEl{m12(Uf4)LiLUXQ#=2l^cUyxKR-XElbIRP$tkHH<bzoV}KOTLhGAIWj~~O01U8{'
    'wlG%V<mRBo@dJY8_d)%UX^OXMdx<-siGLvd`l5O>fRixLNTNCBelyw+4BC<5Q~vkcK(!$ioEdu|Ys+1}$t|#MF~ILfAhqrMrB5~T'
    'u^W@iP$Em26wQ)1!rE2i&5ZI4?`NAsfbLh^ME%JQn|zLCLiv?1iD*vZe&q8jSoQ!wIUnlwgqsu)AI_OAg%g_oKUD*3dy#sJ3LL{>'
    'VI=>?^xS*gE5I$r)wgG4bpaqArCGFs%925k{Z7u@QmT1VMFZFajra}=W~!K_!q6P;Y<8ynEW!`<C)l#~9KGUW_WPjs%I&0LQqp2o'
    '#p3S2_SfyEPRZv|a1_{vNkIn&^BuJLLZ9AVKa}qoz#&^-0UKt|`^#62U|YM9*>2(Wn2Fcx%bF%m!O<KId@+i_5$x4(QVXidfCZf#'
    'U=#(7;}jOH>yuDRcp%G*FNZ}EDaOFdV)`3ie!L~9MeQb$bn4T6h2i5LSDD>Er$i*-ud0r=9e!qPjZ8^*FC#VFNBL`T=Iw3PRLD7i'
    'b{xf92M)P!_^j%wZ#39q9ncsa&PN34w~#7Lp@URyUyEx$pBj(%HojdW*YV00|3Cn^hCQ9%k$RWyvd9xMkqN{hLTo}5H$E6MIYy}e'
    'BEDd9AZCIRpPx*PsxObH{SM-8nHe2)Lv0h!Vp41_*EZZ`pxMq?6Pu7bB)i%oBjspuB!A`^D#U3EybnUShx?LeiNp?`2xG@5&*0?f'
    '$+g;w&2^_-%Gm^FQSg;uCC1Ag<t>)X1Gpqb6u=+TO`(0;hN`2=!3`e`^-bm2W4@9~IIW-de!Yiy1dwVoQ(nfmI=BfZ+{t7s!F0*b'
    'L}&F@LB(<_w%uNOi8A{i&zr)ZTPw1}%m(}ImqKgqfBa%&ZCLW~JuPMY{o6|OrkhKbMZNt$mO6peu?MO%`?!EktDZ=%fap>Z=D0w5'
    '@F?Ld8Xa?JKXvHcC0IDq%u7|pp^7c*U+a|o(@#ZW4v^In)_yx}ty+RJ_^8gN9Zj&6;5-}Q#gu&e<acAGDo8z_P7sZ9J4i3O-G|{G'
    'pGYvAS52sTfxSajeoTuFZLsKfqdSUh<@c+ZWuWwS-?Vq5ItMhu`mUYIifD$Sz7iR=ztCh^o&0n0)R}9EDY^7HSG?N(EFT-Zj(CQ7'
    'YA<IQZm41-q~_1AJgDH2H)2=#8>WTkXCrK&#C`xN4qNmuM_f9uNUi3l?Y&`2%Y<uBs=>BqujO>GuP2%>o^n-ShwCX4k<4HOMz1H1'
    'O5C%OYevCr)pO)rWPAauFP7%XNuy{6OLoL7BQAX%L@kZ0ne`AVcB8}LTQPs0E(m3d)X_;qO#U;q+K60;iItEEf1T=J(q#_dUdv!q'
    'Rc}^#;a`@;hh$Y(&DdCl3?cgh>1MrE`#JfN;A75$$RHX+67uI&if3rP_j#eLoCyBC;?@$>gxj337xd0~-I*VP44Wv#LWQ9%{ufIO'
    'TSkb}AK|`cK>-<Vqv-8Ow{dp^1w^?sXA+yOZZhtTz1~U*wRNGV#ow&t{c)vc_3W={jKiR9QQq!S4yv?+@m=RwWBt0Oe_V3BQzul('
    '8GQMa9$|sRm}Kg}naFEX0@Zh#hke-+c-vyEEyDG+q4Qwh`2KF|8E+ODXAQr-CT1l#+4}=K44isJk|k`_3dHq_N}K}iCYjkj<!NlL'
    '#`kG8Rvgp=P-Os7s-;6+lf;B(R#3Z>IBicCdgU`b``kGOP&=+A*UxXQ;nbZ?g;iWDebvuadcq~vX2=7z1Gr+M{VT-veLsr6tAW|t'
    'bz*889vRV)_N|3mN>MfMSgt3e&f-POCFtx1|90^ENu>U41eLiF+uF{mHG`$>uBozAPd|AY*hDiFk^0|cC`WrHmB8g(dUer3I-z)a'
    '-nr$|L0F12kK<XoOsbz+@$^$A>%IVDyJ9pjG$!NK+jBovea6=QzzuJV-&|1jS>R7@6d!WR@6!^z<W@>sMaTVP&D(EHx(}qLrSphd'
    'zvVu_o~HRQ6i?piCNUEEe5O6@HOiR0!jhVXWiVQ0M>|n*B}srZX%wDi<{c6Na3ex89FBgoG-}$U;oAT+oAoS}R!eAgu*!ciiVyi8'
    'jSBh>E;R?HJ(F!}^Yjow7D27oJVJWDdkULF6MPQ^DJ6s;3^8^uuH(@ELfUY&A^nZ219GnXL7D8+mcPhel+LVcuL9#~dd0Ap#1cmT'
    '&sy6)AKkt}7{zFgq;i7~3K?c7WZVLsV6yaWRZCRFwsc9P?MD?4dv$a*`enp_IJ=h*OrLyOXUucTgx_owJ!wshpz+4mPX$#37aw8g'
    'D>(-N7XbpK@O8yUp)?9p8?0jkGd41q3U9Ka8Vf74-J^%0dL+OKU<GEh!tcCm{#FAMc8Q=Y+qK1~g}CU3kM5zCNQ15`T;9Yfpn-R)'
    '=x6lXJns@yd;-9deh`rywi_L+@CU6Tlm;kREgj(C6CMPss(fiLBq4~)&Vz_)4yyd;NkqZSKKef}5JWZ{)r4DZ487PDog<JYv~HQ{'
    'Q^fdh_Gt)nZY4L0F%>cl3hcFR#OxJun{&<Z84-P_ra$RXm1B_=kW*RD)S)j)R>Iu^?2{|~vj^WcZ?8z^6xJ<eAOpJ;=}0ILBzb*}'
    '))ULeITqHGOC+6f)Ou&Pyl+f(54=tY$8%|otPbsy>wuWGyRz%*hA{?D|4e7L=oil_RTBnTTC)3!*WCuy@wkeytmT}eTYB%=?{Y@a'
    '3~=c;<1B1{8PU0=Y&4p~?*~0*g9PeGmB91>`#(*uYC%K{nECe4dQKrNSb^-a*?H+$K73X%-^gI~JgJWmtg$&Sv&42Jv`f#Lke;1o'
    'D-{He_5}+=Q3`jw^LVuRr~;JrvRbxrD%@=;@Pad)nSQh*dzya~C)n#P-k>_knS*p>>WHT>8Zjj9P6+V$l=X6*aaFqbr=qvnJ%;*~'
    'O{L24m2v)qE=)7$gO`Q6MO1qYjvVJ%sK=$Sy*IFQ&OK++FyU~aY<|GQ{$5H&DL%;9IB(`09&=Ky&xhaB+gw`YMAKr!p4?i@0v=ir'
    'klw;~y2>J$x+u?=SgP_fO~VOC`>^8bPRAZ?hq{_$Y}HX)c>PVXT-zW^s4dG7Sed6p080479S_6E&DeZbZ74k5RY_LJ+uc?>86|v*'
    '=Q3;KBfr)9T<N7{EJj&u*St9W?Odb<!NLMET+b)Hk2#v-O#^~-Gjm+4G-ud?9Wx@F(&6y1yRui*l+%ls)W?hmn2dc;u;}Hw8-RKg'
    'CW|a<3?a<nOLVbV9^%IbnMc`3Un-_roDd!LYVCE^kw|AFzptf1+;mO|<b;^AuqU_P3u+u$Y1tHyDkRcVjaA3FwrsMDVs&beg?ifc'
    'N^d!Z3~}lqYJQCI^EkW$X_8Q`Y~=i5nAm5Mj9?crfbB+5t(B)%4L!;92zn;O@ykiJ%*BGqTzynCm(hK&C;0Lu4|^>O1RN9DA1?FI'
    'wV+uhC&B6^#vj}5sDrCcv4U*D+gEl@)H6fCTS`#O;If6Q*OqTpE0Mhg#KyrS@uSB2f&qs3qQzrS>E=f1N8|RqK+VSyc^^}^?4(T3'
    'h`Lc1#&-)8Ca48aIXl~#)hLWZfuiK)Pxa-OG<T_85s;22dMH}o7sBRHad|a)#x+7TYJi%fIJ~NyYtzVvZUDuK3LOaE=EbAJbf3Xt'
    'cL1CxpvM^gSBm@J_mj9Sv`<=NPO?=>f|?V2QawjU?+B+Ddc-V-U~_yj+%**!pWpAB8xJIn-uH(nsme7Q?jxyd10!urquUaut)dlo'
    '68O*`3Ch}lF4?tD0d|70&Wd3$U-<LdtC;8jcUnB$sGP)@I}*aVfD7>-ydJ6MEc}Uo()Hx!pP}1V!d)U@J?mmF8%a)?Q^Ej50Ygty'
    'LrR~bup%()hF%~omlYazZhj(j{pX%`pv+)A|2#K*xtV832?e~770k6vz=Ej>=0_1A|4l2j?Sg7YXVhj_KVk0s=TRta8CAfrfF`rw'
    'a{CNPet+VV<ub3egL--7E^K8HrZYS&*<B$}>D*)5&MC@+Bgj8|zd#>i6xm&~%gI0{!0*V2c1D>+@=yOIQ8WQ1>XT5CI>3E%Etfkh'
    'i|+HQ*mZhJhG){H>|P8EU>`{zawcD-fD(L^F`P^&cH#hja8tO;gqE7tbu9l>#8@zg9m*-M{~FDfDD*jcc`2}0;AlLrMuVcF=@0if'
    '^Bff%hll>Q|GuXZS)-=FNHKwHv=F3>=S&^Tl5~e{_$~Ot(oer#;G=)7Tq%6H0&#Z3?H-;F-TQdCOs#XVz(NWKgjx^oE-l8F?lA#{'
    'GV>xrwHAb=>+C+j@6F1sS0<aC{<(fMoJ@r$DVw*r)-}x6hSjjjeHWa7Y+iCi)*_usT&Tva#oC8YkgB54#oost<Cz!JHUEv+uXmN<'
    'VRZ}$h!yZlE0tg{XV0b{eZAX|K<^`)R^>tVT%M_}g)aBP5Dv)@{F>Iu>3c<nG?X#|%A<EPUf_1K2{bef`PL$h2JxWPQ%GtFBzz$J'
    'J+Y&()rz+ybt84F+{w0|uBYL-4!S<E9G_l(WibOq5UNsx{6_eumg`R6d}zl+-VU;K-rdbJIvyk2Ggr;|N2XsnW%Hzo^btlRCSklR'
    '5)R%T?Oma6k{KuHa*|hTUDe!^Zk>vWj1t$C#1g+YYB#Yw^}QjdmSXj){%VLW<u30Yx!OE*21}>7(9ikjiUNZS|Cx!!>oY~k+vfrE'
    'LoidWJd?re=%Adc`77&9J!76VFSk~B?a%=4(megrSNnq@@O=p%5>QX`%jz8hS)W+FJk?B+yZ3wQF7<Jmt=|p9rRGDcHLGvJ;N6iB'
    'MfD(4#CN(hLeD3Y&}b)%KWonx;Fsy9%hlbCVJKM4+zhM4=Bpqphd|t3d>E#S`Cg?V)zB<I&V7e7ue=kO^cZ1zU;(^QIz@Q@m2zjA'
    'j=J*IPRx7@7B%{1VltLxCih$ExPnKu<3Sj)zD7SF2=Bd6amYIR0-aqqocB)<uLdp{iYheq=Kiz!JvyujUP9d97aO;(ARmwbfoHvJ'
    '<iQa(%M{z3<e1+In9ZoF*FU1PvA5${;S>qMk&V#i<&E;CuUnmHLGk~yD{rZa^xPG?LuguHGuThDDx36QzPp%(XyTqOd>{yp7Cl6t'
    'Yv2JZR|bO*PuD@)DYLlLjI1da>dVb1Im{dMWIR(hg!ym9uit7uIzooR=K(@9^7Zz&F>58B25sz$nu~ue@ql~C%ggiWc>v>wL_BoQ'
    'PK&jmDGK;e#WN`!B5qN)Ya3)%o`X`xxSAT1u#7vK65n!*+T>NSoJ7QNWUW;Gh}oSH+t%b&wk9>m3%I-eL~}n7sZq~q1&%T5X(`s_'
    '(>XjU<agME)e(2oiTqlNs9rF=Co%#9dNSyVd{?g3UEj%mI_fB@!OlpD$xAcBzT5{Ep-(1kQPym-D%2HWh?lDR9gb4<TxeBm?E-}d'
    '`Lufv<&RCW2P7nyXKVpES5n=D7(j@qa{5AQzbZtr5Cik>f-O})vij<>1oV^)3v5T71Ch?BeV;6PD~*D@ze;i?$?goUH8(qJ`-M;('
    'vD;kCDiD#TdM(deXHpCV>Mo5kvql%mD-qeYgNT^3_G#8t+!{c4GB7!>NGKs&C_yTWo3_OVC_%jziR@uVo<+DqPiUH#7#daPlD`WQ'
    '4+?y1v6p<a0dEK<u7U$5mVR-nDQ$T(f^(JYz$C!QIehowdxU~n3kEUZn&&<XQIX6c>D3<)B}jrbs2INN;QXcXu2F_+mksZ#5-ZzB'
    'y^g6&=OS5gC6{n4JVk${S5_iN6v>7iktx9;T}$Ib9@X2fRel@(YfU{$Yu~+{{+m?l-GN62&y^9dhxJN+`=@7-<el{dFIcP=b8JB)'
    'dJM@@=?lo!<k=dCJ-6No=a1geT)Roenn7l*qKwBSW3w~s<!fI9LNhMZ_HZ7!1J7v7QoklX=;<(%_Cd8&3v8#Lo^z6)1pg<P#w&vK'
    '4;U`{$NxkO{HSJ?6({|5;Z!E1o7R0OTl}@OZ!+-wkMaEHoaK5#)y2`?q|=po&|XtK@tW{N+{>cOLsTy}W6~grVF6u#A8^IrDQh>+'
    'I$Of=Zs;iRX~_lXrcZUAjF+(!5TwNgelf(U!}-k2XYL_aI3P`;N-)F`9BS*5pywv@^`gd<3q?~xxiTeM=r^<{ik5FyG?0I>;l{Ae'
    '#L$5`p0}uv;DKip>8{)O9x#2yX?@T=$fzz{4%a9$o}kHqC95^}_Q8rYWEJyE!%=`-kH@<;;fdY)JtJkBA51+%aa@f#f9TW1d4tY3'
    '12>A}hMa;FWYRPgGFI{W3Cx_}3{r_LU)NrHs&LnFIA{fG5|Nw4;&hWQO800#2+oE_eo@GoRh82w#Mox<1V^SJzFlT#CZ$1(8Py~0'
    'u>UvnK1pcmj#_U?;krzIJxhh8WRQd;c%RLQw_LixqTaDH6lE9xFXW&#x^?f*{&pmCKMX~Sp$|2ZCbdGR{V_{_ZT6_@Ai4pfgLAi;'
    'nU21Y>fjU*b$O2kqSC5|9#XxOt`B088`AY;=@Bgj@BIIt69rv_8)1lXWu^<lDrp;WzoPvOuk10I<q%mTzZrUIOdM-LwplLHsEEpR'
    'K`ha$1r{Jc(#9A9-H;xD#^2z42c@H)*(8<fNJKx|h}qTva;%>d73>VmCna_%Fa&Z`+`WIzOR{76dz6YT6a{B!JT#cbiBf*GSe+Gs'
    ')*U<f-ZbFtv%C|wrx_a}Q`jOcluc=xjBA?L7Qx;;jbg0bY;?2VXRVGpB>XGAth@q7egtD-5So0sR*Z{X*!WUi1pU+%OeZGQk9S#1'
    'bMba**{_a{2t;XY`5TzRu{8Fy5I~+%oRrR_;$oYnO0*aDM8*0l8Rj$ku6$Lo*rh5+n6}ZzDPWv3Dg_E)Q0Z90YV_Nv3BF88>s=RN'
    'p5S)^eSy=7W`JU%FlGE1Y=vxLJul_7x$Uue#^q$@M&{R#l3p>MVgucbNM$iG4e<_uvjc84l2|y{Yt+-kva|+q9o3M~SLFZT@ycQf'
    'Xy;L@4EYozZG4xTOc&W*Mp6*0sypNf%=R1b9-&qGn)QM;fWc9X+no4QP4qwviaYBOX34~2UN>QDoF=sy&>&)#wD%iiZ`#btT6xL*'
    '*zK>nhEEbTzqPBW-EarPz(rk|vN&!u8{VR3K&W|0g<dii<2AhoPoTwZbgWr+*xcbJl3-L5ZF0)wOPR*Z6n0;239Gri>d!&Dq<_zn'
    'qFlbn;b<)7%w1TjMQBtSQ#?-FX$)}#NS`@QLU9^=^gVMS&mFNnq(NoeRAx`bKq#CAAG~AV#S+{jCr$d_+ox58zoawLE>MrnqGW>('
    'DVA4RNg#^40)GXG0DKY@@gT9`7{psd(-IOqjJ(s7UxdETy!X9ltF4hhHMFmsXVU*>^%TW{_Q5MrY3m@TyL8nQ8YTJoYoSbnJhpy|'
    '2(Bpa)@=7w(eto+!!6F5yGA=wrtjrkxiabPpR9m(y^CZ>LX)c9^2mZ%7i19LlAXTLvRCekL}6{6_P0UkkOGA@o)O0*iN)QELNqU<'
    'Z4M~o>hT)LP(bb`)8_Fa5GlLK$Hx%_4j~)!N59vo$R2Fd%In_TJdEhICCp1~RW9o!8vxnW65*`MT?Ql=M0mrK{e>3VIV6?gu}+}s'
    '`__4+7)L9U9GFgBq~D=L&Js}sc$tby_<`8Q;7!G#i@XEK-c~p)GZ_{f)^2@o>K$g@R1)$&5?UNQj)nEppER=K+JD)*bdAK)+9Hfw'
    '79}wm@N6SR+I3G#%n|Wnt66hu<U~rAXvXGWBO@tUxDkutP@Ap#HG;l0qCe8|k(p-dJ1vs#m>4HoXLlWz^mi`1n9^-}b#7Ldi|Gz~'
    '`zfP;<Y;)zZM`k^rGBU;wZUWP%di1=PqbsHYFG?th4w;=+J7^5sb0D8q29!A?pk3TR)@aZzCVsN3mY@mT8@^T-k$J6VO2<C#<;`S'
    '=OcCF=(jTAzV!9bSKR%KHOG9XL<c#1PtC-e47BV5_+l+M=+e5kx!WCA;Ho9AcOC#R02YK4O}>Gi{(JkrkK&fV&sCT)sGUK6O7X))'
    'UrKD;GB&mEX&R;zN>Q`8^typj+;bk8;)lUcQM$(sk!_$pfZLdA1eaSHVmpB71348+ReG*dhG{h}@^{l5r%GIJ6N?2-f?GT8lwd8='
    '9}B$??^4T^kPD$QMuodQ1xz#4*^d+#{g|QaZbk2YHa1}&!3p*ho%T7+tt4Zt+*APT=<ke<?B&fgNLJksckX0LpOG&xTviHM&0vHt'
    'TxKY6I7|K)1G?!;B8gU2%ErpK&1NZC@Cf5S6KgO7d(_JwM>=9Bo;eY)H<QwS{>K60t7{3_LcwHTjs2jKAHIW>T54+%N3iJkhv(F6'
    '3epoIf%&K=>yTn-E0f1RyB$X`pT(=xImzVWuXJC$-y0&0lqWIWWUSZ7I8Wnjss04(1X=RxTT42Yw$0jidd)-d(0+OCmNFdBw$8Pn'
    'V<3Ysv`m+ibMT$qMCRSqtgcSbBJF$CQTrXNdQ4U@NQBZWaPkHu@&|^Naqn=INTU)M-}^jQa^v60e7-ECa~^qOK`GC~-#9q|dK`#5'
    'Od<LX_ep+aq_<_W8qMQ*Fec&N&6y+svKH}prcpn?eQ^_8slT}P;h=?rzq&h^k;T?NZ&DikfByYkhmp>1cU#!!{5D>*Edf?N3>qbI'
    '(@Ty2viI<^7>#j=i5;1q0K16Z?LGO=Cj>5J1_)_Nk70f&IwtEY0}J&5`tCc>$@Z|2l(QcO7_kXa-;}`S7XE(VCP}b&JcN>8DQT)^'
    'n-Tp2PoG6?Py6-4awHy#S2#&`l8lqkpYccpk4L7gfz8!VpA<H;l}vXF*OJ#UQix`Jlm;ySq#B2fZ_p#DMGz2jeZ)b_cVwdGX(*^A'
    '9m&Uyf2rzJl3fVhrZH{K4vL=1EgR}C2oq3sVKQ$#t2~ogAuAz(7TUMqOt_EFm0FPfNpmS$i(y@}e)OT94=x05eEsT-31y@@iOjAj'
    'V{+|E2C=~*x8x42d)6@oKBfALrT*tsBb=dj^?5q?cb4z7ahw=l8aXGzY1ahP5qk|rHa@Y&&m*Ph#)&tzF4S1D{`5AY+m#!~pH-zy'
    '{5=t^-<TFmm)e8I@Stvp3|*^q*d*|mp+(;i-A$n?X&e3Pfo?}AXE_-Z^aOoFs-dd?0C_6OA*i^47v?K(3c2uq(tE>1^)nBHZn7Zh'
    'EMIM&D#$64W*XNgnlm(*khp#r$JFS99FYDzA`K^kd)L#1tQy*ii4zPdv;vD_c0I&fB(r=kTb*N1QriYaOp^}Q-AXEFq7oVzvF+Y#'
    'PK_5SbBQyZ?S=O3RrdtN*-;p5rF^JLdRSRk;(1+6U{weaBS63+#*oOug5wyd@D49s@b|6;rPXkB)IFNhLZ*H1r$Rcd<W+9mDeieX'
    'CEg|@p&d8BrNmqtb4)13Qz>|re`3A@3JFne?X2g~eVzPIX!Swen^MHjhKV#LITwnl5S(Gv;g6U6J<!u|jadlcFr46U7vUSdi_GDm'
    'X0$VNlmAS5`5d9<eLI1B9OnvU(ObVS9~{}my2{vYHk8-@*9*E~)?rJ?AskG2J#v!Cg?k9sjJbROHiFx)sYowKdH)|IzCSg6vB{BO'
    'zQK+%$#x&c;z184&mhcMNp({Su~{4D4&!U0zQtw<DMhW1m~(}U1|6UC?0+v_3;^a-;1LD`2byA;SF^^|Bf1e{Mgqu{VAiph4iMIJ'
    'sN&alI#F-|H_|?xJZxJ^D!}PiUB!-WmBkpl8g172J0Wt~!av;XB5zB8o=v^N<S-v8B3R_k(5gn~i5`#U0s5s|UHz)Kj`7OVj9%KX'
    '8n!)U%~i9OUr42EmKj&St{)J6hUM80%D4s=o(Q*8$i;tWK`5o9=r<yQs-a2!rUjqh&!tHRcFHj@M^TE{Q{iugV$M!%dCQh2j#7rs'
    'QI7O6xw5S7u?#=890%H&f&|X0K|hY<w7WZ$pz50M`e5PwygNGIY}bq|An^7kdW0!fY#q(RmLA#tqW^(O(kQzoVbmHbp1zB^sA~2A'
    'KQUbQDl8@~ql1UFHUUCU+#8GjC=bq@Mq2st4pVVO%K>{9&`+v722dU=<XIqzXQdBhG5XKF^iQ`ZMoFCrc3&<Vepb<VYH6T4PCyjP'
    '(5M{GUv~1XGQzIm?!(=+9x=_Fn9McqK2od!ag-()p54FSiFik;4_QQor7WMAon!9vj`LJ?+SpvCI+Ocwk0Mb;>HKG{qbu;gag9$9'
    'C3~9ZkOEVny&+QZ?hUqbVz@E7b%>Q`>;Wj=W8dmzoua4XhxT^lMqbqb<mC<~I{~b`@2?u-vAXKHMfEsP0)p2sIt{Y01cO_flsW&&'
    '`@8;4kkS<kgnJ`?^mp>Ky=GDa05MWRtmZ<;5z1Vs&$A6t&Wo}Z2CQ~#Pxn%woengejgc{M-aRfE7LNpbh@&B0QIELUNZwt*v&OF+'
    'lAQ!j2nT}Jd%3$WmVW7U|4iy{J+H%}Ceu0m_8XeI(J$RXdj!Rgxu$@`@~gbte8(u00h2r}8p+%2zL?U<qdw$yWd~Q0Mkq_LCe_TR'
    '>zybFFC^1HZBZU{64frdI9_3oZX5gzA^;J)VcOeJPZ-Lv<v^^uJT3_EV?6=J%(bQ(3wH`%-1!pMEDk)M{cS8pKF2x~BTTp6{j&4O'
    'nYO>`=ECXd&J4XXgIVzkenpoUMxVqP<T=_T(5*6+wZ}&}aHJZ*l+1$r{6C(3DurOUZPV7bn?W@22*4lWOACkHvUc+bn>r&%8<ZiM'
    '+)WY*n+p}u)id&hPp-uzD+o8?P0EK5`|3t+*5G6u7Y~_L`s^be=#gqA#LIEb2HL~s8O7`k$XS@$9{*Q9dyveSTfYa(Af}~@*6ajM'
    'I#s(YIbw6zF8Ht6G@Bf``H|}>xM2utV3VQjxkonXU4@8g%Gxww=HL^dy!U1-F?V_5vuBH$1F3p=P*fd~QfhS3=-i00+k#=L(M#LZ'
    'g@Z4fc|ce9bYo(Y&u#lNIw<X^l?*}*wF{d3ehO8tjwFBsgUtQV_TE5Gm=#T!MerRJgrrH>mhYYSq1Y?Kc2rQsef>zpDI`tB2Pj42'
    'O{WBsMWfQ;ZOifI6EaAdT)eRmD)>i7A!}ROE%f+hL8m>m-#*Z_GK+MR#OZab+3(s3`w8!8)U1nMEr>(x8f)KnLSe)2U0py_Q%Od^'
    'sIXpFtk*uPU>7zcRB#!N6;Ukzm~4#>;*^`=_&ZzK5GW9E^dyDE5v1gq>2eDKkg9Fdig|RMl@^2P#s0V(+T768te^$X>47cKUB&9W'
    'zUwxW4GZ`;qr0n8hmcyw#fn081B7(_KtmaD35<{TKI8(A0=Z!z%2hvSh9)eT;)M1dQQU-g5;JtIm<Flh#c$fUmM=2cL{``Y-|5s_'
    'Dn*~tR>dops_Df$7vbI2M8a9|o|ibWIJnwRo5X`TZG?1dOK9z2FMEIpQ;2-eXr@Lm9QlY!m(J{&Mv`3`q$f92kIxRmlnA;|3OKFP'
    'Nk(qDu3Rlju4`w^ORD0HvckB0V=nP<1`il=(X~RBf!SCEPQ!GV4RP4f2*=}K^`Gi>zQf2J#rK?-Xh+qzCXb{@Ng}wzI;+i%PsueJ'
    'J(O|)ZHQQwhnFJhaspQ254(S?6=2*(#^0nw5nKuYcFVEaWE+^2m|Vrx*_0>|N&-$M@R2B35!r!1iJxtSKa%v3HmJh<F=~zY6G%dp'
    'R`*5#^$8M5nH>&)EYv!xh=D+6Dx+rxv?|2JxO1cZ`p0?ZwX*JNmcL)IeCG{n3++&vYq9o{M2+!uC3o<p{U7o^F(G1<!vR0yG>--;'
    'GsCrcjk=@%9q+N7E|P`|D4d57f$2-L_cjYFH;SjLZ4-ixTvlPD4Zh#D_cFx1^{L=w%y-u<v^Hh<S2c=OX^azn++)~FH_dutD-!zk'
    ';^gk7%`Z9DAJ73KjOP033c$xaOtc0A@N@Z+UeU!uhrJmXuFscO%pKMzGFcz{24GDyvmJ9}X_zUW!kwzTfojh8GZpEl2TZp(bQm1l'
    'Gnleji%}d2W-!^#kO#Rg*5xZ^HdudWn!Ziz!*_1tdbrrOhj!pv<c?^6Pc*>#M%L?au*x`aTaO*+MMXhqN6gLSd}Y3}M$5p%dVlPf'
    'p7)}eX<i>Q-URoq_eHF=pgBZ|(m(~AX2ihP5^&{q@XV~P20P$ofk2yD9~0}1$qvJ|msP4f<ny?_coqR<oxg6L+pR3e66YRx+e%>7'
    ')2eCs?X=DmG<TP|DuE0GgqQ08_qn9BlOdN`x^SWh6M3+GkbOVLT!cfA2;fk%A}DiIjKF?3uA}gk26RQnrd+gyza?7`wgSa~0uNoZ'
    'UBAY-3vIRC5R{@kOVf-{%@3)2PL_~VF3?gafatw4X*gMB@;tIz4F|1pX&cvPEKNe20`_KwkZWEae8J;CP;AHKSYAy$sfynX$)v<w'
    '&x`iqU13XO<l?6rF?c&bK<w%NcqT!QJQLCcNC1Z+ol0>1-BZfBl@iHbl8`-S^SrUOPkGiJGUhaw;6&5Q<b=KLLCLl8C^nVT9~R3q'
    '|M79~#-{R9{>ot0C(x(NCYxi*&@U>#q+caWlt_w(!5lMr(9wVI2t6ob={BqwmRJGE1Uqm@eE=MS{YK~BE)SM5atuP%c9pPeLt|1i'
    'v4SVJF}_Ft7<pNkF_P#{@*P4dcTS8nL6DAgAjA!KeIV}-JUvNQ7mvUKnDK*0m4Kni(mTbqqmbojRwr}J6kiJ{%QnDwq(Oo<4?i13'
    '!rA<+_os!2BfQ8v$4KUF2mZJece_S)WgIp~Kqf54+LyqP>5d)u@&H{CwVRf*Vv-Yt_7=Wt8(yjTm?t1abd@=bD~aU%v~vONj*JlU'
    'BPjOgDT(4?xg$G)YdM;z9*(I^?Oa%TQ0sIk#9VVaA+QDHm;@`ut;|F*?0S(=%V2P^D8;LK4)5Hn$s#2)0OCA!dLW3Sri)RgO$}n1'
    'MH3V_`?3;C|10+N5%}J=p)L_J0?WJ`XtXJZt0+BttK>fd$Nt=3bDrnS3}?k5(+YDNKUVn1R&XmK3#*pAHjMDwBXzK_Gtw7+asrGr'
    '(R+W*9~)1A&;Gs+pbhXwU2F^FU|k*Pws4Wp&d~xDkf&LPBUu`o8rP7d=iz)yV+$&t_@#qffETp^>wOzXO2uj6d+e#Xe>#r=_L66W'
    'K+>;$MjTAgBLLcK+c|n3ba$AUiYd3s`2Ai%!j+%zIxcLbqHYArk~>Z=^C;%1VL+Ur8h*xwhdS00B&p(EiZ9%s0tVYgC!LZT3nN2R'
    'xYYJS?>}2}LyOzO5X@3YioO!U1p4!isb&d~))dG-7MCRY!dc~h%eFodIqVzNS9e>q<&${(8FzYeWv8pJ@$0A!BItL|8P`~dSw$*p'
    'tfjFOE+Xny;8d>F2f4gLNJ>YD#^|~-y;`9#9A4dM;tfa$7*y#0y(423Z*kxjR=<zD<ZpoYa$C$jrV8m1-v5>Il_p~^Lxa`li=k<S'
    'pqc^rQSo1epqeecYuYPZRw*Tu(8r*>Ao!~YbkZV58$MrG<%V0yUh>%|_Nb@-$NFjvg3=0-04J#z&P*8r;=|tVs|8fYw$8?o8<@`q'
    'k<|Oe=eEEGpq*g@5%G*4=66S76Z(EaAWIUvQ7lM$+-oMcs~nwYz2l4jfpu_$9&VpoN_PkvNSWi#ZCh4P3F8&$^7Y`b8bHfi+?YL5'
    '6o*ptI<>FGn6SI=0}$j6#S2zyA&LJZ4n2XL+(2jms6A5fwRCo>fX>%n@#l2Dg)}k`wh@B?zTR<v9#Ow*4#9Mr_2~on`E{^8t+2O('
    'sFmN-3>?Dyin`9@I}61#v$P6s9=8|KYipZjat>>Osx>vI>F0Vm$isb6u0|F1&6i?eIb%Q_tiWHoYFDD=uXY!rteKL9Jk=P`s~px)'
    'I152KtZwy#`&~#84`Py$Z&dNIZ1OZ|=S5PKg-imM_p}w<lJCa(CV#*z$a#AyNg{MCu`wT;(QuBMjKxxWX+^4K7CD6;E*`LMwW4$i'
    '3M?fYi>6HKrD<yC^K(neBmTyH0^_nC!oKIac3|_Q9;h&Zv7&2Iz+?FEKSd^r$d+`T9r`5?k&{*oqxe1_ZSV754R)nuhkg&sg+G6V'
    'DOEk5-#P56HP@miU_s=?+;Vo(!{xaIIC^KGeBr2`D@Iu|aVHV747|xf-bw;o$+oeUf#8?|x6#qZ6lM>Zp#cy+qgQ1HkSr`6UkG3`'
    'q4VuN;gu{ylh|!a@`6()*h5`fi-_G1_;MCnDRrm~*D(-BTVM0I@2~+I6DY&BArb$?Ag0!@s~81w-ws-Roq!h}i-ps=Fgh8Y2o4nI'
    '8vzme)$$&fJWHHgaW<MNLOlh9$lJGXS-+(~JtXwX2>;}X(JhT$nxaekTg?dkR8wt@rYJniKJO${jKb|rZ5S9ZPV8LK5==Owe=#g7'
    '05vP4<k(qNe}7yR)Z>GLM9EXK6TUMdWVDI+Su2w{76feRpT?A0e9|hh4{h4@%Wbe#Ob}l-BMdHfxh1em!;1nj=D!#!YODY-+R}T6'
    'COg6;+3;pa0S{7Fk*-ET75nD66!TU_Q_A3Y)Z-fU1Bz^Dctbs88!BJwAl3CIw#&$ew7vrU30vyxYun{}u!;GXhjp;?0(y6X-kbbu'
    'W#8~#has2uT$oMrHlOu0O_Kw`{=!&>>MV>i1$`vN)VE-x>x%1G)PpPE=IZ<~6sAnVo6nJakGQ)PUAybdiDG2DN(Y9SJa-eFZkPEt'
    'x8mgQdn!Bu3CS3T(}4~!PWT_4eS8(@7{DI;lsL%$<C{Y@URESnTQye10vOfG&P;c|k6gn%6cOE*28KRS+-3FdncMMLK<+TxamF4|'
    ')DJ3Dh26>2lh)-oQ&yP;S!F`QJJMr*MvNEg;xp)#qSf{eaIjacAb;dRf9b~P3_}93NQ|RkuZx}5#K*Eq^QeiO%^pT}K_MjmB*CIl'
    'Qf=0;mV+^hN6bBf^v7nE;He#WV(ILAKs>y7NgnNe?kmSsXJ=jZJ>la!>az_c44aX`P9j~Rwt>-$sultLJp%v_SxHd$t#lMP1e)C2'
    'gj>k(m#0;UAr?g5OPFsJhhasPmyFiAP=?Bi6P@!tGHLaH!nu)o)J;M|bsIfK){IR_DpwL=e8|;m<E&V|p^PtqQRFkQRrlkAyW|(d'
    'S?s=;S$AtDSn|fO%42v@&J&gBviBy?3bS3Gs7F=X+NFm<*ZgjNraGgjLtmC<c0B}OmtEyNA-Ki%d(@RXzaO@Z5%Ermykdc!yA+&%'
    'i*hftx=Je7rg=|eov&M;!LVqzJMG+hrpQnkb05U(HCe77#X#_5^?@*LvBzK5B$PmOrPbEHLipj&c&25(N~D54j$jRUjm$a^>i*XN'
    'sk`1&pn4>brd4(Sv_C!5Pz$Rd_}vTvkXuk>BXUQ3XG;7`rMq}$sNiR);{OCNzlfXD@_GflXjK2yZMJy`aF|`1viyOZbRzNqrmDmM'
    'svho1wvJr7FfOGUicS!}LUNMQuRKlbp)ks}rq2iA+)8XGdoElwa(wi+7nJen86rMHzr!JBNUt0iwjWz?Y0mSKT<{XcgTK&3bvYn<'
    'Kj>dWVDfv0U-w~tA$OxS*V*q0T=Jqq2*~S6qu;wi5^7U&*#1ar;S%XrouE2M8tsJO!5~_yK@rp6ZI@Ah>!BI}l8?6hude0F1<Zj&'
    'cGOCsj7{$9;7IYA8<7eCO+hT3-?r~-FlJnt!ITtK{je;U8PY&h@}HA;6`meBTQ^YHiLwUQMv2$D*>eyAU<#;vDn3)Xrbg4Z%VMN)'
    'o$VYE<@nTg0cjb}Dkv0A>YI|UyXwH!PiV`|F1$@9V{{w4q=PviKszd+*4}Nb+gs^m?wa{&_s=>{ZS1=nrb&IbaL(Q!F7-7c@#i!s'
    'O8IUfYQPj<kCuc#wrGUu*vihH?MszU&WU}9#P^dRlI_t^(zyf3$nIJDk-PD}2VSD7(@tt92p;*H7Q6u&vS-~qImOb$hwIZ+jxM(;'
    'z+H$Z_2r_I>3oKXw=qcKbG|`xy+ms>pdH#sI~Sj*wryg@YH(aBw0b5b&CjmGOo;_Ne<nNBUv$a>4#D6fP}mC#u`{5B58T2$<esFn'
    '^2aZ*lH4YwzasY~@CM#4sXV#!*#D8^!~~b%qQ@u&K#5FwE$p66u}Ew|yErF!2#eR8^y*htuSefZpvw0FT~Ab<A^WH)jU=G|Gs9Y%'
    '+w?iem!PLHN3hluzT>i9<%GUcc%R^Ad~J(}VVcmw`IlpikWE(o%y7J3ltwC!o&UtF#>Rl>yM#bw*}9md7zwYARTWF4e#74@G_8A;'
    'cg0zj>8gA>QGm;fd*IAEw-XNpK~vfWzP5Yrb{)g86fq_BrlrA(w3QV{h@xDTpgG7iAi9+B<j`fr78uXC4|YK&nkQU&4-MG9uo+G9'
    '(_!7596w(O55XR)&FFgfccSM0K%}`~jlM<c^CS)#pbse&RL7xC)bc}bFhEfdM{ylZPUWpkYq42d`iBo9o36(RuvU=H1AM9P>yWc_'
    'pIaAcJpNZ8f}BJ0I<XMJ`MuTjxoTk6j@LnGnIIe!IikH%<;bwT>`RlG9J7N~iW-3Hdt_|`qjP_{p>PXQ)3xys#4g}S{yJ;~6e5L}'
    'i#E*wHRhx#BilRIgd0~vlo@HZt`4($s2vLv#4U*A3N;7n3xk;M)c<CxB%JFVmTlCtvt{;*^qb#uo+<2Kam6Oz)tw?59B~Z2Y@po8'
    '`2%>AgW+*(E4dvcosNq85FsBbik@IwKo}aHIUzbyY^4&<1r$=T(GLM+@)6Dq%H>}%I%!x-BiMT<p8;)uuc)f~r0aSJEK!Wr#yv46'
    '&N}Pf4)t9UDN`!2XPGD!MZX*q{t~m+B0f8e$RD1)!q*`DH_RF`b6rCx`(W^bzyG8}>hloyAJ%`EmJpWSggLpJQCV@BK5MD(ws3x?'
    'ULxe*B*zT?s5^BV0sDi#%n=V8*n(d$J-&R$`y^(nEZ`hlvxEo3fr4Upj&i=j%jXDbBmA`x<aq~Ze1_Arh-@z)gHwO0=)M(EWDBW?'
    'I{0QLyTwU6IBo1aI}G!35l@=+zZN6>7;N06`h@+(fAZj%oEyq6<`Sg-ocKLhjzwXE7R2HDD;-~vAdJ_AMU0)o<BZ~`ZJ=T+2$~!8'
    'myYZo8o~;~hGHP0f_*tL^MzmMTlzEs#AGzK?mjo($&`t<0ddf!w`wbRFW|c$=4%|9u?Y}+;Q~MLaLS0<)w{@|?t_%6_mI_{vL^iy'
    '*A(0OR8oV{H)Ag${1Tr=r^-5Kz@Q-I?`COHAZrt!KtZ|Euy?@~fA!BkA^HRmd6ZtPmf_Y`Ou2eiAcGSn3vA00g8N#VN?1<Y%vw9t'
    '95i&SmXT&_(JXWy;i8AlTQM^I8|(98@&R~59b!dGLj)h3*t*Qf55U=uoTy^Uy_EUSN&ms~g60F;{&gMr)OOED_wECQI%JJ>ZW(Qm'
    'Q^deLyyvsncrR;?_FKVua@`JYYzzm89ji42Vg2T+x-MqF*0YtRk^2e2;>^Jv8uxFStvaNKg3(Mi{FL>T4m<yP4OTDmGXC{=Ayh2o'
    '<tSUKK4(rh`!MA`==;bT|19ijySxC=a#8bJ%4hepEbKzLcrAor=*Pc72`rInDl@#Xb0|_%BMpb<Ii_4k=6n8xd)A~oy%XZM(s{fQ'
    'iUMC<Um$&sWzuK?fqNA2=(<ajg^*6Y0ANin%<=+h{QkiN-b+!3%tait>XiMnuiy~3fJ*v+%=DJ+VKVqSevg3Pf6Ealyv~|*N5vj7'
    '>09)$p`!t)94+Wakhmq8jEI5v<yEyO%Ks`CGGb)_OY~q9f$96Z{jzJKNUxE_Bx9(9iEok9&n9S+d!wXTk*_oX@+wdO&I82_E{TV_'
    '{Q;m{G|SWK;v5bXJ${Nj;EU2Mxl;SyxD@Cdj$mO*uLZw8VMp+7r?qe>&MxzrjjYy%1QhG`1UHFl_yxf6_$vMH#Y4j|o)kXd8BCNK'
    ')bau#G@1}D^eH-F^%vDP^{Iq1j4AmK`!vQD6`R=UBek2Pl5IH-gxV8cUcCq0igJF=G=TRw%|1Pe))~`jd>dXEg1FK6AvDtqcz^*E'
    'qGU1Ee1D`Vst{n69hS%^ON!rNO(o;L1l!aZAxB?8V=&(P$2z%{c&D?6G%L+X0@w9Xwj5xzinZw;t*gvw7?BkU5G9z<7&c>;kwaHT'
    'atGjOnjLwLUKN4Ajlf@#N-rCZX94azU3y{X3CyXF3lLdqTw6)<a5vSy;|}tK+U>8(vjLoi950XW(7UR4bwQ)s{cL`?_er>i`wbne'
    '>~=k}W*>G~2<@WO%b!$2s7tRtuqqG~Otcp`Wyp^r$9z!RlJYdql&G4|)lR<uJ*~Q=gn0-;JA58*sQ<}c&F@a<#&(IBUGwL_Cxl#J'
    'K|Ub_jwwT&`4&hF59SkG{m13A`YgsW+9XPxI-^TEKx*ao89ZyxMCv$rpnIH|nM)a;*lOHdRy#W2H>2O+6QQAuI+e`Rsw;WL2AxAf'
    '(ow|&&52gPB6jfl*f;3B8Kv-9;EZz(ve>JGZi6CBvFbrl^sivF7Dnf#Z*mFIoSmTZ8{5@nghgcd^b|;talB!3lR85VL|_ooL&<Y&'
    't(cz8s!hu66F|ek#gHNe59!$FOU~!FeGYh%8K8n_YhltKUNhWP+5creS$0izfB*~00|6Uk`)ucCa@v&8wjIaIn`f~dOwoRmO}(Ly'
    'Zx=TNmmCL{p-XVe7oh`AgD1`=<b>)`onq|j_NEYLpEw98)R>5P4g`P|j&`$OY@n$ylmRPp`kC!q24YNCq1qd*<D#wTIXHA-_=46J'
    'v9@ozhoC~39e?<sQ)1h~_IGeBYQBb{EGwvHk7Ywg$6?89>?^Q$^#yI{QN0y)lMFtB-q2pVYo-d;Cu_}Gsqlob*MhMSKDT=UEK^zd'
    'Lmf7i0rjgj#WOdMza@_MK}67ctLZ(}#XxhIJNCcaNm@QBLS<sb6><<&o0--B(vD4n%!h{Ps0rU}cMS3z%Td%7?+O@P|MUPuV&uWn'
    'wM9xJJS_-rs%y+=bl+z1M);E1J)Y~D9nHA{`6IQM0{bq3duN6e4#%ADWAZO9jE*cQRr2xIWK<*jD9EL;YG@$TwKlU8P~<t8A~i*G'
    ';jy?FhtpPg*UhUU8MbdUG^$<fjUm^N$74;bM7DkyE2Dbo)i`@gHoCGeAcgodE*mo*8G|ThDNA#v$K$2PwW9NDe0Vr`$KfB*qGe1@'
    'yUk(&1A~*^K5i!Rh}G_Y-xB^j-=U7P*N0VRz1dq$w~*V3BP1DqBx`V4<BkNuH5?@6iMK@)?qU2R09-GfW_lJ)er9M!JXAl5!Hq*u'
    'ug31Mo%<iTJ1YfyV&kdy^>~itrP=)fe|I<U%Sl9^zMr#~no%;!d}B;0`s9n;q6`EI%|-Mvj*l~II^kw-N63jURtIqfA7$MSsl3Hw'
    'XCVx)b8`&*^v(-51^?RtQj0|7s{=vWOPU=|;Iq!Bw6zSD&pA68e(+oRgtY^@fp;@PZ)aB8m9YyCHHZOq6X^bX{T%2xJ+N!*ZucDd'
    'lsH(zo~&PCrg{d)(zPP{r{?)Tjd!BgA*v9Sj`|K=`M9!BVccwGpH&n${!_~E{RT;Tj14i&6RaL47fdWjJ;9-l+;<fn55Iv@S{V}D'
    'XAzl!i(cT`Z0&p()C_t;*Teku1m6)kRG(#JTo>lYPaG}%UFES`^SG%D@xulO_FCg!RWDI#F1h0JliVu29>KpW73;)WyuP2}`MN{c'
    'f4~WJmMbezea#!szt$4+OW?P(@7n&OJWoJmqd3GwFJ;6v0d&liIJLXDcMdPZQuVtmgV6`L7xq#FL@nD&3(il!rP$`wJPl2-OF&@I'
    'Bc)yHp6iBZ6U(!kS{w&srx~j93~er|P9N)=!_b26V)Yq2E-A{=sNm3vsY$p#pgMPDLc5#P2-(-6F+d~k`<W*gJF(zM8Ib{Vo@>vA'
    'J$)w#`-%kIIoIib+X+;Q6RNj4%W%J%$Cr`1P~$?JojM)+!8=8iuPbtC*TE>#?Q}q>Wrw%=1+CM^pHtIJgi?%s>`W@6t!LxK1sxff'
    'AM)}2b1m8);5maq_ca?a+tlrrzMIFLu+=B+AANi|X_n-obO0oGpME?YMAF`6lJ|;?<y;$nS!BuOwtVnLZXrOTiNmIu%vI`J(bE#D'
    'iZZDhk4mqxp1$(mQ?Uc62|&GR=j32!4Mdxo=d+h%w<rjL|M{qi4--slAv6Pgc(41#S*ZFFNFJeqY&wC=_{W_r2UkA<7dFJpWJpct'
    'Jj~q-d?NiO>eZK6(lahX(+S-ngX^6n*np!dO&}|UpIXe7l=0TX1>vh}@@@lc?&}RREHI2Q`#`jZHu5UZ_Vfor9-&!1*^>4I62Mua'
    'z6R#$C`f78I$(?XSk053^-=0_=jTkx4qdRq2dv~q0+wPsh@HYS4k6gOJJ13=NimQA9%BaI03AY-oW%S~@E-c(CKg$Rr)g3oz_zt5'
    'ewsN@?kYk{2HdHBfl7Pmfh^fB#!E*O(gogq(nTE@VSY?1m;YHGm{kb6xo*mxq>__8RqDZ<C>yOFn%SwXq8YnEqU=LhODBq0?Xe3T'
    'NQZDXKcL!^4~<!m&S$r((f2Eo)F)2%>6x{#_D?->=UqW(1HHN1d%=VJGqFQOV@d-Qvai~;9ghwaS`O?7EkJkq)#u-!NjYlXBw7Wo'
    'zPp`?L`J5Tvya9^h!ulmBCVy5vaf^6r4Fi#xe^ID9lKeGuK0Etp(H%K(ccwTvk!3#KKsZ66A>X0s~$J*t*l_wnQ$<>V@uLjJpC!b'
    'Zm(?#l^iv5=GBi7X}O3<^baH>GAwfzNIk?#x?%3FZ{_D01u1+Um0rz1PrF{*OPUO%Kb0ToF#sN?OuUF0iTEy+YZYgDuid!oWsAM9'
    's!%LOk5lz=<cv1TGW@6a=Epio3B#O;0GglfW8W7HQQ@cBUoFFuM?9b;s)yv|0>)EN9g^k(hVM>)zBsOFey5s1xHKBbl&W_qvnj$z'
    'UmH4HzPS?LsY(faK=^52T|nJz7Y2+lZ(iQ9_V%ud*V6MPnm-G1h)YEvIaz>@JvJ4HEoFp2X46kf^I?R9E|pghhuW49bbDy4PCg6Q'
    '(ZV%07mG`n{IJA$J<_Gs2Pd(P;_{lwXRBaKdj39qVjg&7o^tjxDMRW3q~|ZlR`U``|7N(&EPdLQ(vwDhU;3XPt(iA%642YIFHkQM'
    'pPzF>4yx@<58{4vm)C|zvLC|RdYdWi3CJ~}631q)7Xi_GXQ}U1(-4({buspLZP>0uc59YZH94X}*)}?Y>=o#Pu-1cMScB7qV*4*S'
    'XPURdq&h|mQi+8wDr&+!?Er9vH*?6|MYXY9yIu~lkeQOw<@Eb0w}j<}`<cjifZaoeilXY;o+g^5(w=bZi)s=EXUE8W>~bQA4pD$1'
    '&BT9f@n4aT`!Fw`LD1T+kbq%s4xxQ9I0BOZenqHQX5UO?c0Dah(8E#iSD}p)&OJyLqUB4h(6-U0et=wqD~v;YgwT?wJ+c5v$(!EA'
    'bpp?9X=_>Li<`C3leQX^7JT3_T@?w0OD2~zMocfRA?=4y3u3J+lQzz#^oi=)TCjr#zGciOW%oZJhKwWPVW9_ABOc??G_X30&0Mc2'
    'V<cTL)%N70^^1&n9)bbD6TW|$^1Gw5hNeI^HoIyGR5<sD|L%gT&9ILU^f>EZuj#X$;Q+{M=rR)AGKygjmH*k4>u*eWjrJ0?f)Hoh'
    'e=r!>V;OKiQTLDaQ()S|xvpPv`sBUsS`FCl;@nmOGGpHLa5HNb*Yk5a=FaSj!5G&x!A#m6`T22Q8272+4EE5BiRH_@)bDGdlC&7|'
    '5DLw(Tm_VMXKDK@+GC~BMqRx0ge&OwGhVYeF^ur3!P7NUI#gtON3<TEJE8YZgpVN;mNG&;l1xE%R<fuKjdSBtkmbBl{dTdIc>4Q1'
    ';hO4U=<}(_)Qq+~YDqv0^a4Vt&d!(Sp|WM-1T4|w0w`6d*b9+vAY5#meqcrvqfbuI{xfo#CiaYhD|aubb3`rc>f2C}KHl~hA=Msy'
    '_#UB6O+Wb|i4{<<1pq~uP#OggYw-KV2YoI(^mSTqdgTN2qT)&sD7q3?N$k1iZ<LwRJr}hUI@Cq`q9_O=lB9E6V9QrcR9P5$h4nl}'
    '2b2Y69u$WBK5^}7AaX9#1e$b@9UJ#StJuX(<jrM)di6vra>YV(J?zYceB^N|iMZ?7v5G9ib9^7W7jLCUaBL{tn(piXOxEts_4LJc'
    '^}eL)T_n@ITA{ezHoE4u7N(dVlw?2HS&JHOYVuax&zm>@;ULp>=ZRg~&+_cO0u*ok1(@xWUHH)JC@tT16RG(s=-&k8uoQBDjs3A7'
    '>h0A*)FCrizsC*b=P6n@TbOWpS!IBG8g|u_$>}@f_Y_s+OF7hRm3+#!@(CYnxGbNB1Se+Fk-Mu>um$0E^(({X%ZXUGzKcq%ug(ts'
    '^5uK%*Aa0LYOXr=t^<UkyDHpOD1hwavw`FX{I04}*T8@|Mm(C{P)t{sC@2S=u@0b6&{aFm+e>%Jt=%D)0Ln$(#;qvJ;tAJ#wlj@b'
    'hJ8&sF5f7gV%apUK}1TN(uO3TgxPe;k_lutq#N-+U|u+$8~7iVSfaTw=Dfd*tyT4daieGG`B<_(gBOrZFU>SmGs10<{_G)o$n9xl'
    '>e!H#%}L>eX2~pZUKYIiX`!0sy7H6iIEUl;Q*LCiGp$b=S@;vLN<)iw{zDvV#|F^WVrCIhD<XSl3w$5pH^&9??E~NT0i=x^nqpIg'
    '71bjU_xCivL$1j-z?|Ecgsg;P;Ly)~n7Lq#({(X98N{m^LSTMMtd=*`b^lLoEZH2_FsLQJkYGwqC#+PhfUK@h2YTcLJ{nNbw`a7)'
    'r)XU^Yit#~XvJU~mJfi9!ANTmWRt>2_WswfR`TvNjrew%9DUw(e~+NHk`kYPVT&Dm%FYu>F^qE<#%-QPd`VE1lG~=?km)af0O3mL'
    'oJP=mRcp@cg1GjoiSc&IWux@X0|)dkW?E*H8NM^C+4l`2GhHWIV6G<y%d(g+DLA;hvQlJ4aKS}BW|sxKu=Z5Vwd{F~4au}O7)-W)'
    'R*NV|-pg|Q!7jv=R=D`rAsZh3qJLvlS<7QbFD);mXJxd~Vl9H^qqFP}m`l~Sq^M97NGML!7Ksc(YsmI}w$p&&tnZ#pCY(rRjw)ei'
    '56QK^?TMn!{w9eDl&fc&H#rMIq<a4K41H#jDa@(yCEd-6=08I!@(Uo41U@<`l-SVoKls<AnsIG;MO*_puMo6Zj14W4)R4^qbr!PH'
    'ywpy5r&^F%om0vt{`yY$B8&F5W&=^Gh+%Wr@V4W(ioOW2dZLip-nVa}(!MJU9G5%aa_OzqOupJM6XFj=iZxj^)r5Vj;(NzQQ(24u'
    'lPAvLo6}N3pN?r%&<%X;qx9}<Q@_1}8oTnCA0%?>g*8?MU!_rV5LU~`Oo#pv3_pBrvO?nVn$Fui!Fo+y5~MO)>Ou{GWzo9B>fPJ!'
    'uBdJCN^2o#2SG{TE!ULTjX*rR26Sgyy8b|xQGWMl$v%w!o6fuXnT#R8Ceim?bs~1ZyWa^9{=|1ncZfEB(o=z;q>WZh5~07^%WL$V'
    '3u6a9Ei`ecUc!vdf_&_&Nm!@hF5dkshfZWb@!?!VvKbD}&|%;mdW6|YQ?96IOuO5mK+~lm2l^jJU3?!mg(^AsU#>@18|ZpGaz>9-'
    '+eR8cAA@NQr5EFJ+j^4SM5{3)G}=3~Sm4_g2;-ck_CwmU3fAhsm1WW;Rfnl722oDq|BsLEL@#05e_NVTrSfx%T*h&fRp_Fvtm~j-'
    'rk>7ok8U|3OhSrDC(G=8GB<CJr@p>HZfWN-cGA0LqaPm7lURMB(kCAKDp7g^XhT7_qnrodkL@}0`an@Orsbk-Ro?|?n|<Sb)K{52'
    'oGeNqtZ?R!gAs<+h}S4Q-pXH<-+49IxL_L0)(TI6_)}cfJ3jm4Ix2x%re>FvkULP%ezKoZIYO9P43v)9+471i6<73HSxXg81Jaog'
    '%~$=Ur8K}+KmKgR)-hlSF($o?I2jb6gjl=n^9({cbU3Sx{#E<?x?&?P0?8|YPAE*<PXq)_M;8F1cv2@<gO%PMGX%igN$ff0q*b-o'
    'xN#T(-CK(&2d@WV*TcxX6w*0I&e$w8((+ny#3nXxPITN`jSdX$TrG3w)%*h_0NGvqL)<g2^mbheheg(eL0>MH5XGA-y|TBPnG=P|'
    '>rgL?3JS4T<Nm@KcK;FQ_-IsrIh85Csj+i&{!y-|Y(ntRZ&p2~E~56$wm(mBWWFgjwZa3}LC4+e&HZQZ2jDus<*1!4EG&d%=0>x^'
    'FM}Xf>_zK}|D~6nqW$>uXi@?X2`RX?gcnuzh#_<BlH(*}&l5SMT7P7_;Fxm%D?${BUtF-ZP*oBPc|Yj%4bQSpfJs|gfVfQ0BplaY'
    '>>72YTSjvhz>u2L4>49d+4r2j#?nhEO+(3{cy1)>%Xtd1rg<SsW0s(`U==FY@!%>hb4(BFQ)Vqpk|9ypqOM-1K@m3u<ntHfTCwc&'
    '8~}v}p0e6N2=yO6CnWr-1R3VHR<Z^vj~#GSEj?w%8Og452Y<Xw{3x&-wuhK>l2-tGsct2ZtwenwPSGyw(asgv>)ctD@sj4-o}pk0'
    '?MY9#E;u8~bJiMu^>`QPF&|bG0`@B4N+32c83b#s>Ymm4Ve8EW@NQ)$=}Q(S8RDu~<4U;J)#{qOrr-Kz%9yhFqAqNg7W29;NONH6'
    'j^-E3%lz|9i_c$dH5cX`G4shi_B}E`8|Xshxm-_S<8XMCb&RKUWF7AJkGwrKy;uN%Wn8rT_yeux?lTGvWl#~n*{UV#^*;Ind+2!k'
    'Avf&ye+-&7l|`xhw;}-7lAg1r4iGTqhRIB~@yFqV+-4p=Da|KLXSkAq4p&eF-*J;*BZAVJhVf{du@AC)b(b|(&I5~QHLIN)2Y$f-'
    '_j{+XLiaK)W0G??9Xyo*G-J2%L|x??P_F>)yCT1m*8=}*Oq2Kwe%#j=b8$dPey-Mq+cA3&n5rzK<(Vd}XSvFxWH{{GX3#dpHo_A3'
    'f)m3yyNl5}D2j}joZQi#j)rI#R0%mN5}iY4lVocW3uhwGWR|N;qXeh1HZU%<VfKNJpOyYE%vY&|Gi+%U!zzR=L`G0PsephzHFFZo'
    'x;{47SirTbQ@aAAuspU{UN+24b3U|TP^1HULg9=%h8$wzOI%C71Vs*p+iM(we1{P_J0DdFk%S|<PxhK>Uz1lKW07GUgTil{Ye*qN'
    'mU?&<hhvuj<{igr4pSertdA3M<{;U#1eEMExR(z&^o0+ZMmbDyFQJUsL6@l`nWlV<*jVv5zcO?mY{-+r>B%_62$G>x^dg0AmV&Xy'
    'a2?AI%-RX#35E@1^J+Je&<@$~+>=0hEl8{$2sV3+y~kjo%lknsRLs&p^x}a)T%b4*$536tI>gqX(D0IP&{c|Ni%<qu)O9|6VdJJ6'
    '6ON<`a|ljwS2%WWzVnf?>Si^ayg-l)k%qMVQ8q+Gc7?}k51IhHWVYQptV%qP7Vm{(<_r_+evzJ@_XNp6+H!u`90+V1jhMnlUg-|6'
    '6S(Qw_6OIYT8#?19h-ZylzknMeYG03a(EXh%M~V8nGEyPFj{>PxV5zUvY|^_Cb57`&+%O-;2x%lh=SKycsLqJ5kX$6mQW0}?nNSe'
    'KFr5c3%t1G?qRo21=B_VBmEq}dIU|-eK?L0C1S^h(Xc(P3XRCm4skDy9I!TSQ--JE6+#pWK17?$O(00d?mGMlj!N|ebcVmU7(L#O'
    'nTv&ragrqp%j5`hQ?a{z_+Bp`a;8|>>uga`ycd2#jMh`lp6-60UTkpN+xUvUc;>Ygb{0FUFCE<w^eMc#=t*qy{~Zf$$iL@Hl+%#r'
    'Q80~zCV*=EMQ8>+-r+5m+-zTyn-C&c63AuGip+W|@_!+S<V1=NIFA>ebmr6QUd1Ct{$lXkdtF6Ng0xp`?Wt<U64Y<TT^LR{l|lBN'
    'VeIp9Vk3P1$jdhXYI9Z#lPAtka0F<+&)b*Fs^*`fPJPE?$Uvs{rVep+!9z>kjnUB8LZJ=sae~H=sN4N}F%-1oI6~vNy*%$@9J-qN'
    't4XkWOGktgV-MTs4F=d-+%+S^%vr#f<uE)!vds>#-{&J{<1`2#$t|j9wM(8gVem5VJOnv1oUVhcJ_khh%F8YigN%zD5aG8-D_?&$'
    'm^(HVBHdMwL48zm89S$en(B;)O|$+A5Iw5!Oz=3wIc>Ry83jQo?YF+o<9HVVD!*Xy2pCwC|Hvo);kJa<M5WV<_CZHgm!}9jPhkru'
    'fu#itGyoy>Guk$Eix&fC)j+bJ?9IA1)pm-@5%R9jy8s@C2`J{8=uMwc``QFRg|3@=a<kN#dJ)Tf$N!!Vu_ZJf_h8}BBJF;Hz;vN^'
    'i_KHSWDeHy@($GRodnJIy=8YYoWra~6!BFNB=RJR6fNR`X`EfRJ|qs2hFjO7V@tghLsoinge{7pqwIOuiCjNE5)L#HY}!gBN@{r6'
    'q;h*G?qpq%AxI;Cw)mzSa&~|h1A8{EW@4T5W4JHU<F(d}WPgJTGp)^Qi$I5CNeJ{%NRi~(7Tq~_UXPq=<;Ppo+(R36$iN;F)e(X6'
    '?rP7b(&uWeI~iX_OuUoeX^VKVONmm`LxHzsw}ff_LUx3weOM<0;uQ1VzW4rY(z&>5rl3Y+Y6tUav*a0!yqy9~N8)UA)XSRCi>BS)'
    'k2&<oGwCndWhMTgu)5r5(KoAk#Qb@0Q-W0mCcjy|?Nsav?&aIo;sPT4<j>OC;Bk{E#%_azP9K`8tD!Q3)WvV<J)jt#4K<%RZ<eYv'
    '!~H!v)Gr-}0`J4G|6h0|*-)<u%ZDPLT8CNvQl7z%d^=pcGMlm!9BJYil~*<HIBe%kgJ~EHId5@RsA^nJ6yrKez4M@XuNYl<q<{>F'
    '(Py`?bKmZQc2bKW+cM<E_Lji_`tIF$%QJQ@j7EROp%yO+;lSr5$6f4R=g=#bdhL4SzGyTkI>Uo-ttHjYZD*oZYVo~~e5kNvUV*9g'
    'Ee0yAuF%j2Qo)NsV~h~B%M=gww{T7a*V_!oltgYl2CmVaXt^`608R1HI`5^4c5!jg{-^bG{)L)j%c%>}Oq+YRV+4rRg;aiP?*l|g'
    'e#_cFqZ|VO*Qp9r$x3N!_f{Z@4lgo_mQ{PPpm0z{AwEliRV-^k@5HF7#Y=b#;_qc5ELM1*HWeHx0Kh?%jAAGtX0ZKsv*mz5h8Qqm'
    'rW584^gm%QI0Ew}X*&~rqQg#YR!qWrQNnwo#r_6+mAhR$maCaR6zv@3h@%Ie2CD+!s!HQNBBx=6u${VT6r?wS$MDY~!C~;%wF3Ey'
    'aVpBP-DcWrB^<M(#VJSWc9H2$G711!4x)YZU+v_gV&+#?8N4|slXU2@igt9*<mW&WMR1d7L>!fS%Y85N2B!<sd$TYnM{wNl^-)Kx'
    's89(~B@kA5Ql4k3QCLK+oRMV*`3A2y7(4B{a(~@-fR7)Pe9k;=c7U^-Muy@{t@azoXg}D4evLs|i!T~+Zj>wE#sk;&v0WY8rb)i1'
    'VgK9HU2cv;JrAe60MXoVS`{gZceJ@a{qs25$Lgl?2$?KIu$$lxLZ`3-Mwiz1WY5w8*7oHhOM5$xGd_~{AHAII5&i2c0NBt@H!qmZ'
    '(`6NFt8f(@QnftkEDfOG!O#>x8sFN%&I3S~f?b{?bm%sW)yyU1B5fOMR}C$Tye}4lr7Ugkp3>yxJkLo92=;p+L0))()S?EfvTUt('
    '>yx1hdT=A@A9$RcJVuBHYUQ{bC1__r(oIG_4%et)JtcKby9Gz!)m&yt#rd#%PJbk)vHsdLWF#2L1r4b12x=~K>1Q(L+>o)HmbHfr'
    'U$oPLi$VjiIH*UBC&4#Evb3)P<Z?_Ns|A`q;0cSN)Wa6?ci<j-&}3B%2|gtuc$22cwK4qnNBK;|h;+z0lD?-UAJEKw&p^-7r6jwf'
    'l!euRfB%`kfTeJD^)-Pg6sK_*X?4dIeLKnJubN*g*ju_f;vJ<Y55EwdEMqBgb1V@=PweF#*Hf|>N4)e<yu6i=Un#N{B;Jw%sZUNS'
    'N<V^4)wL~TvAxs@p(c7PKqXM9g3VGYz%`F(Db)POg79h=vc4)bVFrQnSmOo*sAQktEL78Q1)K7J%I|aBa7ZHf(+*;fYYqTMB{;Q6'
    'D%5c3m{@Qsh&M#I9X48(ML818!wnA+7SPY;p>uyl8#`dq%pIB+=x5*%b=wK;q>wAN7+t+-52->Fi}MPz*X*1Xb2~Q)6?(bcJ6S3E'
    '`|J2&QhV5+*_5X^(q=RvKUNJ@8lvNx=j`PaT24|7ptZfX2ynPagO|Vf=^)J;%+)+9OLW9`YjK?L>x$7@A_{6Ap;}RYa^ga*2zOgf'
    '&ycIYqvwo&>KNEbNOE(1KzysW60Lf2kDB8%-;Ehs=s07t6wUi`$pIV`ty*1U@cFk8R(vd8HuV^a%j8CqZ;a0ymxvaw;r?(8npNKG'
    'pGcxJLe&idDCxQ2@|BA)nKDa~H)zRcYp<%pGz8f$MNa6ElF#g}pZ}chwa;fgA0m1}Thw5QP@W#meCmtkTn+zZUEHP6!-9S5wRaE~'
    '-88-bD>22|@Z)@q;~j*DrYlWEF$ylZVy7FMoN@KgDTeRCx~Q#Ly*lqTA4;FdJ~t%0TeyizDZy9^ES%UNa(os0EwT5kD9e)t%H#U0'
    'Wn9y;iwM_HoKjsFtZC~dZ`z=JJ2{E*G5*7-jn??`_pYH2Oife{Xpv$32Oe%2iQ%FO5Y}M4Yxn)J_%pYqbbbIY$8DUJKM@_Ra%qss'
    '|6MPo4?79nF~~Kf?ex|MYx|v_?sqZ}!Ngh(6&U_7nTtAG&%te!b5%Qvl<1kM939!tv@l;P8^JcpG!DjEF*uS;We3#O`l}vb>a69K'
    'wKP@yZ3{i_SSJ@VhFKPtCYWbxHJsP2MD)@gdRq040#7M=1NGZ@D!;$(6yAH^oW#IphRZ*ZY62`zASFL=U<b4XA5Y@8An(?WYc2>A'
    '7#8e7g_=HDBYdZpDEJ27{UK?~(q_o3IMdXvHDlzAVF2;vW4Xzk#7S7_B7WhGs$kN`Uj=f*w%`naf9rs0TT?b-=2&%rUmJLZKyci4'
    'NN8>c;7cTQ323F?#DP+fbV2m9{UMs@;+B$*miVYrw5@I#e&c5vELQ_%I?I(0r2t(*>Ljr$K^;}Q0S@=s*J*V`N;?b$jh6dYWeey$'
    'XLB0Xg5{U;E4<h}*(y6-_=DG2%btsWTDF}p&qGS5aAgxAxC#uB)C<#Qqv$P@CFhKl75x-7n4ss}BK``G4Lm)JIPY`yls7NlytCxS'
    'm0~0KQYGQAe(<$pcCdTrxpZ@z>y*@Q^-$yweA4<XI{#f)aq@nsnbDEZL`P*YEl#!k-Pm-$;W)(Ggz6S6vAt<+W!l5_yTu-wUq<6E'
    '&%hcXtB&FLc;+Ep%x{4<Bx8r=B1O8gU8nP<dI~HB1L5y|@h3_H5gWd;Mi5&vPL0}I`Bbl;&M0h+GB0H4yb_ek{Ho<nt}9e;ByD8c'
    '<4jOETLq7A17U0#zoTI!=sXrj9S@Z0n^6+TvM~@jz3<vMc2r*9vhe_IIuBNpfb#x!A=Nh<(h0_VLq)~D3hu4fJPl7LJ`AVWx_`$B'
    '0SkTv^a!f1Ka!)dL<e{mu0!46cgtUHBH=bSvax+oQ~`cWTw4{T75SxK&vyN%-W+g<zX1(e#k9Wjsm|@SD0=P}Va=B_WnlhNsrVRy'
    '3}=0d{v98MJ4gdB)OV@&{$60((~_e{6;%?_Gn`;%UQ$6X)}6WJ&DJn^WuQgv1xp3=krmoiQUI>fR`D)lVwpdZpU(e;(<biI%hR<d'
    '{!(=utZmK43F+9_yos!UF(Dka1Eh9d)(>CYN!T}wq(R3HXK;9B?=&J9<-HLSkXGc$&<!CX<B-!29vNgV$lm3w`|HdBH=g~pQOfY<'
    'sdj6FKr?IcE=S>T-qw664}Dig2$pJ47)I_p0D;rpPc{Gq6d8&y%&L}eW0K{3NTQ&pV}ig(ywk;xe2ahnZc2R-#>Iw$WW&j8by{&E'
    'L4FOyC3qB7O_{JD$dJ!se|)e7G;vf@lJ7s;KD#lTj=}pQnE(WGc$mQkqq)*u_+rXR?p{L)3WqO=;rO7gpyC}e53Nq5=+tXV9l-eq'
    'w~9x*dM)T6Hp!deoYyDa?1<tbkpc?9mKjUPX)1mHv408wjYu<E>_`(w4#NelNgfn0^F2^!p*2{f{?b2CMVVYxvak#Qg{mKW!_VY{'
    '7`{zzdD3ZR6D>3Rns&;J$yJN11oiekSU({00lS0xXzruTvA-PS#p2D6W~Ka1CdN){E)hv%dn#i`mz`)!fTnW(ja|rj-ji80z|E$l'
    'g{06k?Ds#3@l0T*Gd@JAfe6$CIR`5vLP#B9>aw-OU@?}peAH;S{sJdhEk|<RLGQUtuQgtCsS>N4L?k5VPeLl}Z*#ahqLIfz8#(jj'
    'n(+9H(r<uTu<47LNDpvm&$@E^Gx$8Q1D11ei|fl!b!dP7vS3zNQ|<M!sC0P$p_G^zcTnzM9>bV#DrLinYP$R(g}R!KaSH01)CZkW'
    'y{*1W(NobNr)Y8rW8_pD<qEA8g8eF>>2IEG)^KT=-#IMpv$3^9mGEe($5a7@;V;Rj<o4*#tM0G=j60UXhiktDeJW$Rdlue!DF1wF'
    'Uh)SS3aC>R%V9fOyPh(#R9o(rXSJO2o;$ipTk%-ybK!WQ$j=ZjFVc={rfx${1`qGhpL8x&(VuqN??HHxkcFiz#%RMqwPBSdGL`$5'
    'E|r!Br?tO@8fpu2CvFFp%*As<T*11swtFQi=ORRkCq;0qhdW(Mq9-axQ(6rE_90~&ILHcHMf5xGM&cXQ8=9j+ZN1PEJfgb%0Ajpt'
    'y26YlfCk%OpU3|_MIe{h_@p%A--7YoEU8MaU0zfc6HbiJ5YB-8#C^9PlSXFWBK~z1u39xpR)kqJ)Xr2U%xY&iFff><Bo$K5n|mtD'
    '+VV`wrka(|>lCV-<md_q$TO8BEpjeCQ#*aYQMRXNQ)VjC#$NbCLp*We{530DRWR{TzW;7CrL4M?6PomcR=ReBP0V@;Tx{p!acEc6'
    'X_vQc^~<|ox4~JI+hbubwaOQqUj%vCGy<Lt;Jr0OGPZ`c#VA!I9o4$Ys4V|=C7XyOB)L+?=&`ai8EydZq)qSq<x|kl)Xp@kh8PHb'
    '_z#pWHq{Et{A;+jS5DP-oYhNoJ*V`<&a-!pkx2Fm&RY>6MpM_tq+shO(|ED@4YX~m4QMRo9ETrwnoC4s&@p%Z5T)Iiq&8)KtHZCm'
    'fgU=yc~S@D-n`B)#^TQQ6ye~D|IoU_Yk3dkI2)A$E9hXHnksQ&Se24yc%q%7cWtVXhmyxmL{PiAaQMN<H*=-fy6wejAD)UzFYi*7'
    'bL56R!yeDBZ*QFr#n-=!B=~~V-lRp*mgwa+jCXb-OwHYOeiKrvZ=)s|$-(?aN0EzG5(khfCKJwVt7g|pO9V^4RM>Zwe=d>TEDBd?'
    '=YhvXX{da#S?Df@R51A1%?lbuj2O=Bx*p&9b2XwOn(Mx*D`g{jpWP5Lv3o3GnO5zC-S$g$_gUThn5f7D)EUY`2kC2J?IL&dL|a8H'
    'tK2ri<jP6c8i^~etz{GWmWOe_?2U|~hHu60hvVVMCQ^ZoLD+v>5?3G2HpGU-N@@lwSI`NF)|z@}Gx4xlD9u%gcip;Wp2TCc9EH19'
    'EvH&xZ_OUx6l%dsmo~sQ(eLrU?&<W!V7j$-cAof^zwp3$>E~K7)mQkawW60-5SdGi+({r1q$I^+SqYQgZOBDQ)&pr}v6o~zYmu+%'
    'J|jbNqySHN3_AAzu=vIU+-u#Tt6^lRbo>Q4o;JQABFB7FIpQhm>yhO!^t}7Mr;T2s;>iQhzHwMTB`XhiOkv>9o7C9hY1p4wd|y{c'
    'n(Oo_P0!MUDhOB7rT|qMz}v*hTxRsfTt+zcypN<9GiCb}lO6Q0)r{5mJ~XX5ftPP7xzHWpG(GO>So)h@_2Bq@=9iC7*7b8!7spmZ'
    'qSn)9bI7=NlHm-ueT&BJ*KNl7QIiI@1D9~H#A<kXs_hZ(rrd?6u45oL5)`^=ad+%Z-m>&D?75`0&9mYkNd~;7tJYg(W2bfCO!3MG'
    'A!s}r*L`>z1fML4-PO*H4h%YDu9)0qZ-1jJu_Ge~@JxdoFlTSca9%Wf`L3dqa)(tAw0Gc@2l4FI_)_oVJ68|TzzRY>cD01MmkZEZ'
    'm`O-pX8F00qwIJqvLy)c8V045(2t_ntQ+7)E1=X;C<9G+WXtRL`N@TndX%AVWpufb-xI#HsfCnOzV4{uRE}=>Jj5b3(KKVb&{Q=~'
    ';5uYL-TV7aZIKEQ=R$hweq_mR)c4w(mML?<2@bEm&JCWxB}<{R8;gwyuo0@TtP0o#ABMaH#Mg)u3CUXnxtl%zG9@Wf(bMQ$_XOg4'
    'C=_=DYkgJBZe4Hw`G3`h(f!4@SxQqZKg-lzbZkptxuE-zVeM@TMz4pH&q!1xotZ`?r)CABH>7#6q{IvxLz>LZ9j7Z-bk<+N=+=v-'
    '#WOnFUU0_RZf46eT5`Q~)PAjj50q?`If_@qWI+~8j#k<Eh4+<tUwmr5KQqt849mF!qM(eYPVFpI7X>YW59cXi6i8;<b(f_=B)~uU'
    'nc2wcr>w*_90-d1b)~DA2ywcLP{K%>t(!8+<>IQlotfyVeFr?^0#m3mEL<!Pi}@NnzMt{kW?Re5UD3ch_-WrW-JK?3-y=y3B^_Ds'
    '>=b^H1bJ1iZdfw+Uo=BQr8c)J7o^utV&kOXxzwO>hMG$T&te{H#dR_TY5>e&mP_h@uOn!san?ts8Hgx2YHItqxs6v2=~zotcV%`A'
    '+zN@V^mCzR)wbmNDv;U%&mkvJ7L`yWaCHuXx|Jj3G&=|?2{B486W<xScYJW0!S4Kjhoec@jn%~VU_Qq_k!Y7;A$upWlK_W2HBGwb'
    '7a*03%Y!acvsYlj%wOnms8~66+}ay@vT_O3q|R2#=Hwgr4X_dG-Jt>>9v4>JyAe2<m#L4M7an`Z$7(G5IT>W|&T_`Z_IOT;XE-*+'
    'S4%shDV}373MSSMNV_uM#At8y&Ygz#_A<!UIQc99f>4qa@yTI3yYx)$QpRKPUZtJCer`Nsh{nC{Pjda4>OGsjeS7+6Sb!RrkiEp@'
    '{_VHb8Bu2Xs4pqVe%djL`Uc)~nDsE!Pql`))T&lTKNOlQ*NbKl1IDI}M`j{U#vaNpBW?TCWs&M~D6KH^mjQ6D;q0V<I^k=iV2Q7V'
    'DRZ0<m(Zo#^~v!@C3r2Fmw=`~00Jdt0u_HLl`OZl!}PGKxa^L4VJv3DnaRTr67#ir&#CVz>Mnd?8PFW+-#a=)SJcf*KE6r{+RBuO'
    'sxz1ZAnL#`;7uqt0ba81{JRhp8a9a2QErVwTQj=&7ST~DkZ!yilsC!r(00zaTndHVlPq*s-WV!dMZN(&>!H((?w^WbXp{gqC1X5Z'
    'WmleH|0VWhzaX4)pVnLUSeYN+J%^+6^H5n|9w%YbLp`%fw3Vf&^LwYdyPIr5H{#CQ?IRsw7(x5r8=rY;TUBL6*S|;$Y9iYzmkyBn'
    'HJ;#OD+bY}D4b>OSTG2i%=?N1OI@^0USSz|H>zoXPwljtBYWYy=fY*>EEb&IucycDDs^paVQ3_)*@kf>TEi)rl^`0iCsXCdD@l=v'
    'k1#jB_bLsXCGgS}V8R+Bp0FKD`pS$}V}`zFZR$+*9K0~p8&13ChIB~SHY|f?Cl4ONfF~3I=zA<ct(}thBd#YX9|4>b1{g9P1fx-0'
    'g|Y6rvRzfv>~~wkj)aP?gI&+XPM56>p$zXHE@Frz><B(c;7cY`hNQmK$RV7IhH7ahJiT`#qZSQ@^^Bx+Lf^ZbDwrlT(8aTC<x_l8'
    '+5dc6C@ym>nuXVqZ0Rm{4eIjo)r(_DW7To+)Z3JxGk*0$%GvW$5nb;?V&ilhmqoo1UrYBrN){QTSfN_H*6p^CM)!lLRzyVj{Z4+3'
    'U=ax~E$pzBzcbJhTKokhrBcpR-S7AOGu@Kg2#6ROEzyDT$I^;3%DUb|2F`YuDH9P9kOLv&6GAOf7(PE;kQ}@vgrYSQNYgNCcJ_dA'
    'FF(^4)R0>0OuOD=+B6}zufRKEPE@R|d)7S*K%S$?>J<FKJt_Ffz1Z(5*!rufPP-UKL{?Lo&pj5J1y+4rkcn-ljL&zrlm$5k^Kr8M'
    'QmAtm!$-AS-V!OxHf>b)o3IXLsp_a>Khg8L#JrGmd<0~Akb{|Khu{nq*v`<BXhO&m#+K#t$!KpMPbK~=C&Y0%(e*ZVJU{!F2}r{%'
    'BVjDA=yaXxvLaL6FXV55nzFpgIafCDefc2)eO*GSB0!qU^a20?A+RiW+9^%wcm-2SkE=>9&v=o-AzbF73~1+R9FoPn{Xe^?dJx(L'
    'Czy6X;7NfrM@0&uFe$#wArh^6=JUd&Li8=j-!KK84s-H;DlO_j;4HBUH-EP9hgx}C4n%hF&(qGYs**u(V3W8)l^tl_P!uu#jrCjd'
    'i@$%oQ3U{RZVV@V-JA%ys?Nv$80Rg^uzBQzCoeNszKfcGsJ@eOb04)~1k7-%R4t~DFY=lzwK1RElVJL!$SI)_lv>j8ocU^XBQ7})'
    'X={WhWVO$SK1hOC(B*f<6-`S)`_(xlF&^q3_ug$W_d?NtVYPM9caa(f36bUncwwMbjXL+z?50^4B-BbCgj}IuC`Q$NQ;YC^Sl^nX'
    'a}~DHvwg|$yzy8$O=3y8jdN-Jp_ngM#?LXSj9pe|f%L;~5Ctt}AEM~JWCi*r+(+u2Lncq`)?l?xN@ZSG8M5p}s+peexRT^jRk$!6'
    'yWmI;uM>iuPXLI?cX|E~d{^5)zD8KCsdC{H9k>{}KVNf0O6{AWg`gaC-nGJG`;tA!Pw6Z3Aln+)Lw~_F-4v)5CXl&&7TcP#2)YlM'
    'u*W&uP+nIg2o1W=z0ruwMhBHtV==gmV}xP%!St1Xw~Z0hTF=zu{pm8Y>A=~(9s+*<-p(+~^UG+doQ}RLar!Xs{ZIRUd~0*Zdtr5#'
    'QHzB$z)@3`wKUUCllIIY%`jMy`tKJpqk;WNeK^x}g;)ES2A+P{4$QPtg@;)dlGIOPhfX`ZCqLuxkjY*el*)ADaK$E?`Xrx!IF0cA'
    '93s1=`23?rTG4Mb;E1MquWY_hOg`kfg!DF8x@@jD!vDW-f9WhGAf8TU=6q+6^zW*`Ga|606dIt*dIsy%IwqUORCMoRlwfTp>jMB_'
    '@+>jWxgrSW?7b}8=QrAX>PB>&^=0~b$2SqdVZp)QwiaZYn+^AhVIBTw<(OIg4Jl7wVj=s^r)-9sBgJSxlsbqkG>1EH40shRSk!X^'
    'aGhrFL{Wo4iS=`R^oAtA9<U^U4;e5O?m?s!yx?=U`{MWNL?8JX0zFN-IMp?n^A8HFoDR!QTFAtoLp_nP?OHBV)y9&BX{`(>5T#i='
    'i!hVp>!Bf{v}!~c*u0#eg6gm+b6v%J&Z&MwusPvjY_be=vPV`<9_r|wtOenIT;?ABpl2bc>rn3cy_x;<Uxti^@YG^ipq}G@khzAb'
    ')*F52f6r>f5HeFAt@bozs9DP}QkDQm(NcDGE1yMgfE5ZCpx&<Kg<+6B1j#&$Ug53bRv2tULOsb9UBA(VC=&|_<*MD^cW$QOw)#7e'
    'K<lfGGAsIeV1vn60%%kq3cDCYYOUK@*m0}*&s7B8ZmRf2+Ev&|Cz_EV0?J!#bhmlWaBbehZ?VFkE_ZkrE3ydg<Alj=&C*^#>)w)m'
    '{!hG|-FrseE&thz7!t(J71DsxRq)Y#oVl1k9yS5Of{b0jbz+N>RpSr^;MD~xeS>XiHr^V`o}57AwI@)hR8K)~yR?nUFV>U$iv5n+'
    ')TpB2yH+KBE7%u%E7k<vOUq36)x|b^$I92BN}KHbFxc%h%=lI=v@BxtIui;LOpmFz(G@%xVIFMNocDSGHZXq`=O>g3`G_sA_$e2N'
    'c#Tu!d8Xx6_8=P>TK@*X{dd7GN4CsZiU+#zGy&&0U4JLro>C~V&l!<SGX!+Yn3N@iYjzV2ppiCX4o{-@i*MOgGQBU|v>*46#q~3C'
    '>Uf}lousfv!OnuV!Rd#>Yfc$}GsKxU#L^ro-yzj4i)0BVkX4dKi8Y&+3d;LeTv#dxZdvA5$WnK*08;6D<Ogh|en)x06^+<~!cEZ@'
    'F1FadhoALlg`2UmV(@1)zJ`FIWWZVT$|c*c>P9Bc%{y9}2OB*<A$MxCwIQjzIp0JjX+4wa(){={LWO*-07_bP^%qe$k(Dw4g=Can'
    'ctc167WruqPaq%QSkh3erFumFnYpmCa4~(qBe2>zJyhd3ZK(WST2uo&4qPi~Y8S0OLK!aAa|?J0bTr^E7G?*aZjjb?Ku6KN$!{Ph'
    'b&d0l;4$^RowyQ4x8T2}h$Y>D9T61zUo9hf{2K(AIS##}-!21(2@SQDqamDm*c23HmghfVI{%`^De=Cjo>p#Rjpf(Q)sjPMu^z6G'
    '9afjE3M>j8pwP%cTVW&fZm5&QW&K>H|B>6x14mA{7P|mw)bfH563^>g&JLE<Llw%w%Cm}UqYQ`$(3+Na@2n!@hOY6Cd`2_t=4wlN'
    'K)CM}bpd!iT}DNsKsKq_FMW|*FJi&s)N{{ujqs@g{+A;opLte_d$<Y{HI~!K_Kl}XZG%bce<2AgKB)&6$q3HQy|s&#tV_LuqyGwn'
    'RE&0||9@Kd{KOOzcUh<!j*&=nwXFLX)#$`%Fji%ehUeN`^<jv>Rsfg^Z45cMmH;S!q$)W5=MS0r<t6w3b(8uA8)>M**fOUlS@I0r'
    'w`*ENpZPJL`esb{PLJn-uu4opLhnN{H<TDfbSX*kgW_7$Ft*KemWj4pEp81~(m7g69j|9=C}XC(kxdiXHTFuoN{F5NPfZ_@>Cmzq'
    'f?7xh()@Iics~7pyc6V%ZjJ+%Dwy}sv5Z26{Xf8&kzB;!_w-+<6uA*aK2rW7rmHYKlM$_0wN52J81)r*hBF~JreBENnWxLi1R)lV'
    'aYQsd*Sgs>ls>8W46TERr2ZOC4)JCLaGTupvOPAOT@i@fmKJPPP=RX7GxT6Jw0-y4;`@3hotU!)_i!fChyFhN=V2C*VS?h&!$sJ9'
    'E|J1&%rIceR8*`*@vUvLp1OF)&V<7_n+PNp^xYsB^q6dIn}gwTWr@(WK`T=E#gTt#ZK$uwa<^P-I?Eme{664OU9{)wJFlSCU+jG+'
    '%Bd@Hlg%ZoLM57nRG#Q4Tl2xY(9Dtlpu;RXOX1Yv%;da+dx>S7woMtX$H_we!by4<n1_6~3>EPmOAJ$$(rxBi9b>(P_s!)17^DWS'
    'ZEr~Z(rybm<LuGgz`!)bW`8tg<A2i~{bo_zB$#F18y{`2xe6sJpU7`qQEdd_J$vm;a6e;mg-UdXcqjD6ZsU=doeT7qb3i!)h!J^h'
    '7oZl4wL)<o13F#5!9~hKt)J>5+t$p`tVJjcB?-iD`3z1&;Ybuh_Xhi!zd!3@2XiGYj0Ft@#&-coU+~G%FlfPFz!>qnblnFBpZi80'
    '8wQ0r+iUs!DoD?(si|2d5~&u<ijx(dRf!aCUixsNr~RctNb?-Xh@6htCCu3^MPH416A)~G(tn#982gMer}~1*iaj9e8>-SG`y-`G'
    'k(pT?<h)<oVP*YH?*eb`mqOB>F0opsw+zVro*<7+6J%-%!YZ{#6hlhK(RJ5@lyhXKdDB$2UE$`ToXEvN6QmH=b5H~tfNpefmw(o0'
    'oy|r+-K=>kv5B^uUJ!BX4C;?<KabP0;HHDI*MfGc5|B^3wzOyKV_@%VD=Nrxpf0|u{dN0y+t4?NtqcP)Wle(7j^?*5HigtnhZ=r<'
    'j{_lIIZr-lP(^5J&zD6vvtb%NZgwQlCdisQ6EL*xog_i6d3mkx{ASTsTVThTM#7JHJ`F&kzm9gjXuicJ{24&EGv488DV!?dS8j)y'
    'Lxp4J%8g2rcW0#x)RY?5@|lCD*l98XJ2K3<BPM8Qp<8h{A&ZPxGpsbGNc`fsia^Wio8mHGa!vJUj*tCvL!e<KdrW3(h7#&kndg6n'
    'wNq9inq)<I1^~l2SK*f?oF31@RF`nheZ<nM9o!?J=sw+C*VraTRg$@YJeiUQq+iM`|7<fZNKxm{N2P(xd;pVG6@(@}zf55%HoP_k'
    ')s;Zw!Zw9>i-NRYSLmm|@=_N=Zxh4FN_beBD#zk<tII6^*E%MChNM~{twIffb(S4iF0r^wSut>QW&mdQGDQ@Bh|L0e-}BY@U9Jt('
    '7~|5Xy_AkdAIM3T|55P5J(xCZg0{AI5D)V}A7Q8~`aX(8jmnQin+X|xS46&#fxO|M^4E>|?GnCQaaeipW|Y>Qzo0VN7)|`%nAwv4'
    'z1sE}5wZ$ZR(F{^$2f#<FB^tim{l`};?@wiFHS6k95k{c6{brOf+lkKCzLyRzg_IaLo{wRQo)rlV5|DTL0EJ{IcrtB%;<2uW!=kE'
    'v6h=k(2rKCTSI<+EN&e>jn)fgd}i=NTBrO))966bb*-4fScJ<^l%f?Pd9!Rbrcc09h2@}*PA<RJL^0+eGQD3n<aBEM*$01TGX?#{'
    'CKZxJl&haMfIAoOQB$cJ_L^cpNe{x5PHvjYOg<2NCyv$5QjzJ~3M*Z^__!oybIbv5%!C~nwHD`RC{xP3Ys9-*7R;?Jp2rb@6&nrc'
    'M3`aMUV6=j7l?>4>h}Z-G34bcQ2ij?4GyOdCJ!B|+geC5)j%&rFJ>WI^w}7MZQHz_c+4Fi%!Py_r`MeZ&Nc%c4Z>1X<8$jORxxzm'
    'Gm(wnpuAlUtGAPbuE*5aX{A?!*8OqY=CrKGe9WPDjlclk3)!(1X90&Ph1nQ}Xv3R%GA#z#8Q+Lxmx93|#QS?{snfb+$_xT+;KGt~'
    'SBEjiI{;z(z>lBoUHqyaigY|ImIHR0p`SHE-~%p!Y>EV-+o*hbd!eP(qRCH)^&s6I+3T4BJqo!@8nMiVKVv&F=?QoUdF^i8>jUx6'
    'ZMz1vX1)HY?!4CbNBAS@TqiN6Hb!>*LjTj4iiO8M0&<`j%&XmLZqtZglbXBM!=VpGToPS%-6tn&W4x`nQuqeU22M~SJ4!wz`-y@<'
    'D}_`DAvKjX6(_1GOKE&lHPua==`|iI(yiSb+J2S0=Jufbs-BQ@%%6W38?|t((l5(j@h=a=U6G3_(qnAW@5Hov7M$OxCu#Asr|0=X'
    '{wqU~p}G}!{1YRxmXa3#pY2?JuoOU!{dBKYuRtnfoh_WYHva=n+}^{zp7MoLHIqA35k6KL|5SToatEgf#-9iK0z<oqiY__gK}%6+'
    'mnUC>jG<-|O1PJeN=ss@Y2Jfu#W6!_9CSq<!14z{R-t4B>GLBTVS^oPW&?F0rTCpg>-fWyk5D<iM{PW+5RSS7@nKQz5Bzj4e8IF}'
    '3tKR#<3c%)(r#%6P$?&EWiHY@gVQ^UKS>pC+<D4_4Vjfwu%}o3k3s6|Z35N|QY_QzdymT#H$kWeDuq%+V%cRi=o*5-cXW>;Is{~6'
    'otvj`!u+$sm&a1Jh9SeF-%SbDkoa(B<AFc*RY7cfYT^Yk$ix!Wc_?L}Z^jKYNmWv+CU+{vzpJgz<M_!~%mxmt>T9T|=9LCJ609`}'
    '83|!W9n0>!rYQIlF^sP=q+U@>TZLLgGd09yQ#7taSHi{$rW5X$4uq%rjBg>uQ<t4)nBuK8l;A40+NWW`Pwf_=E_#6kM~gv$-T@OO'
    '?S)M@E`1`Ca*swZpqA<NUMEUZ5el)Oh#-kJSRCDe2US%!8>j4yY`KSVj9HzBWP(u~1?f<)X8T(38Y`KvmF$NZNA#V3`vo{&d<cy^'
    'T$ZSBXk5Nz2X?ISN=SmQSKU;Q$4Qm@i_Wv7<gPIEk>nxZ2x=a5&-3Y=gT%5EZvXWEI#?fG6mAb1C_vg-M9}f|{AjQj<U33KbgdL^'
    '&Y%#+H?ML0pQvyFOW?QIO4YvRpsX5ksOUc%uFQMqvA_=MXX&1->IfEvrWbv>9Jh7`Eg;FPe3w(<@EM3zD@rnKV;iXG?1g`z@ovc5'
    'K+@e(=d6W^KGz<2h(rQO-TOHO;tz%ZUO7Dj+E>LU+G58c<2@iL9l0Mo*<EPw(A(4_2Z5b<b1SwFhKA*3r+-c_Ih)+=EL|KHhYb~O'
    '%TUQMV?1#iYO=B5{D|l8D2o{fIw?9JJR~`rqpM2(S=k?zM)mW~z8*I@tE4vU>LTJ)RACz!S@v*ts8lJ-6INyy3q*rnQ(Uva8k7n('
    'I<f3B>gWhCCa)suE{ctl^+eF1U(+2poSA3E+S*1?GL8wunjg9iUi^Kxg#~Tg_AI1S(?iu(P->@CKDBf^Kt*?@)gEeedkAt{fGsBC'
    'nz#fqs}lOyni!WX{4cWALGue&)|o0;j1nd}C(AwD9vs_9!k<0DOwcdCw|xSUt{}~xz3}hZ*6OI{VcsyTQPZ69w=1ZC*|C4KhWD+v'
    'K7<5vc}-`m2QX!fd}R4Odp_v&3IbtwRf@XB_~(|u`@9IPZ0lc;SpK4GYG>u{!tyZ~Eq^Oj>ge_W@8(K}3)tBaljtwsN}?l<c4y~m'
    'Ob&$2oDp;l=%|VP5`6u@@P@#C7_tDN=T1}Uw(Udh)lPtZ`-N4<MIJI0hZQ|j2T6O6B49MR-Ibf6Er5DTe>xw4_dUr4IBj8pfgK8R'
    '@?Qjr!XciSG>(^lJ1#SEpoGG7RgdJL1N4QDe+Qg`J@k9j=+~V#>8@$1xaKWpgukvkDh|YXVg&SckY*|y_roX>T=lYMwFzC);kUa;'
    'lJzAy4KLXQ79fMfZeQ79Ko+4@ND?#dfN61pWk^qp2{2X@aV$2Nk_N_*dCH#Xa3DvUH9QDGc`$7qbkD_Kl=eRpHy`A~-kdmd28DP_'
    '=qw2ZPzQ8>QDS;TfA)IO?WXGc!J>u48=}3~sN|xGVto2<5)%it_mG{DTvED?`!1k}wsJ3i%TZ(yo%qtTAb*zDe2O~!=Ad}?28d+}'
    'v=nIk1#zE(Q8Lq%1K*6WBpnh=`<KP#=25FK#{cb=v`n_&K~6VasB!ij7=^r<nGOnG6Ip;5O$Ut`LDPgs;d1)4y}3R3W6<QSF<JoP'
    '-e=RXZ_#{(|5<og3m}bXp+G80$4n?v(4LGWC*rnkY`<2l`Bh3+JzrNHfE}=rVHHm0R7|(`(YJGL-!Pk&8LyS=lLY>Vjcj}B%D}8<'
    'LfJQ^LC~Z*4<4(HI#SrS?5o<z_jD6p_te`+)!-n5Gp)<qMAY7s|C~#HMTRzCfh_?=;ePxpWT#@HaTtx-v#E3HXzU!62&y_1jCiZ5'
    'sD&OmNxlDoN{%()u1pr}Osa~UaVq2B0yj~wXnO;gj_G!Yl!3oQet!G<+)_K#k5UD$k3mCW;<m^!^1p}Sh3>mMkMQ!@I9PO)Z`B@?'
    'F}^V20@&l(!us9uI?!BCHAo&fY43TAJiz=2Ddc!-k1d<P=zyHl4u}?ziv9z7mz>2$%((|ZuD3ST22>{{b~r?cF)ZrAK*!-L4r?iC'
    '`^VI`j$hPLXN_XB0@w5}?{gpZ!kFo1cB_N0lwo{AXW_m<KMkwq<+az|=MZg!YIPa3KVHAZ?HkE9QURDezex=VeC}+dZ9~L&OC@b='
    ';{IG`LcM<wyl*b@XFkb#Qtyhq0vI3LQ&aWzm6oq7U5<S|Zl#@WYE-=&o<ErUnQf3`TOU?n;eYhxsH%H<btyU;@y>AWO0x<j-7QKH'
    'Fi6gP26zyShK4WFGDBY3pP8H2ZBymh(7k!dkSE@I)BHe%=Y)rYbS-ARr&R52=>u2v&LBjfRY2^#%ky@{ZO1ANLfb0*Dn|=ub4u*9'
    'N!`=a4=k-ON|-l|GbPZrn%Mefo1b54La~Q(USmFTyR&eC*a2Nb9#(FdKw1H{sB3<LH$MEWI<o0A5m-E0>1lz6@8=QD+r9FD*Ul~t'
    'xpuDlw*okmIA;b;#5VKJ6)LgNUaFrlT(Xo2{MX{e8EC4;Ph)cm$R}QJwe=p^3_E=*BhT~iHKufe0uGMZM`{1xAwbtlrpE!D-MtBB'
    '%~X1#6xhL&;NB5MkJ=!^3ghQLh}pnFgDClvoL%V4GS<*q#~HRRxeG%0ZH-2xct*;hYrky*ly+(Z@Ssi8dnrQiMQ`U~_!u^2nrC)u'
    'NVLJhO4r&}u;?KzJI<Wria#E!Xp2(@uhhSoV<LpuFIADX*q3i&+2^pn)05#5KDWqc`%MuNPmm+vwm4O^I58)v)$MV<ws$KR8=NDF'
    '3-3P?;NlY&pc38rW)X|xl6WBDCAXBBled&W#9fhhQH<QRv7dn;jGxkz4T3l#Bm~-a1;DG?{VjY%7g{|Nr7&-K%O+!(B37dK8@m2~'
    'v^7fxM1}219+}KAaOs=jL-ne`=Bos%$gCu0K*9n{Y#h*CBi3TL6HhloxR{6tRx?RK?N3S={i4>Pk2W+~`Bt|?ok_A0xf1}~1C9`2'
    'OuMS^8qbr9C<?Z&%7&%VRL%E+dvbmMDh(f4r-PX|4=12@V|60-q}0l2v`{1n6<!@8z&cwf_Yhe#E_MJMh4c9Ou|n2;4!y;f>hi9>'
    'ig+DAww53H8j^<Z=f!`59~fLh+yo`f6gEiEmHu-(sIH*Qk-hL@GO*b7!6y1Z{D-T{szOhSlsaa&YURVK$6&=FEYF{L>q$$5+>;gq'
    '<YtM9Oyo4Ve*wbcOeWczuLU)XFCY8c=cMbh>t3+7{T|5-Df#`s8d+I4ar_a~n_iqc$LPW=Qe20Uh;VnZz0zf$YY8!g%;~Off2GnX'
    '|M~qF0dBJ^4$u<{XF<#<BMdPs0|nyrZ&VO3pK^-us?xq&>d9U0V03ho24>q8CB^WcE=SvVc9}Y75V<3Yo?=m?PKx-18J5p1u=B@N'
    'BBb)owpQ=HRw@qBB)6w)y~)t0!;#+)(6TW!?-C{P-nNS2WXP@`oi`5!*mssE`BSEwi_TCp0&d<cy@kICn<4)Z*py&tJsMy0_map?'
    'i@!Vvz|oz{bvP(R^fm#@k!A`eHb=ePz7u68fq()zd{GH?T@`^;@ib+U1&7$L&jLO8W5dX`kE)VZt_sY$tQk5r+9#7JEP={RgliyS'
    'f5(7r0U=#f3Ycw#emv=xMlI81Js3aeXHa9oOVY$yvNu8gd?tK6gV->JiLRz%ZHTZEDQs~*|AN9WFn+EFQ1w;#6>;MEcE4xB(|(6$'
    'sHVEEBKBwFB!l(GFjm_)5gwD&qAoJ@h*V{3{BfG*tz%Nq!)M?|)v>gABMyB7+YjY}=I*&X70z%e=WI0QxqD6T7}8;VLjnAX9<|YG'
    ')k<Jh$e@UT)13xqg8~fuZAn=Erx(AJ!#8k9KmK@j14(*;`VS0`IsXz-Hb(tU`mRp<%T99VFgF+j69i~oxyCpoWWIZ!>=O5YgE%T$'
    'H?PGjLij(MkQzim$yd*y@tQAzkuf_-_||SZwFUmsxa;^M<`|yi?{~p0$l?cu(!Hq52<IjcS6kJvc&%`;OyBUWEv)39{Ibf4T$A1E'
    'aJ<SGA2^*EAA#{=CEX-dQ(M~Pu4l^ZV{MAuB(?mjxZtv}*3T&1yHEBQ7z_hdPOc@F(siqBRw{$!e2FW~SxmE7#)9VPV~!4yNR_Op'
    'Xp=qllv^8cE6H9h+JF$I!rs@uHne`2N>loGh{i!GN@c8$A*X2E<E)qx`9JeCUy$8iPz&$eS1YlmTM5G`Ep*1jkV&F}@SF0!{maAo'
    'FY<dx4jC)Oqysw1x~;R7(l;=Teaa%eeU3Wov^2(!e$@m3kL}pw8>Z;rmc(Q~L!~qwC;Okp<n;^Z94|ZX-)J?#&g-Vgu?9P2K?;zU'
    'v-?W*>tO0EBfTD218$kJ8$bC&eYG>;Bmon7+S2wOlj*|ZClV4&Yc)GCSH1gfn<b|iemVfgnyLcYX>?^`Jq9%uZU56{y5UNnH;20k'
    'I6K$IJf{J%j%bBns826D(%bt=<05&SEw9^q2Ehn<40ud(vMSQk_Tq~ev9$&?K)F=dYvs!8<{2ECZZvRhUBa~UbCH<GKD>T|Y~a?c'
    'Ih1I<Jd6dt--fv7OmVY-9Vt*(xBI`u3_k>bt22CNdhf=uEI<6Uk`e(Oy;SFyrejSJa4Q7tbAezoZ4ll~SM79ZA^!58fOWYqVVxg{'
    'Vh*{o&XKP;M0r#CZD7I>++igW?rSYD2Bd!lRyLbxmhY}XSc0~bsgzI$n$NM4=?qcu^-2a`<J7?vJ7y&=Jb*e;;!I&n`=Nb!<sNa}'
    '%00?b^-djXyn|nHrn|Uxz%Q;`xPoKqoe2{4llIQ(?D}K(w;p|$yq~CcmkJRBE2WQ`orf;R+U#9GVPZTefN=h4Na@|n(b2K1tu8+s'
    'O;d@ZH)b@^tSHpIh(x5n5Nl&G&^kZ7`Uqy}JACW*maE~Mr?T`F<cbe#F}{e>{!sHhP<{gCOs^(<dvTQZKKP;9jEr}cw%M==th)@h'
    '$XB_O=1QK64kom{xWeY0&`LN~Z=Np}(C4O##URz-LK*kdYClL22D?ZxcJeY_j}mIbV#Px9^wxDtN^TcZJmQL)@8!P;>?Yt^0U5-k'
    'X%js)ccRLq9J5-SeCwxsnTGLnE?xRo?m%<p0^xL-yspO-VBeQTv~8x;SQhAi6@tVB+xe^dLwtS|+N^YL{b6C8LP*-GoPLVvgV|8x'
    '>q&R*#vF{9*BudaDj+{<PVS`}OHAy+H&HD+^V%I{(xW;z=upn=OR>HJm0}~n&Q#18N~tRZtS6_xd49tCj@aJe)xGPf#bZ0~vDP*B'
    '60w5AQg)kmo#?@Wv0Ax}N+iAFx2dfi`Mf^4hw;X%m=ck)Dw(j5L^!Og-dvF^?MO0(G0AxE=MPYD2@ksS4BOHZpd;G2qoH(%J6lF|'
    'U=yy8kT(z6I}Q;qZvny&R|WuHS5JW`Dm9tnGLCjMArn!Hk)A>6WFDb(7fMuTt@X$bVbapIz9`EL)$g@CGn@w|)jKS*g==ZlX-Y9;'
    'ACYM~IKUp-1kyo2zi3rs=T+=QxLPYkd+N!tymwe%99U-ZM;nMVz4MkpE80A1q4FKaILCin69_4J(LYi#NpbVdpRoLvH^{^sS$RT0'
    'OsdhqBfhQc^dNuT*?&+Zrz!vUWNbQNew1b7X5keq^!9ajVuum~S`~vt;=|Hn0-KE!ebeF`tdCbkFThC&kAh(lcr!_KUzhFk3Xp(S'
    '7usl)JUXVdkJpUC2Aq%}*h@8|HN#4VhQS?a#jNVVku`uX5t6#cw}MYv2On+Gsi?hh_DsEux6q<!@^Dr}a8$k2vDDdsqZ8NMZ>|YU'
    '%TPFhL(Odm;8=emwV;e7_L=ez#S|4cH0l?4tS7?onk%xTE(0&cvigEGNH~0NZQj3+7M~Zm$_Mz2Pp2z^<&Il6muw1@`(8R022vP#'
    '`J<?bupTYRjXY#{$ZS$s;`oVvmFxp6Hn>U!!#9xINRcQ38K?cQpcpZjI(%Igp*I}FmuG6-OSEdm<YNbPfe&LOVsm~mA>^9wdA5FT'
    'nc3Q%>|_=q0{%)l1DvGV^*?mIv70g8?JGYp{@xh%?YbvUP0w&SJHsl=6lM!@M!1`6STQTV7pJ4gdGEVCz@B4!2`U@c3ZuYg%*=Rw'
    'aL{7#(`d*lO7r_&%~CD=%6?Z>@5{clA1Li!#gCfCu55r{pNk2HKYzN6`q#C7(^i8cTxI#F?HakQa|EGWE*1Bmb(61%n+~3f@G##~'
    'PIr>G(w;_T_(~qH?%=Vh7dUTg?%g9g`AUQ8;pi8CqzokLQ>tSGD%7dxdq-9Pf6x!cKg{pPN-)k3wrpWu{~VJ!^l~Bgj{!eMMOLm!'
    'T9){o5Tb;wmLqTT3MrLZVAR&jW{g+V8E36(*<R9X6`I?6oq?s~0alKiN=S|{<Fi43;R45EP{Vr1U}40DIh?5Aq>LbwoCu=l@eQ3c'
    '_QN;X*po%<w(Ub1m|ZYYv;X-Gv-t8A4PG*9wqvn>5ElbSQ-dpRbQ}-a!cI9S|G8PuEQypp*xA<s<5M`P{hh-zkqT@TC*6-^@@xC|'
    'z$hduB4EP1X1o|Q1f2vZz<Uix3zTOB&B57%>1Et&9|5k6?I5h}ZeN}}9;RCi(bX?)rC>Qkio}1z+1$1{kM&*ut8Q!ty7}9<;!GlU'
    'lUa;OaKey>fVJI$glLK5n<U$QAI-}$$&o|HVoRdj-77sFfBVQ_7JOyH7V;zzzF5wVk#hJ9%)2hCPtJr%&ds^+)yXvIo^Eh|e+m&&'
    'gDY&|V`{Op>$dv_8DhN8i3=ktotig&34}5u9ZU6oC%jb%&*%4Z({e7ne-5Ya4_2X;)I+!I4;4<wo@ccRg&LC4H3mC-XxcYRJ0vLd'
    'q9qjMq$7NevFAqFU!p&9-QtF(?lvtW7ufsR_vLIpwWgi)9WSyUzDIN+mF#rZF0l~=p*?zZ`O3U<?^`@tfR`@tGN2M1?<frHI2sdu'
    'Bh<qeOIus1t?p=VDA=JWz$#NtIV(%jbn5oA(E_r>T(;rQr=5AW(IlCyrW)es0MJFD`>+0sSQs5KENBh}$Cw;4qjJ+<=;#B{v3%6$'
    '=tn@)Z=xKS$dqt$^_J>a9?^Esb3im6=9C2*2nv5*>63mLUhu+qoI7a9-AKm0LRe(dI@BiOdWW&BSvU@(%1@g`+}HWO5ytAz+q7?|'
    '2Yc=iFVRkAaHdCoWXs4CkKTTTN7x@kmW<8=1T595e0_caK_AU_z6omfkXBnA^gvZYiW_T(Cdk!9O?(GZkiY-LegKxq;IOd}c8Hcn'
    '8(xawu9TW4j|q+QYX!=qY)v#sfrsac#}ZO7XAtN+t5zems-8y$AFh&rcO$AMN1(iL>0V@8F}m)*9+WLW)T^RM+J1A4gYA?Nwe=*6'
    'gUXqP6yDm{!H;Sbd#F%i49`&+lV-`h>S+toq66$~|2{jD_))VD>-%<8vR<>#Cbo!T8h*3n`cn{^#0rAxC!@4NaAcsc3bj3YHJHCa'
    'xZ?4lT%F02ZOJnu!v`rhn@JG?1Cbn66$KAWhI{Jc)Uc+uFD_U=Z0=E-0hB4pScgKT)f#&!MX_*CyYWHK#3{uR4P{f6;Wj##PGq%#'
    'w!Wk{dojEM9)?g3)17oOb1PsWo4>+u-E4&8;?54v{&de}ueQp!U1PUVWvmVHnFc$5)_52s@2>RFmo|XM`#&ziESxh`MLem(yKm(c'
    '6~Tl&OdxFT`>l87P%*B|fW6m5g}dK=nhL>ji!kTK7xlY!A?h;FB-n2M-|mW+7pThE*Ww|Oan}!!!D$;01$U2^fS4e>#tYmM1e#dv'
    '>w>pq71S6qYLdy~%w@9@f$>)1kPd6&{%8JlEgbw%!P{+Ytxq689BTHnVeTeGeVk%NDJL$J&zBZ0nIEob#YsdI;CP*Jf|x3c@|=Ty'
    'Hete#)=oT%zxoC+S7uo(RTO*py}_sq!bq+7`_THjP2|0=ofA-jOVKs4>?OS}`KhMp8#ZLBSmZ1kwADE~=mOScEIa>yeyeUH%JY;W'
    'p&$8EKZdi%Dw0hQ!l04QonH^!x39z66J$uoI9vLR$uET0iKnacOBo7ekmsTD75zR01s+Pa3|yoP)C39pxNF;kS1pE6bON^(M4DQl'
    '^$i`zwvvHr^uVA=)+@u^ei<@~CdsqY&3;NyYCXGdbhd+$qbWcuN^(*}aYX#-<0`bbRzdUc>xDw1yF3gl3APUF;?;yrG2$Pu2)}i@'
    'eu{&yFkF@6Uh6ZM<?<_WkveDr+@k-w4NfoSqlu(xO}H6$d02;?wr@;|d&{BxM!uWEH3H+XP2c5P<ao2s0Pj-qiEfUP>qIXR5SOV#'
    '2xUvoYNil|(hqwd{$!%|Vs`HU?1__=re>Uv56$7+go48rZt#u6Gp`hYfJQ#-p-~naXLt;71%f`x1)fir;Ocx<%w)^b%J*c9Wkfnw'
    'cfL^d;A(c)rBiUY{Mbk)MvP66$KgGlc54F`kacT^1)~%Poplb&Iuemp3}U_PjhNf;T#CCiAgqg*VZdDI{LH6o6{Q95Cik-AAs+|2'
    'I%>jQC#8?wTj_{m@uidRW#&6rFZRQuXt}GD3Aln}27cA~yG*Z&>ZW2E!`1D#mRwG;ut>ad*Y!T`$T6`7uY#>kDnqdryE8eo<4hJ3'
    'bq7AjvNpTL1LPRI@yoM65RlMm?Bo!gYWctoV%Jqw1Ux1+vp}D4MY?v?eGI&akNH@M#cU^Tgk&n5a(Kwu@du&w5~C}q|9spfe(vyU'
    'jPc3=DvjRwSC<vtBa}NQrWLA3ld><ET-_{A!J_9`wlB_~M#6qxa)CO#QKDMgL1}7;KEi{4i|Mu0N(ye~VBig-PyxP{g*YWNALD#Z'
    '3((KijamS<*$;WH(-4&_SCPcX{M9%=B;H%UQ@dfbzf1&mE?qEKWvls9b#_%Du<=R7h)tBGbbW_fh!Vly`5(1BKRz{#dM-1K`zb*e'
    '>r1sKGrQorGTH+8c#5Y|%BtmEYiaMM*a|v=%%P%s(fEfZhrrv=Eq0bohK)k86lGDHsp*X5bWfjy9l>A)+kiS=%X|~A+}YDfWJxCP'
    'nlii&PC7ifUPeRmrv=@|n#|tAk-{^8q&%l4gnpn%zna0hjDVUcLT<xgh?NI1Y7&Q@XOLX$nT89iLbH%X8m6=z8Gv%->}xzb5ixRW'
    't2|DG;=_wn*2oSA5}~h{73^@HouW+Ovb<vcIZzT*Sfko?=*8z_L9$JC-#_3pfJJRBPOe<G|LKf;NY?maqT9Y%>e_u!g`FB@YQp!H'
    'Rgc23dhtf&qWtOHZLZZuIi(H?U_Pw^5WV>7%*URF5a3Z;SFL)~yR-n=J~}c<IXI%dO65FncXB=gbx!)FwRmXg9EUF77vhiQ7Z^iL'
    '!WlR4dW4G2y&p86xcpWet0I2e^5drSNrY);`2r>8SWp8(j~;etm2#;hMkfM6f9>Z}WJaEIEKa+k9W4ov$r<>&aFy+L%P7l9Cc5f+'
    'AbnnYZwJo3csP&#3-I*yu<A}A%b$gwEa{i?!b`tr!>em28{o-3AzIc**ua2(babEbhX$3qL>o#zeK-)YjHv7pJ+zrn70u`HxAa6H'
    'l^j}n$gR`Ka0}F0;j7{Q$U9r=166;n$E6V_Ql1c;+26@|<9JXO{W*|-a8rt`<BO3kIknA0T|4`~s6FibSj81QcLv11e9O~0A}yww'
    'D&B7l7b&Y!yFuj2lM^1xSHX?u8AqH^m&zm_mb6={5I0@d6+nXwF58q(%f_h8asgk@T4xsMW9VXWVh3FX>$*dlSRbU75*Iw}ayC~S'
    ')EUe<x|%*d+8=pI;oa!GfC7r(Z)8~%qG~VcSS?`u6Hz|v1=YK88A0_`KQLv^g9#rJ!AabkAPd8$KFe+N38&RCS6k!mkL>=-VV6md'
    '2_EQsy><=|aiXbvTvp}jsDTq)-nf1ws<jjd+^%>6m2q%5=swCu(QlZZM@UA5b62KqX40H1UhHg(xB4;MM@OiNz1k69f7&0_?3A}8'
    '+<|%Qz;?oukeMu{eo(|%Xlrj8Kc}S&Dp^o5Uy&(yCuH56);|}TpMP$tHNP$q1Hv9Uy`&c&o(x#}Y09U<&u1FK_5afv4Nt&~Ws$l5'
    'G_e%zXjvwF4j!VDcTnEfWOg4oKuORUiM!x5NuyI_hw#O7+;6JOiuDh^QM*YStzu~N%l?gS&o+_+#3v8Yi@nmfrAV(!FeavECUb?}'
    'cJCN1#`s&ZVUZeIv?GuQ2H==u*>|$gYbdLUTM`%E(3#H>_R63ce#K|Q@w7a-ea(8|m#zh0s^jcO`Qj*cgpjFM9G}H(r9KNqJh-NG'
    '-n~Tix87dVrsa)vv4Et+=3ROfqk^%ne<u~FZfNyUWSH*M?{(PDH;Sb=C}waL3UUTSFZ@q+=ZOE?qT{A2<O;<J^*{zG_O+)d`0Igt'
    '*d86VkeHQWGS<HrJFzBf2#Lfa6A=&Pc!sW~-mRJ_9Jc|Zi$(W2Z99$E2tp_LiU)$4NEkVCv^{D01g+#hkc?dBNThkn8!zZmBXOC^'
    '!SuuEHg^Wb<$B)t%_#<a-NxIU2G1Fw|D|R34+QB5G6ue9WZI@BoyF1$c$-5+CN((dAjv{-@O*56V&qKz3U<w~d%s&R59p~#J<(DG'
    '{YB9keQm?{36mRlkT28ens+l}lG&Z4{<is(a!qfg6vrB;r(++20f`PL649hw0;gQUbibCB(Y7g*UAKD;aXp4LiWx2B=L$xoo{b!c'
    'qus!`)Y@gb5+E?og-a!4kIhifjRiaKOAch3r~!gOMkaJe9>nCXS<{IvoNt*}H2m?_H9%Ilx%G6yIt+5=^RsZ(T~F_C6P}#Mmjv&P'
    '&=*;z8if0)E|m?iP$q*rIr}2v(i1Da5cQih*)sj7adH~I%n@*2d}@AAG`f!VjsbUGjqv3>C56>At_}jYQxcwxsN2-nf$l1#x2#xJ'
    '-Xv#-=~Fj_>Jzwk;#BHzmWy?jT97_w0#jEFY6-fJs7F5rNs`FLK{vK{@^NpvE*UMxBXa$T#>&OTA>){H=H#>vF~j+EcZ%i4lLOSe'
    'kUixR${q@v9{_=~?K_jnlyRT>%lWf)HARhI<Szl}yq7+O#t1r6Y?0PDt0B2Z!V)Vjs|i=wL3O|u*)(<RlW<lXFLaV{3zj_4Z7hg2'
    'SivYBo+Ugiuz;yN<X>fm4mUgk%e(XnmC1pd1w^tn&$j6Fw^a<Z6kqbkGGKGtf1HnH`68fA+Orsxz#xN5Z$?(<hbwC)yA}oWbt1c!'
    'm4b}c422-Ej1cAz7SvLZQ1?|sXL)9>@cc_=3<cI!R=ZHoE?cJqJOXs`1R)g|lnLiiAEpJ3v712Rf7hH?UA2neM4G&R30(mFzW62~'
    'G(WnPdlz}1a<$8*<NRwmyj;ZTGkXk67JY}846T!I&z@mvyo*13-Bh&x*>UFa7Fm{SlZBilYF0D4@P9kiWE#@Kbh^lR{#a1uq!*x{'
    'c{R02aK2GLn+vRw+d?RuM|?r}!2dnftdyd{N5<oDMd+oSBh}7hwk)b<pO~*nPaSx@(Ev$K3wujMyhultMfOEr$HzG4Sm#~P`|l5L'
    'l%J39sO(T04gUQu+NqoAuKltW1e<lG6WulNJ-Gw*G~{=By0LW>ctM$jmD>|zK$nzl#Rg28tl@e~DEopqscjMKu$a{tWsUG?TY5K('
    '2+3beAT6&c;Hb5~)mb=mDglC$_~WX-skbfG%qd(6zAWW6O$V_plh@5cTpVZ1%ypJ!VL1>TN~yXWQoq6<t23g%7hN+@*_GdE$1GR)'
    '#fl+#_Z+hJ)_8C(%BjN{W*UH_szUomn|!4>L*`We^p`%-9RgaoI(D=c-q*)l*=Tjw{9pF5N5X-Kl~#FSl~5|l1WjA?IK_6Yk#v>K'
    'P?JD?s$|^e>w^kbC1S4o9?NJK%q<4!(j(jMKRb?Uk$SJ^cwqpiP|v;t_oFb4TxGn`QT~b%d?lGKT3?%{J|ZOsozBjzj&)YTnrY#D'
    'hkfD8_1d&6>%8epmAFb1YpmvcYq%Qn)1l%Dy+D@i?yQgE_)`azA3jejn+-p--ebg~-AAlJqCx?J5XgvODudQB1;;<<%ngA$?-6^W'
    'cmLaVJnp;sQ)EGfEWQs{6l}*}N$qLQqy3ChWWNe`QFg{0BZ_%H7oNnWa%T<s8#!Yt2664+Q27Q9T5Yaxee*A5a2S-7Fp-8PBvUGU'
    'fts?-a4Jvz2v?_NyK7uXml9Chju;aTfiJ+p?cr;4q&_7A#xJV+3};3~%q$!ewWB4q>4qO?L?4-vZqzb?g5iiIac36b>^<giwJYk&'
    'd$Fq)DCY}=H<vNss*mKd9jZ&&5ai|09YDRequyKI>>`tA0zSQ7_;JU5?*5&3{0Ls;`MTM_Wr9SU@1m6NW_|u57!Ong8U`)6`Iyt^'
    'Tn!bshH<+(@`i*~x@Y|dXp$1zvdPpF$XTrbBLxVxSxzn%2&`)K%(0ZXe8Dl&J7Wef1j*$}^8vPA)qDZMs<oa0O}S>U9XaS%Z6;!G'
    'EcrIcy4Vk9j`n;+C5UNCG))8koi2@|r^2hwIh7^eiR0LNIrQcoWsQuhoKt_--Msd>xTS4_2@8-j-<S(vO)!#9xlqP)Ja8zE@zhCk'
    'RzL;XZBjRwfm^&W*^s)$Eb2W<Q;L<?dZLJss1A;GY6rf<WdjJuHfkWdRh=ZNjfBKmBMiZu3O<qg7@Ifu43g?abj6AHfhJUq;@8tB'
    '*nSVu6A=!SofpGvH%|njHSGV+ZTsRRo6wdIV?Q!sm&2<<q{M_2)L8TKB`{^&z_OTVg#l|z#W}dq5!?BL8S(=Wr6Jx#0-i6#?<qfp'
    'm&r3_Z65-=dYr&#Sxg-_od(N5IvN5XQ96IYs5pVJst+5pU37~@#Tl7k2`YW#ich8xvuxr_@fZTWep<)8x*yoD??rE?<m57Vj`sGZ'
    'UTK1<w^8GjZp9bPI$L^e9r9~DZ{`9+83kldPipRFt_eg)JodHkRuX!|H0>`VXd$tf^}7r1BQGG)7N|4L_p1zA>8W6ODs2-OScJMP'
    'dmJPYpNFZ`>`wcMAUhecypNZzxDLVuuz6aQ!r}8fg*Hh6cnqRi&zYta4boy`{D$P%sdeSq+;EP)UxqRExq#qR`REK%Ra!bI2u0um'
    'Xnl39)37JAFNHZy(nRCWYXwl+;o^(;Dh(}a?>y=fwoIHUf#C~EE2ri#n*40X+^0fWF|6cs&joS9cHiM|k9*8|`<Y*Bm=}Kr&v#vz'
    's;vDI>RNY=>eYLua|@X{H_N7yxx#c`?OcgJzn1n)QeRw2R9a3Ny({+ZV)nq+a!h+RnCMO^cN(fE46OY^b6o=*sp4Z^Yu@+2@Q~Ju'
    '045yw_1qMa`rG|<l2?$H2?nv8MoH)dLYVuj(Xo<N?nC8xIF@GXo6c8C)nrEOuoSjZ`yNNw&~=l860lTc(-}PkWuIjp9FJ1ER{)7f'
    'n96?g1qzP4kM7;REtNz%WRQvck0nMg${jIQmmoRt(Wo6&?Ec3=7phi={kPvMpm7_T&L<n8{?u1O4$KYG;f?r?jvn1uq>uDlzYILT'
    'SrWm;V>0%|Q|H!oN1pvKJ7;ByXw)_iR!fqZ9P#N<Ec%{r(|rZwM_jiH>uOU<4zcFQq&`LZpn{4(d2c*nNPB(I3zKn<zJdZaE!M1T'
    '&(&GZ{4M){BtM-QqBxrr=Hik=_{~Bkc^k{qdo9p;t#&Y#Su<p(mf#=CH~*VQ1rh`KpJj%P$nNg!Qov!)^EW3`@Edu3=nggY`S(lg'
    'FYD}~qh*uP?kMHJxBL*%bkOG;5h29uPOnMV-ee^h6?F{$L2c8IZ`F#d9xev}g4!*#o)V<&NIp<<H#)>U7J&S@&VjKESK9_>frJTF'
    'Tlmvcb2PNyz7>Tnw+?u<;JJQZb*>P)PgWdPMStfZ<xEy*Rfut3W4D34oE7ao6{=l3*TWLpzZ?akn{jpt=QE=Bh=XZ3{b*Hl_qf-L'
    'j`k1s%Ry}164+Yz`N}@bo`^ejBtm>9^NvaKF0VIrx<2d%0)3Q7S>jTC3;4ytjU@xKegFyFv8?bs^<PdfB&7*>eLkZRuh1f^rE&}~'
    'iXnPiESU2MHbh5AhkX{5x&(!A1NA%;ru{;X*=f5siu>#oO@zT-yiKt$iQfmcwcso{Hz_*S*Y^EzqE&zYAii4KW#99|oX96hBJaCo'
    'zHm9?xqvPoIF}Ld)Q$6Wm53+Gf^SBeh=sOwbG$O5roLA`i?gRE%cEY=@1FOBbe<+n#fU{Yy6;>PcAdIUbeOIK85^)^a<s>*y^Tp2'
    'uK{1okILf3wc8WJ-vNo9b{55&UkMd&rpBW9Bw_U++9FHBv1Z1CQ6?*6yv6GLU9Uz-bw5y3(aNA%Eu_Qs;$21i0fH8U%6HR9xZ~9V'
    'gW>rtHy<Jv&=3AKu>y;DXWPlZB6H9ClHvq?!ECl=Kg4LHU=cP3yOU)PRqjrY-bBTD0L*-i%-=_7$x#n3q8F=VbBS(ZI~Q+EfeJ<g'
    'f1i<bA_l<|Y9b!_AW{Gj;KhcHkDUPV1qyPc#H>9(-dOi&cD2#Y6Z)-gEW0ZuohM~Au&W(&93wHSkp$L)5Sqk=qWl}J{aP0UcHjz@'
    '*5>@&*gXh?6(M>e$=|yVo?Z(ISaRNB8G9D_5@%mWul8F>&y;MIT6TSM^l#vElH|fLMzd*_{*aHx1HSt=<Dnl$(1QPX4bl8h^IO;^'
    '45bJ~N?mBHsasVW8k$M}Ua)cN&a<;ITJPzs4pZ_+U9qWtyvl$Xt}{k1?@dOc-doQ%T*lf?_y61(ToGC&-A640SzlQh0et5{q^Vb9'
    '4pRrVP|d>)0D@D)4FU~n!oXI1empuD^wKuJC<2Ri?7T~|MJ?v%wK>GP#8ruYE`9#7qhD<Og(ElJMstren^KbMCX$jq712ZpQ*r{V'
    'yNn@}gD@&YcJx-0eW{>cQwgM#Q^A2Z#7vEB1#oE^CGtZO{OD`Hx9OMzIKkupufZgJ*cNK1kfeMttFVs}8s`1gJ3wP?!)oc#*USc7'
    'dHCHO;(8_a-gG5w>dKdPXXEHzDaLQ<3z#`g`?;zYUKZK1N$o1x2rf|039_u6`5by|NHSVD&X;GH*NMY+N|bZ+;|^bdvR`lnZd2=^'
    'zTxE_?}{OCI3i3fod4lNXWY-~`zh#(h#vZ!GmDdC^YG02cxA;DC}5qkS4xr7+rkn(dE@pY+oy?f{l>6(`9EcY8@;irtZ<};F~hbs'
    'O?y{3x9z^9srmj{_Je!&TCN47BX#o}xM4H97RZ}fCkUW4(Ja|qT1emFgIVn#0dsgI#U&Ysg5i=u@x#TVpJp|xVlp2%cmb77F|Oj5'
    '?|`kPvauK5xS>Urdmba<Bo$j9BeB)fv_?VJ3IHH@NUA#?jTc*J5!F$LL99p1T!lKPQ`;_0w}(7lO6sn2R@}T&_4<L#2oH}|7r=)b'
    'yqTP|<@*fg%7Q;d;zn1P(cs<tU0>^332wlp;k=CNL?jV(iS)jzTp)7c#2S<!h}+EYT9Nvp!=v6ABV&;q3wlbF3bF7GedQmv$M|X!'
    '!wmj7Xhwh9+!2(CRSVBl-dqO@j{0x)D(hTfI)?8AtV+80@!j63KFS<OFbOiSmCZfMEnXW0VV9Y1^YWTN8JfoRC9;FuS?sV&a6O2M'
    'Bog|Nl!9R<hUxOG{jNcVgPQ)OaL%@#cXZkxsT}5~PEgL*L{+=2L?=)rZX(Hvgs&{A{*#8d;q)*_p|0z-`)Q3sIqlf9y-?7PJ;}(k'
    '4s?PnP{r*3rXN!a)2W=T6A6j@^o7}Y&1PHvZ+LQYa~%NY_vDw{Ddb<*w?%`otD)pfZM-ao^ok*ZXh7!f80XVsQ65y-ZSTcJ>AsE_'
    'JLe6MM!zARMUGUD$CBw#Wj!M3saboYl>BP7s#FjG$8;x1ul5$dN())AR^$e8g&P_I+I>q#aVOA^nt8gp0mKWb>;ETg|L#_!Lkv=1'
    'NM<Eoe=bWt=>8sQ;)u=%<UdpuUV)b5Vc`HIvN5u_Euj-xgPSj3!0dCE$ufs9H(WL`c-k7}sLoz)e8H@%bMM%6C=PvaN>P$(yXNjs'
    'J$l#l#3v2T5)UglT;4X6ql*ObA@^+k7zs^SCMWL(bxAv71^?SxQ`&b<lBrBtuyfR}cUunc-Y#T_Mm!QGsMDCez)<#|yZM?SbSS@!'
    'gW)I8-z;Bz3X1Mv;Z??2j7D%;kc17~3eQBvO5CT7XvIPc6Gq2z#r3|Pxy}V|Bihw6qQ;Y>6FpBOe<Se$O!+{m3H?Hb8A>)|c`hsl'
    'M{evYA$XeR6X=NkrHKoiuYQ|mje5Ezg<w5Tg1GVpbA|ASFF}f+Jzd%u0|8jXzv=^FETRnNbX0(JM~r-Y|KL67GiP=PS98be0}Lt{'
    '@3_|?Hy)txth!H%t>ld~Z7*{7^%eZ0*yBG|FRYeB<QAF#KJpiv>Uf~pXo$m8bsk^yeo+U5b(Mib9P*B)lj0U$ZBf_+6xX^_T+nLp'
    'wUlD|<IY_gL~7yYb2QT!Q~*b*dzLf&6tC8Or+H3Z?03le3YzDoX5I<0PF0pV7eoR$BI#;QS~yduzi@H_3^!4X84#8ZN~bfe*lX;4'
    '(svUZKuro9cPq1L&iX+@w1!TYTw!d93%Wn#;<=@cK$O2q1pPvPvJ6-b)~0H{I<M4fXdzEK)R|BaE_dQ!aSTG_SaCDOmto#1oYVw^'
    'Q*iav=s3auf_eHm81}iQOEFQK%e|ck@}hEo-G*0x_xVSZC@F1<a?S!HF}v9C$nc&76pO$^_h$s22n79%Ki^mixm2Jk*H(0L+CZ_h'
    'r*TQ*N5*t7e7Nq6bi0BDn9lGBt?SHP&Z|!A49Oma<f-oZ(s!Uf`Ddh+BipR_N9`x${c7n?J$D|eQE_v=vJb5v_kaN~-eHOlXo9r4'
    '<dXMl;bgWLo@GIUo8o`ZL<~8vS73?m{RuZ%&7|rR1!&2k(4PdYE{O=c&I%14;K>2v;G`x(1ufuxFjgc2vRFNtuUnka00000fweV!'
    '8Cc|n00Gwi1l_k5$$3?!vBYQl0ssI200dcD'
)

PROVER_NAME = "false-solver-d6"
PROVER_SCHEMA = "stage2-false-countermodel-prover-result-v1"

_TABLE_BYTES = None


class _SafetyWallExpired(Exception):
    pass


def _safety_wall_handler(_signum, _frame):
    raise _SafetyWallExpired("False prover safety wall expired")


def _arm_safety_wall(seconds):
    if not (
        hasattr(signal, "setitimer")
        and hasattr(signal, "SIGALRM")
        and hasattr(signal, "ITIMER_REAL")
    ):
        return None
    previous = signal.signal(signal.SIGALRM, _safety_wall_handler)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    return previous


def _disarm_safety_wall(previous):
    if previous is None:
        return
    signal.setitimer(signal.ITIMER_REAL, 0.0)
    signal.signal(signal.SIGALRM, previous)


def _runtime_config(config):
    if not isinstance(config, dict):
        raise TypeError("config must be an object")
    copied = dict(config)
    save_mode = copied.pop("result_save_mode", "minimal")
    if save_mode not in ("minimal", "full"):
        raise ValueError("result_save_mode must be minimal or full")
    nested = copied.pop("search_config", None)
    if nested is not None:
        if copied:
            raise ValueError("nested search_config cannot be mixed with top-level fields")
        if not isinstance(nested, dict):
            raise TypeError("search_config must be an object")
        copied = dict(nested)
    unknown = sorted(set(copied) - {"safety_wall_seconds", "use_finite_model_bank"})
    if unknown:
        raise ValueError(f"unknown config fields: {unknown}")
    seconds = float(copied.get("safety_wall_seconds", 295.0))
    enabled = copied.get("use_finite_model_bank", True)
    if not 0.01 <= seconds <= 3600.0:
        raise ValueError("safety_wall_seconds must be in [0.01, 3600]")
    if type(enabled) is not bool:
        raise TypeError("use_finite_model_bank must be a boolean")
    return save_mode, seconds, enabled


def _case_formulas(case):
    if not isinstance(case, dict):
        raise TypeError("case must be an object")
    source = case.get("source_formula")
    target = case.get("target_formula")
    if not isinstance(source, str) or not source.strip():
        raise ValueError("case.source_formula must be a non-empty string")
    if not isinstance(target, str) or not target.strip():
        raise ValueError("case.target_formula must be a non-empty string")
    return case.get("ordinal"), case.get("id"), source, target


def _strip_outer_parentheses(text):
    text = text.strip()
    while len(text) >= 2 and text[0] == "(" and text[-1] == ")":
        depth = 0
        covers_all = True
        for index, character in enumerate(text):
            if character == "(":
                depth += 1
            elif character == ")":
                depth -= 1
                if depth < 0:
                    raise ValueError("unbalanced equation parentheses")
            if depth == 0 and index < len(text) - 1:
                covers_all = False
                break
        if not covers_all:
            break
        if depth != 0:
            raise ValueError("unbalanced equation parentheses")
        text = text[1:-1].strip()
    return text


def _parse_term(text, variable_indices):
    text = _strip_outer_parentheses(text)
    depth = 0
    last_operation = -1
    for index, character in enumerate(text):
        if character == "(":
            depth += 1
        elif character == ")":
            depth -= 1
            if depth < 0:
                raise ValueError("unbalanced equation parentheses")
        elif character == "◇" and depth == 0:
            last_operation = index
    if depth != 0:
        raise ValueError("unbalanced equation parentheses")
    if last_operation >= 0:
        return (
            _parse_term(text[:last_operation], variable_indices),
            _parse_term(text[last_operation + 1 :], variable_indices),
        )
    if len(text) == 1 and text in variable_indices:
        return variable_indices[text]
    raise ValueError(f"cannot parse term: {text!r}")


def _parse_equation(text):
    normalized = text.replace("*", "◇")
    if normalized.count("=") != 1 or "≠" in normalized:
        raise ValueError("formula must contain exactly one equality")
    variables = []
    seen = set()
    for variable in re.findall(r"\b([a-z])\b", normalized):
        if variable not in seen:
            seen.add(variable)
            variables.append(variable)
    if not variables:
        raise ValueError("formula has no variables")
    indices = {variable: index for index, variable in enumerate(variables)}
    lhs, rhs = normalized.split("=", 1)
    return variables, _parse_term(lhs, indices), _parse_term(rhs, indices)


def _eval_term(term, values, table):
    if type(term) is int:
        return values[term]
    return table[_eval_term(term[0], values, table)][
        _eval_term(term[1], values, table)
    ]


def _equation_holds(parsed, table):
    variables, lhs, rhs = parsed
    checked = 0
    for values in product(range(len(table)), repeat=len(variables)):
        checked += 1
        left = _eval_term(lhs, values, table)
        right = _eval_term(rhs, values, table)
        if left != right:
            return False, checked, {
                "assignment": dict(zip(variables, values)),
                "lhs": left,
                "rhs": right,
            }
    return True, checked, None


def _table_bytes():
    global _TABLE_BYTES
    if _TABLE_BYTES is None:
        raw = lzma.decompress(base64.b85decode(_TABLES_XZ_B85))
        if len(raw) != _TABLE_RAW_BYTES:
            raise ValueError("finite-model payload length drift")
        _TABLE_BYTES = raw
    return _TABLE_BYTES


def _tables():
    raw = _table_bytes()
    position = 0
    for model_index in range(_MODEL_COUNT):
        if position >= len(raw):
            raise ValueError("finite-model payload ended early")
        order = raw[position]
        end = position + 1 + order * order
        if order == 0 or end > len(raw):
            raise ValueError("invalid finite-model payload")
        flat = raw[position + 1 : end]
        if any(value >= order for value in flat):
            raise ValueError("finite-model entry outside carrier")
        yield model_index, [
            list(flat[row * order : (row + 1) * order])
            for row in range(order)
        ]
        position = end
    if position != len(raw):
        raise ValueError("finite-model payload has trailing bytes")


def _table_sha256(table):
    canonical = json.dumps(
        table, ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _countermodel(parsed_source, parsed_target, table, metrics):
    source_holds, checked, _failure = _equation_holds(parsed_source, table)
    metrics["assignments_checked"] += checked
    if not source_holds:
        return None
    target_holds, checked, failure = _equation_holds(parsed_target, table)
    metrics["assignments_checked"] += checked
    if target_holds:
        return None
    return {
        "order": len(table),
        "carrier": list(range(len(table))),
        "table": table,
        "source_verified": True,
        "target_counterexample": failure,
        "validation_mode": "exhaustive_finite_table_full_scan",
    }


def _affine_parameters(table):
    order = len(table)
    constant = table[0][0]
    left = (table[1][0] - constant) % order if order > 1 else 0
    right = (table[0][1] - constant) % order if order > 1 else 0
    if all(
        table[row][column]
        == (left * row + right * column + constant) % order
        for row in range(order)
        for column in range(order)
    ):
        return left, right, constant
    return None


def _small_table_false_code(table):
    order = len(table)
    encoded = "[" + ",".join(
        "[" + ",".join(str(value) for value in row) + "]" for row in table
    ) + "]"
    return (
        "import JudgeProblem\n"
        "import JudgeDecide.DecideBang\n"
        "import JudgeFinOp.MemoFinOp\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n"
        "open MemoFinOp\n\n"
        "def submission : Goal := by\n"
        f"  let m : Magma (Fin {order}) := {{\n"
        f'    op := finOpTable "{encoded}"\n'
        "  }\n"
        f"  refine ⟨Fin {order}, m, ?_⟩\n"
        "  decideFin!\n"
    )


def _lean_term(term, variables, operation="d6Affine"):
    if type(term) is int:
        return variables[term]
    left = _lean_term(term[0], variables, operation)
    right = _lean_term(term[1], variables, operation)
    return f"{operation} ({left}) ({right})"


def _affine_false_code(table, parameters, parsed_source, parsed_target, failure):
    order = len(table)
    left, right, constant = parameters
    source_variables, source_lhs, source_rhs = parsed_source
    target_variables, target_lhs, target_rhs = parsed_target
    source_left = _lean_term(source_lhs, source_variables)
    source_right = _lean_term(source_rhs, source_variables)
    witness = failure["assignment"]
    target_arguments = " ".join(
        f"({witness[variable]} : Fin {order})" for variable in target_variables
    )
    witness_variables = {
        index: f"({witness[variable]} : Fin {order})"
        for index, variable in enumerate(target_variables)
    }
    target_left = _lean_term(target_lhs, witness_variables)
    target_right = _lean_term(target_rhs, witness_variables)
    failure_left = failure["lhs"]
    failure_right = failure["rhs"]
    return (
        "import JudgeProblem\n"
        "import Mathlib.Tactic\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n\n"
        f"abbrev d6Carrier := Fin {order}\n\n"
        f"def d6Affine (i j : Fin {order}) : Fin {order} :=\n"
        f"  ({left} : Fin {order}) * i + ({right} : Fin {order}) * j + "
        f"({constant} : Fin {order})\n\n"
        f"@[reducible] def d6Magma : Magma (Fin {order}) := "
        "{ op := d6Affine }\n\n"
        f"local instance : Magma (Fin {order}) := d6Magma\n\n"
        f"def d6Source : EquationLHS (Fin {order}) := by\n"
        f"  intro {' '.join(source_variables)}\n"
        f"  change {source_left} = {source_right}\n"
        "  apply Fin.ext\n"
        "  simp [d6Affine] <;> omega\n\n"
        f"def d6Target : ¬ EquationRHS (Fin {order}) := by\n"
        "  intro h\n"
        f"  have bad := h {target_arguments}\n"
        f"  change {target_left} = {target_right} at bad\n"
        f"  change ({failure_left} : Fin {order}) = "
        f"({failure_right} : Fin {order}) at bad\n"
        f"  exact (show ({failure_left} : Fin {order}) ≠ "
        f"({failure_right} : Fin {order}) by decide) bad\n\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        "  exact ⟨MemoFinOp.d6Carrier, MemoFinOp.d6Magma, "
        "MemoFinOp.d6Source, MemoFinOp.d6Target⟩\n"
    )


def _prime_power(order):
    for prime in (2, 3, 5, 7, 11, 13):
        value = order
        exponent = 0
        while value > 1 and value % prime == 0:
            value //= prime
            exponent += 1
        if value == 1 and exponent >= 2:
            return prime, exponent
    return None


def _vector_digits(value, prime, dimension):
    digits = []
    for _ in range(dimension):
        digits.append(value % prime)
        value //= prime
    return digits


def _vector_value(digits, prime):
    value = 0
    place = 1
    for digit in digits:
        value += digit * place
        place *= prime
    return value


def _vector_add(left, right, prime, dimension):
    return _vector_value(
        [
            (x + y) % prime
            for x, y in zip(
                _vector_digits(left, prime, dimension),
                _vector_digits(right, prime, dimension),
            )
        ],
        prime,
    )


def _vector_sub(left, right, prime, dimension):
    return _vector_value(
        [
            (x - y) % prime
            for x, y in zip(
                _vector_digits(left, prime, dimension),
                _vector_digits(right, prime, dimension),
            )
        ],
        prime,
    )


def _vector_affine_parameters(table):
    decomposition = _prime_power(len(table))
    if decomposition is None:
        return None
    prime, dimension = decomposition
    order = len(table)
    constant = table[0][0]
    left_map = [
        _vector_sub(table[value][0], constant, prime, dimension)
        for value in range(order)
    ]
    right_map = [
        _vector_sub(table[0][value], constant, prime, dimension)
        for value in range(order)
    ]
    if not all(
        table[i][j]
        == _vector_add(
            _vector_add(left_map[i], right_map[j], prime, dimension),
            constant,
            prime,
            dimension,
        )
        for i in range(order)
        for j in range(order)
    ):
        return None
    if not all(
        left_map[_vector_add(i, j, prime, dimension)]
        == _vector_add(left_map[i], left_map[j], prime, dimension)
        and right_map[_vector_add(i, j, prime, dimension)]
        == _vector_add(right_map[i], right_map[j], prime, dimension)
        for i in range(order)
        for j in range(order)
    ):
        return None
    left_columns = [
        _vector_digits(left_map[prime**index], prime, dimension)
        for index in range(dimension)
    ]
    right_columns = [
        _vector_digits(right_map[prime**index], prime, dimension)
        for index in range(dimension)
    ]
    return {
        "prime": prime,
        "dimension": dimension,
        "left_columns": left_columns,
        "right_columns": right_columns,
        "constant": _vector_digits(constant, prime, dimension),
    }


def _product_type(prime, dimension):
    result = f"Fin {prime}"
    for _ in range(dimension - 1):
        result = f"Fin {prime} × ({result})"
    return result


def _coordinate(variable, index, dimension):
    if index == dimension - 1:
        return variable + ".2" * index
    return variable + ".2" * index + ".1"


def _tuple_expression(expressions):
    result = expressions[-1]
    for expression in reversed(expressions[:-1]):
        result = f"⟨{expression}, {result}⟩"
    return result


def _linear_coordinate(variable, row, columns, prime, dimension):
    terms = []
    for column in range(dimension):
        coefficient = columns[column][row]
        if coefficient == 0:
            continue
        coordinate = _coordinate(variable, column, dimension)
        if coefficient == 1:
            terms.append(coordinate)
        else:
            terms.append(f"({coefficient} : ℕ) • {coordinate}")
    return " + ".join(terms) if terms else f"(0 : Fin {prime})"


def _vector_literal(value, prime, dimension):
    return _tuple_expression(
        [f"({digit} : Fin {prime})" for digit in _vector_digits(value, prime, dimension)]
    )


def _integer_linear_term(term, variable_count, parameters):
    dimension = parameters["dimension"]
    if type(term) is int:
        return [
            {(term, coordinate): 1} for coordinate in range(dimension)
        ]
    left = _integer_linear_term(term[0], variable_count, parameters)
    right = _integer_linear_term(term[1], variable_count, parameters)
    result = []
    for row in range(dimension):
        combined = {}
        for columns, values in (
            (parameters["left_columns"], left),
            (parameters["right_columns"], right),
        ):
            for column in range(dimension):
                multiplier = columns[column][row]
                for key, coefficient in values[column].items():
                    combined[key] = combined.get(key, 0) + multiplier * coefficient
        result.append({key: value for key, value in combined.items() if value})
    return result


def _source_zsmul_coefficients(parsed_source, parameters):
    source_variables, source_lhs, source_rhs = parsed_source
    coefficients = set()
    for term in (source_lhs, source_rhs):
        for coordinate in _integer_linear_term(
            term, len(source_variables), parameters
        ):
            coefficients.update(value for value in coordinate.values() if value > 1)
    return sorted(coefficients)


def _vector_affine_false_code(
    table, parameters, parsed_source, parsed_target, failure
):
    prime = parameters["prime"]
    dimension = parameters["dimension"]
    carrier = _product_type(prime, dimension)
    coordinates = []
    for row in range(dimension):
        left = _linear_coordinate(
            "i", row, parameters["left_columns"], prime, dimension
        )
        right = _linear_coordinate(
            "j", row, parameters["right_columns"], prime, dimension
        )
        constant = parameters["constant"][row]
        coordinates.append(f"({left}) + ({right}) + ({constant} : Fin {prime})")
    affine_body = _tuple_expression(coordinates)
    source_variables, source_lhs, source_rhs = parsed_source
    target_variables, target_lhs, target_rhs = parsed_target
    source_left = _lean_term(source_lhs, source_variables)
    source_right = _lean_term(source_rhs, source_variables)
    witness = failure["assignment"]
    target_arguments = " ".join(
        _vector_literal(witness[variable], prime, dimension)
        for variable in target_variables
    )
    witness_variables = {
        index: _vector_literal(witness[variable], prime, dimension)
        for index, variable in enumerate(target_variables)
    }
    target_left = _lean_term(target_lhs, witness_variables)
    target_right = _lean_term(target_rhs, witness_variables)
    left_digits = _vector_digits(failure["lhs"], prime, dimension)
    right_digits = _vector_digits(failure["rhs"], prime, dimension)
    different_index = next(
        index
        for index, (left, right) in enumerate(zip(left_digits, right_digits))
        if left != right
    )
    projection = _coordinate("q", different_index, dimension)
    failure_left = left_digits[different_index]
    failure_right = right_digits[different_index]
    zsmul_coefficients = _source_zsmul_coefficients(parsed_source, parameters)
    if any(coefficient % prime not in (0, 1) for coefficient in zsmul_coefficients):
        raise ValueError("vector source coefficients do not reduce to identity")
    zsmul_lemmas = "".join(
        f"theorem d6Zsmul{coefficient} (x : Fin {prime}) : "
        f"({coefficient} : ℤ) • x = "
        f"{'0' if coefficient % prime == 0 else 'x'} := by\n"
        "  fin_cases x <;> decide\n\n"
        for coefficient in zsmul_coefficients
    )
    zsmul_names = ", ".join(
        f"d6Zsmul{coefficient}" for coefficient in zsmul_coefficients
    )
    if zsmul_names:
        source_proof = (
            "  ext <;> simp [d6Affine] <;> abel_nf <;>\n"
            f"    simp only [{zsmul_names}, zero_add, add_zero]\n\n"
        )
    else:
        source_proof = "  ext <;> simp [d6Affine] <;> abel_nf\n\n"
    return (
        "import JudgeProblem\n"
        "import Mathlib.Tactic\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n\n"
        f"abbrev d6Carrier := {carrier}\n\n"
        "def d6Affine (i j : d6Carrier) : d6Carrier :=\n"
        f"  {affine_body}\n\n"
        f"{zsmul_lemmas}"
        "@[reducible] def d6Magma : Magma d6Carrier := { op := d6Affine }\n\n"
        "local instance : Magma d6Carrier := d6Magma\n\n"
        "def d6Source : EquationLHS d6Carrier := by\n"
        f"  intro {' '.join(source_variables)}\n"
        f"  change {source_left} = {source_right}\n"
        f"{source_proof}"
        "def d6Target : ¬ EquationRHS d6Carrier := by\n"
        "  intro h\n"
        f"  have bad := h {target_arguments}\n"
        f"  change {target_left} = {target_right} at bad\n"
        f"  have badCoordinate := congrArg (fun q : d6Carrier => {projection}) bad\n"
        f"  change ({failure_left} : Fin {prime}) = "
        f"({failure_right} : Fin {prime}) at badCoordinate\n"
        f"  exact (show ({failure_left} : Fin {prime}) ≠ "
        f"({failure_right} : Fin {prime}) by decide) badCoordinate\n\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        "  exact ⟨MemoFinOp.d6Carrier, MemoFinOp.d6Magma, "
        "MemoFinOp.d6Source, MemoFinOp.d6Target⟩\n"
    )


def _compact_table_false_code(table):
    order = len(table)
    alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if order > len(alphabet):
        raise ValueError("compact Base36 table only supports orders up to 36")
    encoded = "".join(alphabet[value] for row in table for value in row)
    if len(encoded) != order * order:
        raise ValueError("compact finite-table encoding length drift")
    return (
        "import JudgeProblem\n"
        "import JudgeDecide.DecideBang\n"
        "import JudgeFinOp.MemoFinOp\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n\n"
        "private def decodeBase36V2 (c : Char) : Nat :=\n"
        "  if c.isDigit then c.toNat - '0'.toNat\n"
        "  else c.toNat - 'A'.toNat + 10\n\n"
        "def base36TableV2 (s : String) (i j : Fin n) : Fin n :=\n"
        "  let vals := s.toList.map decodeBase36V2\n"
        "  let idx := i.val * n + j.val\n"
        "  ⟨(vals.getD idx 0) % n,\n"
        "    Nat.mod_lt _ (Nat.lt_of_le_of_lt (Nat.zero_le i.val) i.isLt)⟩\n\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        f"  let m : Magma (Fin {order}) := {{\n"
        f'    op := MemoFinOp.base36TableV2 "{encoded}"\n'
        "  }\n"
        f"  refine ⟨Fin {order}, m, ?_⟩\n"
        "  decideFin!\n"
    )


def _false_code(table, parsed_source, parsed_target, failure):
    order = len(table)
    if order <= 10:
        return _small_table_false_code(table), "finOpTable_single_digit_decideFin"
    parameters = _affine_parameters(table)
    if parameters is not None:
        return (
            _affine_false_code(
                table, parameters, parsed_source, parsed_target, failure
            ),
            "fin_scalar_affine_symbolic",
        )
    vector_parameters = _vector_affine_parameters(table)
    if (
        vector_parameters is not None
        and not any(vector_parameters["constant"])
        and all(
            coefficient % vector_parameters["prime"] in (0, 1)
            for coefficient in _source_zsmul_coefficients(
                parsed_source, vector_parameters
            )
        )
    ):
        return (
            _vector_affine_false_code(
                table,
                vector_parameters,
                parsed_source,
                parsed_target,
                failure,
            ),
            "fin_vector_affine_symbolic",
        )
    return _compact_table_false_code(table), "base36_compact_table_decideFin"


def _base_result(ordinal, case_id, status, stop_reason, save_mode, metrics):
    return {
        "schema_version": PROVER_SCHEMA,
        "prover_name": PROVER_NAME,
        "ordinal": ordinal,
        "id": case_id,
        "status": status,
        "stop_reason": stop_reason,
        "result_save_mode": save_mode,
        "certificate_valid": None,
        "verdict": None,
        "judge_verdict": None,
        "metrics": dict(metrics),
    }


def prove(case, config):
    """Exhaustively scan one deduplicated bank of static finite models."""

    started = time.monotonic()
    ordinal = case.get("ordinal") if isinstance(case, dict) else None
    case_id = case.get("id") if isinstance(case, dict) else None
    save_mode = "minimal"
    previous_alarm = None
    trace = []
    metrics = {
        "architecture": "false-solver-d6-minimal-finite-table-scan-v1",
        "model_checks": 0,
        "assignments_checked": 0,
        "stage_events": 0,
        "elapsed_seconds": 0.0,
    }
    try:
        save_mode, safety_seconds, enabled = _runtime_config(config)
        ordinal, case_id, source, target = _case_formulas(case)
        parsed_source = _parse_equation(source)
        parsed_target = _parse_equation(target)
        previous_alarm = _arm_safety_wall(safety_seconds)
        if enabled:
            for model_index, table in _tables():
                metrics["model_checks"] += 1
                details = _countermodel(
                    parsed_source, parsed_target, table, metrics
                )
                if details is None:
                    continue
                model_sha256 = _table_sha256(table)
                metrics["stage_events"] = 1
                metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                details.update(
                    {
                        "frozen_model_sha256": model_sha256,
                        "frozen_model_index": model_index,
                        "frozen_library": "unified_static_finite_bank",
                    }
                )
                stage = "stage0_unified_finite_model_full_scan"
                trace.append(
                    {
                        "seq": 1,
                        "stage": stage,
                        "event": "hit",
                        "models_scanned": metrics["model_checks"],
                        "model_index": model_index,
                        "model_sha256": model_sha256,
                    }
                )
                judge_lean, certificate_encoding = _false_code(
                    table,
                    parsed_source,
                    parsed_target,
                    details["target_counterexample"],
                )
                details["certificate_encoding"] = certificate_encoding
                result = _base_result(
                    ordinal,
                    case_id,
                    "REFUTED",
                    "COUNTERMODEL_FOUND",
                    save_mode,
                    metrics,
                )
                result.update(
                    {
                        "certificate_valid": True,
                        "certificate_kind": "finite_magma_countermodel",
                        "verdict": False,
                        "judge_verdict": "false",
                        "stage": stage,
                        "countermodel": details,
                        "judge_lean": f"-- stage:{stage}\n" + judge_lean,
                    }
                )
                if save_mode == "full":
                    result["trace"] = trace
                return result
        metrics["stage_events"] = 1
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        if save_mode == "full":
            trace.append(
                {
                    "seq": 1,
                    "stage": "stage0_unified_finite_model_full_scan",
                    "event": "miss",
                    "models_scanned": metrics["model_checks"],
                }
            )
        result = _base_result(
            ordinal, case_id, "UNKNOWN", "COUNTERMODEL_NOT_FOUND", save_mode, metrics
        )
        if save_mode == "full":
            result["trace"] = trace
        return result
    except _SafetyWallExpired:
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        result = _base_result(
            ordinal, case_id, "UNKNOWN", "SAFETY_WALL", save_mode, metrics
        )
        if save_mode == "full":
            result["trace"] = trace
        return result
    except Exception as error:
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        result = _base_result(
            ordinal, case_id, "ERROR", "PROVER_ERROR", save_mode, metrics
        )
        result.update(
            {"error_type": type(error).__name__, "diagnostic": str(error)}
        )
        return result
    finally:
        _disarm_safety_wall(previous_alarm)


def _main():
    request = json.loads(sys.stdin.readline())
    result = prove(request.get("case"), request.get("config", {}))
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


__all__ = ["PROVER_NAME", "PROVER_SCHEMA", "prove"]


if __name__ == "__main__":
    _main()
