#!/usr/bin/env python3
"""Minimal formula-only finite-model False solver runtime."""

from __future__ import annotations

import base64
import hashlib
from itertools import product
import json
import lzma
import re
import signal
import sys
import time


# __MODEL_PAYLOAD__

PROVER_NAME = "false-solver-d6"
PROVER_SCHEMA = "stage2-false-countermodel-prover-result-v1"

_TABLE_BYTES = None


class _SafetyWallExpired(Exception):
    pass


def _safety_wall_handler(_signum, _frame):
    raise _SafetyWallExpired("False prover safety wall expired")


def _arm_safety_wall(seconds):
    if not (
        hasattr(signal, "setitimer")
        and hasattr(signal, "SIGALRM")
        and hasattr(signal, "ITIMER_REAL")
    ):
        return None
    previous = signal.signal(signal.SIGALRM, _safety_wall_handler)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    return previous


def _disarm_safety_wall(previous):
    if previous is None:
        return
    signal.setitimer(signal.ITIMER_REAL, 0.0)
    signal.signal(signal.SIGALRM, previous)


def _runtime_config(config):
    if not isinstance(config, dict):
        raise TypeError("config must be an object")
    copied = dict(config)
    save_mode = copied.pop("result_save_mode", "minimal")
    if save_mode not in ("minimal", "full"):
        raise ValueError("result_save_mode must be minimal or full")
    nested = copied.pop("search_config", None)
    if nested is not None:
        if copied:
            raise ValueError("nested search_config cannot be mixed with top-level fields")
        if not isinstance(nested, dict):
            raise TypeError("search_config must be an object")
        copied = dict(nested)
    unknown = sorted(set(copied) - {"safety_wall_seconds", "use_finite_model_bank"})
    if unknown:
        raise ValueError(f"unknown config fields: {unknown}")
    seconds = float(copied.get("safety_wall_seconds", 295.0))
    enabled = copied.get("use_finite_model_bank", True)
    if not 0.01 <= seconds <= 3600.0:
        raise ValueError("safety_wall_seconds must be in [0.01, 3600]")
    if type(enabled) is not bool:
        raise TypeError("use_finite_model_bank must be a boolean")
    return save_mode, seconds, enabled


def _case_formulas(case):
    if not isinstance(case, dict):
        raise TypeError("case must be an object")
    source = case.get("source_formula")
    target = case.get("target_formula")
    if not isinstance(source, str) or not source.strip():
        raise ValueError("case.source_formula must be a non-empty string")
    if not isinstance(target, str) or not target.strip():
        raise ValueError("case.target_formula must be a non-empty string")
    return case.get("ordinal"), case.get("id"), source, target


def _strip_outer_parentheses(text):
    text = text.strip()
    while len(text) >= 2 and text[0] == "(" and text[-1] == ")":
        depth = 0
        covers_all = True
        for index, character in enumerate(text):
            if character == "(":
                depth += 1
            elif character == ")":
                depth -= 1
                if depth < 0:
                    raise ValueError("unbalanced equation parentheses")
            if depth == 0 and index < len(text) - 1:
                covers_all = False
                break
        if not covers_all:
            break
        if depth != 0:
            raise ValueError("unbalanced equation parentheses")
        text = text[1:-1].strip()
    return text


def _parse_term(text, variable_indices):
    text = _strip_outer_parentheses(text)
    depth = 0
    last_operation = -1
    for index, character in enumerate(text):
        if character == "(":
            depth += 1
        elif character == ")":
            depth -= 1
            if depth < 0:
                raise ValueError("unbalanced equation parentheses")
        elif character == "◇" and depth == 0:
            last_operation = index
    if depth != 0:
        raise ValueError("unbalanced equation parentheses")
    if last_operation >= 0:
        return (
            _parse_term(text[:last_operation], variable_indices),
            _parse_term(text[last_operation + 1 :], variable_indices),
        )
    if len(text) == 1 and text in variable_indices:
        return variable_indices[text]
    raise ValueError(f"cannot parse term: {text!r}")


def _parse_equation(text):
    normalized = text.replace("*", "◇")
    if normalized.count("=") != 1 or "≠" in normalized:
        raise ValueError("formula must contain exactly one equality")
    variables = []
    seen = set()
    for variable in re.findall(r"\b([a-z])\b", normalized):
        if variable not in seen:
            seen.add(variable)
            variables.append(variable)
    if not variables:
        raise ValueError("formula has no variables")
    indices = {variable: index for index, variable in enumerate(variables)}
    lhs, rhs = normalized.split("=", 1)
    return variables, _parse_term(lhs, indices), _parse_term(rhs, indices)


def _eval_term(term, values, table):
    if type(term) is int:
        return values[term]
    return table[_eval_term(term[0], values, table)][
        _eval_term(term[1], values, table)
    ]


def _equation_holds(parsed, table):
    variables, lhs, rhs = parsed
    checked = 0
    for values in product(range(len(table)), repeat=len(variables)):
        checked += 1
        left = _eval_term(lhs, values, table)
        right = _eval_term(rhs, values, table)
        if left != right:
            return False, checked, {
                "assignment": dict(zip(variables, values)),
                "lhs": left,
                "rhs": right,
            }
    return True, checked, None


def _table_bytes():
    global _TABLE_BYTES
    if _TABLE_BYTES is None:
        raw = lzma.decompress(base64.b85decode(_TABLES_XZ_B85))
        if len(raw) != _TABLE_RAW_BYTES:
            raise ValueError("finite-model payload length drift")
        _TABLE_BYTES = raw
    return _TABLE_BYTES


def _tables():
    raw = _table_bytes()
    position = 0
    for model_index in range(_MODEL_COUNT):
        if position >= len(raw):
            raise ValueError("finite-model payload ended early")
        order = raw[position]
        end = position + 1 + order * order
        if order == 0 or end > len(raw):
            raise ValueError("invalid finite-model payload")
        flat = raw[position + 1 : end]
        if any(value >= order for value in flat):
            raise ValueError("finite-model entry outside carrier")
        yield model_index, [
            list(flat[row * order : (row + 1) * order])
            for row in range(order)
        ]
        position = end
    if position != len(raw):
        raise ValueError("finite-model payload has trailing bytes")


def _table_sha256(table):
    canonical = json.dumps(
        table, ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _countermodel(parsed_source, parsed_target, table, metrics):
    source_holds, checked, _failure = _equation_holds(parsed_source, table)
    metrics["assignments_checked"] += checked
    if not source_holds:
        return None
    target_holds, checked, failure = _equation_holds(parsed_target, table)
    metrics["assignments_checked"] += checked
    if target_holds:
        return None
    return {
        "order": len(table),
        "carrier": list(range(len(table))),
        "table": table,
        "source_verified": True,
        "target_counterexample": failure,
        "validation_mode": "exhaustive_finite_table_full_scan",
    }


def _affine_parameters(table):
    order = len(table)
    constant = table[0][0]
    left = (table[1][0] - constant) % order if order > 1 else 0
    right = (table[0][1] - constant) % order if order > 1 else 0
    if all(
        table[row][column]
        == (left * row + right * column + constant) % order
        for row in range(order)
        for column in range(order)
    ):
        return left, right, constant
    return None


def _small_table_false_code(table):
    order = len(table)
    encoded = "[" + ",".join(
        "[" + ",".join(str(value) for value in row) + "]" for row in table
    ) + "]"
    return (
        "import JudgeProblem\n"
        "import JudgeDecide.DecideBang\n"
        "import JudgeFinOp.MemoFinOp\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n"
        "open MemoFinOp\n\n"
        "def submission : Goal := by\n"
        f"  let m : Magma (Fin {order}) := {{\n"
        f'    op := finOpTable "{encoded}"\n'
        "  }\n"
        f"  refine ⟨Fin {order}, m, ?_⟩\n"
        "  decideFin!\n"
    )


def _lean_term(term, variables, operation="d6Affine"):
    if type(term) is int:
        return variables[term]
    left = _lean_term(term[0], variables, operation)
    right = _lean_term(term[1], variables, operation)
    return f"{operation} ({left}) ({right})"


def _affine_false_code(table, parameters, parsed_source, parsed_target, failure):
    order = len(table)
    left, right, constant = parameters
    source_variables, source_lhs, source_rhs = parsed_source
    target_variables, target_lhs, target_rhs = parsed_target
    source_left = _lean_term(source_lhs, source_variables)
    source_right = _lean_term(source_rhs, source_variables)
    witness = failure["assignment"]
    target_arguments = " ".join(
        f"({witness[variable]} : Fin {order})" for variable in target_variables
    )
    witness_variables = {
        index: f"({witness[variable]} : Fin {order})"
        for index, variable in enumerate(target_variables)
    }
    target_left = _lean_term(target_lhs, witness_variables)
    target_right = _lean_term(target_rhs, witness_variables)
    failure_left = failure["lhs"]
    failure_right = failure["rhs"]
    return (
        "import JudgeProblem\n"
        "import Mathlib.Tactic\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n\n"
        f"abbrev d6Carrier := Fin {order}\n\n"
        f"def d6Affine (i j : Fin {order}) : Fin {order} :=\n"
        f"  ({left} : Fin {order}) * i + ({right} : Fin {order}) * j + "
        f"({constant} : Fin {order})\n\n"
        f"@[reducible] def d6Magma : Magma (Fin {order}) := "
        "{ op := d6Affine }\n\n"
        f"local instance : Magma (Fin {order}) := d6Magma\n\n"
        f"def d6Source : EquationLHS (Fin {order}) := by\n"
        f"  intro {' '.join(source_variables)}\n"
        f"  change {source_left} = {source_right}\n"
        "  apply Fin.ext\n"
        "  simp [d6Affine] <;> omega\n\n"
        f"def d6Target : ¬ EquationRHS (Fin {order}) := by\n"
        "  intro h\n"
        f"  have bad := h {target_arguments}\n"
        f"  change {target_left} = {target_right} at bad\n"
        f"  change ({failure_left} : Fin {order}) = "
        f"({failure_right} : Fin {order}) at bad\n"
        f"  exact (show ({failure_left} : Fin {order}) ≠ "
        f"({failure_right} : Fin {order}) by decide) bad\n\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        "  exact ⟨MemoFinOp.d6Carrier, MemoFinOp.d6Magma, "
        "MemoFinOp.d6Source, MemoFinOp.d6Target⟩\n"
    )


def _prime_power(order):
    for prime in (2, 3, 5, 7, 11, 13):
        value = order
        exponent = 0
        while value > 1 and value % prime == 0:
            value //= prime
            exponent += 1
        if value == 1 and exponent >= 2:
            return prime, exponent
    return None


def _vector_digits(value, prime, dimension):
    digits = []
    for _ in range(dimension):
        digits.append(value % prime)
        value //= prime
    return digits


def _vector_value(digits, prime):
    value = 0
    place = 1
    for digit in digits:
        value += digit * place
        place *= prime
    return value


def _vector_add(left, right, prime, dimension):
    return _vector_value(
        [
            (x + y) % prime
            for x, y in zip(
                _vector_digits(left, prime, dimension),
                _vector_digits(right, prime, dimension),
            )
        ],
        prime,
    )


def _vector_sub(left, right, prime, dimension):
    return _vector_value(
        [
            (x - y) % prime
            for x, y in zip(
                _vector_digits(left, prime, dimension),
                _vector_digits(right, prime, dimension),
            )
        ],
        prime,
    )


def _vector_affine_parameters(table):
    decomposition = _prime_power(len(table))
    if decomposition is None:
        return None
    prime, dimension = decomposition
    order = len(table)
    constant = table[0][0]
    left_map = [
        _vector_sub(table[value][0], constant, prime, dimension)
        for value in range(order)
    ]
    right_map = [
        _vector_sub(table[0][value], constant, prime, dimension)
        for value in range(order)
    ]
    if not all(
        table[i][j]
        == _vector_add(
            _vector_add(left_map[i], right_map[j], prime, dimension),
            constant,
            prime,
            dimension,
        )
        for i in range(order)
        for j in range(order)
    ):
        return None
    if not all(
        left_map[_vector_add(i, j, prime, dimension)]
        == _vector_add(left_map[i], left_map[j], prime, dimension)
        and right_map[_vector_add(i, j, prime, dimension)]
        == _vector_add(right_map[i], right_map[j], prime, dimension)
        for i in range(order)
        for j in range(order)
    ):
        return None
    left_columns = [
        _vector_digits(left_map[prime**index], prime, dimension)
        for index in range(dimension)
    ]
    right_columns = [
        _vector_digits(right_map[prime**index], prime, dimension)
        for index in range(dimension)
    ]
    return {
        "prime": prime,
        "dimension": dimension,
        "left_columns": left_columns,
        "right_columns": right_columns,
        "constant": _vector_digits(constant, prime, dimension),
    }


def _product_type(prime, dimension):
    result = f"Fin {prime}"
    for _ in range(dimension - 1):
        result = f"Fin {prime} × ({result})"
    return result


def _coordinate(variable, index, dimension):
    if index == dimension - 1:
        return variable + ".2" * index
    return variable + ".2" * index + ".1"


def _tuple_expression(expressions):
    result = expressions[-1]
    for expression in reversed(expressions[:-1]):
        result = f"⟨{expression}, {result}⟩"
    return result


def _linear_coordinate(variable, row, columns, prime, dimension):
    terms = []
    for column in range(dimension):
        coefficient = columns[column][row]
        if coefficient == 0:
            continue
        coordinate = _coordinate(variable, column, dimension)
        if coefficient == 1:
            terms.append(coordinate)
        else:
            terms.append(f"({coefficient} : ℕ) • {coordinate}")
    return " + ".join(terms) if terms else f"(0 : Fin {prime})"


def _vector_literal(value, prime, dimension):
    return _tuple_expression(
        [f"({digit} : Fin {prime})" for digit in _vector_digits(value, prime, dimension)]
    )


def _integer_linear_term(term, variable_count, parameters):
    dimension = parameters["dimension"]
    if type(term) is int:
        return [
            {(term, coordinate): 1} for coordinate in range(dimension)
        ]
    left = _integer_linear_term(term[0], variable_count, parameters)
    right = _integer_linear_term(term[1], variable_count, parameters)
    result = []
    for row in range(dimension):
        combined = {}
        for columns, values in (
            (parameters["left_columns"], left),
            (parameters["right_columns"], right),
        ):
            for column in range(dimension):
                multiplier = columns[column][row]
                for key, coefficient in values[column].items():
                    combined[key] = combined.get(key, 0) + multiplier * coefficient
        result.append({key: value for key, value in combined.items() if value})
    return result


def _source_zsmul_coefficients(parsed_source, parameters):
    source_variables, source_lhs, source_rhs = parsed_source
    coefficients = set()
    for term in (source_lhs, source_rhs):
        for coordinate in _integer_linear_term(
            term, len(source_variables), parameters
        ):
            coefficients.update(value for value in coordinate.values() if value > 1)
    return sorted(coefficients)


def _vector_affine_false_code(
    table, parameters, parsed_source, parsed_target, failure
):
    prime = parameters["prime"]
    dimension = parameters["dimension"]
    carrier = _product_type(prime, dimension)
    coordinates = []
    for row in range(dimension):
        left = _linear_coordinate(
            "i", row, parameters["left_columns"], prime, dimension
        )
        right = _linear_coordinate(
            "j", row, parameters["right_columns"], prime, dimension
        )
        constant = parameters["constant"][row]
        coordinates.append(f"({left}) + ({right}) + ({constant} : Fin {prime})")
    affine_body = _tuple_expression(coordinates)
    source_variables, source_lhs, source_rhs = parsed_source
    target_variables, target_lhs, target_rhs = parsed_target
    source_left = _lean_term(source_lhs, source_variables)
    source_right = _lean_term(source_rhs, source_variables)
    witness = failure["assignment"]
    target_arguments = " ".join(
        _vector_literal(witness[variable], prime, dimension)
        for variable in target_variables
    )
    witness_variables = {
        index: _vector_literal(witness[variable], prime, dimension)
        for index, variable in enumerate(target_variables)
    }
    target_left = _lean_term(target_lhs, witness_variables)
    target_right = _lean_term(target_rhs, witness_variables)
    left_digits = _vector_digits(failure["lhs"], prime, dimension)
    right_digits = _vector_digits(failure["rhs"], prime, dimension)
    different_index = next(
        index
        for index, (left, right) in enumerate(zip(left_digits, right_digits))
        if left != right
    )
    projection = _coordinate("q", different_index, dimension)
    failure_left = left_digits[different_index]
    failure_right = right_digits[different_index]
    zsmul_coefficients = _source_zsmul_coefficients(parsed_source, parameters)
    if any(coefficient % prime not in (0, 1) for coefficient in zsmul_coefficients):
        raise ValueError("vector source coefficients do not reduce to identity")
    zsmul_lemmas = "".join(
        f"theorem d6Zsmul{coefficient} (x : Fin {prime}) : "
        f"({coefficient} : ℤ) • x = "
        f"{'0' if coefficient % prime == 0 else 'x'} := by\n"
        "  fin_cases x <;> decide\n\n"
        for coefficient in zsmul_coefficients
    )
    zsmul_names = ", ".join(
        f"d6Zsmul{coefficient}" for coefficient in zsmul_coefficients
    )
    if zsmul_names:
        source_proof = (
            "  ext <;> simp [d6Affine] <;> abel_nf <;>\n"
            f"    simp only [{zsmul_names}, zero_add, add_zero]\n\n"
        )
    else:
        source_proof = "  ext <;> simp [d6Affine] <;> abel_nf\n\n"
    return (
        "import JudgeProblem\n"
        "import Mathlib.Tactic\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n\n"
        f"abbrev d6Carrier := {carrier}\n\n"
        "def d6Affine (i j : d6Carrier) : d6Carrier :=\n"
        f"  {affine_body}\n\n"
        f"{zsmul_lemmas}"
        "@[reducible] def d6Magma : Magma d6Carrier := { op := d6Affine }\n\n"
        "local instance : Magma d6Carrier := d6Magma\n\n"
        "def d6Source : EquationLHS d6Carrier := by\n"
        f"  intro {' '.join(source_variables)}\n"
        f"  change {source_left} = {source_right}\n"
        f"{source_proof}"
        "def d6Target : ¬ EquationRHS d6Carrier := by\n"
        "  intro h\n"
        f"  have bad := h {target_arguments}\n"
        f"  change {target_left} = {target_right} at bad\n"
        f"  have badCoordinate := congrArg (fun q : d6Carrier => {projection}) bad\n"
        f"  change ({failure_left} : Fin {prime}) = "
        f"({failure_right} : Fin {prime}) at badCoordinate\n"
        f"  exact (show ({failure_left} : Fin {prime}) ≠ "
        f"({failure_right} : Fin {prime}) by decide) badCoordinate\n\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        "  exact ⟨MemoFinOp.d6Carrier, MemoFinOp.d6Magma, "
        "MemoFinOp.d6Source, MemoFinOp.d6Target⟩\n"
    )


def _compact_table_false_code(table):
    order = len(table)
    alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if order > len(alphabet):
        raise ValueError("compact Base36 table only supports orders up to 36")
    encoded = "".join(alphabet[value] for row in table for value in row)
    if len(encoded) != order * order:
        raise ValueError("compact finite-table encoding length drift")
    return (
        "import JudgeProblem\n"
        "import JudgeDecide.DecideBang\n"
        "import JudgeFinOp.MemoFinOp\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n\n"
        "private def decodeBase36V2 (c : Char) : Nat :=\n"
        "  if c.isDigit then c.toNat - '0'.toNat\n"
        "  else c.toNat - 'A'.toNat + 10\n\n"
        "def base36TableV2 (s : String) (i j : Fin n) : Fin n :=\n"
        "  let vals := s.toList.map decodeBase36V2\n"
        "  let idx := i.val * n + j.val\n"
        "  ⟨(vals.getD idx 0) % n,\n"
        "    Nat.mod_lt _ (Nat.lt_of_le_of_lt (Nat.zero_le i.val) i.isLt)⟩\n\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        f"  let m : Magma (Fin {order}) := {{\n"
        f'    op := MemoFinOp.base36TableV2 "{encoded}"\n'
        "  }\n"
        f"  refine ⟨Fin {order}, m, ?_⟩\n"
        "  decideFin!\n"
    )


def _false_code(table, parsed_source, parsed_target, failure):
    order = len(table)
    if order <= 10:
        return _small_table_false_code(table), "finOpTable_single_digit_decideFin"
    parameters = _affine_parameters(table)
    if parameters is not None:
        return (
            _affine_false_code(
                table, parameters, parsed_source, parsed_target, failure
            ),
            "fin_scalar_affine_symbolic",
        )
    vector_parameters = _vector_affine_parameters(table)
    if (
        vector_parameters is not None
        and not any(vector_parameters["constant"])
        and all(
            coefficient % vector_parameters["prime"] in (0, 1)
            for coefficient in _source_zsmul_coefficients(
                parsed_source, vector_parameters
            )
        )
    ):
        return (
            _vector_affine_false_code(
                table,
                vector_parameters,
                parsed_source,
                parsed_target,
                failure,
            ),
            "fin_vector_affine_symbolic",
        )
    return _compact_table_false_code(table), "base36_compact_table_decideFin"


def _base_result(ordinal, case_id, status, stop_reason, save_mode, metrics):
    return {
        "schema_version": PROVER_SCHEMA,
        "prover_name": PROVER_NAME,
        "ordinal": ordinal,
        "id": case_id,
        "status": status,
        "stop_reason": stop_reason,
        "result_save_mode": save_mode,
        "certificate_valid": None,
        "verdict": None,
        "judge_verdict": None,
        "metrics": dict(metrics),
    }


def prove(case, config):
    """Exhaustively scan one deduplicated bank of static finite models."""

    started = time.monotonic()
    ordinal = case.get("ordinal") if isinstance(case, dict) else None
    case_id = case.get("id") if isinstance(case, dict) else None
    save_mode = "minimal"
    previous_alarm = None
    trace = []
    metrics = {
        "architecture": "false-solver-d6-minimal-finite-table-scan-v1",
        "model_checks": 0,
        "assignments_checked": 0,
        "stage_events": 0,
        "elapsed_seconds": 0.0,
    }
    try:
        save_mode, safety_seconds, enabled = _runtime_config(config)
        ordinal, case_id, source, target = _case_formulas(case)
        parsed_source = _parse_equation(source)
        parsed_target = _parse_equation(target)
        previous_alarm = _arm_safety_wall(safety_seconds)
        if enabled:
            for model_index, table in _tables():
                metrics["model_checks"] += 1
                details = _countermodel(
                    parsed_source, parsed_target, table, metrics
                )
                if details is None:
                    continue
                model_sha256 = _table_sha256(table)
                metrics["stage_events"] = 1
                metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                details.update(
                    {
                        "frozen_model_sha256": model_sha256,
                        "frozen_model_index": model_index,
                        "frozen_library": "unified_static_finite_bank",
                    }
                )
                stage = "stage0_unified_finite_model_full_scan"
                trace.append(
                    {
                        "seq": 1,
                        "stage": stage,
                        "event": "hit",
                        "models_scanned": metrics["model_checks"],
                        "model_index": model_index,
                        "model_sha256": model_sha256,
                    }
                )
                judge_lean, certificate_encoding = _false_code(
                    table,
                    parsed_source,
                    parsed_target,
                    details["target_counterexample"],
                )
                details["certificate_encoding"] = certificate_encoding
                result = _base_result(
                    ordinal,
                    case_id,
                    "REFUTED",
                    "COUNTERMODEL_FOUND",
                    save_mode,
                    metrics,
                )
                result.update(
                    {
                        "certificate_valid": True,
                        "certificate_kind": "finite_magma_countermodel",
                        "verdict": False,
                        "judge_verdict": "false",
                        "stage": stage,
                        "countermodel": details,
                        "judge_lean": f"-- stage:{stage}\n" + judge_lean,
                    }
                )
                if save_mode == "full":
                    result["trace"] = trace
                return result
        metrics["stage_events"] = 1
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        if save_mode == "full":
            trace.append(
                {
                    "seq": 1,
                    "stage": "stage0_unified_finite_model_full_scan",
                    "event": "miss",
                    "models_scanned": metrics["model_checks"],
                }
            )
        result = _base_result(
            ordinal, case_id, "UNKNOWN", "COUNTERMODEL_NOT_FOUND", save_mode, metrics
        )
        if save_mode == "full":
            result["trace"] = trace
        return result
    except _SafetyWallExpired:
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        result = _base_result(
            ordinal, case_id, "UNKNOWN", "SAFETY_WALL", save_mode, metrics
        )
        if save_mode == "full":
            result["trace"] = trace
        return result
    except Exception as error:
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        result = _base_result(
            ordinal, case_id, "ERROR", "PROVER_ERROR", save_mode, metrics
        )
        result.update(
            {"error_type": type(error).__name__, "diagnostic": str(error)}
        )
        return result
    finally:
        _disarm_safety_wall(previous_alarm)


def _main():
    request = json.loads(sys.stdin.readline())
    result = prove(request.get("case"), request.get("config", {}))
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


__all__ = ["PROVER_NAME", "PROVER_SCHEMA", "prove"]


if __name__ == "__main__":
    _main()
