# False Solver d8

d8 保留 d7 及其正式运行不动，以 d6 的 9,957 个纯有限模型顺序扫描为后备层，
并把可计算无限模型的目标证明改造成目标 AST 驱动的符号生成器。

## 无限模型生成契约

运行时不使用题号、Equation ID、公式 SHA256、精确公式对或目标模板索引：

1. 将 source 解析为变量改名不敏感的 α-规范 AST，并顺序匹配源恒等式规则。
2. 读取该源模型的紧凑见证向量。
3. 遍历传入的 target AST，把变量替换成见证并重建完整 Lean 运算树。
4. 在证书中生成显式 `change`，让 Lean 逐层定义归约封闭运算树。
5. 使用 `nomatch` 从最终的不同构造器等式得到矛盾。
6. 若当前 Judge 拒绝无限候选，继续运行 d6 有限模型基线。

无限模型层完全不使用 `native_decide` 或 `decide`。d6 有限模型基线原有的
`decideFin!` 等已验证有限证书路径保持不变。

## 当前覆盖边界

| 构造族 | 历史题数 | d8 当前符号候选 |
|---|---:|---:|
| 单源自由项异常规则 | 12 | 12 |
| KBO 完成 | 10 | 10 |
| 历史 inductive-CM / 模型迁移 | 4 | 4 |
| 范式归一化 | 1 | 1 |
| Base/Hit/Code 自由树 | 26 | 0 |
| 独立根重写 | 2 | 0 |
| 合计 | 55 | 27 |

前四类的运算是可计算定义，目标 AST 实例可以归约到不同的自由构造器。
后两类仍使用 `Classical.choose` 定义运算，定义归约无法穿过非可计算选择；d8 不会
用历史逐目标证明补洞。它们需要后续加入构造性 Code 解码器和构造性根模式提取器。

## 当前验证结果

- 27/27 个已启用历史目标通过本地完整 `Goal` 串行类型检查。
- 一个不在历史库中的新目标 `x = y` 也由同一源规则动态生成并通过，证明运行时没有
  退化成历史目标查表。
- 四个启用族各取一题在当前 Judge 上以 `refresh` 模式验证，结果为 4/4 accepted。
- 当前 Judge 实际最大带 stage 前缀证书为 19,538 字节，低于 20 KB 限制。
- 这只是四族微型 Judge 评测，不是 27 题 `run-solver` 正式评测。

机器审计见 `symbolic_lean_audit.json` 和 `symbolic_judge_smoke_audit.json`。

## 单文件大小

| 文件 | 字节数 | SHA256 |
|---|---:|---|
| `formula_solver.py` | 167,654 | `fb2c4310274da58e6333718f6af836d3fb30958e0003e3454283234c7c1e4c5e` |
| `solver.py` | 169,181 | `fd9c906ffa7be6f840af90556cacf66f3f670582d6e76fb80af833c51b7873ab` |
| `compressed_formula_solver.py` | 139,615 | `633ab0148b2e1b9739000e823baceba4db8e1e74fe79350e0f2753e2f83c69f1` |

## 验证

```bash
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d8/build_formula_solver.py
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d8/build_solver.py
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d8/validate_formula_solver.py
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d8/validate_infinite_family_templates.py
```

`solver.py` 是单文件 Stage 2 Solo 适配器。正式评测应另行冻结 solver、输入、配置和
run ID 后通过 `run-solver` 执行。
