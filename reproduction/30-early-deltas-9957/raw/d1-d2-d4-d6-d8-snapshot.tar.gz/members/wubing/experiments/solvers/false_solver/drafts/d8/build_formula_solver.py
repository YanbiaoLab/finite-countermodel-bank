#!/usr/bin/env python3
"""Build d8 from d6 plus target-AST symbolic infinite-model families."""

from __future__ import annotations

import ast
import base64
from collections import Counter
import hashlib
import json
import lzma
from pathlib import Path
import runpy
import sys

from infinite_family_templates import (
    FAMILY_IDS,
    canonical_pattern,
    load_rules,
    render_symbolic_code,
)


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
REPO_ROOT = HERE.parents[6]
D1_PROVER = HERE.parent / "d1/solver.py"
D2_PROVER = HERE.parent / "d2/solver.py"
D4_PROVER = HERE.parent / "d4/solver.py"
RUNTIME_SOURCE = HERE / "runtime.py"
OUTPUT = HERE / "formula_solver.py"
MANIFEST = HERE / "manifest.json"
MODEL_AUDIT = HERE / "model_audit.json"
INFINITE_AUDIT = HERE / "infinite_family_audit.json"

PROOF_BANK = (
    REPO_ROOT
    / "members/wubing/data/processed/proof_banks/false/"
    "infinite_countermodels/v1/accepted.jsonl"
)
PROOF_BANK_MANIFEST = PROOF_BANK.with_name("bank_manifest.json")
PROOF_BANK_SHA256 = "e6249fb8449d208fb226cef89be1fe9cd1a4eb973e0e931d41d205e22f22a0c4"
PROOF_BANK_MANIFEST_SHA256 = "eec9cc934bca1119c3ef6088cdd77de2ad3506bbf3d64e4fa87d3e8e6b12f197"
ENABLED_INFINITE_FAMILIES = {
    "single_source_free_term_exception",
    "kbo_completion",
    "inductive_cm_model_transfer",
    "normal_form_normalization",
}

D1_PROVER_SHA256 = "e4c8d2168bbb5569a6d4db7cc1a8c9517426d10721f297b0370e59cf495c9cf0"
D2_PROVER_SHA256 = "f044c640a31106f3cfea4840c9024230eb4b26b32d2c54350afef6165c15df12"
D4_PROVER_SHA256 = "f547221f5ae06acdadddbae49e02366b41f165e52913594281feba451e42e949"
D1_MODEL_COUNT = 66
D2_MODEL_COUNT = 145
FALSE9852_MODEL_COUNT = 9_852
LZMA_PRESET = 9 | lzma.PRESET_EXTREME


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def table_sha256(table: list[list[int]]) -> str:
    canonical = json.dumps(
        table, ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    return sha256_bytes(canonical)


def normalized_table(table) -> list[list[int]]:
    result = [list(row) for row in table]
    order = len(result)
    if not 1 <= order <= 255 or any(len(row) != order for row in result):
        raise RuntimeError("static finite model must be a nonempty square table")
    if any(type(value) is not int or not 0 <= value < order for row in result for value in row):
        raise RuntimeError("static finite model entry outside carrier")
    return result


def extract_ascii_constant(path: Path, name: str) -> bytes:
    chunks: list[str] = []
    active = False
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if not active:
                if line.startswith(f"{name} = ("):
                    active = True
                continue
            if line.strip() == ")":
                break
            value = ast.literal_eval(line.strip())
            if not isinstance(value, str):
                raise RuntimeError(f"non-string chunk in {name}")
            chunks.append(value)
    if not active:
        raise RuntimeError(f"missing frozen constant {name}")
    return "".join(chunks).encode("ascii")


def iter_encoded_tables(raw: bytes, count: int):
    position = 0
    for _model_index in range(count):
        if position >= len(raw):
            raise RuntimeError("encoded table payload ended early")
        order = raw[position]
        end = position + 1 + order * order
        if order == 0 or end > len(raw):
            raise RuntimeError("invalid encoded table payload")
        flat = raw[position + 1 : end]
        if any(value >= order for value in flat):
            raise RuntimeError("encoded table entry outside carrier")
        yield [
            list(flat[row * order : (row + 1) * order])
            for row in range(order)
        ]
        position = end
    if position != len(raw):
        raise RuntimeError("encoded table payload has trailing bytes")


def d1_tables() -> dict[str, list[list[int]]]:
    namespace = runpy.run_path(str(D1_PROVER), run_name="_d6_extract_d1")
    result: dict[str, list[list[int]]] = {}
    rows = namespace["_early_model_portfolio"]() + namespace["_late_model_portfolio"]()
    for _stage, raw_table in rows:
        table = normalized_table(raw_table)
        result.setdefault(table_sha256(table), table)
    for order, left, right, constant in namespace["_RULEBOOK_AFFINE_MODELS"]:
        table = [
            [
                (left * row + right * column + constant) % order
                for column in range(order)
            ]
            for row in range(order)
        ]
        result.setdefault(table_sha256(table), table)
    if len(result) != D1_MODEL_COUNT:
        raise RuntimeError(f"d1 static model count drift: {len(result)}")
    return result


def d2_tables() -> dict[str, list[list[int]]]:
    namespace = runpy.run_path(str(D2_PROVER), run_name="_d6_extract_d2")
    result = {
        digest: normalized_table(table)
        for digest, table in namespace["_OFFLINE_FALSE244_FINITE_TABLES"].items()
    }
    if len(result) != D2_MODEL_COUNT:
        raise RuntimeError(f"d2 finite model count drift: {len(result)}")
    for digest, table in result.items():
        if table_sha256(table) != digest:
            raise RuntimeError(f"d2 finite model identity drift: {digest}")
    return result


def false9852_tables() -> dict[str, list[list[int]]]:
    encoded = extract_ascii_constant(D4_PROVER, "_FALSE9852_TABLES_XZ_B85")
    raw = lzma.decompress(base64.b85decode(encoded))
    result: dict[str, list[list[int]]] = {}
    for table in iter_encoded_tables(raw, FALSE9852_MODEL_COUNT):
        digest = table_sha256(table)
        if digest in result:
            raise RuntimeError(f"duplicate identity inside False-9852: {digest}")
        result[digest] = table
    if len(result) != FALSE9852_MODEL_COUNT:
        raise RuntimeError(f"False-9852 model count drift: {len(result)}")
    return result


def encode_tables(rows: list[tuple[str, list[list[int]]]]) -> bytes:
    payload = bytearray()
    for _digest, table in rows:
        order = len(table)
        payload.append(order)
        for row in table:
            payload.extend(row)
    return bytes(payload)


def render_b85_constant(name: str, payload: bytes) -> str:
    encoded = base64.b85encode(payload).decode("ascii")
    rows = [
        f"    {encoded[index:index + 100]!r}"
        for index in range(0, len(encoded), 100)
    ]
    return f"{name} = (\n" + "\n".join(rows) + "\n)"


def verify_inputs() -> None:
    for path, expected in (
        (D1_PROVER, D1_PROVER_SHA256),
        (D2_PROVER, D2_PROVER_SHA256),
        (D4_PROVER, D4_PROVER_SHA256),
        (PROOF_BANK, PROOF_BANK_SHA256),
        (PROOF_BANK_MANIFEST, PROOF_BANK_MANIFEST_SHA256),
    ):
        actual = sha256_path(path)
        if actual != expected:
            raise RuntimeError(
                f"frozen input drift: {path}: expected {expected}, got {actual}"
            )


def build() -> dict:
    verify_inputs()
    sources = {
        "d1_static": d1_tables(),
        "d2_finite": d2_tables(),
        "false9852": false9852_tables(),
    }
    all_identities = set().union(*(set(values) for values in sources.values()))
    origins = {
        identity: sorted(name for name, values in sources.items() if identity in values)
        for identity in all_identities
    }
    tables = {
        identity: next(values[identity] for values in sources.values() if identity in values)
        for identity in all_identities
    }
    ordered = sorted(tables.items(), key=lambda item: (len(item[1]), item[0]))
    raw_tables = encode_tables(ordered)
    table_xz = lzma.compress(
        raw_tables,
        format=lzma.FORMAT_XZ,
        check=lzma.CHECK_CRC64,
        preset=LZMA_PRESET,
    )
    if lzma.decompress(table_xz) != raw_tables:
        raise RuntimeError("table compression round-trip failed")

    all_infinite_rules = load_rules(PROOF_BANK)
    enabled_infinite_rules = [
        rule for rule in all_infinite_rules if rule.family in ENABLED_INFINITE_FAMILIES
    ]
    blocked_infinite_rules = [
        rule for rule in all_infinite_rules if rule.family not in ENABLED_INFINITE_FAMILIES
    ]
    if (
        len(all_infinite_rules) != 49
        or len(enabled_infinite_rules) != 26
        or sum(len(rule.historical_ordinals) for rule in enabled_infinite_rules) != 27
        or sum(len(rule.historical_ordinals) for rule in blocked_infinite_rules) != 28
    ):
        raise RuntimeError("generalized infinite family accounting drift")
    stage_prefix = "-- stage:stage0_generalized_infinite_source_family\n"
    rules_by_pattern = {rule.source_pattern: rule for rule in enabled_infinite_rules}
    proof_rows = [json.loads(line) for line in PROOF_BANK.open(encoding="utf-8")]
    rendered_historical_codes = []
    for row in proof_rows:
        rule = rules_by_pattern.get(canonical_pattern(str(row["source_equation"])))
        if rule is not None:
            rendered_historical_codes.append(
                render_symbolic_code(rule, str(row["target_equation"]))
            )
    if len(rendered_historical_codes) != 27:
        raise RuntimeError("d8 symbolic historical coverage drift")
    staged_sizes = [
        len((stage_prefix + code).encode("utf-8"))
        for code in rendered_historical_codes
    ]
    if max(staged_sizes) > 20_000:
        raise RuntimeError("generalized infinite certificate exceeds Judge 20 KB limit")
    infinite_rows = [
        [
            rule.family,
            rule.source_pattern,
            rule.witness_vectors,
            rule.carrier_type,
            rule.magma_instance,
            rule.project_subtype_value,
            rule.code,
        ]
        for rule in sorted(
            enabled_infinite_rules,
            key=lambda rule: (rule.family, rule.source_pattern),
        )
    ]
    infinite_raw = json.dumps(
        infinite_rows, ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    infinite_xz = lzma.compress(
        infinite_raw,
        format=lzma.FORMAT_XZ,
        check=lzma.CHECK_CRC64,
        preset=LZMA_PRESET,
    )
    if lzma.decompress(infinite_xz) != infinite_raw:
        raise RuntimeError("infinite family compression round-trip failed")

    model_payload = "\n".join(
        (
            f"_MODEL_COUNT = {len(ordered)}",
            f"_TABLE_RAW_BYTES = {len(raw_tables)}",
            render_b85_constant("_TABLES_XZ_B85", table_xz),
        )
    )
    infinite_payload = "\n".join(
        (
            f"_INFINITE_RULE_COUNT = {len(infinite_rows)}",
            render_b85_constant("_INFINITE_RULES_XZ_B85", infinite_xz),
        )
    )
    runtime_source = RUNTIME_SOURCE.read_text(encoding="utf-8")
    marker = "# __MODEL_PAYLOAD__"
    if runtime_source.count(marker) != 1:
        raise RuntimeError("runtime model-payload marker drift")
    infinite_marker = "# __INFINITE_FAMILY_PAYLOAD__"
    if runtime_source.count(infinite_marker) != 1:
        raise RuntimeError("runtime infinite-family-payload marker drift")
    generated = runtime_source.replace(marker, model_payload).replace(
        infinite_marker, infinite_payload
    )
    compile(generated, str(OUTPUT), "exec")
    OUTPUT.write_text(generated, encoding="utf-8")

    identity_vector = sha256_bytes(
        "".join(f"{identity}\n" for identity, _table in ordered).encode("ascii")
    )
    overlap_counts = {
        "d1_d2": len(set(sources["d1_static"]) & set(sources["d2_finite"])),
        "d1_false9852": len(set(sources["d1_static"]) & set(sources["false9852"])),
        "d2_false9852": len(set(sources["d2_finite"]) & set(sources["false9852"])),
        "all_three": sum(1 for value in origins.values() if len(value) == 3),
    }
    audit = {
        "schema_version": "false-solver-d8-model-audit-v1",
        "status": "passed",
        "identity": "canonical Cayley-table SHA-256 at build time only",
        "source_counts": {name: len(values) for name, values in sources.items()},
        "overlap_counts": overlap_counts,
        "unified_unique_table_count": len(ordered),
        "ordered_identity_vector_sha256": identity_vector,
        "embedded_model_identity_vector": False,
        "embedded_formula_index": False,
        "embedded_candidate_memberships": False,
        "lean_certificate_renderer": {
            "order_at_most_10": "finOpTable_single_digit_decideFin",
            "order_at_least_11_scalar_affine": "fin_scalar_affine_symbolic",
            "zero_constant_vector_affine": "fin_vector_affine_symbolic_with_generated_zsmul_lemmas",
            "remaining_nonaffine": "MemoFinOp_base36TableV2_decideFin",
            "compact_table_encoding": "one Base36 ASCII character per entry",
            "maximum_embedded_model_order": max(len(table) for _identity, table in ordered),
        },
        "dropped_capabilities": {
            "d1_dynamic_search": True,
            "d1_equation_id_bitsets": True,
            "d2_structured_finite_certificate_count": 1,
            "d2_exact_pair_infinite_certificate_problem_count": 55,
            "d8_target_symbolic_infinite_problem_count": 27,
        },
    }
    MODEL_AUDIT.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    family_rule_counts = Counter(rule.family for rule in all_infinite_rules)
    family_problem_counts = Counter()
    enabled_family_problem_counts = Counter()
    for rule in all_infinite_rules:
        family_problem_counts[rule.family] += len(rule.historical_ordinals)
        if rule.family in ENABLED_INFINITE_FAMILIES:
            enabled_family_problem_counts[rule.family] += len(rule.historical_ordinals)
    infinite_audit = {
        "schema_version": "false-solver-d8-infinite-family-audit-v1",
        "status": "passed_partial_generalization",
        "proof_bank": {
            "path": str(PROOF_BANK.relative_to(REPO_ROOT)),
            "sha256": PROOF_BANK_SHA256,
            "historical_problem_count": 55,
            "construction_family_count": len(FAMILY_IDS),
        },
        "recognition_contract": {
            "source": "alpha-canonical equation AST, sequential structural rules",
            "target": "incoming target AST rendered symbolically; no target pattern gate or identity index",
            "problem_id_used": False,
            "equation_id_used": False,
            "formula_hash_used": False,
            "exact_formula_pair_lookup": False,
            "singleton_certificate_fallback": False,
        },
        "parameterization": {
            "rule_count": len(all_infinite_rules),
            "family_rule_counts": dict(sorted(family_rule_counts.items())),
            "family_problem_counts": dict(sorted(family_problem_counts.items())),
            "runtime_enabled_rule_count": len(enabled_infinite_rules),
            "runtime_enabled_problem_count": sum(
                len(rule.historical_ordinals) for rule in enabled_infinite_rules
            ),
            "runtime_enabled_family_problem_counts": dict(
                sorted(enabled_family_problem_counts.items())
            ),
            "runtime_blocked_rule_count": len(blocked_infinite_rules),
            "runtime_blocked_problem_count": sum(
                len(rule.historical_ordinals) for rule in blocked_infinite_rules
            ),
            "target_witness_representation": "compact Lean carrier expressions grouped by source rule and target arity",
            "target_validation": "target-AST operation tree, definitional reduction, constructor nomatch, then current Judge",
            "infinite_native_decide": False,
            "infinite_decide": False,
        },
        "blocked_families": {
            "base_hit_code_free_tree": {
                "problem_count": 26,
                "reason": "historical existential Code evaluator is noncomputable; requires a constructive decoder",
            },
            "independent_root_rewrite": {
                "problem_count": 2,
                "reason": "historical existential root selector is noncomputable; requires constructive pattern extractors",
            },
        },
        "certificate_sizes": {
            "maximum_staged_bytes": max(staged_sizes),
            "limit_bytes": 20_000,
        },
        "payload": {
            "raw_bytes": len(infinite_raw),
            "raw_sha256": sha256_bytes(infinite_raw),
            "xz_bytes": len(infinite_xz),
            "xz_sha256": sha256_bytes(infinite_xz),
            "base85_bytes": len(base64.b85encode(infinite_xz)),
        },
    }
    INFINITE_AUDIT.write_text(
        json.dumps(infinite_audit, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    output_bytes = generated.encode("utf-8")
    manifest = {
        "schema_version": "false-solver-build-v8",
        "name": "false-solver-d8",
        "status": "draft",
        "architecture": {
            "base": None,
            "old_solver_source_concatenated": False,
            "single_file_runtime": True,
            "standard_library_only": True,
            "formula_only_input": True,
            "equation_id_used_from_case": False,
            "finite_models_fail_closed_revalidated": True,
            "model_selection": "alpha-structural infinite source rules with target-AST symbolic proof generation, then d6 full finite scan",
            "embedded_model_hash_vector": False,
            "embedded_formula_index": False,
            "embedded_source_structure_rules": len(enabled_infinite_rules),
            "embedded_target_index": False,
            "embedded_candidate_memberships": False,
            "dynamic_model_search": False,
            "frozen_nonmaterialized_certificates": False,
            "singleton_certificate_fallback": False,
            "lean_certificate_rendering": "symbolic Fin scalar/vector affine proofs or proven Base36 single-character table decoding for order >= 11",
            "large_order_decision": "d6 finite baseline keeps its established Fin/omega/abel_nf/Base36 paths; d8 infinite layer uses no decision reflection",
        },
        "model_bank": {
            "source_counts": {name: len(values) for name, values in sources.items()},
            "overlap_counts": overlap_counts,
            "unified_unique_table_count": len(ordered),
        },
        "infinite_family_bank": {
            "source_rule_count": len(enabled_infinite_rules),
            "known_problem_count": sum(len(rule.historical_ordinals) for rule in enabled_infinite_rules),
            "blocked_problem_count": sum(len(rule.historical_ordinals) for rule in blocked_infinite_rules),
            "enabled_families": sorted(ENABLED_INFINITE_FAMILIES),
        },
        "payload": {
            "table_raw_bytes": len(raw_tables),
            "table_raw_sha256": sha256_bytes(raw_tables),
            "table_xz_bytes": len(table_xz),
            "table_xz_sha256": sha256_bytes(table_xz),
            "table_base85_bytes": len(base64.b85encode(table_xz)),
            "infinite_family_raw_bytes": len(infinite_raw),
            "infinite_family_xz_bytes": len(infinite_xz),
            "infinite_family_base85_bytes": len(base64.b85encode(infinite_xz)),
        },
        "source": {
            "d1_solver_sha256_build_time_only": D1_PROVER_SHA256,
            "d2_solver_sha256_build_time_only": D2_PROVER_SHA256,
            "d4_solver_sha256_build_time_only": D4_PROVER_SHA256,
            "ordered_identity_vector_sha256_build_time_only": identity_vector,
            "infinite_proof_bank_sha256_build_time_only": PROOF_BANK_SHA256,
        },
        "runtime": {
            "path": str(RUNTIME_SOURCE),
            "sha256": sha256_path(RUNTIME_SOURCE),
        },
        "audit": {
            "path": str(MODEL_AUDIT),
            "sha256": sha256_path(MODEL_AUDIT),
        },
        "infinite_family_audit": {
            "path": str(INFINITE_AUDIT),
            "sha256": sha256_path(INFINITE_AUDIT),
        },
        "output": {
            "path": str(OUTPUT),
            "bytes": len(output_bytes),
            "sha256": sha256_bytes(output_bytes),
        },
    }
    MANIFEST.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return manifest


if __name__ == "__main__":
    print(json.dumps(build(), ensure_ascii=False, indent=2, sort_keys=True))
