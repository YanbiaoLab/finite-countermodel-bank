# False Solver d11

d11 在 d10 的无限符号模型与 9,957 张静态有限模型之上，加入两层有限反模型能力：

1. 从嘉铭两批交付中提取并重新编码 102 张已独立验证的有限运算表；
2. 在静态全扫描未命中后，运行公式驱动的 Fin 4/Fin 5 动态模型搜索。

运行时不保存或查询题目 ID、Equation ID、公式哈希或目标索引。动态层只接收解析后的 source/target AST，以及静态扫描过程中自然得到的“满足 source、但仍满足 target”的 Fin 4/Fin 5 模型。

## 模型库增量

| 项目 | d10 | d11 | 增量 |
| --- | ---: | ---: | ---: |
| 唯一有限运算表 | 9,957 | 10,059 | 102 |
| 原始表载荷 | 367,581 B | 371,494 B | 3,913 B（1.06%） |
| `solver.py` | 209,011 B | 252,378 B | 43,367 B |

新增模型阶数为：Fin 4 一张、Fin 5 四十一张、Fin 6 三十二张、Fin 7 十五张、Fin 8 十张、Fin 9 三张。它们与 d10 的精确表哈希重合数为零。

## 动态搜索

动态层按以下顺序运行，并在返回前重新穷举 source 和 target：

1. 对静态库中满足 source 的 Fin 4/Fin 5 模型做目标路径引导的小半径表单元变异；
2. 对 source 变量不超过小规模阈值的题做增量最小冲突（min-conflicts）修复；
3. 使用分类子句（categorical clauses）和反例引导归纳合成（counterexample-guided inductive synthesis, CEGIS），分批加入违反 source 的赋值；
4. 最后使用有限域约束满足问题（constraint satisfaction problem, CSP）回溯作为故障闭合后备。

Stage 2 Solo 适配器给动态层每题 1 秒预算。搜索超时或失败只返回 `UNKNOWN`；不会由超时、局部最优或固定域不可满足（fixed-domain UNSAT）推断命题为 true。

## 评测结果

评测输入是两份交付报告中的 102 题。结果保存在 `evaluation.json`。

| 评测 | 结果 | 外墙时间 |
| --- | ---: | ---: |
| d10 原静态库 | 0/102 | 9.555 秒 |
| d11 新静态库 | 102/102 | 9.697 秒 |
| 动态留出 Fin 4/Fin 5（不加载新增102表） | 2/42 | 43.167 秒 |

动态留出集细分：

- Fin 4：1/1；
- Fin 5：1/41；
- 两张动态生成表均未精确出现在新增102表中；
- 最大已学习有限模型证书为 507 字节；
- 动态集成分支证书为 366 字节；动态证书与最大有限表证书都通过 Lean 类型检查。

这说明“从 source 模型做局部修复”确实产生了新覆盖，但当前纯 Python 动态 Fin 5 搜索仍远弱于 CaDiCaL，不应把 2/42 解读为通用 Fin 5 求解器已经成熟。

## 剩余 200 题边界

嘉铭报告的其余 200 题均已有覆盖 Fin 2–Fin 5 的显式固定域 UNSAT 工件；它们的下一搜索前沿是 Fin 10、Fin 11、Fin 12 或更高。因此，d11 的 Fin 4/Fin 5 动态层不会在这 200 题上产生新反模型。要继续降低该集合，需要扩展到更高阶、继续离线 CaDiCaL 挖掘，或从证明侧解决。

## 构建与验证

```bash
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d11/build_formula_solver.py
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d11/build_solver.py
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d11/evaluate_d11.py
uv run --no-sync python members/wubing/experiments/solvers/false_solver/drafts/d11/validate_formula_solver.py
```

主要产物：

- `formula_solver.py`：可直接调用的公式求解器；
- `solver.py`：单文件 Stage 2 Solo 适配器；
- `manifest.json`：架构与输出摘要；
- `model_audit.json`：新增模型来源、阶数和载荷审计；
- `evaluation.json`：逐题动态留出结果。
