#!/usr/bin/env python3
"""Build False Solver d11 from frozen d10 plus learned models and dynamic search."""

from __future__ import annotations

import base64
import hashlib
import json
import lzma
from pathlib import Path
import re
import runpy


HERE = Path(__file__).resolve().parent
D10 = HERE.parent / "d10/formula_solver.py"
DYNAMIC_ENGINE = HERE / "dynamic_engine.py"
OUTPUT = HERE / "formula_solver.py"
MANIFEST = HERE / "manifest.json"
MODEL_AUDIT = HERE / "model_audit.json"
REPORTS = (
    HERE.parents[4] / "data/processed/jiaming/交付.md",
    HERE.parents[4] / "data/processed/jiaming/剩余252题_false挖掘交付_52题.md",
)
LZMA_PRESET = 9 | lzma.PRESET_EXTREME


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def table_sha256(table: list[list[int]]) -> str:
    return sha256_bytes(
        json.dumps(table, separators=(",", ":")).encode("utf-8")
    )


def report_tables() -> list[list[list[int]]]:
    tables: list[list[list[int]]] = []
    for path in REPORTS:
        text = path.read_text(encoding="utf-8")
        for section in re.split(r"(?=^###\s+\d+\.)", text, flags=re.MULTILINE):
            order_match = re.search(r"域大小：`(\d+)`", section)
            if order_match is None or "`table[a][b] = a * b`" not in section:
                continue
            order = int(order_match.group(1))
            rows: list[list[int]] = []
            for line in section.splitlines():
                match = re.match(r"^\|\s*`(\d+)`\s*\|(.*)\|\s*$", line)
                if match is None:
                    if rows:
                        break
                    continue
                row_index = int(match.group(1))
                values = [int(value) for value in re.findall(r"`(\d+)`", match.group(2))]
                if row_index != len(rows) or len(values) != order:
                    raise RuntimeError(f"malformed table in {path}: row {row_index}")
                rows.append(values)
            if len(rows) != order:
                raise RuntimeError(f"incomplete order-{order} table in {path}")
            if any(value >= order for row in rows for value in row):
                raise RuntimeError(f"out-of-carrier table value in {path}")
            tables.append(rows)
    if len(tables) != 102:
        raise RuntimeError(f"expected 102 JiaMing tables, found {len(tables)}")
    hashes = [table_sha256(table) for table in tables]
    if len(hashes) != len(set(hashes)):
        raise RuntimeError("JiaMing table reports contain duplicates")
    return tables


def encode_tables(tables: list[list[list[int]]]) -> bytes:
    payload = bytearray()
    for table in tables:
        payload.append(len(table))
        for row in table:
            payload.extend(row)
    return bytes(payload)


def render_payload(raw: bytes, count: int) -> str:
    encoded = base64.b85encode(lzma.compress(raw, preset=LZMA_PRESET)).decode("ascii")
    chunks = "\n".join(f"    {encoded[index:index + 100]!r}" for index in range(0, len(encoded), 100))
    return (
        f"_MODEL_COUNT = {count}\n"
        f"_TABLE_RAW_BYTES = {len(raw)}\n"
        "_TABLES_XZ_B85 = (\n"
        f"{chunks}\n"
        ")\n\n"
    )


def replace_once(source: str, old: str, new: str, label: str) -> str:
    if source.count(old) != 1:
        raise RuntimeError(f"d10 anchor drift for {label}: count={source.count(old)}")
    return source.replace(old, new)


def build() -> dict:
    d10_namespace = runpy.run_path(str(D10), run_name="_d11_extract_d10")
    inherited = [table for _index, table in d10_namespace["_tables"]()]
    learned = report_tables()
    inherited_hashes = {table_sha256(table) for table in inherited}
    overlap = [table_sha256(table) for table in learned if table_sha256(table) in inherited_hashes]
    if overlap:
        raise RuntimeError(f"learned tables unexpectedly overlap d10: {overlap[:3]}")
    tables = inherited + learned
    raw = encode_tables(tables)

    source = D10.read_text(encoding="utf-8")
    payload_match = re.search(
        r"_MODEL_COUNT = \d+\n_TABLE_RAW_BYTES = \d+\n_TABLES_XZ_B85 = \(\n.*?\n\)\n(?=_INFINITE_RULE_COUNT)",
        source,
        flags=re.DOTALL,
    )
    if payload_match is None:
        raise RuntimeError("d10 finite payload anchor drift")
    source = source[: payload_match.start()] + render_payload(raw, len(tables)) + source[payload_match.end() :]
    source = source.replace('"false-solver-d10"', '"false-solver-d11"')
    source = source.replace(
        "false-solver-d10-source-term-schemas-plus-d6-finite-v1",
        "false-solver-d11-learned102-plus-dynamic-fin45-v1",
    )

    dynamic_source = DYNAMIC_ENGINE.read_text(encoding="utf-8")
    source = replace_once(
        source,
        "\ndef _table_bytes():\n",
        f"\n\n{dynamic_source}\n\ndef _table_bytes():\n",
        "dynamic engine injection",
    )
    source = replace_once(
        source,
        '        - {"safety_wall_seconds", "use_finite_model_bank", "use_infinite_family_bank"}\n',
        '        - {"safety_wall_seconds", "use_finite_model_bank", "use_infinite_family_bank", "use_dynamic_model_search", "dynamic_search_seconds"}\n',
        "runtime config keys",
    )
    source = replace_once(
        source,
        '    infinite_enabled = copied.get("use_infinite_family_bank", True)\n',
        '    infinite_enabled = copied.get("use_infinite_family_bank", True)\n'
        '    dynamic_enabled = copied.get("use_dynamic_model_search", True)\n'
        '    dynamic_seconds = float(copied.get("dynamic_search_seconds", 1.0))\n',
        "dynamic config values",
    )
    source = replace_once(
        source,
        '    if type(infinite_enabled) is not bool:\n'
        '        raise TypeError("use_infinite_family_bank must be a boolean")\n'
        '    return save_mode, seconds, enabled, infinite_enabled\n',
        '    if type(infinite_enabled) is not bool:\n'
        '        raise TypeError("use_infinite_family_bank must be a boolean")\n'
        '    if type(dynamic_enabled) is not bool:\n'
        '        raise TypeError("use_dynamic_model_search must be a boolean")\n'
        '    if not 0.0 <= dynamic_seconds <= 30.0:\n'
        '        raise ValueError("dynamic_search_seconds must be in [0, 30]")\n'
        '    return save_mode, seconds, enabled, infinite_enabled, dynamic_enabled, dynamic_seconds\n',
        "dynamic config validation",
    )
    source = replace_once(
        source,
        '    if target_holds:\n        return None\n',
        '    if target_holds:\n'
        '        if len(table) in (4, 5):\n'
        '            metrics.setdefault("_dynamic_seed_tables", []).append(table)\n'
        '        return None\n',
        "source-valid seed capture",
    )
    source = replace_once(
        source,
        '        "metrics": dict(metrics),\n',
        '        "metrics": {key: value for key, value in metrics.items() if not key.startswith("_")},\n',
        "private metric filtering",
    )
    source = replace_once(
        source,
        '        save_mode, safety_seconds, enabled, infinite_enabled = _runtime_config(config)\n',
        '        save_mode, safety_seconds, enabled, infinite_enabled, dynamic_enabled, dynamic_seconds = _runtime_config(config)\n',
        "prove config unpack",
    )
    source = replace_once(
        source,
        '        "stage_events": 0,\n        "elapsed_seconds": 0.0,\n',
        '        "stage_events": 0,\n'
        '        "dynamic_enabled": False,\n'
        '        "dynamic_search_seconds": 0.0,\n'
        '        "elapsed_seconds": 0.0,\n',
        "dynamic metrics",
    )
    source = replace_once(
        source,
        '                model_sha256 = _table_sha256(table)\n                metrics["stage_events"] = 1\n',
        '                model_sha256 = _table_sha256(table)\n'
        '                metrics.pop("_dynamic_seed_tables", None)\n'
        '                metrics["stage_events"] = 1\n',
        "static hit private cleanup",
    )

    dynamic_branch = '''                if save_mode == "full":
                    result["trace"] = trace
                return result
        dynamic_seed_tables = metrics.pop("_dynamic_seed_tables", [])
        if dynamic_enabled and dynamic_seconds > 0.0:
            metrics["dynamic_enabled"] = True
            metrics["dynamic_search_seconds"] = dynamic_seconds
            dynamic_table = _d11_dynamic_countermodel(
                parsed_source,
                parsed_target,
                dynamic_seconds,
                metrics,
                dynamic_seed_tables,
            )
            if dynamic_table is not None:
                details = _countermodel(
                    parsed_source, parsed_target, dynamic_table, metrics
                )
                if details is None:
                    raise RuntimeError("dynamic table failed exhaustive revalidation")
                stage = "stage1_dynamic_fin45_model_synthesis"
                details.update(
                    {
                        "construction_family": "source_seed_neighborhood_or_cegis",
                        "dynamic_model_search": True,
                        "formula_only": True,
                    }
                )
                judge_lean, certificate_encoding = _false_code(
                    dynamic_table,
                    parsed_source,
                    parsed_target,
                    details["target_counterexample"],
                )
                staged_judge_lean, certificate_bytes = _staged_certificate(
                    stage, judge_lean
                )
                metrics["maximum_candidate_certificate_bytes"] = max(
                    metrics["maximum_candidate_certificate_bytes"], certificate_bytes
                )
                if staged_judge_lean is not None:
                    metrics["stage_events"] = 1
                    metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                    details["certificate_encoding"] = certificate_encoding
                    result = _base_result(
                        ordinal,
                        case_id,
                        "REFUTED",
                        "DYNAMIC_COUNTERMODEL_FOUND",
                        save_mode,
                        metrics,
                    )
                    result.update(
                        {
                            "certificate_valid": True,
                            "certificate_kind": "finite_magma_countermodel",
                            "certificate_bytes": certificate_bytes,
                            "certificate_limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                            "verdict": False,
                            "judge_verdict": "false",
                            "stage": stage,
                            "countermodel": details,
                            "judge_lean": staged_judge_lean,
                        }
                    )
                    if save_mode == "full":
                        result["trace"] = trace + [
                            {
                                "seq": len(trace) + 1,
                                "stage": stage,
                                "event": "hit",
                                "order": len(dynamic_table),
                            }
                        ]
                    return result
                metrics["oversize_certificates_skipped"] += 1
        metrics["stage_events"] = 1
'''
    source = replace_once(
        source,
        '''                if save_mode == "full":
                    result["trace"] = trace
                return result
        metrics["stage_events"] = 1
''',
        dynamic_branch,
        "dynamic prove branch",
    )

    OUTPUT.write_text(source, encoding="utf-8", newline="\n")
    audit = {
        "schema": "false-solver-d11-model-audit-v1",
        "d10_model_count": len(inherited),
        "learned_jiaming_model_count": len(learned),
        "learned_exact_overlap_with_d10": 0,
        "unified_unique_table_count": len(tables),
        "learned_order_counts": {
            str(order): sum(len(table) == order for table in learned)
            for order in sorted({len(table) for table in learned})
        },
        "learned_raw_bytes": len(encode_tables(learned)),
        "table_raw_bytes": len(raw),
        "report_sha256": {str(path): sha256_path(path) for path in REPORTS},
    }
    MODEL_AUDIT.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    manifest = {
        "name": "false-solver-d11",
        "architecture": {
            "base": "false-solver-d10",
            "dynamic_model_search": True,
            "dynamic_orders": [4, 5],
            "dynamic_strategy": "source-valid-bank-seed mutation, direct min-conflicts repair, then bounded categorical CEGIS",
            "formula_only_input": True,
            "single_file_runtime": True,
            "standard_library_only": True,
            "finite_models_fail_closed_revalidated": True,
        },
        "model_bank": audit,
        "output": {
            "path": str(OUTPUT),
            "bytes": OUTPUT.stat().st_size,
            "sha256": sha256_path(OUTPUT),
        },
    }
    MANIFEST.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return manifest


def main() -> None:
    manifest = build()
    print(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
