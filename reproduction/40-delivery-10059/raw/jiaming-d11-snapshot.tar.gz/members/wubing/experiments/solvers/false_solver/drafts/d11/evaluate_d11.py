#!/usr/bin/env python3
"""Reproduce the d11 learned-bank and dynamic holdout evaluation."""

from __future__ import annotations

from collections import Counter
import json
from pathlib import Path
import re
import runpy
import time

from build_formula_solver import D10, DYNAMIC_ENGINE, OUTPUT, REPORTS, build, report_tables, table_sha256


HERE = Path(__file__).resolve().parent
AUDIT = HERE / "evaluation.json"


def report_cases() -> list[dict]:
    cases = []
    for path in REPORTS:
        for section in re.split(
            r"(?=^###\s+\d+\.)",
            path.read_text(encoding="utf-8"),
            flags=re.MULTILINE,
        ):
            header = re.search(r"^###\s+(\d+)\.\s+.*?`([^`]+)`", section, re.MULTILINE)
            source = re.search(r"- 条件等式：`?([^`\n]+)`?", section)
            target = re.search(r"- 目标等式：`?([^`\n]+)`?", section)
            order = re.search(r"域大小：`(\d+)`", section)
            if header and source and target and order:
                cases.append(
                    {
                        "report": path.name,
                        "report_index": int(header.group(1)),
                        "id": header.group(2),
                        "source_formula": source.group(1).strip(),
                        "target_formula": target.group(1).strip(),
                        "known_order": int(order.group(1)),
                    }
                )
    if len(cases) != 102:
        raise RuntimeError(f"expected 102 report cases, found {len(cases)}")
    return cases


def config_d10() -> dict:
    return {
        "result_save_mode": "minimal",
        "search_config": {
            "safety_wall_seconds": 10.0,
            "use_finite_model_bank": True,
            "use_infinite_family_bank": False,
        },
    }


def config_d11() -> dict:
    return {
        "result_save_mode": "minimal",
        "search_config": {
            "safety_wall_seconds": 10.0,
            "use_finite_model_bank": True,
            "use_infinite_family_bank": False,
            "use_dynamic_model_search": False,
            "dynamic_search_seconds": 0.0,
        },
    }


def payload(case: dict, ordinal: int) -> dict:
    return {
        "ordinal": ordinal,
        "id": case["id"],
        "source_formula": case["source_formula"],
        "target_formula": case["target_formula"],
    }


def main() -> None:
    build()
    cases = report_cases()
    learned_hashes = {table_sha256(table) for table in report_tables()}
    d10 = runpy.run_path(str(D10), run_name="_evaluate_false_solver_d10")
    d11 = runpy.run_path(str(OUTPUT), run_name="_evaluate_false_solver_d11")

    baseline_started = time.monotonic()
    baseline_statuses = Counter()
    for ordinal, case in enumerate(cases, 1):
        result = d10["prove"](payload(case, ordinal), config_d10())
        baseline_statuses[result["status"]] += 1
    baseline_seconds = time.monotonic() - baseline_started

    learned_started = time.monotonic()
    learned_statuses = Counter()
    learned_stages = Counter()
    maximum_certificate_bytes = 0
    for ordinal, case in enumerate(cases, 1):
        result = d11["prove"](payload(case, ordinal), config_d11())
        learned_statuses[result["status"]] += 1
        learned_stages[result.get("stage", "none")] += 1
        maximum_certificate_bytes = max(
            maximum_certificate_bytes, int(result.get("certificate_bytes", 0))
        )
    learned_seconds = time.monotonic() - learned_started

    # Execute the d11 engine inside the d10 namespace, so the 102 learned tables
    # are unavailable.  This is the leakage-free dynamic holdout measurement.
    exec(
        compile(
            DYNAMIC_ENGINE.read_text(encoding="utf-8"),
            str(DYNAMIC_ENGINE),
            "exec",
        ),
        d10,
    )
    d10_fin45 = [table for _index, table in d10["_tables"]() if len(table) in (4, 5)]
    holdout_rows = []
    holdout_started = time.monotonic()
    for case in [case for case in cases if case["known_order"] <= 5]:
        parsed_source = d10["_parse_equation"](case["source_formula"])
        parsed_target = d10["_parse_equation"](case["target_formula"])
        seeds = [
            table
            for table in d10_fin45
            if d10["_equation_holds"](parsed_source, table)[0]
        ]
        metrics: dict = {}
        table = d10["_d11_dynamic_countermodel"](
            parsed_source,
            parsed_target,
            1.0,
            metrics,
            seeds,
        )
        valid = bool(
            table
            and d10["_equation_holds"](parsed_source, table)[0]
            and not d10["_equation_holds"](parsed_target, table)[0]
        )
        holdout_rows.append(
            {
                "id": case["id"],
                "known_order": case["known_order"],
                "found_order": len(table) if table else None,
                "valid": valid,
                "source_valid_d10_seed_count": len(seeds),
                "found_table_sha256": table_sha256(table) if table else None,
                "found_table_exactly_in_learned102": bool(
                    table and table_sha256(table) in learned_hashes
                ),
                "metrics": metrics,
            }
        )
    holdout_seconds = time.monotonic() - holdout_started

    audit = {
        "schema": "false-solver-d11-evaluation-v1",
        "baseline_d10_on_102": {
            "status_counts": dict(sorted(baseline_statuses.items())),
            "wall_seconds": round(baseline_seconds, 6),
        },
        "d11_learned_bank_on_102": {
            "status_counts": dict(sorted(learned_statuses.items())),
            "stage_counts": dict(sorted(learned_stages.items())),
            "maximum_certificate_bytes": maximum_certificate_bytes,
            "wall_seconds": round(learned_seconds, 6),
        },
        "dynamic_holdout_fin45": {
            "budget_seconds_per_case": 1.0,
            "case_count": len(holdout_rows),
            "known_order_counts": dict(
                sorted(Counter(row["known_order"] for row in holdout_rows).items())
            ),
            "valid_hit_count": sum(row["valid"] for row in holdout_rows),
            "valid_hit_count_by_known_order": {
                str(order): sum(
                    row["valid"] and row["known_order"] == order
                    for row in holdout_rows
                )
                for order in (4, 5)
            },
            "exact_learned_table_hit_count": sum(
                row["found_table_exactly_in_learned102"] for row in holdout_rows
            ),
            "wall_seconds": round(holdout_seconds, 6),
            "rows": holdout_rows,
        },
    }
    AUDIT.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(audit, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
