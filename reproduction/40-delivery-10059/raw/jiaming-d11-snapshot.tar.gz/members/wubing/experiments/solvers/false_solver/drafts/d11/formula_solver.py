#!/usr/bin/env python3
"""Formula-only finite and target-symbolic infinite-model False solver runtime."""

from __future__ import annotations

import base64
import hashlib
from itertools import product
import json
import lzma
import re
import signal
import sys
import time


_MODEL_COUNT = 10059
_TABLE_RAW_BYTES = 371494
_TABLES_XZ_B85 = (
    '{Wp48S^xk9=GL@E0stWa8~^|S5YJf5<H!E*{#^h805k9SleYcurgo_*5}L;zu*Z9(wHM3pLM1+@#7MtRp*Eg7$gYn5W~L};GN~f;'
    '3pK6{{C?Gf%@pFY^+fGmdWXN`hZv`(3O1DzD9w>}^LBHfa7zYye}W>Cv2&|%Ja<+~bSk!Mj^+wdHLuYCt^o=yr_K}|QOj|GKW{0i'
    'M8IDJ?=j&HQ1Z3Nd%-xst&MKIzLxcT4kC|PUr8uYWTOR)SwG*Cj0j&(c%pjN=@BhlKj;xVu=n2x_va{|lIt@2rBiRweE4)VBZ^C-'
    '0y|PD7ZiKq7a{>X7aaY7P32!Wq6=-jRn)IpIQgKOPo}k=v9{Jp+=>68A27)-ZgWbD@P~|dVl0OjRu*y!%hX{C(5iBdd-(T|Z7qIO'
    '?5pC22_e6vH<P~$yh0dVy93aldeof2#kKlWj%40h+?_7Gu!)Gr)MXzA#j{p0L<)iPRHG@&_zzAmGj*g&6q?5lUfz##t3&z)DuwPa'
    '4@rSNU$zRfMrWELOcV^<4EJDMaZJ9EW9zv6>1FM-I=6Z=HH~Sr&>ImLEmTXfX7v}ga=oM#RLilpvybecM2T8RMP{E853hsq#D4sk'
    'IbQ>s>Q@C=qe<Vzswl)XIPWKMSBpJI6$o{thg~P;*h1+ug-^07#~jSnK*yL0g`F|8dfZ$^Ws<T9!WAjFL@HSnG!!pH@-moldiNJ1'
    'Z$r%ggA3b&liQ=^g+B=KC=^!iCQO|Wbd8R9U8!zaAdDKhPrb(bZg{k|=EdpwXN1FO#)grn90*TA5OL}akvU7oT2>v~p{;yvJej#N'
    'zLp*5n#q^2`3BQyxzs{EW$hNL&TiJazaL8?YJT7->O!rZA0!@~UJ**xxP_NeeJ4Pyi006avU%zz2XDP2G6@lhCdOHEFnG&Q(zf!j'
    'l`v6a(R*znvIPN9LZ01xeX)da_>0d#V^1+C;ec6qVj8Xp-R{OVYR~AW$3<JN5T`A2f}tNKj}P3VU}!qxh37+vtgguh{Pw;g#-U}C'
    'GA0b^tl0OD9G|a4lG-wBSmkgf9nV+ZA3m}|EF+^Csg~Y3>AICLS@1{S4mYRl$Q)r??~=qX#!fO{mXv|_U;;1vvf7}Mg^mBqA<Y)L'
    '%d#x>0+Es+t^lrW4uoazWY9Wb6xbVXseHxdmGN`4Lt{?qg)DbO`R%fN5n+-S&rZ@Z)LRAqt-<%b$cOESiP#tOYIw!g>Dy1eUFmsp'
    'RDh^c`;Xh;N*LNGAsL1JVy#Ow4M++DcvxveQlcGG$>`(Z-FkP;ih;RpG;qFHTsWp7vxM=L!#{hSo>gejA!%gPloiES#rf1r`fhOZ'
    '6^9)X2{Ync#E(@*5w>FNjWjB{d4`d9iJh}yA_vk~d{t$L9X*J#;j0Hm9SDsocu$Lp=h+|K(6z2qq(*%vnD8<GHqW|@uPW*V4ti3A'
    'd`vJ{3LU`3;r{h)jz_VzMX-Cyv4t+2acS;X%waiCS*6|$r@Wq6=ji0hy}3M`q4taAn&ft}JGx!h7IrBLvMrs#UH>c=dh(a-9(&$6'
    'uO@Qq!_lcN`5P*BPoV+i#pCZCu%5bN5kj9xx;e1l0CJ1Cth(pEZ?n)fOkvhr<LIPK(XJ4SiEU{i#l<;6-IB@+p_Clk{l>$p*L#GV'
    '=CaKNx#Qt+bcs4SkM+B+$){LsQLju@75%H(LhlrCI$&%OFFYZ+T88y}&m~fEr_D~yigRt*v;`esoJuSJa7p+jMj$+wuLismR@5LV'
    '9uzMtn>Y`GVv7);esi0=)dxXWoLmgbZ{GrNvm5ab+g_pdNRkcWR8$4_#y;dpb_R+UPu6mTVL}X%OMi(TABtpWrx4U)`*7WV4}qJA'
    '4qy{R3<X{uT)VE(;sx)5{io0LR19&(m7;h5_X45|%$bQ(9Z&z~Y})vOAbvss;vC)Wi{8v@#GFb^=a>H3_(^9lc{}R3MQWK{LnsUU'
    'Fq-Fgm{;3T$2x^26?;r)F23fnn|3y)3{Gog_-GOgPz`V0xEliMYpmc*>O`Tf`uim{!gq3sUB}`RLbIsEVmk5qJ!UgsWRe~bb@!sa'
    '{`E;qtE7&$l_7QSQN{pLOUiXi@TMMz-xZLa(LL|m(@GqDKZXBfRhhak;00BtxkLVU*ZT-PO72kYyX!xYk(A^ABrKNbQPtO4OPu_k'
    'x?to_ZRvTCbNMvG4D34AOe6Qh;o$ur^aTAWPtn?hF3y`((6^95I#;}Hl^@%}4R}O@X2LnQy+ec8OcLY9$%h|9JCUy0b7_f!QUNOx'
    '$d2q{$@3oO7ck$KCXadBMREb-5QnbW{3mTTLHu}!$`t&9hGm$;qfNsftURJgWnVWG)7nSucohZ^Sdw`svX<dvY7SM}mf(<c&P{8T'
    '@2`9d>LlR!6>$3TP(FxK{p?D)YU+h|cejjsH$kd<!RnJ!FlqVZ{A(h+)9?4iKy&;#9KiThpX=l-`8Q+>d$liXyIV7()W>ki4U%c~'
    '_&?D`hJ6*P=AYQH28EJ-2HibbwOaBqLgGE#CPI1TT=_VjV#oIr+q46WSeR+Ss!z|a>+KUh*cAr3z<vHBpMIRnDIeMEIxHc`YPh;k'
    'Uyf;*?zj-gj|GxbvL~t`l3G)fKC(xHbP?UGk@KX?J3Mxyg-zw^8-2`#1jYKQH6X07x;MaSYxsS2_B>kKHb<)2zLATtR7%|LLs_GB'
    'Yc~~a&_c-RF+c`EfI?vD#J1m~DG&$$K1C$cg$B`xG!vG}k<A~HD!%{p2*#9C<F54%Ex;P1Wnx`CBNF{9w4Ld)9b=Gin_0jZWKQ|H'
    'JxLb(`y61DF_G?+W}iaH%zj=z1zpBYzz4oJsT#wwPaCkK;NW*P0k1|fHhyXChBy$tr<dj0IxJ&JNk!OHE^Xyy<f{)gD(_&>6=_G9'
    '#l)dsD=-3JEfjgz=$KhBBFCF&Ep^TZ*Eclu2}`w?7Y6|D(edgsAm#8r)G@o&+5)UeW2UO)zxztX9CmEt-pE|*4~2nBqs<+Lsb#`{'
    '6^aN~TiV`v2@NDFCWZHBXLbm1r~q2pb0wUb>kXlHrRZs~3{`Yl_Wwy}v{c%gk6YAotyn34-WGM>;*;7BSLfLoILz(6hBoIqrBXhT'
    'L8K4c6HqaK#L9~4B0&&T<vp(f6F`gqaDt3WU1&d-?4D(X<4#ho@my>h+&Gk;ruCgq6q<PzHuyDw`IVR#V=Q^K3*uT0U)g7<3xNSi'
    'xVK7moovMz@je+-^MUkNJLlhuR0!iE9?lo`rXtCnI-Jc>uJiCuScmWl3|-`>8qzJA77Gsq$;u@dEZ88YH^X>nlpS<%Bk?n{0921q'
    'hlFPj6l@lNF-66k_9YYPt&q_P$2%*Z7574>7Jm8^AdH66NlN|WF7)?`NSHi;Vy3ECjZ<c6qfAM4ZEm7D5M>wZ6+tEzG_nU@l9~^T'
    'u#4(*ofnjcNpiA2d`KK+d+%y{O&r=R$^8#hd6j)}h7E*J?vK-~<9FSHTi$xaELXUXpLZK&bx8PJXW3!$ZS_Ud>hYC|AQY!>2ba0)'
    'wB8^HPJGxVy!s`6)#L@aQd=<;gPh2iD*Lg-k5rSV?8jl4`{i!bRJ%~;=c*yvWS)Q#)I#N6qINAw+upq7IM5In*!j(VxF?IQbG9B8'
    ';~1^}(G_8=P7(>obk!&0b)SW@5tW*SH2DB$w!><_JCb6@4KMr!KZ`9(d&>Cnhm@7>?M=U#b?FuI2nXa6eQl2$^3KN^qyk{w6Tj(O'
    'S|O61=fw6gk36biIDgw(u%WlOJn8f|cOiKpsvfad%G$ME>;~76X%zvQN`wJdO4tq~_N*_iZ8#HyH943)>?IgRA8M8mBZ8pLvyDaf'
    '0tlQ8+olG}R8Ywn{b=5byc~_Eg<*@i9jp_6s8uYk)U0!?kI`h2UR``tBLy!VnX1Zobtt0#QM!?lS*}yp-ISr|e+_~=BQ3&f6GnEw'
    'Yy>Q0u*LQqDIqZ=XW4Mb*Xik)AVjt?u@V`~%+m^X$~LjGt!wDH%FS0$hHT7fL;+~kpo-hjOE@8%U7SiGAtC{bKLu_w^VfdIfyzDa'
    'DQj%jz4s1t#wGKTHP|(gGLRi*kz<HHc5VAYG4*5ia&2=@8QTf4^rb3`cZ!#%iqaerd_`d%G<%lcLH93Y%NgPmPOQ?61)map;-;ZJ'
    '$(8qmQ1YhtZKC(=fx5!ys47wIUjiY6qLs}6arXs_^9=@8mU%3{EjX72*%%$H3Nfr?3(CGXo>9mZ%61DGu~?E+ruzT=E&G=)a40Pn'
    'GF%BWx6Mh{(d@OLSyImT%YPG1i(vnW0!%`syE?yNHePz2yYFe!xgPj~4tR+)ezjbYw@zp<>1-$^2=$9HbLOPg!vj9QP_%Iv0z%DR'
    'NFOpzW;oy?>SFDEr-OeIRD|`1+oU@{QM-^D@o3o59!|nH{-qI5wnvV!k#hRN)^kOzNCQ!qL4_umxgkTwpep-YcvxIXEX{A=nW0zZ'
    '(*CaV5WVdW-3A7QJPsfFd<mJz{X0z+`gVS(6t(kY<~6Jd?SST^Rv`q>>0pQ<!)Iw!6^wADHN;lGl#9#EKoBICo;?L#3Wrnc)w-}H'
    '=KC$4KGk_7H|Y?_6l;_jgR^_Ykg?buyf>?4nk|>hscG>G-trQp(Y>Uxz{;6xSL>x5e;4)<K191)U0|YQufIFS@~$0&l=X>;MGftV'
    'X8H@&&O7FF0*4iS6sGal)RzzC|7!P<z;?n0l~YU;o~H#m0fUWM1<2?bBofdH2e;t2ulo!EKTo#oy}xVEavKOItiYsse!G~7I4~wN'
    'mY2M&Qb*9*Q@$$<=w}>qAZIS;8H2bjSm8M=icXu+K&~;5!%kXcOVt`NylX2%uBK#UYVah;%vtK(yrdfmJaS-QV>LzaeFpbbr_CIf'
    'e0vvyVo#+lB?_ny>uL~7io(F~w|s@0hPFaBM*Sl3oPQ$g%Hi=XD#c>*K9{+xH{pQz@uvh$dz5QS*0Z3d^Jp%?oiOHDrF0{Lpw{pi'
    'a1kOKp#R1Df!Fy9{UsAG#w^MJ=E_W#J%{0FST!;1YYS!#4W?D&n#=e&R-UhegGA1~xX#9XC;JWtz`R5;0Gw6G%|GO<5-UE-70Xmd'
    '^tB@a^kyCqFe9|LH)KZ&+L0BRtD`7?ZTZ#S542$vv#!{j(L%E>Hzlq-r^;{mneuSpRp0r!CC}vPKws%$ZP2LgxnuVIJFyg!djpV8'
    'tc<o3dRe?KSne+@z%IU?C`56H<*0SsFiKy40|L!RbePg64s)fBL*8dR8YVHdj^f{}B(t35^>;MFeN2Rkc6f?l4xAUv*LRQPcaIPE'
    'DzDE$pOM-_^hg_;FYDF_DuRW!U=v;EX!GdleXKT$zI+`b@;w@tqJ^P%TWz-g{O6dyX7Z*9lX8}x+$OC<h--HQ{(y6op@6?LcM^ui'
    'RcNtllrjO%fb+w4w|sUN4+ghAd6ui-GXkC1iV(U%SPRa^CXg{`?P}dO_li?C?3jQO-?X(T-C1b)4>a7ZWkte(7gYYfNCQ4y>=ZTo'
    '>?kU8ivLb4J9Vg1^z6lNyMQ_9y-lrmt#S5I@<^zUWRh1S9ng+<s)bc!+MQ4^^xLuDqj>OP?^WiJxm$U6vZWh0A1l!zW=!2_nQU=h'
    'xba~2<du>sSKnp`CjP(49<L*^b3A@_E9itXa^ZQBB3wTLU@@#_3Y!=zfjNJwyT^Hpwy59&Om0ZK2zuW@XgK`Q@i7ZwB>EUc{||UT'
    '_M0Hsh@AUm38Hpkf&EEB40&>EWEWwFb1%Ny0CFyYjl3M2@J@zr!!0yigl=z6a|jY%>L8|aDx}q+7XNltGSDcySaJ<oHgJnH1^4@i'
    'D)P@(z^C<{M~25ig#IVQSe)I|IxKEJ&13@;=Ml{8m^QLHj&3(YllJP=P?=Aex9&B82k+fWZmHIjkh9xo`9Ijq<iO^~E%||Fb~qUS'
    'Y~Y;HM54rxXyS}#%B%btV@6VbIKwy0M!A&<a$qP_sK^|zv6d8n;X|<wEKu(dvc4%zM7llW2`HWFZ4P^c%beiwz>+5nb<N~LHf_Y_'
    'TC&#hC}X<d|AU-5pMEW`DV?oE$P$owzE(tG5KX_sAw#tp_oc<gok~x$gFLR3T_S0z#CKG#8A1hxhd$(c8llm*)ghGZ6zyfjgg)_W'
    'J1(oh!^Yg~)o--`(m)IVgMR+rb`cn9`1c<c(Z{AIPAN4${SRW_HNl)&V_s}2QqK|8uQp!;O4ul|n+Dbp-DJPgj9AZjPx#t;#lJC?'
    'wKi(Ah5KS_g93u!GlJX*ndjF0BY3oFIeV{s2Z6;4cRwnI(o1J|l_svUJTu8dLfe2JDSv}n_tW{Wg3;%FMvkqZu>#mq(#{E1@I{7D'
    'F5GP-y0j>REkoJ9v#>6xkZO1q>*3CVZ#fqH`h;;R)=vg10O)3#$OK;rVuwiyM13EccE)&kZLn-&Z0EW52v{Z`qVK0)*pQosb}u>h'
    '$by0JoE=uUg3sk;i+jjX(iT3=_XoB!69UoaZL4UuN_jOE6_2`gv_u2U9Oxnl^jU`7^!nC<3K^YpH#j77k!Ki+*Z{Lj>XQWtZV7CW'
    'jLMkuEuDe$p(AP2hqTZX=8#IH?y{ihJzDGrpmCX7XF^Hw5Ox=AkAx!Nek`!s;V2xB2yKpDBdeJL__Rkc=o8ll!Wh!w+6KG}96`vZ'
    'O&oBI+2flUE=kxGl}rdBm3_Z0kiwV1gfg_B@PZ?p+Ewy3fZ9LbL#a`%K%`hyeZaGnAm!AR-E!_OP!lxMe`>@zilBsu@4fZE-_x|)'
    'SISJmate!r0uz3@oxl%oSYTQlke>|Nt_@pCvX6o{$}n<vxLBV!5UEKzz;6!5@M}o=>4Gwpnj<9Fkt3M$Pb3ULABRJ@(S<)|ZYXn-'
    '2T=rY{ib~guJ$DsdP;D=45Ai2IXeemNJ_O+UOn>dHF<Si-v*U-#2=6b$gqi;5$lo|m>&BjBibU+J1DSt!`1AkHR$5s8>oPVMBy<6'
    '_?}yaEDA$hde|UM<Dzt-UqcPK#knlZxCC!@>e6b2%;{5w6#gD~pvc#DT&P`6`p54BPKCE@S<<Cq;w1RF`yGxv5KbitD!-WpPW$<S'
    'YC2E}aL-47uuk##VzPTdp!abes%1`ew(?5Bkam+UH_gS@>8a^50ZeY|g_MrjOFlwVv@vp?{dmViXSktQ4id&>Ri5M^L)k$?OJ_kG'
    '{Yw?dilGa;_KHyn*mS}(Je7fBmj?wauCt<Us*?mTIUuds^nO|y&jGuWG#1Mq8<=-uG=l`v#~%%hh}Dm>rtzQ}!o(c*iy`qDAZ-|r'
    'VSb!}5k&_?VST-zH2+*un-tB(`KS#7DMaNOs*nEPstV-lGn8k+XOl705#47HN^**aX~F&=kHtOG!c?7?+?AIYjgxd|OX11be9Z4!'
    '-eC~qpkUK-eIz-@&q!QDR9CkO4g#<{DBq_Oy+c=Fz6gb?P~yfK7jdo)M*&2Vcv*@xmrS~KZ4H+vB4x$Hb^_43rjZ4+#aD}%{eoPJ'
    'j0QjZq%^(&_#^b7w%9Yr%H>+^nBGu?;F5Eua}&T17TI-j_t+Le5J?V>14%)pJU<`e>|RB5jSdqUeOkTFqI+01=Uh_hh@!PVf7i!J'
    'RL2&O$=NUg?tdbM-i_+fXPk?v1!>{s;<F|Gq|zeArvKBX)r?($M8(`rqBPR?JUl9e&^m;^@&C>tLv>K<kIv^H*#0h{s^|5LcF^h!'
    ';W5HdK`(`u#J?S5(sRSukGFEzQXfn40GQrrOTJZr1K0k_m9Q4j!}=jysqBQp3tpb77ghIM8)=i!XS;O0rGlOf6o1?OVPf*Fui>r-'
    '7F|wEEHdd+l}jE^kg}dhK*qZ;Ljm^qoNGU+%{*nxTY^2c%T>QXq9vC*4GLx&K>D{CHDd$?V!hW@{vNYne|U$pB8(DQ)KxiCy}O7*'
    'BepCkR2EBM2}|?>(^ta_MCv8i47euE0UzYP)QrTQyRl9i67KAE*z2%vY5*W6!E_7@jYxo{cw{gfn>vDN@+MGg7pc}4>KqDrFj9iR'
    'jPKMUE^P?b^;+5qmFGd>!3V2UC;=84!tNKhNNYAcJA0b?K!59CT&K-Sm5cxGmYtda>SuxcN=b2H0hD2Z4NU8kJ`xk*H{CY1OF7Zp'
    'Ax!_DnLc|kl~v?iH5nA4j^;y_6gq}eHDSZ(nX}H>5<Qg%u`IO-IIveAIj@3)icy*_0-c5VSnm;cSG<PZ&zUdxJMi|y+b;#y-kv@3'
    'Ty0%R)^t*>(fH<Y-Mb0R2ze6^FDGl2dASIlv=kA*`Ubs2o6hWA4=7{ll$8?A2FSq+zrg8mSIG}IaU7!8Q&9xfUkn9P_fA!9sc_B9'
    '?;0BOgHztQq@f~SpX0DyAQJ(zWQCT{QB(}<z&G+hX>szV(<60PXh)FzDukh-=Jx{vP{oz4Dm#5z>yzyyQw`j~!&BH1q8e5%O&CX<'
    'q_**V%Wl&P%uxUy)9iNsHyO?2xH8Z^qmw>u)Luwd^vs~4LG9w@D+sO%rLvt=3J|nwr!(7Eh*$^gSY#3EhU3z7C4(j#7;g55{ur*~'
    'ctQM}TeGaXDyP|Y`&$OeNWxCI*N}85RjmU(u!{(uiBdiqw(l`q&ARp>CI$NLg5Hu;XtK5d<*~C^A98}`j@is>jEe!_gkBI5lW-S9'
    'yrGi~7gDao#XN2oLmI5P8~-vHcIs4<QisAl(f=m$S^P`G*4ZplYK0YKLILJehJ&lSZ#4@UwA?saKzdL-haMtcR6E*?Ph-M9`fS3>'
    'IcQ#Ep=@WI0)GZBH$<(zGq}e25Q3~B_W2Um){d{7!cg^KoAJ|*1LuCrAhh)Y9$i0oE1ZQ%PVvnEKrXK5KYW7vR8_B)=s3hbWHwEi'
    'Y4Nj35aG*yKMIj{x+H~fZ2Ewf937{vlJHnsU#2yhnD_}1=~OP9pe8*<9x>x4$uV7N20uL2t?mN0fFYLey(3F)zX;@-qX{>hUnK?9'
    'bc=NHk^5T~`edynHBW+vzEW1a?f_;2nb$U7r9sJ*7%EE0$7wiiP58sDfrGI1X-cix07^T~t_WPA(k8Yrgx`*xL_q2tDmCw^WX;c6'
    'x?f^W@jF@=Mf7D*Lwz?#r~?i(a9k?7RL=r2y=hwDP%b)X?V>CSU)h;E@^I`}^Ovr{%>ctT8c^ig5&ms86J+Ni_e2+zPo;vLcbVDA'
    'macs1UWISK{=#=+va-|pkRt-!KlR##mm4JP%}WyLfQP+D-hcz_LPIwMHrx~Byci$AEKbyocqrrbTCh^?O2@mYEk}I<+9_Wnadl~c'
    '+@~ceIRK@Hr_UqM{r%6!qW>^t%GzBRz17S>9|hD&ghpB2(0ybSe0>V-=xz=##EvHn#N;V#nmX<$si+=hUFzs4su#jY^NeXvw!oFV'
    ';2V9^efR(B2(b>rwp)TucLf~HXO1Gxf9>?=7vMcTQPs*FuHy<^R!v{mhgw>RLFR0{+Im#g8T8(qiw0@8N6(5sLWsP(5S_q>I;Ibt'
    'ET;sm?4jpvGecPV#WHZ__2JniWIuT>{<&jDJWj^6vn8o!q_o)N@-{E;NZ#xs1wC6=q(E_%J|C|~F)hyGg5RxjD6_h4hkUa*b1kla'
    'b+V4ZjDpUDPcv&-{QtC-3J^h-T@oU+uYLuy5eh#aMHkU#eK4GJY5OpIsayUA?l_EFI)f(I`OO_kl5sXOk4lU5`=*SMbW^QMamkCv'
    'V6f`=?WhwH$9MU9?ED(upjpY1&kis_Jxz6<S9Nn&%1uRr2tP8ez8`z;$228<hSY+*OsFTHbuW+oz!@BUg3Sss;h$<UtnL|X@}Z5#'
    '>1^=;nsvz=bO(iC$QqQ5{UJhpjam+hzN841Hc0JTbauC(0kY86{Bo^%g_NLIQs~_?UH@lP6Df+SP8D1#ZGuk1+yRS9h;cVaGcI0A'
    '!yNUfMttG)saS%h5f!3@KmNZ-5wwA3U{@|Pa^3qJ#gH(NI!!4m@R<$b|4%-y-_W*!RVa8=0$_wA(^(`pm1%YClVDE_Dzn_xS<<uu'
    '7#bi$6zEmcUF<UERbZrDaMZBUuCdf^%0=|qe>MD6!X<k2f>9K%%FSvngl&2~HWQ&K$^S)rrq!3itrv6&$(fT#x8zZ2M;@Zpv3SQX'
    'h1H_a;k!YU6uE4bH`@s|FC87&Ij*_wXjzO)sO2M#yiyhbT2$T^Q?exUA8ln(4P7~vz3-3QFutYg_r<lbnc<NTmU|dB6f^u{R@edO'
    'V5j6M^*^ftIb#I1CoxIvu*5f((p1{XyQ<1dFg6$0UVv|Bpq?z7lYGsjW6uRmT>gpn8wH}#Yr6`v9;g{Fl%KN@1&z(&ZT9Lf_20YU'
    'sLUBMHT8;gI4alaPA647e~&tq+<@E87_DfSPW%;zD(WZQt6Zi3CL~R0EEo#N;w+*2VJzp#2Es;b(R>}$rifRuu^-c5$0^>Gt*B2{'
    'PLu;TSC4FUq*zqjcn0F54RvP$N7|TkXs3|r4z%ocCTRPf?pvXT4|&bIWoHbZmZt&f$aGSCWn?sqFW%BB>lPf~&!pH{;dX^XCcEF5'
    'Pc;d_i=f`9dg8gd)>EMdrN2YCv9*X)_yjE2G5PGyO53<ffJk8?-3%8h&fdLl552U4xfrygB4ZaN<UQXdwla@{A#6dUVGkgLa8^k2'
    '4b7j$|7y;N;n<h#?HLy|VdHQzc8TQ|ARQO0*JneRah3?muS<S}ZyZWO=7wM;b9d0PB<dxJh<;l)c%*fiY3^T7MQBadMTi>mKEhiF'
    '3#HnViKkD753kcadwvOgyB_AX|8z>G<%wHDRnDEToK?@#JsJ^zes5INN}QA|(GIN$K}{qotc`0$7b9CiHjJh$@T4D6UZW@vh8KZ='
    '+0KAIjx1Jd62?54xcNwHf$XaGUmsvK`s<_a$?xvQUp>m}yNvc%#np*yu<*MY^_=aXtk5fuA08`!ZTr|b=LiZuOJ~>Y6NqYkSY}@G'
    'f1aWFNq4QDYy0Ym*f$TeN#Qb*e8=6^>W6|GZ3DmY;UooG1jDTUSNTBJBd175zlJG--hIm4imb9`QnI=B^YMArSx$@82Mz|;Jh_#q'
    'q2ILuE~e~(<`WA;<bS4N0k^Wl$I+CbenB=`JHenMcki6`L3&NLL9bG#_%7%XKF<(vTk^6Nq0--9tOkFQy>m2y6$Mn}lXXi_tzQw+'
    'WR9cmgr`rY$-$LGXP=glpQcJ(jy;yQw3!23w-FUj`@Gac#$+HBSFweB!q1<D6w7MaYVaYq_2%xnBJIvI6~{Tu^kJ?Gd}v!#@BI9o'
    'w&f<ou8q9j8?LjhBdu3Xn3~ZH(x%%bG+yhg^@5>YqhXC>64DHTuvWJ$C42mhFlx59vK_3;av7EfSFWP%hUZ^4ft+@Q;U)=u`Z~LM'
    'gH4LuplL-%kM|`8D&ygU%P_FxmoMOF{h{uKjBf`e_X#2b(s;n7K2EHLfMw5PEl!kxQmyf1fAb41z3H%I+qP$>S|k|~RX4-3E50`f'
    'h$2q~kP{_t?KXglJ=zgXA!9wSf9Sy*oh$G*-q>ym9&W<C<EA7`3T8IHivl;dcHMoKzGGYJ3`)A+fzev!<jlpnIgsDeo?9`tw~tH@'
    'alv1Z74(_~w&P1Ysp*veNBGr$GA62eD`7nium@)x@oTen9$3;CMty>uCJZRmVWtF%2uZ6m8(5`0;LG0CdWmRDZxk^i8v8*+SlS*4'
    '%A)*s#KRiM8BdObeFc8L@U$b{mh7;<inpTuZ}m7tIWlTCGNXSFTpV|ok?-%a^FKl<=Frt;oFB|a0}H;x*|nZHU{D057MYMP^}cOS'
    'O3E1>%F)Thtu#ISzdq5PBWqWU*grC-B_5I}k6~Q+x>a=JPs2LcV)pFnX1(T>j$!X<v<Y|1!>n+5RcC^0eJl8mE4t6`R;uJ};PbA_'
    'K>9GBqv0qBkf@vTz@=nIJz-XS9Z&Ow5vt?D_>T&RN0u2fjH*2G^%OR1>Xt?$0@34DMDlZokWG{GPu(fB%l$Gus-arD!TK*9tcuUg'
    'J=C#D;(zoR61FU9Wu7Q~;ok_1N>9;7=@B+{AElMI!q7i+zX0^v2_6u^LqB12UKN352l5tA>J6Me1%?uMk39;>%D})BkefR9^&ZGj'
    'R7QLZdeR?p@DU=aSBt<LYiOMFT@tcV*p8Y&<7FtVMIi~iH<%N^Z8fPRP0C3m2&je6lVnnRi_41s^NbDOJvsENUKmW@y~fBM>VUFg'
    'yZ+Xf-LzA!!V3I^TP4ABhV0by<l4aMMWZpKV>!aaW$-WxxTIskhM6s~foz0KFlPz|x$!4;<U@2;_K)Vc@+bw5{}$ga<wP!ZXj2C4'
    'EZCZ|It8o<XhOutYbIvv@dvV9iyud`EqDi^+@YwK^9(76cj`M6&`vKK&`~8WAVJ~ykW^KuHmFe#Vpr4-t&3&P{JPUheZP=Cns)B7'
    'Y}!XenSDEUwt`}<5HEq$+rxl|4XbAO#vk<RRmeGZt7K#0?o`}ZQC<TPfx$NIZh2N1Qi?8^*5*6I+>JfG&l^Cp<@4+6p(gJTEtTVX'
    'j7}}*ms7La8xv+iTQtF9EVdy4{XqPV)v185wO#+8m^81RR+iAwV1DwjZXa|A-)u5@@*FcRAiGQ_vN3nf<dM_8yi}R2PZ~O|Zm2Wh'
    'irL8G#?RoeP8*^f#O7NNl&;u5Tw;m1v3<HiKh6f8Jh2?ip4|9m)KWc0Mh2S65B)4)t(O460)^+9Jw3Tk{wRn6fuKr7x+tRx0*`1C'
    '!zhLf3ud<APNelFoZ^eRU@JA<Tt<lYzP>k8L1HNAj!MqMZae-id}C>1Z+s~WXb@oxX6iEHu{5OO_Ui&s1X~CrZRPpe%`6pmFYCMA'
    'gL}wD<@dW=(at3aOzT@GH7Z-o4bWw~Q>%B8aS34(NF@@b6H@j0l7|KWKMoRpO(Hi%xc$4W6J>#q_uB$C;wLB_Z$ALeSApF<w#p?v'
    '>&KbS9nMYHX<JF8Mh2@h5NfVmX`5_%ZQR07N%Z%oCEP8gKqCrP`|7hZYoip-GhwCzGK*8OC`%t$GwG9A-LjFBRCPw^7u@Ej%?Qb('
    '&7%L&>ZshV&Myk7Pd9K_4TMCgH({ub+%14SC>%h5XW8szkk5pRyJr9th;sh|Y2Uy`gJHi5ULa?%J>8tA!gK#PX7C4^n3=%sK;$Jb'
    'mz9Sjf=5x^>l%jtNY^Vo3ePM~5$OI6K^ccbVBVL0+X1$>{QhYz&+ocqvwcbLhQxzo^p${7)YC=S7XJV1n7CreBk}|s0H^cCMsB7g'
    '@~%=k9>fLpi0f)5r(vx`a~g@1i9A=8Or7KVnsihy{nK}9FLDX>oQi(455!-JN?8GHCiCH#!?;!Vn|N65uIVP*;DYILMg_bwK;QLy'
    '6hs8{pOHe_(9wm9zK{rX)?Dgg*=O&IZ$Gs<5;TtTSdd{R3l-IOX(j;;lCbDr+F}q?yK(H$EV)Ye0}`B?!E5g)sl-8|sTmbW)MxQE'
    'VLA@tonFJh+z2UDI7HnVx5S#As9G6Va>As!2T_!lENkP$T3N<WWd6oQ!lmWhwhj?w6Sl{1Y(5qf%Ci~x2*#ce>4*}uCAzS9ZtG)2'
    'oF2K+)MEkfFkBRi{h_flst>?eMK4;sAvo3g|B&q2%$z(R1eiyhTu^8?t9~1-4$ig1W}V=)n2NVhWiQYhUwv!=pI1@RZ;y1SprsjI'
    'Up~*%=tcb9?XC0G8mZU#KZ|KzZ(}152_9gfOV*$b8lx9*YtiPe5h0pp@*s7gLJIRc(65suJve@Rd=b9TIu^xl_CBc&EHv$_rbd0}'
    'bN424hwlQ#Zg5$7WlTD$M6X<w@7hJ;kOHXovy@QIGbit-&k+2I!Y&!T?+6)J5q4~F`IO!E6bKT_0hSLjB*=AfmDVNVeh<sZ*@<jl'
    'MLbey2%F$f?fmfG6*S#Qtc({aWGd#;<#wWgIH%#a)wwcbo}>-8v`ospetN8d3*{558mNfvdHzrbMSh?cGfB!Yc(I;Ldp<@U6cbJ&'
    'Hy>LKZ^g+Jb1~{VwEwUQAh_i~6k&@%-8V~c_)hUr>wdl1lS8b~GD%BU*z}8~=-+B*RI*Mq(gL~c3ywTnh+LZy6gB_giLKcsVO36o'
    'wP$jV)=RHOfrYZqavbxm!P?jn9Z@xUCW$_E3-{naosNpdzM&V1()aVT!VzY331Ds8BGD0=UBXKu5J?>uKkLiw-9O%TDk3-CdK&k='
    '%{GMEhSUV@g_Bz3i`|Pt_kOq%lgc`mmgggLeA@(a$aS>CFJAzJ$9Ji%)Pr%}yfYVsLtw^J#C4(^=kS;`AwfjWqwDovhk}mX5GYjQ'
    'AatjF!B)dCy^j{u<Ah|EsmMyT=)=(bu!ZI2vtn*_B%zr4fDQ52Vrxc;xN6goH)dk87^;TWgE!ks9e~~?mZH&Nrsp+#<K?POv$h*g'
    'F04VK^wRE4B8u*NnN2I6++W)}7(^?XoqexhSR`Hap`CWr9_ODb{q_4e9i;uxdyW-T(|v2VvYu3uyK`bSfz7zRV8dP!K`${*6I)zx'
    '>{Pli@Cs)0PTK;o1Q8pXUYGL_d|+&RP6w*V+h9&5{)^-`>{y}ZBb47-=%2{bhe0juH`AWJj@Bm}Yh-O4zt)>jxQ(BOOI#S~h9@zV'
    'Otj2)Ev3JovaHi#6mUdl)Q}NxV$-f}#IW5|11XCbm~bRg(dVko(S;4x18cg$IOK(_D*aW9$mSO_5GNetiRX0*N!Z|u?}Pe+l4_}f'
    '?l{7!;8~kW=Xz_b_AT#&CIYxQZrs7c0kzd0MF>%6ah47?jVImt7}Y&Udr_D-nTI+Wx)4I`EZxK#r+r`E@|1Ij=2S!R)xd#g;U2t6'
    'nM(^JqlO5z>H^;EE(=nEAt9luPx92BC~;t*uprF(2l!`Bgbxh}$zgvpVR3yNUUNN;=g2+6GS=o(zH+FH#W6xUiJX_gMNW2aC_B&{'
    '4+#6e(on#(w*!eO{1V*bO7GD<qXrCzvJ-;Hez*WP`z2bHNDO(UR5&0f^VukjLRj-!Cjc#G3p}ZMbrc`Ofo^~AB1un8K;vt5uX&=8'
    'r<dK@;e3haRoEMzq@?ANJu9Ki3DiYU;8?D{T_Tn<fWkCEQ5bAa^0Iz^D}f%aY)h7$yGx9HPD-T%M#f!A>_l@c1j}<bNoAn3z3d>I'
    'VVA}6K(l&Sj?&kExx%e)%YR9t6+^COIb<o_&PZQiNQW08XsotBK91A#CbWJ#2BiVPP_3J&^z$b{I>Z7^95HhqK}q!S>?yE#g|8qU'
    '37SjEj4REr@w_{&h@f@~)!ajLVTM>s(1v+aXaP1UOt&dS%$nFuK-!BjO=A`+Chy$#dszQf>8dXm4EhOm#dy*jq0ff1B57_So6}AN'
    'g|mhg!8!VO2<nZmm|#wO>M+_E08$-g$*amqu)Ifm7Z-yv(@n-5mP)%zaAVI5t{WmIC=24h{jqBW5##^tQ@9X$UpDUEL4W(#YIf!;'
    '1B^qAU09-QN)bI(Cu@W%lgZOKOit7vQh5M*kI?xD(C^#L7b3t0ki)XrcvMN$k{xdK$WR`=%ZhiQQyChW>`z3m%_A=+`BmNV&?~=5'
    '<XWP2St}E(zN69bnJQ$vK{T{hbvx-7DiU6!WUSK^(lLS5v5tCy(gbRmY(reGKeGu<d6G-%1(!+T{MutTW}!Sd0@2V>#KWph+aBGX'
    'Z74b^pl{3Ocd?l5tO#zhXGNl)n^lYYttjP84Cl_sNA`O22_S7s9lmp77v*K3Xd)atlTo9Qi(|RyZ9{#O2)1HT4r(AwkBoiB48-0<'
    'o=Sj-cJA6+M8u{=9ABv>eM@FB0uM`foHW#6C8v7+QGkZxID)5v{QmpfdaV5U_~~#Mtdg%#p8OWh8Ox2otyiwkGB^90Mvz3m-%~Dj'
    'iL(Z4l{8X(KhBs+;>?#XeA{)E8?>+{oELkZr#T8=CNwleu?_w&vsqS&#Pl~NBhe(VjYD$ZGw^!?a$o@#=ABoT!A+}~vo_kaT|h>M'
    '4)m1Gmj|P21gR4)>rC@60pS>Ga2B*K{J5p#DO`7>rztlf3$f<NNep`9lhm1K!XD1YJMTUn!%GS5wV!5Ax!HRsGK<yI9D|Q_6!83+'
    '2o)RghvIE6%p&qUQ$udLKuz6h(NW(9Wx*TFou&n&X!5`{KTcfYTU_g+(fPy=*jJ%^nSORD?8yJ0lA}xe<GVi$GGO<$ITr}Snm`mw'
    'tx+(sA$mLJ_A!~Q;@Cms1E<{f-`0Od**v@KhH1`-+_vIq)BTu-?I6Fac4RkY`To#FmFLq|nz<=sG0}C7l+z*SK&LbHabw3-e@#Az'
    '6%y}Gb<^Hy=)`Qy#jVqy5_>6<Oi9piyqj#5t78(LOJj`}*a>KC^wRQa8hb8?BO|YOj0xXZ%t)0NLyux<vr{f(B`%ZE^v`xgD|OBg'
    'A|&~-W|a1X;(#{u3(vV*h-o@%w)+XqRe^|gbFdTNbS4+7^d^pqImSKnuq=<Ff4pZ85t#KHz@#_ay*0pDahVwI<EB}@gG<McRtkv@'
    'uv39W_{RRoE5_GC{Rd8vnL^jO&pN08ajQ|3?@dgyG5VsTJ}C~BMxT(@IFSPC&Ds~1Z4(1@!{>Z$QvR9PTC4f}YwpJxlp=_%jCMU='
    'ygp)n!<rhdOcX1$i0W?o+SJo?v7So&RFS~@2zsqpdzHS2a@n-+*ET9bB++?HUQRBt?eIrey4+GjFl>cxUO`i_dH^sUg*PQ==U>Dm'
    'ZH-Cht9}3A(x;t#Do{`69o=9GjAG#AWhY(Oo>{Fr34KTFH}&iJ2Wk|)X1d7Vj)KZ|*`T29Sf9aR|L5ya-J8EL)B#~!*wHtD(Hq4-'
    '^&ikt4``VloCOSvdcAW69XZ|j2ofHmDv$ru=}geP?Qobvfaz#Cm<z2}M;LfY!*Jqnq!1Do8pQX&)!dW|j<{4rSBPV!-S}l$0{Bm<'
    'c=62JNw;Ka&89>u<K616z18GX0LSztxUsh_tMv6liKz!t@np4Y@-q2$ot}7N2w^&eVPG#~Ye@(lIYVFyv^k(zVDX*-PMno!`H53g'
    'mo4#uE(LnEjX(%tl&rkq3-&u0qQHg#F#5+lX>SAPewUxkc2V?MJPLX(Gc6%72KZt?@9vU8SW|SlVQVzzk}VFgNvU4qNSRo~JpaP2'
    'RFB`UMdw*mr@Q!d0a5+;%AzCLFq+glL8CE;KN<Fgm>0r?3KA@^Vb7$dNWGtxI0yAA#kKS}uR1;km=L&%b=smhcH=bltF8r3aXum{'
    'mwQ=Xu?*elC#gpN^ZkpoAV2}-Q+)|o#^ZK|E#h<H(6gPA0ck$rOHA>oz0wr`))@jQeo<Rm{Z!O6Hof69+GGh3X0xp^8=h<D`*tkQ'
    '(FX70cOMt2daq+%n{wgtypP*u3?1ITLmId)c%}=WV6Vfz$)vsylZ|IavF!I;oGIdKEfprlfakfuM`)5$P~*+<{+Q8%Zg<KPs;T`^'
    'Mjt(_F^v8${HerAWDsbM%pedchU6;Mf4aZZnDY)Z#%j-Q-w$5&cI+mq_x69uk+eVvMo$wWdVUT&8|aZkRsPEz2rDl+A|M6;tfSE|'
    'g<4{=J4v|@Ba1kfLl7~sDt6}JO=fcVK&|VAMLABB{?ig9{Gg`4NH~o+9n5<VH5UbSp<=wvUD(FF#KF0&VZP>%A8l)1AN=a6#K%Ur'
    '>Ws&uv+~GCms#w8)CKy<A9mzo$pG>0KWX>M0A%@WT^52Nsmtzk5Qhm}pUrO{MX)K{g)~8j>alreXtXMPvGX;`bn4Lt_+WACknq2-'
    '^B}NIHB?0!!4XKj+C9YE9}iCSI!p|vD6iqaEGT05lL<yu;6L`ltn-I2)0knI5af_Z-`48UA)a!dt1(hwdFN@6;E2WX+FtO|ci#Z1'
    '%>CQ0vC$ko)Lpsfgiyn*o{FmLMU_dlvw$@1OC0d~MG-l`Zv+kXW=1!K*H|QX5nQ1qKCJ6`>{h>7<NzpnfT(pW;$hHaeVOOALHh7F'
    'xDJ@FH0w?$5}HKwo^u8z_c;6)@?X~-i->q;#~MbLT6b@v3q3|^Klo#ZehQPAg5JgB!v1FRWNE(Hen5#(W6+$ST)N~PLYUoXeAJ?A'
    'oHP7C6wgVS4D(-O=Lxg~J%O*bFrclp754y1(`n*vk<r_*S2N8Hh513!Kvpp2rh}fJ(;xd=X!$gWsLqsA5;wcEX!C*fmWBz~XE$(>'
    'cII+OJp+NQGZQ^fv=RP^;O?!Yc9wLxLR~$=*l>DS(hMvL8>_)WqnvJS(PX1!#2Ad7-@O`d6K>_==E;iD$CGvpY=8}NyT6TP+Nu)S'
    '5pTD>nB)}O19YePovsOF(^bk;ApTGdP#hsrknc`0?b;w3qTpzYK4IF1{Q9XQHFPQYKID*(*@Tqg84r}T@6x2DGTOP(HH($x28rN;'
    '75-sul~F+ue;41akc7RNl-Y-3{uCw`Ri#+Zs_N?E4e>D^C*Hrhwag4NC}{FK6^{l=es5?lKjOms8x*&*DM(~FO9W)~0@y4o(eGAY'
    '3JN;3a22#d8TGs=pUdHsEjYcz#8GN=+&YFbbO&<ky$n4B_Y$#MF>=1<uWY+ma9#u_1tjKGk}Af($eJYMHazz>UFzhNk~791Stnli'
    'PafXr%Oh&Z#qrfCRWF=n#$L&{xBYv6-RsPMe`nU`2kB5d=;yuP7_|srrwDMc0#<D3eZV<W?2r$P>E8b6hZ*7D#=_MvgPl<*ecOv;'
    'uBzyZ3BszLcg2|P0qj+*l^hV$uGcVo_cTnni^pDmP;yQJbw&V9IWOMiRVL-{|IE?q2rU1*PMey>eiPWp+d#b51GQa&D?yb85jqVw'
    't5E)z7zdCB+``W+lb2D~?_HI^lIJmh(pn{@Exq|MzJJAxcgnI~mifj>rhK~dla76oEgv&;w%~UJn8i%{<=_33KpIh!Jt+uV3xj<r'
    'azyh54*7Mmh&U+$`4El)<AdfzcdUWuiLG1J@6&F>ROD_MS4xH!2;gf{I|oiwz6GWHk9wo%8nCPu4@h9MWJ}zBNa<sa_nzgHbz%k6'
    'sOXvG!7><_5tTaK!>&*Jc&#-JSc`})X}8PfMgU&RTOfv}tKW*yQ$5ua-CmgwU3NA$dtqN4m(r0t?y%il7#T*cKU`MuyqGLxZJsrI'
    'bo>|5x2qBJf5xh2WK?S;z&<-3a>GQQRfo0Sq?@fuhr*nv&tadtI2K1!e#1;wk9BfhQOzSP#p@AzYa)R6EviMPXYPIb!?-UW!H!y%'
    '=;a7Cn7tq9{X8TA(1H=L1_LRY(!-v>SN8a<7E>vdQx1}vWzXzg05Q~4ADr3d=!}_`mY$g3SDZ0+I?<RFaD=A%3yigLHV{=|dv%Bi'
    'g#}CT$2YS;7Elh{$Q(Nyd7+kSC}r7BOfByAbG}Gp5{P4;%ptU0B`VTAs9SSu)Sp1(mg1Ry>{g`i@!9*brJvMHl+lPLW2*n`7NQf5'
    '<;TMIRc`o56s1Jv9cq-zXmVWXHkxdfKmobdk>A&<$XW420K{@B44`&w-EhV3fBumMxCMM6McUwI<{{mn@5%H}=xq`03O;OyldSB6'
    '<MbI?>-LV~-kaFBQdXitRd!{T{D<JX)EiesmSY`eUiS7e;L9lG<4>DjFE{SLqg4h;yEqZH);rXCWpjo4#h;!1bHFV*ZrXRgJ8f#V'
    '1#_Zyw-BO|?siM)?MkX~P5}lV%iCFr+gPw?KHDD)2<lte6o19Qq)v*p2|iJ7HCI{w&{AxL!_f!gMw8r2EUWpMbtH{1Lv(R5?T>dR'
    '6-Oy-4fvl3*+3$|z*C~vQP&7j*k=t6Q$xIq2sD-j>+^EQ0_oLh<C6_1?|z%4F}$C0y2Mtsi>GlF&pNm-VIMf3@~ab&FMx-U*+z{}'
    'YWEGxtchZuE+Rhx;;1&Rhf-$jM-u{F`j#e>_En;{|F#ACl>vWw*`}2}8CLC;`*rqe-&Yl}1J#y6hUd4F=IUa<#2IQ}Ed=~5eO!`8'
    '153|pr%PAqv=13JI)od#tO5V-_p3T3?cIME?@+Cb5jZrY;6zm|G1Bhq9sr5ot$)fxKi3?Y1Y^L7g2hG{r5mXnh~8WxM9oS`xpADY'
    'gtb)wo7HSIYJ$Yw17dIYe*%~h1EQrU+d3ps@CSW5jr>0{cdL6MT^64WfQa%j#zhL8VbT*@ZE=Y~RNdup1cjDDv2A~YLLgp$r4&LO'
    'FyR)qVqpahQ{2_93&XDa9cVkXkcGzQ%5Nw$qGTB4vHhYzDAY-vNNhxQA5<jTnbl=|R7L~KoI8@wtbi{KMd~azHH2a|pf0Ubn)eB$'
    'TWyhx^hz`s-)Wq*a81<bu0@lv>Nei<4M1yxEt^t34{!!5;wOfe1oI&u8j+sa%O!77N~<fftvnb<PD1sC@eJ?<?oMIRhEmTVVWRxn'
    '>;pj`N)<-=_mnvQfxDWB!F3N8`&R!3wsKn(hKh^N<~m{gel`)v!=08e>?r+ajG^lZnW?<46qHRgSEyP=%Y({)9lJF%*|I4yzi+W$'
    ')LmF}Po}>_ufu%u{#r8&wVL8Yuc3y943(N6ohXHw)ZU>Z#J;q%8c{IG4QenAidJY-HG#E8v`!z0wk0tqf%&D~#x@ze&cv;70Jf$W'
    'wT&T#UiMkiggQEPHCEvC$V%}Dzs(392abL^DounTvl{C~g&nsS`bSrMsjiZgzum%d)ZgxU=T>kLj2Oa9!35&iu*cgaahlC1@@x*l'
    'WC>i3rZ0LUn^TBR?GE7?`7#FHb$04h#f$TI?Oa=5>(8%d<9U5MoBv9=tye1Bs>bJ==P;(BfU}Ti<xMdu)HkXK-|&c1XEI)D;{pK%'
    'KIR34bG!K%#D)#PcT@v)#+bPTWanvb<QV9*NFr;Q9?S8$vf_)$un_e&-Iz4XeJ(Y8q^nq-e#REzMYr&<L3lKHgZW02b8e(Ud=#T>'
    'r0<|?cq>uH<~d#*6=?JVmt3x0UPrFYrl!GkNgdzvkNT;PWk&qX-rBT+u1K|PhnQiloDGMtL|qXUHDuXe*i{(K%&T*bMZLpT!JgDw'
    'Xhd+iL$e3Kw2B%~QNilI0U8tweb=7qwE(SXfKy0m5^340S!q}<U!8h?Dl$>BI8>MF*eosvsVj^hN$$CUQuN%laz{#aKj?tM+H)*~'
    'ilr#RZNmJ9dpOL-n34js>~~VSy5`^Mx+ZLn0I{gX*RDaHGIxv8T2XWyEkY98WZvXkN6yj1nI2yo-O0M1c**pJh7S3rMIBIyomOvU'
    '7<$*V{%a;XJOC5tq6I=-pGD+{>?9i|L>O`E#Y%OGXpYe#;wb#Gy;J(9Z(`3%nhIxi7YbgorVU0~ZT~WG@a~s6u{XSqEe`7di;H?9'
    '$ydj6qn>u5;bYJIAlR=Ca256x4rUdy-U>LX?H^;`$9YY5$BxI9(s0a@;D-J@*86G(4ByxgQxtV*V%WM7j0MQ${raq6QSk5A2`>_T'
    'g^7fx`q%a_fn;j%Q#TBCnbD*oiEz-D30|3zN5~Zztl*mKyxpC%AdX}jYsCOF;A_lYW=eZtk3q<dok5ejBRLO!!%v<38Paf_C6ADo'
    '!JSN9G-p-JTx&?YQQ?xm)8%XEF%ad&(4Bm8oJHDJVt5du#`F2+>Lf2ZO@HZz<ZXRB^WDa1QPZj*dgp4OsmOXys;a&zd<{AbyAAtn'
    's-mAI@FNP^kR|Z6jqEVFO3TYAmpg?eKKEBw%OEL{e3;^1^ZA<^d$DS%GyGhA=u`b#+k;V8T;(3zhyTvYIF)*2&2mW4c*DW+CFLOB'
    '+nn7bP>S85b@+CpRl`bgpA2Pmp+Uy>(3N%PgER6kenUr!2b_et^MXsoXzv8RB4bz`_HfbdZ*f*xN#Jiyy0)ifpo6+rQ5qxd^5v5)'
    'x$*%-`be<7woxGFKG`)#JGIE3ie*q~=Ie=houlhCF2?8AY#NhEmq#93_;io?+bM3Fkq#*TT5c{{Egwpw+iO)EK*^TX5EJZ$Ib!&>'
    't`>o|a*I0zepNg|gZKMipaJmfl6QkU4_%&!sa*RDbifxZ`wG-Y>K-V=fmH$6S?B8r(l60b+a+Dz1lCn!p{9|iRKwwb*f1N(onzw~'
    'ddehp3t|#<a+*|9vCZX>TY)7;IAhf*(xf)h25EW-3!S_r3d)GsW8={4ih*ONuFA8xZj*X0>@DtNRHn~S4fr~(guKz+$ZHx>Hb1Ue'
    '$x&Y#vdWq3;72{`Hcge4bW|!>F9a9|wDpjEU)hTf2Qaq}vAK`8-A^GOOI=OR1k#LwB<16*5-jl6di&u|O-7(CAS7wND8(|_6?cm^'
    'yXn=9G*l$|XN1>^yS%QV4GQHb6-}aBMjjfmg;)fEppZTw1O^j0Wg!GFn2b6<ms=qsAFBF9`zj5<`9P}42)U*#)qnDpvYO*2XJ#X)'
    'nqgl?-!rc>F`)kL0bbEGZ4x-F*PkKS<PC8i4>QwB1!!|d!mc29IOv~FPPrx?Y_oz8^r?a+@F!91POE9;KaV)#XRB2pL_h$I1i-d~'
    '(}Rq`dS~jltAE7(yQa6sQfn_})t`J!RK)|mKD-Oy+O!HyP_oG1A}3ZCqwJ+R`iDq8>TT5x8t=VLCiGru%!nJO<qSr8g>d<@_>5S<'
    'X(ILN>_Up}Wh&$W!T99Pc{2mIUvuDIo-Z|6VPGIvMJ`Gl%t$d8<bslL3&?-PRzBlKU{jd!0>1a@vqhz3p{3O6yUie8FL^MJ64r4n'
    '4oXda$s#eIA?((|c=t%$J?adJ2y6y}Df@f+W_sa>X135*-c@=z;m-mjx1PU`-8>T~_7ouY{0bd#ZVIKW7;CpKU328&9kU^xWbdjZ'
    'RsI_<e*o%>tcm&YJOU4fMfzX>eNPx=FWvHtuRTcse}}Qs2l-}lF_&srV-w;Qd`6yBX*VK5uwlXzhAd*5t(MmAKXcl|rL+u_JnjY^'
    't(ytFR`mUx2)6fpoV%wP4ZR&)w5wyo6WFsiE$G=dlGv;XG`a4b_AoNYETiF-FdT8i0E*c^J-YFPywCAeKcHvq)GB!igu)oTQ#G&{'
    '=JXzz8lX=5ex}~56oKp`ehzN7wd4r-SqV=PZ!EK&axTigFpe#3JoD@(Y*S!Id=xqP_xSPK2np&M8bCY~?u5QoZ*{L$U^A$h7KDq`'
    '25>=Uv7xN)zVb6(r_u;uCzR{TqDQeZl0K4^(Xs)YEeGYpfIFKav`{Zz1FlW##!(rwUQyU$uoGcSlOt893Vmv8PIR;-3h`r~F})SB'
    'K*x7kUqC=n)E^!JK!l~J)-vzk2)3e*Qot8e4lB6^8M^$DuJLX<?i29cW(Q>%f1IH}9Zrep8A><nEwwLU85&HGs$y@FhGJFXvEyd|'
    'AnI%#C72@_`BfUYTw&QPRIveh3A3=8KU}^P*hh0igzhfPD+jn<Y6MJ_F4^or;Mf^+n+PRMv|P)S3{7E<G0oKv#>ERVrdTW&I#8%s'
    'y4O5Po3$Q3F&^wh=<e};)zMxY150s&0&umQ3J>sTJ1mZyxd1;R#YDv${G;_1jcN<p(PNQZ!if0;bzMt0JI?hS*3`PmBhTVF{&GC~'
    '2!)>{^OXTI`4N!#6XH5>CI*Y!;@k{H3{MSj(ko|2ArO1lneCzLvI^5$nECWD61pjG2G=1~&Umh4r_YOHt^Y+2Bh-}8&?!CU;EIdm'
    '+E4!KU#ESt!H1QeLoV}XKC*ak7<d?LlV6%FjwW^JCztM^OpM?<6VE3}7_kf<Jjie*etl1#2EsGuMRtV|`<nwMjEyMslEi9F7jLs<'
    'mT7pqGxn2I^t8A&RLS#AnJ0auQm0;FC0wUmzghkQ(A~-APjGHx@7qquhomx4u%G@S!N5vc7p8Ie0TD9dRb48xWR3jsi$b>^0ry|-'
    '<-nhRK(Sf|jbo`{>ehA1ePUuMxpL2zRb@9{NM>R+DfmgpoN7U~=eMy58zdOPnCK(~2_Xg8`0l2y9*nrpE>Lg)E%z(i(ngcv-Oj!K'
    't`D~<DE2h-{<fE~((AGL_(b&HlG|^2n@l@EMD+0*vDhi_$B*8xe-*}z)0dZPV<j+}MEp9(AoY8GJVI@jU`@w5Bkdx<d`^HFLq_4I'
    'MbUjka%}KJh5e=u$F2&<maU+r{@pxWW1J#hAd7sCL>nW{f(QB&bApDnYwG@aQ|VmRecQK=#s!f3^0(PE@()}|O*Z+OqQbUyNPG+t'
    'eZBq&(gVrq-$%GKTKl`0ve8Tnwb&XA^t+1?ZZ8p68%R2LP8lfmn+xacdIklk)EfZ8Gu2Kbk%_*PsY&ZWHQ|m4*Rw{MBo_jk<O;YL'
    'O5qxn=(}UfK`1v0IYcY;|G|{NUotc(C~eP{sZ~%5$<CaF8(#IH%2h1(lHK3;81wOHpCdm`t<n$WLErE-VF}jT`!3AXaDZ_-<SHe&'
    'wQvE96UMZ-<=k)*#LxKR8<L2@`p-^Nkf$rj{^{G(6<MW)+V=IG7mR`CExFfD%(|zhYfB7w-5%F+J4}bi1+)yBj$aIS<KqzqGQ0%u'
    'u~r8>S2N%+gsUjs-@t|-*Eu<QvKgedhzDV3bW#jNSfn~fIle9~Urwjp(tWe$v~Ju=$_K8DZr>W)wtIGxiXpc4>c+g$(9AcH-QaPt'
    'v}!yHgNz5Xb;dPF{S7yD|Mgs1Jw6LKY{6>nk?mFVCXT`yp)DJFd@9|e`5WH6m;w%p@^GJe?A#OTs?(Y<3R&&WR*o@``YlqWo1Lxi'
    '8ieE8*WBzx<>KC+#mfqwm=Px>7C5si&>A`KSGmIh>Cts|L=3?S!4y|_AA5jv1=F>|ftBIR<?JerzGY{S+76tIB)`~R6tyhB;LvH6'
    '^GrXtvsl%jg3sknZQf2*_#yEnZ2z=_q_pBg`K}M|e%SK`#zQPir91#A7UH8qFWP|+qVv+}h5id;!C_llsfz}4e_`(Y=#+}=q|W)_'
    'y&StRGN;}rid69PpL)0QjbVv;mQ*A=fB95u5quy|@>}U<+>*&%a^2UeC#++e#GkjLeQDqORH>ukR{@5CBaVnH%BMeH4is#i%E~it'
    '_LjqsZV!3pv#T%}1sw#s!%CPgo#O}-qvZ=l+qDM63b|0Lw^aHqWcGod2dlwogN9-W5~jo&pLS#iie93Sn*f#KG+O6}7#n~!j(z>='
    'LPtp#prpP<+v$PGhW?UEY?R}P9l1ixcTrH2GR>#v+DGMm4^>|vhSJ*ncJlX8bitQ)H32F}E=s5+e3~lp$q{1L&KP27PdUh3YOqgK'
    '6t!a6A{}we8b+0lDpD2I-|WTX+nv8??#)cV!u<pPMdwbd*&M&MEXlsz#kSS?*eWDzKBjp9exVzX(x*u_;KFr=)huHzm^+qJ7A2FC'
    'AtOb2@iU2RgkQV{6$e*N#p}aC<>6D+LTFo{_?ba1Xb^Hq?rmSh(P@TMGp#Y2X@GY#j2E&b7cwK`yTBDuVCuL}5>*a`zg(cVfhx$W'
    'tXK*)%1(X|{Y0{BuQUP)9j-YtP#}WvX5jAjS|DinY?{?%NNZ-+wXMpEYl{uvY9Kiavp*@f{XZzp$;3p;^S+ijU<xikIF>sUc5rtP'
    '$xw(0Kcj`ZvFwm3M2YWA`T-2dk+6>kZ`(Ps82h(G2HE(%8CmNx>zpbPe0|+eTtunTME?Z}@7gBoW%TMAd-H)yq##YvPz2--kUfn@'
    'ddwH0X{OR3sI=H3IXQP^O#3-yvVrZhFM-lpG_g+LC^=wGt-fjx%VD!wDYK8h%Z`=xyJV67?#W6g#fCm0(3h1{)pd&M^XG*B+8~4D'
    'GoJR#DN^L3Bj2)5gQ|a%Oo^fJebd9eqLq(cA`42tu~_>Nuv)sI9UaS?hDFxubhUHq#KbG4U~E|GXr5l31Wr8tW1Ua_X%pg3?FZmt'
    '`UxQ~yZU6-KNMV8$nxs>fd67QWZsEBoRF+k=$&#^gTGP|koy&YQj4yF6$8R$bRKnX4*V8sNzm7;#S)?9L?im^J!Yrfp|N*${7B!+'
    '=$Fy8kPd7LPR7_r3H=skPU|`c;$cTpj(ZR_L76mU>@M_1?^Ka)1az+*k?Y4oSLgp94;t?bsZS3N{s(PuTBPb(=e}b_7-W?qM-oSO'
    'lIoXT`xoUHxQ5zhfMN8MAMRP=9m4A6q)0pnu14vt{e-W<8zX%0Eg6pZjxps1-5m|uqw&Wxr*`sDn#wO|H3d^m^9p%zcm0V7risUn'
    'Cbucamh8KUCNIMQm429(r@Gmsu><SWJ#^m^)5w1Hy$S-An2KtkC-Y;Ejx3ia@m4i<@*T9d5OlY_;Ty==fFQg)M4%Ph^mZb1_+{A_'
    'm-0xr8o}~VE@H*CM0ZRzWj#=RkTa^@yIEoAif3-Xw4AkcpvUWoVX4xE4of21V^OA9g`C@_z#2JQ`jhK@f4L#!VwlhL0P0hl=hppA'
    'h<T7|5~LT$|32FrtrJ_(I|zv2C)?O1wKuh~A4)2jo5UlAB{^m+DqU&>^*0cvKw;B$0}gT{drU;&NSmh~!!f!8XOE*6qk`H|0JLZ^'
    'e$cGn7dFMnyZ84x8$YrZNI%p%=hR<bR{%pA_b!6q;ck;P7oi>T6f|S2WM(a`rgef_E#nhvxZ3e0H2Tl^V3wpr1cvE9irJ<{xNrAk'
    'T%oJzSI;6XiG%N09JcN%eiP&a9~g`lcjz=Q0cr1b(GL&o&;%j1txAtSCra$<X18;*iT<Q|yjk-Vv1_yXsSpXe*umB=V_O`#A!T(V'
    '&zeD|OZckrbv;19BvvF1#oR*G(f@nKcCFR8Y0`eAlC72P$7)7!TXxaB{Hg*OdT~gPWHUs*P>eSQSGtO|?Usk>IwuLl1dOM$R}|w_'
    'dTt6Xl+EI8@Mhcckl3IPh3{Ourc=!Ns1;5RVZH!ptY;Y)XERBS_rYG(ISuR$EFj&vxOp7r?$k-@b5qVHSv(v+Yr$~_H7M?At>WAF'
    'I#F})OkE;?XY%JbON|;1JNsFM8?^tZ{9Y)CeBBZ`{r={6oiyjur6n;cKn(+pU-GAYsI}P~U(euYR|R20&eUO=i07|lS@G%JGPDDg'
    'O7)L4Os`g<w(NJKyLAm4mdm=-=a(CSts^vnfLe>y2SkyzskgwF0IFGE9@{WZRZ-JnrPUm^Z};Psjl8)ZxI7~+K8@mP2TI{d#qe5D'
    '^>cqj{?G_ng#F~3$xv_AnFBsA^6w;M!bAV6PDaZ-UkU9oDGkHyOerRU?$|9&4A2dgk;amiHej$Ww`7pZBG`gr9p1z#dbCC%AS}FL'
    'I8`^8uNtJ3w7KaMeUvVne=!$FMG^Ekgsw-odfOI8bgs3?@3?J$g-k*SO`<!0krptzsb2}{?){AIh&)nS-S<fozhUABY{knOq2s?r'
    '6m#9ItpEAv`JM@}`6mHqDH6s*f^DXaN8TbVK^mfDpP-y?yCAw?oxW4*oBvrd?cA~o`Xgc2d*)YV3t0_BG*_(1<vt5o-FNGmTaa7Z'
    ')<SlJC@ZloV|S|DW`Dv+r0ld7`Sde;DiJGQxP}CIUk|S<@#q6b7w>HJEO(%tpxy?N3&(+hy9i;?8Io(XMoZ`TF98%LVK-+9{4D}j'
    'bAJn?3%L7XW4eV~XvT44)oeu^i%_X+tm`?9xu-WjbeM7&s|!Uo;I(LR-a8-S(Gg2M;V2F4XT2C{%=XOaPjoGTPi^D=x#+}t$jbD3'
    's`gEwEeq<#QXH+(4^@?(n*#Y_)?!c>W<j7A9L20F=W&Zuvw)e}sS+yaPiVt1{bzju*Kzc*eJx;9fmS1+x+*+bh(`>Ds$Qhm&v=Si'
    '@ACFRg0Om6zc#N%cw~g!cgFXMRt6S8%}Zz3$8sOlKR4{DK1EU2789gUEnJNoRAJB_Rqn31p3N=^OHyaemNJ*dU5U=)nhKEUw_-^4'
    'e9mFb0O647L4U{3sk>SiUdy2bK<n(Zyii!B){`=Q*9N3MF4~LM%l`<3Hkh2n^9+Z#xYcDyFr&kx=P@=xa7ZvDSnpF;6!2uKN|50Y'
    '$_Ml=I`}ADyd>ouE0I*CU67M$dE2LT^h4FFT++jQEdc}??l@u{ljpPMfH-y|!|j)T&yd<c3{U|F0|sv5NHLrc=Dt@`+*d)-SBqNM'
    'V}V9GU~q~#Lx}AuNR}$%TJ3wzZ7vH3?H8yb?{3cAmM;YFT1Ajebjx|c|1$8=`}?|qSJqW!u#sKTNT!8-*iV}AsNom(<?K%p^_}EX'
    'a9wPQ!w2W?FEQEn0NbZ2{*m`uwY;$nCVPs26ExRXcQlAKN}4`uLVqnCI_NIBU;m6>{&Hxqe-%x4WZL)8S(DEy3~v>q()PYL41rtB'
    ';W3zZhUWwG2RL|%C1Jz2%_a*~%{fnCfRjrg;EJnhuY3NEpd=Y)gR{m_;x5R0ocsCZuV;K?H5-xWSJzY7*w-npxpGor+@XM6ZZI8g'
    'ldWdhFIoi~z4bnd1*&ykUka#~!3|AEPPVQAvrG5toA-CJ{MlD)n%jbH*fT@-KhMPr|9#ZD!!f{_@KC6i>d_Z|vkvb8;2z3<PjXKo'
    'A8TT=8ugxE-LWYZ1zgQKOokJ@XnYb5Wb=P2<7qmwn50nl4!_i~Yv$TA>w&!s<v!TUMn%3_a0H$o8Mt=$!`T-UGn=qp5(woE?0tCH'
    '$vg<D$6bxpYyb^!ZIMdQM8xOMQK?^Mh0Sxr4G>QBOV`3LfYmBJLi!8U4>eZ@=ji3PX%sy^@!rMB_=5}pgHM*K_wrX9c}gywsRK-F'
    ';4Yr$w0g}^w%28hxsgdW;cMxf)JpHJ?djt;Hxug5-o`$#_6zNhtcfqW9l#Bq-Rc~kq%yN&eZk;1@VQ5-vN?iiydFN8?}5ej3Nu`T'
    '!j=-#^t7#-#qT}NOgXo_`XE|AUDnzIC-`1WxM_-@Pr7z4a=}GuZuwC=4>nQ3%Kqziq1lHMN+GOcCem~={X|O{Xh%gS)cfCSFS^<a'
    '5?;r_rs<_Kg0OcK7Kcct+BEtFIrzi0VU$k!1f*#TVbw2rvg4te)!}Z%PR4ZQ=#c7qrhj$h1Z79Ll#(G8;=f_QQ?rjJ%$_yD<V;Ok'
    '*+GbTOLNq>nj6s%O+n-W-+J=5QqP-8l;)OykxZUlNRR{wX=OUzL2qr^hx##};w{8}%nPc6n@$PMZLfG(p^s(42wRGn1{=5(6cIQ+'
    'BdGRMry6kO1d6U+N4_iYJF$ag6p`N>rF(RR!?SB);}b@#<WhXtIZ7PMvaxryr$P|+tt=%c@~gObY(b*Se<gS2FFVsik+uVY<gu{8'
    'dE`(yVuEOM01fU(l;_ZZ<Vu{JaujfSCujGz5M;vXTtfy;Z+dyCocJsSGt!pw>Ok$q#5(@o;p&C<ZMsvnFHTuek~y%9BI+|AKJD+#'
    'SaZdh6QwEIg_?)@-zVSkb$Z@xLby{h1@*oKu_nkUP{VH~Gjj!fLG_>~t4*cZAl~sY`i(nFR@TlS<i_TG^~_4?=U3b!q2%`y8rc)l'
    'SR6E10^wn(A}tb4q1M%Upz`Ud@sIw_Ck{j_3+N$!DpVO!BJ^7zdY>=O6ER(yB@36yD9!O>cFouVSr?&sgcVWV)t&oA&)YazMBPC-'
    'GR?waD1xKiE<;9q9jFO^rnv0JvD?8@PWkDlvgHmvk46X#Ui#eK`#t(ouAtnZ-KB^6-h=2R9DtVvB^Bb@+xk@{1OjK7UL&C%MoepC'
    'MMB-1O#7`J8+|~M$K|Ve;&}l*Hyes-)7(OH;3y8rSKcJ~xt$(~1|wUi#6~hW_37=?ca)ADf9K0P+F_4ms+r88HZft)=<4=pM0s@%'
    'qt~Tv_@y>t`N1eGLn!<OWD7{?CfFA}2m2GZDifH)dKT4RAn+1~s|_7pkBfVvSH1TgHD2$c7QEHN>DQ4B=IcTQi^k;uhdx__i@vt1'
    'ew<0Ko9dIepp7HS^AI0K>Gb~)Yt+<dupk~yi8rS!Bp?uAmrWbxRj>H(m#ryy0k1vBxo3iQ+YdH^@Bd(6J<n^2z)M)7z+t)m;cLr;'
    '6}2zy=uVNyqSbI)%DsVN-Jkj!y!lr7NadmG$hvr|BW$f>4V3WFSOOX_JH$NmRXM9h5XYNDh|rcUM9=zV0ienRnlrw|{Qsc?^^08T'
    '?%t4P+dmFe>)<d4N6eAOHgS|NUUPHDD1m0+6li82aRbJKZ-C<|gq2{!HLRH_Hm|m;vH3fIWN8qHQztx+V^X!ug@K|p!3S(<Zw2re'
    'Yf!xHr~bzZl270;N^vCD2WM)|O|<&62Lno3n1<01&eMARRzLo$N<FW$BBT!Vy%SLI;T4gknEuQt?;HsS$nLqh6QWVO%V>9TLhHZ^'
    'W7z<6dt+m4B5VNSj_=|5{IfAHs#EFO#mj{~0AC>0n!ng<-QDRY{CH7V>COI!L8j{j8lvs&x%I&=5QBO}FjuBPEO!nEA3p;ImNd^V'
    'RePa(k?^Q=Ph%t<g~dhq4&ym@X;(=>;4w6iJD)V#scJ6zh}%dwhPJ%74{u$x$|4kh*AAG-cC)B1#g!2jE$Jt_9&18{q5-7C*5CtT'
    'Qyj)J(6Z_o?{ml{O%wdKC7aDE148>R$Y!%n9~i=6pP*fUj(eYtVCzyS{f&;X7iM*_&Kr6H>^|SA-%>9gj4^%h0!>P~K6f1YVmZtk'
    '^HZFkFSeV2herCY-k=&Z%24Emx=P!pawwL2d38Wn0={HxZxbbPWYd#k+n)RxDeQR464y+b{e92$kTNK;?Q|b;Ct$Ye-Bj9D#4Iz9'
    'b9V27-8K7$_Tk`-yjITc1JcbAP~_IfQSy5I$lgXA$(nCn7w;KHr{4Lh5wZjv8(E_et++v-O!o_Jn~D#|%MpM}S`9wx;4}jbWCYdN'
    'TM-_S4Vyid(DviY>b!F|6xHAUeP`Krqo)U@<P4E4QIZ74E-DV&WSoU?MMCBic}?ijL~`9o!Re`0;c8s>jl*<av_n~(!WquOr27MQ'
    '2e$<Ne-e%y!aY0%)W91-|F+K~L#%no9^3)UeTyi9FyV1dTpT%da!nPcEjctdF<x$^q9F%W#g`W&EEiwAZp&3FTwLuxh81$`oQtx2'
    'OqUbXD=d1ZhLTSaMMT|T1nyjmGRRgQ^y-sSon#5Oj-8ti31D0K1L-j}&?c`*%R(eAx0dW|n?hD?IfCZ-w=5qBfEKlUPc7Or(QQ0u'
    'Z|MezC3b@DgwmM$u957eJ-EDiV0n|!VetyBd9ryF+uQo&ND?d`0I4h#amalX;68odNe|uDX*+ON7nLBv;x&z-u9;DXG})D`j!Xbx'
    'g7x>Awlxv$YcE!4vbJjkNdo6D>~kmO*V2IJ;+PYlxXxzX46pX-zNALauRyD&z^nwmfNFu>EW_Q!k`1oFSfbqeoUNqmTV!D_x6{vV'
    'tC38P61Y|X{t=9m634YC`7}$1+JS^1KPXOwRnhVNtWu+cBtB-QE4u4pGUBiS!)epYgGNEd00%T@oRu&|*Ey6g)XP6?zP9>~=kfb$'
    '@`LT#i2&poZ9sST^QO_jdcKlw6UE3lbg+h3jkOG*YL6A=+>9ciPvL_0xWVea1|?XTBr_D?=~$`U#6QK{aNa6+V|=UTwnVn|T3><G'
    ')kgiaHQ{XBRwZ$vD6f-LPF8@h5aHW=jk}%l2uryMVsp)-jNsRic$+s?n<2d7Y=$n3<SHyYC5|*dY7^T3W%ohIgC47?Y)Q&7NKgq2'
    'Oj5cP`ZaOGb#e46fUG6m6h*AFK|`7s#}m0wY)4ukZ>g;n6XdsBou7z@OH%;~bcGq{W}rIr;`Brzh0swa{(0pH`aT^#{JnK@%^jWu'
    'BJt5q5(Rf+R5w}e02m#Iz1uX8LR6q3LSS1c#;)r-q!{FW*6-S4iScGZak4WUx5s1NBe`Yy4cpg?tq(l1(9akkTBy}ah{uv*7NY%|'
    'd7g^dVUCKlXHcaqybaf~qUt*5!(Vkio1m_hDuT<V*n{MWOOQ7-a$){&3Z#)NG;c7PiP~vzP1tNdFq8&lcTnxQUx-?~5yfCrS_0Dk'
    'J4k_@UAcs1^*uo5zlA%}1`Mf$S|<$t!;7su@v7?Qa;n>Uil1nIxw#`Ku5Gl*2}I<iH)SKgVWr{RSLWwVE3m^zna3GSt4Hw}>eRG5'
    'gv#>02^subNM^XL&Zh;c{}hVEY@EL*^sl%t$Ej5oc|{l=TfBrSZ()Xd&j7W5S*fa)L+F16RM-T&3g2@SLy76j=+Vx6PDu&MpP@-('
    'GGOrmk=E9MfD^Ln^Z&fBmIV!J26Pw<oj3ll@|~BmxbvDsuJ=Msq<f4LUt5b2r=gi-F{I8dEmSwaw8m!XnV|Aw%y8idy=-2G(s?Mf'
    '^9>{LLG}b<29xTDU&4VJc;T+SB9QWb+&+4reI-Y}s7|U6SFn^;CE0bU$0h_&M_?Vl^;)IQp-V8#Q}%)H3*Q@S#h+iWA<jeg(Krg5'
    'ZiyV1ydKD|7#){&X6m^P%hw}~?ODU?RvR}nL8#m`^`R1Qjx>8Z?*zgrU~u^cIXqW?emh<<JoOnErAPTq{cS3o$_c!lOx6DsVSqYm'
    '%6YAU2s1d}*eQzq?zU5UC8{`M``}Rmi-eBfBMUQ8yEJc9m%OH^eI`qM8n|*7;Cn&Fc8q4l#CaLb<V`y1z<G@cTti)P<H%yXD+I37'
    'v%Nu;h2gr~jV;p3$+j2%+GUd{3HU|+WM^WnEM7~jfm$1MC(yjdou#p4Gz2NrqsPO+T9J$2a-4G4H~=X5S0`!_hy&tz7gwFS7s?lh'
    'QVLcZw(;=xLX;vvXVR(7O-I=k|4NW<Rt3MR+0U>!2AtmRRbmCKeoHKy`MEd1Fq||OBp4_chuRq%h)!HN=4vIFgglONir`1$)rx*v'
    'E|8*&kbo-HkGmN2xj)O|+4J#(t;{kpie}++=97{@G_vf$p_=PSy--LN-BD3e+%!*qEJxaZ@~uD{q0VYhNCdTveLg)b%m>Ak2yrbl'
    'NQAg$@6R{oif$AX-}Xt5N9ywS_jaG2rJAgyz=q4XS0$_{k@uqbE%5i|n3^)lHQg^on|nLpkUcicL2L`s{0Gb#2uK>f=sB1a*TbU+'
    'N3skq=?6E)SVjrsO&v|J^g4nL0H>yw@(!YI^3JWHQho4Gn5?Mm2<T#12fTiM1Qr_d@|W<;3DJxc<m;GOs9=cG4@krav-@W|+#6y`'
    're^aO7G?3bn+OItNOwNb=b52b)fc9>YN3|1sK#c`(m1(Ry|l4(PwItecmGhoBKc@w*^@ibr1E8uE`Zh@f!axzot!|7^@@EOGl)f8'
    '82I^Z8q9h8;Dj^zcqHJO^MMGC$wotSKHVbj5zJBft<=>|Z4VRw_MED*XfJt(He|JUA94PjmN1SwX6V(i{UGHguvOwf)Pz*TR+Ycx'
    '1}KZg7bqqKbDZaaDKE{3owVmh2*4sAyej_&5ar_W3yB7NkdI=MX0^ysj!m-wT_B^RXt4_CQ{u`Qv{ZaJ2I7S8upG&r9wX5!3T{;K'
    'J@LN8WIoFNGbA&Xu0F2S9Rw8wQoH(FdSg;olSOR;wMGTsx5FLmftm_a?m#%m0_|YF5Sz%VhWKd$MbdvghCLck-URNCvPzl*#JQ;e'
    '&89B)+NpB6l6&gXo2Y#<CJO9~+HUEh_L=yjzF}a#@oNmC9JCHEt~kokSx*Hu5Bhrm6hm=PYi8G+VmhY&)V`t|oEvXM|MCW*1%muI'
    '%#R4U>u4zZ?|{_KOHAZ$dqw-R>TXkvi5pnrI^CIBC;h?td@&~ht`kJ}3r<RUchGxJDt74EC{~(9YGbxN@zTmgqtC6<YX$@u)7wdE'
    '^icJKTHptfLaka-SaZ)e9wj_*hKSimr!-S}e95MYv}vV!929Mqm}7-90agwNrs~I8=$oPxD!v!_HpiN_pBmVX3&u4KSFW-}yZ;5?'
    'x&YV(0Yw9oQ8C?-&sU|f7*1L<JrDeC%(ib|86j^D5%h|}`4WSr95rEpk49eZ`zoD9jpjNTSIHo>+f*kF5nyXatmfnFk6k?UILuWq'
    'wYq(mps&PvG7e_{P@_3D!|;Et0o{&P$WdhvQMzET6vgWip1DZJ7qc205CJ9KO>2QphNmIVsJ$*Rfr2WFk+2R9mpb*lV)tpab=Fxx'
    'P=xx)#Q6*VLynMw9FPCYaZ_CBnX{pF&s*5~#`QZjnIaP+g+x;44h!G&z-P{!`RUFHtu0km&;XyrH~7Z35hiKEq&oeQ)v98@KR!r`'
    '7@0ozuUj(%5RB~{=S!Cxl};M2A=|?9pkZO?saNtLH`X&e0tl6qSm@*)OXFgl=_0l(glwLBl}SVNM_eP*pM|s59>$YGLpZn1MI|r0'
    'Qj#*cZJA{d`Lco%=Hx<{R_#xNTk}ORD~c(xggmMqy4~ygcQEA?b16`o@vqFc{EwUj9tHUVt;~~-=d(Tym;_f=MQ?GC-f?ty(MqUJ'
    'U@Wl*3Zvj}-Y{&RgWoCST8`J6zmqQS<EIJtUM0gZ7S)8;+dc&2GWF`Qm2csd{mkP6Py0TT!9J7X+?bm`n3-20Nov?rg^<M21any{'
    'w6y<A`#%%aITLNRQ8w()U_9mYlhlBo=LI4$wsl;0)q@IRumhLs;>5dkFu3L~Oz4?VfKos`bK>Ezh{k^CT_DxhBFRuoIBY~=nwKN}'
    '{_=+T_436h&iX>XX5F=O(g+8V#;zC6mYL@u{ya0z3}I3u6(P$Fj=n7&LBx=g5Lpi)iDJj*6PM@)cflTN=Kev!-V)Qbp+yS&47i|Z'
    'ij?47$m*R531>YD24MH^w~;{rj?NvguYp3gNsOaNpsl6vs7l@5O&vv5LsqYo51o*SYC5;&sN$roErOcGo>h|=fN{AiWxKFTy{X?{'
    '4M^sCvfapM!SH@DDoT-c_@o$j4e>4w$;_;-At_gxqOBD_OOe9d3OggDBFNeS%+^M7S;b8K+e%K3<&#G_HaE@<?quujC8~wSUF?Rm'
    'iLigZ7mol&+Lh-MZa;Usz~wcy_o2u;4yFvRb(k<<xbejJ&6$7v!D0Qo;&}H|kO&T$j|x-)I3{2Wei#cWP-Y8^V;s3xc8g3GUT<bP'
    'k$Hh8`Esq%npTQ<3JP2PEBRO~(a0@;@k?`fZL+wQHoE~snhiKgBVHcR26Du~D(OQNtoF%dogKHz&lLQ!0WV+CIG1a`t_S|mza^Dx'
    'L1ZNEgv0m=Ae<MuJsJ~Br0ErjqaJA_BvI^`M7e+G91fTlVI515MTEaW0mcxXh;r38X*!VhBe2Hghu_UJKo<8ebkr|;<6g_hr2>bx'
    'sz=$%Mj&gs=-Gb%-tpdW<Coz+<~Hfa<bK%d@8b~CV@K^ma6xtFA$9<Ucesz;3V|vR47L1H97Zg7!rDls$^$=o&hFe1`;g%bmVzv?'
    '*8CV883vb%K*M_!2tId49bGHt(`~X0MD1|Jq>bmiUwNQNG#C6L(+t%fagq!ZjVWC<!FIePDid!$zB1LXxl16THS@#wann5S7lDL5'
    '!mYopm$|;IDAos1nKGinLN`fT>tD{jeQ)l}L$gX<90Hq)rbRO|u3`0~jF8<o@uiBFDNliq6g!1|voJKckL8ih-=J;nvOb4tshM5?'
    'MwoY)kRQj_NW(7Lz=)eKP~Q4);>S%qh+-0m-^%ai`@h3iK<EOwf|vaaFu^s){4)?x*A}VAi%6N>-Z9#gf*fr7&sBvBFJ^XLY));n'
    'tw8ahBf3q7`<Q8|{0P-_PN+-2FFVR`EMq*=`c8;Nw8aEIHIdC2VOr~mXV^oV&9u;r{F@q?Z6qPNMk#n<o`?P(e3BlVH*LFNBSBP9'
    'g`hN>jYEC9)17*nd;%O8i@}Kzdi0q7{AFV6XIYsp8{{iWcRa)&;nObpxr@MP^I?|U*#8Pj$jw{iH(JV%lFgzU@$3N+IGi*f`n=3Z'
    'Q^ZRqMJ{3vOKv9USI;tCPRF?7ARH_3p|0Di{eZZg3tb{xQ3U`DzFU3X$Ij8<8M!x!xiTn>aN>58?evh)@n3jX3^Pr_tIO-I>f#Vp'
    'ERK>V`Ha|LEO7@%$m-nW()uS+qIg9Ya@iQiln??N2w4=J<GCF1B_DsF%i7-m0;Gy-%I1hhsV4$@^Qo$PRO|{$$LaWK^7~YCm)y$N'
    'npk*2dpj@Sn?>Z7hrnTMA!}#o!$YZ%8&Aj9`g@Cgq<92?DW#>c>v#>~P5S<KmX$H~d`=)H<Sc|BJMRVtd$xY%Rx7rzeD;`W<Yx>}'
    'M88d%t5u*MmtXAx!kw8uyvCM>zc7$^<&Q6&7D2AT@cNANuiX04U1CJaUw#(-^35PP5C=NV@BJzE%~2&yoFDz85iiu5Gw-CN(EyS('
    'P@9zeYfuhU1cL;76T>(-u)cIp;%OLYvsB4JS(FUk3}OP+CG<Z;FIU4_(cGI75StzF3Q*sB*J$6Lps|~V8eiNFgc-(Gs4XG%>2N7;'
    '!9d8kL~`s=RvTV>#Zz}<RGiPIEvUdda7G!aAV?$Cb|0vQoJ8Sz2Jy;FE?+RuyF)$6{8YdLt1lr_lJ!Svw7+^A6Sn?0=VCUT5RZe8'
    '#s#QrO%gnHj|%=TAH+(55<<L$D2gZ7OE8hC`Y^u~vqi*#=)dz3b;;^7r&$k)1`j1mUE)iF{WwnNGn`W%B8(7Z<Cm)x3Gx)@mh5(V'
    '%_K<EY;FzH-9cp*L7Ib7sVO)<Hs4k|G=i55qY50#0Uc8I+lYxxv_E#Y2ovxijPL2#k>lVm3#O&nUm#T5`hlg@YoaNC;B>4&f*vV+'
    '8Jq1pmv{bTUVcmVG$5Oy_W0bCF@+Kx0-eBB$D{shYGHc?d8TRhe%ytyewqxaSBg2DLg)4_Zr#s#Az~n&X{6+)QOj$K>16Nbqw@(6'
    'Dz?YBqZr-&-NXU111P}c7%w?KnSs4!U}uB+px><pgYV*eH*K|WKla9REnSO{nM-i>?iB`paf~mooHBwZ0pRZLi&F=^u<OIcnV$;6'
    'T>yx^j1S>`3f)&!kAOjvjP1pC``Zh17bp_z%vs?7ix*TZllMAvUwiiSiPT@GL@7=zr}zh==@<_Gk=KfH<GRDG7t<MsqT8Z)t;N`V'
    'mWY`W*o<3nq<hsTe+ih4jbYPi7|aT#$ZT;gO=E<pP(mf?yenjacm4H-V}^H2WnOh9Z@DEL8@P7MtdxZc-X@u9ZLX5T2}n^P?c~W)'
    'cib2AR)AIyV>-N6UgZPLnlbC^Y78m?Gl%xeor7;$#?wH3KwY3+r*hT)YEw*$xn&LSzVMm|HOSelE!eQ|nB#Hxu}uv?G5kFQ(=Hy}'
    'Ik*xikLyFCEL?CeLS@DwXbk!BRX26DHGs}fvM0NgU)!8d=xYJJdF71%IP+DK8!WeiE}(@gy?)kHkw0JhTy%relcoch6l(x8i5kvv'
    '{ymL^;W?kcQhT~`gHI%j)`z>VV{b}k*#Kv8zhAXAB-Tw?AOBLNY;rRFm|3B)Ghu7Jr*g!8UhbB9VmleuB`;9|Dn*DbNSn<wL_bW;'
    'h`r;}{qBI->Q%fGOhtCw6*|flv>agglB}}Q@XEhM8Hatr5wFp;9Z@>_+w0dU{jAa1qaYysxF4c9WdyXJ$08h_Wutk%5vPRex+!1`'
    'A=4Q-h4OTL*)So&MjF{UJ~N#{>r&$walOn7tjbW38PX>fW#}nCRE`>ke^Si_RwjP=f?{3QQm?@ZtRAp|^?5uzBro+nozQZ-Fl$ND'
    '^I0m7n5Illzp{l^Z9Hv(5GE-+@YQ7*mjPmIOrD_uJbL33gb$JKc7C67J3MOI20r5JXgpDV6F@w`4SYBz%k7Sf`iI$CZ^sJ<v>ZdD'
    ')vgxUtHK&8DJRIa0LZd-QiQkjI5`lMQWX-vRegUIs{`x>x=a>hZ82`p%%1@6{srkaFqBFaLszly0HJ1$v6>Ov4u))FOiS1`%Qm8v'
    '*dtP0eQ_&u2P82F)dfm}<$4$^6BBIk)USN#45X|b#Xgr+oMk?}$cIJ}k*qW6Qf&Ns(xqZOh54*V3vwhcbP6fqIjs(oaFjeJuq_uQ'
    't~3D#9-IGAWpeQHQ?&v)u>?REG$nCAQqlQ*SxPZdmCmvB)=k+{a=6iIi~~>T(LT}HmO(&Sz*3q~L7QO=t+TJ%vKvq1Zb3=w{rtd6'
    'oqB9d(h+A&;ZB2(3Xy+f&&#zKZz!j~)kO9p*z1K=ntNz&Z&<Vo?YugM?gT$CABP|Sfp&PcWsn{WR<|e>nYCmq`+PVz^BsR@#?`lh'
    '&BDRfa9T9Urx`sQpQ3M`5|&7~<nlg!N-lw=TJ<Ug+|X1K+--Azm*&7~&4G9l#!XY5&{L_ZB9re`+k$bZ=&cLrXV>MEt05hkXw**J'
    'K?4v4jBEWw{B7nK9VM_gTx9^pK6QF2OG5|o)@mEwqO;&{Jt%$c=4&1NuqC#Tl!_w4IhKuj1?K?zYICs+PcsA%T9mv0=Qw{S3ow^p'
    'Gq=8kKIe^}b)<Zkk|iXy89!OyN~OzE$L-eo{scJM2vB4W{X9=39e40Is9s=kwB_m%_Rg&9EAHVAJ7YWs-%hj0i+i7#;Vj40#@pQ%'
    '_qfqBjtT1|T#G-~1Kd9$^tL{%-r?u4v3SzaWogR@(lhH}IhD0j26~Dleo%Pq!g^3XYEW8k)H%Sgloy~v9s@!u_|7!!oWYMFD<>}9'
    'Y~kBs58;>RrDI>+rDX(5kdbnh58=pY4xXT=y4_&TQ)a3U7B?`N!;6hNjj0bNp^@Y}iwTt9@|^`*=n)@HTna)p>jn5MgZ?o4H`E?M'
    'E!4x~BmNw|W%TjVR*^wrtkm|6Mv&t#gp{DV;5{r*gf=P^MNVZLgW^bPQ95=Iyn<>$385v~#GsI+wwYR^ux-^nqP7p&3MtX-q2?NS'
    '@?~Q2L=Gk(vf`TzFSXcABf>y6<eq!hgs|%XQrdIRPn!2U&~IQMv-^S$GcvYbop#qLk?r01$)OD<L;#ZGt?hWqSO6%(rI{o9QiZb?'
    '!%&wmJcIV#N%CDtb0Huh3Q>Pt+QS;UmI|U2eZRb)X*LXx)_sj1fG}Xt%1d(sph{*vb@m#1NJ&)q8{&iNV!*n<&Z`7blC+jHcF}$c'
    'sO;o$h-UK>PrNUyb%ay~j#gSWp2?JVjBh3DhkpQ#(+P{;Erz6ZY2}Z<zbboJ;)4;mJ?i?l@fM?duTA1o+93GZ_MgKOBNoAEg;$Nr'
    '-Os;*4$%fuWqirEg%P^0NXm`)H<>DPS&vlpeM3z$gycO5h+su^EP}^YvE(bazPG_UyK=21r9veoKgT2_a`i8M1tM-p5Bl>e1e}1i'
    'g`c{O3ZSIng%@hjGgLA|No>=EE}Fgg0K=?2lGK6tb$WaePW69hG8JDg>uLc2vtUZZQ9f@t7h0iGn|t3kK;)pJ3d5O$TJ%a=7&u$?'
    'Gj@p1U#2&^Alu}^BU>W3@=mv)i>OOU#O5px4^k<0DsuyGgM@NI{&CG<Xbm9V-sdZVA9i5(;8|+tfx=N*!txAJQHeKyg4OhjXD&p0'
    'Wk_aN>I(FhumQi=mN)j^AK+4^oHG{FHCyPF67on16K<aYvYJQ2mqrA*t!^tKlIF}t->X7)CKmWtgL`kf#FA{lyn3HFpHo`D-b^ff'
    '?1__5B|#xZ&eD$2=S}S8cn5-FY$Fnw;q<;gl?`6gyDr14V_d3qz<Ir!VZ^jM2Lu}x=_~wU(TM$wV*(&4uauX_aKSdK1G5bpG>=iC'
    'dD11GAO)V_UD!f^tQHP&MR8cbshJ-&FAJl5MDsyYR&Ea<ly5{+?@q^s`gtPp+lo|!c@Ge2%FFNcVdz1hU1ttt;xUYmuHN5Lf!m1U'
    'Yl)-I7{2hYc{Q6TQD5SL1~o>OSL1DzP*X@mr=%Xa3cNfgmlmOxTVFL8RpFzdR|sw(mNXGo53^=FR$&kO<a~09IKQt2{th{XA)o-D'
    'hOz(u;!V-ejIu86x6&#+-K9NwR56N8Gey3MdwL0MI+O<zg+WKL9STcbM%;A(U{d`hO|WFTYnP!t8S{4LG;i=MrNBm0aRiCa&AhOy'
    'PFQW@!tt4wpsorwNU5Ad_;r56QP7ARO>65rnzAzi@y?WoC-x!jmrD1PC4Vy9PMW{O#HBxQqV6XFVO2EAENlx$?-n9{+`WXENbDh4'
    'Uz!R~91Qx*{ujpx5Cw$;G?46_J@f{=0GL=EEj<oucE4>EttS;S46T&`UBehV7}tVwj}z7B0h#HfA#}QBt*<o_eA-G&F!4pNWPr`q'
    'w&EHjXps|325+7v!G}%UD(NtvLo3bNH+`IgZ7BO~H>9`*%vAP!JT0@9FAkGLWs8n!*2^r8-V@)oQdi5I+#?{IJy$PIQa@B&kWzyk'
    'z#6KCh&~>Xk+Z4~;5@;KwHIvX(}J28E79q4pY8wQY9n2zY+a-}l`K$>d<1Xlj%722Hjuh!OYWQM0uo5Y0#*xQH`N+Syf!flw(p?*'
    'kGgegU}xT*DPmLVO=@I;R8B-p))8OE^J(rp;(w;ma2n%FUNfoibF~u4rDEymtk002$7b}{atsKg7@WCYkY$77Ln9MXwKG0dEq6pH'
    'ayv;>v#=oo7$<sbktC=~^mSDf$oA9P*Q>@wI4zbdr;opT=5Yhcn6m$fCrZbT$>039&yr+M(<XsqL!?nVsC$gOWzi8}G{gKIsdA27'
    'LSz+}mMo0AB&uG^d5fx~=2sn!H~c7UwzM#a9pO?un6Y{lA5#Y|Bzy;mU3bg;|Jc9YQ=%k#WiF6DO!q)adg1>mlM6CI<2#yiyVjE&'
    '2U)DkC2hZ=Y#941IkXl@rj_1KU73*LW5L_@Gt+>}G|lJrVYXx#K1cF4jjlN~P98`bvk;TTDPWsI@C?vkodpOH1Q;}AtU3y{Grcr6'
    '`|t;#N`uMF$ffFk>ws4l$Gh3kj<ol361mcN1JGmY(#!>(Hg>q_-7khmwX;GA^0*?&bGYrTNCZ{mc@5(QXb^&QoaP`iF8tL5QAIjq'
    'nZml>TgKS5qa~dO-!sC9lEHEx2A7#g3_Kts=WVM7ghj_-FkT5}lI>O08vb^o@6ZGh_`8v(pXv4|g?c{`UACl(t#cr4kTpwfrQkRd'
    'kyZOlAqoC(6p4ej>hetU;w+!~rMb$iyJT))r%DxDhCzeP`c_SBiJ)t8-kj3pE$79-Fa%@=sr7h>#Z;uY@E^k7HPD(DQ}JgkzH*$X'
    'WyD&cy+N*`a<Y@^g0|V2%9y=-HI>HvIm+O%ySHQAmt414-GKqyyufFexvmO*+ng`2yr9d50XUtV=EYtVN8jkG8PTY9r?V)#t!=I^'
    'O@15;r+DoKy}v6Hlug>U4x|}kWtloD$7HTpr3-S$CUSBP`D23Rrk`VZeB@Id5k~0y6!)WoDV)=^$fgBggOQ5y2ZZI8{kd}@;%ZHC'
    ')ROlXm~?fwa}(0JfQ_YE%fORLne@9}LgUyGnIyHHiLP9@wzI?fsWqA2rr0Ib%xXF#91XXL9fk!1{rQ;2SF(+0tF9~CM)55gBjZ!#'
    'eEYS?QH9#`cNOT8xbb{46W=*)Qp~Rx1R;=E!4I?B6fx~R&kT3W@bnz!7XLm$I?H-@;XJ*^%zo^K6JQ7&SpzsS0UIX<k$Jm(k)z~n'
    'M6bkjvqF)-s|k4Cpf{mj+1lFxo=OS`n0^>r-167h>oj^b)<N5gP|Oi#dMS#cWb@tQjYhxxg};9za~U$d_-}j_kO@P3kgv4RqsG%B'
    '%}bd7<#e44?yN!;_RN*}urQ>Sjo>y^bMh3d8t##B!`}A2lnsl%J4<|D_(1^vnW!X{mr9Sv9<!?gXq1IC=Z@p(wwhnmgq{Zvkuit2'
    'qwA+j8bcP)IfEO21K<R8Yfa-~5398!p?`1$D`e>B=n>u4dtkkgW-<O%uKu?c3lyLKlaS4Map)F~T=+wME{;w97rBdBn7ZdFkCeRU'
    '1@57=nL7n6)@kFysW7FT;-BF0AISxAMa@j`5X?+|GmzLZ<UinEtj0@KNBxC9Ok4-Mw@B23!&Z$zSSJiOaeiaJ!}em!DcIQ2XIkOr'
    '!?o?-ezl~G;F~)5C&f~?!kL0wbB&pXV~e0#`AQ@&7(pEpgLlfgmCq$Pzk!c`_YYRYa<}8lw&k0k3}-=S#yow5fVI=jDM)4*?pG91'
    'VkGMFO}xlPQbqR!qBVq{5pp}Q>hI|h;TbXx+_nyTb+FDEt#<$RfS;nr-^M87EaQ$zXf@5>>SwCUQ1C678?Fo@Om8<x!hlp|fge#a'
    '9w4NiX}kN1-51f!KN`pWg25~xmT}C3d^_o0u=MsDul5xzXBgHEjbN;jx7;RVg7LlX;8bRjy;!`GWX&t&Jf->=`5n$Mim!?^I%#VU'
    'A_br?zn!6PkE0OxuB@qBma4Ta3JiTWDvsRCOHin{(|~JVwvT_AtBS_ys^f0)=mkA{C5~Wv#lYQyt#ykfZd7FWv;b6mdllc57Yqvw'
    'QdLII1-J15YBa7JtWjv(N;7AnMdiLd4jTy9IV&dWO$fL0Coh#<QWRZJp7|0pl@KgeGzX2?QE4Kktj!wmbc>XCJQ5n+vQ*GOuEwuu'
    '&4LZ^LOwymInol@1|T{NDO`**Iu<D3i!NSbb*-PPjsAF5Tk3sX<ueHACw95)Ti&irsT75R6(~wwadT^sZQ)690{0TwU@}$3CQL60'
    '{Zy}jBq#}vWEWq6JrTO0^^#(@k5H3{&?=<NK9OYUIfhp_3u}p|aZ8V3X!`-3pOn7b{PB3jO8<rrKL4sVC&T`6y_Jpb%1eC9om=4('
    'uBJH8>xW9q)^f)bzrZj?YNwY$@C!HmsAI#1Is&-qVD#d5ZbU^W55ZXN#gr{S!0^wvIhY#2%NK_eE%(VWXT`8{CJy$vpT<#6a{X#M'
    'fV7nDqMu*ngT3H9rx#>u{c^y;rpmNmy^L`wqVg%>&K%YLCurCV$0H$oKW_}g0M$EqWGm#sFGruez-kuE2?&RDcIIP4Hh0_?H3DFO'
    'oFcD~*jdr~V^`Ybzd=R~kQJ(%>ZapR5|BskkR|;<4a~q#c~J`*B!qHhJ2?>&>wWaW?8yoQNqvq^6?b{kljEJKMCoTFFOa$C!hV+G'
    'pJzrPj%Vdk8?#@`)u_?CFtQ~!h;%qiUsn(a!30V}-jz_$MuLSP9fN~lW9FTXigEG})M_kNNf`v*HhCBbXvRZYx{qoO(5w&Ac^GJk'
    'MF8`)g|HJ8dF@xaxW7|HmwPu9;gv1Y8xW>rcmVWA!Q~~lq<zC%V{xt@hE7?dS~n0V@>Zq8HJx?HoDG_F8a{LbTjzhhk?cj+3>laR'
    '-qC>)MAD*HqPrtJj`mT;(&Q86^a;=|kThTX;A!F?bw$yCsaNNF%<cXUSy)?7jEAP|wmavXdReQ>NTC#SImdWT0%i1L|J(%qI%C|>'
    '6&X<{d{Rdx<in4Q?20%*e{;5!bIPx)o7|X}sjOtw`-FLoO&r=);JmlWW3SgsB@(OUmHnyhbI&nAYQ00{W*3?^@Ft+5T-iLtq!pIt'
    'ygCZ>uCJs~$WHIgD7{fxZ$$V8+!wR-=8q$P<Wod?k?Tn9K>X56K$DB`3O?hY=+yU?hZ*jZ2yB_cxTF^05yQmEJD{7HtKiKW;DWQn'
    'Z`3&gECmH$f}&6@<klL-sAh$a={C)LDit*h8Z*R+spe665}+#r%i3wJ;WP>4%}hP`xm=T6emCf01W~a^_mXTa7C-8E@pPEV(CebX'
    ';6Rqj!s+rD(KeC<dWMMD`gjDJC9!<6kY6y@2GTP#v~@tMr?FrgG^;NX9S?l8ApO5$DsKCl`J4fumgt3h1#uRs6OgTv8tH_qg{hqp'
    'f=chm@<(=TRA0`NNDGx5jNk&ITZ(OmGj$0QcOsj61*?TpK!D#Vzrt{_3F=Ss<e>w5^Bc$8ua#0amWkdLIP`=|g{8zAVFNLvzDfmt'
    '12iqu9xw8vM=@KXF}9TG>ohBxlj~Zqa*}B0Ild|CKq}x+yI=<^){!-Qq)VPQ#jR~x^ivsg^tcE1apop1q|JQ8-VMUN4j1^ool@Ns'
    'pcnZ7S8Wyx@Y-B-p%c<V@@gRaLDL<xTQHvKA9P11lGA_D+8M(q=rVa)R8i|5=R{gUd3nfLD3gsunuoq4H<#SZAlnHh1tUa@2Wm}b'
    '`{Zlew=+Lo$0utma%Wy{k0OXV2MiSGvXNLV2~Ij)a|<69XlT9}Mm9f|u*!`<6b%!rs26+7OZW7QdOw1_*c4Yh1lfz`>_EL0EHR=8'
    'B|{_(5v=xYF+8G5BzY&8M!HxhxumA`8hk;$QykSJWJ$txWXDQ6u|dGIM=4OUA`2ut$ya-1R&I{xj}6H|>AC9U<GVDsL8bG$p)Xg6'
    'a&K_P#>tw=*Gn?U+Igfnjfo}Sg~nDrEivtw*_`wr%Fz8+;;4zRM=0f<1t{!BkAJ3ET8*+YB;p7Cimt^_t9KdXE0{|2uD(QrKc^>n'
    '3t<NzeH{B#u=5{h*Q(Usrz|QLkW_&JSVK<-yOoT{-iK`)ByD2IMsst{G6+?#v~ASKcsDS%*~*p0NoW0=gqTo%gY}l&KY(j@l!k7i'
    'xQc7vTw%8<842udq=n4DDWDfYaSpD-I}DBQrc&rf^77OePuuiY*K&;767kI#Y%Q1P2g<UFcPIOHXWnsM-=mawpQ$P@NWSeW3se!~'
    'z@lILFdn`M8UlK9hbZaf9kas`w41}5>&0`ARJYlR_NVAR=P7x)k{O$UVsa#w!^wXK_~H5y-29-IKc$;f5u**hXM^pffF1ArGrqu}'
    'kIC^1@Gv7%A}ZOZS>ye5gZZp9AG})~++#w?Ubc+NXs;c&O?&pFrUeV1n3P>c_cP$19v?%jnHROx88;qk(zV}cBPQ1rDy&ugY*nqy'
    'Ie`{N9jM{l5%zgD4GX#j;OGZu)jiWz>c;%u^6f-Ied#l%p(-%8^{q;zQ~lDr;Ft7YYqI4~?@6fA@>T)OMaoB8WV#?Fadg+bW*2RY'
    '0oKGxT`|#7NN)EZxAB!HFKC9EtW)4XA~p=JsJYyMr2dX;vGTE_;Z68<u;>iH6}){l7%i593i>8ivcs~vfffr!C18(9<W{R32ly&I'
    '#M~#YlRbM*j>)U-y&D$S#~AXPY4r|aga1udAv#s%_g<>5#Jnpx8<~xPyN(oXq}=k3`S592QoK{*MvU~KxWJZhjT%++b5_AY(lnZo'
    ')><KF<=PA+q7wj16$JW3=@IK>XIk}7Vr@KwVDFwh1FD?fxg95TTu})=?WJ87VT}5L5+a7=VbX%d*MmCh0`PDJDWLcU?)PG@kjxtO'
    't19^DHQ66Nq#&-%nDH09c`SUuuLnN>P%`fjDy1i}U>52vS?W*eY!jZ8jo;8+_}xv}dsTrn3DOYoQ+|?UR%Yf{yy>1}AQCUEVGN$J'
    'ZeOkr>BCz{dWfOhg&~XSy;bX>rjVn|GH+RZn|W)nV)!$aUK3(XX00U|SJw&E@_xfHo^~oyikLcXo6$ZxCzNl}5iPii)h$kNx2Teh'
    'n9&k}WfqW^N9_`8j~MP%rKY4uFnCL(-SmjRWB(&TYktFS8j*GSF*jcn=sAaRA~;pq?+K2Zd7Y0%-cV0&X5PO08$27yimueB62Q^2'
    'c{poT@uimsgnXJ|Ak(2-G%xA$(F?)@Jsb{K#|w)LRl54di%fhF2>gbIp>h)RBgTB3>>d<Wjj{}L9&diqr?UY7mC2faYx6Zch&QVe'
    'kKSF%Sj*3!Bg3wih3BKtj8;bb1P4*jEhYOQo_2&yuCx#12T4w@iCi9;E$#q$<YH*7u25g+(*!S&vDK#$(rGSKw7<@_da=8l7mJzB'
    '4vJA2s_^q%$<IOUiJQJ}GeeDx97I!&rPeq-EuR3kHlnmM5|^Qr1(C__N(y1Q^a+<;&sb1}^~jq}_J`CrFq10qz=bp)H7HR%oXPDQ'
    'A%kaix8O;0I6;w>jArq_du-9f1hhvASv+Bqot~J}ALD>Z*7+&>il5RTR0@r{Rkvzp2SF|XQeKxlTCF}Co`8AVeIQwtt}<=r5azbW'
    'x0$^i0i{-#%)>Q^VC{ndnBo_q@y*J)ecyaSD+!^ad`ZT-%|+i~Mt1OABY##_se|GX=SE2~6V8GVme=s~m*q&RT4lEC-pLuzua+6B'
    'a31sL_5&`fn;cU#{S4lyEf)(znSq=rS>~fLsvIg5*>~}}z;2%KtkZ52sL-6<h^Z6>W0?xb^G0F#&$BHK3U?r%Gm1**v7%ihqG-z*'
    '+|33<M!RH6>ai^Gix`RA6jcA21BbF{3oe^^ePdps0;VLKfEi32LJfXU8AYZrUvzP~Tb%R?Z|8V%RchVwk<=TmsT6&iv-sNj`)f)R'
    'cJ<ydC;>P;NnFs<9lB7gw~v=1kVy!zP5C<`r!GTFZ3b|Qk$Mz6i|>tFp}D9AKZTu6EK0*zn7vL<rH+&qe8^e)qSSF;Ll{%fS*gZo'
    '9CT5Gwe5oQFNbkt_Rj*!mPIF2P7f}%^v(YwOvu=X)}40(f(ZUX!=|10rq`%XMz5ln8!k{3BcO`7^X-pn(?Z_rVLj9`XL3e6ta|i{'
    'np+kXr=*nzOlZfCeVT5coa}`x=b^z1rI?*jXq6P`N-bt@b5jc_u;-*Hgi9q^(Tx8GR>grr5(e=5tMB_*b|{KCJbkTChS?@9mL0St'
    'xf{`bOLY8ux*CvYH=Dzt-A<kGD@Pj2ZQnwFvCicdZ$Jnt$UO#0U5<5Ym8H`6BG`I`BVQ71mJL&5X|yiUd|Dw7yoNJ^G}TKmh*`!O'
    'pgA~Extc{M>(WUUF0tw+4PEHu-B(`aw@$Hsb1-P6aQ8KJvNWzW0aPK0Sq~PaMqAw>%VEboPmm&W;pnw^ATk}7I$mYj+3(zROO}jB'
    'qt-saVA4*Oe32$r`!h?y{ee@u_Svrv@kqtqN#qv0M!(=vV{^qmcdnmq>a-tj+ci?dZ&pV0k<9Nz`|P<$Yq}d6SjXQ@&c`tCPcEY0'
    'obD)VsJw_s)xlsJQ@XV-BIxnCo`Tt5Y}g<W=7}(w>@LRUK93-34b1zzaKr<9Zn1Bizpa>?Sk3)1hMFStB$Q7j+kzO+=Wi=KTAGs6'
    'Cj-;O>_t||`ewsD3hHRl;?|01k_Z4{>mILIF>uz4%Ij`MS`P7tW@>IK2aPi%<~i>iWgmaq2v5`zKVTk#W2wP$ul~@23lzc8%VMm2'
    'bD}_-b9kX>ECF|zLKS32ZsOyU$#3X;S*Em|dY85uJ5}j3%|=8PFO;bt^I!@5Ey3TGA?bs{Rz+BtJQ)CPqFAfa<C*dX4#Xm1B)p)b'
    'nd#Snttr0a$;wsAoTDP6*4)Ry2X5=4|31(HG3md>%h(6IU;GEHN#11~DQ=r7E+HMT5L0`9_1dy}o90spHIn*@Fb%B6f9<6X%uj}l'
    'Ko*<MM`1L?Phm*I!AKAgn*{&BK_^rWu}nVi*T?qA>b)+&ecsI&H*+;%Fm2i9>a_^Zz@tmcVcIMVnfL8pr*QTbt>4bFk!hrP>DR?O'
    't%@`-e`vq+SBE{A>Ga*(BmNDU#>AR#k@3ELFn6e8^6bRPDmf?|8iLz3&4Fe@8o+!)@BVeBE9(9@*Q<t^N~~azfqLwdUJ)?4$DuIY'
    '8!Y5ayy5f$h0%~+a~=7I+DX04bN(-kw^|p>Ke9VulhO-pta)2&m*3#zJA9jMv&h}wPqQhE*=R$jXwB;tPy$%c(t5+xfW5lc4%1y%'
    'Q+Tg{L&6rN)mvaMzhAXJ&tXsq0&ndw;10XFXy2r*K(vVw_e{hb?d8x1yd7Z*IuQWMttc_<6ORBg<<Z<rN}^5LS%zE`q9FwaP0S9N'
    '`Hq>$wbu_0Q}sw_yj`350E4#2j87dqfEhxL%!OLmr<0CEHA#qWaPkp2#P0BVt#c{*Z|x=-sON||pwyP$>{qXB<674T@g0l+Mc725'
    'cz5VsP#lpQaWgTf3=q0qF_3opo14a`OX2{V{BQ;i$ptWUV)p!4#SUaL|HzD4*B^w*v*b|KiZ7#{%kD$~eA&D!+r^Z26H@rc^3JN9'
    'S#cKTI3wEU5GV)lwA?-yn?S$t0SwV{ap&K(wLG~CqgB1AD*$O}_m8C@mtIpWeL~32g|zV{L;B`<o#6&%7Z+KHau&`{uu>J;X*(o-'
    'w4)~cNEbP78(ZotewjG~P@}$-26#Nb2Cf{XFQGqs{%|-zmXKSmH2qYJfnC^aCKw5v9y6P%x#LFOH##JlRpr)AAfmpW*csp>D1Dl{'
    'nMYr<3^{D7n)N1~=DYPFAEEAX)Y^(YdEQCi1{oj`J)$B%*5D4#W5}ZyG6Yo;@sp8Qa@%yOMXR)j5c-8|do^ef>p**Vme#`w1uHYo'
    'R%Z|EG?7%rM)_qoNrx$@`-EJ_b&7P!#Z0p4YKR0MYTTZRvt<u6aJK~MvBH{qV^b8qeOC(<GYF;F1`q!ml;QAp13M1lRfrupb%#v4'
    'IxxL_Vz*_>Qe`AZtQ;Kc&()76EwP3<ga;v>K5I9*ofO}(uKpn|39+6DG4OYf<~3pu66-S2*x@(A!abwRo7aZ!`WMdq1$#G%Ow%Pg'
    'wdboF$HnL1i-<RpV9~(P>ud)wgB2$yd~e#OFpRkjDU}MQqX(GkOK@g1*-gCF=84#M7A`%$Ve#;L!O8AGA)FxTUYr26m5!T_XYh2Y'
    'f{Fkf>tLiOuFj4F_Y5_L=~av+Faqo3%i)+y=3uN^s49TOK(I(9r|n*?9`&cjgRT-xV!97Fxem*hZaWJ6r<jdgjD`{8!^J>|BEGI{'
    'WBxs;th;@B4rB1PGhp1QXJAS_KO)ZrS=iHbog!xTO0uBwdGhDoRLF{Rc>rU9*FvbfFGW^Fp-1@nJq6>WyKD;zNUv#61&dglj?J+o'
    'V0CBbF!ve4TKhA3GfhmskhT8gI^heaFydOGpr%joD~$6}3=J-n-7_Mn&uyv7&igU1@){a-t6lZ{sop5~3Dh5Aop3gHxJ227f|rPP'
    '^Rcq?3IoGrcHjg$K4GZ!&@V<1ccb_zj<&P7h-UR6jPQ!i+>b~|a@2o)LCmL0^E}r`WW12lzgL6YojB)>(a7`%7P}#Y#ioS0@|6mi'
    'Vtj(^9?m^+o=%Bn3t|iofz8>s^c%!wWmnlnCF8(m4Q{%iPe67=<xYt9s`~x_VsVYy>qUY!dV_A&eVciKGPIqCn}awd1viPoStM_-'
    'MrwHgon^8z_cP5yOG)s4yC4=Y0wADsJbM;~(>!r`<4b;(loA-WMb~_n8UG@)9vAtk3Sw)3V-z~xG|Ec=+)nZ>;J!$|L4+wU8!4q|'
    '%IC%@tqyJl;T6imPdh*I22J__W(^uRSvK!@sJvyCw?qMKDR7IKJM!E`VS6CG@rM`h{HTB&pS7t1C;0*v?h>OtLdW(4Z!azJr=AaU'
    'if<(3LG<T{)*EL02G#iX(`YW45{3h_u*@YVvs#)p7a-CjnRXLUNWAk(_unwU!Z;7VDiz528XckQtuXMRm3#l?3@-N4Fmb|WVxHb0'
    'X|7oG!!Ev`MLP%-lew25rB{fs2V2Wga6FiG?JV7S?a99`ObvZ7p!Pk=(Z9k(R4pGI+m^xHCA()+!9kQ_^DA|AbofEQuNhVvBf+>z'
    '0_#l-q`7di9L_kN2NjXr7wqBAcjFWdu&rQAr)a7t(!V^6p2O1Fzu321B^XwOZ$}=wrL=i{=h~w&-wyOptEIiRf-XJys8V~`<W;b0'
    'k|QOJ3}O9%PEuhIli>ZT6qQz8y;VF|zh#IpWOCfvj-4#draQj3xt97Lv$liIStX6g+kjZYY4%i86vN7TU!9?|L2CxP6U*g!yE4Yd'
    '<)^mpVaKKCQ#=)4EHydEAiHsPtH9!>n&@*Rs<&1+C?F&tB`5RolYjkA7Udc;w3L6smJQbd|FiT8hQCdF=DP}&$k(}+6Q%M*?l<_@'
    '_u+dXj|Mdau=X1n(;rBMi86}<_x`AOHX1rv=|6{02XjT3k=bT2cPMMb;jfttM|xA>QQ&GXUE}qp!DrKl<cU@DY8lej$Q(o`$-zq6'
    'R<6%j0r^C&+o?coQk){ubP5OV%&NBCTRZ>SR8BFgH0wMGkZ2i3&Y<n-K>uzG0&;e2Ni#I~zsrM$4Mr4>nVaFf$-SWg=`!;S^g}7~'
    'gCY}J&um&RHuF*Z{@LQJYUCSL=<$XKvoEl^Zpim$BU;cTV)QvOhJTriHM?*@QfwZbN3B0)PzCk59acPAn%}z=lOU!1ie0rQO);NL'
    'jBD^$DlqdCIC)wI4tvGqCdimw$7g>(tj)}uR&nTU8tfVAFOa5z5z+5&qUL2WbF5TxuKZOGHy4=kLNE*0KNwYWAQB=+u-YMFzO0=Y'
    'ny?4}&&7(asE8}cAGJo=6lFtR>Y{V|T{(hc#j>tp7+FpyClnXXrHrjxGK2Q;wai}J;3W=qu}Ii-*8j`3kmWlul5}h!NL00kPA9ml'
    'wV^@^u6=KQZH4vqIBsvHqtuMzA_xxQO+4ttEl{m12(Uf4)LiLUXQ#=2l^cUyxKR-XElbIRP$tkHH<bzoV}KOTLhGAIWj~~O01U8{'
    'wlG%V<mRBo@dJY8_d)%UX^OXMdx<-siGLvd`l5O>fRixLNTNCBelyw+4BC<5Q~vkcK(!$ioEdu|Ys+1}$t|#MF~ILfAhqrMrB5~T'
    'u^W@iP$Em26wQ)1!rE2i&5ZI4?`NAsfbLh^ME%JQn|zLCLiv?1iD*vZe&q8jSoQ!wIUnlwgqsu)AI_OAg%g_oKUD*3dy#sJ3LL{>'
    'VI=>?^xS*gE5I$r)wgG4bpaqArCGFs%925k{Z7u@QmT1VMFZFajra}=W~!K_!q6P;Y<8ynEW!`<C)l#~9KGUW_WPjs%I&0LQqp2o'
    '#p3S2_SfyEPRZv|a1_{vNkIn&^BuJLLZ9AVKa}qoz#&^-0UKt|`^#62U|YM9*>2(Wn2Fcx%bF%m!O<KId@+i_5$x4(QVXidfCZf#'
    'U=#(7;}jOH>yuDRcp%G*FNZ}EDaOFdV)`3ie!L~9MeQb$bn4T6h2i5LSDD>Er$i*-ud0r=9e!qPjZ8^*FC#VFNBL`T=Iw3PRLD7i'
    'b{xf92M)P!_^j%wZ#39q9ncsa&PN34w~#7Lp@URyUyEx$pBj(%HojdW*YV00|3Cn^hCQ9%k$RWyvd9xMkqN{hLTo}5H$E6MIYy}e'
    'BEDd9AZCIRpPx*PsxObH{SM-8nHe2)Lv0h!Vp41_*EZZ`pxMq?6Pu7bB)i%oBjspuB!A`^D#U3EybnUShx?LeiNp?`2xG@5&*0?f'
    '$+g;w&2^_-%Gm^FQSg;uCC1Ag<t>)X1Gpqb6u=+TO`(0;hN`2=!3`e`^-bm2W4@9~IIW-de!Yiy1dwVoQ(nfmI=BfZ+{t7s!F0*b'
    'L}&F@LB(<_w%uNOi8A{i&zr)ZTPw1}%m(}ImqKgqfBa%&ZCLW~JuPMY{o6|OrkhKbMZNt$mO6peu?MO%`?!EktDZ=%fap>Z=D0w5'
    '@F?Ld8Xa?JKXvHcC0IDq%u7|pp^7c*U+a|o(@#ZW4v^In)_yx}ty+RJ_^8gN9Zj&6;5-}Q#gu&e<acAGDo8z_P7sZ9J4i3O-G|{G'
    'pGYvAS52sTfxSajeoTuFZLsKfqdSUh<@c+ZWuWwS-?Vq5ItMhu`mUYIifD$Sz7iR=ztCh^o&0n0)R}9EDY^7HSG?N(EFT-Zj(CQ7'
    'YA<IQZm41-q~_1AJgDH2H)2=#8>WTkXCrK&#C`xN4qNmuM_f9uNUi3l?Y&`2%Y<uBs=>BqujO>GuP2%>o^n-ShwCX4k<4HOMz1H1'
    'O5C%OYevCr)pO)rWPAauFP7%XNuy{6OLoL7BQAX%L@kZ0ne`AVcB8}LTQPs0E(m3d)X_;qO#U;q+K60;iItEEf1T=J(q#_dUdv!q'
    'Rc}^#;a`@;hh$Y(&DdCl3?cgh>1MrE`#JfN;A75$$RHX+67uI&if3rP_j#eLoCyBC;?@$>gxj337xd0~-I*VP44Wv#LWQ9%{ufIO'
    'TSkb}AK|`cK>-<Vqv-8Ow{dp^1w^?sXA+yOZZhtTz1~U*wRNGV#ow&t{c)vc_3W={jKiR9QQq!S4yv?+@m=RwWBt0Oe_V3BQzul('
    '8GQMa9$|sRm}Kg}naFEX0@Zh#hke-+c-vyEEyDG+q4Qwh`2KF|8E+ODXAQr-CT1l#+4}=K44isJk|k`_3dHq_N}K}iCYjkj<!NlL'
    '#`kG8Rvgp=P-Os7s-;6+lf;B(R#3Z>IBicCdgU`b``kGOP&=+A*UxXQ;nbZ?g;iWDebvuadcq~vX2=7z1Gr+M{VT-veLsr6tAW|t'
    'bz*889vRV)_N|3mN>MfMSgt3e&f-POCFtx1|90^ENu>U41eLiF+uF{mHG`$>uBozAPd|AY*hDiFk^0|cC`WrHmB8g(dUer3I-z)a'
    '-nr$|L0F12kK<XoOsbz+@$^$A>%IVDyJ9pjG$!NK+jBovea6=QzzuJV-&|1jS>R7@6d!WR@6!^z<W@>sMaTVP&D(EHx(}qLrSphd'
    'zvVu_o~HRQ6i?piCNUEEe5O6@HOiR0!jhVXWiVQ0M>|n*B}srZX%wDi<{c6Na3ex89FBgoG-}$U;oAT+oAoS}R!eAgu*!ciiVyi8'
    'jSBh>E;R?HJ(F!}^Yjow7D27oJVJWDdkULF6MPQ^DJ6s;3^8^uuH(@ELfUY&A^nZ219GnXL7D8+mcPhel+LVcuL9#~dd0Ap#1cmT'
    '&sy6)AKkt}7{zFgq;i7~3K?c7WZVLsV6yaWRZCRFwsc9P?MD?4dv$a*`enp_IJ=h*OrLyOXUucTgx_owJ!wshpz+4mPX$#37aw8g'
    'D>(-N7XbpK@O8yUp)?9p8?0jkGd41q3U9Ka8Vf74-J^%0dL+OKU<GEh!tcCm{#FAMc8Q=Y+qK1~g}CU3kM5zCNQ15`T;9Yfpn-R)'
    '=x6lXJns@yd;-9deh`rywi_L+@CU6Tlm;kREgj(C6CMPss(fiLBq4~)&Vz_)4yyd;NkqZSKKef}5JWZ{)r4DZ487PDog<JYv~HQ{'
    'Q^fdh_Gt)nZY4L0F%>cl3hcFR#OxJun{&<Z84-P_ra$RXm1B_=kW*RD)S)j)R>Iu^?2{|~vj^WcZ?8z^6xJ<eAOpJ;=}0ILBzb*}'
    '))ULeITqHGOC+6f)Ou&Pyl+f(54=tY$8%|otPbsy>wuWGyRz%*hA{?D|4e7L=oil_RTBnTTC)3!*WCuy@wkeytmT}eTYB%=?{Y@a'
    '3~=c;<1B1{8PU0=Y&4p~?*~0*g9PeGmB91>`#(*uYC%K{nECe4dQKrNSb^-a*?H+$K73X%-^gI~JgJWmtg$&Sv&42Jv`f#Lke;1o'
    'D-{He_5}+=Q3`jw^LVuRr~;JrvRbxrD%@=;@Pad)nSQh*dzya~C)n#P-k>_knS*p>>WHT>8Zjj9P6+V$l=X6*aaFqbr=qvnJ%;*~'
    'O{L24m2v)qE=)7$gO`Q6MO1qYjvVJ%sK=$Sy*IFQ&OK++FyU~aY<|GQ{$5H&DL%;9IB(`09&=Ky&xhaB+gw`YMAKr!p4?i@0v=ir'
    'klw;~y2>J$x+u?=SgP_fO~VOC`>^8bPRAZ?hq{_$Y}HX)c>PVXT-zW^s4dG7Sed6p080479S_6E&DeZbZ74k5RY_LJ+uc?>86|v*'
    '=Q3;KBfr)9T<N7{EJj&u*St9W?Odb<!NLMET+b)Hk2#v-O#^~-Gjm+4G-ud?9Wx@F(&6y1yRui*l+%ls)W?hmn2dc;u;}Hw8-RKg'
    'CW|a<3?a<nOLVbV9^%IbnMc`3Un-_roDd!LYVCE^kw|AFzptf1+;mO|<b;^AuqU_P3u+u$Y1tHyDkRcVjaA3FwrsMDVs&beg?ifc'
    'N^d!Z3~}lqYJQCI^EkW$X_8Q`Y~=i5nAm5Mj9?crfbB+5t(B)%4L!;92zn;O@ykiJ%*BGqTzynCm(hK&C;0Lu4|^>O1RN9DA1?FI'
    'wV+uhC&B6^#vj}5sDrCcv4U*D+gEl@)H6fCTS`#O;If6Q*OqTpE0Mhg#KyrS@uSB2f&qs3qQzrS>E=f1N8|RqK+VSyc^^}^?4(T3'
    'h`Lc1#&-)8Ca48aIXl~#)hLWZfuiK)Pxa-OG<T_85s;22dMH}o7sBRHad|a)#x+7TYJi%fIJ~NyYtzVvZUDuK3LOaE=EbAJbf3Xt'
    'cL1CxpvM^gSBm@J_mj9Sv`<=NPO?=>f|?V2QawjU?+B+Ddc-V-U~_yj+%**!pWpAB8xJIn-uH(nsme7Q?jxyd10!urquUaut)dlo'
    '68O*`3Ch}lF4?tD0d|70&Wd3$U-<LdtC;8jcUnB$sGP)@I}*aVfD7>-ydJ6MEc}Uo()Hx!pP}1V!d)U@J?mmF8%a)?Q^Ej50Ygty'
    'LrR~bup%()hF%~omlYazZhj(j{pX%`pv+)A|2#K*xtV832?e~770k6vz=Ej>=0_1A|4l2j?Sg7YXVhj_KVk0s=TRta8CAfrfF`rw'
    'a{CNPet+VV<ub3egL--7E^K8HrZYS&*<B$}>D*)5&MC@+Bgj8|zd#>i6xm&~%gI0{!0*V2c1D>+@=yOIQ8WQ1>XT5CI>3E%Etfkh'
    'i|+HQ*mZhJhG){H>|P8EU>`{zawcD-fD(L^F`P^&cH#hja8tO;gqE7tbu9l>#8@zg9m*-M{~FDfDD*jcc`2}0;AlLrMuVcF=@0if'
    '^Bff%hll>Q|GuXZS)-=FNHKwHv=F3>=S&^Tl5~e{_$~Ot(oer#;G=)7Tq%6H0&#Z3?H-;F-TQdCOs#XVz(NWKgjx^oE-l8F?lA#{'
    'GV>xrwHAb=>+C+j@6F1sS0<aC{<(fMoJ@r$DVw*r)-}x6hSjjjeHWa7Y+iCi)*_usT&Tva#oC8YkgB54#oost<Cz!JHUEv+uXmN<'
    'VRZ}$h!yZlE0tg{XV0b{eZAX|K<^`)R^>tVT%M_}g)aBP5Dv)@{F>Iu>3c<nG?X#|%A<EPUf_1K2{bef`PL$h2JxWPQ%GtFBzz$J'
    'J+Y&()rz+ybt84F+{w0|uBYL-4!S<E9G_l(WibOq5UNsx{6_eumg`R6d}zl+-VU;K-rdbJIvyk2Ggr;|N2XsnW%Hzo^btlRCSklR'
    '5)R%T?Oma6k{KuHa*|hTUDe!^Zk>vWj1t$C#1g+YYB#Yw^}QjdmSXj){%VLW<u30Yx!OE*21}>7(9ikjiUNZS|Cx!!>oY~k+vfrE'
    'LoidWJd?re=%Adc`77&9J!76VFSk~B?a%=4(megrSNnq@@O=p%5>QX`%jz8hS)W+FJk?B+yZ3wQF7<Jmt=|p9rRGDcHLGvJ;N6iB'
    'MfD(4#CN(hLeD3Y&}b)%KWonx;Fsy9%hlbCVJKM4+zhM4=Bpqphd|t3d>E#S`Cg?V)zB<I&V7e7ue=kO^cZ1zU;(^QIz@Q@m2zjA'
    'j=J*IPRx7@7B%{1VltLxCih$ExPnKu<3Sj)zD7SF2=Bd6amYIR0-aqqocB)<uLdp{iYheq=Kiz!JvyujUP9d97aO;(ARmwbfoHvJ'
    '<iQa(%M{z3<e1+In9ZoF*FU1PvA5${;S>qMk&V#i<&E;CuUnmHLGk~yD{rZa^xPG?LuguHGuThDDx36QzPp%(XyTqOd>{yp7Cl6t'
    'Yv2JZR|bO*PuD@)DYLlLjI1da>dVb1Im{dMWIR(hg!ym9uit7uIzooR=K(@9^7Zz&F>58B25sz$nu~ue@ql~C%ggiWc>v>wL_BoQ'
    'PK&jmDGK;e#WN`!B5qN)Ya3)%o`X`xxSAT1u#7vK65n!*+T>NSoJ7QNWUW;Gh}oSH+t%b&wk9>m3%I-eL~}n7sZq~q1&%T5X(`s_'
    '(>XjU<agME)e(2oiTqlNs9rF=Co%#9dNSyVd{?g3UEj%mI_fB@!OlpD$xAcBzT5{Ep-(1kQPym-D%2HWh?lDR9gb4<TxeBm?E-}d'
    '`Lufv<&RCW2P7nyXKVpES5n=D7(j@qa{5AQzbZtr5Cik>f-O})vij<>1oV^)3v5T71Ch?BeV;6PD~*D@ze;i?$?goUH8(qJ`-M;('
    'vD;kCDiD#TdM(deXHpCV>Mo5kvql%mD-qeYgNT^3_G#8t+!{c4GB7!>NGKs&C_yTWo3_OVC_%jziR@uVo<+DqPiUH#7#daPlD`WQ'
    '4+?y1v6p<a0dEK<u7U$5mVR-nDQ$T(f^(JYz$C!QIehowdxU~n3kEUZn&&<XQIX6c>D3<)B}jrbs2INN;QXcXu2F_+mksZ#5-ZzB'
    'y^g6&=OS5gC6{n4JVk${S5_iN6v>7iktx9;T}$Ib9@X2fRel@(YfU{$Yu~+{{+m?l-GN62&y^9dhxJN+`=@7-<el{dFIcP=b8JB)'
    'dJM@@=?lo!<k=dCJ-6No=a1geT)Roenn7l*qKwBSW3w~s<!fI9LNhMZ_HZ7!1J7v7QoklX=;<(%_Cd8&3v8#Lo^z6)1pg<P#w&vK'
    '4;U`{$NxkO{HSJ?6({|5;Z!E1o7R0OTl}@OZ!+-wkMaEHoaK5#)y2`?q|=po&|XtK@tW{N+{>cOLsTy}W6~grVF6u#A8^IrDQh>+'
    'I$Of=Zs;iRX~_lXrcZUAjF+(!5TwNgelf(U!}-k2XYL_aI3P`;N-)F`9BS*5pywv@^`gd<3q?~xxiTeM=r^<{ik5FyG?0I>;l{Ae'
    '#L$5`p0}uv;DKip>8{)O9x#2yX?@T=$fzz{4%a9$o}kHqC95^}_Q8rYWEJyE!%=`-kH@<;;fdY)JtJkBA51+%aa@f#f9TW1d4tY3'
    '12>A}hMa;FWYRPgGFI{W3Cx_}3{r_LU)NrHs&LnFIA{fG5|Nw4;&hWQO800#2+oE_eo@GoRh82w#Mox<1V^SJzFlT#CZ$1(8Py~0'
    'u>UvnK1pcmj#_U?;krzIJxhh8WRQd;c%RLQw_LixqTaDH6lE9xFXW&#x^?f*{&pmCKMX~Sp$|2ZCbdGR{V_{_ZT6_@Ai4pfgLAi;'
    'nU21Y>fjU*b$O2kqSC5|9#XxOt`B088`AY;=@Bgj@BIIt69rv_8)1lXWu^<lDrp;WzoPvOuk10I<q%mTzZrUIOdM-LwplLHsEEpR'
    'K`ha$1r{Jc(#9A9-H;xD#^2z42c@H)*(8<fNJKx|h}qTva;%>d73>VmCna_%Fa&Z`+`WIzOR{76dz6YT6a{B!JT#cbiBf*GSe+Gs'
    ')*U<f-ZbFtv%C|wrx_a}Q`jOcluc=xjBA?L7Qx;;jbg0bY;?2VXRVGpB>XGAth@q7egtD-5So0sR*Z{X*!WUi1pU+%OeZGQk9S#1'
    'bMba**{_a{2t;XY`5TzRu{8Fy5I~+%oRrR_;$oYnO0*aDM8*0l8Rj$ku6$Lo*rh5+n6}ZzDPWv3Dg_E)Q0Z90YV_Nv3BF88>s=RN'
    'p5S)^eSy=7W`JU%FlGE1Y=vxLJul_7x$Uue#^q$@M&{R#l3p>MVgucbNM$iG4e<_uvjc84l2|y{Yt+-kva|+q9o3M~SLFZT@ycQf'
    'Xy;L@4EYozZG4xTOc&W*Mp6*0sypNf%=R1b9-&qGn)QM;fWc9X+no4QP4qwviaYBOX34~2UN>QDoF=sy&>&)#wD%iiZ`#btT6xL*'
    '*zK>nhEEbTzqPBW-EarPz(rk|vN&!u8{VR3K&W|0g<dii<2AhoPoTwZbgWr+*xcbJl3-L5ZF0)wOPR*Z6n0;239Gri>d!&Dq<_zn'
    'qFlbn;b<)7%w1TjMQBtSQ#?-FX$)}#NS`@QLU9^=^gVMS&mFNnq(NoeRAx`bKq#CAAG~AV#S+{jCr$d_+ox58zoawLE>MrnqGW>('
    'DVA4RNg#^40)GXG0DKY@@gT9`7{psd(-IOqjJ(s7UxdETy!X9ltF4hhHMFmsXVU*>^%TW{_Q5MrY3m@TyL8nQ8YTJoYoSbnJhpy|'
    '2(Bpa)@=7w(eto+!!6F5yGA=wrtjrkxiabPpR9m(y^CZ>LX)c9^2mZ%7i19LlAXTLvRCekL}6{6_P0UkkOGA@o)O0*iN)QELNqU<'
    'Z4M~o>hT)LP(bb`)8_Fa5GlLK$Hx%_4j~)!N59vo$R2Fd%In_TJdEhICCp1~RW9o!8vxnW65*`MT?Ql=M0mrK{e>3VIV6?gu}+}s'
    '`__4+7)L9U9GFgBq~D=L&Js}sc$tby_<`8Q;7!G#i@XEK-c~p)GZ_{f)^2@o>K$g@R1)$&5?UNQj)nEppER=K+JD)*bdAK)+9Hfw'
    '79}wm@N6SR+I3G#%n|Wnt66hu<U~rAXvXGWBO@tUxDkutP@Ap#HG;l0qCe8|k(p-dJ1vs#m>4HoXLlWz^mi`1n9^-}b#7Ldi|Gz~'
    '`zfP;<Y;)zZM`k^rGBU;wZUWP%di1=PqbsHYFG?th4w;=+J7^5sb0D8q29!A?pk3TR)@aZzCVsN3mY@mT8@^T-k$J6VO2<C#<;`S'
    '=OcCF=(jTAzV!9bSKR%KHOG9XL<c#1PtC-e47BV5_+l+M=+e5kx!WCA;Ho9AcOC#R02YK4O}>Gi{(JkrkK&fV&sCT)sGUK6O7X))'
    'UrKD;GB&mEX&R;zN>Q`8^typj+;bk8;)lUcQM$(sk!_$pfZLdA1eaSHVmpB71348+ReG*dhG{h}@^{l5r%GIJ6N?2-f?GT8lwd8='
    '9}B$??^4T^kPD$QMuodQ1xz#4*^d+#{g|QaZbk2YHa1}&!3p*ho%T7+tt4Zt+*APT=<ke<?B&fgNLJksckX0LpOG&xTviHM&0vHt'
    'TxKY6I7|K)1G?!;B8gU2%ErpK&1NZC@Cf5S6KgO7d(_JwM>=9Bo;eY)H<QwS{>K60t7{3_LcwHTjs2jKAHIW>T54+%N3iJkhv(F6'
    '3epoIf%&K=>yTn-E0f1RyB$X`pT(=xImzVWuXJC$-y0&0lqWIWWUSZ7I8Wnjss04(1X=RxTT42Yw$0jidd)-d(0+OCmNFdBw$8Pn'
    'V<3Ysv`m+ibMT$qMCRSqtgcSbBJF$CQTrXNdQ4U@NQBZWaPkHu@&|^Naqn=INTU)M-}^jQa^v60e7-ECa~^qOK`GC~-#9q|dK`#5'
    'Od<LX_ep+aq_<_W8qMQ*Fec&N&6y+svKH}prcpn?eQ^_8slT}P;h=?rzq&h^k;T?NZ&DikfByYkhmp>1cU#!!{5D>*Edf?N3>qbI'
    '(@Ty2viI<^7>#j=i5;1q0K16Z?LGO=Cj>5J1_)_Nk70f&IwtEY0}J&5`tCc>$@Z|2l(QcO7_kXa-;}`S7XE(VCP}b&JcN>8DQT)^'
    'n-Tp2PoG6?Py6-4awHy#S2#&`l8lqkpYccpk4L7gfz8!VpA<H;l}vXF*OJ#UQix`Jlm;ySq#B2fZ_p#DMGz2jeZ)b_cVwdGX(*^A'
    '9m&Uyf2rzJl3fVhrZH{K4vL=1EgR}C2oq3sVKQ$#t2~ogAuAz(7TUMqOt_EFm0FPfNpmS$i(y@}e)OT94=x05eEsT-31y@@iOjAj'
    'V{+|E2C=~*x8x42d)6@oKBfALrT*tsBb=dj^?5q?cb4z7ahw=l8aXGzY1ahP5qk|rHa@Y&&m*Ph#)&tzF4S1D{`5AY+m#!~pH-zy'
    '{5=t^-<TFmm)e8I@Stvp3|*^q*d*|mp+(;i-A$n?X&e3Pfo?}AXE_-Z^aOoFs-dd?0C_6OA*i^47v?K(3c2uq(tE>1^)nBHZn7Zh'
    'EMIM&D#$64W*XNgnlm(*khp#r$JFS99FYDzA`K^kd)L#1tQy*ii4zPdv;vD_c0I&fB(r=kTb*N1QriYaOp^}Q-AXEFq7oVzvF+Y#'
    'PK_5SbBQyZ?S=O3RrdtN*-;p5rF^JLdRSRk;(1+6U{weaBS63+#*oOug5wyd@D49s@b|6;rPXkB)IFNhLZ*H1r$Rcd<W+9mDeieX'
    'CEg|@p&d8BrNmqtb4)13Qz>|re`3A@3JFne?X2g~eVzPIX!Swen^MHjhKV#LITwnl5S(Gv;g6U6J<!u|jadlcFr46U7vUSdi_GDm'
    'X0$VNlmAS5`5d9<eLI1B9OnvU(ObVS9~{}my2{vYHk8-@*9*E~)?rJ?AskG2J#v!Cg?k9sjJbROHiFx)sYowKdH)|IzCSg6vB{BO'
    'zQK+%$#x&c;z184&mhcMNp({Su~{4D4&!U0zQtw<DMhW1m~(}U1|6UC?0+v_3;^a-;1LD`2byA;SF^^|Bf1e{Mgqu{VAiph4iMIJ'
    'sN&alI#F-|H_|?xJZxJ^D!}PiUB!-WmBkpl8g172J0Wt~!av;XB5zB8o=v^N<S-v8B3R_k(5gn~i5`#U0s5s|UHz)Kj`7OVj9%KX'
    '8n!)U%~i9OUr42EmKj&St{)J6hUM80%D4s=o(Q*8$i;tWK`5o9=r<yQs-a2!rUjqh&!tHRcFHj@M^TE{Q{iugV$M!%dCQh2j#7rs'
    'QI7O6xw5S7u?#=890%H&f&|X0K|hY<w7WZ$pz50M`e5PwygNGIY}bq|An^7kdW0!fY#q(RmLA#tqW^(O(kQzoVbmHbp1zB^sA~2A'
    'KQUbQDl8@~ql1UFHUUCU+#8GjC=bq@Mq2st4pVVO%K>{9&`+v722dU=<XIqzXQdBhG5XKF^iQ`ZMoFCrc3&<Vepb<VYH6T4PCyjP'
    '(5M{GUv~1XGQzIm?!(=+9x=_Fn9McqK2od!ag-()p54FSiFik;4_QQor7WMAon!9vj`LJ?+SpvCI+Ocwk0Mb;>HKG{qbu;gag9$9'
    'C3~9ZkOEVny&+QZ?hUqbVz@E7b%>Q`>;Wj=W8dmzoua4XhxT^lMqbqb<mC<~I{~b`@2?u-vAXKHMfEsP0)p2sIt{Y01cO_flsW&&'
    '`@8;4kkS<kgnJ`?^mp>Ky=GDa05MWRtmZ<;5z1Vs&$A6t&Wo}Z2CQ~#Pxn%woengejgc{M-aRfE7LNpbh@&B0QIELUNZwt*v&OF+'
    'lAQ!j2nT}Jd%3$WmVW7U|4iy{J+H%}Ceu0m_8XeI(J$RXdj!Rgxu$@`@~gbte8(u00h2r}8p+%2zL?U<qdw$yWd~Q0Mkq_LCe_TR'
    '>zybFFC^1HZBZU{64frdI9_3oZX5gzA^;J)VcOeJPZ-Lv<v^^uJT3_EV?6=J%(bQ(3wH`%-1!pMEDk)M{cS8pKF2x~BTTp6{j&4O'
    'nYO>`=ECXd&J4XXgIVzkenpoUMxVqP<T=_T(5*6+wZ}&}aHJZ*l+1$r{6C(3DurOUZPV7bn?W@22*4lWOACkHvUc+bn>r&%8<ZiM'
    '+)WY*n+p}u)id&hPp-uzD+o8?P0EK5`|3t+*5G6u7Y~_L`s^be=#gqA#LIEb2HL~s8O7`k$XS@$9{*Q9dyveSTfYa(Af}~@*6ajM'
    'I#s(YIbw6zF8Ht6G@Bf``H|}>xM2utV3VQjxkonXU4@8g%Gxww=HL^dy!U1-F?V_5vuBH$1F3p=P*fd~QfhS3=-i00+k#=L(M#LZ'
    'g@Z4fc|ce9bYo(Y&u#lNIw<X^l?*}*wF{d3ehO8tjwFBsgUtQV_TE5Gm=#T!MerRJgrrH>mhYYSq1Y?Kc2rQsef>zpDI`tB2Pj42'
    'O{WBsMWfQ;ZOifI6EaAdT)eRmD)>i7A!}ROE%f+hL8m>m-#*Z_GK+MR#OZab+3(s3`w8!8)U1nMEr>(x8f)KnLSe)2U0py_Q%Od^'
    'sIXpFtk*uPU>7zcRB#!N6;Ukzm~4#>;*^`=_&ZzK5GW9E^dyDE5v1gq>2eDKkg9Fdig|RMl@^2P#s0V(+T768te^$X>47cKUB&9W'
    'zUwxW4GZ`;qr0n8hmcyw#fn081B7(_KtmaD35<{TKI8(A0=Z!z%2hvSh9)eT;)M1dQQU-g5;JtIm<Flh#c$fUmM=2cL{``Y-|5s_'
    'Dn*~tR>dops_Df$7vbI2M8a9|o|ibWIJnwRo5X`TZG?1dOK9z2FMEIpQ;2-eXr@Lm9QlY!m(J{&Mv`3`q$f92kIxRmlnA;|3OKFP'
    'Nk(qDu3Rlju4`w^ORD0HvckB0V=nP<1`il=(X~RBf!SCEPQ!GV4RP4f2*=}K^`Gi>zQf2J#rK?-Xh+qzCXb{@Ng}wzI;+i%PsueJ'
    'J(O|)ZHQQwhnFJhaspQ254(S?6=2*(#^0nw5nKuYcFVEaWE+^2m|Vrx*_0>|N&-$M@R2B35!r!1iJxtSKa%v3HmJh<F=~zY6G%dp'
    'R`*5#^$8M5nH>&)EYv!xh=D+6Dx+rxv?|2JxO1cZ`p0?ZwX*JNmcL)IeCG{n3++&vYq9o{M2+!uC3o<p{U7o^F(G1<!vR0yG>--;'
    'GsCrcjk=@%9q+N7E|P`|D4d57f$2-L_cjYFH;SjLZ4-ixTvlPD4Zh#D_cFx1^{L=w%y-u<v^Hh<S2c=OX^azn++)~FH_dutD-!zk'
    ';^gk7%`Z9DAJ73KjOP033c$xaOtc0A@N@Z+UeU!uhrJmXuFscO%pKMzGFcz{24GDyvmJ9}X_zUW!kwzTfojh8GZpEl2TZp(bQm1l'
    'Gnleji%}d2W-!^#kO#Rg*5xZ^HdudWn!Ziz!*_1tdbrrOhj!pv<c?^6Pc*>#M%L?au*x`aTaO*+MMXhqN6gLSd}Y3}M$5p%dVlPf'
    'p7)}eX<i>Q-URoq_eHF=pgBZ|(m(~AX2ihP5^&{q@XV~P20P$ofk2yD9~0}1$qvJ|msP4f<ny?_coqR<oxg6L+pR3e66YRx+e%>7'
    ')2eCs?X=DmG<TP|DuE0GgqQ08_qn9BlOdN`x^SWh6M3+GkbOVLT!cfA2;fk%A}DiIjKF?3uA}gk26RQnrd+gyza?7`wgSa~0uNoZ'
    'UBAY-3vIRC5R{@kOVf-{%@3)2PL_~VF3?gafatw4X*gMB@;tIz4F|1pX&cvPEKNe20`_KwkZWEae8J;CP;AHKSYAy$sfynX$)v<w'
    '&x`iqU13XO<l?6rF?c&bK<w%NcqT!QJQLCcNC1Z+ol0>1-BZfBl@iHbl8`-S^SrUOPkGiJGUhaw;6&5Q<b=KLLCLl8C^nVT9~R3q'
    '|M79~#-{R9{>ot0C(x(NCYxi*&@U>#q+caWlt_w(!5lMr(9wVI2t6ob={BqwmRJGE1Uqm@eE=MS{YK~BE)SM5atuP%c9pPeLt|1i'
    'v4SVJF}_Ft7<pNkF_P#{@*P4dcTS8nL6DAgAjA!KeIV}-JUvNQ7mvUKnDK*0m4Kni(mTbqqmbojRwr}J6kiJ{%QnDwq(Oo<4?i13'
    '!rA<+_os!2BfQ8v$4KUF2mZJece_S)WgIp~Kqf54+LyqP>5d)u@&H{CwVRf*Vv-Yt_7=Wt8(yjTm?t1abd@=bD~aU%v~vONj*JlU'
    'BPjOgDT(4?xg$G)YdM;z9*(I^?Oa%TQ0sIk#9VVaA+QDHm;@`ut;|F*?0S(=%V2P^D8;LK4)5Hn$s#2)0OCA!dLW3Sri)RgO$}n1'
    'MH3V_`?3;C|10+N5%}J=p)L_J0?WJ`XtXJZt0+BttK>fd$Nt=3bDrnS3}?k5(+YDNKUVn1R&XmK3#*pAHjMDwBXzK_Gtw7+asrGr'
    '(R+W*9~)1A&;Gs+pbhXwU2F^FU|k*Pws4Wp&d~xDkf&LPBUu`o8rP7d=iz)yV+$&t_@#qffETp^>wOzXO2uj6d+e#Xe>#r=_L66W'
    'K+>;$MjTAgBLLcK+c|n3ba$AUiYd3s`2Ai%!j+%zIxcLbqHYArk~>Z=^C;%1VL+Ur8h*xwhdS00B&p(EiZ9%s0tVYgC!LZT3nN2R'
    'xYYJS?>}2}LyOzO5X@3YioO!U1p4!isb&d~))dG-7MCRY!dc~h%eFodIqVzNS9e>q<&${(8FzYeWv8pJ@$0A!BItL|8P`~dSw$*p'
    'tfjFOE+Xny;8d>F2f4gLNJ>YD#^|~-y;`9#9A4dM;tfa$7*y#0y(423Z*kxjR=<zD<ZpoYa$C$jrV8m1-v5>Il_p~^Lxa`li=k<S'
    'pqc^rQSo1epqeecYuYPZRw*Tu(8r*>Ao!~YbkZV58$MrG<%V0yUh>%|_Nb@-$NFjvg3=0-04J#z&P*8r;=|tVs|8fYw$8?o8<@`q'
    'k<|Oe=eEEGpq*g@5%G*4=66S76Z(EaAWIUvQ7lM$+-oMcs~nwYz2l4jfpu_$9&VpoN_PkvNSWi#ZCh4P3F8&$^7Y`b8bHfi+?YL5'
    '6o*ptI<>FGn6SI=0}$j6#S2zyA&LJZ4n2XL+(2jms6A5fwRCo>fX>%n@#l2Dg)}k`wh@B?zTR<v9#Ow*4#9Mr_2~on`E{^8t+2O('
    'sFmN-3>?Dyin`9@I}61#v$P6s9=8|KYipZjat>>Osx>vI>F0Vm$isb6u0|F1&6i?eIb%Q_tiWHoYFDD=uXY!rteKL9Jk=P`s~px)'
    'I152KtZwy#`&~#84`Py$Z&dNIZ1OZ|=S5PKg-imM_p}w<lJCa(CV#*z$a#AyNg{MCu`wT;(QuBMjKxxWX+^4K7CD6;E*`LMwW4$i'
    '3M?fYi>6HKrD<yC^K(neBmTyH0^_nC!oKIac3|_Q9;h&Zv7&2Iz+?FEKSd^r$d+`T9r`5?k&{*oqxe1_ZSV754R)nuhkg&sg+G6V'
    'DOEk5-#P56HP@miU_s=?+;Vo(!{xaIIC^KGeBr2`D@Iu|aVHV747|xf-bw;o$+oeUf#8?|x6#qZ6lM>Zp#cy+qgQ1HkSr`6UkG3`'
    'q4VuN;gu{ylh|!a@`6()*h5`fi-_G1_;MCnDRrm~*D(-BTVM0I@2~+I6DY&BArb$?Ag0!@s~81w-ws-Roq!h}i-ps=Fgh8Y2o4nI'
    '8vzme)$$&fJWHHgaW<MNLOlh9$lJGXS-+(~JtXwX2>;}X(JhT$nxaekTg?dkR8wt@rYJniKJO${jKb|rZ5S9ZPV8LK5==Owe=#g7'
    '05vP4<k(qNe}7yR)Z>GLM9EXK6TUMdWVDI+Su2w{76feRpT?A0e9|hh4{h4@%Wbe#Ob}l-BMdHfxh1em!;1nj=D!#!YODY-+R}T6'
    'COg6;+3;pa0S{7Fk*-ET75nD66!TU_Q_A3Y)Z-fU1Bz^Dctbs88!BJwAl3CIw#&$ew7vrU30vyxYun{}u!;GXhjp;?0(y6X-kbbu'
    'W#8~#has2uT$oMrHlOu0O_Kw`{=!&>>MV>i1$`vN)VE-x>x%1G)PpPE=IZ<~6sAnVo6nJakGQ)PUAybdiDG2DN(Y9SJa-eFZkPEt'
    'x8mgQdn!Bu3CS3T(}4~!PWT_4eS8(@7{DI;lsL%$<C{Y@URESnTQye10vOfG&P;c|k6gn%6cOE*28KRS+-3FdncMMLK<+TxamF4|'
    ')DJ3Dh26>2lh)-oQ&yP;S!F`QJJMr*MvNEg;xp)#qSf{eaIjacAb;dRf9b~P3_}93NQ|RkuZx}5#K*Eq^QeiO%^pT}K_MjmB*CIl'
    'Qf=0;mV+^hN6bBf^v7nE;He#WV(ILAKs>y7NgnNe?kmSsXJ=jZJ>la!>az_c44aX`P9j~Rwt>-$sultLJp%v_SxHd$t#lMP1e)C2'
    'gj>k(m#0;UAr?g5OPFsJhhasPmyFiAP=?Bi6P@!tGHLaH!nu)o)J;M|bsIfK){IR_DpwL=e8|;m<E&V|p^PtqQRFkQRrlkAyW|(d'
    'S?s=;S$AtDSn|fO%42v@&J&gBviBy?3bS3Gs7F=X+NFm<*ZgjNraGgjLtmC<c0B}OmtEyNA-Ki%d(@RXzaO@Z5%Ermykdc!yA+&%'
    'i*hftx=Je7rg=|eov&M;!LVqzJMG+hrpQnkb05U(HCe77#X#_5^?@*LvBzK5B$PmOrPbEHLipj&c&25(N~D54j$jRUjm$a^>i*XN'
    'sk`1&pn4>brd4(Sv_C!5Pz$Rd_}vTvkXuk>BXUQ3XG;7`rMq}$sNiR);{OCNzlfXD@_GflXjK2yZMJy`aF|`1viyOZbRzNqrmDmM'
    'svho1wvJr7FfOGUicS!}LUNMQuRKlbp)ks}rq2iA+)8XGdoElwa(wi+7nJen86rMHzr!JBNUt0iwjWz?Y0mSKT<{XcgTK&3bvYn<'
    'Kj>dWVDfv0U-w~tA$OxS*V*q0T=Jqq2*~S6qu;wi5^7U&*#1ar;S%XrouE2M8tsJO!5~_yK@rp6ZI@Ah>!BI}l8?6hude0F1<Zj&'
    'cGOCsj7{$9;7IYA8<7eCO+hT3-?r~-FlJnt!ITtK{je;U8PY&h@}HA;6`meBTQ^YHiLwUQMv2$D*>eyAU<#;vDn3)Xrbg4Z%VMN)'
    'o$VYE<@nTg0cjb}Dkv0A>YI|UyXwH!PiV`|F1$@9V{{w4q=PviKszd+*4}Nb+gs^m?wa{&_s=>{ZS1=nrb&IbaL(Q!F7-7c@#i!s'
    'O8IUfYQPj<kCuc#wrGUu*vihH?MszU&WU}9#P^dRlI_t^(zyf3$nIJDk-PD}2VSD7(@tt92p;*H7Q6u&vS-~qImOb$hwIZ+jxM(;'
    'z+H$Z_2r_I>3oKXw=qcKbG|`xy+ms>pdH#sI~Sj*wryg@YH(aBw0b5b&CjmGOo;_Ne<nNBUv$a>4#D6fP}mC#u`{5B58T2$<esFn'
    '^2aZ*lH4YwzasY~@CM#4sXV#!*#D8^!~~b%qQ@u&K#5FwE$p66u}Ew|yErF!2#eR8^y*htuSefZpvw0FT~Ab<A^WH)jU=G|Gs9Y%'
    '+w?iem!PLHN3hluzT>i9<%GUcc%R^Ad~J(}VVcmw`IlpikWE(o%y7J3ltwC!o&UtF#>Rl>yM#bw*}9md7zwYARTWF4e#74@G_8A;'
    'cg0zj>8gA>QGm;fd*IAEw-XNpK~vfWzP5Yrb{)g86fq_BrlrA(w3QV{h@xDTpgG7iAi9+B<j`fr78uXC4|YK&nkQU&4-MG9uo+G9'
    '(_!7596w(O55XR)&FFgfccSM0K%}`~jlM<c^CS)#pbse&RL7xC)bc}bFhEfdM{ylZPUWpkYq42d`iBo9o36(RuvU=H1AM9P>yWc_'
    'pIaAcJpNZ8f}BJ0I<XMJ`MuTjxoTk6j@LnGnIIe!IikH%<;bwT>`RlG9J7N~iW-3Hdt_|`qjP_{p>PXQ)3xys#4g}S{yJ;~6e5L}'
    'i#E*wHRhx#BilRIgd0~vlo@HZt`4($s2vLv#4U*A3N;7n3xk;M)c<CxB%JFVmTlCtvt{;*^qb#uo+<2Kam6Oz)tw?59B~Z2Y@po8'
    '`2%>AgW+*(E4dvcosNq85FsBbik@IwKo}aHIUzbyY^4&<1r$=T(GLM+@)6Dq%H>}%I%!x-BiMT<p8;)uuc)f~r0aSJEK!Wr#yv46'
    '&N}Pf4)t9UDN`!2XPGD!MZX*q{t~m+B0f8e$RD1)!q*`DH_RF`b6rCx`(W^bzyG8}>hloyAJ%`EmJpWSggLpJQCV@BK5MD(ws3x?'
    'ULxe*B*zT?s5^BV0sDi#%n=V8*n(d$J-&R$`y^(nEZ`hlvxEo3fr4Upj&i=j%jXDbBmA`x<aq~Ze1_Arh-@z)gHwO0=)M(EWDBW?'
    'I{0QLyTwU6IBo1aI}G!35l@=+zZN6>7;N06`h@+(fAZj%oEyq6<`Sg-ocKLhjzwXE7R2HDD;-~vAdJ_AMU0)o<BZ~`ZJ=T+2$~!8'
    'myYZo8o~;~hGHP0f_*tL^MzmMTlzEs#AGzK?mjo($&`t<0ddf!w`wbRFW|c$=4%|9u?Y}+;Q~MLaLS0<)w{@|?t_%6_mI_{vL^iy'
    '*A(0OR8oV{H)Ag${1Tr=r^-5Kz@Q-I?`COHAZrt!KtZ|Euy?@~fA!BkA^HRmd6ZtPmf_Y`Ou2eiAcGSn3vA00g8N#VN?1<Y%vw9t'
    '95i&SmXT&_(JXWy;i8AlTQM^I8|(98@&R~59b!dGLj)h3*t*Qf55U=uoTy^Uy_EUSN&ms~g60F;{&gMr)OOED_wECQI%JJ>ZW(Qm'
    'Q^deLyyvsncrR;?_FKVua@`JYYzzm89ji42Vg2T+x-MqF*0YtRk^2e2;>^Jv8uxFStvaNKg3(Mi{FL>T4m<yP4OTDmGXC{=Ayh2o'
    '<tSUKK4(rh`!MA`==;bT|19ijySxC=a#8bJ%4hepEbKzLcrAor=*Pc72`rInDl@#Xb0|_%BMpb<Ii_4k=6n8xd)A~oy%XZM(s{fQ'
    'iUMC<Um$&sWzuK?fqNA2=(<ajg^*6Y0ANin%<=+h{QkiN-b+!3%tait>XiMnuiy~3fJ*v+%=DJ+VKVqSevg3Pf6Ealyv~|*N5vj7'
    '>09)$p`!t)94+Wakhmq8jEI5v<yEyO%Ks`CGGb)_OY~q9f$96Z{jzJKNUxE_Bx9(9iEok9&n9S+d!wXTk*_oX@+wdO&I82_E{TV_'
    '{Q;m{G|SWK;v5bXJ${Nj;EU2Mxl;SyxD@Cdj$mO*uLZw8VMp+7r?qe>&MxzrjjYy%1QhG`1UHFl_yxf6_$vMH#Y4j|o)kXd8BCNK'
    ')bau#G@1}D^eH-F^%vDP^{Iq1j4AmK`!vQD6`R=UBek2Pl5IH-gxV8cUcCq0igJF=G=TRw%|1Pe))~`jd>dXEg1FK6AvDtqcz^*E'
    'qGU1Ee1D`Vst{n69hS%^ON!rNO(o;L1l!aZAxB?8V=&(P$2z%{c&D?6G%L+X0@w9Xwj5xzinZw;t*gvw7?BkU5G9z<7&c>;kwaHT'
    'atGjOnjLwLUKN4Ajlf@#N-rCZX94azU3y{X3CyXF3lLdqTw6)<a5vSy;|}tK+U>8(vjLoi950XW(7UR4bwQ)s{cL`?_er>i`wbne'
    '>~=k}W*>G~2<@WO%b!$2s7tRtuqqG~Otcp`Wyp^r$9z!RlJYdql&G4|)lR<uJ*~Q=gn0-;JA58*sQ<}c&F@a<#&(IBUGwL_Cxl#J'
    'K|Ub_jwwT&`4&hF59SkG{m13A`YgsW+9XPxI-^TEKx*ao89ZyxMCv$rpnIH|nM)a;*lOHdRy#W2H>2O+6QQAuI+e`Rsw;WL2AxAf'
    '(ow|&&52gPB6jfl*f;3B8Kv-9;EZz(ve>JGZi6CBvFbrl^sivF7Dnf#Z*mFIoSmTZ8{5@nghgcd^b|;talB!3lR85VL|_ooL&<Y&'
    't(cz8s!hu66F|ek#gHNe59!$FOU~!FeGYh%8K8n_YhltKUNhWP+5creS$0izfB*~00|6Uk`)ucCa@v&8wjIaIn`f~dOwoRmO}(Ly'
    'Zx=TNmmCL{p-XVe7oh`AgD1`=<b>)`onq|j_NEYLpEw98)R>5P4g`P|j&`$OY@n$ylmRPp`kC!q24YNCq1qd*<D#wTIXHA-_=46J'
    'v9@ozhoC~39e?<sQ)1h~_IGeBYQBb{EGwvHk7Ywg$6?89>?^Q$^#yI{QN0y)lMFtB-q2pVYo-d;Cu_}Gsqlob*MhMSKDT=UEK^zd'
    'Lmf7i0rjgj#WOdMza@_MK}67ctLZ(}#XxhIJNCcaNm@QBLS<sb6><<&o0--B(vD4n%!h{Ps0rU}cMS3z%Td%7?+O@P|MUPuV&uWn'
    'wM9xJJS_-rs%y+=bl+z1M);E1J)Y~D9nHA{`6IQM0{bq3duN6e4#%ADWAZO9jE*cQRr2xIWK<*jD9EL;YG@$TwKlU8P~<t8A~i*G'
    ';jy?FhtpPg*UhUU8MbdUG^$<fjUm^N$74;bM7DkyE2Dbo)i`@gHoCGeAcgodE*mo*8G|ThDNA#v$K$2PwW9NDe0Vr`$KfB*qGe1@'
    'yUk(&1A~*^K5i!Rh}G_Y-xB^j-=U7P*N0VRz1dq$w~*V3BP1DqBx`V4<BkNuH5?@6iMK@)?qU2R09-GfW_lJ)er9M!JXAl5!Hq*u'
    'ug31Mo%<iTJ1YfyV&kdy^>~itrP=)fe|I<U%Sl9^zMr#~no%;!d}B;0`s9n;q6`EI%|-Mvj*l~II^kw-N63jURtIqfA7$MSsl3Hw'
    'XCVx)b8`&*^v(-51^?RtQj0|7s{=vWOPU=|;Iq!Bw6zSD&pA68e(+oRgtY^@fp;@PZ)aB8m9YyCHHZOq6X^bX{T%2xJ+N!*ZucDd'
    'lsH(zo~&PCrg{d)(zPP{r{?)Tjd!BgA*v9Sj`|K=`M9!BVccwGpH&n${!_~E{RT;Tj14i&6RaL47fdWjJ;9-l+;<fn55Iv@S{V}D'
    'XAzl!i(cT`Z0&p()C_t;*Teku1m6)kRG(#JTo>lYPaG}%UFES`^SG%D@xulO_FCg!RWDI#F1h0JliVu29>KpW73;)WyuP2}`MN{c'
    'f4~WJmMbezea#!szt$4+OW?P(@7n&OJWoJmqd3GwFJ;6v0d&liIJLXDcMdPZQuVtmgV6`L7xq#FL@nD&3(il!rP$`wJPl2-OF&@I'
    'Bc)yHp6iBZ6U(!kS{w&srx~j93~er|P9N)=!_b26V)Yq2E-A{=sNm3vsY$p#pgMPDLc5#P2-(-6F+d~k`<W*gJF(zM8Ib{Vo@>vA'
    'J$)w#`-%kIIoIib+X+;Q6RNj4%W%J%$Cr`1P~$?JojM)+!8=8iuPbtC*TE>#?Q}q>Wrw%=1+CM^pHtIJgi?%s>`W@6t!LxK1sxff'
    'AM)}2b1m8);5maq_ca?a+tlrrzMIFLu+=B+AANi|X_n-obO0oGpME?YMAF`6lJ|;?<y;$nS!BuOwtVnLZXrOTiNmIu%vI`J(bE#D'
    'iZZDhk4mqxp1$(mQ?Uc62|&GR=j32!4Mdxo=d+h%w<rjL|M{qi4--slAv6Pgc(41#S*ZFFNFJeqY&wC=_{W_r2UkA<7dFJpWJpct'
    'Jj~q-d?NiO>eZK6(lahX(+S-ngX^6n*np!dO&}|UpIXe7l=0TX1>vh}@@@lc?&}RREHI2Q`#`jZHu5UZ_Vfor9-&!1*^>4I62Mua'
    'z6R#$C`f78I$(?XSk053^-=0_=jTkx4qdRq2dv~q0+wPsh@HYS4k6gOJJ13=NimQA9%BaI03AY-oW%S~@E-c(CKg$Rr)g3oz_zt5'
    'ewsN@?kYk{2HdHBfl7Pmfh^fB#!E*O(gogq(nTE@VSY?1m;YHGm{kb6xo*mxq>__8RqDZ<C>yOFn%SwXq8YnEqU=LhODBq0?Xe3T'
    'NQZDXKcL!^4~<!m&S$r((f2Eo)F)2%>6x{#_D?->=UqW(1HHN1d%=VJGqFQOV@d-Qvai~;9ghwaS`O?7EkJkq)#u-!NjYlXBw7Wo'
    'zPp`?L`J5Tvya9^h!ulmBCVy5vaf^6r4Fi#xe^ID9lKeGuK0Etp(H%K(ccwTvk!3#KKsZ66A>X0s~$J*t*l_wnQ$<>V@uLjJpC!b'
    'Zm(?#l^iv5=GBi7X}O3<^baH>GAwfzNIk?#x?%3FZ{_D01u1+Um0rz1PrF{*OPUO%Kb0ToF#sN?OuUF0iTEy+YZYgDuid!oWsAM9'
    's!%LOk5lz=<cv1TGW@6a=Epio3B#O;0GglfW8W7HQQ@cBUoFFuM?9b;s)yv|0>)EN9g^k(hVM>)zBsOFey5s1xHKBbl&W_qvnj$z'
    'UmH4HzPS?LsY(faK=^52T|nJz7Y2+lZ(iQ9_V%ud*V6MPnm-G1h)YEvIaz>@JvJ4HEoFp2X46kf^I?R9E|pghhuW49bbDy4PCg6Q'
    '(ZV%07mG`n{IJA$J<_Gs2Pd(P;_{lwXRBaKdj39qVjg&7o^tjxDMRW3q~|ZlR`U``|7N(&EPdLQ(vwDhU;3XPt(iA%642YIFHkQM'
    'pPzF>4yx@<58{4vm)C|zvLC|RdYdWi3CJ~}631q)7Xi_GXQ}U1(-4({buspLZP>0uc59YZH94X}*)}?Y>=o#Pu-1cMScB7qV*4*S'
    'XPURdq&h|mQi+8wDr&+!?Er9vH*?6|MYXY9yIu~lkeQOw<@Eb0w}j<}`<cjifZaoeilXY;o+g^5(w=bZi)s=EXUE8W>~bQA4pD$1'
    '&BT9f@n4aT`!Fw`LD1T+kbq%s4xxQ9I0BOZenqHQX5UO?c0Dah(8E#iSD}p)&OJyLqUB4h(6-U0et=wqD~v;YgwT?wJ+c5v$(!EA'
    'bpp?9X=_>Li<`C3leQX^7JT3_T@?w0OD2~zMocfRA?=4y3u3J+lQzz#^oi=)TCjr#zGciOW%oZJhKwWPVW9_ABOc??G_X30&0Mc2'
    'V<cTL)%N70^^1&n9)bbD6TW|$^1Gw5hNeI^HoIyGR5<sD|L%gT&9ILU^f>EZuj#X$;Q+{M=rR)AGKygjmH*k4>u*eWjrJ0?f)Hoh'
    'e=r!>V;OKiQTLDaQ()S|xvpPv`sBUsS`FCl;@nmOGGpHLa5HNb*Yk5a=FaSj!5G&x!A#m6`T22Q8272+4EE5BiRH_@)bDGdlC&7|'
    '5DLw(Tm_VMXKDK@+GC~BMqRx0ge&OwGhVYeF^ur3!P7NUI#gtON3<TEJE8YZgpVN;mNG&;l1xE%R<fuKjdSBtkmbBl{dTdIc>4Q1'
    ';hO4U=<}(_)Qq+~YDqv0^a4Vt&d!(Sp|WM-1T4|w0w`6d*b9+vAY5#meqcrvqfbuI{xfo#CiaYhD|aubb3`rc>f2C}KHl~hA=Msy'
    '_#UB6O+Wb|i4{<<1pq~uP#OggYw-KV2YoI(^mSTqdgTN2qT)&sD7q3?N$k1iZ<LwRJr}hUI@Cq`q9_O=lB9E6V9QrcR9P5$h4nl}'
    '2b2Y69u$WBK5^}7AaX9#1e$b@9UJ#StJuX(<jrM)di6vra>YV(J?zYceB^N|iMZ?7v5G9ib9^7W7jLCUaBL{tn(piXOxEts_4LJc'
    '^}eL)T_n@ITA{ezHoE4u7N(dVlw?2HS&JHOYVuax&zm>@;ULp>=ZRg~&+_cO0u*ok1(@xWUHH)JC@tT16RG(s=-&k8uoQBDjs3A7'
    '>h0A*)FCrizsC*b=P6n@TbOWpS!IBG8g|u_$>}@f_Y_s+OF7hRm3+#!@(CYnxGbNB1Se+Fk-Mu>um$0E^(({X%ZXUGzKcq%ug(ts'
    '^5uK%*Aa0LYOXr=t^<UkyDHpOD1hwavw`FX{I04}*T8@|Mm(C{P)t{sC@2S=u@0b6&{aFm+e>%Jt=%D)0Ln$(#;qvJ;tAJ#wlj@b'
    'hJ8&sF5f7gV%apUK}1TN(uO3TgxPe;k_lutq#N-+U|u+$8~7iVSfaTw=Dfd*tyT4daieGG`B<_(gBOrZFU>SmGs10<{_G)o$n9xl'
    '>e!H#%}L>eX2~pZUKYIiX`!0sy7H6iIEUl;Q*LCiGp$b=S@;vLN<)iw{zDvV#|F^WVrCIhD<XSl3w$5pH^&9??E~NT0i=x^nqpIg'
    '71bjU_xCivL$1j-z?|Ecgsg;P;Ly)~n7Lq#({(X98N{m^LSTMMtd=*`b^lLoEZH2_FsLQJkYGwqC#+PhfUK@h2YTcLJ{nNbw`a7)'
    'r)XU^Yit#~XvJU~mJfi9!ANTmWRt>2_WswfR`TvNjrew%9DUw(e~+NHk`kYPVT&Dm%FYu>F^qE<#%-QPd`VE1lG~=?km)af0O3mL'
    'oJP=mRcp@cg1GjoiSc&IWux@X0|)dkW?E*H8NM^C+4l`2GhHWIV6G<y%d(g+DLA;hvQlJ4aKS}BW|sxKu=Z5Vwd{F~4au}O7)-W)'
    'R*NV|-pg|Q!7jv=R=D`rAsZh3qJLvlS<7QbFD);mXJxd~Vl9H^qqFP}m`l~Sq^M97NGML!7Ksc(YsmI}w$p&&tnZ#pCY(rRjw)ei'
    '56QK^?TMn!{w9eDl&fc&H#rMIq<a4K41H#jDa@(yCEd-6=08I!@(Uo41U@<`l-SVoKls<AnsIG;MO*_puMo6Zj14W4)R4^qbr!PH'
    'ywpy5r&^F%om0vt{`yY$B8&F5W&=^Gh+%Wr@V4W(ioOW2dZLip-nVa}(!MJU9G5%aa_OzqOupJM6XFj=iZxj^)r5Vj;(NzQQ(24u'
    'lPAvLo6}N3pN?r%&<%X;qx9}<Q@_1}8oTnCA0%?>g*8?MU!_rV5LU~`Oo#pv3_pBrvO?nVn$Fui!Fo+y5~MO)>Ou{GWzo9B>fPJ!'
    'uBdJCN^2o#2SG{TE!ULTjX*rR26Sgyy8b|xQGWMl$v%w!o6fuXnT#R8Ceim?bs~1ZyWa^9{=|1ncZfEB(o=z;q>WZh5~07^%WL$V'
    '3u6a9Ei`ecUc!vdf_&_&Nm!@hF5dkshfZWb@!?!VvKbD}&|%;mdW6|YQ?96IOuO5mK+~lm2l^jJU3?!mg(^AsU#>@18|ZpGaz>9-'
    '+eR8cAA@NQr5EFJ+j^4SM5{3)G}=3~Sm4_g2;-ck_CwmU3fAhsm1WW;Rfnl722oDq|BsLEL@#05e_NVTrSfx%T*h&fRp_Fvtm~j-'
    'rk>7ok8U|3OhSrDC(G=8GB<CJr@p>HZfWN-cGA0LqaPm7lURMB(kCAKDp7g^XhT7_qnrodkL@}0`an@Orsbk-Ro?|?n|<Sb)K{52'
    'oGeNqtZ?R!gAs<+h}S4Q-pXH<-+49IxL_L0)(TI6_)}cfJ3jm4Ix2x%re>FvkULP%ezKoZIYO9P43v)9+471i6<73HSxXg81Jaog'
    '%~$=Ur8K}+KmKgR)-hlSF($o?I2jb6gjl=n^9({cbU3Sx{#E<?x?&?P0?8|YPAE*<PXq)_M;8F1cv2@<gO%PMGX%igN$ff0q*b-o'
    'xN#T(-CK(&2d@WV*TcxX6w*0I&e$w8((+ny#3nXxPITN`jSdX$TrG3w)%*h_0NGvqL)<g2^mbheheg(eL0>MH5XGA-y|TBPnG=P|'
    '>rgL?3JS4T<Nm@KcK;FQ_-IsrIh85Csj+i&{!y-|Y(ntRZ&p2~E~56$wm(mBWWFgjwZa3}LC4+e&HZQZ2jDus<*1!4EG&d%=0>x^'
    'FM}Xf>_zK}|D~6nqW$>uXi@?X2`RX?gcnuzh#_<BlH(*}&l5SMT7P7_;Fxm%D?${BUtF-ZP*oBPc|Yj%4bQSpfJs|gfVfQ0BplaY'
    '>>72YTSjvhz>u2L4>49d+4r2j#?nhEO+(3{cy1)>%Xtd1rg<SsW0s(`U==FY@!%>hb4(BFQ)Vqpk|9ypqOM-1K@m3u<ntHfTCwc&'
    '8~}v}p0e6N2=yO6CnWr-1R3VHR<Z^vj~#GSEj?w%8Og452Y<Xw{3x&-wuhK>l2-tGsct2ZtwenwPSGyw(asgv>)ctD@sj4-o}pk0'
    '?MY9#E;u8~bJiMu^>`QPF&|bG0`@B4N+32c83b#s>Ymm4Ve8EW@NQ)$=}Q(S8RDu~<4U;J)#{qOrr-Kz%9yhFqAqNg7W29;NONH6'
    'j^-E3%lz|9i_c$dH5cX`G4shi_B}E`8|Xshxm-_S<8XMCb&RKUWF7AJkGwrKy;uN%Wn8rT_yeux?lTGvWl#~n*{UV#^*;Ind+2!k'
    'Avf&ye+-&7l|`xhw;}-7lAg1r4iGTqhRIB~@yFqV+-4p=Da|KLXSkAq4p&eF-*J;*BZAVJhVf{du@AC)b(b|(&I5~QHLIN)2Y$f-'
    '_j{+XLiaK)W0G??9Xyo*G-J2%L|x??P_F>)yCT1m*8=}*Oq2Kwe%#j=b8$dPey-Mq+cA3&n5rzK<(Vd}XSvFxWH{{GX3#dpHo_A3'
    'f)m3yyNl5}D2j}joZQi#j)rI#R0%mN5}iY4lVocW3uhwGWR|N;qXeh1HZU%<VfKNJpOyYE%vY&|Gi+%U!zzR=L`G0PsephzHFFZo'
    'x;{47SirTbQ@aAAuspU{UN+24b3U|TP^1HULg9=%h8$wzOI%C71Vs*p+iM(we1{P_J0DdFk%S|<PxhK>Uz1lKW07GUgTil{Ye*qN'
    'mU?&<hhvuj<{igr4pSertdA3M<{;U#1eEMExR(z&^o0+ZMmbDyFQJUsL6@l`nWlV<*jVv5zcO?mY{-+r>B%_62$G>x^dg0AmV&Xy'
    'a2?AI%-RX#35E@1^J+Je&<@$~+>=0hEl8{$2sV3+y~kjo%lknsRLs&p^x}a)T%b4*$536tI>gqX(D0IP&{c|Ni%<qu)O9|6VdJJ6'
    '6ON<`a|ljwS2%WWzVnf?>Si^ayg-l)k%qMVQ8q+Gc7?}k51IhHWVYQptV%qP7Vm{(<_r_+evzJ@_XNp6+H!u`90+V1jhMnlUg-|6'
    '6S(Qw_6OIYT8#?19h-ZylzknMeYG03a(EXh%M~V8nGEyPFj{>PxV5zUvY|^_Cb57`&+%O-;2x%lh=SKycsLqJ5kX$6mQW0}?nNSe'
    'KFr5c3%t1G?qRo21=B_VBmEq}dIU|-eK?L0C1S^h(Xc(P3XRCm4skDy9I!TSQ--JE6+#pWK17?$O(00d?mGMlj!N|ebcVmU7(L#O'
    'nTv&ragrqp%j5`hQ?a{z_+Bp`a;8|>>uga`ycd2#jMh`lp6-60UTkpN+xUvUc;>Ygb{0FUFCE<w^eMc#=t*qy{~Zf$$iL@Hl+%#r'
    'Q80~zCV*=EMQ8>+-r+5m+-zTyn-C&c63AuGip+W|@_!+S<V1=NIFA>ebmr6QUd1Ct{$lXkdtF6Ng0xp`?Wt<U64Y<TT^LR{l|lBN'
    'VeIp9Vk3P1$jdhXYI9Z#lPAtka0F<+&)b*Fs^*`fPJPE?$Uvs{rVep+!9z>kjnUB8LZJ=sae~H=sN4N}F%-1oI6~vNy*%$@9J-qN'
    't4XkWOGktgV-MTs4F=d-+%+S^%vr#f<uE)!vds>#-{&J{<1`2#$t|j9wM(8gVem5VJOnv1oUVhcJ_khh%F8YigN%zD5aG8-D_?&$'
    'm^(HVBHdMwL48zm89S$en(B;)O|$+A5Iw5!Oz=3wIc>Ry83jQo?YF+o<9HVVD!*Xy2pCwC|Hvo);kJa<M5WV<_CZHgm!}9jPhkru'
    'fu#itGyoy>Guk$Eix&fC)j+bJ?9IA1)pm-@5%R9jy8s@C2`J{8=uMwc``QFRg|3@=a<kN#dJ)Tf$N!!Vu_ZJf_h8}BBJF;Hz;vN^'
    'i_KHSWDeHy@($GRodnJIy=8YYoWra~6!BFNB=RJR6fNR`X`EfRJ|qs2hFjO7V@tghLsoinge{7pqwIOuiCjNE5)L#HY}!gBN@{r6'
    'q;h*G?qpq%AxI;Cw)mzSa&~|h1A8{EW@4T5W4JHU<F(d}WPgJTGp)^Qi$I5CNeJ{%NRi~(7Tq~_UXPq=<;Ppo+(R36$iN;F)e(X6'
    '?rP7b(&uWeI~iX_OuUoeX^VKVONmm`LxHzsw}ff_LUx3weOM<0;uQ1VzW4rY(z&>5rl3Y+Y6tUav*a0!yqy9~N8)UA)XSRCi>BS)'
    'k2&<oGwCndWhMTgu)5r5(KoAk#Qb@0Q-W0mCcjy|?Nsav?&aIo;sPT4<j>OC;Bk{E#%_azP9K`8tD!Q3)WvV<J)jt#4K<%RZ<eYv'
    '!~H!v)Gr-}0`J4G|6h0|*-)<u%ZDPLT8CNvQl7z%d^=pcGMlm!9BJYil~*<HIBe%kgJ~EHId5@RsA^nJ6yrKez4M@XuNYl<q<{>F'
    '(Py`?bKmZQc2bKW+cM<E_Lji_`tIF$%QJQ@j7EROp%yO+;lSr5$6f4R=g=#bdhL4SzGyTkI>Uo-ttHjYZD*oZYVo~~e5kNvUV*9g'
    'Ee0yAuF%j2Qo)NsV~h~B%M=gww{T7a*V_!oltgYl2CmVaXt^`608R1HI`5^4c5!jg{-^bG{)L)j%c%>}Oq+YRV+4rRg;aiP?*l|g'
    'e#_cFqZ|VO*Qp9r$x3N!_f{Z@4lgo_mQ{PPpm0z{AwEliRV-^k@5HF7#Y=b#;_qc5ELM1*HWeHx0Kh?%jAAGtX0ZKsv*mz5h8Qqm'
    'rW584^gm%QI0Ew}X*&~rqQg#YR!qWrQNnwo#r_6+mAhR$maCaR6zv@3h@%Ie2CD+!s!HQNBBx=6u${VT6r?wS$MDY~!C~;%wF3Ey'
    'aVpBP-DcWrB^<M(#VJSWc9H2$G711!4x)YZU+v_gV&+#?8N4|slXU2@igt9*<mW&WMR1d7L>!fS%Y85N2B!<sd$TYnM{wNl^-)Kx'
    's89(~B@kA5Ql4k3QCLK+oRMV*`3A2y7(4B{a(~@-fR7)Pe9k;=c7U^-Muy@{t@azoXg}D4evLs|i!T~+Zj>wE#sk;&v0WY8rb)i1'
    'VgK9HU2cv;JrAe60MXoVS`{gZceJ@a{qs25$Lgl?2$?KIu$$lxLZ`3-Mwiz1WY5w8*7oHhOM5$xGd_~{AHAII5&i2c0NBt@H!qmZ'
    '(`6NFt8f(@QnftkEDfOG!O#>x8sFN%&I3S~f?b{?bm%sW)yyU1B5fOMR}C$Tye}4lr7Ugkp3>yxJkLo92=;p+L0))()S?EfvTUt('
    '>yx1hdT=A@A9$RcJVuBHYUQ{bC1__r(oIG_4%et)JtcKby9Gz!)m&yt#rd#%PJbk)vHsdLWF#2L1r4b12x=~K>1Q(L+>o)HmbHfr'
    'U$oPLi$VjiIH*UBC&4#Evb3)P<Z?_Ns|A`q;0cSN)Wa6?ci<j-&}3B%2|gtuc$22cwK4qnNBK;|h;+z0lD?-UAJEKw&p^-7r6jwf'
    'l!euRfB%`kfTeJD^)-Pg6sK_*X?4dIeLKnJubN*g*ju_f;vJ<Y55EwdEMqBgb1V@=PweF#*Hf|>N4)e<yu6i=Un#N{B;Jw%sZUNS'
    'N<V^4)wL~TvAxs@p(c7PKqXM9g3VGYz%`F(Db)POg79h=vc4)bVFrQnSmOo*sAQktEL78Q1)K7J%I|aBa7ZHf(+*;fYYqTMB{;Q6'
    'D%5c3m{@Qsh&M#I9X48(ML818!wnA+7SPY;p>uyl8#`dq%pIB+=x5*%b=wK;q>wAN7+t+-52->Fi}MPz*X*1Xb2~Q)6?(bcJ6S3E'
    '`|J2&QhV5+*_5X^(q=RvKUNJ@8lvNx=j`PaT24|7ptZfX2ynPagO|Vf=^)J;%+)+9OLW9`YjK?L>x$7@A_{6Ap;}RYa^ga*2zOgf'
    '&ycIYqvwo&>KNEbNOE(1KzysW60Lf2kDB8%-;Ehs=s07t6wUi`$pIV`ty*1U@cFk8R(vd8HuV^a%j8CqZ;a0ymxvaw;r?(8npNKG'
    'pGcxJLe&idDCxQ2@|BA)nKDa~H)zRcYp<%pGz8f$MNa6ElF#g}pZ}chwa;fgA0m1}Thw5QP@W#meCmtkTn+zZUEHP6!-9S5wRaE~'
    '-88-bD>22|@Z)@q;~j*DrYlWEF$ylZVy7FMoN@KgDTeRCx~Q#Ly*lqTA4;FdJ~t%0TeyizDZy9^ES%UNa(os0EwT5kD9e)t%H#U0'
    'Wn9y;iwM_HoKjsFtZC~dZ`z=JJ2{E*G5*7-jn??`_pYH2Oife{Xpv$32Oe%2iQ%FO5Y}M4Yxn)J_%pYqbbbIY$8DUJKM@_Ra%qss'
    '|6MPo4?79nF~~Kf?ex|MYx|v_?sqZ}!Ngh(6&U_7nTtAG&%te!b5%Qvl<1kM939!tv@l;P8^JcpG!DjEF*uS;We3#O`l}vb>a69K'
    'wKP@yZ3{i_SSJ@VhFKPtCYWbxHJsP2MD)@gdRq040#7M=1NGZ@D!;$(6yAH^oW#IphRZ*ZY62`zASFL=U<b4XA5Y@8An(?WYc2>A'
    '7#8e7g_=HDBYdZpDEJ27{UK?~(q_o3IMdXvHDlzAVF2;vW4Xzk#7S7_B7WhGs$kN`Uj=f*w%`naf9rs0TT?b-=2&%rUmJLZKyci4'
    'NN8>c;7cTQ323F?#DP+fbV2m9{UMs@;+B$*miVYrw5@I#e&c5vELQ_%I?I(0r2t(*>Ljr$K^;}Q0S@=s*J*V`N;?b$jh6dYWeey$'
    'XLB0Xg5{U;E4<h}*(y6-_=DG2%btsWTDF}p&qGS5aAgxAxC#uB)C<#Qqv$P@CFhKl75x-7n4ss}BK``G4Lm)JIPY`yls7NlytCxS'
    'm0~0KQYGQAe(<$pcCdTrxpZ@z>y*@Q^-$yweA4<XI{#f)aq@nsnbDEZL`P*YEl#!k-Pm-$;W)(Ggz6S6vAt<+W!l5_yTu-wUq<6E'
    '&%hcXtB&FLc;+Ep%x{4<Bx8r=B1O8gU8nP<dI~HB1L5y|@h3_H5gWd;Mi5&vPL0}I`Bbl;&M0h+GB0H4yb_ek{Ho<nt}9e;ByD8c'
    '<4jOETLq7A17U0#zoTI!=sXrj9S@Z0n^6+TvM~@jz3<vMc2r*9vhe_IIuBNpfb#x!A=Nh<(h0_VLq)~D3hu4fJPl7LJ`AVWx_`$B'
    '0SkTv^a!f1Ka!)dL<e{mu0!46cgtUHBH=bSvax+oQ~`cWTw4{T75SxK&vyN%-W+g<zX1(e#k9Wjsm|@SD0=P}Va=B_WnlhNsrVRy'
    '3}=0d{v98MJ4gdB)OV@&{$60((~_e{6;%?_Gn`;%UQ$6X)}6WJ&DJn^WuQgv1xp3=krmoiQUI>fR`D)lVwpdZpU(e;(<biI%hR<d'
    '{!(=utZmK43F+9_yos!UF(Dka1Eh9d)(>CYN!T}wq(R3HXK;9B?=&J9<-HLSkXGc$&<!CX<B-!29vNgV$lm3w`|HdBH=g~pQOfY<'
    'sdj6FKr?IcE=S>T-qw664}Dig2$pJ47)I_p0D<EsRIdO86d8&y%&L}eW0K{3NTQ&pV}ig(ywk;xe2ahnZc2R-#>Iw$WW&j8by{&E'
    'L4FOyC3qB7O_{JD$dJ!se|)e7G;vf@lJ7s;KD#lTj=}pQnE(WGc$mQkqq)*u_+rXR?p{L)3WqO=;rO7gpyC}e53Nq5=+tXV9l-eq'
    'w~9x*dM)T6Hp!deoYyDa?1<tbkpc?9mKjUPX)1mHv408wjYu<E>_`(w4#NelNgfn0^F2^!p*2{f{?b2CMVVYxvak#Qg{mKW!_VY{'
    '7`{zzdD3ZR6D>3Rns&;J$yJN11oiekSU({00lS0xXzruTvA-PS#p2D6W~Ka1CdN){E)hv%dn#i`mz`)!fTnW(ja|rj-ji80z|E$l'
    'g{06k?Ds#3@l0T*Gd@JAfe6$CIR`5vLP#B9>aw-OU@?}peAH;S{sJdhEk|<RLGQUtuQgtCsS>N4L?k5VPeLl}Z*#ahqLIfz8#(jj'
    'n(+9H(r<uTu<47LNDpvm&$@E^Gx$8Q1D11ei|fl!b!dP7vS3zNQ|<M!sC0P$p_G^zcTnzM9>bV#DrLinYP$R(g}R!KaSH01)CZkW'
    'y{*1W(NobNr)Y8rW8_pD<qEA8g8eF>>2IEG)^KT=-#IMpv$3^9mGEe($5a7@;V;Rj<o4*#tM0G=j60UXhiktDeJW$Rdlue!DF1wF'
    'Uh)SS3aC>R%V9fOyPh(#R9o(rXSJO2o;$ipTk%-ybK!WQ$j=ZjFVc={rfx${1`qGhpL8x&(VuqN??HHxkcFiz#%RMqwPBSdGL`$5'
    'E|r!Br?tO@8fpu2CvFFp%*As<T*11swtFQi=ORRkCq;0qhdW(Mq9-axQ(6rE_90~&ILHcHMf5xGM&cXQ8=9j+ZN1PEJfgb%0Ajpt'
    'y26YlfCk%OpU3|_MIe{h_@p%A--7YoEU8MaU0zfc6HbiJ5YB-8#C^9PlSXFWBK~z1u39xpR)kqJ)Xr2U%xY&iFff><Bo$K5n|mtD'
    '+VV`wrka(|>lCV-<md_q$TO8BEpjeCQ#*aYQMRXNQ)VjC#$NbCLp*We{530DRWR{TzW;7CrL4M?6PomcR=ReBP0V@;Tx{p!acEc6'
    'X_vQc^~<|ox4~JI+hbubwaOQqUj%vCGy<Lt;Jr0OGPZ`c#VA!I9o4$Ys4V|=C7XyOB)L+?=&`ai8EydZq)qSq<x|kl)Xp@kh8PHb'
    '_z#pWHq{Et{A;+jS5DP-oYhNoJ*V`<&a-!pkx2Fm&RY>6MpM_tq+shO(|ED@4YX~m4QMRo9ETrwnoC4s&@p%Z5T)Iiq&8)KtHZCm'
    'fgU=yc~S@D-n`B)#^TQQ6ye~D|IoU_Yk3dkI2)A$E9hXHnksQ&Se24yc%q%7cWtVXhmyxmL{PiAaQMN<H*=-fy6wejAD)UzFYi*7'
    'bL56R!yeDBZ*QFr#n-=!B=~~V-lRp*mgwa+jCXb-OwHYOeiKrvZ=)s|$-(?aN0EzG5(khfCKJwVt7g|pO9V^4RM>Zwe=d>TEDBd?'
    '=YhvXX{da#S?Df@R51A1%?lbuj2O=Bx*p&9b2XwOn(Mx*D`g{jpWP5Lv3o3GnO5zC-S$g$_gUThn5f7D)EUY`2kC2J?IL&dL|a8H'
    'tK2ri<jP6c8i^~etz{GWmWOe_?2U|~hHu60hvVVMCQ^ZoLD+v>5?3G2HpGU-N@@lwSI`NF)|z@}Gx4xlD9u%gcip;Wp2TCc9EH19'
    'EvH&xZ_OUx6l%dsmo~sQ(eLrU?&<W!V7j$-cAof^zwp3$>E~K7)mQkawW60-5SdGi+({r1q$I^+SqYQgZOBDQ)&pr}v6o~zYmu+%'
    'J|jbNqySHN3_AAzu=vIU+-u#Tt6^lRbo>Q4o;JQABFB7FIpQhm>yhO!^t}7Mr;T2s;>iQhzHwMTB`XhiOkv>9o7C9hY1p4wd|y{c'
    'n(Oo_P0!MUDhOB7rT|qMz}v*hTxRsfTt+zcypN<9GiCb}lO6Q0)r{5mJ~XX5ftPP7xzHWpG(GO>So)h@_2Bq@=9iC7*7b8!7spmZ'
    'qSn)9bI7=NlHm-ueT&BJ*KNl7QIiI@1D9~H#A<kXs_hZ(rrd?6u45oL5)`^=ad+%Z-m>&D?75`0&9mYkNd~;7tJYg(W2bfCO!3MG'
    'A!s}r*L`>z1fML4-PO*H4h%YDu9)0qZ-1jJu_Ge~@JxdoFlTSca9%Wf`L3dqa)(tAw0Gc@2l4FI_)_oVJ68|TzzRY>cD01MmkZEZ'
    'm`O-pX8F00qwIJqvLy)c8V045(2t_ntQ+7)E1=X;C<9G+WXtRL`N@TndX%AVWpufb-xI#HsfCnOzV4{uRE}=>Jj5b3(KKVb&{Q=~'
    ';5uYL-TV7aZIKEQ=R$hweq_mR)c4w(mML?<2@bEm&JCWxB}<{R8;gwyuo0@TtP0o#ABMaH#Mg)u3CUXnxtl%zG9@Wf(bMQ$_XOg4'
    'C=_=DYkgJBZe4Hw`G3`h(f!4@SxQqZKg-lzbZkptxuE-zVeM@TMz4pH&q!1xotZ`?r)CABH>7#6q{IvxLz>LZ9j7Z-bk<+N=+=v-'
    '#WOnFUU0_RZf46eT5`Q~)PAjj50q?`If_@qWI+~8j#k<Eh4+<tUwmr5KQqt849mF!qM(eYPVFpI7X>YW59cXi6i8;<b(f_=B)~uU'
    'nc2wcr>w*_90-d1b)~DA2ywcLP{K%>t(!8+<>IQlotfyVeFr?^0#m3mEL<!Pi}@NnzMt{kW?Re5UD3ch_-WrW-JK?3-y=y3B^_Ds'
    '>=b^H1bJ1iZdfw+Uo=BQr8c)J7o^utV&kOXxzwO>hMG$T&te{H#dR_TY5>e&mP_h@uOn!san?ts8Hgx2YHItqxs6v2=~zotcV%`A'
    '+zN@V^mCzR)wbmNDv;U%&mkvJ7L`yWaCHuXx|Jj3G&=|?2{B486W<xScYJW0!S4Kjhoec@jn%~VU_Qq_k!Y7;A$upWlK_W2HBGwb'
    '7a*03%Y!acvsYlj%wOnms8~66+}ay@vT_O3q|R2#=Hwgr4X_dG-Jt>>9v4>JyAe2<m#L4M7an`Z$7(G5IT>W|&T_`Z_IOT;XE-*+'
    'S4%shDV}373MSSMNV_uM#At8y&Ygz#_A<!UIQc99f>4qa@yTI3yYx)$QpRKPUZtJCer`Nsh{nC{Pjda4>OGsjeS7+6Sb!RrkiEp@'
    '{_VHb8Bu2Xs4pqVe%djL`Uc)~nDsE!Pql`))T&lTKNOlQ*NbKl1IDI}M`j{U#vaNpBW?TCWs&M~D6KH^mjQ6D;q0V<I^k=iV2Q7V'
    'DRZ0<m(Zo#^~v!@C3r2Fmw=`~00Jdt0u_HLl`OZl!}PGKxa^L4VJv3DnaRTr67#ir&#CVz>Mnd?8PFW+-#a=)SJcf*KE6r{+RBuO'
    'sxz1ZAnL#`;7uqt0ba81{JRhp8a9a2QErVwTQj=&7ST~DkZ!yilsC!r(00zaTndHVlPq*s-WV!dMZN(&>!H((?w^WbXp{gqC1X5Z'
    'WmleH|0VWhzaX4)pVnLUSeYN+J%^+6^H5n|9w%YbLp`%fw3Vf&^LwYdyPIr5H{#CQ?IRsw7(x5r8=rY;TUBL6*S|;$Y9iYzmkyBn'
    'HJ;#OD+bY}D4b>OSTG2i%=?N1OI@^0USSz|H>zoXPwljtBYWYy=fY*>EEb&IucycDDs^paVQ3_)*@kf>TEi)rl^`0iCsXCdD@l=v'
    'k1#jB_bLsXCGgS}V8R+Bp0FKD`pS$}V}`zFZR$+*9K0~p8&13ChIB~SHY|f?Cl4ONfF~3I=zA<ct(}thBd#YX9|4>b1{g9P1fx-0'
    'g|Y6rvRzfv>~~wkj)aP?gI&+XPM56>p$zXHE@Frz><B(c;7cY`hNQmK$RV7IhH7ahJiT`#qZSQ@^^Bx+Lf^ZbDwrlT(8aTC<x_l8'
    '+5dc6C@ym>nuXVqZ0Rm{4eIjo)r(_DW7To+)Z3JxGk*0$%GvW$5nb;?V&ilhmqoo1UrYBrN){QTSfN_H*6p^CM)!lLRzyVj{Z4+3'
    'U=ax~E$pzBzcbJhTKokhrBcpR-S7AOGu@Kg2#6ROEzyDT$I^;3%DUb|2F`YuDH9P9kOLv&6GAOf7(PE;kQ}@vgrYSQNYgNCcJ_dA'
    'FF(^4)R0>0OuOD=+B6}zufRKEPE@R|d)7S*K%S$?>J<FKJt_Ffz1Z(5*!rufPP-UKL{?Lo&pj5J1y+4rkcn-ljL&zrlm$5k^Kr8M'
    'QmAtm!$-AS-V!OxHf>b)o3IXLsp_a>Khg8L#JrGmd<0~Akb{|Khu{nq*v`<BXhO&m#+K#t$!KpMPbK~=C&Y0%(e*ZVJU{!F2}r{%'
    'BVjDA=yaXxvLaL6FXV55nzFpgIafCDefc2)eO*GSB0!qU^a20?A+RiW+9^%wcm-2SkE=>9&v=o-AzbF73~1+R9FoPn{Xe^?dJx(L'
    'Czy6X;7NfrM@0&uFe$#wArh^6=JUd&Li8=j-!KK84s-H;DlO_j;4HBUH-EP9hgx}C4n%hF&(qGYs**u(V3W8)l^tl_P!uu#jrCjd'
    'i@$%oQ3U{RZVV@V-JA%ys?Nv$80Rg^uzBQzCoeNszKfcGsJ@eOb04)~1k7-%R4t~DFY=lzwK1RElVJL!$SI)_lv>j8ocU^XBQ7})'
    'X={WhWVO$SK1hOC(B*f<6-`S)`_(xlF&^q3_ug$W_d?NtVYPM9caa(f36bUncwwMbjXL+z?50^4B-BbCgj}IuC`Q$NQ;YC^Sl^nX'
    'a}~DHvwg|$yzy8$O=3y8jdN-Jp_ngM#?LXSj9pe|f%L;~5Ctt}AEM~JWCi*r+(+u2Lncq`)?l?xN@ZSG8M5p}s+peexRT^jRk$!6'
    'yWmI;uM>iuPXLI?cX|E~d{^5)zD8KCsdC{H9k>{}KVNf0O6{AWg`gaC-nGJG`;tA!Pw6Z3Aln+)Lw~_F-4v)5CXl&&7TcP#2)YlM'
    'u*W&uP+nIg2o1W=z0ruwMhBHtV==gmV}xP%!St1Xw~Z0hTF=zu{pm8Y>A=~(9s+*<-p(+~^UG+doQ}RLar!Xs{ZIRUd~0*Zdtr5#'
    'QHzB$z)@3`wKUUCllIIY%`jMy`tKJpqk;WNeK^x}g;)ES2A+P{4$QPtg@;)dlGIOPhfX`ZCqLuxkjY*el*)ADaK$E?`Xrx!IF0cA'
    '93s1=`23?rTG4Mb;E1MquWY_hOg`kfg!DF8x@@jD!vDW-f9WhGAf8TU=6q+6^zW*`Ga|606dIt*dIsy%IwqUORCMoRlwfTp>jMB_'
    '@+>jWxgrSW?7b}8=QrAX>PB>&^=0~b$2SqdVZp)QwiaZYn+^AhVIBTw<(OIg4Jl7wVj=s^r)-9sBgJSxlsbqkG>1EH40shRSk!X^'
    'aGhrFL{Wo4iS=`R^oAtA9<U^U4;e5O?m?s!yx?=U`{MWNL?8JX0zFN-IMp?n^A8HFoDR!QTFAtoLp_nP?OHBV)y9&BX{`(>5T#i='
    'i!hVp>!Bf{v}!~c*u0#eg6gm+b6v%J&Z&MwusPvjY_be=vPV`<9_r|wtOenIT;?ABpl2bc>rn3cy_x;<Uxti^@YG^ipq}G@khzAb'
    ')*F52f6r>f5HeFAt@bozs9DP}QkDQm(NcDGE1yMgfE5ZCpx&<Kg<+6B1j#&$Ug53bRv2tULOsb9UBA(VC=&|_<*MD^cW$QOw)#7e'
    'K<lfGGAsIeV1vn60%%kq3cDCYYOUK@*m0}*&s7B8ZmRf2+Ev&|Cz_EV0?J!#bhmlWaBbehZ?VFkE_ZkrE3ydg<Alj=&C*^#>)w)m'
    '{!hG|-FrseE&thz7!t(J71DsxRq)Y#oVl1k9yS5Of{b0jbz+N>RpSr^;MD~xeS>XiHr^V`o}57AwI@)hR8K)~yR?nUFV>U$iv5n+'
    ')TpB2yH+KBE7%u%E7k<vOUq36)x|b^$I92BN}KHbFxc%h%=lI=v@BxtIui;LOpmFz(G@%xVIFMNocDSGHZXq`=O>g3`G_sA_$e2N'
    'c#Tu!d8Xx6_8=P>TK@*X{dd7GN4CsZiU+#zGy&&0U4JLro>C~V&l!<SGX!+Yn3N@iYjzV2ppiCX4o{-@i*MOgGQBU|v>*46#q~3C'
    '>Uf}lousfv!OnuV!Rd#>Yfc$}GsKxU#L^ro-yzj4i)0BVkX4dKi8Y&+3d;LeTv#dxZdvA5$WnK*08;6D<Ogh|en)x06^+<~!cEZ@'
    'F1FadhoALlg`2UmV(@1)zJ`FIWWZVT$|c*c>P9Bc%{y9}2OB*<A$MxCwIQjzIp0JjX+4wa(){={LWO*-07_bP^%qe$k(Dw4g=Can'
    'ctc167WruqPaq%QSkh3erFumFnYpmCa4~(qBe2>zJyhd3ZK(WST2uo&4qPi~Y8S0OLK!aAa|?J0bTr^E7G?*aZjjb?Ku6KN$!{Ph'
    'b&d0l;4$^RowyQ4x8T2}h$Y>D9T61zUo9hf{2K(AIS##}-!21(2@SQDqamDm*c23HmghfVI{%`^De=Cjo>p#Rjpf(Q)sjPMu^z6G'
    '9afjE3M>j8pwP%cTVW&fZm5&QW&K>H|B>6x14mA{7P|mw)bfH563^>g&JLE<Llw%w%Cm}UqYQ`$(3+Na@2n!@hOY6Cd`2_t=4wlN'
    'K)CM}bpd!iT}DNsKsKq_FMW|*FJi&s)N{{ujqs@g{+A;opLte_d$<Y{HI~!K_Kl}XZG%bce<2AgKB)&6$q3HQy|s&#tV_LuqyGwn'
    'RE&0||9@Kd{KOOzcUh<!j*&=nwXFLX)#$`%Fji%ehUeN`^<jv>Rsfg^Z45cMmH;S!q$)W5=MS0r<t6w3b(8uA8)>M**fOUlS@I0r'
    'w`*ENpZPJL`esb{PLJn-uu4opLhnN{H<TDfbSX*kgW_7$Ft*KemWj4pEp81~(m7g69j|9=C}XC(kxdiXHTFuoN{F5NPfZ_@>Cmzq'
    'f?7xh()@Iics~7pyc6V%ZjJ+%Dwy}sv5Z26{Xf8&kzB;!_w-+<6uA*aK2rW7rmHYKlM$_0wN52J81)r*hBF~JreBENnWxLi1R)lV'
    'aYQsd*Sgs>ls>8W46TERr2ZOC4)JCLaGTupvOPAOT@i@fmKJPPP=RX7GxT6Jw0-y4;`@3hotU!)_i!fChyFhN=V2C*VS?h&!$sJ9'
    'E|J1&%rIceR8*`*@vUvLp1OF)&V<7_n+PNp^xYsB^q6dIn}gwTWr@(WK`T=E#gTt#ZK$uwa<^P-I?Eme{664OU9{)wJFlSCU+jG+'
    '%Bd@Hlg%ZoLM57nRG#Q4Tl2xY(9Dtlpu;RXOX1Yv%;da+dx>S7woMtX$H_we!by4<n1_6~3>EPmOAJ$$(rxBi9b>(P_s!)17^DWS'
    'ZEr~Z(rybm<LuGgz`!)bW`8tg<A2i~{bo_zB$#F18y{`2xe6sJpU7`qQEdd_J$vm;a6e;mg-UdXcqjD6ZsU=doeT7qb3i!)h!J^h'
    '7oZl4wL)<o13F#5!9~hKt)J>5+t$p`tVJjcB?-iD`3z1&;Ybuh_Xhi!zd!3@2XiGYj0Ft@#&-coU+~G%FlfPFz!>qnblnFBpZi80'
    '8wQ0r+iUs!DoD?(si|2d5~&u<ijx(dRf!aCUixsNr~RctNb?-Xh@6htCCu3^MPH416A)~G(tn#982gMer}~1*iaj9e8>-SG`y-`G'
    'k(pT?<h)<oVP*YH?*eb`mqOB>F0opsw+zVro*<7+6J%-%!YZ{#6hlhK(RJ5@lyhXKdDB$2UE$`ToXEvN6QmH=b5H~tfNpefmw(o0'
    'oy|r+-K=>kv5B^uUJ!BX4C;?<KabP0;HHDI*MfGc5|B^3wzOyKV_@%VD=Nrxpf0|u{dN0y+t4?NtqcP)Wle(7j^?*5HigtnhZ=r<'
    'j{_lIIZr-lP(^5J&zD6vvtb%NZgwQlCdisQ6EL*xog_i6d3mkx{ASTsTVThTM#7JHJ`F&kzm9gjXuicJ{24&EGv488DV!?dS8j)y'
    'Lxp4J%8g2rcW0#x)RY?5@|lCD*l98XJ2K3<BPM8Qp<8h{A&ZPxGpsbGNc`fsia^Wio8mHGa!vJUj*tCvL!e<KdrW3(h7#&kndg6n'
    'wNq9inq)<I1^~l2SK*f?oF31@RF`nheZ<nM9o!?J=sw+C*VraTRg$@YJeiUQq+iM`|7<fZNKxm{N2P(xd;pVG6@(@}zf55%HoP_k'
    ')s;Zw!Zw9>i-NRYSLmm|@=_N=Zxh4FN_beBD#zk<tII6^*E%MChNM~{twIffb(S4iF0r^wSut>QW&mdQGDQ@Bh|L0e-}BY@U9Jt('
    '7~|5Xy_AkdAIM3T|55P5J(xCZg0{AI5D)V}A7Q8~`aX(8jmnQin+X|xS46&#fxO|M^4E>|?GnCQaaeipW|Y>Qzo0VN7)|`%nAwv4'
    'z1sE}5wZ$ZR(F{^$2f#<FB^tim{l`};?@wiFHS6k95k{c6{brOf+lkKCzLyRzg_IaLo{wRQo)rlV5|DTL0EJ{IcrtB%;<2uW!=kE'
    'v6h=k(2rKCTSI<+EN&e>jn)fgd}i=NTBrO))966bb*-4fScJ<^l%f?Pd9!Rbrcc09h2@}*PA<RJL^0+eGQD3n<aBEM*$01TGX?#{'
    'CKZxJl&haMfIAoOQB$cJ_L^cpNe{x5PHvjYOg<2NCyv$5QjzJ~3M*Z^__!oybIbv5%!C~nwHD`RC{xP3Ys9-*7R;?Jp2rb@6&nrc'
    'M3`aMUV6=j7l?>4>h}Z-G34bcQ2ij?4GyOdCJ!B|+geC5)j%&rFJ>WI^w}7MZQHz_c+4Fi%!Py_r`MeZ&Nc%c4Z>1X<8$jORxxzm'
    'Gm(wnpuAlUtGAPbuE*5aX{A?!*8OqY=CrKGe9WPDjlclk3)!(1X90&Ph1nQ}Xv3R%GA#z#8Q+Lxmx93|#QS?{snfb+$_xT+;KGt~'
    'SBEjiI{;z(z>lBoUHqyaigY|ImIHR0p`SHE-~%p!Y>EV-+o*hbd!eP(qRCH)^&s6I+3T4BJqo!@8nMiVKVv&F=?QoUdF^i8>jUx6'
    'ZMz1vX1)HY?!4CbNBAS@TqiN6Hb!>*LjTj4iiO8M0&<`j%&XmLZqtZglbXBM!=VpGToPS%-6tn&W4x`nQuqeU22M~SJ4!wz`-y@<'
    'D}_`DAvKjX6(_1GOKE&lHPua==`|iI(yiSb+J2S0=Jufbs-BQ@%%6W38?|t((l5(j@h=a=U6G3_(qnAW@5Hov7M$OxCu#Asr|0=X'
    '{wqU~p}G}!{1YRxmXa3#pY2?JuoOU!{dBKYuRtnfoh_WYHva=n+}^{zp7MoLHIqA35k6KL|5SToatEgf#-9iK0z<oqiY__gK}%6+'
    'mnUC>jG<-|O1PJeN=ss@Y2Jfu#W6!_9CSq<!14z{R-t4B>GLBTVS^oPW&?F0rTCpg>-fWyk5D<iM{PW+5RSS7@nKQz5Bzj4e8IF}'
    '3tKR#<3c%)(r#%6P$?&EWiHY@gVQ^UKS>pC+<D4_4Vjfwu%}o3k3s6|Z35N|QY_QzdymT#H$kWeDuq%+V%cRi=o*5-cXW>;Is{~6'
    'otvj`!u+$sm&a1Jh9SeF-%SbDkoa(B<AFc*RY7cfYT^Yk$ix!Wc_?L}Z^jKYNmWv+CU+{vzpJgz<M_!~%mxmt>T9T|=9LCJ609`}'
    '83|!W9n0>!rYQIlF^sP=q+U@>TZLLgGd09yQ#7taSHi{$rW5X$4uq%rjBg>uQ<t4)nBuK8l;A40+NWW`Pwf_=E_#6kM~gv$-T@OO'
    '?S)M@E`1`Ca*swZpqA<NUMEUZ5el)Oh#-kJSRCDe2US%!8>j4yY`KSVj9HzBWP(u~1?f<)X8T(38Y`KvmF$NZNA#V3`vo{&d<cy^'
    'T$ZSBXk5Nz2X?ISN=SmQSKU;Q$4Qm@i_Wv7<gPIEk>nxZ2x=a5&-3Y=gT%5EZvXWEI#?fG6mAb1C_vg-M9}f|{AjQj<U33KbgdL^'
    '&Y%#+H?ML0pQvyFOW?QIO4YvRpsX5ksOUc%uFQMqvA_=MXX&1->IfEvrWbv>9Jh7`Eg;FPe3w(<@EM3zD@rnKV;iXG?1g`z@ovc5'
    'K+@e(=d6W^KGz<2h(rQO-TOHO;tz%ZUO7Dj+E>LU+G58c<2@iL9l0Mo*<EPw(A(4_2Z5b<b1SwFhKA*3r+-c_Ih)+=EL|KHhYb~O'
    '%TUQMV?1#iYO=B5{D|l8D2o{fIw?9JJR~`rqpM2(S=k?zM)mW~z8*I@tE4vU>LTJ)RACz!S@v*ts8lJ-6INyy3q*rnQ(Uva8k7n('
    'I<f3B>gWhCCa)suE{ctl^+eF1U(+2poSA3E+S*1?GL8wunjg9iUi^Kxg#~Tg_AI1S(?iu(P->@CKDBf^Kt*?@)gEeedkAt{fGsBC'
    'nz#fqs}lOyni!WX{4cWALGue&)|o0;j1nd}C(AwD9vs_9!k<0DOwcdCw|xSUt{}~xz3}hZ*6OI{VcsyTQPZ69w=1ZC*|C4KhWD+v'
    'K7<5vc}-`m2QX!fd}R4Odp_v&3IbtwRf@XB_~(|u`@9IPZ0lc;SpK4GYG>u{!tyZ~Eq^Oj>ge_W@8(K}3)tBaljtwsN}?l<c4y~m'
    'Ob&$2oDp;l=%|VP5`6u@@P@#C7_tDN=T1}Uw(Udh)lPtZ`-N4<MIJI0hZQ|j2T6O6B49MR-Ibf6Er5DTe>xw4_dUr4IBj8pfgK8R'
    '@?Qjr!XciSG>(^lJ1#SEpoGG7RgdJL1N4QDe+Qg`J@k9j=+~V#>8@$1xaKWpgukvkDh|YXVg&SckY*|y_roX>T=lYMwFzC);kUa;'
    'lJzAy4KLXQ79fMfZeQ79Ko+4@ND?#dfN61pWk^qp2{2X@aV$2Nk_N_*dCH#Xa3DvUH9QDGc`$7qbkD_Kl=eRpHy`A~-kdmd28DP_'
    '=qw2ZPzQ8>QDS;TfA)IO?WXGc!J>u48=}3~sN|xGVto2<5)%it_mG{DTvED?`!1k}wsJ3i%TZ(yo%qtTAb*zDe2O~!=Ad}?28d+}'
    'v=nIk1#zE(Q8Lq%1K*6WBpnh=`<KP#=25FK#{cb=v`n_&K~6VasB!ij7=^r<nGOnG6Ip;5O$Ut`LDPgs;d1)4y}3R3W6<QSF<JoP'
    '-e=RXZ_#{(|5<og3m}bXp+G80$4n?v(4LGWC*rnkY`<2l`Bh3+JzrNHfE}=rVHHm0R7|(`(YJGL-!Pk&8LyS=lLY>Vjcj}B%D}8<'
    'LfJQ^LC~Z*4<4(HI#SrS?5o<z_jD6p_te`+)!-n5Gp)<qMAY7s|C~#HMTRzCfh_?=;ePxpWT#@HaTtx-v#E3HXzU!62&y_1jCiZ5'
    'sD&OmNxlDoN{%()u1pr}Osa~UaVq2B0yj~wXnO;gj_G!Yl!3oQet!G<+)_K#k5UD$k3mCW;<m^!^1p}Sh3>mMkMQ!@I9PO)Z`B@?'
    'F}^V20@&l(!us9uI?!BCHAo&fY43TAJiz=2Ddc!-k1d<P=zyHl4u}?ziv9z7mz>2$%((|ZuD3ST22>{{b~r?cF)ZrAK*!-L4r?iC'
    '`^VI`j$hPLXN_XB0@w5}?{gpZ!kFo1cB_N0lwo{AXW_m<KMkwq<+az|=MZg!YIPa3KVHAZ?HkE9QURDezex=VeC}+dZ9~L&OC@b='
    ';{IG`LcM<wyl*b@XFkb#Qtyhq0vI3LQ&aWzm6oq7U5<S|Zl#@WYE-=&o<ErUnQf3`TOU?n;eYhxsH%H<btyU;@y>AWO0x<j-7QKH'
    'Fi6gP26zyShK4WFGDBY3pP8H2ZBymh(7k!dkSE@I)BHe%=Y)rYbS-ARr&R52=>u2v&LBjfRY2^#%ky@{ZO1ANLfb0*Dn|=ub4u*9'
    'N!`=a4=k-ON|-l|GbPZrn%Mefo1b54La~Q(USmFTyR&eC*a2Nb9#(FdKw1H{sB3<LH$MEWI<o0A5m-E0>1lz6@8=QD+r9FD*Ul~t'
    'xpuDlw*okmIA;b;#5VKJ6)LgNUaFrlT(Xo2{MX{e8EC4;Ph)cm$R}QJwe=p^3_E=*BhT~iHKufe0uGMZM`{1xAwbtlrpE!D-MtBB'
    '%~X1#6xhL&;NB5MkJ=!^3ghQLh}pnFgDClvoL%V4GS<*q#~HRRxeG%0ZH-2xct*;hYrky*ly+(Z@Ssi8dnrQiMQ`U~_!u^2nrC)u'
    'NVLJhO4r&}u;?KzJI<Wria#E!Xp2(@uhhSoV<LpuFIADX*q3i&+2^pn)05#5KDWqc`%MuNPmm+vwm4O^I58)v)$MV<ws$KR8=NDF'
    '3-3P?;NlY&pc38rW)X|xl6WBDCAXBBled&W#9fhhQH<QRv7dn;jGxkz4T3l#Bm~-a1;DG?{VjY%7g{|Nr7&-K%O+!(B37dK8@m2~'
    'v^7fxM1}219+}KAaOs=jL-ne`=Bos%$gCu0K*9n{Y#h*CBi3TL6HhloxR{6tRx?RK?N3S={i4>Pk2W+~`Bt|?ok_A0xf1}~1C9`2'
    'OuMS^8qbr9C<?Z&%7&%VRL%E+dvbmMDh(f4r-PX|4=12@V|60-q}0l2v`{1n6<!@8z&cwf_Yhe#E_MJMh4c9Ou|n2;4!y;f>hi9>'
    'ig+DAww53H8j^<Z=f!`59~fLh+yo`f6gEiEmHu-(sIH*Qk-hL@GO*b7!6y1Z{D-T{szOhSlsaa&YURVK$6&=FEYF{L>q$$5+>;gq'
    '<YtM9Oyo4Ve*wbcOeWczuLU)XFCY8c=cMbh>t3+7{T|5-Df#`s8d+I4ar_a~n_iqc$LPW=Qe20Uh;VnZz0zf$YY8!g%;~Off2GnX'
    '|M~qF0dBJ^4$u<{XF<#<BMdPs0|nyrZ&VO3pK^-us?xq&>d9U0V03ho24>q8CB^WcE=SvVc9}Y75V<3Yo?=m?PKx-18J5p1u=B@N'
    'BBb)owpQ=HRw@qBB)6w)y~)t0!;#+)(6TW!?-C{P-nNS2WXP@`oi`5!*mssE`BSEwi_TCp0&d<cy@kICn<4)Z*py&tJsMy0_map?'
    'i@!Vvz|oz{bvP(R^fm#@k!A`eHb=ePz7u68fq()zd{GH?T@`^;@ib+U1&7$L&jLO8W5dX`kE)VZt_sY$tQk5r+9#7JEP={RgliyS'
    'f5(7r0U=#f3Ycw#emv=xMlI81Js3aeXHa9oOVY$yvNu8gd?tK6gV->JiLRz%ZHTZEDQs~*|AN9WFn+EFQ1w;#6>;MEcE4xB(|(6$'
    'sHVEEBKBwFB!l(GFjm_)5gwD&qAoJ@h*V{3{BfG*tz%Nq!)M?|)v>gABMyB7+YjY}=I*&X70z%e=WI0QxqD6T7}8;VLjnAX9<|YG'
    ')k<Jh$e@UT)13xqg8~fuZAn=Erx(AJ!#8k9KmK@j14(*;`VS0`IsXz-Hb(tU`mRp<%T99VFgF+j69i~oxyCpoWWIZ!>=O5YgE%T$'
    'H?PGjLij(MkQzim$yd*y@tQAzkuf_-_||SZwFUmsxa;^M<`|yi?{~p0$l?cu(!Hq52<IjcS6kJvc&%`;OyBUWEv)39{Ibf4T$A1E'
    'aJ<SGA2^*EAA#{=CEX-dQ(M~Pu4l^ZV{MAuB(?mjxZtv}*3T&1yHEBQ7z_hdPOc@F(siqBRw{$!e2FW~SxmE7#)9VPV~!4yNR_Op'
    'Xp=qllv^8cE6H9h+JF$I!rs@uHne`2N>loGh{i!GN@c8$A*X2E<E)qx`9JeCUy$8iPz&$eS1YlmTM5G`Ep*1jkV&F}@SF0!{maAo'
    'FY<dx4jC)Oqysw1x~;R7(l;=Teaa%eeU3Wov^2(!e$@m3kL}pw8>Z;rmc(Q~L!~qwC;Okp<n;^Z94|ZX-)J?#&g-Vgu?9P2K?;zU'
    'v-?W*>tO0EBfTD218$kJ8$bC&eYG>;Bmon7+S2wOlj*|ZClV4&Yc)GCSH1gfn<b|iemVfgnyLcYX>?^`Jq9%uZU56{y5UNnH;20k'
    'I6K$IJf{J%j%bBns826D(%bt=<05&SEw9^q2Ehn<40ud(vMSQk_Tq~ev9$&?K)F=dYvs!8<{2ECZZvRhUBa~UbCH<GKD>T|Y~a?c'
    'Ih1I<Jd6dt--fv7OmVY-9Vt*(xBI`u3_k>bt22CNdhf=uEI<6Uk`e(Oy;SFyrejSJa4Q7tbAezoZ4ll~SM79ZA^!58fOWYqVVxg{'
    'Vh*{o&XKP;M0r#CZD7I>++igW?rSYD2Bd!lRyLbxmhY}XSc0~bsgzI$n$NM4=?qcu^-2a`<J7?vJ7y&=Jb*e;;!I&n`=Nb!<sNa}'
    '%00?b^-djXyn|nHrn|Uxz%Q;`xPoKqoe2{4llIQ(?D}K(w;p|$yq~CcmkJRBE2WQ`orf;R+U#9GVPZTefN=h4Na@|n(b2K1tu8+s'
    'O;d@ZH)b@^tSHpIh(x5n5Nl&G&^kZ7`Uqy}JACW*maE~Mr?T`F<cbe#F}{e>{!sHhP<{gCOs^(<dvTQZKKP;9jEr}cw%M==th)@h'
    '$XB_O=1QK64kom{xWeY0&`LN~Z=Np}(C4O##URz-LK*kdYClL22D?ZxcJeY_j}mIbV#Px9^wxDtN^TcZJmQL)@8!P;>?Yt^0U5-k'
    'X%js)ccRLq9J5-SeCwxsnTGLnE?xRo?m%<p0^xL-yspO-VBeQTv~8x;SQhAi6@tVB+xe^dLwtS|+N^YL{b6C8LP*-GoPLVvgV|8x'
    '>q&R*#vF{9*BudaDj+{<PVS`}OHAy+H&HD+^V%I{(xW;z=upn=OR>HJm0}~n&Q#18N~tRZtS6_xd49tCj@aJe)xGPf#bZ0~vDP*B'
    '60w5AQg)kmo#?@Wv0Ax}N+iAFx2dfi`Mf^4hw;X%m=ck)Dw(j5L^!Og-dvF^?MO0(G0AxE=MPYD2@ksS4BOHZpd;G2qoH(%J6lF|'
    'U=yy8kT(z6I}Q;qZvny&R|WuHS5JW`Dm9tnGLCjMArn!Hk)A>6WFDb(7fMuTt@X$bVbapIz9`EL)$g@CGn@w|)jKS*g==ZlX-Y9;'
    'ACYM~IKUp-1kyo2zi3rs=T+=QxLPYkd+N!tymwe%99U-ZM;nMVz4MkpE80A1q4FKaILCin69_4J(LYi#NpbVdpRoLvH^{^sS$RT0'
    'OsdhqBfhQc^dNuT*?&+Zrz!vUWNbQNew1b7X5keq^!9ajVuum~S`~vt;=|Hn0-KE!ebeF`tdCbkFThC&kAh(lcr!_KUzhFk3Xp(S'
    '7usl)JUXVdkJpUC2Aq%}*h@8|HN#4VhQS?a#jNVVku`uX5t6#cw}MYv2On+Gsi?hh_DsEux6q<!@^Dr}a8$k2vDDdsqZ8NMZ>|YU'
    '%TPFhL(Odm;8=emwV;e7_L=ez#S|4cH0l?4tS7?onk%xTE(0&cvigEGNH~0NZQj3+7M~Zm$_Mz2Pp2z^<&Il6muw1@`(8R022vP#'
    '`J<?bupTYRjXY#{$ZS$s;`oVvmFxp6Hn>U!!#9xINRcQ38K?cQpcpZjI(%Igp*I}FmuG6-OSEdm<YNbPfe&LOVsm~mA>^9wdA5FT'
    'nc3Q%>|_=q0{%)l1DvGV^*?mIv70g8?JGYp{@xh%?YbvUP0w&SJHsl=6lM!@M!1`6STQTV7pJ4gdGEVCz@B4!2`U@c3ZuYg%*=Rw'
    'aL{7#(`d*lO7r_&%~CD=%6?Z>@5{clA1Li!#gCfCu55r{pNk2HKYzN6`q#C7(^i8cTxI#F?HakQa|EGWE*1Bmb(61%n+~3f@G##~'
    'PIr>G(w;_T_(~qH?%=Vh7dUTg?%g9g`AUQ8;pi8CqzokLQ>tSGD%7dxdq-9Pf6x!cKg{pPN-)k3wrpWu{~VJ!^l~Bgj{!eMMOLm!'
    'T9){o5Tb;wmLqTT3MrLZVAR&jW{g+V8E36(*<R9X6`I?6oq?s~0alKiN=S|{<Fi43;R45EP{Vr1U}40DIh?5Aq>LbwoCu=l@eQ3c'
    '_QN;X*po%<w(Ub1m|ZYYv;X-Gv-t8A4PG*9wqvn>5ElbSQ-dpRbQ}-a!cI9S|G8PuEQypp*xA<s<5M`P{hh-zkqT@TC*6-^@@xC|'
    'z$hduB4EP1X1o|Q1f2vZz<Uix3zTOB&B57%>1Et&9|5k6?I5h}ZeN}}9;RCi(bX?)rC>Qkio}1z+1$1{kM&*ut8Q!ty7}9<;!GlU'
    'lUa;OaKey>fVJI$glLK5n<U$QAI-}$$&o|HVoRdj-77sFfBVQ_7JOyH7V;zzzF5wVk#hJ9%)2hCPtJr%&ds^+)yXvIo^Eh|e+m&&'
    'gDY&|V`{Op>$dv_8DhN8i3=ktotig&34}5u9ZU6oC%jb%&*%4Z({e7ne-5Ya4_2X;)I+!I4;4<wo@ccRg&LC4H3mC-XxcYRJ0vLd'
    'q9qjMq$7NevFAqFU!p&9-QtF(?lvtW7ufsR_vLIpwWgi)9WSyUzDIN+mF#rZF0l~=p*?zZ`O3U<?^`@tfR`@tGN2M1?<frHI2sdu'
    'Bh<qeOIus1t?p=VDA=JWz$#NtIV(%jbn5oA(E_r>T(;rQr=5AW(IlCyrW)es0MJFD`>+0sSQs5KENBh}$Cw;4qjJ+<=;#B{v3%6$'
    '=tn@)Z=xKS$dqt$^_J>a9?^Esb3im6=9C2*2nv5*>63mLUhu+qoI7a9-AKm0LRe(dI@BiOdWW&BSvU@(%1@g`+}HWO5ytAz+q7?|'
    '2Yc=iFVRkAaHdCoWXs4CkKTTTN7x@kmW<8=1T595e0_caK_AU_z6omfkXBnA^gvZYiW_T(Cdk!9O?(GZkiY-LegKxq;IOd}c8Hcn'
    '8(xawu9TW4j|q+QYX!=qY)v#sfrsac#}ZO7XAtN+t5zems-8y$AFh&rcO$AMN1(iL>0V@8F}m)*9+WLW)T^RM+J1A4gYA?Nwe=*6'
    'gUXqP6yDm{!H;Sbd#F%i49`&+lV-`h>S+toq66$~|2{jD_))VD>-%<8vR<>#Cbo!T8h*3n`cn{^#0rAxC!@4NaAcsc3bj3YHJHCa'
    'xZ?4lT%F02ZOJnu!v`rhn@JG?1Cbn66$KAWhI{Jc)Uc+uFD_U=Z0=E-0hB4pScgKT)f#&!MX_*CyYWHK#3{uR4P{f6;Wj##PGq%#'
    'w!Wk{dojEM9)?g3)17oOb1PsWo4>+u-E4&8;?54v{&de}ueQp!U1PUVWvmVHnFc$5)_52s@2>RFmo|XM`#&ziESxh`MLem(yKm(c'
    '6~Tl&OdxFT`>l87P%*B|fW6m5g}dK=nhL>ji!kTK7xlY!A?h;FB-n2M-|mW+7pThE*Ww|Oan}!!!D$;01$U2^fS4e>#tYmM1e#dv'
    '>w>pq71S6qYLdy~%w@9@f$>)1kPd6&{%8JlEgbw%!P{+Ytxq689BTHnVeTeGeVk%NDJL$J&zBZ0nIEob#YsdI;CP*Jf|x3c@|=Ty'
    'Hete#)=oT%zxoC+S7uo(RTO*py}_sq!bq+7`_THjP2|0=ofA-jOVKs4>?OS}`KhMp8#ZLBSmZ1kwADE~=mOScEIa>yeyeUH%JY;W'
    'p&$8EKZdi%Dw0hQ!l04QonH^!x39z66J$uoI9vLR$uET0iKnacOBo7ekmsTD75zR01s+Pa3|yoP)C39pxNF;kS1pE6bON^(M4DQl'
    '^$i`zwvvHr^uVA=)+@u^ei<@~CdsqY&3;NyYCXGdbhd+$qbWcuN^(*}aYX#-<0`bbRzdUc>xDw1yF3gl3APUF;?;yrG2$Pu2)}i@'
    'eu{&yFkF@6Uh6ZM<?<_WkveDr+@k-w4NfoSqlu(xO}H6$d02;?wr@;|d&{BxM!uWEH3H+XP2c5P<ao2s0Pj-qiEfUP>qIXR5SOV#'
    '2xUvoYNil|(hqwd{$!%|Vs`HU?1__=re>Uv56$7+go48rZt#u6Gp`hYfJQ#-p-~naXLt;71%f`x1)fir;Ocx<%w)^b%J*c9Wkfnw'
    'cfL^d;A(c)rBiUY{Mbk)MvP66$KgGlc54F`kacT^1)~%Poplb&Iuemp3}U_PjhNf;T#CCiAgqg*VZdDI{LH6o6{Q95Cik-AAs+|2'
    'I%>jQC#8?wTj_{m@uidRW#&6rFZRQuXt}GD3Aln}27cA~yG*Z&>ZW2E!`1D#mRwG;ut>ad*Y!T`$T6`7uY#>kDnqdryE8eo<4hJ3'
    'bq7AjvNpTL1LPRI@yoM65RlMm?Bo!gYWctoV%Jqw1Ux1+vp}D4MY?v?eGI&akNH@M#cU^Tgk&n5a(Kwu@du&w5~C}q|9spfe(vyU'
    'jPc3=DvjRwSC<vtBa}NQrWLA3ld><ET-_{A!J_9`wlB_~M#6qxa)CO#QKDMgL1}7;KEi{4i|Mu0N(ye~VBig-PyxP{g*YWNALD#Z'
    '3((KijamS<*$;WH(-4&_SCPcX{M9%=B;H%UQ@dfbzf1&mE?qEKWvls9b#_%Du<=R7h)tBGbbW_fh!Vly`5(1BKRz{#dM-1K`zb*e'
    '>r1sKGrQorGTH+8c#5Y|%BtmEYiaMM*a|v=%%P%s(fEfZhrrv=Eq0bohK)k86lGDHsp*X5bWfjy9l>A)+kiS=%X|~A+}YDfWJxCP'
    'nlii&PC7ifUPeRmrv=@|n#|tAk-{^8q&%l4gnpn%zna0hjDVUcLT<xgh?NI1Y7&Q@XOLX$nT89iLbH%X8m6=z8Gv%->}xzb5ixRW'
    't2|DG;=_wn*2oSA5}~h{73^@HouW+Ovb<vcIZzT*Sfko?=*8z_L9$JC-#_3pfJJRBPOe<G|LKf;NY?maqT9Y%>e_u!g`FB@YQp!H'
    'Rgc23dhtf&qWtOHZLZZuIi(H?U_Pw^5WV>7%*URF5a3Z;SFL)~yR-n=J~}c<IXI%dO65FncXB=gbx!)FwRmXg9EUF77vhiQ7Z^iL'
    '!WlR4dW4G2y&p86xcpWet0I2e^5drSNrY);`2r>8SWp8(j~;etm2#;hMkfM6f9>Z}WJaEIEKa+k9W4ov$r<>&aFy+L%P7l9Cc5f+'
    'AbnnYZwJo3csP&#3-I*yu<A}A%b$gwEa{i?!b`tr!>em28{o-3AzIc**ua2(babEbhX$3qL>o#zeK-)YjHv7pJ+zrn70u`HxAa6H'
    'l^j}n$gR`Ka0}F0;j7{Q$U9r=166;n$E6V_Ql1c;+26@|<9JXO{W*|-a8rt`<BO3kIknA0T|4`~s6FibSj81QcLv11e9O~0A}yww'
    'D&B7l7b&Y!yFuj2lM^1xSHX?u8AqH^m&zm_mb6={5I0@d6+nXwF58q(%f_h8asgk@T4xsMW9VXWVh3FX>$*dlSRbU75*Iw}ayC~S'
    ')EUe<x|%*d+8=pI;oa!GfC7r(Z)8~%qG~VcSS?`u6Hz|v1=YK88A0_`KQLv^g9#rJ!AabkAPd8$KFe+N38&RCS6k!mkL>=-VV6md'
    '2_EQsy><=|aiXbvTvp}jsDTq)-nf1ws<jjd+^%>6m2q%5=swCu(QlZZM@UA5b62KqX40H1UhHg(xB4;MM@OiNz1k69f7&0_?3A}8'
    '+<|%Qz;?oukeMu{eo(|%Xlrj8Kc}S&Dp^o5Uy&(yCuH56);|}TpMP$tHNP$q1Hv9Uy`&c&o(x#}Y09U<&u1FK_5afv4Nt&~Ws$l5'
    'G_e%zXjvwF4j!VDcTnEfWOg4oKuORUiM!x5NuyI_hw#O7+;6JOiuDh^QM*YStzu~N%l?gS&o+_+#3v8Yi@nmfrAV(!FeavECUb?}'
    'cJCN1#`s&ZVUZeIv?GuQ2H==u*>|$gYbdLUTM`%E(3#H>_R63ce#K|Q@w7a-ea(8|m#zh0s^jcO`Qj*cgpjFM9G}H(r9KNqJh-NG'
    '-n~Tix87dVrsa)vv4Et+=3ROfqk^%ne<u~FZfNyUWSH*M?{(PDH;Sb=C}waL3UUTSFZ@q+=ZOE?qT{A2<O;<J^*{zG_O+)d`0Igt'
    '*d86VkeHQWGS<HrJFzBf2#Lfa6A=&Pc!sW~-mRJ_9Jc|Zi$(W2Z99$E2tp_LiU)$4NEkVCv^{D01g+#hkc?dBNThkn8!zZmBXOC^'
    '!SuuEHg^Wb<$B)t%_#<a-NxIU2G1Fw|D|R34+QB5G6ue9WZI@BoyF1$c$-5+CN((dAjv{-@O*56V&qKz3U<w~d%s&R59p~#J<(DG'
    '{YB9keQm?{36mRlkT28ens+l}lG&Z4{<is(a!qfg6vrB;r(++20f`PL649hw0;gQUbibCB(Y7g*UAKD;aXp4LiWx2B=L$xoo{b!c'
    'qus!`)Y@gb5+E?og-a!4kIhifjRiaKOAch3r~!gOMkaJe9>nCXS<{IvoNt*}H2m?_H9%Ilx%G6yIt+5=^RsZ(T~F_C6P}#Mmjv&P'
    '&=*;z8if0)E|m?iP$q*rIr}2v(i1Da5cQih*)sj7adH~I%n@*2d}@AAG`f!VjsbUGjqv3>C56>At_}jYQxcwxsN2-nf$l1#x2#xJ'
    '-Xv#-=~Fj_>Jzwk;#BHzmWy?jT97_w0#jEFY6-fJs7F5rNs`FLK{vK{@^NpvE*UMxBXa$T#>&OTA>){H=H#>vF~j+EcZ%i4lLOSe'
    'kUixR${q@v9{_=~?K_jnlyRT>%lWf)HARhI<Szl}yq7+O#t1r6Y?0PDt0B2Z!V)Vjs|i=wL3O|u*)(<RlW<lXFLaV{3zj_4Z7hg2'
    'SivYBo+Ugiuz;yN<X>fm4mUgk%e(XnmC1pd1w^tn&$j6Fw^a<Z6kqbkGGKGtf1HnH`68fA+Orsxz#xN5Z$?(<hbwC)yA}oWbt1c!'
    'm4b}c422-Ej1cAz7SvLZQ1?|sXL)9>@cc_=3<cI!R=ZHoE?cJqJOXs`1R)g|lnLiiAEpJ3v712Rf7hH?UA2neM4G&R30(mFzW62~'
    'G(WnPdlz}1a<$8*<NRwmyj;ZTGkXk67JY}846T!I&z@mvyo*13-Bh&x*>UFa7Fm{SlZBilYF0D4@P9kiWE#@Kbh^lR{#a1uq!*x{'
    'c{R02aK2GLn+vRw+d?RuM|?r}!2dnftdyd{N5<oDMd+oSBh}7hwk)b<pO~*nPaSx@(Ev$K3wujMyhultMfOEr$HzG4Sm#~P`|l5L'
    'l%J39sO(T04gUQu+NqoAuKltW1e<lG6WulNJ-Gw*G~{=By0LW>ctM$jmD>|zK$nzl#Rg28tl@e~DEopqscjMKu$a{tWsUG?TY5K('
    '2+3beAT6&c;Hb5~)mb=mDglC$_~WX-skbfG%qd(6zAWW6O$V_plh@5cTpVZ1%ypJ!VL1>TN~yXWQoq6<t23g%7hN+@*_GdE$1GR)'
    '#fl+#_Z+hJ)_8C(%BjN{W*UH_szUomn|!4>L*`We^p`%-9RgaoI(D=c-q*)l*=Tjw{9pF5N5X-Kl~#FSl~5|l1WjA?IK_6Yk#v>K'
    'P?JD?s$|^e>w^kbC1S4o9?NJK%q<4!(j(jMKRb?Uk$SJ^cwqpiP|v;t_oFb4TxGn`QT~b%d?lGKT3?%{J|ZOsozBjzj&)YTnrY#D'
    'hkfD8_1d&6>%8epmAFb1YpmvcYq%Qn)1l%Dy+D@i?yQgE_)`azA3jejn+-p--ebg~-AAlJqCx?J5XgvODudQB1;;<<%ngA$?-6^W'
    'cmLaVJnp;sQ)EGfEWQs{6l}*}N$qLQqy3ChWWNe`QFg{0BZ_%H7oNnWa%T<s8#!Yt2664+Q27Q9T5Yaxee*A5a2S-7Fp-8PBvUGU'
    'fts?-a4Jvz2v?_NyK7uXml9Chju;aTfiJ+p?cr;4q&_7A#xJV+3};3~%q$!ewWB4q>4qO?L?4-vZqzb?g5iiIac36b>^<giwJYk&'
    'd$Fq)DCY}=H<vNss*mKd9jZ&&5ai|09YDRequyKI>>`tA0zSQ7_;JU5?*5&3{0Ls;`MTM_Wr9SU@1m6NW_|u57!Ong8U`)6`Iyt^'
    'Tn!bshH<+(@`i*~x@Y|dXp$1zvdPpF$XTrbBLxVxSxzn%2&`)K%(0ZXe8Dl&J7Wef1j*$}^8vPA)qDZMs<oa0O}S>U9XaS%Z6;!G'
    'EcrIcy4Vk9j`n;+C5UNCG))8koi2@|r^2hwIh7^eiR0LNIrQcoWsQuhoKt_--Msd>xTS4_2@8-j-<S(vO)!#9xlqP)Ja8zE@zhCk'
    'RzL;XZBjRwfm^&W*^s)$Eb2W<Q;L<?dZLJss1A;GY6rf<WdjJuHfkWdRh=ZNjfBKmBMiZu3O<qg7@Ifu43g?abj6AHfhJUq;@8tB'
    '*nSVu6A=!SofpGvH%|njHSGV+ZTsRRo6wdIV?Q!sm&2<<q{M_2)L8TKB`{^&z_OTVg#l|z#W}dq5!?BL8S(=Wr6Jx#0-i6#?<qfp'
    'm&r3_Z65-=dYr&#Sxg-_od(N5IvN5XQ96IYs5pVJst+5pU37~@#Tl7k2`YW#ich8xvuxr_@fZTWep<)8x*yoD??rE?<m57Vj`sGZ'
    'UTK1<w^8GjZp9bPI$L^e9r9~DZ{`9+83kldPipRFt_eg)JodHkRuX!|H0>`VXd$tf^}7r1BQGG)7N|4L_p1zA>8W6ODs2-OScJMP'
    'dmJPYpNFZ`>`wcMAUhecypNZzxDLVuuz6aQ!r}8fg*Hh6cnqRi&zYta4boy`{D$P%sdeSq+;EP)UxqRExq#qR`REK%Ra!bI2u0um'
    'Xnl39)37JAFNHZy(nRCWYXwl+;o^(;Dh(}a?>y=fwoIHUf#C~EE2ri#n*40X+^0fWF|6cs&joS9cHiM|k9*8|`<Y*Bm=}Kr&v#vz'
    's;vDI>RNY=>eYLua|@X{H_N7yxx#c`?OcgJzn1n)QeRw2R9a3Ny({+ZV)nq+a!h+RnCMO^cN(fE46OY^b6o=*sp4Z^Yu@+2@Q~Ju'
    '045yw_1qMa`rG|<l2?$H2?nv8MoH)dLYVuj(Xo<N?nC8xIF@GXo6c8C)nrEOuoSjZ`yNNw&~=l860lTc(-}PkWuIjp9FJ1ER{)7f'
    'n96?g1qzP4kM7;REtNz%WRQvck0nMg${jIQmmoRt(Wo6&?Ec3=7phi={kPvMpm7_T&L<n8{?u1O4$KYG;f?r?jvn1uq>uDlzYILT'
    'SrWm;V>0%|Q|H!oN1pvKJ7;ByXw)_iR!fqZ9P#N<Ec%{r(|rZwM_jiH>uOU<4zcFQq&`LZpn{4(d2c*nNPB(I3zKn<zJdZaE!M1T'
    '&(&GZ{4M){BtM-QqBxrr=Hik=_{~Bkc^k{qdo9p;t#&Y#Su<p(mf#=CH~*VQ1rh`KpJj%P$nNg!Qov!)^EW3`@Edu3=nggY`S(lg'
    'FYD}~qh*uP?kMHJxBL*%bkOG;5h29uPOnMV-ee^h6?F{$L2c8IZ`F#d9xev}g4!*#o)V<&NIp<<H#)>U7J&S@&VjKESK9_>frJTF'
    'Tlmvcb2PNyz7>Tnw+?u<;JJQZb*>P)PgWdPMStfZ<xEy*Rfut3W4D34oE7ao6{=l3*TWLpzZ?akn{jpt=QE=Bh=XZ3{b*Hl_qf-L'
    'j`k1s%Ry}164+Yz`N}@bo`^ejBtm>9^NvaKF0VIrx<2d%0)3Q7S>jTC3;4ytjU@xKegFyFv8?bs^<PdfB&7*>eLkZRuh1f^rE&}~'
    'iXnPiESU2MHbh5AhkX{5x&(!A1NA%;ru{;X*=f5siu>#oO@zT-yiKt$iQfmcwcso{Hz_*S*Y^EzqE&zYAii4KW#99|oX96hBJaCo'
    'zHm9?xqvPoIF}Ld)Q$6Wm53+Gf^SBeh=sOwbG$O5roLA`i?gRE%cEY=@1FOBbe<+n#fU{Yy6;>PcAdIUbeOIK85^)^a<s>*y^Tp2'
    'uK{1okILf3wc8WJ-vNo9b{55&UkMd&rpBW9Bw_U++9FHBv1Z1CQ6?*6yv6GLU9Uz-bw5y3(aNA%Eu_Qs;$21i0fH8U%6HR9xZ~9V'
    'gW>rtHy<Jv&=3AKu>y;DXWPlZB6H9ClHvq?!ECl=Kg4LHU=cP3yOU)PRqjrY-bBTD0L*-i%-=_7$x#n3q8F=VbBS(ZI~Q+EfeJ<g'
    'f1i<bA_l<|Y9b!_AW{Gj;KhcHkDUPV1qyPc#H>9(-dOi&cD2#Y6Z)-gEW0ZuohM~Au&W(&93wHSkp$L)5Sqk=qWl}J{aP0UcHjz@'
    '*5>@&*gXh?6(M>e$=|yVo?Z(ISaRNB8G9D_5@%mWul8F>&y;MIT6TSM^l#vElH|fLMzd*_{*aHx1HSt=<Dnl$(1QPX4bl8h^IO;^'
    '45bJ~N?mBHsasVW8k$M}Ua)cN&a<;ITJPzs4pZ_+U9qWtyvl$Xt}{k1?@dOc-doQ%T*lf?_y61(ToGC&-A640SzlQh0et5{q^Vb9'
    '4pRrVP|d>)0D@D)4FU~n!oXI1empuD^wKuJC<2Ri?7T~|MJ?v%wK>GP#8ruYE`9#7qhD<Og(ElJMstren^KbMCX$jq712ZpQ*r{V'
    'yNn@}gD@&YcJx-0eW{>cQwgM#Q^A2Z#7vEB1#oE^CGtZO{OD`Hx9OMzIKkupufZgJ*cNK1kfeMttFVs}8s`1gJ3wP?!)oc#*USc7'
    'dHCHO;(8_a-gG5w>dKdPXXEHzDaLQ<3z#`g`?;zYUKZK1N$o1x2rf|039_u6`5by|NHSVD&X;GH*NMY+N|bZ+;|^bdvR`lnZd2=^'
    'zTxE_?}{OCI3i3fod4lNXWY-~`zh#(h#vZ!GmDdC^YG02cxA;DC}5qkS4xr7+rkn(dE@pY+oy?f{l>6(`9EcY8@;irtZ<};F~hbs'
    'O?y{3x9z^9srmj{_Je!&TCN47BX#o}xM4H97RZ}fCkUW4(Ja|qT1emFgIVn#0dsgI#U&Ysg5i=u@x#TVpJp|xVlp2%cmb77F|Oj5'
    '?|`kPvauK5xS>Urdmba<Bo$j9BeB)fv_?VJ3IHH@NUA#?jTc*J5!F$LL99p1T!lKPQ`;_0w}(7lO6sn2R@}T&_4<L#2oH}|7r=)b'
    'yqTP|<@*fg%7Q;d;zn1P(cs<tU0>^332wlp;k=CNL?jV(iS)jzTp)7c#2S<!h}+EYT9Nvp!=v6ABV&;q3wlbF3bF7GedQmv$M|X!'
    '!wmj7Xhwh9+!2(CRSVBl-dqO@j{0x)D(hTfI)?8AtV+80@!j63KFS<OFbOiSmCZfMEnXW0VV9Y1^YWTN8JfoRC9;FuS?sV&a6O2M'
    'Bog|Nl!9R<hUxOG{jNcVgPQ)OaL%@#cXZkxsT}5~PEgL*L{+=2L?=)rZX(Hvgs&{A{*#8d;q)*_p|0z-`)Q3sIqlf9y-?7PJ;}(k'
    '4s?PnP{r*3rXN!a)2W=T6A6j@^o7}Y&1PHvZ+LQYa~%NY_vDw{Ddb<*w?%`otD)pfZM-ao^ok*ZXh7!f80XVsQ65y-ZSTcJ>AsE_'
    'JLe6MM!zARMUGUD$CBw#Wj!M3saboYl>BP7s#FjG$8;x1ul5$dN())AR^$e8g&P_I+I>q#aVOA^nt8gp0mKWb>;ETg|L#_!Lkv=1'
    'NM<Eoe=bWt=>8sQ;)u=%<UdpuUV)b5Vc`HIvN5u_Euj-xgPSj3!0dCE$ufs9H(WL`c-k7}sLoz)e8H@%bMM%6C=PvaN>P$(yXNjs'
    'J$l#l#3v2T5)UglT;4X6ql*ObA@^+k7zs^SCMWL(bxAv71^?SxQ`&b<lBrBtuyfR}cUunc-Y#T_Mm!QGsMDCez)<#|yZM?SbSS@!'
    'gW)I8-z;Bz3X1Mv;Z??2j7D%;kc17~3eQBvO5CT7XvIPc6Gq2z#r3|Pxy}V|Bihw6qQ;Y>6FpBOe<Se$O!+{m3H?Hb8A>)|c`hsl'
    'M{evYA$XeR6X=NkrHKoiuYQ|mje5Ezg<w5Tg1GVpbA|ASFF}f+Jzd%u0|8jXzv=^FETRnNbX0(JM~r-Y|KL67GiP=PS98be0}Lt{'
    '@3_|?Hy)txth!H%t>ld~Z7*{7^%eZ0*yBG|FRYeB<QAF#KJpiv>Uf~pXo$m8bsk^yeo+U5b(Mib9P*B)lj0U$ZBf_+6xX^_T+nLp'
    'wUlD|<IY_gL~7yYb2QT!Q~*b*dzLf&6tC8Or+H3Z?03le3YzDoX5I<0PF0pV7eoR$BI#;QS~yduzi@H_3^!4X84#8ZN~bfe*lX;4'
    '(svUZKuro9cPq1L&iX+@w1!TYTw!d93%Wn#;<=@cK$O2q1pPvPvJ6-b)~0H{I<M4fXdzEK)R|BaE_dQ!aSTG_SaCDOmto#1oYVw^'
    'Q*iav=s3auf_eHm81}iQOEFQK%e|ck@}hEo-G*0x_xVSZC@F1<a?S!HF}v9C$nc&76pO$^_h$s22n79%Ki^mixm2Jk*H(0L+CZ_h'
    'r*TQ*N5*t7e7Nq6bi0BDn9lGBt?SHP&Z|!A49Oma<f-oZ(s!Uf`Ddh+BipR_N9`x${c7n?J$D|eQE_v=vJb5v_kaN~-eHOlXo9r4'
    '<dXMl;bgWLo@GIUo8o`ZL<~8vS73?m{RuZ%&7|rR1!&2k(4PdYE{O=c&I%14;K>2v;G`x(1ufuxFjgc2vRFNtuU^`147&bvo;MYp'
    '&YQ>yRV*vK?7p%W3$N6Idx2j+c911N{bfn^SC>Gd<I{a3KE~ITi6MQNxPew|40`GSoGO3PFmQUBoQnM$!0jx5HRt<T+Z=+m`D-__'
    '$)~Jn2&yfTHksx(FE`e|Jg9qdZhoN#M4ywwMBkF5jW~!FnLDR9oWLaByr~DckcB22S`b<WhEfR#Nqo`YaEAGgi5L$34sSw5)pz?{'
    '<WK}-1bJ_a|99{I=*HnlaNRO6e-i5IPvgHb-xIA>1JKj%O`<d~FqOz*=tk4kV#{%pjT)vV*G6WwE_f(ro%gXYvW>oGvvS!^&(>@{'
    'RhRq!A<i%Q6{rVH91Lb`qo=1Vr}{#NhVKcHqDSQh0a`y9m(vDFK)foeMU5Adl!cT4CR2dW*X7&(>n_7oey7IYQ8_oCDxmqu;tnW{'
    '586-@xBL9)aAOe!-#PkwP>eQscCfjHrRz6*#+Wa9ivk0u=~H-N4=gZxZ3h#Y{w}thgV|xQl+)#Xbe+i8n09fgqmlt1WJryFKG78I'
    'B&zX&k(~}Cd$Aqq$kcHKy_|`^ep$$Sepql}LEU+p#JAGrShi?;6&ASU)ADiw`AsbC?sc#thfCzdgdwaY2R+7wik2*KOTV26LSf={'
    'ChlrL4f&+te-vY7=xfjBOEtRB1eK|zzgSoaRx0|Xd%&pO<U-8Vqz=u+gdn*3bikBXc4B(vK`FuF9=Ft)9H@T=8fK*POMLY=Ps(%4'
    'quDua<E0m+hxIyweFm_wt&cHvDM~l8us9O{!F1V3)z($8V=cePJlKLT;PyrhoZl4`-*9gbxuMkY(X_5as6k5&1Vc0rJsc0Y!JBGu'
    '>ouT0vtt+Vyt??b%=e{r4<wd)ZnXTe`Kxw~%dr_)X{Wf}gS<75cMw+aJFF^w0kWQ^8c!R9P)OO6<QKKb7mx*DK8!FVr%7RYchRgz'
    'IXxl7>=S;^H?qr^ecGxGxHwFkE}3N`$O<%XJ7YD@kHga-doStuL49rF<;yyw!+qsfcuP&kVodefe@S5@g!U5tR)j+%1+0Ub_SqjB'
    'd2Q9RGd<y!WZ8h5HQ%lXGuhKsqUR^fD~RlvB$`2_6sHX~Uexhsq_x=j+^Z?A^;PW7ADhgq-q-REHOgQt)A5_AC?Dk9p9|^*?X0Z5'
    '|Krakd9;wRH&~IKV?mIGM#2Om?8_1#NlV@WgOhVGN}m4#ElL49G0#g?&1-p4l$8?>uC}r0b=G>iir>ktkiWu4cDn*z=ah4i)J3ua'
    'kqA|2k#qb%6cN##+?C5Q%rE##)QHpV$m7~J#z-nfC-CD7Tg-qAec<sC^Edg)9(MaDJ_$hiy|p$5{^k&^@7rXbhVJ&aYbm0>K@6_b'
    '$x-xwYwKtv)uPHlI04hdU%^;%1pNXVXhCjsqjicUA?mx@<$rhENutfN&gzoZE)-T{qw4}iO&#8u<SJD)uS*`RD0r$SL6rjK{7p8R'
    'g+P^Vdb0_27I@r*%?CIuUb3e(Wk8%xG^f)BGs6ri;`XNh=OQW~S>fxxWH@haJniWu6z_~iwOyQFio=%X)V_(*oWi0s*Y1BPUyY~`'
    'VJ98Qwy)Tm>h7$aP{dRSV^fIsA~cG@hTc5V{Y5$cZ-1bvOtQbNCNU+RVwJ)~)SmHhd)am(2!39eybq?j()XD&fkIgPBq+1^3(+uy'
    ';xZ;58{yWxglwHKA*j_k_#xoR^_?X-7RplB*l}6CB?KQwQ;p7N2FAH@Jd0)i5R9ZJ!zL2mBiGagkJ7LDr(7gUY8S5S5-tPOfmPJz'
    'WoUpIOgCAE<<x;C5o+@RiQH_y(@qa00ygj=l9LvAWNZKcU?pw4)~@<;00Ga51*X;(cdUR`vBYQl0ssI200dcD'
)

_INFINITE_RULE_COUNT = 47
_INFINITE_RULES_XZ_B85 = (
    '{Wp48S^xk9=GL@E0stWa8~^|S5YJf5=I0EUv0VTy;Dp3sIa(c!;^|CWtR@>(-0PI0G1@A5uQ-5Q;7+FfS^s_${9XjtfTL3MZ2ic~'
    'H_nSyZ_YJ9czz4=xc(U<tQD~Qs{NA3IZ#s_w2E^bc{{!|rqj35YIodYkiqPNZoWU#U0W`H!BpTO$3e*jz+0s-e!0D_em>ctaL~dx'
    'Wb%SenrzUJlYZP`gm00p4SWNGqo@4mk@f0(-WWLX{R8WmkHZGaW3zDtOTt&tV{V=vURni*vFD2<r7_f@G1X;rF=%J;Iy3F*n)u)f'
    '^Y2I{86%w0bLl^;`6U1WO7q-zSI0~at~5T;;@l<#Gv`7(1qx4!PW{|=8qvHg!T^2MvAFyBb06vrB|vma4@`bmBjVCg{>Gw}l~?r6'
    'ACUtuUl?^HqGYDhm7?oJAb*wu<&t!8@1g$pk7cSELV6#2M{ipSiYEn<4_G3;o#Q$Jt47<LvpB)od0B#Q`s_%avMv7%dji_`bqFbQ'
    '&T>NS&|uk~W#Twco?I0MkUy64QP=qAtpmF_aW^;(#cCxhy<0YW)|tldQn?^kO8y+ojt7JBg3LhPkxW!qQVo%_a*@+=U%SbWGA`Jg'
    'YTG3)_8N5>E##eG=T%Bm==e3Hj78xJf>Y#0F!u(^VSl>3u)GYucQGvB1T-uWGN>5s9HnSDUr^KKiWZC&GrDuxRy<WI@EQ5l{DJ9S'
    '!~y(o?|Ca(g0mo<pzt@5Vsu_Y3*RdZ-c$GOd($JP+-95Ph?F@ZsR+E&w~wq^m&+m<q==m&h`F<TZ@jL-zp-tWmhYJ6tQ3Svc0l!y'
    '3wp`Bsz!HqSATx%ntTI3#jU_6Fo!kLXPub8Z-ienT;PS|WI6i-E6*MJCpV5hb_sR`M@1r|rHb^zQl$lizUH|e0BL~bPro45--?0P'
    'WdNqhdT1uzMYX-CdzvT9Sy)FyZ74G;|2|~SqhRxkk+ok^mTXE>tWKk*+3pYVTk^@8emeJ5f|;JZO46w^XQCl0Fw{-YSsl4nid9oa'
    'Yi8zQc7YkO(7!`OW>m{@_OT%{?#95uImB@?y(F6)AD@LEf-nqJN~DN*CoHfodfsX$K<3J0sK*a|>b5=p4laQzi3gTYp`J4!dX%<N'
    'ShmRYCw#jU7BL=q>)=0N2w-kus&$1c@o5Du<$nHwoN{}Sra2#J!hlGsYuhDw73QZyoNPtE>oG4jJ^dEMUBeDS)0uPYWow6$YVjOs'
    '4d$QZgqXITBNtAxSx=O2Az+WT-9Ley*vXkb!2{E|9w(G}8L!vMj0U>}9TRuIR4}PXO}8n6Q&r>VvDGGbfzeskf0BBJ&$ab3iL|b_'
    'r9B<c2A#a%k?0-Uqi#8|3bGKp<B$L?gv+H?Nc}b1-JCH~xIhq53i&We^9Mkj-FX|eN!l)Z7dpoyGgpq!R4Ej0Rp^y>&nl4;Y*=tc'
    '+LXuKW|Wfa1%*2#HHA4Kgz`UGyMJHe<z~1^r0wFJ#F1kc331LKBz{9mf#4u6zGfXwi?Uh%e;h>3q+hpJqTur8kMW}_^(<3NX`>aB'
    'Z4%f@I?!^bWuzHlyQw2hL&#!}GO(*)*hD2+WM;ZUf<pG+E8N$-gsTaN1oTg4)*ItvAuHHhP(C^l!e#(<VYz(w3gTPpKEehpffdT='
    'h@*p43xHM$gd2%a%*Ko=>|S|4BVXKwNlBaU@4XZLxDX=GdL4Nvo+hsE|FrX&DfDp#%{woZy+SUdxC6VmEvcX90J{qo%c14#L767<'
    '+GeR6G$JnXFXfN_7kUK)wKb*EKSJUyJ{kQz0)L&70kZ)1S6Faw%WZqrjnDB`baP++nZhVo2hf8MA<7%WVeU-#`Kz+R3d;e~NIf-K'
    'OF86UY<KyVCW#n;mt&r-g{D%2YdjpJR5ujXf2o@5mRX#y>Gm{l6dpNSybUuT67=z6f=%Ou`ri;GMjIm{KsPx3Mk6h%M(uYp!fA6='
    '=MQua)-KNfwN8diyuyI(T>Z09^FW$Wx2wV9U^^!E!MX<LDF8yP$sj4`A*=K%ltb~~e1p^SUgMi?i6~(+jP+>Soi}uBvH@qUI_4$~'
    'sam%=G`_n);~o*sAoNCBjm-RjGan{jH%QntPSwg`DJT(qr=zDK<teNv0$RBd+Ht^}4p>t)cvTHt*Bd&Nmj@E<w-hBdFF~r$zOe%!'
    '0D>IAAf{q9o}wvEyD*9%rktk^zfFco2G)vyu~3F%)UFHChJJg83>r?IT#%vgM}6LP8To=Flxf3@bTt(0ds8n%9#j!4hIi>HOEtK?'
    'da2?wyX|ePt@Dl?`|^}$LnpxS`kMH*^m_IfO4~jEnV1$CZS313z#W(Vop>Q|V?ai9!b2Gp;$udZ_C)zOgq!Yf^t?$WkG#}@-_?lP'
    'G}bI1kOo=B46~cAWM~<(>7k&p(f||LuU0WPF`JVV9XB;yds&I4v!ngO{Vw#l?<oA?@}3V;>JHpB`BX^UG;pFYSe%<h9(D#NNC~6t'
    'wX=U0shTeoNAW;Zurx%}GG-~^)WVti_`VD((%1y}vQAq2U;c5<%Z}aSt?qrfj7WMi55C)S7-<)Z_WQIy%4#Z-MP?7Jk$aiQ^8MWO'
    'GS_ne7qUMK7)J|0pZlY@d*Si#v1XgfYA20(76TR3#D}i7RDP@z8calu{bq;QEImp4w!$KmISKp5<Y3Gy^}ztsS$E#x<`p`VRVUT2'
    'Y!C_r*kro|Tv35-V|e$i5u=R~MJh2Jc)ir3YFEJ;N@#vlcaWZdrzJa20Z+Gn^0&zhW|1P0O|CQn&%OgKMF}cV$NYb$(30oX#N}<S'
    'Sg_OvmMF>t)NK^|cw$HaIgQLGW&QRkIs>=Wk~CQUq_lvtK;(+$_x?PBksIf1H=Ylcb3mACFyo?`^HSjbC52o+BsWFKa4!0~!&u}4'
    'KQ*eI6OkSL_y-p&;&+p7Gcbi!`(B@4^nF$VDy31JKbE1l>bULZy%KpW?dFCMmo$U4c|X~E4tXMOpuC#(us$qYXG;Ya_rjRRD-9LZ'
    'P~Rcj)(pFfQxB7rml)o&Xp6&1Ne}gz)^mRlC$)A~R=7~a8x!sqyc^FF2dNk*bd{Q#O{?1IJRdayu_k)Z&BaUV5n4dNK@vVnnh7?1'
    '%yLpUYAXq{#B#Q^O4HHH|H(Y$i<AbtBPzqzxKzV$BEIZB?HcKnY5RP(TC{!n#-k38<Lv#A53W+KV!;viB#wA<Z0~P3dTbMam_CRJ'
    'RO*_=O;wBCu2!An&nxoB#X6$bck~}1rS>E^e<+Qv+GP|N1A2AO?iLLV;ErMV!z0S({R$AN5d-kZs%&&o4gU22t#K&&@Shy&5g5UQ'
    'MpnP>%BU=V(1}Tr3**N%7I$i0&$()FgtA6#&1MBqQS(IoUB$B=cIV`bhh?xJtiH47^r*kkyq7*<pnC~3r;X6FGc%=;aa7%QvD7_~'
    'l0<VfkRGgSrsT)?OJUk~aPZ0O3Q~=1ALo==BtvjzZu74E008-m<ZWtJnX8m+M{==dzp)m2NJ<$SD!&{TM@SR%P7*>c_iZ&|H~ts~'
    'm^C4etCp^63jcqw-y(?8z^A^6&Q70@Dt8^X%GF18oR+E5)PbXpv;V%elQ-UQ%*?Oe-V`f3&rwN$w_Z#9qRdk&wX@_eP+!k_SilPM'
    '%f&xm{^nQ98wsC;McqEz>j6>E0JB;}F`pZ@KI0nJqKRdob4&^g8%@@LsE4hOclRcXv|`g28dBIIS?{pES99X^;<zLq=?`czev_!B'
    'WpN-4Ka1S!rvIH{7&$zb;3EITVKVxI$5Ot7Km?-Siut&#hQE|<46}*jwKB9Ic<pWN$-N;a^awRnf~aV=Bf`^<m!EPboMAW^%9?4I'
    'fC?`xZ1Uc+0#OE7j-k}?rek9go}PXbetzI;6l_uV#5UO|Sv@{@C_%<>#gYaNDE#c<9dBkkLF9yp3CezLJrEBI6inS|N={ydE#1^T'
    'M;=3ONRPC?>?vQG`F^|P60k?M;Ps($GArKSmZ{1&TIm^B?4?N6m$%!l+ZmDO;)AOYGvgajCct9WKwIx)#3TJr<A%pu)PMxX#G8%w'
    'u;o)Tbq+@1@_e-J@Y+zp4Xb7XzARiXdbe>mqkYJ{N}5?|d83rll>ZyV2<`OC#8aJ)jP~{5jE|TsB%Q5JOC94p_V-H*6!#eLB=ySb'
    'F|zB0$d}u$1zJHdG}8kw+4Z+!y%w`P>F;f6e<?_-_MysBXEloAd`~eb+(`nm(0iJ>#WD%Y$Z3Qbc)M-BI+pVAjre}#RM0O+RQkK$'
    'TqF^*+<`9t<;G{DWDN~}s-~u=1&khZS{suDy*}k~YFkF7U6d+N&pKw`qY~{{#*KC@$0<tkw+sGnsy^vku1i~GM8|m@v!^%L<?Wzg'
    'j9mbbAc2djPH7-8`JU)@coZH**lw9HlFBggzgUm3MU7kld=Bp{z0Z!sjJ}f}Q=dh*KYZ_>akK-&8SS54m}`RTgGZ%kh0wf7DdDoV'
    'w))eL!ATs!UxVY>-#4}9a|pBjeH*Yuj|D3(G86MTF8`3-Uvj=GkxrX@k3GYBeO5}=VmOxk#AAI;{)6{LlyE4y*8?z5IE@MWAUs|#'
    'X-ew@fLC)M6amH>ek*D<B(AN0_=^gF4nSX7Du=#pR#oPG9zFm|=U?To)a~I_F%V_&wSDE3fjueCxZYz$^d=KDr5CazV3_Ao#w0^a'
    'qPn#xpWRn~tC?9gleqX=yi^*MnsIo96%crdDdXkyCAFEvT$QYh$n-T*JCcYVT~)Ah-F!5YOx+)e{ar3?7hn$b;C2T=+n$CXDA}yW'
    '#X~KK)uvS&hj_Sq`+QGA3*wt>Lc6g)Wd7RdK)UP&YH)9oR{n=vB8CrhDKU7(iyYr7CUp<QhrRajNel`uozg>iR3U68>y;gcQshzl'
    'EUvM&gys{WtO}EL!7paI@wolA7v_xcnOQ4r9@y`Tiz2T~YN2gdci>V-17e%#2;$oYBR<T9pPO9r8s6xTl#6i_wgoOdhalcH>tM<d'
    'J>+TEuYdJPJ>3@0gc1`^d*{%Vii`mHCnHmpa-=`m8tMlzx)tA|VfObwF+~0|){=PVMpVr*EOhu}o@6klas!J4uZLB<fGTEZ!LPnq'
    'M&D}v?N-qy*ippv6&tH-Cr|8vDMwuACk}fj>a6vnWzG0rJvWD12(X=px}0u1+sL#u*$LGic^>4<aSM8H2T7uGYYGGKD}nc`YTFD&'
    'I&_uXObny8ov?+4`V{SrH)**5K5Yt`dX`c;u<i#M{mUyq3SnS?zVfeDGur_^&^86g$p2&4I+GZioDy6(Bnd?3r<(#$kL>^5i+*3>'
    'O^^;V1S`GveLkQ0J;i6o@l#ZX`<B7<0ACvecBq1@CDqs*MJ@<BUh*Rh6-eTFM*w3&wGkT@;r!WvrDP#;iPanRi&!W5KqnP#SlxBW'
    'az1Pfe4f}cV$bDFeFV9Beh5k<?r`x>IrHoe+(=BxRV2)m`_tkiI}r-02?atb-L`Q7;j<jBboz&_01Us4mlqI`(NBiY-e8-$D_Bbh'
    '-@?)jsBu>~%3%CC+4e>U54e2C!N?ggbr|8G0RAq~rstOcHbHu+uCcMlESKb%OLVaxEe-P9H&usP_CL~Sm)KK|hWzXvL@Tu3e&V{+'
    'Olik8m9pH;&$g)9$xZl^5}#UXoPoUlnRSYx*0;Mduvo#pAAO(VBDd0-%cR}qZq-gX{U7T%>(5!V7ATczSq5m`?;=CedqlZ??49AE'
    'xpw)s3Ew~aK#z>tc~x)y9-v!ng#C*L$uOXr*bc<sef1OpmVVXot7LfhUK$V|b#*)OkBDBs0LaH76T`{*L9VdgHGi;&4_kw;(-Vp-'
    'f!~J5RAl0d0|-pm)ONCP`Kh~^q1ce$KoO8r1VmXZ!rck{GI>!xXc&-TA&{3Sk}V=Iby8T;h|?dcB&jrl6f<J!i7c{X6}IgQ5!5`-'
    'V*?R6b#7+dyz4wg3(P~g6Rr(5iD+||e>3vr7votS^b?5PANcYV@<?6nWJXfz*)kaJDXK+USVRstLcbx_8^MJVG2bs}?fQ^~Bo5(;'
    'D1yS5?4S-8=mOW*z7YpF18-oOMIfF-tpR-D$4bX}oYS(P*W@Jm!16{xE2RdooQ9`$W=neRmERpO@w*)trsnQA*?PZxFhO}?tWXxv'
    '?vD)$bXK80CXZh>I$cF-aBn}5J?4x+f!Er_KW%|bBDNb291d4ZmVkW(JH{B;K!gvH&zM^A2PiRPoaIf7ODTq4OLCG8_e;%2TdSUE'
    '@&yVwz-CEIpSql*{T#4@$k+DBR}B-axRv8jaV8VqJR%%)-12iEo0eGJ&m#Ss_>xT7QqR)|J6<?fhjP?to#5FNJ6w<RX;mU4{u%e?'
    '8duh|B{~)DP1E3E^ikWX*YxA(ii%YN7~t>@)Ud%d)Cy0#t-Lcyxl=*|$;dxDnR)SPvqV#iNv+_7M}XjDw2y!zYSDZN#NJzm&j-%y'
    '=Hi5LV}7MuhLBGfD6=oPp3!lGwTHhO-}h0>Hq9!zi!&~s;mYEpU$jr*Ra|@2nwq;LznAa_u|)jm)3v%Rl}0C;AKcpkxqvXZ`ce8@'
    'vOZR`=;e?fKZTf(1=T^x4%}PUrHlOK1c5@|Ym+d`#t+AC0`=paPoKm<vYzJVFH3J0E@1hhtb^i>lBOfmRb2P6O!CDm$12Qx5J=o6'
    'g_<5j#kx2|j2FHSDRZIy`4G%?R{0n^P*D(y(seyBzITZrL9f$}G%QV$F!soun=uZLKkeqzs~)+O9Aj{LT`<$JSY(GF7Z$D%D97fc'
    'gN(l7!2JAbp?4~yvhI|Q-lKvcz{2P#ZiqDb>t~!vuaALRX&Kw3hjNqHk+tHCns#{#`;6?wX8j47j06AMMl+G*j9GJ9#9f7G;>AJ}'
    'po0!pPjlu3f~aZw*~e+75JH#eTwRH!LV&fW>Ku_Kde~Ci&#d+MWs>rn5{?%OR6oNkg60IoU}m<XwNhJ#mqjdsc`QA3zRO2RX9E1u'
    'NN`6fditq0Lf2<kz<s#G!w`pnXnE^E(QpUJgp)+%(4eyj8laf9gm>i1pt0n(y~l@UX(XW(0nmS(ExR?mbI=sm(uB6KiK5rF<`cyi'
    ';C^f{p)I!Z?Ih(IYYKaVZ+>LVG{pkNey>`B)UIAfAwWo;j?9gQ_k4-u|KkozN<ajw{JQxkAESGyw`ytP4^PAG$F^a1q4c1L+e6LT'
    'dhtc&%g~<JD04;BI2;^ENKCZD71`OK?zf3t6FA9itH4whdU09bGCz?{C~6JNpqgTh;8m(D4{Yq30Y{{br1jwV+;@yY*`@k|it~ae'
    'X-7=j=iJ64r?UoUX1TR+C~MOhA0yj|wDUF5@js^fd;`YC^F=ZSo>rh#{~nQ;BI|NQ__|YV4JfszZCIOkoVc&%UUS5^XCTk+3rn5N'
    '7#xdu<488u*RgpP*YTLy3)cS;^6E%a!qAtfD=)sr3^Wdr#y=SyIC+z4795sa-#Y$*K{24aJ?6IakRJKB1Q9o{qrHW|#FX^4YK<v1'
    'yx+97^rUWE^pgMyV|Jq@YAy^0YFUZXuTY}LT$b526>QVQeXfc})fLA=RTt-2747aZ<b2iuFw;U3vMad67m3?=twJ><=f;SKHj_L_'
    'dIraic`|gOS!p6IYScc4H+aD%YHn)FCwdr9$|8T%xH6tFe%9h-{8FCL(PdeW(wQbP3&zvtSLX2MXE9b|06nWXazF~UgB5|haN;Ws'
    '$goPT4t)&Zod)0psDnM3cIKR2G7?TX?3=UV0L=k3dipF;vqo8r_~&9481t!oZu~$U_<i*Y`OPmd*fDv2k`~_5%TWs#G};>Bdk2kX'
    'Smy+jm6f=*h|dNI{mxihnsxUOZ-lKEC*J}V9?(k>*n9pz5r2L*QH-EPC#iOb!W15K;|LUw4a%Ghfoh<<(1ED&0*+NBEw?;PKa}gw'
    'HQWosQP-6)S?Az3bsw3V(KNp~Xz0M~V7ALcnrU9$$fFFdIKP@6yDqJQtBFG}?xuoB=YP)LspAeu%hrkA8@Uc~i!Y<y2w}Zvx3Cs9'
    'QQ1-z%f&;ZqW2Y`xb%oMlg4H-ZewUn=MOTf5t=X19!w_k3|QHX(qRR?c+An!yH`HFg2UO*{wOX%tPefaiU726B1o?C0eQ{J?QN5_'
    'Fa_BwB2eOl;>!C_L<&b+kFvWB4gcWGc!3FNo9(jk7Hm^R`_u-*U8Zbi2Zu71r^+ZNS^Li<<axds>cZb%57Hj^>XeXQ!|~{yZ6E52'
    'Z4B0Q0gkwt99*_ET&_$<$TT3f<)u}D7ijXiI08v<Culltew8VgotuUmPksw(r-kdzKpzWf_NUS9l-zj&g$S@I<`dPPTo>~f*7y7E'
    '7TEXGHYr#kAS0V^Z??a=2_&KuDXbeMOXUOyBrXLLIsXZ7B7@Ta&1_;cSI$Z08x9a`v-vRL4xL4;>dgh_f;s|);$hUHbiNy;oP(6;'
    '=<pM6!lYNvz!-V@f<_c5cBk}4uEwuI%;E~HW<<PSUqiiK)b)4tE(lUqA%J#%`k8@N<*{g#tc*?#O)*;STnrfcsuvFM(jSFoc{OV}'
    '4h^`T?kA58Cd<WNu)LrCo;1-f9DUj0azeX$Y?G-rj8Os%6*}JKK4lcB_G*>-GvTei<}_vE41Z-sIndiPlW3J*=FzQlB`u3bB-L%|'
    'Im0&Sk1@BGqnGC)19a%za{~`dodiF~@q}LVeFL@@!JjeA8P_80G;J0|0k)i!oO}8!HDL~le|1+rmeeey8$zBkZTSA9Q6IxGsOubF'
    'ujDmZ=yF6ufQQ=rcVGZQr!^%A9FvL9s;n%w4r?IPJ*1Z<<_~^k{#9R3cSmcW0Fv-EG6D%CB)uWai!5RuMj1l9gZu;)z82k5_5pd&'
    'ft4~0cBX}otd!*i&{O&?w9Ho5J0oJDIZN^MCS6>cr=|-Qr49I6tr#(!!}QX(Htjk(214ARt(Y1bjj-!R3JClJ3_jytc{r0?3(+FT'
    '4RNHVj{$TUt5QnIV$9?Q4u#n_E=@2u6Vy{SpmL1Uq@`05JYy0d$!8c>SZsw6H3H2}i?J*NBANcQ#$WaUWFmB;vVYf;vDJ8X_gWjd'
    '#a(6pmLk6S7Tv6N!hC`l{jC_w<0^VJ@@WyJM0t-Q;H{wg9gRDd+}8Vgw+^D9(6~>Y^7NO<+?wCQHZ>0s%TH#$G^{4a#X+N_A$Gkm'
    'J9B4S2L%yJpjP`l+Ev8HBk(S_3<`da;$SAZAtUlD51TIKFoLABus$xHvfovHb~WMOKi-Y1D_+==Ygu(h2hxlV{+8FeCLQR&QbdgA'
    'FjKv_edcSkfFi-2fxf|37_PWqMxtSIIzTU#Vq6jcGsOhF#!hEL*Zm-l2;tMW$eb7Zf9f;RdYJoUA&w&6-b}9yIbG~j$r(P>qTPC$'
    '-RzYglTB3{))A<3-+(!`uC%w1?PVOO1j$RyClcK0{EEYD>C^u287P<y=2AYfln5C9qw#_Wc9rrMy2f*b1?9Vbt=X%<gR1qb#ii2`'
    '=R6wXbu6tim+R30JHs@6w)Yb)8qbBFuYogo8?5r1S8hv8pj4$|h(WTK*t4`2&aY%C(|H>5ANT5OcFCO^bPRP$fJ}ymN15aY(NpKJ'
    'Id0-k(2TdCB{|SatNN>opDSxxWn;JJaIxyng(<g4__B@A_Os!P-6!!_X0o_I+TySUuesm2JC}Y)WP}WvF78I(Ri*jdZe<ewm!`JR'
    '{SNN8e;B3h8QRj1%YWyWNSTS^_+lvE={%{jodXEV=I$qefr%PdZeD}1(<^>=xL3ebgqiC@+kC<rRSP`NWzhS6Of^I75zyb&kBQ|('
    '>@=b6V6y`7);<d;{9b=#0jJN97(Np;N>Dl3mG>9-_G?9kDKbWH2gvU`9AFdn>KW_ORMW4ork7~FAQf!zTFI!>(Bj&^h-F8YhA?7W'
    'xQ{RTHErhp*7B=cJ3uUokmkT-s<9OK8Z%Urh719&Ab!<}6SfnTIwJR;{T~Ude#e;DUjW=sH})s$L)v>pl%EgH)8$@UH)-?+NyzZ#'
    '<e~1=xB|i<H=o6b3t7E?1-NXFo;!CdesFR{&3N<VceO+jE~aBBKZSSN7dVKS_KEki2In_^UZzDG#Egr0$1OFsH1A+N_uBMs%^)*+'
    'HeXFj-pdJ;NsQJ)drL9H?dj>QIyCSv(|1}mG`#OD;Rw#wKAF&|nsfYy(nBv1+^HhI(zob}!Ove7jhw}dNoKAae-UP3?qJ&W=XIKy'
    'y`-&WHEusi?ZkwrP?W%FYOQ(E-WZBlcy#3`ytiVfh$;%9zmdHyLHkXJb60u#1$Wj<95rjhk*eguK|T|Mn*7m4e$=iUR-}7vZ~vXl'
    '81WTy6T{%cQw5MN#J#0HV!m28!RMI|)IIYAOk!(Mwhc1*K%qIk=*3!`N){5A;?+9WpGQ$=q9`1g5|REkAcfI2Qa}#vkP8)X*~e3M'
    'gHi#-rtI0CO=5?FLkGevBMc>3coDBAGBURpt({^un2Ifl*1_=_6wB^hjdw&<yRI;q#v#*n>5d~%?N+R|AI?!Mz2!j$RIXDNl4j{Q'
    '`S-84Ri+i28J<pGS&9wjRCffmXYvh}gf!l1R9+PTbstWY@qCAm0Y0FO1O~!iuMnFeeKuy=M&IH7CA(yV#$C1A;^ml(-Ss?26d4FS'
    'dp`!@-vtGV^-%+Vw`e&j<Hfxc0;Bw^U>fPCP3vx3hQ}zEm?!pV!WQ;Xib|MZOUHtncL+w3lEmYM8iEyO_S-rWWRtx99gS~t77&mn'
    'UEc544l_t1?m#%`q|>n|FqVS-l5U^qil?d7zSyMPQ)O-wsk*y0u94tW)tu@7P`9jZDk`Z^$pOD8r<&mj<qw8~sTM_lkwbj;|2EC$'
    'fr7DMu&P_@CcWiAo!qWHH`T0)Uxbam;|5~{U-4HAUQIY-sIkEpV>;!u5xX<rFAb+|uARh7EohE%8qN+(8`*7KAe^-VJa^E?ub77`'
    '^R{LA#ZRwjojO>A?Tddj!tQzs(5W>=ok5Z<pYe)~<UH)*ENSS;t4MiM;t;O^ktHX+<<!)0bh8x}6wcPhQ6IaXrgz)=f~XFu4R&uS'
    's#a1Wza59FG{aNvCrGm!m>Wym7<4}vU*K82E^hUyq-$6C_SIb#n3Y`Hpe`lISj?Yb3Ynw8f#cAmTe}B0*b2{flcX8NIKtyaOhE4Z'
    'j7_A{ky*pTsp(xIXq-JOjKyTkt5QSm;nlBx{#fm~y7y82$=FJN0G9Z13v!M=@c2Q%>o>m1-owGt44Xjj%1x@4-r9!-XqG~4)A`1S'
    'afFa6b*C3oL;?8&q4!_Po5S({m>JoDp!<}#z&AUmdYBw~2Iv(;JUzVe6y743UKNl)f3(zLh?W#2J!d>dfHy2<FUz|PVGDE>1UX1Q'
    'XEzPoy7bEke>)+d^NBeCU?!y&lq>jQ?*#MG`SI#?+`rr_RSj(lgfTbN1(U*3Z?BI)Yu2jkGV`bwHlJS*^c+uAM1h?0BfT0VAO}Yl'
    'V7Y<~V^PyVs*o}u+7(4MfN12N$9w-@+nyU4d>L<uNbysMgX=T}Kf^bolsGh<X6b6CSa`En)#zrN53`<?(o_P|Qq;O}A+6jbaI115'
    'E<9DXwc2TY7l{U+4jVuBZHsi;lbMV|^Qn2RY)vNBG`FnjpYY{u;cfEU7m$w*+hE$dNvXX&a66$VWTM+vordM=mm@mKyNT}_PQ0^I'
    '9`@?|&qo<l2d>MP#Na_+(ZxpV@_r$F9eEow!hoR+`Aw5ZHOoWo7j~LS%z~JYOc#kF+kz!PXUvNCR_AS6hB~ETfotr`G4@SaA;eR*'
    'klJ2>UN1U@%Q3FzXdhq4ftaZUS|+r*xgBtvc1s`@{fS6=Ew1_}elG04Ld+=Mq57c&U{Q4`F)b6YQ7Q6v58G5a6ovhM4Y_gMnIHIO'
    'RR(OfbSfJaqvl!f-=H;cf#@csjIoV5^ah656eyPahMYQ;o^Fin@w0A^miPxLc}xeDpG57FSJ&q#{W(zF>JrT;fq=yG@Z8VydG817'
    'nf|MeQ_-ytn?fb+q_32<F?wz(2YuYBcdO`p1$@x8$IeFx?a?+2vwDzRnqEpZ9z*w<qpC#6-1Bd#PECOP)dfK>XTL~x0>LPSk2wyh'
    'zhXy_z$D$E#Tq)j+Z`l+HkmJQb?!bs6&%WWB4$Z=191T2NwIKN;-f8KG#+h)+Lv5f4omY_=MSxmuu##Ai0=ad@23t8^K<j-<&iu<'
    '@+V)UPF0@*1;D-0Bbr~IPY~K9?LWaeFof%IReTrZ*QsO3xuw^ZI&#bH2qL~}6`C)Qdh9Tb`V_|T)-I`7*PlqjxY$u<7RIpU`fc%u'
    'LIJoWevXL_r@<c<SkQm*KWkko2B3sASF12yQ{)oNJ6UhX<j)COoh=t1|5*|-G)vWnM_n5fem}i`ZKh(n55nv4eILBqbNL92cjcK?'
    'uCc&xKW9S_kdzh3UM5^tdgn4ma%Rj;TKR1~=vgwS@{|ExBBZ*%gq11Krlb{TcZ8?6oTRQ5XMlZbEZ_3cxcbiJ(vhllPIzJCi4|1U'
    'DZJjP|AF9I@*z^3>>X5mx~g$){|^uC-9OX*S&`up?Eqs&1~Dw=%QY@|m9{YBX!(U-z-|Q9>eE;Bw$=|Vro#;Tdy{_D)Y67Zx|BaD'
    'Bax*~9iD!a4WlH;Njf6kki}fz!x{9+^Ez}p(A<1R`q*>B5Kquyf(-)JrG&z6hJ(51_J%NO*deKW8kfoHdM2<r={NyW{_>7dKaI1+'
    '3|@Ls5EsRzlQ!c{B-lVLX#c4aE@2`@wLZ-mWflJiHq9v}v{ke{di^T)B7Qow%8imZH@m@W`si9LncVHZhATeMhQAV?_$Xo13<Il='
    'V)Q^X6~k0^*o<QJ&9L?TrkE+@^r*7R(5vS9kTrT9GIh2*bMqhDwy1XHp0sm{SHdeN!>iVus0?;FjeycH{dhC&zvV>*kRW69F}DAP'
    'gbJsWjF|W`nkU0pa5quRV*X@R>0wGHy1ggQYh@i7<A^YjY9rfn>FlixhePSpBvsD~q`c1Kx`A|B)+BUtnCinASnK<3r2=s`KObT`'
    '2R`J@6L?(Z`h1b3`)&5_u?1L7=hB{$8k(MjZ-y~@MV2Y2FGc=bMEOZ>>RSrRe9i_65Re)FcNIUeh0R#{Lh8wxL$|O(@bQDfTj}O<'
    'fHa&##fig>4LUF<(kprs{bY;28nSOTl=MnT7kGL}0oId3zm?Pt3lLug$**25jDYKdYd}$pE>Coy?S=ZKSdl$2M7)X>G+l6fo8Y*8'
    '3ORx@5Bf6XpDvS;My8Gr-Y2!uy@N{t^w*eUph_P_kv0+<s0EX+0+FGsdBjz<n%-%lsD2|EPkSXW3aMwaolZA}J2;v}IP3@~MUqg+'
    'y9t~cq)SSyD5R8PIBzIcyF9gJqFFjDit+Soy44NHDqM_J%yjlKv}fsFFva4X1d-X?T7ZX^+c|Qsf$C-6HWPM$PDIP6IMf)k4sMGC'
    'Hzl6z$()NO_<rSmra1bc(X=vy-IB5>s?s#8zoR@EU2MvNrDq-bXv6AjiJLRcGhRaBg$LY{8=tkE-h?6}CA0p>Lw&gjU3s<28xu`F'
    'W!<gD$czHDtsgA6L#d=PY7T8tp66-jTx`l7l@rjPW~a~)M7r}OzM%#2#ucz&z|IHRZB^Wna1=HX_a{-G8VBWvbq-R&5Bv|g{?Y=s'
    '1%X1{NbAKLfe&Ndqn=!<U5w@r4F-mj#;Lj->wb1-g`wwQfdr+5e;8TS6N_n@gHc~zlsY$yTn;%+meO_n%dMd)Li@-8QEB!(C+KTf'
    'pQEtEFelC~MfJMk!4DjiT<g45^WE5Fgq+F1IK4erVapS?G0i<OsB=Yv@zLU*eaD^#doJ0i;%UA?b=Br|3lHdOkFWDuDjK0Qmmmye'
    'l`#&9OtGh<hSPK)n?>G9U~QHwf6AU+jFL9EoeYwkv^~QYm_1bTXB*B4<IL~6DtIn*=r^ydsITkBu4&}fE%!eI{Lq@};+)1}M}c->'
    'ID(pQLcCmc=(g7z!o}wRQ`O$6RPl-7L=H|BI<ycMwoCCgpVp_FwaWofS0vkK0+0vyj?%l3902#&&KS#q_D{!;w&r5W`gl)8XWo(v'
    '(_I#}+z4dqlKip#L8vk}aw8!F9K}n^+8g<+aU0(b^E&2~*+>vcuO(u-#dW9lDA+5=XITQncI^>fwtCo(g=K4c>5Dpp`}bEj%ZXi>'
    'Ex1&&mgH(ZE;kL0F0#tT#TK&PmW3uAhuOec5&T9;-$C|jqdCY6D8cl%pl;Alwab;{G!iJy-Mh$g)A=xxXV<FY=%5gJR1w(Wk6f=G'
    'EdJpnZ^d)n4RwqVW&)r(>spp+TpawakAxzMGa#T2EfkcU0Z?<L=}>##aRj?3XqiFvZ!W3Ag}{NB^kJ{lNs#>H%`391%nic0@9_-O'
    '(pI=!9axhjC^UpY4(aQ1$Ngk;+ZdbYmnYw|j&)f(K|`=-CY{B+mOolEK{Pvcbu`6EOjwx4*>MEJ?&f%j!fmIqGo>@14>E%qOx<7-'
    'J2!?1f0D#hT|C`ykDRRqY6ElXFIWQZ*OMM;F)1XlJOJA|3Z;c)8q$dHk|YJ7L>7n@`W{?6eOd&e3@Jbm=dd2nASMc4`czBGC-Ydr'
    'y2+stS>R^@Py~KAI1g!aHL*Sm`)WJ)Rkt&y%4x{~_5T*Q%b5miBbSmvN)t-+s7I3$)dYyv64N<-=0CUOyzZFRK%Oj#9Sks#|3g+B'
    'DR}Tl536`n0E%fpbV)go=BYY7Hj0S_|Mg68Rauz@GKHu%G>r`kZ6Tfh_}M~xw{E}RV2jaa%qOoXP)%XvPJPQg$+?~}{6}>>Kw?A)'
    'w*6wj6aAs?+{*AF-270Rcth8yIJN$e>Qim5$BaH^<#l=SjKw)<W-gt8cd6g?l^|xwJ&MmXeFl~&DvqAE_|6oI6k>DHg&8fLKCgS{'
    'LnS;NLP%A3sGZD1#D!-{36Z+bdCWLs9Jb?vjo`<)T%`p`!Ga21lUaHSlEVA^$uCJe<=@2l57G3J`ZU`G1Zqby2Es(!E?g&!TxrRy'
    'EFu7Iy~fJM5Ak8dgdZM~xm{L`y{~A7?=Y<?L%xh4<IAwqfX_qFj)f$$)nL+yZn*(2K_P`R_!YsXvD+TQAh?<ok=7jr+fR|UN1Xyn'
    'lC9%xtgQ4Da8fC`e6C`!eyNuLQeq14W(&3&I%i_c(#;BZ?(6yrai|#gEj$<ceHXWwq7pu8i1rH_o8IOBzwBO}d@ihO*%zrTb^|*b'
    'cwmhryRR%t22*}uIScVc<hE<xx-g87NRv}O);C#U{$26w;%r=^v2Iis*kefP*DAusPT+NViZWaT@Bx8tvn9j82&>H*7nNDzIPW-r'
    'RG{l1P&4Z?G@pb|e_@qc<OEqLsFO99+i>rkg;vg}NRh!|sxZh!g--~~UoE<2{jualruz)%^pISHvutGQySk*B*m})oOX+qOlRPs2'
    'G8ZGVE?>@+${Mzkg$%ilv$E9_)Bozdp=P^Kr4~?HQnL*#gY`V(zi{XCBJ1HbB44V+T(DeM&sl*9DSA6Qtrv`ZvaVB7)%pKLaeiA@'
    '9ej_V05Mxv{qqkE!TQn3#f&l%4#}q`k`$}UWyzgb{nX^HSM}^?O2!q5r;~-}TX&lLXqLa0)dGwfm+4fj+k0Yz69`i<^}ki~ECCLv'
    'ps;8vKb}cEk)Q}&eHp$h3A}y2{rdqifBYa7brq@eB|z=K52rMp7nl94(Q!aLr9CZCdiK#BSG0fq4p}X6Q{Bh^#j3=b1vl=^piC^t'
    '&h*Qt#7PYpn^bGUvur{nI*~i-gliBAputpDL-(fFJ24GGGJn&3sc>Z&^MA*>t7Wjb4YlfEvNNz@p{R3NS;T2qL&zl>80NyO_aR=R'
    'AcP?xw%|U{c8HE0#dtYP2^kdO!Dk@WLTH~C8WC1ER_>mnod5;8BWBCNo-M(VjLep)gFy%?8TGYggKW3KW?c$oy`BOXg{7p@yBABj'
    'Hz;EQ`jh9_sDy8SoARLFpGJ`A@{=dtTAzIQ0B{IUnD?YOOX8#DD31--1KZklwr%w{8-UK0Z^Qff+dYdc1StX$M*7Nd_q%#zegGpG'
    'EGt}=j}9b4=s6yq&3<#xf^tQv!S;=wTSI8sC&~E|v<ouV9pEQ@(XzKMk{t6+y&o)pvriWk0&cmen^|<fQn<KwTkRj6NTCoi&jL=r'
    '5_cq%4uhwsn<V{1D{6OCPZ3bjb+_4xP<$VYXIkJ=33?k_*GrrMy1@2@A(oCMk2W?ZrBKT#IK=FAJ!cAC%dI$kQgFZqbu>JMx#!B)'
    '?DFWAiY;ho@xRkxRJtk9Gz+0?-siYRD{o1XYdg8@q83BOqg1kzMAu>?suUu{pQ}h%KbE~dvHo4OpOa}WrW{I(HW+CroFzZ~-qpD?'
    'rSs9<;HOc#_)v{^_tFMib(l9>U9R;?IHR8-LwlPIoh8UH^Vi%{Az>?YpP*4$3qoKUcGWZ=c~lC8d8yMCPD3vU@nyg`FJbr7gq9_S'
    'x&+JA0HmI9Qf+tw0mh{IE3Q;B)Y?FO_8X|Kd(zNxGIBY#C<9oUPi?VJkfs?Zo?WnM#bAEf)MCj_<6M4vvs3oC5tx1k+mGKka?g<~'
    '%Ik|mE*oT5q!`Kev_ch_%B34_TT?2k2qskx7o8_;G!MQ00f(rBl(}!fwjH~%4Qw(0-TF!x6dOF6@&<Z^lQ)&DD&}F9c?B&uOODAe'
    '0F(O;2B-@*rrI=?xVXO3cCyu^k_h#FnDk*I4SJB*yh4b{6j(SW*4gy@DpIBCkKXnN6BNXxa!jd67Bxj?Kx#%Ar1G_u1WS49yC;IZ'
    'd;hUgWtc*qGZrk9@ygbSdRoFTvHT(@iS<&szpx!*KB2~%oPgpvovnOz%YM2t;lMLsos)}%TrKj+^_1f=Gg@62IZ{N|0IEvg`3_is'
    'Bp^Z!XLr9u*T9`Z=)NNg=Lr-gOVB;&%RO>~HT~|8-3=je(0e;Kw$E~<2EPXyxe}6KB-qgt^R+qPcaAwxbf<+<l_roYw(ov<jp_4x'
    'yxuSopxTs<TPLf-hOe?@VmKpT%dx407IR0IEo8wk?P)pjbILyu22`4x;VF6FHg<ttlQL2WEl^J+%;l$)gvV}ZdI%m%{L8NON$PB!'
    'Txr503b|4WZLfMR9@GLfQH;i|ue|&Z!{yDGw-rBLMc>0Dtq<qi;c3JPGgX;Gx?+5{;@$hLAkHwP#ir&sgw`UfK$GUB`r~f>Q)luZ'
    '>JK^F<p`scP$&9zP)pO-mQ;N@r{VP8NxKE2T-ggjnB}ki1e!>1C9^Bk4Te(i+E6ID*^;W+XcD<$n&IQ$05}5`!mp|(j#cPl4(lj%'
    'WN87AHvnNjb4gG5lRDJ}I%B5manHq8fnP5ZN{E);c>~mPMNMW4%ejVtVXY|x<qE9d%SQ~dd?S!sE>r9FV;R}I2);})yHaGnez$=t'
    '2TETdcWGe`(w+=74dl|SxE=AKmf>+&G(^q1@hASPJt?zIkD3S_XI^}wf=|qx{+TZ^qv*XNN<vl8oRM7#e8)rS#II7v+LvpI;7n48'
    'Zv6xKQihZLbVd43{Xq5kE6w}v=iB}|a*;<4;)*6a0=^(uPb`PY+8oFU%K0#zLaSpbAxw@dcyi1Mi!V6G8Om|o6M60nFo+LnmN+Sl'
    '5YW@B1JsjcOknWgr(MD6t8|8k;&IU60fPwo6OXpHQqW$6==QS_$F(ey$WCjZ9c9V4Tw+qcLP;Rn`asZ11nf9t+thb;h{N}!@Snf_'
    'ja`3VH!c`UYee%t*R>xqYk{o`@->zLtokSMF@^DjIyKPMBg<PgJO8$PqK?I(9TqLN;_G_d)B@3u+Ut!A2<PimXz<PFg&@zGG@w+~'
    'z<vQ$+LRk4AvnkB0TUHEPjfo6Rv~Lmg4&}R9<nqCp(`bEP1l&=V15K5wTt1%wcjum>4m`!rS}>B$u5bcBFO}k;tBEmE|AjEB7ENq'
    'uT19O{AwC0*%)NHo~H6uWYz)Q2Uez0fkdgyvzS)Z2W+O}IakHYynvv;vk4ZSZBx%x`ouV~x;_$N>`txosI$iOgIDZ%Mr1{UepN5>'
    '9*;JY?InQgBF{0^5ZL&mu&cr8Pw2-)E6)_N%7Mz``t%1^?tdfD7un8IkcEC$UXTp=bi9r<92;cghqk^Y&keMBq$YI`A;XhDXH6CR'
    'rl}0uNGIus7r$#2S}Vu-Cr>5K5MZwjH01y_@Il;Ydp*w3yr!@}SNB%mDLNRO9_X*X{!d)$+5Ngm)foX5In338-lO4XGvzOYsVb6f'
    'z~H8V=uc}A@Z|4!j384NQ1jYSjMF_sB)8#I{3W&v9_V~Gd(m-7##pfL-^<pyxmB~p$xNn%$T*If+G{=`1UjmQKrE<sNo%Cg7p`Q7'
    'j~cQc_2*HYbrGrS?2Z_rrdBb0a@TE`Y+3%Fit!&GNq;>ILx0rk02wPz4AVBSA@r(*9#Vow<QKZcK9^GVG;nh0GX%rizZGCnTajPb'
    '1_Je<TM(=p^1|g_g7e{`r8L@pMs82-pj2t9%c=A-u}*B53j{Oq)7=Vf_9X4SF#^#Kf)y?>SI%EZ&(>tlf+1M2-eJ7ucaTBJ`ZJ?F'
    '%@Jdg{i93`ZH6BWSXAV%tlm}Woz6@Ekvh(sQnXF5p_G7hM&DtNwLZH+TnTy4P2VmEq|E1#B*xSQ106Mmz$1JIx<(qqWPw|n^h{c1'
    'UV9pev-cb<V{_HlRd;o|iH=PR)K@45OfX#{*|H`x0xOiMe7}BjqCwwY!zDsFxpX6dQlbHYVE%@8Z_E_5B?T5TpxJDn@Xz9@o;-T1'
    'KJ<IxE{H)6Rv!nE8zN3tZ@))mYQxE^+AWD)xZEn{o2Nm`S!`p%vsr~ygk&9H^;atBX0<pKeHa2TRdA)hql20wXX>7LM8%aY;d8(P'
    'o4^>EA>6zTnTWrfquJbE+9UHyWeXSBc>imYeRjqkZ8icH%m-LJb)Vb$A1$p}f*{>(ms{W@f&h0hmX(LA^EM)RG>6gJTR#DMWYi4m'
    '&xeo__CSX2Lhn)p30`2ncZ@$#Oaq2*KI49^B&%F@&jtbIU7u>*@=|MKc729Hq`|uP{@<IpSy++XsSb*l5~rE&83re^RhlAh4y?Cs'
    'm5P0n@Endj$`BOT?x<*m<k=*(CQCAM2kYxmxeHMiGnkI9|J#|y#Npf)@kWoL200+Hr-xm87sKAV0kk9eN2ox*^MowRT0*kb)3`f;'
    'lj~R@<CGFZy<505OG%x?cY-!Sq_F>sNQvV;yW99-{@f>J);tl7m{|l0l84Ab3n87}<m4`T=wzxJHan?v_-A5Z5cv4Nd@8X;_~TxU'
    'uP&SN-D~|cG%Qr7{|lhL(!VE34UneuqC+_XeV&l5S)`BJ7~Qx_lj6d|jdp!-hQSs4a8(m)fY7eoTJy0P2A*_IQ!3ACq>F@tI7T^M'
    '>6+FcUyH7Irogl>XrP<ed*^^(&88X!8aaLne_;>5?B0gF_%Quj{5YTtmyB3VVXI>Jg?GOmU`Ci%v@%D*7w7j1J<L+Qp%wcoAiV%*'
    'MI6b?sz~?)G0QpP(>{vT7d9zHYFaHSJL08@+C!V(aCPgJi$q3<>PjLIglo~-qSUz2G_y7~RP^`Y@HiD26ZinHkXTwU6MK-~WL_HA'
    'T|LR{tLO?*`v6ef{R&cVPYB09ZP|i1ochXkpbNwaYQcpV*<%XspM0h*mO)|MS!OC!?diePOEu1npom99vSo1z2_3m&>UJwnz%Z8r'
    'SpzO#Mw(7mE_St&eTyG}FRdn=VN;8g4=?t&e&fw#Hftyk?31M_B=Pc?p(+#EER8Wt&`TF5@C<nsk=<vYX-DOT#BPtoVitka;_*1S'
    '$uHHTn*5Yk=IC-Sc6xYDK96MW*z?6(_Em;dl5iT2?5}}d3ZECwKg-8$Q!-`(rHE%di3RbPM{Uv0cLOp>>nchMiy5?lU`mcM4$yo('
    'rNt2Rk)i9y3eo-trL+el@a&UI`ojY@PzNxK&rM@06IOD|I*0FTi#Bp}QwJD%z80q$Nye%bD~XT+BQVMXWscMWZbW8b<l|&e=a~dE'
    'H-<&617#jXYjvdPA+vl(c6^A>^3hqTOOl4@8<)vJktU=8t`u|`o1isMQ5=96$QtW_6M_CjP=XIq)F$1^-^q`kx^muI`%RNvGI&x`'
    '!5c|N#D3-E-u@;1Qfz6w>i}a}nt@|4F!0(~K;t(`E5i_uxibWZScCofW!j{E0JQKKB~2~8@H6+n(_T}3D#UnuTxIDhMTKrOm}`Z&'
    'bT^A$LU(JB*yR1?@0Eu`&A#@?&MbI-gBrlK{4K`Z*_5vutl8ldrX`fEL4fpbS-lgdoTCec)Tsk>B4tusKI27T-&9#wq4C_mI9)tL'
    'vD6EAt|TXa0g#5HwT&M+_`Uea0xagHe68l?iHcvX2YM7}3owYkpnboXrTA1s(fTgIFIspkl3JB87myiy8FC9!OMFFDqy(V+Ar3e!'
    '_i(^1laF5|2A^@5Y;3Z>f>R&m=*~$m7NwFhCf^4C;^Oh=$9opIu<x0DhXrF$IGG<H_@5VHB4?Tu^-<Gce36=Cmk9cGW(1e)T2YqU'
    '<A&!HtrK)Z|ERU0=ZN)?X4#F`wd`fRp+5v58uWUy007m3YbfS_`ulj5fRa)UQjU<wJOF1_1(FOT?aE$)+;!aXV;bM2^B5lTS(s0+'
    '27@|5uEZzGvN>~qArXx+yM+AjQ`(Y*b*-iM9tLcYq6(@v-Bdr@*X!|zOqE4*tjS-AKlon`nuCYPVtd*cRFGXPsX~c%<RSq)*F>Bq'
    '5Rpme<2KskS|(|YpOJF96j~d~K?<PWoZ%rpE$<Nt_;EY3K96-C+p}9iFP1=#KH{0sB(8ejiV+{TWuv(v=F8y2kJ?8iO9=r;^WL79'
    'p~hZ*94T14@5@C)*^&ku3Kof?2d9io9KFpKPPW4?$-eUQ5gm>+<M!N{SX5D}lhOS}34oodfQsP7!76Tpkn~>d!jH8y2P2uUcaH~v'
    'VnV@J>L18tzGknn*}sJN-;QM?fK}x?RGCM2sn>%|A`C&uA?+%2oo1~6rCej}Y<K|_qE#*&JSQ0kaW>z9Xq;MpBIu^!+b8aOEIF_l'
    'UiEVHsyjDI2C+r4doY^IR<Jx)mBcI@&R6%bpXnHZ`R29N8c8^|F}`;c_yvC9HU%P}+`5)N6on-27u!?6LYSxRDcnq)$l^rXFL{}b'
    'MXp8k{q}MrJz`VlG8Uohsfk00Wt=BAL1mPh3ARoxpJphoQ@s0$SabS$ZS*NtUIT+b;~;@rGtOggVs3Wbs9bp0GDw61V^X8}%icE('
    'NO|Clt^nxmGzB}mr4*ECi50U*CHFM#rE&9c$ncR~&S=RqBPPI}3hjcIKlo6q14U}S(Q!|1a0urm`BXGSF$S5|EOGJ4WVF47t%Bo%'
    'R%uN`0b<j1lsl9=yo1(-{hpY!Z=+Y%52@30>p1DOMZ!SP4bk9w+PRBj5v#oz&RK%!Dug(P17Dm+${IbhU~YQ&u#3bLYYMVSf3W86'
    'FesP-AlRZ!f(QGhF6MUrdFQc3Rn<}MwR^NjNrttaVd|g(&^ggSou{#k>o#t-jS8iO)k>x!^c7v0j84ohFKuU#@*)TO%8Pco(n!Ij'
    'WlQiB^Ie`6+{1GNM?<>)QU{yE+7%t^lp+gd!D0{d+t?)FdQ_xIRJ)$iC!Z~b8z`$RR4jV+&TW=6PSI+0ER;ZGQ;x;Sd$zi8+r9W{'
    'f2Arm<}XX2CGW{Nh~5+nh;FUHl8^AK_vpVhL{^U$Dr-_`>DXfa$8ap?tdtxUp)d0wwBWeC!uvLRn*Ef!Xqz0#qkoLsLTk`t1a#u?'
    'nFm%}Vq*{6dYFB)V^NnY4unF++MyAdWqLs}R&j)%O}xmDM${`i=|SRNOSu%d1eX_FO^_K>dN~G-j(5#(i5`q2?*WT!F~)x=N<6mC'
    'g?i9s*aMoWfP6%A==L3K7bq78dPBpEe{HdlpzX14R?~k7Zd$WqEZ$dwb<Z@$6$;^7DoHMsRTJXXNmXOyNGx#|W07V`tliQSeerBN'
    '1XjYTALL^I@R>1QqkzOodi%J)J(6-s5NPi><c!!K>Q<oa<j~sDi~O9@5{J{vZUIZad;1kP7$>mWW4z#8(A#o{Dfjhd7{8(`4T^c6'
    ')O2~?BRIr~L4Rv|Jj4OE{e$o^d_j%(MWM^_9mAAOqWnl7jEPtPRzv;uYRr2)TNdqDVV<P`pl?0FeER~_<{x~F{@s3R?Zg^opx&v5'
    'zI?=bV86g^=N0r57!)?=t(|j}wBn0CAspbIA#m#`Ui`j|m57fue_o-TYKf2{B?R9NwOY0CIah6tNhgGjym*bvoaQH|#t$H8d)pGh'
    '7!xx=tc_re>lat6TCt$h4vmt@p@m}YfYn$nPRIo-vJ2;OWev2g*}zO>RexWzdKB~n67q2KM5_`C2#6BJi2H>7ACb|;QVA-W%a}}+'
    'mEj9AoLyGIK!N0xp3Ml=i2XOf2*zBhab}v(GA((=ngB7~<f!TbuB*`VP1lp4PcoUXLD#R=wWIteMN)OU^}p!L+?4N3K-wiFQVEUk'
    'eb#ny07c)jG*V$l_aZ`EBiLPTetp1o5#%nF9wLBA?BZs!TegYl#>Qj16(e@-fr0Lqc8(*Gz3oXY$RO?7_P4YJj~1aSJ;9pDfsuL$'
    '1|HWK$18AiO;Eppi}c5b0I`<mBAm9P5|h8vX(sO{kzfAy?IZlYP--++Q9^p|c2O7-W2F4o>yYAphkP=$M^^9lRmC7hW6+u;ovbQ>'
    '==a6XV3fcaa`%PF+<C=K%?gKUq|^qS#da?{_ic^bEorh@CKUjC-7-x<E*y;=4qXjvZh;F}#K^4X=>eA0cU)BT@jkKFfZ@!jJ-r9t'
    'qXCKhj=P^%c!t4P1a{xajfuTr9HU_oL+xOW>L8xiqpaA4>ODGn7bAy0@CkPEaNPuJhd|qko*HbFbQZ465(_fNd(W=dM!5YYEm(4j'
    '*WAJ0xi>#P<EFO@n!ZT{p{$)j_$5M@e=7hkHDmP^Y=|{vj}ezSTwiN-L%;D)_GuR{p=p^0Ve5TuRrMHR3>itk9-jVRey&ZYxg;mx'
    '`_UIyz5RAT5s~H3t{O7YlkIWCYdi*>LhTJUT-Cnk<Mp|@Kw8&Rw-z!xRcrv3noT5QQUPypweU77XDkfNAaQ0n=gKoX07Bs!@vsQ$'
    '@&P%_<-A#>!HE9XuWXiw#<Do~PcB_kje50geu7i~-r{FCbyn5EH5K(duCM=bZkKmhL;)-^3(a29Io_&^<Uomt#tm7BcXDtSNh1vS'
    'X=5X>xWWZC8&bI}tCaaH9?j_DS@-DQ0e&B4Jwd-VS-O=lCLqA@>l(meY+vO?n|%V7UV1|<%J^xj#?l6i*TA?|kI50sHO(RZKI#J&'
    'vj<5IHemX@K><W3j(XGvS3#FDmY*y#e4p@tW)AjBR}+dI*tE*>uG@CnpenZ4T39TMQ0}~>tLG&G<S2HROWuk`Nj>x~%=WiYGYrYl'
    '_tgItyqJHpt+^^Z23XORLrO)Q>>yihmIJV;U78#b+Oqw84&T0bxwu8+^jfs>W?ObZT&Jl=HSp|bFp6LJo#{w3oHn{xZa64Vf1mNy'
    '(5h&3hk4{#-L<IJ=pk<-1^><3G0j};XGH%}m!IE}b+g3-m3<MiuI@9ycIqFsdljByYEQ<`Qj<5Ak+*QL$5Am7S20l3>e~_comN(o'
    'PGtT%L@4=`I2(XPQp2RUFDe)BI>SHQSvb}0QS|&2aokeb?&rY~N#6BOk=|tL^2_e;o7Q%D%;{@+eV2)KbtZ)WzL%Un8M?j#fT@M?'
    '4(h#ESP|ZBYY7&pzP6zj@4act_L&SPH#6($IxBG2cG-o3ce32GW&idyG(<&Bd{MfWJ-pd^mZ)o|9K(hCXOKK3=dHDFmkSyh2{RRd'
    'N%aP&hwJbuvm(TheLl$5)a||(!jC{UGfFl@Rog49(yna*J2e}QDuD`-FUw6kjw}=@VxLEjDViG2DggU{x2Np;>4DSn=IthpZgvgg'
    'EyW}Q+pt|-RQFm}sxOriTqQq2+poOBg6|M><Hu9~RT=f2qj(Lib&P%~YqJ6gGTyq3tyr%8l-b*uf^;zsZqRU;jsn?A!-QB6T5-l>'
    'gZn*9nmi+Z@Yq#7C~_XvfE1l#u#q^oSEcYv$|3Be9>pJOTB!WK*GB|5V>j5;(UIDwa;|jUt<N%!`e7hgyD{y36JjqW!WnNv65sYt'
    'f=;yaCqoZEJ>|%G)%Y>HTKw`!d0zc#!58?&7kc|MaEm;_a^0HX0Jb6(U)jriavpjpSm&Gc#iDLVq_rm3q%$%3C2+`d2>*(q=JX;U'
    '8-d^#4P~0zAlQQ!D~8~pH(SOWTK{GH*!uUQnokj4g=NWKDAJ!Drse#hQSTGA>$%IVckZ?ZJEq=0aFV;8vbN^I#51(vfw|L;d3PUd'
    '8Ez^btl^qqF5l60H_Q=LKl~MPWoo?Bm&NI44Jg@KfLWT5hY}~QWaj*;)j>BV(9yX9xM&#@n8u7B)~D{WDMEr8#3(9(*-5S|!-@+9'
    'Yd*zn9K|ngZ(5;jod>GlOSXsKUdUJG%-sa9lVa-30Bm}@Y2EBhQ7Ohl6@%3AQ!TUjy|HZc+Xd(8qYWwKmcHNYAJu_M1kOPH7tc~M'
    'RnZ2A41e@^9?VT4qTk2-*PXfr%CuY?k>rn9!G-N`DE(^;R{gRcXpGjErkoDZk;9G%ecaed0ku*^4GEVl(Bo3p0^*u%nj@N6R2=t('
    'G_aPZPIS4_INa_mChoCYa`vE$Ajqi4^ywv8#G(OfB2rn(v5JtFPzm#sL|LQK@@btP9i`=U)!;}|9HILr$b!=C5hxj0fvTFA(yFw4'
    '8c@g5m|i+gu&3=2O;4>+=u{)A<GF41E|snqx!!t#od;l3?4i1gS+ijzl(tU%v#Pi6?l$0uCiG$I=cCOc$E-&e8fp??gdlXK7Ze>`'
    'vxlOHiqpb)IeGvAq=BGk6;njtnot~DEl9&$S@P5G-tZ(m$7(71rP4IT7bgXf)@FcVP-ds0jPN}Ky=W1}YAO-rRke9_>th{8)Ct=E'
    '2&qU3m|k%<pmnkoVAiKDuoIa=6x^Q2d;zQ$cox*UW%!qc1mi3vse9D)yuM3C(LEyc@E&c%ip6bbXXnD9MIZ?!--eluP3N*0s3@0l'
    'L_h$&3x-tp%i~y+A@iH)IyeoQ&AC2qczbuOpflA=8hDCT?QtNLs2s;Dt-C-n7Jk80q-*Ek_KRc&x$Z>K{(1*D#@g~GP_$a%8%(A)'
    'S>aL1yon9}9W*qYOmfm2?hwFelg`W(8>nC6IV*rgFjMh-Dc&nA{-E-=%tq4?KcrDx&(i;k737!Y)3BSbrnV-bV1qY9P@aN)g@%o6'
    '=#I*ARIdB`x|INUh26zykO}rr{}a;s|3+KugJGyTSky#b_Ep3l-Vp{2+X-jg#~J#=rnK7p#bLa%sUdaXkI4>{Ov!<a$CapM=K<bg'
    '2n}Sp5VPmvXEWnYNfzLL)&5;vk}%D{hDeLZF>wl;*~)34Gjm{vY}#gLRfUwIGF@n8>5ZkxDa0^0+LY!+iMXKjOQf>{NiYE5Ls!Kr'
    '*;vARKO$yXFoSJRDB`bYl%E=?ab*c1<S<B7mqCux5W?(L<y%IPYS{;O>J`V2U8C1y?2grsz$w5#8V|OU!HXB|pVdq(N4AqAESTxD'
    'vK6K145;g4$CqTZTiMGN7x+XGG2^wpBYg7dA!wY?BWIRLfKkRX@D9VOkfeDv(Mj6h9qP~2qqLuBeZdBYcUmOHV=`bZ;bLqd-hJ17'
    '!ACowA|zh5Yq>xG-0E+bH;ASe-;&|Jku=$mB3~7|@T#24Ws;V*?_ImP+hKVUwS|pEy5FRDojKJ?X41A3zmNXvdB>!NZieV`3TxLI'
    'L}}z<JYYA~M^KKQYu1@I0}h0nRDrG5BFBiJ_jTJZS=W}DhL&ji3vGTz4>wH=XkdV^%6L0gg~ywO+xj!gHwG!YeBWI3cvEqZn?uVv'
    'X@MNEopL5^aQ=*pgIe*t%yB$fF0c>vk9v~iD|EFHv((9y4@?0&Fj!zRKmghvR<j#h2o0w51O=cUk}sz7p2;{P#WD#`j_jYB`$;rc'
    ';ZTKoN<XYBl%eMVVLuH56E(PK;j8EBpZN(d7Jl%30YR$0clExDfcuJa?hLbAs#M7%yyU{6|IoTO4q!r8)fHZFdate*F4P$DT80?3'
    'tdBf$1{nyGORO-e$3WFA;|1kf1+Oa68Am6Md?)A0MMAupvpe1EsS~$u9yobk>yv%xPfyb&t_oxLPJCSnHaM48rZPzsOJOZ{v_!PB'
    'Z+&C9u_-x^{g5#bvB_R|vEf|8(f+uS+e(ia1N{w~;`k={Pm>j(Y1#EC5cBpwr)wh<`=I&;A_yC8a><!SZH*tf@-+#!`ooNr+hi-d'
    'o*c2f{|T{8<|CbSn1CG$QNDjL3QJXMp>h>XF~0qP1^VM^N|TR6mxu|0OX?8+&MuK+l5}uwZQLM-wh-%wo3wPB?}$6wZlej951@<Q'
    'V2aEqJns=k<KEfW!PxX@YRs~YF-^5ZTr+_B_Mg|Uh<u^yPeS2}*Jba#{A>y6fQ5%4&3WA+4YV{#6l%|79;5L1h-qS=_!;Gl3^he8'
    'z~fWYvB?LKy6#D0y@<z@pl7+nc*<K5gM;{kj2_umKa+UHI(c{`b<Nm$v`N3)SUH%dl9p|o(H8Y^I(8Z@NjEm!PzEPi5Tj7d`-OZ?'
    'KKwmCeI>+o@YrMkYB;?ndoJLoM}zkOX}wcezA~lUcMgEOH7m<}li{-!!Rz_BiT|v*T^3-N4sVB+Fg^0T3#PN`dBmHcd&QJw-F)SR'
    'N!X=vS^3XKFLEBrXLfA%H(O$~YtV-MCzrskV%LgupEH%P5QeK|!fL_%tIp9BL^SM^RftZ$3P4IF7MYMKBNjwhP*!dHV&@5O=tDLu'
    '+k2cdnuB7ZOpZq90br)m6W1SqLIA(5DHZ17Kw}${V^ECUL<_H8$$K(n|8KzBbj*gq6JpXvt1>I97l&x>b062B0_k6dGj|jjk>KmU'
    'O9C#rsIen;#^EU$_M5B*NFGq(3U!PXL*Q`0D;K2ZcgLfeWjvr|5{Dm~KQDd$U4Od4p&Z-Y7Wu+(#l7pL_6mN<A+i9Bq|x5nBXlva'
    '4lB!s1Q!hK7N!Me6~|9?>r||ku)-z#XUJ$+;_PZL5rJh##~z$hmMl*$51%<WieG?E2v-ALFtBQz7T`CwOJak*Lu7iL)nZfLxJ$=I'
    '`JC3}N?dBpF;b@W-=KKGWd{bYj%KWky&=~vmK&~9AIY9Y>bBKC&=<fSw8$(P(l|f&9J?}4gcOPI2p?1PaUBHsKC>^qVzPwjjQsIm'
    '?~g-4h(6@WT0&1Uoy02HiqIRBKI=|fKBnih@VoKDvKpI8^G$`|2Y4!fiTOZ6z=$>hXmbS1*r$+#X3Eh~o{8QHRDUER#o4$|)_>-('
    '>P8+32pPoG=p~Ce0l$HnH=Xejh`HR};QaXz{%J<1hgzh<9z++Z!+D#^t?{rt!9F5zHrByg<EzsE;eS8f#^hK5CxnLoY!=9v7yLHD'
    'BdH-u`4r{qAfTiF5PGuVkAnOMl$knxD7cR}+k7zl#JX)2+?OgL(|8@Eo^)A{_yO)dMi8_ZqY_aBP+}IhkwA8AlDkocmmHMU0j2d)'
    '$!=Au4ZMtUpwj5$BrO~S5I?qXe+X6Wj$x>p^*NpFv(1hzQ}gGw`k2JEVg#>D3)FiGM}>;5k~LS8kBIZm1LH+gDAtLLcV0-{duIX4'
    '%PR4f;R4uqCB}8RQE+pmr!<=MqZ9>Lz-7M#XK_(Kme?E5UE~GPD=-+Ab!(!ePIUan?#+WS@IR(H9LCE&jOM5*69^Q@$y!JpW4;Iq'
    'J9Nq7MfIK&U(6%>uQTVY!U~<gqxmKD&$WfOarKzylq$ZGnh|J8z{_~N{1pcQhdG^BI?I>BPv=o~>R$(<gr4U}q4gn^hngH3Jwo9L'
    '<OgzYpv1%tLsFG8Dd*e1WvseE5pX?VrBm|@3|f<cUlxcDO(&{qPHyukJoQ39WcAx`TP3j)8&s>y=E`ygI0%lUqFAn?2cbf<!bpI4'
    'hlu&%hocZENrKa#pj42b*%~dS*)GL4z!doe;rGS`fEZ)YoS{Kg$)J|QSD{%0#!4)+(Y`8sMY=ynqxfhEXhM;nRf)HeGrdeyEoAy6'
    'W4~_kTmmqcjamRW)9cO=qxJslhP^hrVso+-LpYz<&z}>UkMddx;QN_*a!$$T(x#$4k(bgh@6L}53k-8y9yP#caTuSdEno8RRCtq$'
    '(UcV^G&!gqFAH-xJN8yz%r(BQY)<0WEsinCm)tAEh*gag4{%tp&3f6tz5$AH$i60Vya@X7B*R2(r$c5QPx|{pESe*CZt7~6Ay7Fx'
    '*!PZ|&JhCgyle&Nek0Sqp?I(xptrA>!Z3ZeezK2SA&kqXOihIO4{vne+hJHz*I&nERy94+lW%+8>Yzq6;`VEMy&*UHkA0hJt=!_('
    'C8}L!{2I0@0JzFYUOB>~bJ~9j!<5B{DB!~p0lH2UL(A~AhHq|(;uXr^w*MlZ{%f{OHNkf&2-pe}k4wZKMnl_v-Ea71YW!_(lUdg#'
    'R|b$Sjo>DM+!x>9MtQiCm-TjJCO^A7U(c{J@Q0QA29<%@GdWzDHkkl{BWJl(C``+z-|FmgFc<5`N9fiQiPyl3h}w>{T=nud<H#P9'
    'cw?rUe1c+#VhM|&J$0^`;UgCCp3JfT^s`imbGrSyS<Dr%@K&E%TR-SLp8Lr*X|Un0>f4wKH37-IF)kgW$Ki(y)7c3%)}+W{VAg4E'
    'jOQX#zZK3@+h|lxdw2F$@>;U??9)zic&GgR7fhm@lQo%{dU30S%1)I5Uew#`;)P;*d(Q$eK2qoMlKqnd`^U6*pwqedH}@10ICR1i'
    'ypd6^M*YWJl<w7r_G3!<@XCLWvU2WxCch3k%E7%Ep<c+DjnrjA@xHD{jh;3W{vY|ku%4P;ojdPA3K4qY10$ztKok_DkTVpwPo*gW'
    'BnfT82=(}ojUlv}jKiwq4DQgK)tT}1u&<Xnp$_dtK%8C_sa)~9;18q~_kEL-vZnRs-n0y|R1U7;R&9XT6zZBsl}L#B`nB&|RoBI#'
    'C--z#BIdF$clPg_u`L#N?vY7+jwGlp=329FA|~-p4=9W!ymR#x#!N)n+c0sSA{%lJVpK;k4Wz84l&P5J(5*X-yvc1d<uvzF_=c|j'
    'O_sVW92>sET6lHVpZH)eGeXBYKr8txnT}0K+MAsy<}Dy7*tubADtHt~@q^|pK~nLh_5}QKem+kjd*jF<644FuffD>ogjLku<&q>{'
    '^w5a)qtSUhUn@_R*Q0K>?}IUu1|Uwk8YT2Eucf^LZZ+>BjNngXZsXkL_Fue7X9<!y<+az-d>A83Z=HA<ASJHCaco`rmm4_aA2sh{'
    'mjZ?c5UBMVsr^-2_!tbli6S(RxT4ZN_cwAvbH00By*LzS^kH-ipwbD?IB|=IsEV0RjnGw};;WJ#{t&{p)i!gBI7x-<k5MVHOy*O7'
    'ua&ARBe&Xf)yGr`*Ig||M9i5e3o3?CUu@^^VT(Q30DeoC-N2hMGp|BF73GfO$tW+dm0KDdDFcJCb<Oc+jAevaHud>16+FG>moP4M'
    '9j!yO?mKxa!;9vqr9)iz{!4S7eI`Y+Z|lHLWS0?kH==e&5m-bC1aj~|5(aenjh}M0h6hICy(M?#PUx+@KIl!J!ri%`E1^Y`gtK&W'
    '`!X<Lbs_unQwWQcH_g_OTNp=UX41B?u-DD*@ez5sc<BpDBt<v+!RSEKNQy2C6U?FX;SIyBY>#SI^WH`h8o8SZahw4iTFo#?83NvR'
    'WHSf*XZI-mIx&Onr3-$>!t(wiRe&f_RB;=iR@}A(ax`_X!i@AW;9=|M54A4@f2;~gGqcQ0tF=t;zWd;!OI!SWTe96(pnj2a{uz9_'
    '#;NN}rsj17<hAQ;47^1ZP(ZnqdRz?jG+|Es=Xg>MaxzdcP0IXWuN!H@yj1AseTrj5$8S6<Ok8!qX~?IYegkCnaOrv&WE`8llTS~!'
    '%Lvwrr|Zfa7=6?oUAkg{aae~n^3WuDk&e!}j~-NXFc(PKsWg%V+`JqDT`#R!%a^R*n6$VF36^c&^28kw3iUz8Qh*Ex6^#PGpCdAb'
    'R7cq3uU3MeStGaA{@LK(_^9FVXUd1t)Ss)Bc|X*hijSWcef=YTE;)I*@AHGp?@1Xc$k&y$`Vv4%N&RJxN|y?4kS(mt<|RN(8g9%<'
    'u>oGKDSSHUv@&6ymwlc;I&JQLDXGU@sgSK7JnecJ-N@-2XKgkxT)o~t;Ey<Xi7}=I;;baN$yo5z6XmyQn0;pR-*(S4h|eT2H0CAM'
    's+9pHG67Q-6xv}gW?ZRZ=%Te%%!<%l#ufy4b5;2u(%nC(`aSI@?UGRnNEkeC_`I%Xu;Sr;#Y}nmcH|x6N-dtl+)2Ep!t}4H_%UT!'
    'iOc$P9!D{Yb5mScCu;tyZj%BEZuRR3g0FIbuPx<`oub-E%rQ+)#OFd-EweT^B5~+Gk=jQ%Y4)Pd`vkx+xZvr_Z$d+;ccLR6PArv&'
    '_#;neu;0$dK#FdF{dJ-ZmT|IjCu=<ho}f%pAC4}1tm6{z71afRfrWy>(V(lN_QF~inVoY)+8QkAk7=!<lRGl7HOXjLCZM9YBGh-9'
    '>_WTb?z0T&aUoIAD^8e(UnKpp6qg7)zn_<kZwl&8H0jvbhcSHy7H;iVfRx_tOrnBsLO$I9H_)qi5VOZ-#DCN`Fd@N&8Ds^5h7zKV'
    '$Ug_Mt<EQo=kI&)d`DEJb4<kk9Y|8QKT__04fK%1U`){f#Z4YFnSF+e)jwe|KhTo{dpB)WB%-A3g1A}fZKK`sb8yp0o9Q+%q;Jw1'
    'wN5dg1y-)j?sIJkN=#J2?Lc_IClbO-;ZlbzEF()jI3lAdrFq&;Zu`*V<N0FdsGxo?ZJ&R#NGcd!9$q@DEL0rj$!qG3HnJt}0e;33'
    'Gw;8<K*cvETv&Fs-gNiCQW)ZDHBX>}v7^r!DK_W8=KWMEvK4fEOf>T_k-@V`5OI8+vajDoxlyM_#*Qnu!p9`Oy2$1lPW!heI*IRt'
    'vQiwdRJIyds`aaYhE47L8)kp#FM-2H%E5M3&D)0GV>k{Kh{mmYX|@GTf$)Nkz({CzLM#$Jz``b3?wpzE<L1um$sWHA`2%H|SrybJ'
    'HH*1A$_v?uld^T;xcJMR#i+qjC5d!Jm*JCT-v=3=jDdb|u*=R@SK)h;>IDs+fwLsEP$FF*Plpcs*yXY&3UT{%cCm7=gAQ#NoV?!b'
    '1&MWd34sx#ZqL>sOh6pXAy#L>Ki`#K1>?EkOm$xJKl^Rm0e#qd#p-XnQ}1Y*UUNVYHLD<BdNhkdZMf%zm=G+zvYsvqo=E&`e07eW'
    'H+~Uoaok73zeZM2{|&S}L(}a3utRkAe`b;qC5+W(sbk|E!L{tqtE%O?U0r(eJhD`^Rxwb;MZrTBZ`lZWUAo?bfn5EF(irMq7frHZ'
    'x1@k{S2QoK*2gcbzQR|_mpf}qjn54CF_vq<o~BLOF84$ci(WYZS!mTnm^vORdy3Tx6<W&V8n=*cMu6%Ml`o^}Bo}IMP-fd(lS1&4'
    'nfQHv#Gk}4dBNIR@zMC_=~HZPgzA6)GeqER<iLtkW{W~KsiFXyH7~TQ_~)<Uw*3J!l=oG%vH4gvd&xn24;%L^<pMLJeuQS|hPN4Z'
    '0!ZSseaP67R_Mo!FO3>r4>$UR1(+oK_!PwWX^g#T(@gE1cq|L`FLs1+LJUnDlzc%F5$uZ%W4;`SKSi8TydPr;TY^@^nBPZ!+!$$('
    'A<EWA`P7s5Dm(ExT?b~EH1cQZDm6z+{)9#OHv<<d4D{N|C^+G>nKrElRlLLxWgQW1Vk$F`>k!~lZlS<Md6eShFUj^dBXco?E;a7b'
    '*xfrj7RWHbNe*K8-oxZO?*mjm^iPCqHXe5$rmMlKH#Y6k<CTUx4q2+>2sZdMSsOtn2H4qi0*7>tB?DHtc$$Hp80_B=+^3k-8!VX^'
    'g=q*Tz)v@Z(yaxyz($LNFRSz-MtY$Jw%@0DEjA47@}SI?Uws_k^K@Li9lNLFj+H_@@%UWEMRR<E2T9qzR_Pama17g$*<FZ05<gT1'
    'qwivD>O4$&ev3fAj_#|5*}B(@Y&hv6fBvwCm=w}sBNyo1fYmBxtL07a`-p+zkT{k-L=6#A26;6gIb;c?)A7I6#k|@yBWT`qptVsp'
    '^SnWoHjx3(RqF6rsy!erMUvIOR>N~jk;`jIzMfMx@pz^R(fBZ7&Bb~I>PFQBseB1T6$=>wT9CD5l49xTM3k@W{QhF3oNgQk@^6W2'
    'LmwyOdB8bwGakrF6pw#e?h2-c?AMzcSn$KT0hDxnU%r_IaThH|Dtp(a`4~|fe8>m|9Jo(4fVmyPY-yp8_>k+F6?$JdH4?$5E^2H#'
    'U_`Y8zHJGeDsYO+Namw@*WH=00B1%}TodC4-8ytU4h!HjyH2i#Erw7WyYyqm($2ER{7_~z3!^9GnKu=HbQ&WAWysmJ$-f7U4EfaS'
    'oH=9X4Wn41QB{z+t&66(tTF7nsw_Qz`hT%p?e9!VfA8}@s)$+^PG}?tMMO@`%I2|>LO7k;P%VkxRHUb$C7AEgzJP~`@Nuq&cHd9e'
    '&0{HrKK<fe0%&8N*N`52$fKYETN0<Rlh~SoY5L|H50ovM!Nn5L0&GJJt%JSB?I1*tGo7R&(b6+%Qdiv{EstC-KUa7hUs3yT_p<{Q'
    'M5J{!6UhetDlzC*F7=%mLx(qNfd%0rH857tW6$1}-LmfPSCbD+&ZALjnJi;nfG+>R%@s(M-;L4dYq}|dYd~caTD%fY9nng;o-b~U'
    '3Iz}xXoMnq{&k1_E)-I-|5o;Ew7tG!+OElER;4u%S$0*u)?dPTa>>yJSIh^#Lz>v3=Yt1xjY=--W+_#1Y)t(KR~rJ{?xa&oKNXX5'
    '&&G^vX#L<!Gs?sED@H4$pGNU_6i3^g026_2%g~?IpZfe?rCbz+&_IKvDVMCkul{={qD%QwIuw&^7#@S|D)bu!ILDU?vl(EJNF9F#'
    'd?_{n)-mHX_w`m>^(#FBS&WTvki8A{&xAX=e}3r9Bs{`pwSd0TcbPuxGLhBTxN5FWhqffg*jE!*6=Zbs>4|}Y(sUJM+zXvaFR%Wc'
    '%hu*xVMjR$XX4#jM$*0p_C>qDZ#B2j9z$Q*{uaL$maDW$j0x1R%T88Rx6<fX4NB-@b$iO^-nCKJ)=asigw=c6D42(T(yx2hniL#u'
    '`GHUF+esIR3>d7wYD|km0DA>;ibHRGx;@nlTTKR39fQ14-qDp(Ar_JB!E;S4@1WkAVHG|Pwe&=*cA(S)i~UPiB~TnLs*zEAV)LOX'
    'qg3mI2F?RIEwRyl^Ja&9u&TLT&dwu*6k!eZ!UO#)>tzA*c-N}T6G?b1z(o(SD8+Kh(aX5toJDh+7*{MM5`_76XJQjgVLA($ZKko)'
    ')wv-a>mZRXMXBVSG4M{(w5O8H!^gwxK9uf*Y(wg1-ucJnF`&Y=Fhwf7*XF7M{?*$tF>Cz|Tkimbnx4w`G_Vul^o=GUa~B~DGe>Lw'
    'dTiJ>olVJI7A``ooEJ5r=o{~aQV3^{y5%Gpk)4tY{n5-LSzb{Xz+I&C&C>yXwg$@EL>sxudO7_vGv%`24F}RRSDnTnxY{xK)?IIs'
    'NtO7$*DMd(7T6vg#dz_8-H)ZeedSYIGi|j5-pOxo=}+3bVYiAGUkvAZV3|o>JIn!N*bMM*OXnv<EIsDaj&q@SB6KSv7}n_(I&>P('
    '9f4a2bk$pT<bN5~)D1TN0Xp_Q4`N+g9tsS6ku-tk1dw!I+oN&YA81VeH_`zg!ZGOj9QkwnF1h#sqylK4lyDrbJ7Fjn2AxEP3(!OM'
    'P(L8xRb<9gU^CoM&W*YlUW}<sfLU1aWBOUqU-mVwzEEHd;iMAtC1OC0ebbbST>1`QLjVAR4!L%R^Zuvh4=bG}3tX$AjzKT)wu7+`'
    'cm+ZpxFR3ZOB<>4&3Bq7Zj_fDJca`=BQ7nWC-uer-1sC3wX4W%?_;{o+W3%tbHsOOnUqGytKKc9T3?Q?{0Lv2j3XYn<zp5Pj~}Ja'
    'b2FJlhwex?J2@jnhsXZL@-Ubh^7@f{`$OjlFzwPpe_RlWnV0^cucU&*zcgM+cUAeN2sZP5v%Ua_qPw8FwqVROIbDEas6^vn$TN-T'
    'AlEQ`?&>r?=zM<jjrh=KICtf?*ATZEuMCdTCJ9=&mlj=n>P{s(Lrt*H-;I&27}Ejx33!SaUth*De&1UuD=<bD96-+VrEl5x7+JQw'
    '%LWb2gpP^?jU$N(<qeGL`p|ESGwwwwful4^GE8ZG2X$M5hDazA257=otzIXPlNv<xVGF@B!yZ7eNR%15l|^B}t_KyJ{<qM%f8Hfm'
    ')X<@r$RHL!QwKU^#3WR3nvuTc?Ux4v;|~?9M8?0Ns6150FMgDR>Y+6_43H*x<LA|-C-Z=dpLNAdKsqmQZ5nOlk#CsuTs2l5W*)mD'
    '-6m3I>GwVh@QpCdh_r^!`{)NCaze6$42B#_pb>D`YRu1zQi9p7gu?6}131lr6MYj;NYFMrX%5cRl2LMC++r`y5T72v&4Y}Utgg@R'
    '5$igP&QoWD;D)HOxm%Eif*iTF<J{l<1>}>~2x1Hlo9PSOB4lS>C)WMDV{;3F0c4&@1G_h@pGiqv83+d{luU|Jj6!2N;>4;=S!NI&'
    '+gEy&E_JI>KXe95H@0?x>TwZ?>7hQ~iG@9j2{6akt16fuW?CE<Sbu?J{;B(0qhHOr+J;*8t)@5yW)&*EgfmBz)hmG6$70Qe9#5Th'
    'GZHWtiGO0IjA6MAp9p#jVanbmF+DgM!%*~Xyk5Y4xYY9~?q8;X0tP73EX?39pkvWMqF7`Mnlx`-#t*9t9@395`4u{X)7nL+N}VPN'
    '{in&d1{*JP*WhhjFqcEx6voWIxBx&HUi|?cT&0UlbzXYq$;p7HWN=jQR-3UJF>KfD9i0425t56ZFOJN)8*zaerjf~Y*AL3TPAbV3'
    'I>t0!3x+u?KGBYp>XEN$>74)bia~)JBb4EC+yhv|rbpr3y^x?f+fEdZ3~txcAn$<;QiULic#OOzk*dW`kXg(+9b^z)!k@SNuW*H('
    'AVb)gg%s%m5f$W+6^R0)&wvea_*DP(*yO5G<d})+Z3CP~27H;>W_dnm8Hd+sSHPQxm6;H&{x*iJdo@m62BYUF86)+Pi((*H+@z{_'
    'yr$FaW;qN>R>`rKvXZdJC<>6F=Azmf0anaaY#lz%?;lt3u(2y00$marUJf*;5gB$Ap5+$c;aiqq5_xx&HW^x4KPHAS-T6q+rc|`2'
    '#v|%n`}0(~(@1UGHyMCR4s62QdGu(G`1JY9i9-nw%yL^;E>%MsTg-UWX#pk7R)&s|O8EQF{)Z&qm^nCM^GAa~@2D9T^v1uo0PgXd'
    'eLt`@`#F5ZTUy%n98igUk;+~(wDwHHam}#bHXw62afB(?6*HlEpe(psGc4<{g^8$HG6G&}zyt81B2^B5*yJu-SO}6Gq(s*8E5yAn'
    'XE1H)8xbkng(V;-AXWseghd}BfjbLhj~-Ch0xdU$e^0+Sim{WH=in6RtqOhmuK&4-(@%U%J{;Zdqe$yzw@8qP3Fb9a3k%tGd;tAW'
    'UOaa^$#(z=VY~>DTpCc+1t6}E?>9pj_XdK=8O7p9KZ-?;%qR-AMbemwQWLh84O+&-1r%z+K=o1tR~~h5igBc><0zH9>s?EPQ-}0r'
    'j+>f7_Uxjje^p%<c!^$r+PiSsEY2(W;}MW|jIz7Pvu%GJ;w+-L<xFG0h0Zz``xFUg{<5wOfB1c!ps+4)=Y!pV2A6tA%Xv^I5b5Kg'
    'fDX-(Oy!)KhHgqN`W6IL{diDR)x0-lPJfX+O6_p0hypeDKKkd?_}gH_^`&d*d3t$J0DC;PoqlHD9aot}n#&0FD_Ts{qH=fqzg>xl'
    '@`{VxTD9zFXE&=jMz`M;d~OFw9;g{TiGy^9^oahLdqjp38zLh9PSetyP8d*`x@o}!VnYXXzKqx>AOA@4aLa28ryV%t#l1Vl4W#X#'
    'ki=)U@;_Ry?BWZlO2L^87-7T<nRFQm+JC~c(AGn-p!aszN@~zr>EJJ6#a&O*<kP_*kEK<=mNy5bKkVEDZJx=QsPZ<Y(5Y;-h*|(2'
    'Seni)-b(0qG{LCXk1{ivWS8;0d6IfyLVGQ<D1@2TLzLi{ktl#6B5t&j0-G5?JLsrMAy{&BT|#MBf|5ibe(2JcKk|dlm63o!k3e8('
    'UIvn7Wz*AdA?_~KI*FS<-q2?w<uj7}@V-;j%CBNR+ZkyIow|j}Nvd6FwfB0zjlc8$5vr!?8<El}de`kMqwQ@fYNpjEMN;&s3=6&U'
    'Av$+Rl6;dgErS7y2B^3?9JjRj3B4bvv8tCK`gQvj$)BlKF~>H}jHJyPl`v6M;V=(W*ZRO}^;1>H5@h2dTYYQ!yNiYCH+1rXZu5-J'
    'JG}S?hO1O$jPY(j<!umYW;l-~J4-UcM9&6}cK#s{!FW2Lv3o~M@JygMArcy%5`dIAoP$N%Sx$G{2;nIcqa9QlrLa*lS+W?G10s^M'
    '5Dj;2;}JghR^-`|s)+~O(0bR*@~m$8R_^AT6HwlqfzYTASB6j$K|j$xZiwi_AOAD{rl@)yL@`6SIl95T|Jv}AK2`wOcYq=4DMRRc'
    'toLZK0Cz;~i6STzZ0QcXI#v%+NF}E5^ZTh{gHay5w++^<VcUc{+ECU@6rKnMEsTu~N06icna;<XigfH5Ey35~oIlwcxI8!ZWPa6>'
    '!PM`Ap+?}9DNk3BB3^WQ;fm*X)r_~Y_8CDs#=>Sp$nJc`7No0~I#-P=?+egQ_KKsR7$Yljjir@w-tTETBz;E+%hR2>IBa%kQU4re'
    '?j2Qu;xGO4P#SH%+iLZ&nw5Z#AE18#FYPHrjP2YAZ#tviIsM;J3Z7ai;luxhBIm11(0{EeHtHEDTZ*6bA2`s}o?<ddDb}DM(eFu^'
    'F*mOfQbU3QwP@lf!Gx)kumW?9kM@Q5o^5+uumICAW;)GVog5=wW;`N+Y1$}-PiYugXI>6L|1LWe+f$M3Bo~-i9iLk^bzl`fFczC1'
    'Mdh)Jy!5~{?@tvEx5GK}@j7Q0h*jqk()cBEDddtjq%rKgDEsIUFmqN%KgTjg;st$eqn`@Z>nnsIeCVg_g*L1ae{}`DPiSh_DhP%P'
    'K)m^}HLx3q-e3P^aiMf&$-`GAIemC*_W^PXT7Y4@LdzX%dlB|i&0>9<;`k+!X4INotQy&}CwZ}L^~IgyNb1*V%T?b8#otd6^EMV2'
    '=7PdHdklyL67$9`JfVq!;71+QFB5N?UlDfZ>;}{+dUn1aj$q6HE*a{5#40INj&n|3d<ibp)V#GQZ{gQUuw$!u$3s8ALI?Xbj(w$L'
    '4PUwy_YA#P_Pw}&)(>liRF|R(&V>h)^SmhHrT8t?D)EFm_&47Pyl&_*Lj%lM$G3|u5k^o@#EB;7adq$I0NFY~KI<^90?VqBqzT+('
    '{iE$jmP<ttd3IWE6iP*E*#S-ldtdt+y$!q!Nhq%+7)lU%3IKIx=s3DXfNMZ912l$BA4MvQ{}c|;9qPh)E{*G?fu~+&kOsf*;gFCK'
    '%)@8*+bi%B7btY?gB?Klltw1Ys;F>R!-D4ndlEYbYi3ke-~p7@%5l{VDLX(4_0Xxk?abkHr))(oNjR@iq021q0*l+8!}aC?|FsqL'
    'Yhwqf(3zxjAK@vQWdFa%hH4o?@hw-Jk*!<83F`Jd&~Sgx=xol$Qlv4_56PkQd&)bX%Wc9phsZ=Ni4=ZIL7gDobLVCAe<`3erb`_i'
    '6^Pfo>)_Oi4Vw)*NmaYSDT->Y7PWYzJ_wUlUk5=lojbK(lDa}?RUir_htCFTJbl7!_p2{I4pUplU&+c}#IxG&Ff;5Ay9RvMx^QOV'
    'Sb<mBUO=;jh8TC<%VH;^n@8*m6^3zqdnvE3D}+F-Pqvq$+LhX~4;G1t#Mq-PaNr-41+S%fKZX<h=N)o)9!yFlclm;;3oGXXL8(!I'
    '$BJ6W6_XC!JI_Fn;j>^8wLg90p|>~bY4g1%tXGEzBfHp4O^30x0)wb|cv~{BOa+(eCBxFqo*(R@;^%OV@h1%9JRw8-_A0g?SCM}G'
    'cxcY1QD}^m^UKz4V>fV<%9mwTIBweAF^@2CpTB@Qj5ggPqaA9u-;IwjG7=@g%ybr{6U3!8YJ41RV4j;QOv41~7!JV<KC4}t;?2<)'
    'SVD9zRKbHUK_3fs=0Rna<#mfqc8!g$nHh}*JU%?(?B4^a^5fimIySUUjn9Fh9{S!b5*6~{@#UpA@byI|=l^{B=6av!0LLSc4tHs('
    'pfaIv71bQL;yZ}?EysCG;$uq5p8_eg2fstn>6U`48XG?85e+pH3A_Z~jJLnukK-@axQr<bbWsGY;xqU3V^?3bRjdy+{jYQHgW0`-'
    'Ew?@_w1cqvP>&9Ov>>0}Yfi^f^|OpiZMY4fvFTHLT8D%-;4s9<krFJj1T3+}_Jd@|0&)>MC`b6Xv)fE|Y;0>eC`NV0*4#1|oCgju'
    'teZqzOK?(G<QOaf?`(1X!Xzv;Ec%k!k{zox8C&y@15?y&SwwE2k$d`G@EXbabR>zIkZ|3gzg<K&e_BUeM*K}C?voSIAaLPwv@w!P'
    '5h?w2+4Eo3Igy-*9UwZ~UrFCucnKHiT5%TM9bWw#l9f&g!WA4@>Q<sYQ>FUXPFu3?PfVRU?i*et0cy}gic8ToVjKeHMOhPi<`{n%'
    '+oh+M9vdzl=SWb?(lE~{PPS#0G6-2xCZ)FBUh1Vg)hBVu9j2O(9B%z^EU`E~+!U*A{!YX$z24_jj~i{dxot8;q|U7}Yp%3eEvBrh'
    '0}xC<bK8$oHM_hV5~rvDPPPGqF1$G)zZ2Y{CT!7Bk@yg>sJ8zW?T{M!20SC@om6qWTR3YNBg??pcVP<ZCCr62kX=$w2q`~`SAMl5'
    'g~NPwU;(+3ij3E=Cwkdm)Y*!}LEdmGcV^QMlH^+?E-*7575-Hm>RaVJ#dSn|CXT|&#AuiErr$KKOlQoz#a+En7z@Ahcv(fIEp+32'
    ')#r*k5x{4;;Nfj=3wmhdOC~}7DV9B;*iCNM3T86cR^6vFJ6ujBRlq$8(Ze-#r5qDcWU@7-q)THTpN$xSuhw2K9=y3g-{_R>g;x0*'
    '9(*iP47JmihhzX#>3J`z!aKu@Kh-2iWy`6pFE2f@t-O*p$;4a2Pwp?u#<Wx}bWd4rd=seC0B7+lTqP~CA0TwmKAXQr5+ESi>x|GD'
    '4I5+uZN~Rm0sM;q4S0&vwgh~_+2c^-EC!Jw6ogUW<P2W*C%`t=<%u|l_|d4(>*AuWlj3wRP-iageFw~pwwpTqwe!Ig!ZK(rF~B+H'
    '6%~V-!Zt!yfOq2+$ai6|j_B9P)R4eQnWBB&2|KE5Mwz>WT=_g5RvhJ`u<p)5<U85*A{ylVo;6s_PYNOY6&<JnPa@&o!DTeZQW(u('
    '7PL>@Oh*aDVJ|)(3Z^q+f@(`a{zUSVg-xzan>x@A#n^dv7@Yg~MA!L1{0agc*{I5ufG_*y6vKGYgYMN1d@dcPpz^XKRH&Ve)pR#X'
    'p3w{Y^n89aQ$|E=)>OYshL%CUTICH66TjdYma`E5@7o&ia^?KY2i>d=$`pLy4A!o;*<mEI5c9e?t8m&gsXJ=k3iQ`73(`_xLmDET'
    'cx#b}$M5e0I~~vo;)D?&&^uxFqmnLu@nD(jZgKBm4AEoyaO>)eyB_0s4q*aA@JtnY7T0KGy|$RK)oLQB!Fh0O0|z$>g;f|hos-+p'
    'X-!?;4F*`jf+gnZPjF)|^i%B5;rO9`^~W5pKeX_a;Cf*zFKdBgfdfsc7Gm5oh93h^xtxxR=8-tQu4yDl!zj?J$}!rEH&f%LOh)e_'
    'w)ce!^lQyLL4GNsOL_BklQ-fy$^oF~(``|z9)PJ(8iwj{VUaOWuMb}~{Sg~4TySCGExvYT*Wly^4XVSB7TTbQ#|O(&LG!W7H~EUv'
    're|cA1Yfr*pV%N1e1;sIvnd*sa$`I(gxf(=ARr|1Bu0Yr&FBS4ByQ1$*L<{r;mWLJ$MY>Y3?YXHpejpqDZj5$KFh^Ott+KqP!g0L'
    'IVn~RDp-{uy>FwH5!9F7?^xyhheY=^fOe5g5%iWl=p`2m!{k7r_D%nqM5v6GIXwEV#FD~j!M$KyUYz#WgoB3Z5q&n$+!bS;cG9!o'
    '@}JjhM}%&{Jjck68zQM~Xu=bc+!$92D%NQ^z@_`o`#Vrk8E9>W9?)+Y>=E|in|64cN_D-ujw*NN+=UfPP?KfX2X2flM@4xIp1HXz'
    'p+i(cMGhViU12pT?_=VH>QL@80xeGmL=%UW{drs%zOWiwGaALwTFj(Dw&*;bc>lW|h&F|612Nw=T|0r{>6=1A%f^lVgz;`3{Lcra'
    '1Cdc;;E>ni!A2qn_VM}wz<h<cSGHS>u@Z#x&I+btfK<$*%29k+Hq~?aJbrSYKm)~Eb_mIgTaKXs7kt?P7J=Omp}hQr0pdi)|B$Yr'
    'DsNrNh<w2jq2;+-)M9xw7)g45vnFI8h&3uD{C#v|PwvJr|BKWZ1jP(M-om*z2=%{l2%o}Fvga}F1>kGAl`YJR`MGX<q%|p~2<dSZ'
    'p}+VsYQ|kn5g-<W-&GI`RH?UB=1LRkFsDjfpK%-alasugou+c|lR~SP&ilm^o1xQXrnbcX_VwyT;{z`7N|2~^IsiOzX#Uhm{EMtq'
    '>y=p?MNA{oM5Gu(kckr!D`v&?54SP!>*5CZS>nx>AhILo37<kUjY)pqweDltxfdV3Ca+N+)N2KjQs&X^-YN4?`%9AGfpUM7(Ky>|'
    '=-^y}((%BmuwWs9P#4l(xU3K@?(D$f+VZQ*;Q)WreJ9<lLe(^`)q)b*z?Y9usQr`VcNJ5w`Xf3*y_HH6IaE=#dc%$*a$=uv<Ag%@'
    'H8l>{cw>_azF1$PuV9=b42MA~W6aD{ZtyK8DAj8+Fc#v~i-g~ivUlg5x2-G4Vy6r(;pQh0nGOWbej2#t92N9d&=gqg#{;W!#!7%{'
    'jA>TKNrbiqIuQH$v$;fhEf?fKwf2))Icsg@0tDe!<Fe&v3FhTqJI)k&7FB1B503h`1-}HST=vBYN}u0r5CWi3Zi~T$_?5t9)1A<R'
    ';Ei>qA3!EBt6#rj-i<aS7~K|7jjur*6w{%j!Sj%3Nx%U*<WUpmzR`8;F&@GsIw^!~=&rWYLl}j>!qYZd(KPd3Wk=~vOY`1L{*R$Z'
    'Yb%^tai(lwhfre#-=6-@pBM5}E4@H|E5POya8WNza`azWJm|E;@j-K-f@!}MM<+#x&*-lbkh<ReVv8b+F^JKtm4O2%_LWjAxoW6P'
    '6E;7O2{}eS!x?@Bwbl{*9!iT{QDzNJC_>(`+g511(3`IC5MRZv`7G!%!0t*wlP}tRkRJgm7wH5NP!BT*gh`*BXn}VW7w<R%$gY%R'
    '%vw0VFB}FmeNn4WBtME^{w0c8S>wH4W@erpp|e$*23CuuuSM^1GVHA_|L_QVrgMikKt-0QZmhk;0Lwvb-e%T~DDv!~RItrx|3+_@'
    'BIPJ^?qdKpadDvxS2aNmYIXQ_-;$HVTt5~B^0!gyl7!45<BYIxMa_bAesG*Ci3+5{GtZ}yq8FHF15qcg0)2dk!A_fq$nuhr#Z<M4'
    '2lCQV<JLPs=vIkaEZ;qJ`EIE2Ch&QgLGh=qa?za~)T#d4Y?`vYrhn$s7L1<Y@`V-)Lkk0x!Hy@oh^ivVf9z^46WU@{tpImCC>tge'
    '?Y+5cAG1I8dQ_{2aW+`Ifj;Y4oOm}b{c_zl#Zg^#3IniIFz<#oA(K_Zuc3K85-Mp!{1;lGemrv;*FzW)YhtdaiR6L-4BN;la`}vX'
    '#`~U)f-q~*U6TE)8r97=D?(=-5bZ|8>;gOoP|Ev891ju~CYkRey}d)(O+~)gt6XKRBx?kpW9lLL#;T^MdrK<JGQmqi5VtkD(8Q*C'
    'zAv}l^ykj_J#kCIm$Pm!Dx4F?{-LL^ZG_ONrLJo1T>Yfh(K5Z;VA1))B~Y87M8tuoQ{hj$!d#Y;lLtkE^U61np#9sTND6KW<dCHp'
    '>&uo!p9-~)VH1^FZr_ZTkU1YMs^(spg#hX8KQbyuUTW0H)4QL6@&02AhaTMF>=A&_Y;4->?5+Nc^^h!N6(wYaS7(Hxd#8}%Qj>Qu'
    '_q?HS^G#U>JmE5WG|3l3>5al7D8kME9<O9xF1Y9)@aJpr0x!1Tm*Xz+nUJB|eL{^=Qo1cw{rXYykaG{3I>0=)RWRNQK;T$_1o=h<'
    'Akipy_@;^>kj}GZn36-8={A7PwsPkIsFoRCJ7Rj~<!*PMkS=s{IY;KIGB>sRE~hGR#GUY8DAUT8gyE}HJI{KWN6%y4w{e%3AzwS='
    '1!h9E6=S?l+Z)!9mM!T(T`{_G@utuFvi}2;{?4BYvk?<wuD8d&GTB{{dx>)tj&-nxCr0HPQ8P#-CUCnac<*$jTEM}c$!!R2*9BSj'
    'McvKE>sL492Adosf(7ndXxIp-_w%~TdlHG|uMOqH6O#!aC_r7p*hra6YaTa9rS07RTSAJ)3Eicv=$WeN=uQJigaq(ZUR+J*(?}p<'
    'a-!NSo+WHo5^xANbzLC-OCNl1Pu33R0s4FmuON8}z99+g+FkYF^sQpRSCTZ3`VFNMf0cjw;s9^?KsuF+qDZ+wJKp?{9|wTJgJywk'
    'qfbbIXZS9BT<<Q!+y!+V<H;fvmqvXUWyZa1JSKNX(D&KaJGYtW7^Rs_>{}|zyUy*V^(U1r#H3~ylUvf`J(vX_BX25>`AT1&n>~KZ'
    'A~rUi7iM*Fo(b9m&WvA?RPb)CL!=FCd?M^|B8e27t|Pk)B~#@=vTl);hjN$UZ=IAjX*KD!Ru}INl;sMcttS;qEo0siR>I~L6Ps?K'
    'TVfDbNb`9vh#qfWago<1U+!V`@PdCk`!T+`bfVx?Bh(-Oh<bl?JdTv)r-<rKE<?IBJ1~hox_xp^ylQ%^!xx)V8DE(nqzyQkSRMmi'
    '-5`bu21H{$@SOPVQ!wb(DC3o*Oh%V*bJ>hTrX5ixZ&NN4XRn>O!9D@3FZv2)_pe3^Ye&0dNOoldm2s82(T}6LdHS{?;LY()b5g^^'
    'Sb^l1*&bn;OOJ)zVxZeKd2N$64#bM*^slNA>gFi@#mJVK<P+8@hmvZttV&v+>~48<=9PkwELp<L-8QBu92ht0F9k<+l>u=HhoRzb'
    'J;cKaf;YoImvml|QdxssKN4d0T9L(e-7I|*tZ(F-kVH-j92^HIMbwzn=*>OH{U2105rJA!k_rCE@W}iipEw5>1oadt9<~hiP0T_N'
    'ZWZj5*$Po<IDx)rewgxFqx-DW))h|;li5O9x8CBb$E8bqrkv5to2x#eZzybdp<M}9s)fgfQPl5inY8?#eueJJ*l8yti{IWf0Qp%u'
    't{V_Ppf#7h2CvG}T2@_rRc#Rd#_2uE|G?mT*#3`oRxU2TTU(prWigx<0R!X$!o|+U)=>mKo+uDdJQ9PALp;I2=}ORi^KLLA@U2G>'
    '09ci-()rdM>1p70!9e-ka~medWiNtJ^srW@<AA5w9u>CHK>%Wy=p@F_acVpYL{0OphQBm)y&<iU(TAD?cL2DA=$ynj4#NU;SK8+_'
    'i%Rt~2$JJoTb-`K{cOYi$7oXjpQ7T&q`b^>icWi)4W2S(Dx#D207VSD-H!yJ8Fnd3-3J<n(Ll?ymy*S>u~r#ea}?A*`Fuqnpx*XK'
    '{G*ze_p6O>{jPRF4(~f6N(ft%)>}@FDfs{YAn!5v>ZK)dkgDkYG_f1Rr)NNdYITEZp@qft9?u>c7=%;}4=+5=+3-y5j8#q-(pV$!'
    '=BC8s(P}zP3rUVbeL?>PcI$%V=nDmQnpv_w{2<X9Yt68!VI@GV0i^@lX*3Re)k50JEB^onJ77Z*GqKIlo#!!%$~6Vpmo`1$q7?Yy'
    '%U*Mr&Mj`*1e8Za*##GOAxg|Xkt(C1XbmT*NM&NgNp$u$=Hc9-V+K(n=aOE`1x$!sL<0{vB_wNfWy@{D2mnMR*+6rxIi89I=Xl#_'
    'zkI}082HKhx(6k2XZX5doD{w{E2SUCXM|zW|FR|1NDPQARI?Q}@B{vv_(%GbF2|P^H0p%k4?G_|9gWP-SS1|h5?-Mglvz7vpJ?$m'
    'dWLzPn(<=|PfuC#8sktS&3yOAgPh<G$rq}f&GxRku0oTH5iZB*!NmN-U{MquPe~$#tYYzJ912XNV{`V$=kGbxR1RnRT(T1=XH`|w'
    'dmoE?zT82hx!thDYLE)BMJO)S#A<7M7ufn)bF`*sOmj{zngLcB?<`uyYV&YhyxArp0D<gmHtDY>nlYeeaZ)u<Lk@x!=hbejTbE^&'
    '+Hg<WrO@xXl&z;-Rc_w_F<dxn=aQf&m^J*HbV%duJs1Aa)`nl37I%b-Wh|`RW7ZWg3j{3YbUIHuF_Fjc;9+I0c`z%lHquZiq(}>C'
    'K1d@fvpKurL%23cEe#N`D{UZt!@;>!KS;)Qi|N@hGw3Y8?{4VY|NL3`+xHRRa0?knVEWrtZ#&rkrR^dhmQTX;eakcdXR-+;d5!pk'
    'P=DiaYJ|W^`pT20rQ7ixX5f0Ey~hPgjf|$Q3<`hwO%xhF&G1jnYG&c2L{6>Dz+jel$pC|LqSVb~WKj?C;jW+3IQF7&$i7NgecB_m'
    'Zuw73W^$`0EM7i6p*m_LqXorkL5B-!gjU`em48Z-9l&g8J~n;Q5!F}Hm@;*kHx&3>;%sMlqhCbFXo0?f8;oTUh^o$B_53-`5II11'
    'XwsEylijqG<iZS^iH<?jk2gq2dddWd{DJwe8>p3uPJ(esxbb=ar}4^<#r^Gn%%eAA-9xbq`7o^a*;`P}{q1dIHK+$|LSjgn-vylY'
    'aOEpPIGqZc)@gxfR)~YNZcP(xFa$;i&CvJ5`or0NS^NNq9?A3*rf|jCz1Btbm;j|H!A9OPskpI%(S6kBbkkDkhoSjCrW=CF{=NMp'
    ';@_=U5R?3cqABvtzP@02^;(`c6x6-C_FV_#kL)uZL*q8Uy%wCqanmvqKn^|-szMnTTh@(Mn1!gri)A}B9hYuJHuP99^KE|ECA+7@'
    'z~#gT*yl0II0?1<kXO8?5`Y_eSK>+AFG+!8rhC<<!xl;QrEcP@MgN%~)ce!}B$0|^Gu#4R&-~_&?2b(-*pwfULE`#WGxM>jxQCty'
    '4mG4F0G?yP`GdmLu?O(Ty`XV4a8x4l1Xjb@W3>ZUnj<E~pOM$$jGGJY{8cip)<@%DaET*o16G>b1G0W3qK_S`t)(@lR<VK#Il{CX'
    'Llf(UJ_}-#&A3%}&71l=aow=hTv7Kvbx9}BjnoVm3Ssk>{vINGB@Q!A$Npm_r{s~FP&9lucyqmRvE)d&+Mx|&kd2f4>rk8qb#=Zq'
    'YXjC!ef}i40{Hsb)2*!|?}l<I(Ei4><e%>8P|PFtj)GTL@k(gn{Ta|xhAsNyRc#(YIr&hgtMz;kJf6Fi0O)X~X=Or#eC6^}7rX6b'
    'fAEx^P0`u+iQY;?z>`U@wK3zp^sBi0iF}n_;Fxs{md-0|dg9*Mr5A!+?1%V+eVZ<3F;BfX$!Am-9HMR0^I%404SI*;SU7TQ*3>|_'
    'nb*OuHrYG4NZt14W;c{%N<iX-$<X=lsHv9R6QOt<FBJ6pXe#C?kc)g(dNPXu{Pt~7zkiPyQ>@DuCYIIQS5B+{f4;_i)KJ@jc`Orq'
    'UQq)gmmz5!#?cgZ%LM~19zA#!Ys4^SvJlBKX0~H_pan)w%LsE|C<)~m?jK}qZ+LZh3<3wa_<Y>YU}>0`I?Sj!!XA&WrG@AMPf;y)'
    '3)!wt$r2AdlzZkE5_gBICL8NeQ`E&6tOR@BZVMGFhlV_Z^A}B=mW#v0?p?B$jY_`EIAmpCd{=H~Nt@V7x-n~lQgxQ-#8RCJq|5f|'
    '5`3E-y&Ei}b;YS9U141RweE(&iLRSCE@Iet-3T~l>u*ej=@!~-0#mCxK?GVy^uqJqFqZSEd?N<=<r!)N)8ijj^7HD~QZzP+ck;Qp'
    'C3Oj&rQN7dhLn0wM0egOSz4)EYI1-+|86u9yIsZd0eZ<o+Ckl@9&H5chcf+rs$#4mUq=N-*(`{u{+q|Z>gDG%#Ym3(D?y3p<wXzl'
    'SP^G#_dOSLXlvdsAv2BYk;1Qd^?s7!--=A$=mRykMGzqPH(0(!A(k^CWnx%1S*)@~0En*ZSd9AgfX7S+H~gZ-Y00pq)#$SmPN`U='
    'VP!z~4v{|@Uj!bw%5-e<NghOIGii`q1l&p#DP5~6un)rl0P^$*+i=w*M`+(EUY!avc_qhM<-d_DdU|R;`QZwqW{3+L7`?j_+bdDn'
    '^ssu}Af;PnAT_-Eh~Vc~u?xN4>t6VYApidTB(h9Xy{(`p!v+-ABryl*8@f{CNmrBDC)Bbd>B~x&#6iJVSH@80HgzjxYk7N@_pBl+'
    'BxJVAX=4h|^~)QK%5?{d-%^*VP3QhPLRfu~Z<ap#?sg~KD}KJR;7bSm&>)A|YSg<~Mr%=MDfr-&k<8F#O(!cVI6KO_9il}W#*UjV'
    'YXhAt;U2pSi+H+z<B0-UGV{uJax|08#gD{D;kv^$Q>Hg6do@CQaRb}xah$%WP9|~4a6VOI?dA-NPe1<)YxaeX0u{_*5;G~$QMfbJ'
    'sDJI-5VH2E5|6t#hwV*l`;jNVD<@_*)3T*{%van`jb&d@PGw%|IYEKk;h+J=enn&_s{B50&LKMc1@jsM0F_u+2x8I3)m1K#=DQEI'
    '&qiQ)FGy2*1Ba39w?)cUK0I9yULMUYdyR6g>J$e$@-&^5;~QIg6Uqc`WxCYnS`QD>W%Oi(2`W2^XZFu$XhGYXVpNd7MZ1GjiN~C{'
    '`!9|CU9;ABLj0%cG!>qJ-CgF7_-&o`_=8F>@|EsS#Og;eD<2LkUDMCwCG>1U9#)9rU_MRA7}%u^wuj8hs9<Wo^@mTdzz!xGw0eMq'
    'BZ1?2C4Q<24&4`E@n8}QR+!iKPv1smPP>RlX$=h6ixrO@S~sV;Z=ja(yU=~30OAXnGdi*+RoCIZp#3{7UXZpcL=g9dQJ{YoCuMs^'
    '^r>mPRgRT%1Zk2Od#EDx`5wewtSFoS5mMqnb&dz*RYd`k4;oT}VG5e1$M5OR;@V96?0<bE`Fe#$M*skxe&vU~jo-HsRVLnMCeC2w'
    'rOoP5%OFp6xlqF3L!6o!y~S(pR7oQ?h#s2H{TVC*b}36uM38Nq6}6yHH|k%|Y`7fh#y1||xmLh+V8Pi(h0f-D6xU$vx$@lMtDl8#'
    'tB8)CzMgO8%fw32LX*Ai=2k&3Nwu)^ca<ltvqg8#nEd1Liw_<dpITo9$IBR}zH4zhy1C21TB4B_4h6tZ(bBnmf04w<3+RH{o<scq'
    '#`Z|2TL-JqZHvq`Gl)k&&io!v3!1{Z48OD~Z3Yr@$&linv)SlFlT5w)%nMOOs#C^&=X>$9a9~g-8Fr>-)uZF!^?hcqKINVByeQ?Z'
    'GFY3A1&M}d{kcnlXv*r>naEtM6Dl~wYsw;A?SsV-dneen^<P(!<6{J3E#Co1hEalB7lD)vw$<7SwFaRJkfdVxTBOeP9|g7K#pZsx'
    'h~AhOG2uAmaB<=UBt%?`^s*%N?rN0UD_tZq6J-PIY(fu9A?`qXy{h!qq<Ki#NY8){_*Ic8$=8186&8X(<U8IYYSn6ci*mZ4QX!b4'
    ';xeX1QSVxTm>XRWvj&07j}_ylpfb=-P1z1i8G0n?rgmXkS!gS_M<ei4Mr+P0&)h@KKR~BiBFcE*x%NYY+Lz_)9VJPJxtbi0Jl3mF'
    'n7}O1o`tT&&fOEZPjfcoCu`e=%OGAsK914%CiL>#7k7m&A7NvpFv{iG#80%Zvfd>^1Bz5<=<zb1YiB-v7xOCBMdL5SR!^ExW?0Qe'
    'P$m{?sw*ioBX93^dJRg!3o9FM6gWFh{kvBCCazaE6Uk`uKEKmaY-YgHDz0o0IHPiwN4w*Y%zaBz|L!37e*hVZ<MplIG>ZkG)*4xK'
    '3ED!?E2&4sh3P8+;L08ylfwV{d0_^mA&yfrE?`_L+OgnE?5>P&5D2YbnAo2QwkxkdhW1uDqfp)T<X|mQ2`yfau4Ihi$l=?+hL7nA'
    ')#Y<r7BG|xQ7z|BBo{2PHbMtSuqUmNyY+F`mSJE8;ijeT23>cC!h^tQM(^8dNi~c1PRreHLmO*)vSQn}&iPFmG$BF{cEZ&zENp;0'
    'TR$vdMbJzc-({MDpUVJA<FW2G>i!H;F!e3`^X9XOADID2=V8@Vk`0jSH22Jqsf4PE?^D{-hJ&z<jHoWN9A~$V^+B+4o<uB8Uad5&'
    'ggzT`<qh4^{Q45Z1r59NNsw6zW=SaET)AjYmzDAvfJtx2dM`V)YE4n19zD>nB~w!frTeUk)r7mdchbhxe9jOTt)|2ZHlAmvvDw8t'
    '>Xb7fE4c(@)XJM9YL0}u+HH3-xY|>LRnKsySKf2dCV&&OUOQLd=!Tlz?-|b$-kzAFf!(Q^7v>Y`ILkbL0sz0J{Qzfr8)j?1$IG;_'
    'mfO2K-a(Co;Hi5|Ew2Jz$C25aEftJ!pqW524zZZi{cNsQu-M=trRq1Yx;tk)eavdW@Ju&>JCEi4PL1e%Y}h?QU2KX2a|r})ef%zy'
    '#04|2tS&eydFDv~PTEM+xuVJgdal@ycFtZOO>>Uj-c!3+epJ#aU_ev?L4z2+j4D4L{g#ym)*-B5$00v$UVnYKZ@S))?o5tG((-p7'
    'vWWM31x<QOSB{{prh)>SD=^3$r`K86D2V!ZDjm2_bqDI|?}IkpY5jw`edIOM!I09)#N>`C`7@5DioS&V!ux>WCb7W96@^j~5^#Tc'
    ';w(UyAgsCXta}-?<cMlPyB_Xq|8)?!V2BT&Krn=Gc2pni<VFtyIZ_}l>v{I)a6DPxkgX8cGV7gOuDQr|!?gwOvLD9}^4P{pwH20+'
    'wP}oa2qH~Tdhp7vpM>}IY1?^<p(onkebbhwgBrT`C{%KNhi-|R#*Loo`))Z21F0WngO=+>nQq$Gu^Wp8t-{rTZLrX^-JcS=dJ#G;'
    'o0WR2<2QaMes{Q#bA9_bhBtFQns2Z~jgD#ne+Nj5qMj}V-7^-H6tSBrd9jCqK<5``Z&>@`!wu~@(C=;!q2lA>U!T@%BqmNP855?4'
    '$pX&Xn9kn3l5*Dd2=hY{^Ze#IOr5Xra0P<Co)OUjS>9?A_&OAKS^~Q5**_~n#B7JC(`fHSJN|-x1Z}Lw;gE~0qh>>M&faaV*lq@('
    '+6lC?xr=5`*Jd>=9y<1D(@l{Iea|w=<kE6AAE~NEb$q0-C|6!U!>)llVMv@_;lNJYiMM`D57)H#2~-tx{Yd6W1vn;XB^l^9*^4o%'
    'O(I;4ifa!^H2I!IRy8K~Jiy`425ZV5U<ztxPD)11*AXt+*=hpQUfeK&KUgHeP;CN;D7RQ^vm;}KM{F&dL~KHKdwf>swIH<N;R(>f'
    '<6u8$o_R;Lobk39JJt6a&MGCVI-r6}{b8y`%!xW}??CK(w5r#1BDrJx62mnH(6v(sw^7~nu)q{(#dwqprsAOm{=jIqsrSbEt>sJ`'
    'w2T(ifgw53B-$hcyLFH}nEv=W4Qz_{GL5m2w(SNLIXLp6+Se3)UBsFqAfJcQeVq1yUa%g<e&-t}4qvGi1y*(KH@kkAU-RrXvSGj%'
    'YQ9+^$h9QY@g)9{HB%W4Fc3W-+d8>r0fEM$pR#FQ#ASri#<5f>KU|6i%c&B)Dby_UnA2+V4$p-d#}FQdDgkPw%D#Xg;5S{~wA~3<'
    'W5(b07WqYtSyVft!;~wJ7QuB6Zdl(ZbI*_t1)cl(WNEU<A>G$h)yjQ}0Ubeq%(d2ZYm45Wm!4IHA;Y84|D1pl6+H#RCjT(LLOX89'
    'Bn3LiTx<}zXp)dzfzA%vwDn+_NotXOQM~J6PRqDEVO5mEWE*K}k~97Zi9-t-Y*QBjwB3AM|7-@652q||E8o~G{BlFR`p^Kjy?UO?'
    '8?pN{n)RAm+!Y~oE2634&W{OZSfm{At@(Lieaiv<@_<dtn_8IhuUqZj-^t+$$v)A1*oq0kbF5Hz1Azi0nF5GzltH&;mhs$Jz>Tf!'
    'NC#Rnp*KHLx6A!U;2BN=moXB>((&Z9rIzjH`#?|6hlABq=)t0AV?T(X^cwyPv?K5Op45sBLQZ*}YTg8@rlkI~5m@Pk)pkvV=w3U6'
    'd(27+nmP$$Y!^#gxI9+_<Geph9^=#+66jhUqLRVP(1f+smv_mUf8x|tdCBZat>)Xv%9xvNRSanO`$=jxKP)oK{r~`Ggh?`b#tuOy'
    'M0dT*`Rbto9U|TErHZn7%33G$5ArO5cgUZ4OVLhi!w8|R8TZW>YFTgiftJ2G_aQ5j60Z3Qtt{CXOs5c=xSp;_3^ky|pKc(z_W}z#'
    'Kj}2}N7PaXDVx&t?uOI3<@<nR0dQgM1pvFM{4xdR?vV}|MT;2FkXaAngtkfS9Y!+H!XN+Yz{s2iQ1D0w^raw14d>e)B^*;4FNeky'
    'mLq+Xgjni{{RTS~&r=YU-0!Ac6_*GmUdjVT3W%cQfw&6t0#Qd<?B|94<g}NSBP!e511bwx1EMhkwv*By$r66^;?)r5b28}Lc_Lyv'
    '-J9UMykgR;+a4Mq>E3T5_zVuOSDsaR%@KkeI45?G)c46=*7^qexEJ4xh!U0p_HEJ6*jrS6CAH^DD=g&?Grzb8Rc~b9Q-_R?{xel#'
    '*uD6jVE~W!Sn(%&)N%(MMS$I;GwM4M7%-XRxJJOj*BAyOAcc8&0!)Uto{mBIzMG`f;#B2cd>9p(2sBA;+<FBcTpj8q0Zr8@kE*G_'
    'g6x-YVxiOV4YKzQt_aaggH#$e*SP73chd}_{U=@R^Wj)XBT#l!g^GnwoRa%0jvqxwZi=JiCfj(b51#!rb2-yXr#Pf~`f_$IQK^ds'
    '00000S{q+SN|k*<00GUh0*%faXN!E_vBYQl0ssI200dcD'
)

PROVER_NAME = "false-solver-d11"
PROVER_SCHEMA = "stage2-false-countermodel-prover-result-v1"
MAX_FALSE_CERTIFICATE_BYTES = 20_000

_TABLE_BYTES = None
_INFINITE_RULE_ROWS = None


class _SafetyWallExpired(Exception):
    pass


def _safety_wall_handler(_signum, _frame):
    raise _SafetyWallExpired("False prover safety wall expired")


def _arm_safety_wall(seconds):
    if not (
        hasattr(signal, "setitimer")
        and hasattr(signal, "SIGALRM")
        and hasattr(signal, "ITIMER_REAL")
    ):
        return None
    previous = signal.signal(signal.SIGALRM, _safety_wall_handler)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    return previous


def _disarm_safety_wall(previous):
    if previous is None:
        return
    signal.setitimer(signal.ITIMER_REAL, 0.0)
    signal.signal(signal.SIGALRM, previous)


def _runtime_config(config):
    if not isinstance(config, dict):
        raise TypeError("config must be an object")
    copied = dict(config)
    save_mode = copied.pop("result_save_mode", "minimal")
    if save_mode not in ("minimal", "full"):
        raise ValueError("result_save_mode must be minimal or full")
    nested = copied.pop("search_config", None)
    if nested is not None:
        if copied:
            raise ValueError("nested search_config cannot be mixed with top-level fields")
        if not isinstance(nested, dict):
            raise TypeError("search_config must be an object")
        copied = dict(nested)
    unknown = sorted(
        set(copied)
        - {"safety_wall_seconds", "use_finite_model_bank", "use_infinite_family_bank", "use_dynamic_model_search", "dynamic_search_seconds"}
    )
    if unknown:
        raise ValueError(f"unknown config fields: {unknown}")
    seconds = float(copied.get("safety_wall_seconds", 295.0))
    enabled = copied.get("use_finite_model_bank", True)
    infinite_enabled = copied.get("use_infinite_family_bank", True)
    dynamic_enabled = copied.get("use_dynamic_model_search", True)
    dynamic_seconds = float(copied.get("dynamic_search_seconds", 1.0))
    if not 0.01 <= seconds <= 3600.0:
        raise ValueError("safety_wall_seconds must be in [0.01, 3600]")
    if type(enabled) is not bool:
        raise TypeError("use_finite_model_bank must be a boolean")
    if type(infinite_enabled) is not bool:
        raise TypeError("use_infinite_family_bank must be a boolean")
    if type(dynamic_enabled) is not bool:
        raise TypeError("use_dynamic_model_search must be a boolean")
    if not 0.0 <= dynamic_seconds <= 30.0:
        raise ValueError("dynamic_search_seconds must be in [0, 30]")
    return save_mode, seconds, enabled, infinite_enabled, dynamic_enabled, dynamic_seconds


def _case_formulas(case):
    if not isinstance(case, dict):
        raise TypeError("case must be an object")
    source = case.get("source_formula")
    target = case.get("target_formula")
    if not isinstance(source, str) or not source.strip():
        raise ValueError("case.source_formula must be a non-empty string")
    if not isinstance(target, str) or not target.strip():
        raise ValueError("case.target_formula must be a non-empty string")
    return case.get("ordinal"), case.get("id"), source, target


def _strip_outer_parentheses(text):
    text = text.strip()
    while len(text) >= 2 and text[0] == "(" and text[-1] == ")":
        depth = 0
        covers_all = True
        for index, character in enumerate(text):
            if character == "(":
                depth += 1
            elif character == ")":
                depth -= 1
                if depth < 0:
                    raise ValueError("unbalanced equation parentheses")
            if depth == 0 and index < len(text) - 1:
                covers_all = False
                break
        if not covers_all:
            break
        if depth != 0:
            raise ValueError("unbalanced equation parentheses")
        text = text[1:-1].strip()
    return text


def _parse_term(text, variable_indices):
    text = _strip_outer_parentheses(text)
    depth = 0
    last_operation = -1
    for index, character in enumerate(text):
        if character == "(":
            depth += 1
        elif character == ")":
            depth -= 1
            if depth < 0:
                raise ValueError("unbalanced equation parentheses")
        elif character == "◇" and depth == 0:
            last_operation = index
    if depth != 0:
        raise ValueError("unbalanced equation parentheses")
    if last_operation >= 0:
        return (
            _parse_term(text[:last_operation], variable_indices),
            _parse_term(text[last_operation + 1 :], variable_indices),
        )
    if len(text) == 1 and text in variable_indices:
        return variable_indices[text]
    raise ValueError(f"cannot parse term: {text!r}")


def _parse_equation(text):
    normalized = text.replace("*", "◇")
    if normalized.count("=") != 1 or "≠" in normalized:
        raise ValueError("formula must contain exactly one equality")
    variables = []
    seen = set()
    for variable in re.findall(r"\b([a-z])\b", normalized):
        if variable not in seen:
            seen.add(variable)
            variables.append(variable)
    if not variables:
        raise ValueError("formula has no variables")
    indices = {variable: index for index, variable in enumerate(variables)}
    lhs, rhs = normalized.split("=", 1)
    return variables, _parse_term(lhs, indices), _parse_term(rhs, indices)


def _source_pattern(parsed):
    _variables, lhs, rhs = parsed

    def encode(term):
        if type(term) is int:
            return term
        return ["op", encode(term[0]), encode(term[1])]

    return json.dumps([encode(lhs), encode(rhs)], separators=(",", ":"))


def _source_schema_match(source_pattern, parsed_source):
    """Match canonical source metavariables to arbitrary incoming terms."""

    pattern = json.loads(source_pattern)
    _variables, incoming_left, incoming_right = parsed_source
    environment = {}

    def match(pattern_term, incoming_term):
        if type(pattern_term) is int:
            if pattern_term in environment:
                return environment[pattern_term] == incoming_term
            environment[pattern_term] = incoming_term
            return True
        return (
            isinstance(pattern_term, list)
            and len(pattern_term) == 3
            and pattern_term[0] == "op"
            and type(incoming_term) is tuple
            and match(pattern_term[1], incoming_term[0])
            and match(pattern_term[2], incoming_term[1])
        )

    if not (
        match(pattern[0], incoming_left)
        and match(pattern[1], incoming_right)
    ):
        return None
    return environment


def _expanded_witness_vectors(witness_vectors, target_arity):
    ordered = []
    for vector in witness_vectors:
        vector = tuple(vector)
        if len(vector) == target_arity and vector not in ordered:
            ordered.append(vector)
    pool = []
    for vector in witness_vectors:
        for value in vector:
            if value not in pool:
                pool.append(value)
    products = sorted(
        product(pool, repeat=target_arity),
        key=lambda values: -len(set(values)),
    )
    for vector in products:
        if vector not in ordered:
            ordered.append(vector)
        if len(ordered) >= 8:
            break
    return tuple(ordered)


def _lean_open_term(term, variable_names):
    if type(term) is int:
        return variable_names[term]
    return (
        f"({_lean_open_term(term[0], variable_names)} ◇ "
        f"{_lean_open_term(term[1], variable_names)})"
    )


def _rewrite_source_branch(code, parsed_source, substitution, marker):
    marker_position = code.index(marker)
    branch_start = code.rfind("\n  · intro ", 0, marker_position)
    if branch_start < 0:
        return None
    branch_start += 1
    original = code[branch_start:marker_position].rstrip()
    lines = original.splitlines()
    introduction = re.fullmatch(r"  · intro (.+)", lines[0])
    if introduction is None:
        return None
    binders = introduction.group(1).split()
    if set(substitution) != set(range(len(binders))):
        return None
    incoming_variables = parsed_source[0]
    fresh_names = tuple(
        f"_d10v{index}" for index in range(len(incoming_variables))
    )
    replacements = {
        binder: _lean_open_term(substitution[index], fresh_names)
        for index, binder in enumerate(binders)
    }
    body = "\n".join(lines[1:])
    for variable in sorted(replacements, key=len, reverse=True):
        body = re.sub(
            rf"\b{re.escape(variable)}\b",
            f"({replacements[variable]})",
            body,
        )
    rewritten = "  · intro " + " ".join(fresh_names)
    if body:
        rewritten += "\n" + body
    return code[:branch_start] + rewritten + "\n" + code[marker_position:]


def _infinite_rules():
    global _INFINITE_RULE_ROWS
    if _INFINITE_RULE_ROWS is None:
        payload = lzma.decompress(base64.b85decode(_INFINITE_RULES_XZ_B85.encode("ascii")))
        rows = json.loads(payload.decode("utf-8"))
        if not isinstance(rows, list) or len(rows) != _INFINITE_RULE_COUNT:
            raise RuntimeError("infinite family payload count drift")
        _INFINITE_RULE_ROWS = rows
    return _INFINITE_RULE_ROWS


def _lean_closed_term(
    term,
    values,
    carrier_type,
    magma_instance,
    target_eval_function="",
    target_eval_opposite=False,
):
    if type(term) is int:
        return values[term]
    left = _lean_closed_term(
        term[0], values, carrier_type, magma_instance,
        target_eval_function, target_eval_opposite,
    )
    right = _lean_closed_term(
        term[1], values, carrier_type, magma_instance,
        target_eval_function, target_eval_opposite,
    )
    if target_eval_function:
        if target_eval_opposite:
            left, right = right, left
        return f"({target_eval_function} {left} {right})"
    return f"(@Magma.op {carrier_type} {magma_instance} {left} {right})"


def _symbolic_target_branch(
    parsed_target,
    witness_vectors,
    carrier_type,
    magma_instance,
    project_subtype_value,
    target_simp_lemmas,
    target_eval_function,
    target_eval_opposite,
    target_stepwise_raw,
):
    variables, left, right = parsed_target
    compatible = list(dict.fromkeys(
        tuple(values)
        for values in witness_vectors
        if len(values) == len(variables)
    ))
    if not compatible:
        return None
    lines = ["  · intro target", "    first"]
    for values in compatible:
        application = " ".join(values)
        typed_values = tuple(f"({value} : {carrier_type})" for value in values)
        symbolic_left = _lean_closed_term(
            left, typed_values, carrier_type, magma_instance,
            target_eval_function, target_eval_opposite,
        )
        symbolic_right = _lean_closed_term(
            right, typed_values, carrier_type, magma_instance,
            target_eval_function, target_eval_opposite,
        )
        original_left, original_right = symbolic_left, symbolic_right
        step_lines = []
        rewrites = []
        if target_stepwise_raw:
            constructor = f"{carrier_type.split('.')[0]}.p"
            cache = {}

            def evaluate(term):
                if type(term) is int:
                    return typed_values[term]
                left_value = evaluate(term[0])
                right_value = evaluate(term[1])
                call_left, call_right = left_value, right_value
                if target_eval_opposite:
                    call_left, call_right = call_right, call_left
                call = f"{target_eval_function} ({call_left}) ({call_right})"
                result = f"({constructor} ({call_left}) ({call_right}))"
                if call not in cache:
                    name = f"d10step{len(cache)}"
                    cache[call] = name
                    step_lines.extend(
                        (
                            f"      have {name} : {call} = {result} := by",
                            f"        simp [{', '.join(target_simp_lemmas)}]",
                        )
                    )
                    rewrites.append(name)
                return result

            symbolic_left = evaluate(left)
            symbolic_right = evaluate(right)
        lines.extend(
            (
                f"    | have bad := target {application}",
                *step_lines,
                f"      change {original_left} = {original_right} at bad",
                *((f"      rw [{', '.join(rewrites)}] at bad",) if rewrites else ()),
                *((f"      change {symbolic_left} = {symbolic_right} at bad",) if rewrites else ()),
                *(("      have badv := congrArg Subtype.val bad",) if project_subtype_value else ()),
                (
                    f"      simpa [{', '.join(target_simp_lemmas)}] using "
                    f"{'badv' if project_subtype_value else 'bad'}"
                    if target_simp_lemmas
                    else "      exact nomatch badv"
                    if project_subtype_value
                    else "      exact nomatch bad"
                ),
            )
        )
    return "\n".join(lines)


def _infinite_candidate(parsed_source, parsed_target):
    incoming_pattern = _source_pattern(parsed_source)
    marker = "  -- __D10_TARGET_AST_SYMBOLIC_BRANCH__"
    matches = []
    for row in _infinite_rules():
        source_pattern = row[1]
        substitution = _source_schema_match(source_pattern, parsed_source)
        if substitution is None:
            continue
        exact_source = source_pattern == incoming_pattern
        matches.append((not exact_source, len(row[-1]), row, substitution))
    for _nonexact, _template_bytes, row, substitution in sorted(
        matches, key=lambda item: (item[0], item[1], item[2][0], item[2][1])
    ):
        family, source_pattern, witness_vectors, carrier_type, magma_instance, project_subtype_value, _constructive_model, target_simp_lemmas, target_eval_function, target_eval_opposite, target_stepwise_raw, code_template = row
        exact_source = source_pattern == incoming_pattern
        if not exact_source:
            witness_vectors = _expanded_witness_vectors(
                witness_vectors, len(parsed_target[0])
            )
        branch = _symbolic_target_branch(
            parsed_target,
            witness_vectors,
            carrier_type,
            magma_instance,
            project_subtype_value,
            target_simp_lemmas,
            target_eval_function,
            target_eval_opposite,
            target_stepwise_raw,
        )
        if branch is None or code_template.count(marker) != 1:
            continue
        template = code_template
        if not exact_source:
            template = _rewrite_source_branch(
                template, parsed_source, substitution, marker
            )
            if template is None:
                continue
        if "theorem family_submission" in template:
            code = template.replace(marker, branch)
        else:
            helper_scope = carrier_type
            local_witness_lets = tuple(dict.fromkeys(
                match.group(0).strip()
                for vector in witness_vectors
                for value in vector
                if re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", value)
                for match in [re.search(
                    rf"^[ \t]*let[ \t]+{re.escape(value)}[ \t]*:[^\n]+$",
                    template,
                    re.MULTILINE,
                )]
                if match is not None
            ))
            branch_lines = branch.splitlines()
            if not branch_lines or branch_lines[0] != "  · intro target":
                continue
            helper_body = "\n".join(
                line[2:] if line.startswith("  ") else line
                for line in branch_lines[1:]
            )
            if local_witness_lets:
                helper_body = (
                    "\n".join(f"  {line}" for line in local_witness_lets)
                    + "\n"
                    + helper_body
                )
            helper = (
                f"namespace submission.{helper_scope}\n\n"
                f"theorem d10TargetRefutation\n"
                f"    (target : @EquationRHS {carrier_type} {magma_instance}) : False := by\n"
                f"{helper_body}\n\n"
                f"end submission.{helper_scope}\n\n"
            )
            final_submission = "def submission : Goal := by"
            if template.rfind(final_submission) < 0:
                continue
            simple_branch = (
                "  · intro target\n"
                f"    exact {helper_scope}.d10TargetRefutation target"
            )
            code = template.replace(marker, simple_branch)
            position = code.rfind(final_submission)
            code = code[:position] + helper + code[position:]
        return (
            family,
            code,
            "alpha_exact_source_law"
            if exact_source
            else "uniform_term_substitution_source_schema",
        )
    return None


def _staged_certificate(stage, code):
    """Return the exact Judge payload and its UTF-8 size, or fail closed."""

    staged = f"-- stage:{stage}\n" + code
    size = len(staged.encode("utf-8"))
    if size > MAX_FALSE_CERTIFICATE_BYTES:
        return None, size
    return staged, size


def _eval_term(term, values, table):
    if type(term) is int:
        return values[term]
    return table[_eval_term(term[0], values, table)][
        _eval_term(term[1], values, table)
    ]


def _equation_holds(parsed, table):
    variables, lhs, rhs = parsed
    checked = 0
    for values in product(range(len(table)), repeat=len(variables)):
        checked += 1
        left = _eval_term(lhs, values, table)
        right = _eval_term(rhs, values, table)
        if left != right:
            return False, checked, {
                "assignment": dict(zip(variables, values)),
                "lhs": left,
                "rhs": right,
            }
    return True, checked, None



"""Bounded formula-only finite magma synthesis for False Solver d11.

This file is injected into the generated single-file runtime.  It deliberately
uses no problem IDs, formula hashes, frozen countermodels, or third-party SAT
libraries.  Search is fail-closed: every returned table is exhaustively checked
against the complete source and target equations by the caller.
"""

import random


class _D11Deadline(Exception):
    pass


def _d11_ref_domain(domains, reference):
    if reference < 0:
        return 1 << (-reference - 1)
    return domains[reference]


def _d11_restricted_growth_vectors(length, order):
    """Yield one representative of every carrier-renaming witness orbit."""

    if length <= 0:
        yield ()
        return
    vector = [0] * length

    def visit(index, maximum):
        if index == length:
            yield tuple(vector)
            return
        for value in range(min(order - 1, maximum + 1) + 1):
            vector[index] = value
            yield from visit(index + 1, max(maximum, value))

    yield from visit(1, 0)


def _d11_source_failures(parsed_source, table, limit=1):
    variables, lhs, rhs = parsed_source
    failures = []
    for values in product(range(len(table)), repeat=len(variables)):
        if _eval_term(lhs, values, table) != _eval_term(rhs, values, table):
            failures.append(values)
            if len(failures) >= limit:
                break
    return failures


def _d11_first_source_failure(parsed_source, table):
    failures = _d11_source_failures(parsed_source, table, 1)
    return failures[0] if failures else None


def _d11_target_failure(parsed_target, table):
    variables, lhs, rhs = parsed_target
    for values in _d11_restricted_growth_vectors(len(variables), len(table)):
        left = _eval_term(lhs, values, table)
        right = _eval_term(rhs, values, table)
        if left != right:
            return values, left, right
    return None


def _d11_eval_with_cells(term, values, table):
    if type(term) is int:
        return values[term], ()
    left, left_cells = _d11_eval_with_cells(term[0], values, table)
    right, right_cells = _d11_eval_with_cells(term[1], values, table)
    cell = left * len(table) + right
    return table[left][right], left_cells + right_cells + (cell,)


def _d11_structured_seeds(order):
    """Small formula-independent phase seeds, not a frozen problem lookup."""

    yield [[0 for _column in range(order)] for _row in range(order)]
    yield [[row for _column in range(order)] for row in range(order)]
    yield [[column for column in range(order)] for _row in range(order)]
    yield [[(row + column) % order for column in range(order)] for row in range(order)]
    yield [[(row - column) % order for column in range(order)] for row in range(order)]
    yield [[min(row, column) for column in range(order)] for row in range(order)]
    yield [[max(row, column) for column in range(order)] for row in range(order)]


class _D11ClauseModel:
    """Compact categorical CNF: every group always has exactly one value."""

    def __init__(self, order):
        self.order = order
        self.table_group_count = order * order
        self.group_count = self.table_group_count
        self.clauses = []
        self.operation_groups = {}

    @staticmethod
    def _constant(value):
        return -value - 1

    def _new_group(self):
        group = self.group_count
        self.group_count += 1
        return group

    def _literal(self, reference, value, positive):
        if reference < 0:
            actual = -reference - 1
            truth = actual == value
            return True if truth == positive else False
        atom = reference * self.order + value + 1
        return atom if positive else -atom

    def _add_clause(self, literal_specs):
        clause = []
        for reference, value, positive in literal_specs:
            literal = self._literal(reference, value, positive)
            if literal is True:
                return
            if literal is False:
                continue
            if -literal in clause:
                return
            if literal not in clause:
                clause.append(literal)
        self.clauses.append(tuple(clause))

    def _compile_term(self, term, assignment, memo, references=False):
        if type(term) is int:
            return assignment[term] if references else self._constant(assignment[term])
        if term in memo:
            return memo[term]
        left = self._compile_term(term[0], assignment, memo, references)
        right = self._compile_term(term[1], assignment, memo, references)
        result = self._new_group()
        self.operation_groups[result] = (left, right)
        for row in range(self.order):
            for column in range(self.order):
                cell = row * self.order + column
                for value in range(self.order):
                    self._add_clause(
                        (
                            (left, row, False),
                            (right, column, False),
                            (cell, value, False),
                            (result, value, True),
                        )
                    )
        memo[term] = result
        return result

    def compile_equation(self, parsed, assignment, equality, references=False):
        _variables, lhs, rhs = parsed
        memo = {}
        left = self._compile_term(lhs, assignment, memo, references)
        right = self._compile_term(rhs, assignment, memo, references)
        for value in range(self.order):
            if equality:
                self._add_clause(((left, value, False), (right, value, True)))
                self._add_clause(((right, value, False), (left, value, True)))
            else:
                self._add_clause(((left, value, False), (right, value, False)))


def _d11_clause_parts(literal, order):
    atom = abs(literal) - 1
    return atom // order, atom % order, literal > 0


def _d11_clause_satisfied(clause, assignment, order, override_group=-1, override_value=-1):
    for literal in clause:
        group, value, positive = _d11_clause_parts(literal, order)
        actual = override_value if group == override_group else assignment[group]
        if (actual == value) == positive:
            return True
    return False


def _d11_local_assignment(model, phase_table, deadline, seed, metrics):
    """Finite-domain WalkSAT with one-value groups preserved by construction."""

    order = model.order
    occurrences = [[] for _ in range(model.group_count)]
    for clause_index, clause in enumerate(model.clauses):
        seen = set()
        for literal in clause:
            group, _value, _positive = _d11_clause_parts(literal, order)
            if group not in seen:
                seen.add(group)
                occurrences[group].append(clause_index)

    rng = random.Random(seed)
    restart = 0
    while time.monotonic() < deadline:
        restart += 1
        metrics["dynamic_local_restarts"] += 1
        assignment = [rng.randrange(order) for _ in range(model.group_count)]
        if phase_table is not None:
            for row in range(order):
                for column in range(order):
                    value = phase_table[row][column]
                    if restart > 1 and rng.random() < min(0.5, 0.08 * restart):
                        value = rng.randrange(order)
                    assignment[row * order + column] = value
        # Term-result groups are created bottom-up.  Initialize them by actual
        # evaluation in the phase table so operation clauses start satisfied;
        # only source equality and target disequality need repair.
        for group in range(model.table_group_count, model.group_count):
            operation = model.operation_groups.get(group)
            if operation is None:
                continue
            left, right = operation
            left_value = -left - 1 if left < 0 else assignment[left]
            right_value = -right - 1 if right < 0 else assignment[right]
            assignment[group] = assignment[left_value * order + right_value]

        satisfied = [False] * len(model.clauses)
        unsatisfied = []
        positions = {}

        def add_unsatisfied(index):
            if index not in positions:
                positions[index] = len(unsatisfied)
                unsatisfied.append(index)

        def remove_unsatisfied(index):
            position = positions.pop(index, None)
            if position is None:
                return
            tail = unsatisfied.pop()
            if position < len(unsatisfied):
                unsatisfied[position] = tail
                positions[tail] = position

        for index, clause in enumerate(model.clauses):
            value = _d11_clause_satisfied(clause, assignment, order)
            satisfied[index] = value
            if not value:
                add_unsatisfied(index)
        if not unsatisfied:
            return assignment

        step_limit = max(2_000, min(80_000, 160 * len(model.clauses)))
        for _step in range(step_limit):
            metrics["dynamic_local_steps"] += 1
            if metrics["dynamic_local_steps"] & 1023 == 0 and time.monotonic() >= deadline:
                return None
            if not unsatisfied:
                return assignment
            clause_index = unsatisfied[rng.randrange(len(unsatisfied))]
            clause = model.clauses[clause_index]
            moves = []
            for literal in clause:
                group, literal_value, positive = _d11_clause_parts(literal, order)
                if positive:
                    candidate_values = (literal_value,)
                else:
                    candidate_values = tuple(
                        value for value in range(order) if value != literal_value
                    )
                for new_value in candidate_values:
                    if assignment[group] == new_value:
                        continue
                    delta = 0
                    for affected in occurrences[group]:
                        new_satisfied = _d11_clause_satisfied(
                            model.clauses[affected],
                            assignment,
                            order,
                            group,
                            new_value,
                        )
                        if new_satisfied != satisfied[affected]:
                            delta += -1 if new_satisfied else 1
                    moves.append((delta, rng.random(), group, new_value))
            if not moves:
                break
            if rng.random() < 0.12:
                _delta, _tie, group, new_value = moves[rng.randrange(len(moves))]
            else:
                _delta, _tie, group, new_value = min(moves)
            assignment[group] = new_value
            for affected in occurrences[group]:
                new_satisfied = _d11_clause_satisfied(
                    model.clauses[affected], assignment, order
                )
                if new_satisfied == satisfied[affected]:
                    continue
                satisfied[affected] = new_satisfied
                if new_satisfied:
                    remove_unsatisfied(affected)
                else:
                    add_unsatisfied(affected)
    return None


def _d11_solve_local(order, parsed_source, parsed_target, source_assignments, phase_table, deadline, metrics):
    model = _D11ClauseModel(order)
    target_references = [model._constant(0)]
    target_references.extend(
        model._new_group() for _ in range(len(parsed_target[0]) - 1)
    )
    model.compile_equation(parsed_target, target_references, False, True)
    for assignment in source_assignments:
        model.compile_equation(parsed_source, assignment, True)
    metrics["dynamic_max_groups"] = max(
        metrics.get("dynamic_max_groups", 0), model.group_count
    )
    metrics["dynamic_max_clauses"] = max(
        metrics.get("dynamic_max_clauses", 0), len(model.clauses)
    )
    solved = _d11_local_assignment(
        model,
        phase_table,
        deadline,
        0xD110000 + order * 1009 + len(source_assignments) * 9176,
        metrics,
    )
    if solved is None:
        return None
    return [
        solved[row * order : (row + 1) * order]
        for row in range(order)
    ]


def _d11_full_source_local(parsed_source, parsed_target, seed_tables, deadline, metrics):
    """Repair a source-valid bank model while retaining every small-domain law instance."""

    if not seed_tables:
        return None
    order = len(seed_tables[0])
    assignment_count = order ** len(parsed_source[0])
    if assignment_count > 125:
        return None
    source_assignments = list(
        product(range(order), repeat=len(parsed_source[0]))
    )
    model = _D11ClauseModel(order)
    target_references = [model._constant(0)]
    target_references.extend(
        model._new_group() for _ in range(len(parsed_target[0]) - 1)
    )
    model.compile_equation(parsed_target, target_references, False, True)
    for assignment in source_assignments:
        model.compile_equation(parsed_source, assignment, True)
    metrics["dynamic_full_source_groups"] = max(
        metrics.get("dynamic_full_source_groups", 0), model.group_count
    )
    metrics["dynamic_full_source_clauses"] = max(
        metrics.get("dynamic_full_source_clauses", 0), len(model.clauses)
    )
    phases = seed_tables[: min(12, len(seed_tables))]
    for index, phase in enumerate(phases):
        if time.monotonic() >= deadline:
            return None
        remaining = len(phases) - index
        slice_deadline = min(
            deadline,
            time.monotonic() + max(0.03, (deadline - time.monotonic()) / remaining),
        )
        solved = _d11_local_assignment(
            model,
            phase,
            slice_deadline,
            0xD11F011 + index * 65537 + order,
            metrics,
        )
        if solved is None:
            continue
        table = [
            solved[row * order : (row + 1) * order]
            for row in range(order)
        ]
        if _d11_first_source_failure(parsed_source, table) is None and (
            _d11_target_failure(parsed_target, table) is not None
        ):
            return table
    return None


def _d11_equation_trace(parsed, assignment, table):
    left, left_cells = _d11_eval_with_cells(parsed[1], assignment, table)
    right, right_cells = _d11_eval_with_cells(parsed[2], assignment, table)
    return left == right, tuple(set(left_cells + right_cells))


def _d11_direct_repair(parsed_source, parsed_target, seed_tables, deadline, metrics):
    """Min-conflicts repair over table cells with exact incremental source checks."""

    if not seed_tables:
        return None
    order = len(seed_tables[0])
    source_assignment_count = order ** len(parsed_source[0])
    if source_assignment_count > 125:
        return None
    source_assignments = list(
        product(range(order), repeat=len(parsed_source[0]))
    )
    witnesses = list(
        _d11_restricted_growth_vectors(len(parsed_target[0]), order)
    )
    rng = random.Random(0xD11D1EC7 + order)
    phases = seed_tables[: min(32, len(seed_tables))]
    restart = 0
    while time.monotonic() < deadline:
        metrics["dynamic_direct_restarts"] += 1
        phase = phases[restart % len(phases)]
        restart += 1
        table = [row[:] for row in phase]
        witness = witnesses[rng.randrange(len(witnesses))]
        records = []
        cell_users = [set() for _ in range(order * order)]
        violations = set()
        for index, assignment in enumerate(source_assignments):
            holds, cells = _d11_equation_trace(parsed_source, assignment, table)
            records.append((holds, cells))
            if not holds:
                violations.add(index)
            for cell in cells:
                cell_users[cell].add(index)

        for _step in range(900):
            metrics["dynamic_direct_steps"] += 1
            if metrics["dynamic_direct_steps"] & 127 == 0 and time.monotonic() >= deadline:
                return None
            target_holds, target_cells = _d11_equation_trace(
                parsed_target, witness, table
            )
            if not violations and not target_holds:
                return table

            candidate_cells = set(target_cells)
            if violations:
                for index in rng.sample(
                    tuple(violations), min(4, len(violations))
                ):
                    candidate_cells.update(records[index][1])
            while len(candidate_cells) < min(8, order * order):
                candidate_cells.add(rng.randrange(order * order))

            moves = []
            for cell in candidate_cells:
                old_value = table[cell // order][cell % order]
                for new_value in range(order):
                    if new_value == old_value:
                        continue
                    table[cell // order][cell % order] = new_value
                    new_violation_count = len(violations)
                    for index in cell_users[cell]:
                        old_holds = records[index][0]
                        new_holds, _new_cells = _d11_equation_trace(
                            parsed_source, source_assignments[index], table
                        )
                        if old_holds != new_holds:
                            new_violation_count += -1 if new_holds else 1
                    new_target_holds, _cells = _d11_equation_trace(
                        parsed_target, witness, table
                    )
                    table[cell // order][cell % order] = old_value
                    score = new_violation_count + (10 if new_target_holds else 0)
                    moves.append((score, rng.random(), "cell", cell, new_value))

            for variable in range(1, len(witness)):
                for new_value in range(order):
                    if new_value == witness[variable]:
                        continue
                    candidate_witness = list(witness)
                    candidate_witness[variable] = new_value
                    new_target_holds, _cells = _d11_equation_trace(
                        parsed_target, tuple(candidate_witness), table
                    )
                    score = len(violations) + (10 if new_target_holds else 0)
                    moves.append(
                        (score, rng.random(), "witness", variable, new_value)
                    )
            if not moves:
                break
            if rng.random() < 0.10:
                move = moves[rng.randrange(len(moves))]
            else:
                move = min(moves)
            _score, _tie, kind, location, new_value = move
            if kind == "witness":
                updated = list(witness)
                updated[location] = new_value
                witness = tuple(updated)
                continue

            cell = location
            affected = tuple(cell_users[cell])
            table[cell // order][cell % order] = new_value
            for index in affected:
                old_holds, old_cells = records[index]
                new_holds, new_cells = _d11_equation_trace(
                    parsed_source, source_assignments[index], table
                )
                if old_holds and not new_holds:
                    violations.add(index)
                elif not old_holds and new_holds:
                    violations.discard(index)
                if old_cells != new_cells:
                    for old_cell in old_cells:
                        cell_users[old_cell].discard(index)
                    for new_cell in new_cells:
                        cell_users[new_cell].add(index)
                records[index] = (new_holds, new_cells)
    return None


class _D11CSP:
    """Tiny finite-domain CSP specialized to an unknown binary operation."""

    def _new_variable(self):
        variable = len(self.domains)
        self.domains.append(self.full)
        return variable

    @staticmethod
    def _constant(value):
        return -value - 1

    def _compile_term(self, term, assignment, memo, references=False):
        if type(term) is int:
            if references:
                return assignment[term]
            return self._constant(assignment[term])
        if term in memo:
            return memo[term]
        left = self._compile_term(term[0], assignment, memo, references)
        right = self._compile_term(term[1], assignment, memo, references)
        result = self._new_variable()
        self.operations.append((left, right, result))
        memo[term] = result
        return result

    def _compile_equation(self, parsed, assignment, equality, references=False):
        _variables, lhs, rhs = parsed
        memo = {}
        left = self._compile_term(lhs, assignment, memo, references)
        right = self._compile_term(rhs, assignment, memo, references)
        if equality:
            self.equalities.append((left, right))
        else:
            self.disequalities.append((left, right))

    def _set_domain(self, reference, mask):
        if reference < 0:
            return bool(mask & _d11_ref_domain(self.domains, reference)), False
        new_mask = self.domains[reference] & mask
        if not new_mask:
            return False, False
        if new_mask == self.domains[reference]:
            return True, False
        self.domains[reference] = new_mask
        return True, True

    def _propagate(self):
        order = self.order
        while True:
            if time.monotonic() >= self.deadline:
                raise _D11Deadline
            changed = False
            self.metrics["dynamic_propagation_rounds"] += 1

            for left, right in self.equalities:
                common = _d11_ref_domain(self.domains, left) & _d11_ref_domain(self.domains, right)
                if not common:
                    return False
                ok, did_change = self._set_domain(left, common)
                if not ok:
                    return False
                changed |= did_change
                ok, did_change = self._set_domain(right, common)
                if not ok:
                    return False
                changed |= did_change

            for left, right in self.disequalities:
                left_domain = _d11_ref_domain(self.domains, left)
                right_domain = _d11_ref_domain(self.domains, right)
                if left_domain.bit_count() == right_domain.bit_count() == 1:
                    if left_domain == right_domain:
                        return False
                    continue
                if left_domain.bit_count() == 1:
                    ok, did_change = self._set_domain(right, self.full ^ left_domain)
                    if not ok:
                        return False
                    changed |= did_change
                if right_domain.bit_count() == 1:
                    ok, did_change = self._set_domain(left, self.full ^ right_domain)
                    if not ok:
                        return False
                    changed |= did_change

            for left, right, result in self.operations:
                left_domain = _d11_ref_domain(self.domains, left)
                right_domain = _d11_ref_domain(self.domains, right)
                result_domain = self.domains[result]
                supported_left = 0
                supported_right = 0
                supported_result = 0
                for row in range(order):
                    row_bit = 1 << row
                    if not left_domain & row_bit:
                        continue
                    for column in range(order):
                        column_bit = 1 << column
                        if not right_domain & column_bit:
                            continue
                        cell_domain = self.domains[row * order + column]
                        common = cell_domain & result_domain
                        if common:
                            supported_left |= row_bit
                            supported_right |= column_bit
                            supported_result |= common
                if not supported_left or not supported_right or not supported_result:
                    return False
                ok, did_change = self._set_domain(left, supported_left)
                if not ok:
                    return False
                changed |= did_change
                ok, did_change = self._set_domain(right, supported_right)
                if not ok:
                    return False
                changed |= did_change
                ok, did_change = self._set_domain(result, supported_result)
                if not ok:
                    return False
                changed |= did_change

                left_domain = _d11_ref_domain(self.domains, left)
                right_domain = _d11_ref_domain(self.domains, right)
                if left_domain.bit_count() == right_domain.bit_count() == 1:
                    row = left_domain.bit_length() - 1
                    column = right_domain.bit_length() - 1
                    cell = row * order + column
                    common = self.domains[cell] & self.domains[result]
                    if not common:
                        return False
                    if common != self.domains[cell]:
                        self.domains[cell] = common
                        changed = True
                    if common != self.domains[result]:
                        self.domains[result] = common
                        changed = True

            if not changed:
                return True

    def _candidate_table(self):
        table = []
        for row in range(self.order):
            output_row = []
            for column in range(self.order):
                domain = self.domains[row * self.order + column]
                if domain.bit_count() != 1:
                    return None
                output_row.append(domain.bit_length() - 1)
            table.append(output_row)
        return table

    def _choose_variable(self):
        best = None
        best_key = None
        for variable, domain in enumerate(self.domains):
            size = domain.bit_count()
            if size <= 1:
                continue
            # Term results are selected before equally sized table cells so
            # operation inputs become concrete and constrain the relevant cell.
            key = (size, variable < self.table_variable_count, variable)
            if best_key is None or key < best_key:
                best_key = key
                best = variable
        return best

    def _value_order(self, variable):
        domain = self.domains[variable]
        values = []
        if variable < self.table_variable_count and self.phase_table is not None:
            row, column = divmod(variable, self.order)
            phase = self.phase_table[row][column]
            if domain & (1 << phase):
                values.append(phase)
            for peer in (
                self.phase_table[max(0, row - 1)][column],
                self.phase_table[row][max(0, column - 1)],
            ):
                if domain & (1 << peer) and peer not in values:
                    values.append(peer)
        for value in range(self.order):
            if domain & (1 << value) and value not in values:
                values.append(value)
        return values

    def search(self):
        self.metrics["dynamic_search_nodes"] += 1
        if self.metrics["dynamic_search_nodes"] & 255 == 0 and time.monotonic() >= self.deadline:
            raise _D11Deadline
        snapshot = self.domains[:]
        if not self._propagate():
            self.metrics["dynamic_conflicts"] += 1
            self.domains = snapshot
            return None
        table = self._candidate_table()
        if table is not None:
            if _d11_target_failure(self.parsed_target, table) is None or any(
                _eval_term(self.parsed_source[1], assignment, table)
                != _eval_term(self.parsed_source[2], assignment, table)
                for assignment in self.source_assignments
            ):
                self.metrics["dynamic_conflicts"] += 1
                self.domains = snapshot
                return None
            self.domains = snapshot
            return table
        variable = self._choose_variable()
        if variable is None:
            self.domains = snapshot
            return None
        propagated = self.domains[:]
        for value in self._value_order(variable):
            self.domains = propagated[:]
            self.domains[variable] = 1 << value
            result = self.search()
            if result is not None:
                self.domains = snapshot
                return result
        self.domains = snapshot
        return None


def _d11_solve_csp(order, parsed_source, parsed_target, source_assignments, phase_table, deadline, metrics):
    solver = _D11CSP.__new__(_D11CSP)
    solver.order = order
    solver.full = (1 << order) - 1
    solver.table_variable_count = order * order
    solver.domains = [solver.full] * solver.table_variable_count
    solver.operations = []
    solver.equalities = []
    solver.disequalities = []
    solver.deadline = deadline
    solver.metrics = metrics
    solver.phase_table = phase_table
    solver.parsed_source = parsed_source
    solver.parsed_target = parsed_target
    solver.source_assignments = source_assignments
    # Search for the target witness together with the table.  Fixing the first
    # target variable to zero is sound under carrier relabeling and removes the
    # largest symmetry orbit without enumerating witness equality patterns.
    target_references = [solver._constant(0)]
    target_references.extend(
        solver._new_variable() for _ in range(len(parsed_target[0]) - 1)
    )
    solver._compile_equation(parsed_target, target_references, False, True)
    for assignment in source_assignments:
        solver._compile_equation(parsed_source, assignment, True)
    return solver.search()


def _d11_seed_neighborhood(parsed_source, parsed_target, seed_tables, deadline, metrics):
    """Search small Hamming neighborhoods of source-valid bank models."""

    rng = random.Random(0xD11CEED)
    for seed in seed_tables:
        order = len(seed)
        if order not in (4, 5):
            continue
        flat = [value for row in seed for value in row]
        witnesses = sorted(
            _d11_restricted_growth_vectors(len(parsed_target[0]), order),
            key=lambda values: (-len(set(values)), values),
        )
        mutation_jobs = []
        for witness in witnesses:
            left, left_cells = _d11_eval_with_cells(parsed_target[1], witness, seed)
            right, right_cells = _d11_eval_with_cells(parsed_target[2], witness, seed)
            if left != right:
                return seed
            relevant = tuple(sorted(set(left_cells + right_cells)))
            mutation_jobs.extend(((witness, (cell,)) for cell in relevant))
            mutation_jobs.extend(
                (witness, (first, second))
                for position, first in enumerate(relevant)
                for second in relevant[position + 1 :]
            )
            if len(relevant) >= 3:
                mutation_jobs.extend(
                    (witness, tuple(sorted(rng.sample(relevant, 3))))
                    for _ in range(min(24, len(relevant) * 3))
                )
        for witness, cells in mutation_jobs:
            value_choices = [[]]
            for cell in cells:
                value_choices = [
                    prefix + [value]
                    for prefix in value_choices
                    for value in range(order)
                    if value != flat[cell]
                ]
            for values in value_choices:
                metrics["dynamic_seed_mutations"] += 1
                if metrics["dynamic_seed_mutations"] & 255 == 0 and time.monotonic() >= deadline:
                    return None
                candidate_flat = flat[:]
                for cell, value in zip(cells, values):
                    candidate_flat[cell] = value
                table = [
                    candidate_flat[row * order : (row + 1) * order]
                    for row in range(order)
                ]
                if _d11_first_source_failure(parsed_source, table) is None:
                    left = _eval_term(parsed_target[1], witness, table)
                    right = _eval_term(parsed_target[2], witness, table)
                    if left != right:
                        return table
    return None


def _d11_dynamic_countermodel(parsed_source, parsed_target, seconds, metrics, seed_tables=()):
    """Find a verified Fin4/Fin5 table within a strict local wall budget."""

    started = time.monotonic()
    deadline = started + max(0.0, seconds)
    metrics.setdefault("dynamic_orders_attempted", 0)
    metrics.setdefault("dynamic_witnesses_attempted", 0)
    metrics.setdefault("dynamic_cegis_rounds", 0)
    metrics.setdefault("dynamic_source_instances", 0)
    metrics.setdefault("dynamic_search_nodes", 0)
    metrics.setdefault("dynamic_propagation_rounds", 0)
    metrics.setdefault("dynamic_conflicts", 0)
    metrics.setdefault("dynamic_local_restarts", 0)
    metrics.setdefault("dynamic_local_steps", 0)
    metrics.setdefault("dynamic_seed_mutations", 0)
    metrics.setdefault("dynamic_direct_restarts", 0)
    metrics.setdefault("dynamic_direct_steps", 0)

    usable_seeds = [
        table for table in seed_tables
        if len(table) in (4, 5)
        and _d11_first_source_failure(parsed_source, table) is None
    ]
    metrics["dynamic_source_valid_seeds"] = len(usable_seeds)
    neighborhood_deadline = min(deadline, started + max(0.02, seconds * 0.35))
    seeded = _d11_seed_neighborhood(
        parsed_source, parsed_target, usable_seeds, neighborhood_deadline, metrics
    )
    if seeded is not None:
        metrics["dynamic_elapsed_seconds"] = round(time.monotonic() - started, 6)
        return seeded

    direct_deadline = min(deadline, started + max(0.04, seconds * 0.72))
    for order in (4, 5):
        order_seeds = [table for table in usable_seeds if len(table) == order]
        repaired = _d11_direct_repair(
            parsed_source, parsed_target, order_seeds, direct_deadline, metrics
        )
        if repaired is not None:
            metrics["dynamic_elapsed_seconds"] = round(time.monotonic() - started, 6)
            return repaired

    full_source_deadline = min(deadline, started + max(0.04, seconds * 0.88))
    for order in (4, 5):
        order_seeds = [table for table in usable_seeds if len(table) == order]
        repaired = _d11_full_source_local(
            parsed_source,
            parsed_target,
            order_seeds,
            full_source_deadline,
            metrics,
        )
        if repaired is not None:
            metrics["dynamic_elapsed_seconds"] = round(time.monotonic() - started, 6)
            return repaired

    for order in (4, 5):
        if time.monotonic() >= deadline:
            break
        metrics["dynamic_orders_attempted"] += 1
        for seed in _d11_structured_seeds(order):
            if _d11_first_source_failure(parsed_source, seed) is None:
                target_failure = _d11_target_failure(parsed_target, seed)
                if target_failure is not None:
                    metrics["dynamic_elapsed_seconds"] = round(time.monotonic() - started, 6)
                    return seed

        metrics["dynamic_witnesses_attempted"] += 1
        source_assignments = []
        order_seeds = [table for table in usable_seeds if len(table) == order]
        phase_table = (
            order_seeds[0] if order_seeds else next(_d11_structured_seeds(order))
        )
        while time.monotonic() < deadline:
            metrics["dynamic_cegis_rounds"] += 1
            try:
                table = _d11_solve_local(
                    order,
                    parsed_source,
                    parsed_target,
                    source_assignments,
                    phase_table,
                    deadline,
                    metrics,
                )
            except _D11Deadline:
                metrics["dynamic_elapsed_seconds"] = round(time.monotonic() - started, 6)
                return None
            if table is None:
                break
            phase_table = table
            failures = _d11_source_failures(parsed_source, table, 16)
            if not failures:
                if _d11_target_failure(parsed_target, table) is not None:
                    metrics["dynamic_elapsed_seconds"] = round(time.monotonic() - started, 6)
                    return table
                break
            new_failures = [
                failure for failure in failures if failure not in source_assignments
            ]
            if not new_failures:
                break
            source_assignments.extend(new_failures)
            metrics["dynamic_source_instances"] += len(new_failures)
    metrics["dynamic_elapsed_seconds"] = round(time.monotonic() - started, 6)
    return None


def _table_bytes():
    global _TABLE_BYTES
    if _TABLE_BYTES is None:
        raw = lzma.decompress(base64.b85decode(_TABLES_XZ_B85))
        if len(raw) != _TABLE_RAW_BYTES:
            raise ValueError("finite-model payload length drift")
        _TABLE_BYTES = raw
    return _TABLE_BYTES


def _tables():
    raw = _table_bytes()
    position = 0
    for model_index in range(_MODEL_COUNT):
        if position >= len(raw):
            raise ValueError("finite-model payload ended early")
        order = raw[position]
        end = position + 1 + order * order
        if order == 0 or end > len(raw):
            raise ValueError("invalid finite-model payload")
        flat = raw[position + 1 : end]
        if any(value >= order for value in flat):
            raise ValueError("finite-model entry outside carrier")
        yield model_index, [
            list(flat[row * order : (row + 1) * order])
            for row in range(order)
        ]
        position = end
    if position != len(raw):
        raise ValueError("finite-model payload has trailing bytes")


def _table_sha256(table):
    canonical = json.dumps(
        table, ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _countermodel(parsed_source, parsed_target, table, metrics):
    source_holds, checked, _failure = _equation_holds(parsed_source, table)
    metrics["assignments_checked"] += checked
    if not source_holds:
        return None
    target_holds, checked, failure = _equation_holds(parsed_target, table)
    metrics["assignments_checked"] += checked
    if target_holds:
        if len(table) in (4, 5):
            metrics.setdefault("_dynamic_seed_tables", []).append(table)
        return None
    return {
        "order": len(table),
        "carrier": list(range(len(table))),
        "table": table,
        "source_verified": True,
        "target_counterexample": failure,
        "validation_mode": "exhaustive_finite_table_full_scan",
    }


def _affine_parameters(table):
    order = len(table)
    constant = table[0][0]
    left = (table[1][0] - constant) % order if order > 1 else 0
    right = (table[0][1] - constant) % order if order > 1 else 0
    if all(
        table[row][column]
        == (left * row + right * column + constant) % order
        for row in range(order)
        for column in range(order)
    ):
        return left, right, constant
    return None


def _small_table_false_code(table):
    order = len(table)
    encoded = "[" + ",".join(
        "[" + ",".join(str(value) for value in row) + "]" for row in table
    ) + "]"
    return (
        "import JudgeProblem\n"
        "import JudgeDecide.DecideBang\n"
        "import JudgeFinOp.MemoFinOp\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n"
        "open MemoFinOp\n\n"
        "def submission : Goal := by\n"
        f"  let m : Magma (Fin {order}) := {{\n"
        f'    op := finOpTable "{encoded}"\n'
        "  }\n"
        f"  refine ⟨Fin {order}, m, ?_⟩\n"
        "  decideFin!\n"
    )


def _lean_term(term, variables, operation="d6Affine"):
    if type(term) is int:
        return variables[term]
    left = _lean_term(term[0], variables, operation)
    right = _lean_term(term[1], variables, operation)
    return f"{operation} ({left}) ({right})"


def _affine_false_code(table, parameters, parsed_source, parsed_target, failure):
    order = len(table)
    left, right, constant = parameters
    source_variables, source_lhs, source_rhs = parsed_source
    target_variables, target_lhs, target_rhs = parsed_target
    source_left = _lean_term(source_lhs, source_variables)
    source_right = _lean_term(source_rhs, source_variables)
    witness = failure["assignment"]
    target_arguments = " ".join(
        f"({witness[variable]} : Fin {order})" for variable in target_variables
    )
    witness_variables = {
        index: f"({witness[variable]} : Fin {order})"
        for index, variable in enumerate(target_variables)
    }
    target_left = _lean_term(target_lhs, witness_variables)
    target_right = _lean_term(target_rhs, witness_variables)
    failure_left = failure["lhs"]
    failure_right = failure["rhs"]
    return (
        "import JudgeProblem\n"
        "import Mathlib.Tactic\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n\n"
        f"abbrev d6Carrier := Fin {order}\n\n"
        f"def d6Affine (i j : Fin {order}) : Fin {order} :=\n"
        f"  ({left} : Fin {order}) * i + ({right} : Fin {order}) * j + "
        f"({constant} : Fin {order})\n\n"
        f"@[reducible] def d6Magma : Magma (Fin {order}) := "
        "{ op := d6Affine }\n\n"
        f"local instance : Magma (Fin {order}) := d6Magma\n\n"
        f"def d6Source : EquationLHS (Fin {order}) := by\n"
        f"  intro {' '.join(source_variables)}\n"
        f"  change {source_left} = {source_right}\n"
        "  apply Fin.ext\n"
        "  simp [d6Affine] <;> omega\n\n"
        f"def d6Target : ¬ EquationRHS (Fin {order}) := by\n"
        "  intro h\n"
        f"  have bad := h {target_arguments}\n"
        f"  change {target_left} = {target_right} at bad\n"
        f"  change ({failure_left} : Fin {order}) = "
        f"({failure_right} : Fin {order}) at bad\n"
        f"  exact (show ({failure_left} : Fin {order}) ≠ "
        f"({failure_right} : Fin {order}) by decide) bad\n\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        "  exact ⟨MemoFinOp.d6Carrier, MemoFinOp.d6Magma, "
        "MemoFinOp.d6Source, MemoFinOp.d6Target⟩\n"
    )


def _prime_power(order):
    for prime in (2, 3, 5, 7, 11, 13):
        value = order
        exponent = 0
        while value > 1 and value % prime == 0:
            value //= prime
            exponent += 1
        if value == 1 and exponent >= 2:
            return prime, exponent
    return None


def _vector_digits(value, prime, dimension):
    digits = []
    for _ in range(dimension):
        digits.append(value % prime)
        value //= prime
    return digits


def _vector_value(digits, prime):
    value = 0
    place = 1
    for digit in digits:
        value += digit * place
        place *= prime
    return value


def _vector_add(left, right, prime, dimension):
    return _vector_value(
        [
            (x + y) % prime
            for x, y in zip(
                _vector_digits(left, prime, dimension),
                _vector_digits(right, prime, dimension),
            )
        ],
        prime,
    )


def _vector_sub(left, right, prime, dimension):
    return _vector_value(
        [
            (x - y) % prime
            for x, y in zip(
                _vector_digits(left, prime, dimension),
                _vector_digits(right, prime, dimension),
            )
        ],
        prime,
    )


def _vector_affine_parameters(table):
    decomposition = _prime_power(len(table))
    if decomposition is None:
        return None
    prime, dimension = decomposition
    order = len(table)
    constant = table[0][0]
    left_map = [
        _vector_sub(table[value][0], constant, prime, dimension)
        for value in range(order)
    ]
    right_map = [
        _vector_sub(table[0][value], constant, prime, dimension)
        for value in range(order)
    ]
    if not all(
        table[i][j]
        == _vector_add(
            _vector_add(left_map[i], right_map[j], prime, dimension),
            constant,
            prime,
            dimension,
        )
        for i in range(order)
        for j in range(order)
    ):
        return None
    if not all(
        left_map[_vector_add(i, j, prime, dimension)]
        == _vector_add(left_map[i], left_map[j], prime, dimension)
        and right_map[_vector_add(i, j, prime, dimension)]
        == _vector_add(right_map[i], right_map[j], prime, dimension)
        for i in range(order)
        for j in range(order)
    ):
        return None
    left_columns = [
        _vector_digits(left_map[prime**index], prime, dimension)
        for index in range(dimension)
    ]
    right_columns = [
        _vector_digits(right_map[prime**index], prime, dimension)
        for index in range(dimension)
    ]
    return {
        "prime": prime,
        "dimension": dimension,
        "left_columns": left_columns,
        "right_columns": right_columns,
        "constant": _vector_digits(constant, prime, dimension),
    }


def _product_type(prime, dimension):
    result = f"Fin {prime}"
    for _ in range(dimension - 1):
        result = f"Fin {prime} × ({result})"
    return result


def _coordinate(variable, index, dimension):
    if index == dimension - 1:
        return variable + ".2" * index
    return variable + ".2" * index + ".1"


def _tuple_expression(expressions):
    result = expressions[-1]
    for expression in reversed(expressions[:-1]):
        result = f"⟨{expression}, {result}⟩"
    return result


def _linear_coordinate(variable, row, columns, prime, dimension):
    terms = []
    for column in range(dimension):
        coefficient = columns[column][row]
        if coefficient == 0:
            continue
        coordinate = _coordinate(variable, column, dimension)
        if coefficient == 1:
            terms.append(coordinate)
        else:
            terms.append(f"({coefficient} : ℕ) • {coordinate}")
    return " + ".join(terms) if terms else f"(0 : Fin {prime})"


def _vector_literal(value, prime, dimension):
    return _tuple_expression(
        [f"({digit} : Fin {prime})" for digit in _vector_digits(value, prime, dimension)]
    )


def _integer_linear_term(term, variable_count, parameters):
    dimension = parameters["dimension"]
    if type(term) is int:
        return [
            {(term, coordinate): 1} for coordinate in range(dimension)
        ]
    left = _integer_linear_term(term[0], variable_count, parameters)
    right = _integer_linear_term(term[1], variable_count, parameters)
    result = []
    for row in range(dimension):
        combined = {}
        for columns, values in (
            (parameters["left_columns"], left),
            (parameters["right_columns"], right),
        ):
            for column in range(dimension):
                multiplier = columns[column][row]
                for key, coefficient in values[column].items():
                    combined[key] = combined.get(key, 0) + multiplier * coefficient
        result.append({key: value for key, value in combined.items() if value})
    return result


def _source_zsmul_coefficients(parsed_source, parameters):
    source_variables, source_lhs, source_rhs = parsed_source
    coefficients = set()
    for term in (source_lhs, source_rhs):
        for coordinate in _integer_linear_term(
            term, len(source_variables), parameters
        ):
            coefficients.update(value for value in coordinate.values() if value > 1)
    return sorted(coefficients)


def _vector_affine_false_code(
    table, parameters, parsed_source, parsed_target, failure
):
    prime = parameters["prime"]
    dimension = parameters["dimension"]
    carrier = _product_type(prime, dimension)
    coordinates = []
    for row in range(dimension):
        left = _linear_coordinate(
            "i", row, parameters["left_columns"], prime, dimension
        )
        right = _linear_coordinate(
            "j", row, parameters["right_columns"], prime, dimension
        )
        constant = parameters["constant"][row]
        coordinates.append(f"({left}) + ({right}) + ({constant} : Fin {prime})")
    affine_body = _tuple_expression(coordinates)
    source_variables, source_lhs, source_rhs = parsed_source
    target_variables, target_lhs, target_rhs = parsed_target
    source_left = _lean_term(source_lhs, source_variables)
    source_right = _lean_term(source_rhs, source_variables)
    witness = failure["assignment"]
    target_arguments = " ".join(
        _vector_literal(witness[variable], prime, dimension)
        for variable in target_variables
    )
    witness_variables = {
        index: _vector_literal(witness[variable], prime, dimension)
        for index, variable in enumerate(target_variables)
    }
    target_left = _lean_term(target_lhs, witness_variables)
    target_right = _lean_term(target_rhs, witness_variables)
    left_digits = _vector_digits(failure["lhs"], prime, dimension)
    right_digits = _vector_digits(failure["rhs"], prime, dimension)
    different_index = next(
        index
        for index, (left, right) in enumerate(zip(left_digits, right_digits))
        if left != right
    )
    projection = _coordinate("q", different_index, dimension)
    failure_left = left_digits[different_index]
    failure_right = right_digits[different_index]
    zsmul_coefficients = _source_zsmul_coefficients(parsed_source, parameters)
    if any(coefficient % prime not in (0, 1) for coefficient in zsmul_coefficients):
        raise ValueError("vector source coefficients do not reduce to identity")
    zsmul_lemmas = "".join(
        f"theorem d6Zsmul{coefficient} (x : Fin {prime}) : "
        f"({coefficient} : ℤ) • x = "
        f"{'0' if coefficient % prime == 0 else 'x'} := by\n"
        "  fin_cases x <;> decide\n\n"
        for coefficient in zsmul_coefficients
    )
    zsmul_names = ", ".join(
        f"d6Zsmul{coefficient}" for coefficient in zsmul_coefficients
    )
    if zsmul_names:
        source_proof = (
            "  ext <;> simp [d6Affine] <;> abel_nf <;>\n"
            f"    simp only [{zsmul_names}, zero_add, add_zero]\n\n"
        )
    else:
        source_proof = "  ext <;> simp [d6Affine] <;> abel_nf\n\n"
    return (
        "import JudgeProblem\n"
        "import Mathlib.Tactic\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n\n"
        f"abbrev d6Carrier := {carrier}\n\n"
        "def d6Affine (i j : d6Carrier) : d6Carrier :=\n"
        f"  {affine_body}\n\n"
        f"{zsmul_lemmas}"
        "@[reducible] def d6Magma : Magma d6Carrier := { op := d6Affine }\n\n"
        "local instance : Magma d6Carrier := d6Magma\n\n"
        "def d6Source : EquationLHS d6Carrier := by\n"
        f"  intro {' '.join(source_variables)}\n"
        f"  change {source_left} = {source_right}\n"
        f"{source_proof}"
        "def d6Target : ¬ EquationRHS d6Carrier := by\n"
        "  intro h\n"
        f"  have bad := h {target_arguments}\n"
        f"  change {target_left} = {target_right} at bad\n"
        f"  have badCoordinate := congrArg (fun q : d6Carrier => {projection}) bad\n"
        f"  change ({failure_left} : Fin {prime}) = "
        f"({failure_right} : Fin {prime}) at badCoordinate\n"
        f"  exact (show ({failure_left} : Fin {prime}) ≠ "
        f"({failure_right} : Fin {prime}) by decide) badCoordinate\n\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        "  exact ⟨MemoFinOp.d6Carrier, MemoFinOp.d6Magma, "
        "MemoFinOp.d6Source, MemoFinOp.d6Target⟩\n"
    )


def _compact_table_false_code(table):
    order = len(table)
    alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if order > len(alphabet):
        raise ValueError("compact Base36 table only supports orders up to 36")
    encoded = "".join(alphabet[value] for row in table for value in row)
    if len(encoded) != order * order:
        raise ValueError("compact finite-table encoding length drift")
    return (
        "import JudgeProblem\n"
        "import JudgeDecide.DecideBang\n"
        "import JudgeFinOp.MemoFinOp\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n\n"
        "private def decodeBase36V2 (c : Char) : Nat :=\n"
        "  if c.isDigit then c.toNat - '0'.toNat\n"
        "  else c.toNat - 'A'.toNat + 10\n\n"
        "def base36TableV2 (s : String) (i j : Fin n) : Fin n :=\n"
        "  let vals := s.toList.map decodeBase36V2\n"
        "  let idx := i.val * n + j.val\n"
        "  ⟨(vals.getD idx 0) % n,\n"
        "    Nat.mod_lt _ (Nat.lt_of_le_of_lt (Nat.zero_le i.val) i.isLt)⟩\n\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        f"  let m : Magma (Fin {order}) := {{\n"
        f'    op := MemoFinOp.base36TableV2 "{encoded}"\n'
        "  }\n"
        f"  refine ⟨Fin {order}, m, ?_⟩\n"
        "  decideFin!\n"
    )


def _false_code(table, parsed_source, parsed_target, failure):
    order = len(table)
    if order <= 10:
        return _small_table_false_code(table), "finOpTable_single_digit_decideFin"
    parameters = _affine_parameters(table)
    if parameters is not None:
        return (
            _affine_false_code(
                table, parameters, parsed_source, parsed_target, failure
            ),
            "fin_scalar_affine_symbolic",
        )
    vector_parameters = _vector_affine_parameters(table)
    if (
        vector_parameters is not None
        and not any(vector_parameters["constant"])
        and all(
            coefficient % vector_parameters["prime"] in (0, 1)
            for coefficient in _source_zsmul_coefficients(
                parsed_source, vector_parameters
            )
        )
    ):
        return (
            _vector_affine_false_code(
                table,
                vector_parameters,
                parsed_source,
                parsed_target,
                failure,
            ),
            "fin_vector_affine_symbolic",
        )
    return _compact_table_false_code(table), "base36_compact_table_decideFin"


def _base_result(ordinal, case_id, status, stop_reason, save_mode, metrics):
    return {
        "schema_version": PROVER_SCHEMA,
        "prover_name": PROVER_NAME,
        "ordinal": ordinal,
        "id": case_id,
        "status": status,
        "stop_reason": stop_reason,
        "result_save_mode": save_mode,
        "certificate_valid": None,
        "verdict": None,
        "judge_verdict": None,
        "metrics": {key: value for key, value in metrics.items() if not key.startswith("_")},
    }


def prove(case, config):
    """Try generalized infinite source rules, then the d6 finite-model bank."""

    started = time.monotonic()
    ordinal = case.get("ordinal") if isinstance(case, dict) else None
    case_id = case.get("id") if isinstance(case, dict) else None
    save_mode = "minimal"
    previous_alarm = None
    trace = []
    metrics = {
        "architecture": "false-solver-d11-learned102-plus-dynamic-fin45-v1",
        "infinite_family_checks": 0,
        "model_checks": 0,
        "assignments_checked": 0,
        "oversize_certificates_skipped": 0,
        "maximum_candidate_certificate_bytes": 0,
        "stage_events": 0,
        "dynamic_enabled": False,
        "dynamic_search_seconds": 0.0,
        "elapsed_seconds": 0.0,
    }
    try:
        save_mode, safety_seconds, enabled, infinite_enabled, dynamic_enabled, dynamic_seconds = _runtime_config(config)
        ordinal, case_id, source, target = _case_formulas(case)
        parsed_source = _parse_equation(source)
        parsed_target = _parse_equation(target)
        previous_alarm = _arm_safety_wall(safety_seconds)
        if infinite_enabled:
            metrics["infinite_family_checks"] = _INFINITE_RULE_COUNT
            candidate = _infinite_candidate(parsed_source, parsed_target)
            if candidate is not None:
                family, code, source_recognition = candidate
                stage = "stage0_generalized_infinite_source_family"
                judge_lean, certificate_bytes = _staged_certificate(stage, code)
                metrics["maximum_candidate_certificate_bytes"] = max(
                    metrics["maximum_candidate_certificate_bytes"], certificate_bytes
                )
                if judge_lean is None:
                    metrics["oversize_certificates_skipped"] += 1
                    if save_mode == "full":
                        trace.append(
                            {
                                "seq": len(trace) + 1,
                                "stage": stage,
                                "event": "certificate_too_large",
                                "certificate_bytes": certificate_bytes,
                                "limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                            }
                        )
                else:
                    metrics["stage_events"] = 1
                    metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                    result = _base_result(
                        ordinal,
                        case_id,
                        "REFUTED",
                        "INFINITE_COUNTERMODEL_CANDIDATE",
                        save_mode,
                        metrics,
                    )
                    result.update(
                        {
                            "certificate_valid": None,
                            "certificate_kind": "generalized_infinite_source_model",
                            "certificate_bytes": certificate_bytes,
                            "certificate_limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                            "verdict": False,
                            "judge_verdict": "false",
                            "stage": stage,
                            "countermodel": {
                                "carrier_class": "infinite",
                                "construction_family": family,
                                "recognition": source_recognition,
                                "target_index_used": False,
                                "target_validation": "target_ast_symbolic_reduction_then_constructor_nomatch_then_current_judge",
                            },
                            "judge_lean": judge_lean,
                        }
                    )
                    if save_mode == "full":
                        result["trace"] = trace + [
                            {
                                "seq": len(trace) + 1,
                                "stage": stage,
                                "event": "candidate",
                                "construction_family": family,
                                "certificate_bytes": certificate_bytes,
                            }
                        ]
                    return result
        if enabled:
            for model_index, table in _tables():
                metrics["model_checks"] += 1
                details = _countermodel(
                    parsed_source, parsed_target, table, metrics
                )
                if details is None:
                    continue
                model_sha256 = _table_sha256(table)
                metrics.pop("_dynamic_seed_tables", None)
                metrics["stage_events"] = 1
                metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                details.update(
                    {
                        "frozen_model_sha256": model_sha256,
                        "frozen_model_index": model_index,
                        "frozen_library": "unified_static_finite_bank",
                    }
                )
                stage = "stage0_unified_finite_model_full_scan"
                trace.append(
                    {
                        "seq": 1,
                        "stage": stage,
                        "event": "hit",
                        "models_scanned": metrics["model_checks"],
                        "model_index": model_index,
                        "model_sha256": model_sha256,
                    }
                )
                judge_lean, certificate_encoding = _false_code(
                    table,
                    parsed_source,
                    parsed_target,
                    details["target_counterexample"],
                )
                staged_judge_lean, certificate_bytes = _staged_certificate(
                    stage, judge_lean
                )
                metrics["maximum_candidate_certificate_bytes"] = max(
                    metrics["maximum_candidate_certificate_bytes"], certificate_bytes
                )
                if staged_judge_lean is None:
                    metrics["oversize_certificates_skipped"] += 1
                    if save_mode == "full":
                        trace.append(
                            {
                                "seq": len(trace) + 1,
                                "stage": stage,
                                "event": "certificate_too_large",
                                "model_index": model_index,
                                "certificate_bytes": certificate_bytes,
                                "limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                            }
                        )
                    continue
                details["certificate_encoding"] = certificate_encoding
                result = _base_result(
                    ordinal,
                    case_id,
                    "REFUTED",
                    "COUNTERMODEL_FOUND",
                    save_mode,
                    metrics,
                )
                result.update(
                    {
                        "certificate_valid": True,
                        "certificate_kind": "finite_magma_countermodel",
                        "certificate_bytes": certificate_bytes,
                        "certificate_limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                        "verdict": False,
                        "judge_verdict": "false",
                        "stage": stage,
                        "countermodel": details,
                        "judge_lean": staged_judge_lean,
                    }
                )
                if save_mode == "full":
                    result["trace"] = trace
                return result
        dynamic_seed_tables = metrics.pop("_dynamic_seed_tables", [])
        if dynamic_enabled and dynamic_seconds > 0.0:
            metrics["dynamic_enabled"] = True
            metrics["dynamic_search_seconds"] = dynamic_seconds
            dynamic_table = _d11_dynamic_countermodel(
                parsed_source,
                parsed_target,
                dynamic_seconds,
                metrics,
                dynamic_seed_tables,
            )
            if dynamic_table is not None:
                details = _countermodel(
                    parsed_source, parsed_target, dynamic_table, metrics
                )
                if details is None:
                    raise RuntimeError("dynamic table failed exhaustive revalidation")
                stage = "stage1_dynamic_fin45_model_synthesis"
                details.update(
                    {
                        "construction_family": "source_seed_neighborhood_or_cegis",
                        "dynamic_model_search": True,
                        "formula_only": True,
                    }
                )
                judge_lean, certificate_encoding = _false_code(
                    dynamic_table,
                    parsed_source,
                    parsed_target,
                    details["target_counterexample"],
                )
                staged_judge_lean, certificate_bytes = _staged_certificate(
                    stage, judge_lean
                )
                metrics["maximum_candidate_certificate_bytes"] = max(
                    metrics["maximum_candidate_certificate_bytes"], certificate_bytes
                )
                if staged_judge_lean is not None:
                    metrics["stage_events"] = 1
                    metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                    details["certificate_encoding"] = certificate_encoding
                    result = _base_result(
                        ordinal,
                        case_id,
                        "REFUTED",
                        "DYNAMIC_COUNTERMODEL_FOUND",
                        save_mode,
                        metrics,
                    )
                    result.update(
                        {
                            "certificate_valid": True,
                            "certificate_kind": "finite_magma_countermodel",
                            "certificate_bytes": certificate_bytes,
                            "certificate_limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                            "verdict": False,
                            "judge_verdict": "false",
                            "stage": stage,
                            "countermodel": details,
                            "judge_lean": staged_judge_lean,
                        }
                    )
                    if save_mode == "full":
                        result["trace"] = trace + [
                            {
                                "seq": len(trace) + 1,
                                "stage": stage,
                                "event": "hit",
                                "order": len(dynamic_table),
                            }
                        ]
                    return result
                metrics["oversize_certificates_skipped"] += 1
        metrics["stage_events"] = 1
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        if save_mode == "full":
            trace.append(
                {
                    "seq": 1,
                    "stage": "stage0_unified_finite_model_full_scan",
                    "event": "miss",
                    "models_scanned": metrics["model_checks"],
                }
            )
        result = _base_result(
            ordinal, case_id, "UNKNOWN", "COUNTERMODEL_NOT_FOUND", save_mode, metrics
        )
        if save_mode == "full":
            result["trace"] = trace
        return result
    except _SafetyWallExpired:
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        result = _base_result(
            ordinal, case_id, "UNKNOWN", "SAFETY_WALL", save_mode, metrics
        )
        if save_mode == "full":
            result["trace"] = trace
        return result
    except Exception as error:
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        result = _base_result(
            ordinal, case_id, "ERROR", "PROVER_ERROR", save_mode, metrics
        )
        result.update(
            {"error_type": type(error).__name__, "diagnostic": str(error)}
        )
        return result
    finally:
        _disarm_safety_wall(previous_alarm)


def _main():
    request = json.loads(sys.stdin.readline())
    result = prove(request.get("case"), request.get("config", {}))
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


__all__ = ["PROVER_NAME", "PROVER_SCHEMA", "prove"]


if __name__ == "__main__":
    _main()
