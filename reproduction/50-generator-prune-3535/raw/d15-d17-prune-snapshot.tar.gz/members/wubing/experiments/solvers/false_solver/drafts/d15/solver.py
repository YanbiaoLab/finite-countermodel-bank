#!/usr/bin/env python3
"""Formula-only finite and target-symbolic infinite-model False solver runtime."""

from __future__ import annotations

import base64
import hashlib
from itertools import product
import json
import lzma
import math
import re
import signal
import sys
import time
import traceback


_MODEL_COUNT = 10059
_TABLE_RAW_BYTES = 371494
_TABLES_XZ_B85 = (
    '{Wp48S^xk9=GL@E0stWa8~^|S5YJf5<H!E*{#^h805k9SleYcurgo_*5}L;zu*Z9(wHM3pLM1+@#7MtRp*Eg7$gYn5W~L};GN~f;'
    '3pK6{{C?Gf%@pFY^+fGmdWXN`hZv`(3O1DzD9w>}^LBHfa7zYye}W>Cv2&|%Ja<+~bSk!Mj^+wdHLuYCt^o=yr_K}|QOj|GKW{0i'
    'M8IDJ?=j&HQ1Z3Nd%-xst&MKIzLxcT4kC|PUr8uYWTOR)SwG*Cj0j&(c%pjN=@BhlKj;xVu=n2x_va{|lIt@2rBiRweE4)VBZ^C-'
    '0y|PD7ZiKq7a{>X7aaY7P32!Wq6=-jRn)IpIQgKOPo}k=v9{Jp+=>68A27)-ZgWbD@P~|dVl0OjRu*y!%hX{C(5iBdd-(T|Z7qIO'
    '?5pC22_e6vH<P~$yh0dVy93aldeof2#kKlWj%40h+?_7Gu!)Gr)MXzA#j{p0L<)iPRHG@&_zzAmGj*g&6q?5lUfz##t3&z)DuwPa'
    '4@rSNU$zRfMrWELOcV^<4EJDMaZJ9EW9zv6>1FM-I=6Z=HH~Sr&>ImLEmTXfX7v}ga=oM#RLilpvybecM2T8RMP{E853hsq#D4sk'
    'IbQ>s>Q@C=qe<Vzswl)XIPWKMSBpJI6$o{thg~P;*h1+ug-^07#~jSnK*yL0g`F|8dfZ$^Ws<T9!WAjFL@HSnG!!pH@-moldiNJ1'
    'Z$r%ggA3b&liQ=^g+B=KC=^!iCQO|Wbd8R9U8!zaAdDKhPrb(bZg{k|=EdpwXN1FO#)grn90*TA5OL}akvU7oT2>v~p{;yvJej#N'
    'zLp*5n#q^2`3BQyxzs{EW$hNL&TiJazaL8?YJT7->O!rZA0!@~UJ**xxP_NeeJ4Pyi006avU%zz2XDP2G6@lhCdOHEFnG&Q(zf!j'
    'l`v6a(R*znvIPN9LZ01xeX)da_>0d#V^1+C;ec6qVj8Xp-R{OVYR~AW$3<JN5T`A2f}tNKj}P3VU}!qxh37+vtgguh{Pw;g#-U}C'
    'GA0b^tl0OD9G|a4lG-wBSmkgf9nV+ZA3m}|EF+^Csg~Y3>AICLS@1{S4mYRl$Q)r??~=qX#!fO{mXv|_U;;1vvf7}Mg^mBqA<Y)L'
    '%d#x>0+Es+t^lrW4uoazWY9Wb6xbVXseHxdmGN`4Lt{?qg)DbO`R%fN5n+-S&rZ@Z)LRAqt-<%b$cOESiP#tOYIw!g>Dy1eUFmsp'
    'RDh^c`;Xh;N*LNGAsL1JVy#Ow4M++DcvxveQlcGG$>`(Z-FkP;ih;RpG;qFHTsWp7vxM=L!#{hSo>gejA!%gPloiES#rf1r`fhOZ'
    '6^9)X2{Ync#E(@*5w>FNjWjB{d4`d9iJh}yA_vk~d{t$L9X*J#;j0Hm9SDsocu$Lp=h+|K(6z2qq(*%vnD8<GHqW|@uPW*V4ti3A'
    'd`vJ{3LU`3;r{h)jz_VzMX-Cyv4t+2acS;X%waiCS*6|$r@Wq6=ji0hy}3M`q4taAn&ft}JGx!h7IrBLvMrs#UH>c=dh(a-9(&$6'
    'uO@Qq!_lcN`5P*BPoV+i#pCZCu%5bN5kj9xx;e1l0CJ1Cth(pEZ?n)fOkvhr<LIPK(XJ4SiEU{i#l<;6-IB@+p_Clk{l>$p*L#GV'
    '=CaKNx#Qt+bcs4SkM+B+$){LsQLju@75%H(LhlrCI$&%OFFYZ+T88y}&m~fEr_D~yigRt*v;`esoJuSJa7p+jMj$+wuLismR@5LV'
    '9uzMtn>Y`GVv7);esi0=)dxXWoLmgbZ{GrNvm5ab+g_pdNRkcWR8$4_#y;dpb_R+UPu6mTVL}X%OMi(TABtpWrx4U)`*7WV4}qJA'
    '4qy{R3<X{uT)VE(;sx)5{io0LR19&(m7;h5_X45|%$bQ(9Z&z~Y})vOAbvss;vC)Wi{8v@#GFb^=a>H3_(^9lc{}R3MQWK{LnsUU'
    'Fq-Fgm{;3T$2x^26?;r)F23fnn|3y)3{Gog_-GOgPz`V0xEliMYpmc*>O`Tf`uim{!gq3sUB}`RLbIsEVmk5qJ!UgsWRe~bb@!sa'
    '{`E;qtE7&$l_7QSQN{pLOUiXi@TMMz-xZLa(LL|m(@GqDKZXBfRhhak;00BtxkLVU*ZT-PO72kYyX!xYk(A^ABrKNbQPtO4OPu_k'
    'x?to_ZRvTCbNMvG4D34AOe6Qh;o$ur^aTAWPtn?hF3y`((6^95I#;}Hl^@%}4R}O@X2LnQy+ec8OcLY9$%h|9JCUy0b7_f!QUNOx'
    '$d2q{$@3oO7ck$KCXadBMREb-5QnbW{3mTTLHu}!$`t&9hGm$;qfNsftURJgWnVWG)7nSucohZ^Sdw`svX<dvY7SM}mf(<c&P{8T'
    '@2`9d>LlR!6>$3TP(FxK{p?D)YU+h|cejjsH$kd<!RnJ!FlqVZ{A(h+)9?4iKy&;#9KiThpX=l-`8Q+>d$liXyIV7()W>ki4U%c~'
    '_&?D`hJ6*P=AYQH28EJ-2HibbwOaBqLgGE#CPI1TT=_VjV#oIr+q46WSeR+Ss!z|a>+KUh*cAr3z<vHBpMIRnDIeMEIxHc`YPh;k'
    'Uyf;*?zj-gj|GxbvL~t`l3G)fKC(xHbP?UGk@KX?J3Mxyg-zw^8-2`#1jYKQH6X07x;MaSYxsS2_B>kKHb<)2zLATtR7%|LLs_GB'
    'Yc~~a&_c-RF+c`EfI?vD#J1m~DG&$$K1C$cg$B`xG!vG}k<A~HD!%{p2*#9C<F54%Ex;P1Wnx`CBNF{9w4Ld)9b=Gin_0jZWKQ|H'
    'JxLb(`y61DF_G?+W}iaH%zj=z1zpBYzz4oJsT#wwPaCkK;NW*P0k1|fHhyXChBy$tr<dj0IxJ&JNk!OHE^Xyy<f{)gD(_&>6=_G9'
    '#l)dsD=-3JEfjgz=$KhBBFCF&Ep^TZ*Eclu2}`w?7Y6|D(edgsAm#8r)G@o&+5)UeW2UO)zxztX9CmEt-pE|*4~2nBqs<+Lsb#`{'
    '6^aN~TiV`v2@NDFCWZHBXLbm1r~q2pb0wUb>kXlHrRZs~3{`Yl_Wwy}v{c%gk6YAotyn34-WGM>;*;7BSLfLoILz(6hBoIqrBXhT'
    'L8K4c6HqaK#L9~4B0&&T<vp(f6F`gqaDt3WU1&d-?4D(X<4#ho@my>h+&Gk;ruCgq6q<PzHuyDw`IVR#V=Q^K3*uT0U)g7<3xNSi'
    'xVK7moovMz@je+-^MUkNJLlhuR0!iE9?lo`rXtCnI-Jc>uJiCuScmWl3|-`>8qzJA77Gsq$;u@dEZ88YH^X>nlpS<%Bk?n{0921q'
    'hlFPj6l@lNF-66k_9YYPt&q_P$2%*Z7574>7Jm8^AdH66NlN|WF7)?`NSHi;Vy3ECjZ<c6qfAM4ZEm7D5M>wZ6+tEzG_nU@l9~^T'
    'u#4(*ofnjcNpiA2d`KK+d+%y{O&r=R$^8#hd6j)}h7E*J?vK-~<9FSHTi$xaELXUXpLZK&bx8PJXW3!$ZS_Ud>hYC|AQY!>2ba0)'
    'wB8^HPJGxVy!s`6)#L@aQd=<;gPh2iD*Lg-k5rSV?8jl4`{i!bRJ%~;=c*yvWS)Q#)I#N6qINAw+upq7IM5In*!j(VxF?IQbG9B8'
    ';~1^}(G_8=P7(>obk!&0b)SW@5tW*SH2DB$w!><_JCb6@4KMr!KZ`9(d&>Cnhm@7>?M=U#b?FuI2nXa6eQl2$^3KN^qyk{w6Tj(O'
    'S|O61=fw6gk36biIDgw(u%WlOJn8f|cOiKpsvfad%G$ME>;~76X%zvQN`wJdO4tq~_N*_iZ8#HyH943)>?IgRA8M8mBZ8pLvyDaf'
    '0tlQ8+olG}R8Ywn{b=5byc~_Eg<*@i9jp_6s8uYk)U0!?kI`h2UR``tBLy!VnX1Zobtt0#QM!?lS*}yp-ISr|e+_~=BQ3&f6GnEw'
    'Yy>Q0u*LQqDIqZ=XW4Mb*Xik)AVjt?u@V`~%+m^X$~LjGt!wDH%FS0$hHT7fL;+~kpo-hjOE@8%U7SiGAtC{bKLu_w^VfdIfyzDa'
    'DQj%jz4s1t#wGKTHP|(gGLRi*kz<HHc5VAYG4*5ia&2=@8QTf4^rb3`cZ!#%iqaerd_`d%G<%lcLH93Y%NgPmPOQ?61)map;-;ZJ'
    '$(8qmQ1YhtZKC(=fx5!ys47wIUjiY6qLs}6arXs_^9=@8mU%3{EjX72*%%$H3Nfr?3(CGXo>9mZ%61DGu~?E+ruzT=E&G=)a40Pn'
    'GF%BWx6Mh{(d@OLSyImT%YPG1i(vnW0!%`syE?yNHePz2yYFe!xgPj~4tR+)ezjbYw@zp<>1-$^2=$9HbLOPg!vj9QP_%Iv0z%DR'
    'NFOpzW;oy?>SFDEr-OeIRD|`1+oU@{QM-^D@o3o59!|nH{-qI5wnvV!k#hRN)^kOzNCQ!qL4_umxgkTwpep-YcvxIXEX{A=nW0zZ'
    '(*CaV5WVdW-3A7QJPsfFd<mJz{X0z+`gVS(6t(kY<~6Jd?SST^Rv`q>>0pQ<!)Iw!6^wADHN;lGl#9#EKoBICo;?L#3Wrnc)w-}H'
    '=KC$4KGk_7H|Y?_6l;_jgR^_Ykg?buyf>?4nk|>hscG>G-trQp(Y>Uxz{;6xSL>x5e;4)<K191)U0|YQufIFS@~$0&l=X>;MGftV'
    'X8H@&&O7FF0*4iS6sGal)RzzC|7!P<z;?n0l~YU;o~H#m0fUWM1<2?bBofdH2e;t2ulo!EKTo#oy}xVEavKOItiYsse!G~7I4~wN'
    'mY2M&Qb*9*Q@$$<=w}>qAZIS;8H2bjSm8M=icXu+K&~;5!%kXcOVt`NylX2%uBK#UYVah;%vtK(yrdfmJaS-QV>LzaeFpbbr_CIf'
    'e0vvyVo#+lB?_ny>uL~7io(F~w|s@0hPFaBM*Sl3oPQ$g%Hi=XD#c>*K9{+xH{pQz@uvh$dz5QS*0Z3d^Jp%?oiOHDrF0{Lpw{pi'
    'a1kOKp#R1Df!Fy9{UsAG#w^MJ=E_W#J%{0FST!;1YYS!#4W?D&n#=e&R-UhegGA1~xX#9XC;JWtz`R5;0Gw6G%|GO<5-UE-70Xmd'
    '^tB@a^kyCqFe9|LH)KZ&+L0BRtD`7?ZTZ#S542$vv#!{j(L%E>Hzlq-r^;{mneuSpRp0r!CC}vPKws%$ZP2LgxnuVIJFyg!djpV8'
    'tc<o3dRe?KSne+@z%IU?C`56H<*0SsFiKy40|L!RbePg64s)fBL*8dR8YVHdj^f{}B(t35^>;MFeN2Rkc6f?l4xAUv*LRQPcaIPE'
    'DzDE$pOM-_^hg_;FYDF_DuRW!U=v;EX!GdleXKT$zI+`b@;w@tqJ^P%TWz-g{O6dyX7Z*9lX8}x+$OC<h--HQ{(y6op@6?LcM^ui'
    'RcNtllrjO%fb+w4w|sUN4+ghAd6ui-GXkC1iV(U%SPRa^CXg{`?P}dO_li?C?3jQO-?X(T-C1b)4>a7ZWkte(7gYYfNCQ4y>=ZTo'
    '>?kU8ivLb4J9Vg1^z6lNyMQ_9y-lrmt#S5I@<^zUWRh1S9ng+<s)bc!+MQ4^^xLuDqj>OP?^WiJxm$U6vZWh0A1l!zW=!2_nQU=h'
    'xba~2<du>sSKnp`CjP(49<L*^b3A@_E9itXa^ZQBB3wTLU@@#_3Y!=zfjNJwyT^Hpwy59&Om0ZK2zuW@XgK`Q@i7ZwB>EUc{||UT'
    '_M0Hsh@AUm38Hpkf&EEB40&>EWEWwFb1%Ny0CFyYjl3M2@J@zr!!0yigl=z6a|jY%>L8|aDx}q+7XNltGSDcySaJ<oHgJnH1^4@i'
    'D)P@(z^C<{M~25ig#IVQSe)I|IxKEJ&13@;=Ml{8m^QLHj&3(YllJP=P?=Aex9&B82k+fWZmHIjkh9xo`9Ijq<iO^~E%||Fb~qUS'
    'Y~Y;HM54rxXyS}#%B%btV@6VbIKwy0M!A&<a$qP_sK^|zv6d8n;X|<wEKu(dvc4%zM7llW2`HWFZ4P^c%beiwz>+5nb<N~LHf_Y_'
    'TC&#hC}X<d|AU-5pMEW`DV?oE$P$owzE(tG5KX_sAw#tp_oc<gok~x$gFLR3T_S0z#CKG#8A1hxhd$(c8llm*)ghGZ6zyfjgg)_W'
    'J1(oh!^Yg~)o--`(m)IVgMR+rb`cn9`1c<c(Z{AIPAN4${SRW_HNl)&V_s}2QqK|8uQp!;O4ul|n+Dbp-DJPgj9AZjPx#t;#lJC?'
    'wKi(Ah5KS_g93u!GlJX*ndjF0BY3oFIeV{s2Z6;4cRwnI(o1J|l_svUJTu8dLfe2JDSv}n_tW{Wg3;%FMvkqZu>#mq(#{E1@I{7D'
    'F5GP-y0j>REkoJ9v#>6xkZO1q>*3CVZ#fqH`h;;R)=vg10O)3#$OK;rVuwiyM13EccE)&kZLn-&Z0EW52v{Z`qVK0)*pQosb}u>h'
    '$by0JoE=uUg3sk;i+jjX(iT3=_XoB!69UoaZL4UuN_jOE6_2`gv_u2U9Oxnl^jU`7^!nC<3K^YpH#j77k!Ki+*Z{Lj>XQWtZV7CW'
    'jLMkuEuDe$p(AP2hqTZX=8#IH?y{ihJzDGrpmCX7XF^Hw5Ox=AkAx!Nek`!s;V2xB2yKpDBdeJL__Rkc=o8ll!Wh!w+6KG}96`vZ'
    'O&oBI+2flUE=kxGl}rdBm3_Z0kiwV1gfg_B@PZ?p+Ewy3fZ9LbL#a`%K%`hyeZaGnAm!AR-E!_OP!lxMe`>@zilBsu@4fZE-_x|)'
    'SISJmate!r0uz3@oxl%oSYTQlke>|Nt_@pCvX6o{$}n<vxLBV!5UEKzz;6!5@M}o=>4Gwpnj<9Fkt3M$Pb3ULABRJ@(S<)|ZYXn-'
    '2T=rY{ib~guJ$DsdP;D=45Ai2IXeemNJ_O+UOn>dHF<Si-v*U-#2=6b$gqi;5$lo|m>&BjBibU+J1DSt!`1AkHR$5s8>oPVMBy<6'
    '_?}yaEDA$hde|UM<Dzt-UqcPK#knlZxCC!@>e6b2%;{5w6#gD~pvc#DT&P`6`p54BPKCE@S<<Cq;w1RF`yGxv5KbitD!-WpPW$<S'
    'YC2E}aL-47uuk##VzPTdp!abes%1`ew(?5Bkam+UH_gS@>8a^50ZeY|g_MrjOFlwVv@vp?{dmViXSktQ4id&>Ri5M^L)k$?OJ_kG'
    '{Yw?dilGa;_KHyn*mS}(Je7fBmj?wauCt<Us*?mTIUuds^nO|y&jGuWG#1Mq8<=-uG=l`v#~%%hh}Dm>rtzQ}!o(c*iy`qDAZ-|r'
    'VSb!}5k&_?VST-zH2+*un-tB(`KS#7DMaNOs*nEPstV-lGn8k+XOl705#47HN^**aX~F&=kHtOG!c?7?+?AIYjgxd|OX11be9Z4!'
    '-eC~qpkUK-eIz-@&q!QDR9CkO4g#<{DBq_Oy+c=Fz6gb?P~yfK7jdo)M*&2Vcv*@xmrS~KZ4H+vB4x$Hb^_43rjZ4+#aD}%{eoPJ'
    'j0QjZq%^(&_#^b7w%9Yr%H>+^nBGu?;F5Eua}&T17TI-j_t+Le5J?V>14%)pJU<`e>|RB5jSdqUeOkTFqI+01=Uh_hh@!PVf7i!J'
    'RL2&O$=NUg?tdbM-i_+fXPk?v1!>{s;<F|Gq|zeArvKBX)r?($M8(`rqBPR?JUl9e&^m;^@&C>tLv>K<kIv^H*#0h{s^|5LcF^h!'
    ';W5HdK`(`u#J?S5(sRSukGFEzQXfn40GQrrOTJZr1K0k_m9Q4j!}=jysqBQp3tpb77ghIM8)=i!XS;O0rGlOf6o1?OVPf*Fui>r-'
    '7F|wEEHdd+l}jE^kg}dhK*qZ;Ljm^qoNGU+%{*nxTY^2c%T>QXq9vC*4GLx&K>D{CHDd$?V!hW@{vNYne|U$pB8(DQ)KxiCy}O7*'
    'BepCkR2EBM2}|?>(^ta_MCv8i47euE0UzYP)QrTQyRl9i67KAE*z2%vY5*W6!E_7@jYxo{cw{gfn>vDN@+MGg7pc}4>KqDrFj9iR'
    'jPKMUE^P?b^;+5qmFGd>!3V2UC;=84!tNKhNNYAcJA0b?K!59CT&K-Sm5cxGmYtda>SuxcN=b2H0hD2Z4NU8kJ`xk*H{CY1OF7Zp'
    'Ax!_DnLc|kl~v?iH5nA4j^;y_6gq}eHDSZ(nX}H>5<Qg%u`IO-IIveAIj@3)icy*_0-c5VSnm;cSG<PZ&zUdxJMi|y+b;#y-kv@3'
    'Ty0%R)^t*>(fH<Y-Mb0R2ze6^FDGl2dASIlv=kA*`Ubs2o6hWA4=7{ll$8?A2FSq+zrg8mSIG}IaU7!8Q&9xfUkn9P_fA!9sc_B9'
    '?;0BOgHztQq@f~SpX0DyAQJ(zWQCT{QB(}<z&G+hX>szV(<60PXh)FzDukh-=Jx{vP{oz4Dm#5z>yzyyQw`j~!&BH1q8e5%O&CX<'
    'q_**V%Wl&P%uxUy)9iNsHyO?2xH8Z^qmw>u)Luwd^vs~4LG9w@D+sO%rLvt=3J|nwr!(7Eh*$^gSY#3EhU3z7C4(j#7;g55{ur*~'
    'ctQM}TeGaXDyP|Y`&$OeNWxCI*N}85RjmU(u!{(uiBdiqw(l`q&ARp>CI$NLg5Hu;XtK5d<*~C^A98}`j@is>jEe!_gkBI5lW-S9'
    'yrGi~7gDao#XN2oLmI5P8~-vHcIs4<QisAl(f=m$S^P`G*4ZplYK0YKLILJehJ&lSZ#4@UwA?saKzdL-haMtcR6E*?Ph-M9`fS3>'
    'IcQ#Ep=@WI0)GZBH$<(zGq}e25Q3~B_W2Um){d{7!cg^KoAJ|*1LuCrAhh)Y9$i0oE1ZQ%PVvnEKrXK5KYW7vR8_B)=s3hbWHwEi'
    'Y4Nj35aG*yKMIj{x+H~fZ2Ewf937{vlJHnsU#2yhnD_}1=~OP9pe8*<9x>x4$uV7N20uL2t?mN0fFYLey(3F)zX;@-qX{>hUnK?9'
    'bc=NHk^5T~`edynHBW+vzEW1a?f_;2nb$U7r9sJ*7%EE0$7wiiP58sDfrGI1X-cix07^T~t_WPA(k8Yrgx`*xL_q2tDmCw^WX;c6'
    'x?f^W@jF@=Mf7D*Lwz?#r~?i(a9k?7RL=r2y=hwDP%b)X?V>CSU)h;E@^I`}^Ovr{%>ctT8c^ig5&ms86J+Ni_e2+zPo;vLcbVDA'
    'macs1UWISK{=#=+va-|pkRt-!KlR##mm4JP%}WyLfQP+D-hcz_LPIwMHrx~Byci$AEKbyocqrrbTCh^?O2@mYEk}I<+9_Wnadl~c'
    '+@~ceIRK@Hr_UqM{r%6!qW>^t%GzBRz17S>9|hD&ghpB2(0ybSe0>V-=xz=##EvHn#N;V#nmX<$si+=hUFzs4su#jY^NeXvw!oFV'
    ';2V9^efR(B2(b>rwp)TucLf~HXO1Gxf9>?=7vMcTQPs*FuHy<^R!v{mhgw>RLFR0{+Im#g8T8(qiw0@8N6(5sLWsP(5S_q>I;Ibt'
    'ET;sm?4jpvGecPV#WHZ__2JniWIuT>{<&jDJWj^6vn8o!q_o)N@-{E;NZ#xs1wC6=q(E_%J|C|~F)hyGg5RxjD6_h4hkUa*b1kla'
    'b+V4ZjDpUDPcv&-{QtC-3J^h-T@oU+uYLuy5eh#aMHkU#eK4GJY5OpIsayUA?l_EFI)f(I`OO_kl5sXOk4lU5`=*SMbW^QMamkCv'
    'V6f`=?WhwH$9MU9?ED(upjpY1&kis_Jxz6<S9Nn&%1uRr2tP8ez8`z;$228<hSY+*OsFTHbuW+oz!@BUg3Sss;h$<UtnL|X@}Z5#'
    '>1^=;nsvz=bO(iC$QqQ5{UJhpjam+hzN841Hc0JTbauC(0kY86{Bo^%g_NLIQs~_?UH@lP6Df+SP8D1#ZGuk1+yRS9h;cVaGcI0A'
    '!yNUfMttG)saS%h5f!3@KmNZ-5wwA3U{@|Pa^3qJ#gH(NI!!4m@R<$b|4%-y-_W*!RVa8=0$_wA(^(`pm1%YClVDE_Dzn_xS<<uu'
    '7#bi$6zEmcUF<UERbZrDaMZBUuCdf^%0=|qe>MD6!X<k2f>9K%%FSvngl&2~HWQ&K$^S)rrq!3itrv6&$(fT#x8zZ2M;@Zpv3SQX'
    'h1H_a;k!YU6uE4bH`@s|FC87&Ij*_wXjzO)sO2M#yiyhbT2$T^Q?exUA8ln(4P7~vz3-3QFutYg_r<lbnc<NTmU|dB6f^u{R@edO'
    'V5j6M^*^ftIb#I1CoxIvu*5f((p1{XyQ<1dFg6$0UVv|Bpq?z7lYGsjW6uRmT>gpn8wH}#Yr6`v9;g{Fl%KN@1&z(&ZT9Lf_20YU'
    'sLUBMHT8;gI4alaPA647e~&tq+<@E87_DfSPW%;zD(WZQt6Zi3CL~R0EEo#N;w+*2VJzp#2Es;b(R>}$rifRuu^-c5$0^>Gt*B2{'
    'PLu;TSC4FUq*zqjcn0F54RvP$N7|TkXs3|r4z%ocCTRPf?pvXT4|&bIWoHbZmZt&f$aGSCWn?sqFW%BB>lPf~&!pH{;dX^XCcEF5'
    'Pc;d_i=f`9dg8gd)>EMdrN2YCv9*X)_yjE2G5PGyO53<ffJk8?-3%8h&fdLl552U4xfrygB4ZaN<UQXdwla@{A#6dUVGkgLa8^k2'
    '4b7j$|7y;N;n<h#?HLy|VdHQzc8TQ|ARQO0*JneRah3?muS<S}ZyZWO=7wM;b9d0PB<dxJh<;l)c%*fiY3^T7MQBadMTi>mKEhiF'
    '3#HnViKkD753kcadwvOgyB_AX|8z>G<%wHDRnDEToK?@#JsJ^zes5INN}QA|(GIN$K}{qotc`0$7b9CiHjJh$@T4D6UZW@vh8KZ='
    '+0KAIjx1Jd62?54xcNwHf$XaGUmsvK`s<_a$?xvQUp>m}yNvc%#np*yu<*MY^_=aXtk5fuA08`!ZTr|b=LiZuOJ~>Y6NqYkSY}@G'
    'f1aWFNq4QDYy0Ym*f$TeN#Qb*e8=6^>W6|GZ3DmY;UooG1jDTUSNTBJBd175zlJG--hIm4imb9`QnI=B^YMArSx$@82Mz|;Jh_#q'
    'q2ILuE~e~(<`WA;<bS4N0k^Wl$I+CbenB=`JHenMcki6`L3&NLL9bG#_%7%XKF<(vTk^6Nq0--9tOkFQy>m2y6$Mn}lXXi_tzQw+'
    'WR9cmgr`rY$-$LGXP=glpQcJ(jy;yQw3!23w-FUj`@Gac#$+HBSFweB!q1<D6w7MaYVaYq_2%xnBJIvI6~{Tu^kJ?Gd}v!#@BI9o'
    'w&f<ou8q9j8?LjhBdu3Xn3~ZH(x%%bG+yhg^@5>YqhXC>64DHTuvWJ$C42mhFlx59vK_3;av7EfSFWP%hUZ^4ft+@Q;U)=u`Z~LM'
    'gH4LuplL-%kM|`8D&ygU%P_FxmoMOF{h{uKjBf`e_X#2b(s;n7K2EHLfMw5PEl!kxQmyf1fAb41z3H%I+qP$>S|k|~RX4-3E50`f'
    'h$2q~kP{_t?KXglJ=zgXA!9wSf9Sy*oh$G*-q>ym9&W<C<EA7`3T8IHivl;dcHMoKzGGYJ3`)A+fzev!<jlpnIgsDeo?9`tw~tH@'
    'alv1Z74(_~w&P1Ysp*veNBGr$GA62eD`7nium@)x@oTen9$3;CMty>uCJZRmVWtF%2uZ6m8(5`0;LG0CdWmRDZxk^i8v8*+SlS*4'
    '%A)*s#KRiM8BdObeFc8L@U$b{mh7;<inpTuZ}m7tIWlTCGNXSFTpV|ok?-%a^FKl<=Frt;oFB|a0}H;x*|nZHU{D057MYMP^}cOS'
    'O3E1>%F)Thtu#ISzdq5PBWqWU*grC-B_5I}k6~Q+x>a=JPs2LcV)pFnX1(T>j$!X<v<Y|1!>n+5RcC^0eJl8mE4t6`R;uJ};PbA_'
    'K>9GBqv0qBkf@vTz@=nIJz-XS9Z&Ow5vt?D_>T&RN0u2fjH*2G^%OR1>Xt?$0@34DMDlZokWG{GPu(fB%l$Gus-arD!TK*9tcuUg'
    'J=C#D;(zoR61FU9Wu7Q~;ok_1N>9;7=@B+{AElMI!q7i+zX0^v2_6u^LqB12UKN352l5tA>J6Me1%?uMk39;>%D})BkefR9^&ZGj'
    'R7QLZdeR?p@DU=aSBt<LYiOMFT@tcV*p8Y&<7FtVMIi~iH<%N^Z8fPRP0C3m2&je6lVnnRi_41s^NbDOJvsENUKmW@y~fBM>VUFg'
    'yZ+Xf-LzA!!V3I^TP4ABhV0by<l4aMMWZpKV>!aaW$-WxxTIskhM6s~foz0KFlPz|x$!4;<U@2;_K)Vc@+bw5{}$ga<wP!ZXj2C4'
    'EZCZ|It8o<XhOutYbIvv@dvV9iyud`EqDi^+@YwK^9(76cj`M6&`vKK&`~8WAVJ~ykW^KuHmFe#Vpr4-t&3&P{JPUheZP=Cns)B7'
    'Y}!XenSDEUwt`}<5HEq$+rxl|4XbAO#vk<RRmeGZt7K#0?o`}ZQC<TPfx$NIZh2N1Qi?8^*5*6I+>JfG&l^Cp<@4+6p(gJTEtTVX'
    'j7}}*ms7La8xv+iTQtF9EVdy4{XqPV)v185wO#+8m^81RR+iAwV1DwjZXa|A-)u5@@*FcRAiGQ_vN3nf<dM_8yi}R2PZ~O|Zm2Wh'
    'irL8G#?RoeP8*^f#O7NNl&;u5Tw;m1v3<HiKh6f8Jh2?ip4|9m)KWc0Mh2S65B)4)t(O460)^+9Jw3Tk{wRn6fuKr7x+tRx0*`1C'
    '!zhLf3ud<APNelFoZ^eRU@JA<Tt<lYzP>k8L1HNAj!MqMZae-id}C>1Z+s~WXb@oxX6iEHu{5OO_Ui&s1X~CrZRPpe%`6pmFYCMA'
    'gL}wD<@dW=(at3aOzT@GH7Z-o4bWw~Q>%B8aS34(NF@@b6H@j0l7|KWKMoRpO(Hi%xc$4W6J>#q_uB$C;wLB_Z$ALeSApF<w#p?v'
    '>&KbS9nMYHX<JF8Mh2@h5NfVmX`5_%ZQR07N%Z%oCEP8gKqCrP`|7hZYoip-GhwCzGK*8OC`%t$GwG9A-LjFBRCPw^7u@Ej%?Qb('
    '&7%L&>ZshV&Myk7Pd9K_4TMCgH({ub+%14SC>%h5XW8szkk5pRyJr9th;sh|Y2Uy`gJHi5ULa?%J>8tA!gK#PX7C4^n3=%sK;$Jb'
    'mz9Sjf=5x^>l%jtNY^Vo3ePM~5$OI6K^ccbVBVL0+X1$>{QhYz&+ocqvwcbLhQxzo^p${7)YC=S7XJV1n7CreBk}|s0H^cCMsB7g'
    '@~%=k9>fLpi0f)5r(vx`a~g@1i9A=8Or7KVnsihy{nK}9FLDX>oQi(455!-JN?8GHCiCH#!?;!Vn|N65uIVP*;DYILMg_bwK;QLy'
    '6hs8{pOHe_(9wm9zK{rX)?Dgg*=O&IZ$Gs<5;TtTSdd{R3l-IOX(j;;lCbDr+F}q?yK(H$EV)Ye0}`B?!E5g)sl-8|sTmbW)MxQE'
    'VLA@tonFJh+z2UDI7HnVx5S#As9G6Va>As!2T_!lENkP$T3N<WWd6oQ!lmWhwhj?w6Sl{1Y(5qf%Ci~x2*#ce>4*}uCAzS9ZtG)2'
    'oF2K+)MEkfFkBRi{h_flst>?eMK4;sAvo3g|B&q2%$z(R1eiyhTu^8?t9~1-4$ig1W}V=)n2NVhWiQYhUwv!=pI1@RZ;y1SprsjI'
    'Up~*%=tcb9?XC0G8mZU#KZ|KzZ(}152_9gfOV*$b8lx9*YtiPe5h0pp@*s7gLJIRc(65suJve@Rd=b9TIu^xl_CBc&EHv$_rbd0}'
    'bN424hwlQ#Zg5$7WlTD$M6X<w@7hJ;kOHXovy@QIGbit-&k+2I!Y&!T?+6)J5q4~F`IO!E6bKT_0hSLjB*=AfmDVNVeh<sZ*@<jl'
    'MLbey2%F$f?fmfG6*S#Qtc({aWGd#;<#wWgIH%#a)wwcbo}>-8v`ospetN8d3*{558mNfvdHzrbMSh?cGfB!Yc(I;Ldp<@U6cbJ&'
    'Hy>LKZ^g+Jb1~{VwEwUQAh_i~6k&@%-8V~c_)hUr>wdl1lS8b~GD%BU*z}8~=-+B*RI*Mq(gL~c3ywTnh+LZy6gB_giLKcsVO36o'
    'wP$jV)=RHOfrYZqavbxm!P?jn9Z@xUCW$_E3-{naosNpdzM&V1()aVT!VzY331Ds8BGD0=UBXKu5J?>uKkLiw-9O%TDk3-CdK&k='
    '%{GMEhSUV@g_Bz3i`|Pt_kOq%lgc`mmgggLeA@(a$aS>CFJAzJ$9Ji%)Pr%}yfYVsLtw^J#C4(^=kS;`AwfjWqwDovhk}mX5GYjQ'
    'AatjF!B)dCy^j{u<Ah|EsmMyT=)=(bu!ZI2vtn*_B%zr4fDQ52Vrxc;xN6goH)dk87^;TWgE!ks9e~~?mZH&Nrsp+#<K?POv$h*g'
    'F04VK^wRE4B8u*NnN2I6++W)}7(^?XoqexhSR`Hap`CWr9_ODb{q_4e9i;uxdyW-T(|v2VvYu3uyK`bSfz7zRV8dP!K`${*6I)zx'
    '>{Pli@Cs)0PTK;o1Q8pXUYGL_d|+&RP6w*V+h9&5{)^-`>{y}ZBb47-=%2{bhe0juH`AWJj@Bm}Yh-O4zt)>jxQ(BOOI#S~h9@zV'
    'Otj2)Ev3JovaHi#6mUdl)Q}NxV$-f}#IW5|11XCbm~bRg(dVko(S;4x18cg$IOK(_D*aW9$mSO_5GNetiRX0*N!Z|u?}Pe+l4_}f'
    '?l{7!;8~kW=Xz_b_AT#&CIYxQZrs7c0kzd0MF>%6ah47?jVImt7}Y&Udr_D-nTI+Wx)4I`EZxK#r+r`E@|1Ij=2S!R)xd#g;U2t6'
    'nM(^JqlO5z>H^;EE(=nEAt9luPx92BC~;t*uprF(2l!`Bgbxh}$zgvpVR3yNUUNN;=g2+6GS=o(zH+FH#W6xUiJX_gMNW2aC_B&{'
    '4+#6e(on#(w*!eO{1V*bO7GD<qXrCzvJ-;Hez*WP`z2bHNDO(UR5&0f^VukjLRj-!Cjc#G3p}ZMbrc`Ofo^~AB1un8K;vt5uX&=8'
    'r<dK@;e3haRoEMzq@?ANJu9Ki3DiYU;8?D{T_Tn<fWkCEQ5bAa^0Iz^D}f%aY)h7$yGx9HPD-T%M#f!A>_l@c1j}<bNoAn3z3d>I'
    'VVA}6K(l&Sj?&kExx%e)%YR9t6+^COIb<o_&PZQiNQW08XsotBK91A#CbWJ#2BiVPP_3J&^z$b{I>Z7^95HhqK}q!S>?yE#g|8qU'
    '37SjEj4REr@w_{&h@f@~)!ajLVTM>s(1v+aXaP1UOt&dS%$nFuK-!BjO=A`+Chy$#dszQf>8dXm4EhOm#dy*jq0ff1B57_So6}AN'
    'g|mhg!8!VO2<nZmm|#wO>M+_E08$-g$*amqu)Ifm7Z-yv(@n-5mP)%zaAVI5t{WmIC=24h{jqBW5##^tQ@9X$UpDUEL4W(#YIf!;'
    '1B^qAU09-QN)bI(Cu@W%lgZOKOit7vQh5M*kI?xD(C^#L7b3t0ki)XrcvMN$k{xdK$WR`=%ZhiQQyChW>`z3m%_A=+`BmNV&?~=5'
    '<XWP2St}E(zN69bnJQ$vK{T{hbvx-7DiU6!WUSK^(lLS5v5tCy(gbRmY(reGKeGu<d6G-%1(!+T{MutTW}!Sd0@2V>#KWph+aBGX'
    'Z74b^pl{3Ocd?l5tO#zhXGNl)n^lYYttjP84Cl_sNA`O22_S7s9lmp77v*K3Xd)atlTo9Qi(|RyZ9{#O2)1HT4r(AwkBoiB48-0<'
    'o=Sj-cJA6+M8u{=9ABv>eM@FB0uM`foHW#6C8v7+QGkZxID)5v{QmpfdaV5U_~~#Mtdg%#p8OWh8Ox2otyiwkGB^90Mvz3m-%~Dj'
    'iL(Z4l{8X(KhBs+;>?#XeA{)E8?>+{oELkZr#T8=CNwleu?_w&vsqS&#Pl~NBhe(VjYD$ZGw^!?a$o@#=ABoT!A+}~vo_kaT|h>M'
    '4)m1Gmj|P21gR4)>rC@60pS>Ga2B*K{J5p#DO`7>rztlf3$f<NNep`9lhm1K!XD1YJMTUn!%GS5wV!5Ax!HRsGK<yI9D|Q_6!83+'
    '2o)RghvIE6%p&qUQ$udLKuz6h(NW(9Wx*TFou&n&X!5`{KTcfYTU_g+(fPy=*jJ%^nSORD?8yJ0lA}xe<GVi$GGO<$ITr}Snm`mw'
    'tx+(sA$mLJ_A!~Q;@Cms1E<{f-`0Od**v@KhH1`-+_vIq)BTu-?I6Fac4RkY`To#FmFLq|nz<=sG0}C7l+z*SK&LbHabw3-e@#Az'
    '6%y}Gb<^Hy=)`Qy#jVqy5_>6<Oi9piyqj#5t78(LOJj`}*a>KC^wRQa8hb8?BO|YOj0xXZ%t)0NLyux<vr{f(B`%ZE^v`xgD|OBg'
    'A|&~-W|a1X;(#{u3(vV*h-o@%w)+XqRe^|gbFdTNbS4+7^d^pqImSKnuq=<Ff4pZ85t#KHz@#_ay*0pDahVwI<EB}@gG<McRtkv@'
    'uv39W_{RRoE5_GC{Rd8vnL^jO&pN08ajQ|3?@dgyG5VsTJ}C~BMxT(@IFSPC&Ds~1Z4(1@!{>Z$QvR9PTC4f}YwpJxlp=_%jCMU='
    'ygp)n!<rhdOcX1$i0W?o+SJo?v7So&RFS~@2zsqpdzHS2a@n-+*ET9bB++?HUQRBt?eIrey4+GjFl>cxUO`i_dH^sUg*PQ==U>Dm'
    'ZH-Cht9}3A(x;t#Do{`69o=9GjAG#AWhY(Oo>{Fr34KTFH}&iJ2Wk|)X1d7Vj)KZ|*`T29Sf9aR|L5ya-J8EL)B#~!*wHtD(Hq4-'
    '^&ikt4``VloCOSvdcAW69XZ|j2ofHmDv$ru=}geP?Qobvfaz#Cm<z2}M;LfY!*Jqnq!1Do8pQX&)!dW|j<{4rSBPV!-S}l$0{Bm<'
    'c=62JNw;Ka&89>u<K616z18GX0LSztxUsh_tMv6liKz!t@np4Y@-q2$ot}7N2w^&eVPG#~Ye@(lIYVFyv^k(zVDX*-PMno!`H53g'
    'mo4#uE(LnEjX(%tl&rkq3-&u0qQHg#F#5+lX>SAPewUxkc2V?MJPLX(Gc6%72KZt?@9vU8SW|SlVQVzzk}VFgNvU4qNSRo~JpaP2'
    'RFB`UMdw*mr@Q!d0a5+;%AzCLFq+glL8CE;KN<Fgm>0r?3KA@^Vb7$dNWGtxI0yAA#kKS}uR1;km=L&%b=smhcH=bltF8r3aXum{'
    'mwQ=Xu?*elC#gpN^ZkpoAV2}-Q+)|o#^ZK|E#h<H(6gPA0ck$rOHA>oz0wr`))@jQeo<Rm{Z!O6Hof69+GGh3X0xp^8=h<D`*tkQ'
    '(FX70cOMt2daq+%n{wgtypP*u3?1ITLmId)c%}=WV6Vfz$)vsylZ|IavF!I;oGIdKEfprlfakfuM`)5$P~*+<{+Q8%Zg<KPs;T`^'
    'Mjt(_F^v8${HerAWDsbM%pedchU6;Mf4aZZnDY)Z#%j-Q-w$5&cI+mq_x69uk+eVvMo$wWdVUT&8|aZkRsPEz2rDl+A|M6;tfSE|'
    'g<4{=J4v|@Ba1kfLl7~sDt6}JO=fcVK&|VAMLABB{?ig9{Gg`4NH~o+9n5<VH5UbSp<=wvUD(FF#KF0&VZP>%A8l)1AN=a6#K%Ur'
    '>Ws&uv+~GCms#w8)CKy<A9mzo$pG>0KWX>M0A%@WT^52Nsmtzk5Qhm}pUrO{MX)K{g)~8j>alreXtXMPvGX;`bn4Lt_+WACknq2-'
    '^B}NIHB?0!!4XKj+C9YE9}iCSI!p|vD6iqaEGT05lL<yu;6L`ltn-I2)0knI5af_Z-`48UA)a!dt1(hwdFN@6;E2WX+FtO|ci#Z1'
    '%>CQ0vC$ko)Lpsfgiyn*o{FmLMU_dlvw$@1OC0d~MG-l`Zv+kXW=1!K*H|QX5nQ1qKCJ6`>{h>7<NzpnfT(pW;$hHaeVOOALHh7F'
    'xDJ@FH0w?$5}HKwo^u8z_c;6)@?X~-i->q;#~MbLT6b@v3q3|^Klo#ZehQPAg5JgB!v1FRWNE(Hen5#(W6+$ST)N~PLYUoXeAJ?A'
    'oHP7C6wgVS4D(-O=Lxg~J%O*bFrclp754y1(`n*vk<r_*S2N8Hh513!Kvpp2rh}fJ(;xd=X!$gWsLqsA5;wcEX!C*fmWBz~XE$(>'
    'cII+OJp+NQGZQ^fv=RP^;O?!Yc9wLxLR~$=*l>DS(hMvL8>_)WqnvJS(PX1!#2Ad7-@O`d6K>_==E;iD$CGvpY=8}NyT6TP+Nu)S'
    '5pTD>nB)}O19YePovsOF(^bk;ApTGdP#hsrknc`0?b;w3qTpzYK4IF1{Q9XQHFPQYKID*(*@Tqg84r}T@6x2DGTOP(HH($x28rN;'
    '75-sul~F+ue;41akc7RNl-Y-3{uCw`Ri#+Zs_N?E4e>D^C*Hrhwag4NC}{FK6^{l=es5?lKjOms8x*&*DM(~FO9W)~0@y4o(eGAY'
    '3JN;3a22#d8TGs=pUdHsEjYcz#8GN=+&YFbbO&<ky$n4B_Y$#MF>=1<uWY+ma9#u_1tjKGk}Af($eJYMHazz>UFzhNk~791Stnli'
    'PafXr%Oh&Z#qrfCRWF=n#$L&{xBYv6-RsPMe`nU`2kB5d=;yuP7_|srrwDMc0#<D3eZV<W?2r$P>E8b6hZ*7D#=_MvgPl<*ecOv;'
    'uBzyZ3BszLcg2|P0qj+*l^hV$uGcVo_cTnni^pDmP;yQJbw&V9IWOMiRVL-{|IE?q2rU1*PMey>eiPWp+d#b51GQa&D?yb85jqVw'
    't5E)z7zdCB+``W+lb2D~?_HI^lIJmh(pn{@Exq|MzJJAxcgnI~mifj>rhK~dla76oEgv&;w%~UJn8i%{<=_33KpIh!Jt+uV3xj<r'
    'azyh54*7Mmh&U+$`4El)<AdfzcdUWuiLG1J@6&F>ROD_MS4xH!2;gf{I|oiwz6GWHk9wo%8nCPu4@h9MWJ}zBNa<sa_nzgHbz%k6'
    'sOXvG!7><_5tTaK!>&*Jc&#-JSc`})X}8PfMgU&RTOfv}tKW*yQ$5ua-CmgwU3NA$dtqN4m(r0t?y%il7#T*cKU`MuyqGLxZJsrI'
    'bo>|5x2qBJf5xh2WK?S;z&<-3a>GQQRfo0Sq?@fuhr*nv&tadtI2K1!e#1;wk9BfhQOzSP#p@AzYa)R6EviMPXYPIb!?-UW!H!y%'
    '=;a7Cn7tq9{X8TA(1H=L1_LRY(!-v>SN8a<7E>vdQx1}vWzXzg05Q~4ADr3d=!}_`mY$g3SDZ0+I?<RFaD=A%3yigLHV{=|dv%Bi'
    'g#}CT$2YS;7Elh{$Q(Nyd7+kSC}r7BOfByAbG}Gp5{P4;%ptU0B`VTAs9SSu)Sp1(mg1Ry>{g`i@!9*brJvMHl+lPLW2*n`7NQf5'
    '<;TMIRc`o56s1Jv9cq-zXmVWXHkxdfKmobdk>A&<$XW420K{@B44`&w-EhV3fBumMxCMM6McUwI<{{mn@5%H}=xq`03O;OyldSB6'
    '<MbI?>-LV~-kaFBQdXitRd!{T{D<JX)EiesmSY`eUiS7e;L9lG<4>DjFE{SLqg4h;yEqZH);rXCWpjo4#h;!1bHFV*ZrXRgJ8f#V'
    '1#_Zyw-BO|?siM)?MkX~P5}lV%iCFr+gPw?KHDD)2<lte6o19Qq)v*p2|iJ7HCI{w&{AxL!_f!gMw8r2EUWpMbtH{1Lv(R5?T>dR'
    '6-Oy-4fvl3*+3$|z*C~vQP&7j*k=t6Q$xIq2sD-j>+^EQ0_oLh<C6_1?|z%4F}$C0y2Mtsi>GlF&pNm-VIMf3@~ab&FMx-U*+z{}'
    'YWEGxtchZuE+Rhx;;1&Rhf-$jM-u{F`j#e>_En;{|F#ACl>vWw*`}2}8CLC;`*rqe-&Yl}1J#y6hUd4F=IUa<#2IQ}Ed=~5eO!`8'
    '153|pr%PAqv=13JI)od#tO5V-_p3T3?cIME?@+Cb5jZrY;6zm|G1Bhq9sr5ot$)fxKi3?Y1Y^L7g2hG{r5mXnh~8WxM9oS`xpADY'
    'gtb)wo7HSIYJ$Yw17dIYe*%~h1EQrU+d3ps@CSW5jr>0{cdL6MT^64WfQa%j#zhL8VbT*@ZE=Y~RNdup1cjDDv2A~YLLgp$r4&LO'
    'FyR)qVqpahQ{2_93&XDa9cVkXkcGzQ%5Nw$qGTB4vHhYzDAY-vNNhxQA5<jTnbl=|R7L~KoI8@wtbi{KMd~azHH2a|pf0Ubn)eB$'
    'TWyhx^hz`s-)Wq*a81<bu0@lv>Nei<4M1yxEt^t34{!!5;wOfe1oI&u8j+sa%O!77N~<fftvnb<PD1sC@eJ?<?oMIRhEmTVVWRxn'
    '>;pj`N)<-=_mnvQfxDWB!F3N8`&R!3wsKn(hKh^N<~m{gel`)v!=08e>?r+ajG^lZnW?<46qHRgSEyP=%Y({)9lJF%*|I4yzi+W$'
    ')LmF}Po}>_ufu%u{#r8&wVL8Yuc3y943(N6ohXHw)ZU>Z#J;q%8c{IG4QenAidJY-HG#E8v`!z0wk0tqf%&D~#x@ze&cv;70Jf$W'
    'wT&T#UiMkiggQEPHCEvC$V%}Dzs(392abL^DounTvl{C~g&nsS`bSrMsjiZgzum%d)ZgxU=T>kLj2Oa9!35&iu*cgaahlC1@@x*l'
    'WC>i3rZ0LUn^TBR?GE7?`7#FHb$04h#f$TI?Oa=5>(8%d<9U5MoBv9=tye1Bs>bJ==P;(BfU}Ti<xMdu)HkXK-|&c1XEI)D;{pK%'
    'KIR34bG!K%#D)#PcT@v)#+bPTWanvb<QV9*NFr;Q9?S8$vf_)$un_e&-Iz4XeJ(Y8q^nq-e#REzMYr&<L3lKHgZW02b8e(Ud=#T>'
    'r0<|?cq>uH<~d#*6=?JVmt3x0UPrFYrl!GkNgdzvkNT;PWk&qX-rBT+u1K|PhnQiloDGMtL|qXUHDuXe*i{(K%&T*bMZLpT!JgDw'
    'Xhd+iL$e3Kw2B%~QNilI0U8tweb=7qwE(SXfKy0m5^340S!q}<U!8h?Dl$>BI8>MF*eosvsVj^hN$$CUQuN%laz{#aKj?tM+H)*~'
    'ilr#RZNmJ9dpOL-n34js>~~VSy5`^Mx+ZLn0I{gX*RDaHGIxv8T2XWyEkY98WZvXkN6yj1nI2yo-O0M1c**pJh7S3rMIBIyomOvU'
    '7<$*V{%a;XJOC5tq6I=-pGD+{>?9i|L>O`E#Y%OGXpYe#;wb#Gy;J(9Z(`3%nhIxi7YbgorVU0~ZT~WG@a~s6u{XSqEe`7di;H?9'
    '$ydj6qn>u5;bYJIAlR=Ca256x4rUdy-U>LX?H^;`$9YY5$BxI9(s0a@;D-J@*86G(4ByxgQxtV*V%WM7j0MQ${raq6QSk5A2`>_T'
    'g^7fx`q%a_fn;j%Q#TBCnbD*oiEz-D30|3zN5~Zztl*mKyxpC%AdX}jYsCOF;A_lYW=eZtk3q<dok5ejBRLO!!%v<38Paf_C6ADo'
    '!JSN9G-p-JTx&?YQQ?xm)8%XEF%ad&(4Bm8oJHDJVt5du#`F2+>Lf2ZO@HZz<ZXRB^WDa1QPZj*dgp4OsmOXys;a&zd<{AbyAAtn'
    's-mAI@FNP^kR|Z6jqEVFO3TYAmpg?eKKEBw%OEL{e3;^1^ZA<^d$DS%GyGhA=u`b#+k;V8T;(3zhyTvYIF)*2&2mW4c*DW+CFLOB'
    '+nn7bP>S85b@+CpRl`bgpA2Pmp+Uy>(3N%PgER6kenUr!2b_et^MXsoXzv8RB4bz`_HfbdZ*f*xN#Jiyy0)ifpo6+rQ5qxd^5v5)'
    'x$*%-`be<7woxGFKG`)#JGIE3ie*q~=Ie=houlhCF2?8AY#NhEmq#93_;io?+bM3Fkq#*TT5c{{Egwpw+iO)EK*^TX5EJZ$Ib!&>'
    't`>o|a*I0zepNg|gZKMipaJmfl6QkU4_%&!sa*RDbifxZ`wG-Y>K-V=fmH$6S?B8r(l60b+a+Dz1lCn!p{9|iRKwwb*f1N(onzw~'
    'ddehp3t|#<a+*|9vCZX>TY)7;IAhf*(xf)h25EW-3!S_r3d)GsW8={4ih*ONuFA8xZj*X0>@DtNRHn~S4fr~(guKz+$ZHx>Hb1Ue'
    '$x&Y#vdWq3;72{`Hcge4bW|!>F9a9|wDpjEU)hTf2Qaq}vAK`8-A^GOOI=OR1k#LwB<16*5-jl6di&u|O-7(CAS7wND8(|_6?cm^'
    'yXn=9G*l$|XN1>^yS%QV4GQHb6-}aBMjjfmg;)fEppZTw1O^j0Wg!GFn2b6<ms=qsAFBF9`zj5<`9P}42)U*#)qnDpvYO*2XJ#X)'
    'nqgl?-!rc>F`)kL0bbEGZ4x-F*PkKS<PC8i4>QwB1!!|d!mc29IOv~FPPrx?Y_oz8^r?a+@F!91POE9;KaV)#XRB2pL_h$I1i-d~'
    '(}Rq`dS~jltAE7(yQa6sQfn_})t`J!RK)|mKD-Oy+O!HyP_oG1A}3ZCqwJ+R`iDq8>TT5x8t=VLCiGru%!nJO<qSr8g>d<@_>5S<'
    'X(ILN>_Up}Wh&$W!T99Pc{2mIUvuDIo-Z|6VPGIvMJ`Gl%t$d8<bslL3&?-PRzBlKU{jd!0>1a@vqhz3p{3O6yUie8FL^MJ64r4n'
    '4oXda$s#eIA?((|c=t%$J?adJ2y6y}Df@f+W_sa>X135*-c@=z;m-mjx1PU`-8>T~_7ouY{0bd#ZVIKW7;CpKU328&9kU^xWbdjZ'
    'RsI_<e*o%>tcm&YJOU4fMfzX>eNPx=FWvHtuRTcse}}Qs2l-}lF_&srV-w;Qd`6yBX*VK5uwlXzhAd*5t(MmAKXcl|rL+u_JnjY^'
    't(ytFR`mUx2)6fpoV%wP4ZR&)w5wyo6WFsiE$G=dlGv;XG`a4b_AoNYETiF-FdT8i0E*c^J-YFPywCAeKcHvq)GB!igu)oTQ#G&{'
    '=JXzz8lX=5ex}~56oKp`ehzN7wd4r-SqV=PZ!EK&axTigFpe#3JoD@(Y*S!Id=xqP_xSPK2np&M8bCY~?u5QoZ*{L$U^A$h7KDq`'
    '25>=Uv7xN)zVb6(r_u;uCzR{TqDQeZl0K4^(Xs)YEeGYpfIFKav`{Zz1FlW##!(rwUQyU$uoGcSlOt893Vmv8PIR;-3h`r~F})SB'
    'K*x7kUqC=n)E^!JK!l~J)-vzk2)3e*Qot8e4lB6^8M^$DuJLX<?i29cW(Q>%f1IH}9Zrep8A><nEwwLU85&HGs$y@FhGJFXvEyd|'
    'AnI%#C72@_`BfUYTw&QPRIveh3A3=8KU}^P*hh0igzhfPD+jn<Y6MJ_F4^or;Mf^+n+PRMv|P)S3{7E<G0oKv#>ERVrdTW&I#8%s'
    'y4O5Po3$Q3F&^wh=<e};)zMxY150s&0&umQ3J>sTJ1mZyxd1;R#YDv${G;_1jcN<p(PNQZ!if0;bzMt0JI?hS*3`PmBhTVF{&GC~'
    '2!)>{^OXTI`4N!#6XH5>CI*Y!;@k{H3{MSj(ko|2ArO1lneCzLvI^5$nECWD61pjG2G=1~&Umh4r_YOHt^Y+2Bh-}8&?!CU;EIdm'
    '+E4!KU#ESt!H1QeLoV}XKC*ak7<d?LlV6%FjwW^JCztM^OpM?<6VE3}7_kf<Jjie*etl1#2EsGuMRtV|`<nwMjEyMslEi9F7jLs<'
    'mT7pqGxn2I^t8A&RLS#AnJ0auQm0;FC0wUmzghkQ(A~-APjGHx@7qquhomx4u%G@S!N5vc7p8Ie0TD9dRb48xWR3jsi$b>^0ry|-'
    '<-nhRK(Sf|jbo`{>ehA1ePUuMxpL2zRb@9{NM>R+DfmgpoN7U~=eMy58zdOPnCK(~2_Xg8`0l2y9*nrpE>Lg)E%z(i(ngcv-Oj!K'
    't`D~<DE2h-{<fE~((AGL_(b&HlG|^2n@l@EMD+0*vDhi_$B*8xe-*}z)0dZPV<j+}MEp9(AoY8GJVI@jU`@w5Bkdx<d`^HFLq_4I'
    'MbUjka%}KJh5e=u$F2&<maU+r{@pxWW1J#hAd7sCL>nW{f(QB&bApDnYwG@aQ|VmRecQK=#s!f3^0(PE@()}|O*Z+OqQbUyNPG+t'
    'eZBq&(gVrq-$%GKTKl`0ve8Tnwb&XA^t+1?ZZ8p68%R2LP8lfmn+xacdIklk)EfZ8Gu2Kbk%_*PsY&ZWHQ|m4*Rw{MBo_jk<O;YL'
    'O5qxn=(}UfK`1v0IYcY;|G|{NUotc(C~eP{sZ~%5$<CaF8(#IH%2h1(lHK3;81wOHpCdm`t<n$WLErE-VF}jT`!3AXaDZ_-<SHe&'
    'wQvE96UMZ-<=k)*#LxKR8<L2@`p-^Nkf$rj{^{G(6<MW)+V=IG7mR`CExFfD%(|zhYfB7w-5%F+J4}bi1+)yBj$aIS<KqzqGQ0%u'
    'u~r8>S2N%+gsUjs-@t|-*Eu<QvKgedhzDV3bW#jNSfn~fIle9~Urwjp(tWe$v~Ju=$_K8DZr>W)wtIGxiXpc4>c+g$(9AcH-QaPt'
    'v}!yHgNz5Xb;dPF{S7yD|Mgs1Jw6LKY{6>nk?mFVCXT`yp)DJFd@9|e`5WH6m;w%p@^GJe?A#OTs?(Y<3R&&WR*o@``YlqWo1Lxi'
    '8ieE8*WBzx<>KC+#mfqwm=Px>7C5si&>A`KSGmIh>Cts|L=3?S!4y|_AA5jv1=F>|ftBIR<?JerzGY{S+76tIB)`~R6tyhB;LvH6'
    '^GrXtvsl%jg3sknZQf2*_#yEnZ2z=_q_pBg`K}M|e%SK`#zQPir91#A7UH8qFWP|+qVv+}h5id;!C_llsfz}4e_`(Y=#+}=q|W)_'
    'y&StRGN;}rid69PpL)0QjbVv;mQ*A=fB95u5quy|@>}U<+>*&%a^2UeC#++e#GkjLeQDqORH>ukR{@5CBaVnH%BMeH4is#i%E~it'
    '_LjqsZV!3pv#T%}1sw#s!%CPgo#O}-qvZ=l+qDM63b|0Lw^aHqWcGod2dlwogN9-W5~jo&pLS#iie93Sn*f#KG+O6}7#n~!j(z>='
    'LPtp#prpP<+v$PGhW?UEY?R}P9l1ixcTrH2GR>#v+DGMm4^>|vhSJ*ncJlX8bitQ)H32F}E=s5+e3~lp$q{1L&KP27PdUh3YOqgK'
    '6t!a6A{}we8b+0lDpD2I-|WTX+nv8??#)cV!u<pPMdwbd*&M&MEXlsz#kSS?*eWDzKBjp9exVzX(x*u_;KFr=)huHzm^+qJ7A2FC'
    'AtOb2@iU2RgkQV{6$e*N#p}aC<>6D+LTFo{_?ba1Xb^Hq?rmSh(P@TMGp#Y2X@GY#j2E&b7cwK`yTBDuVCuL}5>*a`zg(cVfhx$W'
    'tXK*)%1(X|{Y0{BuQUP)9j-YtP#}WvX5jAjS|DinY?{?%NNZ-+wXMpEYl{uvY9Kiavp*@f{XZzp$;3p;^S+ijU<xikIF>sUc5rtP'
    '$xw(0Kcj`ZvFwm3M2YWA`T-2dk+6>kZ`(Ps82h(G2HE(%8CmNx>zpbPe0|+eTtunTME?Z}@7gBoW%TMAd-H)yq##YvPz2--kUfn@'
    'ddwH0X{OR3sI=H3IXQP^O#3-yvVrZhFM-lpG_g+LC^=wGt-fjx%VD!wDYK8h%Z`=xyJV67?#W6g#fCm0(3h1{)pd&M^XG*B+8~4D'
    'GoJR#DN^L3Bj2)5gQ|a%Oo^fJebd9eqLq(cA`42tu~_>Nuv)sI9UaS?hDFxubhUHq#KbG4U~E|GXr5l31Wr8tW1Ua_X%pg3?FZmt'
    '`UxQ~yZU6-KNMV8$nxs>fd67QWZsEBoRF+k=$&#^gTGP|koy&YQj4yF6$8R$bRKnX4*V8sNzm7;#S)?9L?im^J!Yrfp|N*${7B!+'
    '=$Fy8kPd7LPR7_r3H=skPU|`c;$cTpj(ZR_L76mU>@M_1?^Ka)1az+*k?Y4oSLgp94;t?bsZS3N{s(PuTBPb(=e}b_7-W?qM-oSO'
    'lIoXT`xoUHxQ5zhfMN8MAMRP=9m4A6q)0pnu14vt{e-W<8zX%0Eg6pZjxps1-5m|uqw&Wxr*`sDn#wO|H3d^m^9p%zcm0V7risUn'
    'Cbucamh8KUCNIMQm429(r@Gmsu><SWJ#^m^)5w1Hy$S-An2KtkC-Y;Ejx3ia@m4i<@*T9d5OlY_;Ty==fFQg)M4%Ph^mZb1_+{A_'
    'm-0xr8o}~VE@H*CM0ZRzWj#=RkTa^@yIEoAif3-Xw4AkcpvUWoVX4xE4of21V^OA9g`C@_z#2JQ`jhK@f4L#!VwlhL0P0hl=hppA'
    'h<T7|5~LT$|32FrtrJ_(I|zv2C)?O1wKuh~A4)2jo5UlAB{^m+DqU&>^*0cvKw;B$0}gT{drU;&NSmh~!!f!8XOE*6qk`H|0JLZ^'
    'e$cGn7dFMnyZ84x8$YrZNI%p%=hR<bR{%pA_b!6q;ck;P7oi>T6f|S2WM(a`rgef_E#nhvxZ3e0H2Tl^V3wpr1cvE9irJ<{xNrAk'
    'T%oJzSI;6XiG%N09JcN%eiP&a9~g`lcjz=Q0cr1b(GL&o&;%j1txAtSCra$<X18;*iT<Q|yjk-Vv1_yXsSpXe*umB=V_O`#A!T(V'
    '&zeD|OZckrbv;19BvvF1#oR*G(f@nKcCFR8Y0`eAlC72P$7)7!TXxaB{Hg*OdT~gPWHUs*P>eSQSGtO|?Usk>IwuLl1dOM$R}|w_'
    'dTt6Xl+EI8@Mhcckl3IPh3{Ourc=!Ns1;5RVZH!ptY;Y)XERBS_rYG(ISuR$EFj&vxOp7r?$k-@b5qVHSv(v+Yr$~_H7M?At>WAF'
    'I#F})OkE;?XY%JbON|;1JNsFM8?^tZ{9Y)CeBBZ`{r={6oiyjur6n;cKn(+pU-GAYsI}P~U(euYR|R20&eUO=i07|lS@G%JGPDDg'
    'O7)L4Os`g<w(NJKyLAm4mdm=-=a(CSts^vnfLe>y2SkyzskgwF0IFGE9@{WZRZ-JnrPUm^Z};Psjl8)ZxI7~+K8@mP2TI{d#qe5D'
    '^>cqj{?G_ng#F~3$xv_AnFBsA^6w;M!bAV6PDaZ-UkU9oDGkHyOerRU?$|9&4A2dgk;amiHej$Ww`7pZBG`gr9p1z#dbCC%AS}FL'
    'I8`^8uNtJ3w7KaMeUvVne=!$FMG^Ekgsw-odfOI8bgs3?@3?J$g-k*SO`<!0krptzsb2}{?){AIh&)nS-S<fozhUABY{knOq2s?r'
    '6m#9ItpEAv`JM@}`6mHqDH6s*f^DXaN8TbVK^mfDpP-y?yCAw?oxW4*oBvrd?cA~o`Xgc2d*)YV3t0_BG*_(1<vt5o-FNGmTaa7Z'
    ')<SlJC@ZloV|S|DW`Dv+r0ld7`Sde;DiJGQxP}CIUk|S<@#q6b7w>HJEO(%tpxy?N3&(+hy9i;?8Io(XMoZ`TF98%LVK-+9{4D}j'
    'bAJn?3%L7XW4eV~XvT44)oeu^i%_X+tm`?9xu-WjbeM7&s|!Uo;I(LR-a8-S(Gg2M;V2F4XT2C{%=XOaPjoGTPi^D=x#+}t$jbD3'
    's`gEwEeq<#QXH+(4^@?(n*#Y_)?!c>W<j7A9L20F=W&Zuvw)e}sS+yaPiVt1{bzju*Kzc*eJx;9fmS1+x+*+bh(`>Ds$Qhm&v=Si'
    '@ACFRg0Om6zc#N%cw~g!cgFXMRt6S8%}Zz3$8sOlKR4{DK1EU2789gUEnJNoRAJB_Rqn31p3N=^OHyaemNJ*dU5U=)nhKEUw_-^4'
    'e9mFb0O647L4U{3sk>SiUdy2bK<n(Zyii!B){`=Q*9N3MF4~LM%l`<3Hkh2n^9+Z#xYcDyFr&kx=P@=xa7ZvDSnpF;6!2uKN|50Y'
    '$_Ml=I`}ADyd>ouE0I*CU67M$dE2LT^h4FFT++jQEdc}??l@u{ljpPMfH-y|!|j)T&yd<c3{U|F0|sv5NHLrc=Dt@`+*d)-SBqNM'
    'V}V9GU~q~#Lx}AuNR}$%TJ3wzZ7vH3?H8yb?{3cAmM;YFT1Ajebjx|c|1$8=`}?|qSJqW!u#sKTNT!8-*iV}AsNom(<?K%p^_}EX'
    'a9wPQ!w2W?FEQEn0NbZ2{*m`uwY;$nCVPs26ExRXcQlAKN}4`uLVqnCI_NIBU;m6>{&Hxqe-%x4WZL)8S(DEy3~v>q()PYL41rtB'
    ';W3zZhUWwG2RL|%C1Jz2%_a*~%{fnCfRjrg;EJnhuY3NEpd=Y)gR{m_;x5R0ocsCZuV;K?H5-xWSJzY7*w-npxpGor+@XM6ZZI8g'
    'ldWdhFIoi~z4bnd1*&ykUka#~!3|AEPPVQAvrG5toA-CJ{MlD)n%jbH*fT@-KhMPr|9#ZD!!f{_@KC6i>d_Z|vkvb8;2z3<PjXKo'
    'A8TT=8ugxE-LWYZ1zgQKOokJ@XnYb5Wb=P2<7qmwn50nl4!_i~Yv$TA>w&!s<v!TUMn%3_a0H$o8Mt=$!`T-UGn=qp5(woE?0tCH'
    '$vg<D$6bxpYyb^!ZIMdQM8xOMQK?^Mh0Sxr4G>QBOV`3LfYmBJLi!8U4>eZ@=ji3PX%sy^@!rMB_=5}pgHM*K_wrX9c}gywsRK-F'
    ';4Yr$w0g}^w%28hxsgdW;cMxf)JpHJ?djt;Hxug5-o`$#_6zNhtcfqW9l#Bq-Rc~kq%yN&eZk;1@VQ5-vN?iiydFN8?}5ej3Nu`T'
    '!j=-#^t7#-#qT}NOgXo_`XE|AUDnzIC-`1WxM_-@Pr7z4a=}GuZuwC=4>nQ3%Kqziq1lHMN+GOcCem~={X|O{Xh%gS)cfCSFS^<a'
    '5?;r_rs<_Kg0OcK7Kcct+BEtFIrzi0VU$k!1f*#TVbw2rvg4te)!}Z%PR4ZQ=#c7qrhj$h1Z79Ll#(G8;=f_QQ?rjJ%$_yD<V;Ok'
    '*+GbTOLNq>nj6s%O+n-W-+J=5QqP-8l;)OykxZUlNRR{wX=OUzL2qr^hx##};w{8}%nPc6n@$PMZLfG(p^s(42wRGn1{=5(6cIQ+'
    'BdGRMry6kO1d6U+N4_iYJF$ag6p`N>rF(RR!?SB);}b@#<WhXtIZ7PMvaxryr$P|+tt=%c@~gObY(b*Se<gS2FFVsik+uVY<gu{8'
    'dE`(yVuEOM01fU(l;_ZZ<Vu{JaujfSCujGz5M;vXTtfy;Z+dyCocJsSGt!pw>Ok$q#5(@o;p&C<ZMsvnFHTuek~y%9BI+|AKJD+#'
    'SaZdh6QwEIg_?)@-zVSkb$Z@xLby{h1@*oKu_nkUP{VH~Gjj!fLG_>~t4*cZAl~sY`i(nFR@TlS<i_TG^~_4?=U3b!q2%`y8rc)l'
    'SR6E10^wn(A}tb4q1M%Upz`Ud@sIw_Ck{j_3+N$!DpVO!BJ^7zdY>=O6ER(yB@36yD9!O>cFouVSr?&sgcVWV)t&oA&)YazMBPC-'
    'GR?waD1xKiE<;9q9jFO^rnv0JvD?8@PWkDlvgHmvk46X#Ui#eK`#t(ouAtnZ-KB^6-h=2R9DtVvB^Bb@+xk@{1OjK7UL&C%MoepC'
    'MMB-1O#7`J8+|~M$K|Ve;&}l*Hyes-)7(OH;3y8rSKcJ~xt$(~1|wUi#6~hW_37=?ca)ADf9K0P+F_4ms+r88HZft)=<4=pM0s@%'
    'qt~Tv_@y>t`N1eGLn!<OWD7{?CfFA}2m2GZDifH)dKT4RAn+1~s|_7pkBfVvSH1TgHD2$c7QEHN>DQ4B=IcTQi^k;uhdx__i@vt1'
    'ew<0Ko9dIepp7HS^AI0K>Gb~)Yt+<dupk~yi8rS!Bp?uAmrWbxRj>H(m#ryy0k1vBxo3iQ+YdH^@Bd(6J<n^2z)M)7z+t)m;cLr;'
    '6}2zy=uVNyqSbI)%DsVN-Jkj!y!lr7NadmG$hvr|BW$f>4V3WFSOOX_JH$NmRXM9h5XYNDh|rcUM9=zV0ienRnlrw|{Qsc?^^08T'
    '?%t4P+dmFe>)<d4N6eAOHgS|NUUPHDD1m0+6li82aRbJKZ-C<|gq2{!HLRH_Hm|m;vH3fIWN8qHQztx+V^X!ug@K|p!3S(<Zw2re'
    'Yf!xHr~bzZl270;N^vCD2WM)|O|<&62Lno3n1<01&eMARRzLo$N<FW$BBT!Vy%SLI;T4gknEuQt?;HsS$nLqh6QWVO%V>9TLhHZ^'
    'W7z<6dt+m4B5VNSj_=|5{IfAHs#EFO#mj{~0AC>0n!ng<-QDRY{CH7V>COI!L8j{j8lvs&x%I&=5QBO}FjuBPEO!nEA3p;ImNd^V'
    'RePa(k?^Q=Ph%t<g~dhq4&ym@X;(=>;4w6iJD)V#scJ6zh}%dwhPJ%74{u$x$|4kh*AAG-cC)B1#g!2jE$Jt_9&18{q5-7C*5CtT'
    'Qyj)J(6Z_o?{ml{O%wdKC7aDE148>R$Y!%n9~i=6pP*fUj(eYtVCzyS{f&;X7iM*_&Kr6H>^|SA-%>9gj4^%h0!>P~K6f1YVmZtk'
    '^HZFkFSeV2herCY-k=&Z%24Emx=P!pawwL2d38Wn0={HxZxbbPWYd#k+n)RxDeQR464y+b{e92$kTNK;?Q|b;Ct$Ye-Bj9D#4Iz9'
    'b9V27-8K7$_Tk`-yjITc1JcbAP~_IfQSy5I$lgXA$(nCn7w;KHr{4Lh5wZjv8(E_et++v-O!o_Jn~D#|%MpM}S`9wx;4}jbWCYdN'
    'TM-_S4Vyid(DviY>b!F|6xHAUeP`Krqo)U@<P4E4QIZ74E-DV&WSoU?MMCBic}?ijL~`9o!Re`0;c8s>jl*<av_n~(!WquOr27MQ'
    '2e$<Ne-e%y!aY0%)W91-|F+K~L#%no9^3)UeTyi9FyV1dTpT%da!nPcEjctdF<x$^q9F%W#g`W&EEiwAZp&3FTwLuxh81$`oQtx2'
    'OqUbXD=d1ZhLTSaMMT|T1nyjmGRRgQ^y-sSon#5Oj-8ti31D0K1L-j}&?c`*%R(eAx0dW|n?hD?IfCZ-w=5qBfEKlUPc7Or(QQ0u'
    'Z|MezC3b@DgwmM$u957eJ-EDiV0n|!VetyBd9ryF+uQo&ND?d`0I4h#amalX;68odNe|uDX*+ON7nLBv;x&z-u9;DXG})D`j!Xbx'
    'g7x>Awlxv$YcE!4vbJjkNdo6D>~kmO*V2IJ;+PYlxXxzX46pX-zNALauRyD&z^nwmfNFu>EW_Q!k`1oFSfbqeoUNqmTV!D_x6{vV'
    'tC38P61Y|X{t=9m634YC`7}$1+JS^1KPXOwRnhVNtWu+cBtB-QE4u4pGUBiS!)epYgGNEd00%T@oRu&|*Ey6g)XP6?zP9>~=kfb$'
    '@`LT#i2&poZ9sST^QO_jdcKlw6UE3lbg+h3jkOG*YL6A=+>9ciPvL_0xWVea1|?XTBr_D?=~$`U#6QK{aNa6+V|=UTwnVn|T3><G'
    ')kgiaHQ{XBRwZ$vD6f-LPF8@h5aHW=jk}%l2uryMVsp)-jNsRic$+s?n<2d7Y=$n3<SHyYC5|*dY7^T3W%ohIgC47?Y)Q&7NKgq2'
    'Oj5cP`ZaOGb#e46fUG6m6h*AFK|`7s#}m0wY)4ukZ>g;n6XdsBou7z@OH%;~bcGq{W}rIr;`Brzh0swa{(0pH`aT^#{JnK@%^jWu'
    'BJt5q5(Rf+R5w}e02m#Iz1uX8LR6q3LSS1c#;)r-q!{FW*6-S4iScGZak4WUx5s1NBe`Yy4cpg?tq(l1(9akkTBy}ah{uv*7NY%|'
    'd7g^dVUCKlXHcaqybaf~qUt*5!(Vkio1m_hDuT<V*n{MWOOQ7-a$){&3Z#)NG;c7PiP~vzP1tNdFq8&lcTnxQUx-?~5yfCrS_0Dk'
    'J4k_@UAcs1^*uo5zlA%}1`Mf$S|<$t!;7su@v7?Qa;n>Uil1nIxw#`Ku5Gl*2}I<iH)SKgVWr{RSLWwVE3m^zna3GSt4Hw}>eRG5'
    'gv#>02^subNM^XL&Zh;c{}hVEY@EL*^sl%t$Ej5oc|{l=TfBrSZ()Xd&j7W5S*fa)L+F16RM-T&3g2@SLy76j=+Vx6PDu&MpP@-('
    'GGOrmk=E9MfD^Ln^Z&fBmIV!J26Pw<oj3ll@|~BmxbvDsuJ=Msq<f4LUt5b2r=gi-F{I8dEmSwaw8m!XnV|Aw%y8idy=-2G(s?Mf'
    '^9>{LLG}b<29xTDU&4VJc;T+SB9QWb+&+4reI-Y}s7|U6SFn^;CE0bU$0h_&M_?Vl^;)IQp-V8#Q}%)H3*Q@S#h+iWA<jeg(Krg5'
    'ZiyV1ydKD|7#){&X6m^P%hw}~?ODU?RvR}nL8#m`^`R1Qjx>8Z?*zgrU~u^cIXqW?emh<<JoOnErAPTq{cS3o$_c!lOx6DsVSqYm'
    '%6YAU2s1d}*eQzq?zU5UC8{`M``}Rmi-eBfBMUQ8yEJc9m%OH^eI`qM8n|*7;Cn&Fc8q4l#CaLb<V`y1z<G@cTti)P<H%yXD+I37'
    'v%Nu;h2gr~jV;p3$+j2%+GUd{3HU|+WM^WnEM7~jfm$1MC(yjdou#p4Gz2NrqsPO+T9J$2a-4G4H~=X5S0`!_hy&tz7gwFS7s?lh'
    'QVLcZw(;=xLX;vvXVR(7O-I=k|4NW<Rt3MR+0U>!2AtmRRbmCKeoHKy`MEd1Fq||OBp4_chuRq%h)!HN=4vIFgglONir`1$)rx*v'
    'E|8*&kbo-HkGmN2xj)O|+4J#(t;{kpie}++=97{@G_vf$p_=PSy--LN-BD3e+%!*qEJxaZ@~uD{q0VYhNCdTveLg)b%m>Ak2yrbl'
    'NQAg$@6R{oif$AX-}Xt5N9ywS_jaG2rJAgyz=q4XS0$_{k@uqbE%5i|n3^)lHQg^on|nLpkUcicL2L`s{0Gb#2uK>f=sB1a*TbU+'
    'N3skq=?6E)SVjrsO&v|J^g4nL0H>yw@(!YI^3JWHQho4Gn5?Mm2<T#12fTiM1Qr_d@|W<;3DJxc<m;GOs9=cG4@krav-@W|+#6y`'
    're^aO7G?3bn+OItNOwNb=b52b)fc9>YN3|1sK#c`(m1(Ry|l4(PwItecmGhoBKc@w*^@ibr1E8uE`Zh@f!axzot!|7^@@EOGl)f8'
    '82I^Z8q9h8;Dj^zcqHJO^MMGC$wotSKHVbj5zJBft<=>|Z4VRw_MED*XfJt(He|JUA94PjmN1SwX6V(i{UGHguvOwf)Pz*TR+Ycx'
    '1}KZg7bqqKbDZaaDKE{3owVmh2*4sAyej_&5ar_W3yB7NkdI=MX0^ysj!m-wT_B^RXt4_CQ{u`Qv{ZaJ2I7S8upG&r9wX5!3T{;K'
    'J@LN8WIoFNGbA&Xu0F2S9Rw8wQoH(FdSg;olSOR;wMGTsx5FLmftm_a?m#%m0_|YF5Sz%VhWKd$MbdvghCLck-URNCvPzl*#JQ;e'
    '&89B)+NpB6l6&gXo2Y#<CJO9~+HUEh_L=yjzF}a#@oNmC9JCHEt~kokSx*Hu5Bhrm6hm=PYi8G+VmhY&)V`t|oEvXM|MCW*1%muI'
    '%#R4U>u4zZ?|{_KOHAZ$dqw-R>TXkvi5pnrI^CIBC;h?td@&~ht`kJ}3r<RUchGxJDt74EC{~(9YGbxN@zTmgqtC6<YX$@u)7wdE'
    '^icJKTHptfLaka-SaZ)e9wj_*hKSimr!-S}e95MYv}vV!929Mqm}7-90agwNrs~I8=$oPxD!v!_HpiN_pBmVX3&u4KSFW-}yZ;5?'
    'x&YV(0Yw9oQ8C?-&sU|f7*1L<JrDeC%(ib|86j^D5%h|}`4WSr95rEpk49eZ`zoD9jpjNTSIHo>+f*kF5nyXatmfnFk6k?UILuWq'
    'wYq(mps&PvG7e_{P@_3D!|;Et0o{&P$WdhvQMzET6vgWip1DZJ7qc205CJ9KO>2QphNmIVsJ$*Rfr2WFk+2R9mpb*lV)tpab=Fxx'
    'P=xx)#Q6*VLynMw9FPCYaZ_CBnX{pF&s*5~#`QZjnIaP+g+x;44h!G&z-P{!`RUFHtu0km&;XyrH~7Z35hiKEq&oeQ)v98@KR!r`'
    '7@0ozuUj(%5RB~{=S!Cxl};M2A=|?9pkZO?saNtLH`X&e0tl6qSm@*)OXFgl=_0l(glwLBl}SVNM_eP*pM|s59>$YGLpZn1MI|r0'
    'Qj#*cZJA{d`Lco%=Hx<{R_#xNTk}ORD~c(xggmMqy4~ygcQEA?b16`o@vqFc{EwUj9tHUVt;~~-=d(Tym;_f=MQ?GC-f?ty(MqUJ'
    'U@Wl*3Zvj}-Y{&RgWoCST8`J6zmqQS<EIJtUM0gZ7S)8;+dc&2GWF`Qm2csd{mkP6Py0TT!9J7X+?bm`n3-20Nov?rg^<M21any{'
    'w6y<A`#%%aITLNRQ8w()U_9mYlhlBo=LI4$wsl;0)q@IRumhLs;>5dkFu3L~Oz4?VfKos`bK>Ezh{k^CT_DxhBFRuoIBY~=nwKN}'
    '{_=+T_436h&iX>XX5F=O(g+8V#;zC6mYL@u{ya0z3}I3u6(P$Fj=n7&LBx=g5Lpi)iDJj*6PM@)cflTN=Kev!-V)Qbp+yS&47i|Z'
    'ij?47$m*R531>YD24MH^w~;{rj?NvguYp3gNsOaNpsl6vs7l@5O&vv5LsqYo51o*SYC5;&sN$roErOcGo>h|=fN{AiWxKFTy{X?{'
    '4M^sCvfapM!SH@DDoT-c_@o$j4e>4w$;_;-At_gxqOBD_OOe9d3OggDBFNeS%+^M7S;b8K+e%K3<&#G_HaE@<?quujC8~wSUF?Rm'
    'iLigZ7mol&+Lh-MZa;Usz~wcy_o2u;4yFvRb(k<<xbejJ&6$7v!D0Qo;&}H|kO&T$j|x-)I3{2Wei#cWP-Y8^V;s3xc8g3GUT<bP'
    'k$Hh8`Esq%npTQ<3JP2PEBRO~(a0@;@k?`fZL+wQHoE~snhiKgBVHcR26Du~D(OQNtoF%dogKHz&lLQ!0WV+CIG1a`t_S|mza^Dx'
    'L1ZNEgv0m=Ae<MuJsJ~Br0ErjqaJA_BvI^`M7e+G91fTlVI515MTEaW0mcxXh;r38X*!VhBe2Hghu_UJKo<8ebkr|;<6g_hr2>bx'
    'sz=$%Mj&gs=-Gb%-tpdW<Coz+<~Hfa<bK%d@8b~CV@K^ma6xtFA$9<Ucesz;3V|vR47L1H97Zg7!rDls$^$=o&hFe1`;g%bmVzv?'
    '*8CV883vb%K*M_!2tId49bGHt(`~X0MD1|Jq>bmiUwNQNG#C6L(+t%fagq!ZjVWC<!FIePDid!$zB1LXxl16THS@#wann5S7lDL5'
    '!mYopm$|;IDAos1nKGinLN`fT>tD{jeQ)l}L$gX<90Hq)rbRO|u3`0~jF8<o@uiBFDNliq6g!1|voJKckL8ih-=J;nvOb4tshM5?'
    'MwoY)kRQj_NW(7Lz=)eKP~Q4);>S%qh+-0m-^%ai`@h3iK<EOwf|vaaFu^s){4)?x*A}VAi%6N>-Z9#gf*fr7&sBvBFJ^XLY));n'
    'tw8ahBf3q7`<Q8|{0P-_PN+-2FFVR`EMq*=`c8;Nw8aEIHIdC2VOr~mXV^oV&9u;r{F@q?Z6qPNMk#n<o`?P(e3BlVH*LFNBSBP9'
    'g`hN>jYEC9)17*nd;%O8i@}Kzdi0q7{AFV6XIYsp8{{iWcRa)&;nObpxr@MP^I?|U*#8Pj$jw{iH(JV%lFgzU@$3N+IGi*f`n=3Z'
    'Q^ZRqMJ{3vOKv9USI;tCPRF?7ARH_3p|0Di{eZZg3tb{xQ3U`DzFU3X$Ij8<8M!x!xiTn>aN>58?evh)@n3jX3^Pr_tIO-I>f#Vp'
    'ERK>V`Ha|LEO7@%$m-nW()uS+qIg9Ya@iQiln??N2w4=J<GCF1B_DsF%i7-m0;Gy-%I1hhsV4$@^Qo$PRO|{$$LaWK^7~YCm)y$N'
    'npk*2dpj@Sn?>Z7hrnTMA!}#o!$YZ%8&Aj9`g@Cgq<92?DW#>c>v#>~P5S<KmX$H~d`=)H<Sc|BJMRVtd$xY%Rx7rzeD;`W<Yx>}'
    'M88d%t5u*MmtXAx!kw8uyvCM>zc7$^<&Q6&7D2AT@cNANuiX04U1CJaUw#(-^35PP5C=NV@BJzE%~2&yoFDz85iiu5Gw-CN(EyS('
    'P@9zeYfuhU1cL;76T>(-u)cIp;%OLYvsB4JS(FUk3}OP+CG<Z;FIU4_(cGI75StzF3Q*sB*J$6Lps|~V8eiNFgc-(Gs4XG%>2N7;'
    '!9d8kL~`s=RvTV>#Zz}<RGiPIEvUdda7G!aAV?$Cb|0vQoJ8Sz2Jy;FE?+RuyF)$6{8YdLt1lr_lJ!Svw7+^A6Sn?0=VCUT5RZe8'
    '#s#QrO%gnHj|%=TAH+(55<<L$D2gZ7OE8hC`Y^u~vqi*#=)dz3b;;^7r&$k)1`j1mUE)iF{WwnNGn`W%B8(7Z<Cm)x3Gx)@mh5(V'
    '%_K<EY;FzH-9cp*L7Ib7sVO)<Hs4k|G=i55qY50#0Uc8I+lYxxv_E#Y2ovxijPL2#k>lVm3#O&nUm#T5`hlg@YoaNC;B>4&f*vV+'
    '8Jq1pmv{bTUVcmVG$5Oy_W0bCF@+Kx0-eBB$D{shYGHc?d8TRhe%ytyewqxaSBg2DLg)4_Zr#s#Az~n&X{6+)QOj$K>16Nbqw@(6'
    'Dz?YBqZr-&-NXU111P}c7%w?KnSs4!U}uB+px><pgYV*eH*K|WKla9REnSO{nM-i>?iB`paf~mooHBwZ0pRZLi&F=^u<OIcnV$;6'
    'T>yx^j1S>`3f)&!kAOjvjP1pC``Zh17bp_z%vs?7ix*TZllMAvUwiiSiPT@GL@7=zr}zh==@<_Gk=KfH<GRDG7t<MsqT8Z)t;N`V'
    'mWY`W*o<3nq<hsTe+ih4jbYPi7|aT#$ZT;gO=E<pP(mf?yenjacm4H-V}^H2WnOh9Z@DEL8@P7MtdxZc-X@u9ZLX5T2}n^P?c~W)'
    'cib2AR)AIyV>-N6UgZPLnlbC^Y78m?Gl%xeor7;$#?wH3KwY3+r*hT)YEw*$xn&LSzVMm|HOSelE!eQ|nB#Hxu}uv?G5kFQ(=Hy}'
    'Ik*xikLyFCEL?CeLS@DwXbk!BRX26DHGs}fvM0NgU)!8d=xYJJdF71%IP+DK8!WeiE}(@gy?)kHkw0JhTy%relcoch6l(x8i5kvv'
    '{ymL^;W?kcQhT~`gHI%j)`z>VV{b}k*#Kv8zhAXAB-Tw?AOBLNY;rRFm|3B)Ghu7Jr*g!8UhbB9VmleuB`;9|Dn*DbNSn<wL_bW;'
    'h`r;}{qBI->Q%fGOhtCw6*|flv>agglB}}Q@XEhM8Hatr5wFp;9Z@>_+w0dU{jAa1qaYysxF4c9WdyXJ$08h_Wutk%5vPRex+!1`'
    'A=4Q-h4OTL*)So&MjF{UJ~N#{>r&$walOn7tjbW38PX>fW#}nCRE`>ke^Si_RwjP=f?{3QQm?@ZtRAp|^?5uzBro+nozQZ-Fl$ND'
    '^I0m7n5Illzp{l^Z9Hv(5GE-+@YQ7*mjPmIOrD_uJbL33gb$JKc7C67J3MOI20r5JXgpDV6F@w`4SYBz%k7Sf`iI$CZ^sJ<v>ZdD'
    ')vgxUtHK&8DJRIa0LZd-QiQkjI5`lMQWX-vRegUIs{`x>x=a>hZ82`p%%1@6{srkaFqBFaLszly0HJ1$v6>Ov4u))FOiS1`%Qm8v'
    '*dtP0eQ_&u2P82F)dfm}<$4$^6BBIk)USN#45X|b#Xgr+oMk?}$cIJ}k*qW6Qf&Ns(xqZOh54*V3vwhcbP6fqIjs(oaFjeJuq_uQ'
    't~3D#9-IGAWpeQHQ?&v)u>?REG$nCAQqlQ*SxPZdmCmvB)=k+{a=6iIi~~>T(LT}HmO(&Sz*3q~L7QO=t+TJ%vKvq1Zb3=w{rtd6'
    'oqB9d(h+A&;ZB2(3Xy+f&&#zKZz!j~)kO9p*z1K=ntNz&Z&<Vo?YugM?gT$CABP|Sfp&PcWsn{WR<|e>nYCmq`+PVz^BsR@#?`lh'
    '&BDRfa9T9Urx`sQpQ3M`5|&7~<nlg!N-lw=TJ<Ug+|X1K+--Azm*&7~&4G9l#!XY5&{L_ZB9re`+k$bZ=&cLrXV>MEt05hkXw**J'
    'K?4v4jBEWw{B7nK9VM_gTx9^pK6QF2OG5|o)@mEwqO;&{Jt%$c=4&1NuqC#Tl!_w4IhKuj1?K?zYICs+PcsA%T9mv0=Qw{S3ow^p'
    'Gq=8kKIe^}b)<Zkk|iXy89!OyN~OzE$L-eo{scJM2vB4W{X9=39e40Is9s=kwB_m%_Rg&9EAHVAJ7YWs-%hj0i+i7#;Vj40#@pQ%'
    '_qfqBjtT1|T#G-~1Kd9$^tL{%-r?u4v3SzaWogR@(lhH}IhD0j26~Dleo%Pq!g^3XYEW8k)H%Sgloy~v9s@!u_|7!!oWYMFD<>}9'
    'Y~kBs58;>RrDI>+rDX(5kdbnh58=pY4xXT=y4_&TQ)a3U7B?`N!;6hNjj0bNp^@Y}iwTt9@|^`*=n)@HTna)p>jn5MgZ?o4H`E?M'
    'E!4x~BmNw|W%TjVR*^wrtkm|6Mv&t#gp{DV;5{r*gf=P^MNVZLgW^bPQ95=Iyn<>$385v~#GsI+wwYR^ux-^nqP7p&3MtX-q2?NS'
    '@?~Q2L=Gk(vf`TzFSXcABf>y6<eq!hgs|%XQrdIRPn!2U&~IQMv-^S$GcvYbop#qLk?r01$)OD<L;#ZGt?hWqSO6%(rI{o9QiZb?'
    '!%&wmJcIV#N%CDtb0Huh3Q>Pt+QS;UmI|U2eZRb)X*LXx)_sj1fG}Xt%1d(sph{*vb@m#1NJ&)q8{&iNV!*n<&Z`7blC+jHcF}$c'
    'sO;o$h-UK>PrNUyb%ay~j#gSWp2?JVjBh3DhkpQ#(+P{;Erz6ZY2}Z<zbboJ;)4;mJ?i?l@fM?duTA1o+93GZ_MgKOBNoAEg;$Nr'
    '-Os;*4$%fuWqirEg%P^0NXm`)H<>DPS&vlpeM3z$gycO5h+su^EP}^YvE(bazPG_UyK=21r9veoKgT2_a`i8M1tM-p5Bl>e1e}1i'
    'g`c{O3ZSIng%@hjGgLA|No>=EE}Fgg0K=?2lGK6tb$WaePW69hG8JDg>uLc2vtUZZQ9f@t7h0iGn|t3kK;)pJ3d5O$TJ%a=7&u$?'
    'Gj@p1U#2&^Alu}^BU>W3@=mv)i>OOU#O5px4^k<0DsuyGgM@NI{&CG<Xbm9V-sdZVA9i5(;8|+tfx=N*!txAJQHeKyg4OhjXD&p0'
    'Wk_aN>I(FhumQi=mN)j^AK+4^oHG{FHCyPF67on16K<aYvYJQ2mqrA*t!^tKlIF}t->X7)CKmWtgL`kf#FA{lyn3HFpHo`D-b^ff'
    '?1__5B|#xZ&eD$2=S}S8cn5-FY$Fnw;q<;gl?`6gyDr14V_d3qz<Ir!VZ^jM2Lu}x=_~wU(TM$wV*(&4uauX_aKSdK1G5bpG>=iC'
    'dD11GAO)V_UD!f^tQHP&MR8cbshJ-&FAJl5MDsyYR&Ea<ly5{+?@q^s`gtPp+lo|!c@Ge2%FFNcVdz1hU1ttt;xUYmuHN5Lf!m1U'
    'Yl)-I7{2hYc{Q6TQD5SL1~o>OSL1DzP*X@mr=%Xa3cNfgmlmOxTVFL8RpFzdR|sw(mNXGo53^=FR$&kO<a~09IKQt2{th{XA)o-D'
    'hOz(u;!V-ejIu86x6&#+-K9NwR56N8Gey3MdwL0MI+O<zg+WKL9STcbM%;A(U{d`hO|WFTYnP!t8S{4LG;i=MrNBm0aRiCa&AhOy'
    'PFQW@!tt4wpsorwNU5Ad_;r56QP7ARO>65rnzAzi@y?WoC-x!jmrD1PC4Vy9PMW{O#HBxQqV6XFVO2EAENlx$?-n9{+`WXENbDh4'
    'Uz!R~91Qx*{ujpx5Cw$;G?46_J@f{=0GL=EEj<oucE4>EttS;S46T&`UBehV7}tVwj}z7B0h#HfA#}QBt*<o_eA-G&F!4pNWPr`q'
    'w&EHjXps|325+7v!G}%UD(NtvLo3bNH+`IgZ7BO~H>9`*%vAP!JT0@9FAkGLWs8n!*2^r8-V@)oQdi5I+#?{IJy$PIQa@B&kWzyk'
    'z#6KCh&~>Xk+Z4~;5@;KwHIvX(}J28E79q4pY8wQY9n2zY+a-}l`K$>d<1Xlj%722Hjuh!OYWQM0uo5Y0#*xQH`N+Syf!flw(p?*'
    'kGgegU}xT*DPmLVO=@I;R8B-p))8OE^J(rp;(w;ma2n%FUNfoibF~u4rDEymtk002$7b}{atsKg7@WCYkY$77Ln9MXwKG0dEq6pH'
    'ayv;>v#=oo7$<sbktC=~^mSDf$oA9P*Q>@wI4zbdr;opT=5Yhcn6m$fCrZbT$>039&yr+M(<XsqL!?nVsC$gOWzi8}G{gKIsdA27'
    'LSz+}mMo0AB&uG^d5fx~=2sn!H~c7UwzM#a9pO?un6Y{lA5#Y|Bzy;mU3bg;|Jc9YQ=%k#WiF6DO!q)adg1>mlM6CI<2#yiyVjE&'
    '2U)DkC2hZ=Y#941IkXl@rj_1KU73*LW5L_@Gt+>}G|lJrVYXx#K1cF4jjlN~P98`bvk;TTDPWsI@C?vkodpOH1Q;}AtU3y{Grcr6'
    '`|t;#N`uMF$ffFk>ws4l$Gh3kj<ol361mcN1JGmY(#!>(Hg>q_-7khmwX;GA^0*?&bGYrTNCZ{mc@5(QXb^&QoaP`iF8tL5QAIjq'
    'nZml>TgKS5qa~dO-!sC9lEHEx2A7#g3_Kts=WVM7ghj_-FkT5}lI>O08vb^o@6ZGh_`8v(pXv4|g?c{`UACl(t#cr4kTpwfrQkRd'
    'kyZOlAqoC(6p4ej>hetU;w+!~rMb$iyJT))r%DxDhCzeP`c_SBiJ)t8-kj3pE$79-Fa%@=sr7h>#Z;uY@E^k7HPD(DQ}JgkzH*$X'
    'WyD&cy+N*`a<Y@^g0|V2%9y=-HI>HvIm+O%ySHQAmt414-GKqyyufFexvmO*+ng`2yr9d50XUtV=EYtVN8jkG8PTY9r?V)#t!=I^'
    'O@15;r+DoKy}v6Hlug>U4x|}kWtloD$7HTpr3-S$CUSBP`D23Rrk`VZeB@Id5k~0y6!)WoDV)=^$fgBggOQ5y2ZZI8{kd}@;%ZHC'
    ')ROlXm~?fwa}(0JfQ_YE%fORLne@9}LgUyGnIyHHiLP9@wzI?fsWqA2rr0Ib%xXF#91XXL9fk!1{rQ;2SF(+0tF9~CM)55gBjZ!#'
    'eEYS?QH9#`cNOT8xbb{46W=*)Qp~Rx1R;=E!4I?B6fx~R&kT3W@bnz!7XLm$I?H-@;XJ*^%zo^K6JQ7&SpzsS0UIX<k$Jm(k)z~n'
    'M6bkjvqF)-s|k4Cpf{mj+1lFxo=OS`n0^>r-167h>oj^b)<N5gP|Oi#dMS#cWb@tQjYhxxg};9za~U$d_-}j_kO@P3kgv4RqsG%B'
    '%}bd7<#e44?yN!;_RN*}urQ>Sjo>y^bMh3d8t##B!`}A2lnsl%J4<|D_(1^vnW!X{mr9Sv9<!?gXq1IC=Z@p(wwhnmgq{Zvkuit2'
    'qwA+j8bcP)IfEO21K<R8Yfa-~5398!p?`1$D`e>B=n>u4dtkkgW-<O%uKu?c3lyLKlaS4Map)F~T=+wME{;w97rBdBn7ZdFkCeRU'
    '1@57=nL7n6)@kFysW7FT;-BF0AISxAMa@j`5X?+|GmzLZ<UinEtj0@KNBxC9Ok4-Mw@B23!&Z$zSSJiOaeiaJ!}em!DcIQ2XIkOr'
    '!?o?-ezl~G;F~)5C&f~?!kL0wbB&pXV~e0#`AQ@&7(pEpgLlfgmCq$Pzk!c`_YYRYa<}8lw&k0k3}-=S#yow5fVI=jDM)4*?pG91'
    'VkGMFO}xlPQbqR!qBVq{5pp}Q>hI|h;TbXx+_nyTb+FDEt#<$RfS;nr-^M87EaQ$zXf@5>>SwCUQ1C678?Fo@Om8<x!hlp|fge#a'
    '9w4NiX}kN1-51f!KN`pWg25~xmT}C3d^_o0u=MsDul5xzXBgHEjbN;jx7;RVg7LlX;8bRjy;!`GWX&t&Jf->=`5n$Mim!?^I%#VU'
    'A_br?zn!6PkE0OxuB@qBma4Ta3JiTWDvsRCOHin{(|~JVwvT_AtBS_ys^f0)=mkA{C5~Wv#lYQyt#ykfZd7FWv;b6mdllc57Yqvw'
    'QdLII1-J15YBa7JtWjv(N;7AnMdiLd4jTy9IV&dWO$fL0Coh#<QWRZJp7|0pl@KgeGzX2?QE4Kktj!wmbc>XCJQ5n+vQ*GOuEwuu'
    '&4LZ^LOwymInol@1|T{NDO`**Iu<D3i!NSbb*-PPjsAF5Tk3sX<ueHACw95)Ti&irsT75R6(~wwadT^sZQ)690{0TwU@}$3CQL60'
    '{Zy}jBq#}vWEWq6JrTO0^^#(@k5H3{&?=<NK9OYUIfhp_3u}p|aZ8V3X!`-3pOn7b{PB3jO8<rrKL4sVC&T`6y_Jpb%1eC9om=4('
    'uBJH8>xW9q)^f)bzrZj?YNwY$@C!HmsAI#1Is&-qVD#d5ZbU^W55ZXN#gr{S!0^wvIhY#2%NK_eE%(VWXT`8{CJy$vpT<#6a{X#M'
    'fV7nDqMu*ngT3H9rx#>u{c^y;rpmNmy^L`wqVg%>&K%YLCurCV$0H$oKW_}g0M$EqWGm#sFGruez-kuE2?&RDcIIP4Hh0_?H3DFO'
    'oFcD~*jdr~V^`Ybzd=R~kQJ(%>ZapR5|BskkR|;<4a~q#c~J`*B!qHhJ2?>&>wWaW?8yoQNqvq^6?b{kljEJKMCoTFFOa$C!hV+G'
    'pJzrPj%Vdk8?#@`)u_?CFtQ~!h;%qiUsn(a!30V}-jz_$MuLSP9fN~lW9FTXigEG})M_kNNf`v*HhCBbXvRZYx{qoO(5w&Ac^GJk'
    'MF8`)g|HJ8dF@xaxW7|HmwPu9;gv1Y8xW>rcmVWA!Q~~lq<zC%V{xt@hE7?dS~n0V@>Zq8HJx?HoDG_F8a{LbTjzhhk?cj+3>laR'
    '-qC>)MAD*HqPrtJj`mT;(&Q86^a;=|kThTX;A!F?bw$yCsaNNF%<cXUSy)?7jEAP|wmavXdReQ>NTC#SImdWT0%i1L|J(%qI%C|>'
    '6&X<{d{Rdx<in4Q?20%*e{;5!bIPx)o7|X}sjOtw`-FLoO&r=);JmlWW3SgsB@(OUmHnyhbI&nAYQ00{W*3?^@Ft+5T-iLtq!pIt'
    'ygCZ>uCJs~$WHIgD7{fxZ$$V8+!wR-=8q$P<Wod?k?Tn9K>X56K$DB`3O?hY=+yU?hZ*jZ2yB_cxTF^05yQmEJD{7HtKiKW;DWQn'
    'Z`3&gECmH$f}&6@<klL-sAh$a={C)LDit*h8Z*R+spe665}+#r%i3wJ;WP>4%}hP`xm=T6emCf01W~a^_mXTa7C-8E@pPEV(CebX'
    ';6Rqj!s+rD(KeC<dWMMD`gjDJC9!<6kY6y@2GTP#v~@tMr?FrgG^;NX9S?l8ApO5$DsKCl`J4fumgt3h1#uRs6OgTv8tH_qg{hqp'
    'f=chm@<(=TRA0`NNDGx5jNk&ITZ(OmGj$0QcOsj61*?TpK!D#Vzrt{_3F=Ss<e>w5^Bc$8ua#0amWkdLIP`=|g{8zAVFNLvzDfmt'
    '12iqu9xw8vM=@KXF}9TG>ohBxlj~Zqa*}B0Ild|CKq}x+yI=<^){!-Qq)VPQ#jR~x^ivsg^tcE1apop1q|JQ8-VMUN4j1^ool@Ns'
    'pcnZ7S8Wyx@Y-B-p%c<V@@gRaLDL<xTQHvKA9P11lGA_D+8M(q=rVa)R8i|5=R{gUd3nfLD3gsunuoq4H<#SZAlnHh1tUa@2Wm}b'
    '`{Zlew=+Lo$0utma%Wy{k0OXV2MiSGvXNLV2~Ij)a|<69XlT9}Mm9f|u*!`<6b%!rs26+7OZW7QdOw1_*c4Yh1lfz`>_EL0EHR=8'
    'B|{_(5v=xYF+8G5BzY&8M!HxhxumA`8hk;$QykSJWJ$txWXDQ6u|dGIM=4OUA`2ut$ya-1R&I{xj}6H|>AC9U<GVDsL8bG$p)Xg6'
    'a&K_P#>tw=*Gn?U+Igfnjfo}Sg~nDrEivtw*_`wr%Fz8+;;4zRM=0f<1t{!BkAJ3ET8*+YB;p7Cimt^_t9KdXE0{|2uD(QrKc^>n'
    '3t<NzeH{B#u=5{h*Q(Usrz|QLkW_&JSVK<-yOoT{-iK`)ByD2IMsst{G6+?#v~ASKcsDS%*~*p0NoW0=gqTo%gY}l&KY(j@l!k7i'
    'xQc7vTw%8<842udq=n4DDWDfYaSpD-I}DBQrc&rf^77OePuuiY*K&;767kI#Y%Q1P2g<UFcPIOHXWnsM-=mawpQ$P@NWSeW3se!~'
    'z@lILFdn`M8UlK9hbZaf9kas`w41}5>&0`ARJYlR_NVAR=P7x)k{O$UVsa#w!^wXK_~H5y-29-IKc$;f5u**hXM^pffF1ArGrqu}'
    'kIC^1@Gv7%A}ZOZS>ye5gZZp9AG})~++#w?Ubc+NXs;c&O?&pFrUeV1n3P>c_cP$19v?%jnHROx88;qk(zV}cBPQ1rDy&ugY*nqy'
    'Ie`{N9jM{l5%zgD4GX#j;OGZu)jiWz>c;%u^6f-Ied#l%p(-%8^{q;zQ~lDr;Ft7YYqI4~?@6fA@>T)OMaoB8WV#?Fadg+bW*2RY'
    '0oKGxT`|#7NN)EZxAB!HFKC9EtW)4XA~p=JsJYyMr2dX;vGTE_;Z68<u;>iH6}){l7%i593i>8ivcs~vfffr!C18(9<W{R32ly&I'
    '#M~#YlRbM*j>)U-y&D$S#~AXPY4r|aga1udAv#s%_g<>5#Jnpx8<~xPyN(oXq}=k3`S592QoK{*MvU~KxWJZhjT%++b5_AY(lnZo'
    ')><KF<=PA+q7wj16$JW3=@IK>XIk}7Vr@KwVDFwh1FD?fxg95TTu})=?WJ87VT}5L5+a7=VbX%d*MmCh0`PDJDWLcU?)PG@kjxtO'
    't19^DHQ66Nq#&-%nDH09c`SUuuLnN>P%`fjDy1i}U>52vS?W*eY!jZ8jo;8+_}xv}dsTrn3DOYoQ+|?UR%Yf{yy>1}AQCUEVGN$J'
    'ZeOkr>BCz{dWfOhg&~XSy;bX>rjVn|GH+RZn|W)nV)!$aUK3(XX00U|SJw&E@_xfHo^~oyikLcXo6$ZxCzNl}5iPii)h$kNx2Teh'
    'n9&k}WfqW^N9_`8j~MP%rKY4uFnCL(-SmjRWB(&TYktFS8j*GSF*jcn=sAaRA~;pq?+K2Zd7Y0%-cV0&X5PO08$27yimueB62Q^2'
    'c{poT@uimsgnXJ|Ak(2-G%xA$(F?)@Jsb{K#|w)LRl54di%fhF2>gbIp>h)RBgTB3>>d<Wjj{}L9&diqr?UY7mC2faYx6Zch&QVe'
    'kKSF%Sj*3!Bg3wih3BKtj8;bb1P4*jEhYOQo_2&yuCx#12T4w@iCi9;E$#q$<YH*7u25g+(*!S&vDK#$(rGSKw7<@_da=8l7mJzB'
    '4vJA2s_^q%$<IOUiJQJ}GeeDx97I!&rPeq-EuR3kHlnmM5|^Qr1(C__N(y1Q^a+<;&sb1}^~jq}_J`CrFq10qz=bp)H7HR%oXPDQ'
    'A%kaix8O;0I6;w>jArq_du-9f1hhvASv+Bqot~J}ALD>Z*7+&>il5RTR0@r{Rkvzp2SF|XQeKxlTCF}Co`8AVeIQwtt}<=r5azbW'
    'x0$^i0i{-#%)>Q^VC{ndnBo_q@y*J)ecyaSD+!^ad`ZT-%|+i~Mt1OABY##_se|GX=SE2~6V8GVme=s~m*q&RT4lEC-pLuzua+6B'
    'a31sL_5&`fn;cU#{S4lyEf)(znSq=rS>~fLsvIg5*>~}}z;2%KtkZ52sL-6<h^Z6>W0?xb^G0F#&$BHK3U?r%Gm1**v7%ihqG-z*'
    '+|33<M!RH6>ai^Gix`RA6jcA21BbF{3oe^^ePdps0;VLKfEi32LJfXU8AYZrUvzP~Tb%R?Z|8V%RchVwk<=TmsT6&iv-sNj`)f)R'
    'cJ<ydC;>P;NnFs<9lB7gw~v=1kVy!zP5C<`r!GTFZ3b|Qk$Mz6i|>tFp}D9AKZTu6EK0*zn7vL<rH+&qe8^e)qSSF;Ll{%fS*gZo'
    '9CT5Gwe5oQFNbkt_Rj*!mPIF2P7f}%^v(YwOvu=X)}40(f(ZUX!=|10rq`%XMz5ln8!k{3BcO`7^X-pn(?Z_rVLj9`XL3e6ta|i{'
    'np+kXr=*nzOlZfCeVT5coa}`x=b^z1rI?*jXq6P`N-bt@b5jc_u;-*Hgi9q^(Tx8GR>grr5(e=5tMB_*b|{KCJbkTChS?@9mL0St'
    'xf{`bOLY8ux*CvYH=Dzt-A<kGD@Pj2ZQnwFvCicdZ$Jnt$UO#0U5<5Ym8H`6BG`I`BVQ71mJL&5X|yiUd|Dw7yoNJ^G}TKmh*`!O'
    'pgA~Extc{M>(WUUF0tw+4PEHu-B(`aw@$Hsb1-P6aQ8KJvNWzW0aPK0Sq~PaMqAw>%VEboPmm&W;pnw^ATk}7I$mYj+3(zROO}jB'
    'qt-saVA4*Oe32$r`!h?y{ee@u_Svrv@kqtqN#qv0M!(=vV{^qmcdnmq>a-tj+ci?dZ&pV0k<9Nz`|P<$Yq}d6SjXQ@&c`tCPcEY0'
    'obD)VsJw_s)xlsJQ@XV-BIxnCo`Tt5Y}g<W=7}(w>@LRUK93-34b1zzaKr<9Zn1Bizpa>?Sk3)1hMFStB$Q7j+kzO+=Wi=KTAGs6'
    'Cj-;O>_t||`ewsD3hHRl;?|01k_Z4{>mILIF>uz4%Ij`MS`P7tW@>IK2aPi%<~i>iWgmaq2v5`zKVTk#W2wP$ul~@23lzc8%VMm2'
    'bD}_-b9kX>ECF|zLKS32ZsOyU$#3X;S*Em|dY85uJ5}j3%|=8PFO;bt^I!@5Ey3TGA?bs{Rz+BtJQ)CPqFAfa<C*dX4#Xm1B)p)b'
    'nd#Snttr0a$;wsAoTDP6*4)Ry2X5=4|31(HG3md>%h(6IU;GEHN#11~DQ=r7E+HMT5L0`9_1dy}o90spHIn*@Fb%B6f9<6X%uj}l'
    'Ko*<MM`1L?Phm*I!AKAgn*{&BK_^rWu}nVi*T?qA>b)+&ecsI&H*+;%Fm2i9>a_^Zz@tmcVcIMVnfL8pr*QTbt>4bFk!hrP>DR?O'
    't%@`-e`vq+SBE{A>Ga*(BmNDU#>AR#k@3ELFn6e8^6bRPDmf?|8iLz3&4Fe@8o+!)@BVeBE9(9@*Q<t^N~~azfqLwdUJ)?4$DuIY'
    '8!Y5ayy5f$h0%~+a~=7I+DX04bN(-kw^|p>Ke9VulhO-pta)2&m*3#zJA9jMv&h}wPqQhE*=R$jXwB;tPy$%c(t5+xfW5lc4%1y%'
    'Q+Tg{L&6rN)mvaMzhAXJ&tXsq0&ndw;10XFXy2r*K(vVw_e{hb?d8x1yd7Z*IuQWMttc_<6ORBg<<Z<rN}^5LS%zE`q9FwaP0S9N'
    '`Hq>$wbu_0Q}sw_yj`350E4#2j87dqfEhxL%!OLmr<0CEHA#qWaPkp2#P0BVt#c{*Z|x=-sON||pwyP$>{qXB<674T@g0l+Mc725'
    'cz5VsP#lpQaWgTf3=q0qF_3opo14a`OX2{V{BQ;i$ptWUV)p!4#SUaL|HzD4*B^w*v*b|KiZ7#{%kD$~eA&D!+r^Z26H@rc^3JN9'
    'S#cKTI3wEU5GV)lwA?-yn?S$t0SwV{ap&K(wLG~CqgB1AD*$O}_m8C@mtIpWeL~32g|zV{L;B`<o#6&%7Z+KHau&`{uu>J;X*(o-'
    'w4)~cNEbP78(ZotewjG~P@}$-26#Nb2Cf{XFQGqs{%|-zmXKSmH2qYJfnC^aCKw5v9y6P%x#LFOH##JlRpr)AAfmpW*csp>D1Dl{'
    'nMYr<3^{D7n)N1~=DYPFAEEAX)Y^(YdEQCi1{oj`J)$B%*5D4#W5}ZyG6Yo;@sp8Qa@%yOMXR)j5c-8|do^ef>p**Vme#`w1uHYo'
    'R%Z|EG?7%rM)_qoNrx$@`-EJ_b&7P!#Z0p4YKR0MYTTZRvt<u6aJK~MvBH{qV^b8qeOC(<GYF;F1`q!ml;QAp13M1lRfrupb%#v4'
    'IxxL_Vz*_>Qe`AZtQ;Kc&()76EwP3<ga;v>K5I9*ofO}(uKpn|39+6DG4OYf<~3pu66-S2*x@(A!abwRo7aZ!`WMdq1$#G%Ow%Pg'
    'wdboF$HnL1i-<RpV9~(P>ud)wgB2$yd~e#OFpRkjDU}MQqX(GkOK@g1*-gCF=84#M7A`%$Ve#;L!O8AGA)FxTUYr26m5!T_XYh2Y'
    'f{Fkf>tLiOuFj4F_Y5_L=~av+Faqo3%i)+y=3uN^s49TOK(I(9r|n*?9`&cjgRT-xV!97Fxem*hZaWJ6r<jdgjD`{8!^J>|BEGI{'
    'WBxs;th;@B4rB1PGhp1QXJAS_KO)ZrS=iHbog!xTO0uBwdGhDoRLF{Rc>rU9*FvbfFGW^Fp-1@nJq6>WyKD;zNUv#61&dglj?J+o'
    'V0CBbF!ve4TKhA3GfhmskhT8gI^heaFydOGpr%joD~$6}3=J-n-7_Mn&uyv7&igU1@){a-t6lZ{sop5~3Dh5Aop3gHxJ227f|rPP'
    '^Rcq?3IoGrcHjg$K4GZ!&@V<1ccb_zj<&P7h-UR6jPQ!i+>b~|a@2o)LCmL0^E}r`WW12lzgL6YojB)>(a7`%7P}#Y#ioS0@|6mi'
    'Vtj(^9?m^+o=%Bn3t|iofz8>s^c%!wWmnlnCF8(m4Q{%iPe67=<xYt9s`~x_VsVYy>qUY!dV_A&eVciKGPIqCn}awd1viPoStM_-'
    'MrwHgon^8z_cP5yOG)s4yC4=Y0wADsJbM;~(>!r`<4b;(loA-WMb~_n8UG@)9vAtk3Sw)3V-z~xG|Ec=+)nZ>;J!$|L4+wU8!4q|'
    '%IC%@tqyJl;T6imPdh*I22J__W(^uRSvK!@sJvyCw?qMKDR7IKJM!E`VS6CG@rM`h{HTB&pS7t1C;0*v?h>OtLdW(4Z!azJr=AaU'
    'if<(3LG<T{)*EL02G#iX(`YW45{3h_u*@YVvs#)p7a-CjnRXLUNWAk(_unwU!Z;7VDiz528XckQtuXMRm3#l?3@-N4Fmb|WVxHb0'
    'X|7oG!!Ev`MLP%-lew25rB{fs2V2Wga6FiG?JV7S?a99`ObvZ7p!Pk=(Z9k(R4pGI+m^xHCA()+!9kQ_^DA|AbofEQuNhVvBf+>z'
    '0_#l-q`7di9L_kN2NjXr7wqBAcjFWdu&rQAr)a7t(!V^6p2O1Fzu321B^XwOZ$}=wrL=i{=h~w&-wyOptEIiRf-XJys8V~`<W;b0'
    'k|QOJ3}O9%PEuhIli>ZT6qQz8y;VF|zh#IpWOCfvj-4#draQj3xt97Lv$liIStX6g+kjZYY4%i86vN7TU!9?|L2CxP6U*g!yE4Yd'
    '<)^mpVaKKCQ#=)4EHydEAiHsPtH9!>n&@*Rs<&1+C?F&tB`5RolYjkA7Udc;w3L6smJQbd|FiT8hQCdF=DP}&$k(}+6Q%M*?l<_@'
    '_u+dXj|Mdau=X1n(;rBMi86}<_x`AOHX1rv=|6{02XjT3k=bT2cPMMb;jfttM|xA>QQ&GXUE}qp!DrKl<cU@DY8lej$Q(o`$-zq6'
    'R<6%j0r^C&+o?coQk){ubP5OV%&NBCTRZ>SR8BFgH0wMGkZ2i3&Y<n-K>uzG0&;e2Ni#I~zsrM$4Mr4>nVaFf$-SWg=`!;S^g}7~'
    'gCY}J&um&RHuF*Z{@LQJYUCSL=<$XKvoEl^Zpim$BU;cTV)QvOhJTriHM?*@QfwZbN3B0)PzCk59acPAn%}z=lOU!1ie0rQO);NL'
    'jBD^$DlqdCIC)wI4tvGqCdimw$7g>(tj)}uR&nTU8tfVAFOa5z5z+5&qUL2WbF5TxuKZOGHy4=kLNE*0KNwYWAQB=+u-YMFzO0=Y'
    'ny?4}&&7(asE8}cAGJo=6lFtR>Y{V|T{(hc#j>tp7+FpyClnXXrHrjxGK2Q;wai}J;3W=qu}Ii-*8j`3kmWlul5}h!NL00kPA9ml'
    'wV^@^u6=KQZH4vqIBsvHqtuMzA_xxQO+4ttEl{m12(Uf4)LiLUXQ#=2l^cUyxKR-XElbIRP$tkHH<bzoV}KOTLhGAIWj~~O01U8{'
    'wlG%V<mRBo@dJY8_d)%UX^OXMdx<-siGLvd`l5O>fRixLNTNCBelyw+4BC<5Q~vkcK(!$ioEdu|Ys+1}$t|#MF~ILfAhqrMrB5~T'
    'u^W@iP$Em26wQ)1!rE2i&5ZI4?`NAsfbLh^ME%JQn|zLCLiv?1iD*vZe&q8jSoQ!wIUnlwgqsu)AI_OAg%g_oKUD*3dy#sJ3LL{>'
    'VI=>?^xS*gE5I$r)wgG4bpaqArCGFs%925k{Z7u@QmT1VMFZFajra}=W~!K_!q6P;Y<8ynEW!`<C)l#~9KGUW_WPjs%I&0LQqp2o'
    '#p3S2_SfyEPRZv|a1_{vNkIn&^BuJLLZ9AVKa}qoz#&^-0UKt|`^#62U|YM9*>2(Wn2Fcx%bF%m!O<KId@+i_5$x4(QVXidfCZf#'
    'U=#(7;}jOH>yuDRcp%G*FNZ}EDaOFdV)`3ie!L~9MeQb$bn4T6h2i5LSDD>Er$i*-ud0r=9e!qPjZ8^*FC#VFNBL`T=Iw3PRLD7i'
    'b{xf92M)P!_^j%wZ#39q9ncsa&PN34w~#7Lp@URyUyEx$pBj(%HojdW*YV00|3Cn^hCQ9%k$RWyvd9xMkqN{hLTo}5H$E6MIYy}e'
    'BEDd9AZCIRpPx*PsxObH{SM-8nHe2)Lv0h!Vp41_*EZZ`pxMq?6Pu7bB)i%oBjspuB!A`^D#U3EybnUShx?LeiNp?`2xG@5&*0?f'
    '$+g;w&2^_-%Gm^FQSg;uCC1Ag<t>)X1Gpqb6u=+TO`(0;hN`2=!3`e`^-bm2W4@9~IIW-de!Yiy1dwVoQ(nfmI=BfZ+{t7s!F0*b'
    'L}&F@LB(<_w%uNOi8A{i&zr)ZTPw1}%m(}ImqKgqfBa%&ZCLW~JuPMY{o6|OrkhKbMZNt$mO6peu?MO%`?!EktDZ=%fap>Z=D0w5'
    '@F?Ld8Xa?JKXvHcC0IDq%u7|pp^7c*U+a|o(@#ZW4v^In)_yx}ty+RJ_^8gN9Zj&6;5-}Q#gu&e<acAGDo8z_P7sZ9J4i3O-G|{G'
    'pGYvAS52sTfxSajeoTuFZLsKfqdSUh<@c+ZWuWwS-?Vq5ItMhu`mUYIifD$Sz7iR=ztCh^o&0n0)R}9EDY^7HSG?N(EFT-Zj(CQ7'
    'YA<IQZm41-q~_1AJgDH2H)2=#8>WTkXCrK&#C`xN4qNmuM_f9uNUi3l?Y&`2%Y<uBs=>BqujO>GuP2%>o^n-ShwCX4k<4HOMz1H1'
    'O5C%OYevCr)pO)rWPAauFP7%XNuy{6OLoL7BQAX%L@kZ0ne`AVcB8}LTQPs0E(m3d)X_;qO#U;q+K60;iItEEf1T=J(q#_dUdv!q'
    'Rc}^#;a`@;hh$Y(&DdCl3?cgh>1MrE`#JfN;A75$$RHX+67uI&if3rP_j#eLoCyBC;?@$>gxj337xd0~-I*VP44Wv#LWQ9%{ufIO'
    'TSkb}AK|`cK>-<Vqv-8Ow{dp^1w^?sXA+yOZZhtTz1~U*wRNGV#ow&t{c)vc_3W={jKiR9QQq!S4yv?+@m=RwWBt0Oe_V3BQzul('
    '8GQMa9$|sRm}Kg}naFEX0@Zh#hke-+c-vyEEyDG+q4Qwh`2KF|8E+ODXAQr-CT1l#+4}=K44isJk|k`_3dHq_N}K}iCYjkj<!NlL'
    '#`kG8Rvgp=P-Os7s-;6+lf;B(R#3Z>IBicCdgU`b``kGOP&=+A*UxXQ;nbZ?g;iWDebvuadcq~vX2=7z1Gr+M{VT-veLsr6tAW|t'
    'bz*889vRV)_N|3mN>MfMSgt3e&f-POCFtx1|90^ENu>U41eLiF+uF{mHG`$>uBozAPd|AY*hDiFk^0|cC`WrHmB8g(dUer3I-z)a'
    '-nr$|L0F12kK<XoOsbz+@$^$A>%IVDyJ9pjG$!NK+jBovea6=QzzuJV-&|1jS>R7@6d!WR@6!^z<W@>sMaTVP&D(EHx(}qLrSphd'
    'zvVu_o~HRQ6i?piCNUEEe5O6@HOiR0!jhVXWiVQ0M>|n*B}srZX%wDi<{c6Na3ex89FBgoG-}$U;oAT+oAoS}R!eAgu*!ciiVyi8'
    'jSBh>E;R?HJ(F!}^Yjow7D27oJVJWDdkULF6MPQ^DJ6s;3^8^uuH(@ELfUY&A^nZ219GnXL7D8+mcPhel+LVcuL9#~dd0Ap#1cmT'
    '&sy6)AKkt}7{zFgq;i7~3K?c7WZVLsV6yaWRZCRFwsc9P?MD?4dv$a*`enp_IJ=h*OrLyOXUucTgx_owJ!wshpz+4mPX$#37aw8g'
    'D>(-N7XbpK@O8yUp)?9p8?0jkGd41q3U9Ka8Vf74-J^%0dL+OKU<GEh!tcCm{#FAMc8Q=Y+qK1~g}CU3kM5zCNQ15`T;9Yfpn-R)'
    '=x6lXJns@yd;-9deh`rywi_L+@CU6Tlm;kREgj(C6CMPss(fiLBq4~)&Vz_)4yyd;NkqZSKKef}5JWZ{)r4DZ487PDog<JYv~HQ{'
    'Q^fdh_Gt)nZY4L0F%>cl3hcFR#OxJun{&<Z84-P_ra$RXm1B_=kW*RD)S)j)R>Iu^?2{|~vj^WcZ?8z^6xJ<eAOpJ;=}0ILBzb*}'
    '))ULeITqHGOC+6f)Ou&Pyl+f(54=tY$8%|otPbsy>wuWGyRz%*hA{?D|4e7L=oil_RTBnTTC)3!*WCuy@wkeytmT}eTYB%=?{Y@a'
    '3~=c;<1B1{8PU0=Y&4p~?*~0*g9PeGmB91>`#(*uYC%K{nECe4dQKrNSb^-a*?H+$K73X%-^gI~JgJWmtg$&Sv&42Jv`f#Lke;1o'
    'D-{He_5}+=Q3`jw^LVuRr~;JrvRbxrD%@=;@Pad)nSQh*dzya~C)n#P-k>_knS*p>>WHT>8Zjj9P6+V$l=X6*aaFqbr=qvnJ%;*~'
    'O{L24m2v)qE=)7$gO`Q6MO1qYjvVJ%sK=$Sy*IFQ&OK++FyU~aY<|GQ{$5H&DL%;9IB(`09&=Ky&xhaB+gw`YMAKr!p4?i@0v=ir'
    'klw;~y2>J$x+u?=SgP_fO~VOC`>^8bPRAZ?hq{_$Y}HX)c>PVXT-zW^s4dG7Sed6p080479S_6E&DeZbZ74k5RY_LJ+uc?>86|v*'
    '=Q3;KBfr)9T<N7{EJj&u*St9W?Odb<!NLMET+b)Hk2#v-O#^~-Gjm+4G-ud?9Wx@F(&6y1yRui*l+%ls)W?hmn2dc;u;}Hw8-RKg'
    'CW|a<3?a<nOLVbV9^%IbnMc`3Un-_roDd!LYVCE^kw|AFzptf1+;mO|<b;^AuqU_P3u+u$Y1tHyDkRcVjaA3FwrsMDVs&beg?ifc'
    'N^d!Z3~}lqYJQCI^EkW$X_8Q`Y~=i5nAm5Mj9?crfbB+5t(B)%4L!;92zn;O@ykiJ%*BGqTzynCm(hK&C;0Lu4|^>O1RN9DA1?FI'
    'wV+uhC&B6^#vj}5sDrCcv4U*D+gEl@)H6fCTS`#O;If6Q*OqTpE0Mhg#KyrS@uSB2f&qs3qQzrS>E=f1N8|RqK+VSyc^^}^?4(T3'
    'h`Lc1#&-)8Ca48aIXl~#)hLWZfuiK)Pxa-OG<T_85s;22dMH}o7sBRHad|a)#x+7TYJi%fIJ~NyYtzVvZUDuK3LOaE=EbAJbf3Xt'
    'cL1CxpvM^gSBm@J_mj9Sv`<=NPO?=>f|?V2QawjU?+B+Ddc-V-U~_yj+%**!pWpAB8xJIn-uH(nsme7Q?jxyd10!urquUaut)dlo'
    '68O*`3Ch}lF4?tD0d|70&Wd3$U-<LdtC;8jcUnB$sGP)@I}*aVfD7>-ydJ6MEc}Uo()Hx!pP}1V!d)U@J?mmF8%a)?Q^Ej50Ygty'
    'LrR~bup%()hF%~omlYazZhj(j{pX%`pv+)A|2#K*xtV832?e~770k6vz=Ej>=0_1A|4l2j?Sg7YXVhj_KVk0s=TRta8CAfrfF`rw'
    'a{CNPet+VV<ub3egL--7E^K8HrZYS&*<B$}>D*)5&MC@+Bgj8|zd#>i6xm&~%gI0{!0*V2c1D>+@=yOIQ8WQ1>XT5CI>3E%Etfkh'
    'i|+HQ*mZhJhG){H>|P8EU>`{zawcD-fD(L^F`P^&cH#hja8tO;gqE7tbu9l>#8@zg9m*-M{~FDfDD*jcc`2}0;AlLrMuVcF=@0if'
    '^Bff%hll>Q|GuXZS)-=FNHKwHv=F3>=S&^Tl5~e{_$~Ot(oer#;G=)7Tq%6H0&#Z3?H-;F-TQdCOs#XVz(NWKgjx^oE-l8F?lA#{'
    'GV>xrwHAb=>+C+j@6F1sS0<aC{<(fMoJ@r$DVw*r)-}x6hSjjjeHWa7Y+iCi)*_usT&Tva#oC8YkgB54#oost<Cz!JHUEv+uXmN<'
    'VRZ}$h!yZlE0tg{XV0b{eZAX|K<^`)R^>tVT%M_}g)aBP5Dv)@{F>Iu>3c<nG?X#|%A<EPUf_1K2{bef`PL$h2JxWPQ%GtFBzz$J'
    'J+Y&()rz+ybt84F+{w0|uBYL-4!S<E9G_l(WibOq5UNsx{6_eumg`R6d}zl+-VU;K-rdbJIvyk2Ggr;|N2XsnW%Hzo^btlRCSklR'
    '5)R%T?Oma6k{KuHa*|hTUDe!^Zk>vWj1t$C#1g+YYB#Yw^}QjdmSXj){%VLW<u30Yx!OE*21}>7(9ikjiUNZS|Cx!!>oY~k+vfrE'
    'LoidWJd?re=%Adc`77&9J!76VFSk~B?a%=4(megrSNnq@@O=p%5>QX`%jz8hS)W+FJk?B+yZ3wQF7<Jmt=|p9rRGDcHLGvJ;N6iB'
    'MfD(4#CN(hLeD3Y&}b)%KWonx;Fsy9%hlbCVJKM4+zhM4=Bpqphd|t3d>E#S`Cg?V)zB<I&V7e7ue=kO^cZ1zU;(^QIz@Q@m2zjA'
    'j=J*IPRx7@7B%{1VltLxCih$ExPnKu<3Sj)zD7SF2=Bd6amYIR0-aqqocB)<uLdp{iYheq=Kiz!JvyujUP9d97aO;(ARmwbfoHvJ'
    '<iQa(%M{z3<e1+In9ZoF*FU1PvA5${;S>qMk&V#i<&E;CuUnmHLGk~yD{rZa^xPG?LuguHGuThDDx36QzPp%(XyTqOd>{yp7Cl6t'
    'Yv2JZR|bO*PuD@)DYLlLjI1da>dVb1Im{dMWIR(hg!ym9uit7uIzooR=K(@9^7Zz&F>58B25sz$nu~ue@ql~C%ggiWc>v>wL_BoQ'
    'PK&jmDGK;e#WN`!B5qN)Ya3)%o`X`xxSAT1u#7vK65n!*+T>NSoJ7QNWUW;Gh}oSH+t%b&wk9>m3%I-eL~}n7sZq~q1&%T5X(`s_'
    '(>XjU<agME)e(2oiTqlNs9rF=Co%#9dNSyVd{?g3UEj%mI_fB@!OlpD$xAcBzT5{Ep-(1kQPym-D%2HWh?lDR9gb4<TxeBm?E-}d'
    '`Lufv<&RCW2P7nyXKVpES5n=D7(j@qa{5AQzbZtr5Cik>f-O})vij<>1oV^)3v5T71Ch?BeV;6PD~*D@ze;i?$?goUH8(qJ`-M;('
    'vD;kCDiD#TdM(deXHpCV>Mo5kvql%mD-qeYgNT^3_G#8t+!{c4GB7!>NGKs&C_yTWo3_OVC_%jziR@uVo<+DqPiUH#7#daPlD`WQ'
    '4+?y1v6p<a0dEK<u7U$5mVR-nDQ$T(f^(JYz$C!QIehowdxU~n3kEUZn&&<XQIX6c>D3<)B}jrbs2INN;QXcXu2F_+mksZ#5-ZzB'
    'y^g6&=OS5gC6{n4JVk${S5_iN6v>7iktx9;T}$Ib9@X2fRel@(YfU{$Yu~+{{+m?l-GN62&y^9dhxJN+`=@7-<el{dFIcP=b8JB)'
    'dJM@@=?lo!<k=dCJ-6No=a1geT)Roenn7l*qKwBSW3w~s<!fI9LNhMZ_HZ7!1J7v7QoklX=;<(%_Cd8&3v8#Lo^z6)1pg<P#w&vK'
    '4;U`{$NxkO{HSJ?6({|5;Z!E1o7R0OTl}@OZ!+-wkMaEHoaK5#)y2`?q|=po&|XtK@tW{N+{>cOLsTy}W6~grVF6u#A8^IrDQh>+'
    'I$Of=Zs;iRX~_lXrcZUAjF+(!5TwNgelf(U!}-k2XYL_aI3P`;N-)F`9BS*5pywv@^`gd<3q?~xxiTeM=r^<{ik5FyG?0I>;l{Ae'
    '#L$5`p0}uv;DKip>8{)O9x#2yX?@T=$fzz{4%a9$o}kHqC95^}_Q8rYWEJyE!%=`-kH@<;;fdY)JtJkBA51+%aa@f#f9TW1d4tY3'
    '12>A}hMa;FWYRPgGFI{W3Cx_}3{r_LU)NrHs&LnFIA{fG5|Nw4;&hWQO800#2+oE_eo@GoRh82w#Mox<1V^SJzFlT#CZ$1(8Py~0'
    'u>UvnK1pcmj#_U?;krzIJxhh8WRQd;c%RLQw_LixqTaDH6lE9xFXW&#x^?f*{&pmCKMX~Sp$|2ZCbdGR{V_{_ZT6_@Ai4pfgLAi;'
    'nU21Y>fjU*b$O2kqSC5|9#XxOt`B088`AY;=@Bgj@BIIt69rv_8)1lXWu^<lDrp;WzoPvOuk10I<q%mTzZrUIOdM-LwplLHsEEpR'
    'K`ha$1r{Jc(#9A9-H;xD#^2z42c@H)*(8<fNJKx|h}qTva;%>d73>VmCna_%Fa&Z`+`WIzOR{76dz6YT6a{B!JT#cbiBf*GSe+Gs'
    ')*U<f-ZbFtv%C|wrx_a}Q`jOcluc=xjBA?L7Qx;;jbg0bY;?2VXRVGpB>XGAth@q7egtD-5So0sR*Z{X*!WUi1pU+%OeZGQk9S#1'
    'bMba**{_a{2t;XY`5TzRu{8Fy5I~+%oRrR_;$oYnO0*aDM8*0l8Rj$ku6$Lo*rh5+n6}ZzDPWv3Dg_E)Q0Z90YV_Nv3BF88>s=RN'
    'p5S)^eSy=7W`JU%FlGE1Y=vxLJul_7x$Uue#^q$@M&{R#l3p>MVgucbNM$iG4e<_uvjc84l2|y{Yt+-kva|+q9o3M~SLFZT@ycQf'
    'Xy;L@4EYozZG4xTOc&W*Mp6*0sypNf%=R1b9-&qGn)QM;fWc9X+no4QP4qwviaYBOX34~2UN>QDoF=sy&>&)#wD%iiZ`#btT6xL*'
    '*zK>nhEEbTzqPBW-EarPz(rk|vN&!u8{VR3K&W|0g<dii<2AhoPoTwZbgWr+*xcbJl3-L5ZF0)wOPR*Z6n0;239Gri>d!&Dq<_zn'
    'qFlbn;b<)7%w1TjMQBtSQ#?-FX$)}#NS`@QLU9^=^gVMS&mFNnq(NoeRAx`bKq#CAAG~AV#S+{jCr$d_+ox58zoawLE>MrnqGW>('
    'DVA4RNg#^40)GXG0DKY@@gT9`7{psd(-IOqjJ(s7UxdETy!X9ltF4hhHMFmsXVU*>^%TW{_Q5MrY3m@TyL8nQ8YTJoYoSbnJhpy|'
    '2(Bpa)@=7w(eto+!!6F5yGA=wrtjrkxiabPpR9m(y^CZ>LX)c9^2mZ%7i19LlAXTLvRCekL}6{6_P0UkkOGA@o)O0*iN)QELNqU<'
    'Z4M~o>hT)LP(bb`)8_Fa5GlLK$Hx%_4j~)!N59vo$R2Fd%In_TJdEhICCp1~RW9o!8vxnW65*`MT?Ql=M0mrK{e>3VIV6?gu}+}s'
    '`__4+7)L9U9GFgBq~D=L&Js}sc$tby_<`8Q;7!G#i@XEK-c~p)GZ_{f)^2@o>K$g@R1)$&5?UNQj)nEppER=K+JD)*bdAK)+9Hfw'
    '79}wm@N6SR+I3G#%n|Wnt66hu<U~rAXvXGWBO@tUxDkutP@Ap#HG;l0qCe8|k(p-dJ1vs#m>4HoXLlWz^mi`1n9^-}b#7Ldi|Gz~'
    '`zfP;<Y;)zZM`k^rGBU;wZUWP%di1=PqbsHYFG?th4w;=+J7^5sb0D8q29!A?pk3TR)@aZzCVsN3mY@mT8@^T-k$J6VO2<C#<;`S'
    '=OcCF=(jTAzV!9bSKR%KHOG9XL<c#1PtC-e47BV5_+l+M=+e5kx!WCA;Ho9AcOC#R02YK4O}>Gi{(JkrkK&fV&sCT)sGUK6O7X))'
    'UrKD;GB&mEX&R;zN>Q`8^typj+;bk8;)lUcQM$(sk!_$pfZLdA1eaSHVmpB71348+ReG*dhG{h}@^{l5r%GIJ6N?2-f?GT8lwd8='
    '9}B$??^4T^kPD$QMuodQ1xz#4*^d+#{g|QaZbk2YHa1}&!3p*ho%T7+tt4Zt+*APT=<ke<?B&fgNLJksckX0LpOG&xTviHM&0vHt'
    'TxKY6I7|K)1G?!;B8gU2%ErpK&1NZC@Cf5S6KgO7d(_JwM>=9Bo;eY)H<QwS{>K60t7{3_LcwHTjs2jKAHIW>T54+%N3iJkhv(F6'
    '3epoIf%&K=>yTn-E0f1RyB$X`pT(=xImzVWuXJC$-y0&0lqWIWWUSZ7I8Wnjss04(1X=RxTT42Yw$0jidd)-d(0+OCmNFdBw$8Pn'
    'V<3Ysv`m+ibMT$qMCRSqtgcSbBJF$CQTrXNdQ4U@NQBZWaPkHu@&|^Naqn=INTU)M-}^jQa^v60e7-ECa~^qOK`GC~-#9q|dK`#5'
    'Od<LX_ep+aq_<_W8qMQ*Fec&N&6y+svKH}prcpn?eQ^_8slT}P;h=?rzq&h^k;T?NZ&DikfByYkhmp>1cU#!!{5D>*Edf?N3>qbI'
    '(@Ty2viI<^7>#j=i5;1q0K16Z?LGO=Cj>5J1_)_Nk70f&IwtEY0}J&5`tCc>$@Z|2l(QcO7_kXa-;}`S7XE(VCP}b&JcN>8DQT)^'
    'n-Tp2PoG6?Py6-4awHy#S2#&`l8lqkpYccpk4L7gfz8!VpA<H;l}vXF*OJ#UQix`Jlm;ySq#B2fZ_p#DMGz2jeZ)b_cVwdGX(*^A'
    '9m&Uyf2rzJl3fVhrZH{K4vL=1EgR}C2oq3sVKQ$#t2~ogAuAz(7TUMqOt_EFm0FPfNpmS$i(y@}e)OT94=x05eEsT-31y@@iOjAj'
    'V{+|E2C=~*x8x42d)6@oKBfALrT*tsBb=dj^?5q?cb4z7ahw=l8aXGzY1ahP5qk|rHa@Y&&m*Ph#)&tzF4S1D{`5AY+m#!~pH-zy'
    '{5=t^-<TFmm)e8I@Stvp3|*^q*d*|mp+(;i-A$n?X&e3Pfo?}AXE_-Z^aOoFs-dd?0C_6OA*i^47v?K(3c2uq(tE>1^)nBHZn7Zh'
    'EMIM&D#$64W*XNgnlm(*khp#r$JFS99FYDzA`K^kd)L#1tQy*ii4zPdv;vD_c0I&fB(r=kTb*N1QriYaOp^}Q-AXEFq7oVzvF+Y#'
    'PK_5SbBQyZ?S=O3RrdtN*-;p5rF^JLdRSRk;(1+6U{weaBS63+#*oOug5wyd@D49s@b|6;rPXkB)IFNhLZ*H1r$Rcd<W+9mDeieX'
    'CEg|@p&d8BrNmqtb4)13Qz>|re`3A@3JFne?X2g~eVzPIX!Swen^MHjhKV#LITwnl5S(Gv;g6U6J<!u|jadlcFr46U7vUSdi_GDm'
    'X0$VNlmAS5`5d9<eLI1B9OnvU(ObVS9~{}my2{vYHk8-@*9*E~)?rJ?AskG2J#v!Cg?k9sjJbROHiFx)sYowKdH)|IzCSg6vB{BO'
    'zQK+%$#x&c;z184&mhcMNp({Su~{4D4&!U0zQtw<DMhW1m~(}U1|6UC?0+v_3;^a-;1LD`2byA;SF^^|Bf1e{Mgqu{VAiph4iMIJ'
    'sN&alI#F-|H_|?xJZxJ^D!}PiUB!-WmBkpl8g172J0Wt~!av;XB5zB8o=v^N<S-v8B3R_k(5gn~i5`#U0s5s|UHz)Kj`7OVj9%KX'
    '8n!)U%~i9OUr42EmKj&St{)J6hUM80%D4s=o(Q*8$i;tWK`5o9=r<yQs-a2!rUjqh&!tHRcFHj@M^TE{Q{iugV$M!%dCQh2j#7rs'
    'QI7O6xw5S7u?#=890%H&f&|X0K|hY<w7WZ$pz50M`e5PwygNGIY}bq|An^7kdW0!fY#q(RmLA#tqW^(O(kQzoVbmHbp1zB^sA~2A'
    'KQUbQDl8@~ql1UFHUUCU+#8GjC=bq@Mq2st4pVVO%K>{9&`+v722dU=<XIqzXQdBhG5XKF^iQ`ZMoFCrc3&<Vepb<VYH6T4PCyjP'
    '(5M{GUv~1XGQzIm?!(=+9x=_Fn9McqK2od!ag-()p54FSiFik;4_QQor7WMAon!9vj`LJ?+SpvCI+Ocwk0Mb;>HKG{qbu;gag9$9'
    'C3~9ZkOEVny&+QZ?hUqbVz@E7b%>Q`>;Wj=W8dmzoua4XhxT^lMqbqb<mC<~I{~b`@2?u-vAXKHMfEsP0)p2sIt{Y01cO_flsW&&'
    '`@8;4kkS<kgnJ`?^mp>Ky=GDa05MWRtmZ<;5z1Vs&$A6t&Wo}Z2CQ~#Pxn%woengejgc{M-aRfE7LNpbh@&B0QIELUNZwt*v&OF+'
    'lAQ!j2nT}Jd%3$WmVW7U|4iy{J+H%}Ceu0m_8XeI(J$RXdj!Rgxu$@`@~gbte8(u00h2r}8p+%2zL?U<qdw$yWd~Q0Mkq_LCe_TR'
    '>zybFFC^1HZBZU{64frdI9_3oZX5gzA^;J)VcOeJPZ-Lv<v^^uJT3_EV?6=J%(bQ(3wH`%-1!pMEDk)M{cS8pKF2x~BTTp6{j&4O'
    'nYO>`=ECXd&J4XXgIVzkenpoUMxVqP<T=_T(5*6+wZ}&}aHJZ*l+1$r{6C(3DurOUZPV7bn?W@22*4lWOACkHvUc+bn>r&%8<ZiM'
    '+)WY*n+p}u)id&hPp-uzD+o8?P0EK5`|3t+*5G6u7Y~_L`s^be=#gqA#LIEb2HL~s8O7`k$XS@$9{*Q9dyveSTfYa(Af}~@*6ajM'
    'I#s(YIbw6zF8Ht6G@Bf``H|}>xM2utV3VQjxkonXU4@8g%Gxww=HL^dy!U1-F?V_5vuBH$1F3p=P*fd~QfhS3=-i00+k#=L(M#LZ'
    'g@Z4fc|ce9bYo(Y&u#lNIw<X^l?*}*wF{d3ehO8tjwFBsgUtQV_TE5Gm=#T!MerRJgrrH>mhYYSq1Y?Kc2rQsef>zpDI`tB2Pj42'
    'O{WBsMWfQ;ZOifI6EaAdT)eRmD)>i7A!}ROE%f+hL8m>m-#*Z_GK+MR#OZab+3(s3`w8!8)U1nMEr>(x8f)KnLSe)2U0py_Q%Od^'
    'sIXpFtk*uPU>7zcRB#!N6;Ukzm~4#>;*^`=_&ZzK5GW9E^dyDE5v1gq>2eDKkg9Fdig|RMl@^2P#s0V(+T768te^$X>47cKUB&9W'
    'zUwxW4GZ`;qr0n8hmcyw#fn081B7(_KtmaD35<{TKI8(A0=Z!z%2hvSh9)eT;)M1dQQU-g5;JtIm<Flh#c$fUmM=2cL{``Y-|5s_'
    'Dn*~tR>dops_Df$7vbI2M8a9|o|ibWIJnwRo5X`TZG?1dOK9z2FMEIpQ;2-eXr@Lm9QlY!m(J{&Mv`3`q$f92kIxRmlnA;|3OKFP'
    'Nk(qDu3Rlju4`w^ORD0HvckB0V=nP<1`il=(X~RBf!SCEPQ!GV4RP4f2*=}K^`Gi>zQf2J#rK?-Xh+qzCXb{@Ng}wzI;+i%PsueJ'
    'J(O|)ZHQQwhnFJhaspQ254(S?6=2*(#^0nw5nKuYcFVEaWE+^2m|Vrx*_0>|N&-$M@R2B35!r!1iJxtSKa%v3HmJh<F=~zY6G%dp'
    'R`*5#^$8M5nH>&)EYv!xh=D+6Dx+rxv?|2JxO1cZ`p0?ZwX*JNmcL)IeCG{n3++&vYq9o{M2+!uC3o<p{U7o^F(G1<!vR0yG>--;'
    'GsCrcjk=@%9q+N7E|P`|D4d57f$2-L_cjYFH;SjLZ4-ixTvlPD4Zh#D_cFx1^{L=w%y-u<v^Hh<S2c=OX^azn++)~FH_dutD-!zk'
    ';^gk7%`Z9DAJ73KjOP033c$xaOtc0A@N@Z+UeU!uhrJmXuFscO%pKMzGFcz{24GDyvmJ9}X_zUW!kwzTfojh8GZpEl2TZp(bQm1l'
    'Gnleji%}d2W-!^#kO#Rg*5xZ^HdudWn!Ziz!*_1tdbrrOhj!pv<c?^6Pc*>#M%L?au*x`aTaO*+MMXhqN6gLSd}Y3}M$5p%dVlPf'
    'p7)}eX<i>Q-URoq_eHF=pgBZ|(m(~AX2ihP5^&{q@XV~P20P$ofk2yD9~0}1$qvJ|msP4f<ny?_coqR<oxg6L+pR3e66YRx+e%>7'
    ')2eCs?X=DmG<TP|DuE0GgqQ08_qn9BlOdN`x^SWh6M3+GkbOVLT!cfA2;fk%A}DiIjKF?3uA}gk26RQnrd+gyza?7`wgSa~0uNoZ'
    'UBAY-3vIRC5R{@kOVf-{%@3)2PL_~VF3?gafatw4X*gMB@;tIz4F|1pX&cvPEKNe20`_KwkZWEae8J;CP;AHKSYAy$sfynX$)v<w'
    '&x`iqU13XO<l?6rF?c&bK<w%NcqT!QJQLCcNC1Z+ol0>1-BZfBl@iHbl8`-S^SrUOPkGiJGUhaw;6&5Q<b=KLLCLl8C^nVT9~R3q'
    '|M79~#-{R9{>ot0C(x(NCYxi*&@U>#q+caWlt_w(!5lMr(9wVI2t6ob={BqwmRJGE1Uqm@eE=MS{YK~BE)SM5atuP%c9pPeLt|1i'
    'v4SVJF}_Ft7<pNkF_P#{@*P4dcTS8nL6DAgAjA!KeIV}-JUvNQ7mvUKnDK*0m4Kni(mTbqqmbojRwr}J6kiJ{%QnDwq(Oo<4?i13'
    '!rA<+_os!2BfQ8v$4KUF2mZJece_S)WgIp~Kqf54+LyqP>5d)u@&H{CwVRf*Vv-Yt_7=Wt8(yjTm?t1abd@=bD~aU%v~vONj*JlU'
    'BPjOgDT(4?xg$G)YdM;z9*(I^?Oa%TQ0sIk#9VVaA+QDHm;@`ut;|F*?0S(=%V2P^D8;LK4)5Hn$s#2)0OCA!dLW3Sri)RgO$}n1'
    'MH3V_`?3;C|10+N5%}J=p)L_J0?WJ`XtXJZt0+BttK>fd$Nt=3bDrnS3}?k5(+YDNKUVn1R&XmK3#*pAHjMDwBXzK_Gtw7+asrGr'
    '(R+W*9~)1A&;Gs+pbhXwU2F^FU|k*Pws4Wp&d~xDkf&LPBUu`o8rP7d=iz)yV+$&t_@#qffETp^>wOzXO2uj6d+e#Xe>#r=_L66W'
    'K+>;$MjTAgBLLcK+c|n3ba$AUiYd3s`2Ai%!j+%zIxcLbqHYArk~>Z=^C;%1VL+Ur8h*xwhdS00B&p(EiZ9%s0tVYgC!LZT3nN2R'
    'xYYJS?>}2}LyOzO5X@3YioO!U1p4!isb&d~))dG-7MCRY!dc~h%eFodIqVzNS9e>q<&${(8FzYeWv8pJ@$0A!BItL|8P`~dSw$*p'
    'tfjFOE+Xny;8d>F2f4gLNJ>YD#^|~-y;`9#9A4dM;tfa$7*y#0y(423Z*kxjR=<zD<ZpoYa$C$jrV8m1-v5>Il_p~^Lxa`li=k<S'
    'pqc^rQSo1epqeecYuYPZRw*Tu(8r*>Ao!~YbkZV58$MrG<%V0yUh>%|_Nb@-$NFjvg3=0-04J#z&P*8r;=|tVs|8fYw$8?o8<@`q'
    'k<|Oe=eEEGpq*g@5%G*4=66S76Z(EaAWIUvQ7lM$+-oMcs~nwYz2l4jfpu_$9&VpoN_PkvNSWi#ZCh4P3F8&$^7Y`b8bHfi+?YL5'
    '6o*ptI<>FGn6SI=0}$j6#S2zyA&LJZ4n2XL+(2jms6A5fwRCo>fX>%n@#l2Dg)}k`wh@B?zTR<v9#Ow*4#9Mr_2~on`E{^8t+2O('
    'sFmN-3>?Dyin`9@I}61#v$P6s9=8|KYipZjat>>Osx>vI>F0Vm$isb6u0|F1&6i?eIb%Q_tiWHoYFDD=uXY!rteKL9Jk=P`s~px)'
    'I152KtZwy#`&~#84`Py$Z&dNIZ1OZ|=S5PKg-imM_p}w<lJCa(CV#*z$a#AyNg{MCu`wT;(QuBMjKxxWX+^4K7CD6;E*`LMwW4$i'
    '3M?fYi>6HKrD<yC^K(neBmTyH0^_nC!oKIac3|_Q9;h&Zv7&2Iz+?FEKSd^r$d+`T9r`5?k&{*oqxe1_ZSV754R)nuhkg&sg+G6V'
    'DOEk5-#P56HP@miU_s=?+;Vo(!{xaIIC^KGeBr2`D@Iu|aVHV747|xf-bw;o$+oeUf#8?|x6#qZ6lM>Zp#cy+qgQ1HkSr`6UkG3`'
    'q4VuN;gu{ylh|!a@`6()*h5`fi-_G1_;MCnDRrm~*D(-BTVM0I@2~+I6DY&BArb$?Ag0!@s~81w-ws-Roq!h}i-ps=Fgh8Y2o4nI'
    '8vzme)$$&fJWHHgaW<MNLOlh9$lJGXS-+(~JtXwX2>;}X(JhT$nxaekTg?dkR8wt@rYJniKJO${jKb|rZ5S9ZPV8LK5==Owe=#g7'
    '05vP4<k(qNe}7yR)Z>GLM9EXK6TUMdWVDI+Su2w{76feRpT?A0e9|hh4{h4@%Wbe#Ob}l-BMdHfxh1em!;1nj=D!#!YODY-+R}T6'
    'COg6;+3;pa0S{7Fk*-ET75nD66!TU_Q_A3Y)Z-fU1Bz^Dctbs88!BJwAl3CIw#&$ew7vrU30vyxYun{}u!;GXhjp;?0(y6X-kbbu'
    'W#8~#has2uT$oMrHlOu0O_Kw`{=!&>>MV>i1$`vN)VE-x>x%1G)PpPE=IZ<~6sAnVo6nJakGQ)PUAybdiDG2DN(Y9SJa-eFZkPEt'
    'x8mgQdn!Bu3CS3T(}4~!PWT_4eS8(@7{DI;lsL%$<C{Y@URESnTQye10vOfG&P;c|k6gn%6cOE*28KRS+-3FdncMMLK<+TxamF4|'
    ')DJ3Dh26>2lh)-oQ&yP;S!F`QJJMr*MvNEg;xp)#qSf{eaIjacAb;dRf9b~P3_}93NQ|RkuZx}5#K*Eq^QeiO%^pT}K_MjmB*CIl'
    'Qf=0;mV+^hN6bBf^v7nE;He#WV(ILAKs>y7NgnNe?kmSsXJ=jZJ>la!>az_c44aX`P9j~Rwt>-$sultLJp%v_SxHd$t#lMP1e)C2'
    'gj>k(m#0;UAr?g5OPFsJhhasPmyFiAP=?Bi6P@!tGHLaH!nu)o)J;M|bsIfK){IR_DpwL=e8|;m<E&V|p^PtqQRFkQRrlkAyW|(d'
    'S?s=;S$AtDSn|fO%42v@&J&gBviBy?3bS3Gs7F=X+NFm<*ZgjNraGgjLtmC<c0B}OmtEyNA-Ki%d(@RXzaO@Z5%Ermykdc!yA+&%'
    'i*hftx=Je7rg=|eov&M;!LVqzJMG+hrpQnkb05U(HCe77#X#_5^?@*LvBzK5B$PmOrPbEHLipj&c&25(N~D54j$jRUjm$a^>i*XN'
    'sk`1&pn4>brd4(Sv_C!5Pz$Rd_}vTvkXuk>BXUQ3XG;7`rMq}$sNiR);{OCNzlfXD@_GflXjK2yZMJy`aF|`1viyOZbRzNqrmDmM'
    'svho1wvJr7FfOGUicS!}LUNMQuRKlbp)ks}rq2iA+)8XGdoElwa(wi+7nJen86rMHzr!JBNUt0iwjWz?Y0mSKT<{XcgTK&3bvYn<'
    'Kj>dWVDfv0U-w~tA$OxS*V*q0T=Jqq2*~S6qu;wi5^7U&*#1ar;S%XrouE2M8tsJO!5~_yK@rp6ZI@Ah>!BI}l8?6hude0F1<Zj&'
    'cGOCsj7{$9;7IYA8<7eCO+hT3-?r~-FlJnt!ITtK{je;U8PY&h@}HA;6`meBTQ^YHiLwUQMv2$D*>eyAU<#;vDn3)Xrbg4Z%VMN)'
    'o$VYE<@nTg0cjb}Dkv0A>YI|UyXwH!PiV`|F1$@9V{{w4q=PviKszd+*4}Nb+gs^m?wa{&_s=>{ZS1=nrb&IbaL(Q!F7-7c@#i!s'
    'O8IUfYQPj<kCuc#wrGUu*vihH?MszU&WU}9#P^dRlI_t^(zyf3$nIJDk-PD}2VSD7(@tt92p;*H7Q6u&vS-~qImOb$hwIZ+jxM(;'
    'z+H$Z_2r_I>3oKXw=qcKbG|`xy+ms>pdH#sI~Sj*wryg@YH(aBw0b5b&CjmGOo;_Ne<nNBUv$a>4#D6fP}mC#u`{5B58T2$<esFn'
    '^2aZ*lH4YwzasY~@CM#4sXV#!*#D8^!~~b%qQ@u&K#5FwE$p66u}Ew|yErF!2#eR8^y*htuSefZpvw0FT~Ab<A^WH)jU=G|Gs9Y%'
    '+w?iem!PLHN3hluzT>i9<%GUcc%R^Ad~J(}VVcmw`IlpikWE(o%y7J3ltwC!o&UtF#>Rl>yM#bw*}9md7zwYARTWF4e#74@G_8A;'
    'cg0zj>8gA>QGm;fd*IAEw-XNpK~vfWzP5Yrb{)g86fq_BrlrA(w3QV{h@xDTpgG7iAi9+B<j`fr78uXC4|YK&nkQU&4-MG9uo+G9'
    '(_!7596w(O55XR)&FFgfccSM0K%}`~jlM<c^CS)#pbse&RL7xC)bc}bFhEfdM{ylZPUWpkYq42d`iBo9o36(RuvU=H1AM9P>yWc_'
    'pIaAcJpNZ8f}BJ0I<XMJ`MuTjxoTk6j@LnGnIIe!IikH%<;bwT>`RlG9J7N~iW-3Hdt_|`qjP_{p>PXQ)3xys#4g}S{yJ;~6e5L}'
    'i#E*wHRhx#BilRIgd0~vlo@HZt`4($s2vLv#4U*A3N;7n3xk;M)c<CxB%JFVmTlCtvt{;*^qb#uo+<2Kam6Oz)tw?59B~Z2Y@po8'
    '`2%>AgW+*(E4dvcosNq85FsBbik@IwKo}aHIUzbyY^4&<1r$=T(GLM+@)6Dq%H>}%I%!x-BiMT<p8;)uuc)f~r0aSJEK!Wr#yv46'
    '&N}Pf4)t9UDN`!2XPGD!MZX*q{t~m+B0f8e$RD1)!q*`DH_RF`b6rCx`(W^bzyG8}>hloyAJ%`EmJpWSggLpJQCV@BK5MD(ws3x?'
    'ULxe*B*zT?s5^BV0sDi#%n=V8*n(d$J-&R$`y^(nEZ`hlvxEo3fr4Upj&i=j%jXDbBmA`x<aq~Ze1_Arh-@z)gHwO0=)M(EWDBW?'
    'I{0QLyTwU6IBo1aI}G!35l@=+zZN6>7;N06`h@+(fAZj%oEyq6<`Sg-ocKLhjzwXE7R2HDD;-~vAdJ_AMU0)o<BZ~`ZJ=T+2$~!8'
    'myYZo8o~;~hGHP0f_*tL^MzmMTlzEs#AGzK?mjo($&`t<0ddf!w`wbRFW|c$=4%|9u?Y}+;Q~MLaLS0<)w{@|?t_%6_mI_{vL^iy'
    '*A(0OR8oV{H)Ag${1Tr=r^-5Kz@Q-I?`COHAZrt!KtZ|Euy?@~fA!BkA^HRmd6ZtPmf_Y`Ou2eiAcGSn3vA00g8N#VN?1<Y%vw9t'
    '95i&SmXT&_(JXWy;i8AlTQM^I8|(98@&R~59b!dGLj)h3*t*Qf55U=uoTy^Uy_EUSN&ms~g60F;{&gMr)OOED_wECQI%JJ>ZW(Qm'
    'Q^deLyyvsncrR;?_FKVua@`JYYzzm89ji42Vg2T+x-MqF*0YtRk^2e2;>^Jv8uxFStvaNKg3(Mi{FL>T4m<yP4OTDmGXC{=Ayh2o'
    '<tSUKK4(rh`!MA`==;bT|19ijySxC=a#8bJ%4hepEbKzLcrAor=*Pc72`rInDl@#Xb0|_%BMpb<Ii_4k=6n8xd)A~oy%XZM(s{fQ'
    'iUMC<Um$&sWzuK?fqNA2=(<ajg^*6Y0ANin%<=+h{QkiN-b+!3%tait>XiMnuiy~3fJ*v+%=DJ+VKVqSevg3Pf6Ealyv~|*N5vj7'
    '>09)$p`!t)94+Wakhmq8jEI5v<yEyO%Ks`CGGb)_OY~q9f$96Z{jzJKNUxE_Bx9(9iEok9&n9S+d!wXTk*_oX@+wdO&I82_E{TV_'
    '{Q;m{G|SWK;v5bXJ${Nj;EU2Mxl;SyxD@Cdj$mO*uLZw8VMp+7r?qe>&MxzrjjYy%1QhG`1UHFl_yxf6_$vMH#Y4j|o)kXd8BCNK'
    ')bau#G@1}D^eH-F^%vDP^{Iq1j4AmK`!vQD6`R=UBek2Pl5IH-gxV8cUcCq0igJF=G=TRw%|1Pe))~`jd>dXEg1FK6AvDtqcz^*E'
    'qGU1Ee1D`Vst{n69hS%^ON!rNO(o;L1l!aZAxB?8V=&(P$2z%{c&D?6G%L+X0@w9Xwj5xzinZw;t*gvw7?BkU5G9z<7&c>;kwaHT'
    'atGjOnjLwLUKN4Ajlf@#N-rCZX94azU3y{X3CyXF3lLdqTw6)<a5vSy;|}tK+U>8(vjLoi950XW(7UR4bwQ)s{cL`?_er>i`wbne'
    '>~=k}W*>G~2<@WO%b!$2s7tRtuqqG~Otcp`Wyp^r$9z!RlJYdql&G4|)lR<uJ*~Q=gn0-;JA58*sQ<}c&F@a<#&(IBUGwL_Cxl#J'
    'K|Ub_jwwT&`4&hF59SkG{m13A`YgsW+9XPxI-^TEKx*ao89ZyxMCv$rpnIH|nM)a;*lOHdRy#W2H>2O+6QQAuI+e`Rsw;WL2AxAf'
    '(ow|&&52gPB6jfl*f;3B8Kv-9;EZz(ve>JGZi6CBvFbrl^sivF7Dnf#Z*mFIoSmTZ8{5@nghgcd^b|;talB!3lR85VL|_ooL&<Y&'
    't(cz8s!hu66F|ek#gHNe59!$FOU~!FeGYh%8K8n_YhltKUNhWP+5creS$0izfB*~00|6Uk`)ucCa@v&8wjIaIn`f~dOwoRmO}(Ly'
    'Zx=TNmmCL{p-XVe7oh`AgD1`=<b>)`onq|j_NEYLpEw98)R>5P4g`P|j&`$OY@n$ylmRPp`kC!q24YNCq1qd*<D#wTIXHA-_=46J'
    'v9@ozhoC~39e?<sQ)1h~_IGeBYQBb{EGwvHk7Ywg$6?89>?^Q$^#yI{QN0y)lMFtB-q2pVYo-d;Cu_}Gsqlob*MhMSKDT=UEK^zd'
    'Lmf7i0rjgj#WOdMza@_MK}67ctLZ(}#XxhIJNCcaNm@QBLS<sb6><<&o0--B(vD4n%!h{Ps0rU}cMS3z%Td%7?+O@P|MUPuV&uWn'
    'wM9xJJS_-rs%y+=bl+z1M);E1J)Y~D9nHA{`6IQM0{bq3duN6e4#%ADWAZO9jE*cQRr2xIWK<*jD9EL;YG@$TwKlU8P~<t8A~i*G'
    ';jy?FhtpPg*UhUU8MbdUG^$<fjUm^N$74;bM7DkyE2Dbo)i`@gHoCGeAcgodE*mo*8G|ThDNA#v$K$2PwW9NDe0Vr`$KfB*qGe1@'
    'yUk(&1A~*^K5i!Rh}G_Y-xB^j-=U7P*N0VRz1dq$w~*V3BP1DqBx`V4<BkNuH5?@6iMK@)?qU2R09-GfW_lJ)er9M!JXAl5!Hq*u'
    'ug31Mo%<iTJ1YfyV&kdy^>~itrP=)fe|I<U%Sl9^zMr#~no%;!d}B;0`s9n;q6`EI%|-Mvj*l~II^kw-N63jURtIqfA7$MSsl3Hw'
    'XCVx)b8`&*^v(-51^?RtQj0|7s{=vWOPU=|;Iq!Bw6zSD&pA68e(+oRgtY^@fp;@PZ)aB8m9YyCHHZOq6X^bX{T%2xJ+N!*ZucDd'
    'lsH(zo~&PCrg{d)(zPP{r{?)Tjd!BgA*v9Sj`|K=`M9!BVccwGpH&n${!_~E{RT;Tj14i&6RaL47fdWjJ;9-l+;<fn55Iv@S{V}D'
    'XAzl!i(cT`Z0&p()C_t;*Teku1m6)kRG(#JTo>lYPaG}%UFES`^SG%D@xulO_FCg!RWDI#F1h0JliVu29>KpW73;)WyuP2}`MN{c'
    'f4~WJmMbezea#!szt$4+OW?P(@7n&OJWoJmqd3GwFJ;6v0d&liIJLXDcMdPZQuVtmgV6`L7xq#FL@nD&3(il!rP$`wJPl2-OF&@I'
    'Bc)yHp6iBZ6U(!kS{w&srx~j93~er|P9N)=!_b26V)Yq2E-A{=sNm3vsY$p#pgMPDLc5#P2-(-6F+d~k`<W*gJF(zM8Ib{Vo@>vA'
    'J$)w#`-%kIIoIib+X+;Q6RNj4%W%J%$Cr`1P~$?JojM)+!8=8iuPbtC*TE>#?Q}q>Wrw%=1+CM^pHtIJgi?%s>`W@6t!LxK1sxff'
    'AM)}2b1m8);5maq_ca?a+tlrrzMIFLu+=B+AANi|X_n-obO0oGpME?YMAF`6lJ|;?<y;$nS!BuOwtVnLZXrOTiNmIu%vI`J(bE#D'
    'iZZDhk4mqxp1$(mQ?Uc62|&GR=j32!4Mdxo=d+h%w<rjL|M{qi4--slAv6Pgc(41#S*ZFFNFJeqY&wC=_{W_r2UkA<7dFJpWJpct'
    'Jj~q-d?NiO>eZK6(lahX(+S-ngX^6n*np!dO&}|UpIXe7l=0TX1>vh}@@@lc?&}RREHI2Q`#`jZHu5UZ_Vfor9-&!1*^>4I62Mua'
    'z6R#$C`f78I$(?XSk053^-=0_=jTkx4qdRq2dv~q0+wPsh@HYS4k6gOJJ13=NimQA9%BaI03AY-oW%S~@E-c(CKg$Rr)g3oz_zt5'
    'ewsN@?kYk{2HdHBfl7Pmfh^fB#!E*O(gogq(nTE@VSY?1m;YHGm{kb6xo*mxq>__8RqDZ<C>yOFn%SwXq8YnEqU=LhODBq0?Xe3T'
    'NQZDXKcL!^4~<!m&S$r((f2Eo)F)2%>6x{#_D?->=UqW(1HHN1d%=VJGqFQOV@d-Qvai~;9ghwaS`O?7EkJkq)#u-!NjYlXBw7Wo'
    'zPp`?L`J5Tvya9^h!ulmBCVy5vaf^6r4Fi#xe^ID9lKeGuK0Etp(H%K(ccwTvk!3#KKsZ66A>X0s~$J*t*l_wnQ$<>V@uLjJpC!b'
    'Zm(?#l^iv5=GBi7X}O3<^baH>GAwfzNIk?#x?%3FZ{_D01u1+Um0rz1PrF{*OPUO%Kb0ToF#sN?OuUF0iTEy+YZYgDuid!oWsAM9'
    's!%LOk5lz=<cv1TGW@6a=Epio3B#O;0GglfW8W7HQQ@cBUoFFuM?9b;s)yv|0>)EN9g^k(hVM>)zBsOFey5s1xHKBbl&W_qvnj$z'
    'UmH4HzPS?LsY(faK=^52T|nJz7Y2+lZ(iQ9_V%ud*V6MPnm-G1h)YEvIaz>@JvJ4HEoFp2X46kf^I?R9E|pghhuW49bbDy4PCg6Q'
    '(ZV%07mG`n{IJA$J<_Gs2Pd(P;_{lwXRBaKdj39qVjg&7o^tjxDMRW3q~|ZlR`U``|7N(&EPdLQ(vwDhU;3XPt(iA%642YIFHkQM'
    'pPzF>4yx@<58{4vm)C|zvLC|RdYdWi3CJ~}631q)7Xi_GXQ}U1(-4({buspLZP>0uc59YZH94X}*)}?Y>=o#Pu-1cMScB7qV*4*S'
    'XPURdq&h|mQi+8wDr&+!?Er9vH*?6|MYXY9yIu~lkeQOw<@Eb0w}j<}`<cjifZaoeilXY;o+g^5(w=bZi)s=EXUE8W>~bQA4pD$1'
    '&BT9f@n4aT`!Fw`LD1T+kbq%s4xxQ9I0BOZenqHQX5UO?c0Dah(8E#iSD}p)&OJyLqUB4h(6-U0et=wqD~v;YgwT?wJ+c5v$(!EA'
    'bpp?9X=_>Li<`C3leQX^7JT3_T@?w0OD2~zMocfRA?=4y3u3J+lQzz#^oi=)TCjr#zGciOW%oZJhKwWPVW9_ABOc??G_X30&0Mc2'
    'V<cTL)%N70^^1&n9)bbD6TW|$^1Gw5hNeI^HoIyGR5<sD|L%gT&9ILU^f>EZuj#X$;Q+{M=rR)AGKygjmH*k4>u*eWjrJ0?f)Hoh'
    'e=r!>V;OKiQTLDaQ()S|xvpPv`sBUsS`FCl;@nmOGGpHLa5HNb*Yk5a=FaSj!5G&x!A#m6`T22Q8272+4EE5BiRH_@)bDGdlC&7|'
    '5DLw(Tm_VMXKDK@+GC~BMqRx0ge&OwGhVYeF^ur3!P7NUI#gtON3<TEJE8YZgpVN;mNG&;l1xE%R<fuKjdSBtkmbBl{dTdIc>4Q1'
    ';hO4U=<}(_)Qq+~YDqv0^a4Vt&d!(Sp|WM-1T4|w0w`6d*b9+vAY5#meqcrvqfbuI{xfo#CiaYhD|aubb3`rc>f2C}KHl~hA=Msy'
    '_#UB6O+Wb|i4{<<1pq~uP#OggYw-KV2YoI(^mSTqdgTN2qT)&sD7q3?N$k1iZ<LwRJr}hUI@Cq`q9_O=lB9E6V9QrcR9P5$h4nl}'
    '2b2Y69u$WBK5^}7AaX9#1e$b@9UJ#StJuX(<jrM)di6vra>YV(J?zYceB^N|iMZ?7v5G9ib9^7W7jLCUaBL{tn(piXOxEts_4LJc'
    '^}eL)T_n@ITA{ezHoE4u7N(dVlw?2HS&JHOYVuax&zm>@;ULp>=ZRg~&+_cO0u*ok1(@xWUHH)JC@tT16RG(s=-&k8uoQBDjs3A7'
    '>h0A*)FCrizsC*b=P6n@TbOWpS!IBG8g|u_$>}@f_Y_s+OF7hRm3+#!@(CYnxGbNB1Se+Fk-Mu>um$0E^(({X%ZXUGzKcq%ug(ts'
    '^5uK%*Aa0LYOXr=t^<UkyDHpOD1hwavw`FX{I04}*T8@|Mm(C{P)t{sC@2S=u@0b6&{aFm+e>%Jt=%D)0Ln$(#;qvJ;tAJ#wlj@b'
    'hJ8&sF5f7gV%apUK}1TN(uO3TgxPe;k_lutq#N-+U|u+$8~7iVSfaTw=Dfd*tyT4daieGG`B<_(gBOrZFU>SmGs10<{_G)o$n9xl'
    '>e!H#%}L>eX2~pZUKYIiX`!0sy7H6iIEUl;Q*LCiGp$b=S@;vLN<)iw{zDvV#|F^WVrCIhD<XSl3w$5pH^&9??E~NT0i=x^nqpIg'
    '71bjU_xCivL$1j-z?|Ecgsg;P;Ly)~n7Lq#({(X98N{m^LSTMMtd=*`b^lLoEZH2_FsLQJkYGwqC#+PhfUK@h2YTcLJ{nNbw`a7)'
    'r)XU^Yit#~XvJU~mJfi9!ANTmWRt>2_WswfR`TvNjrew%9DUw(e~+NHk`kYPVT&Dm%FYu>F^qE<#%-QPd`VE1lG~=?km)af0O3mL'
    'oJP=mRcp@cg1GjoiSc&IWux@X0|)dkW?E*H8NM^C+4l`2GhHWIV6G<y%d(g+DLA;hvQlJ4aKS}BW|sxKu=Z5Vwd{F~4au}O7)-W)'
    'R*NV|-pg|Q!7jv=R=D`rAsZh3qJLvlS<7QbFD);mXJxd~Vl9H^qqFP}m`l~Sq^M97NGML!7Ksc(YsmI}w$p&&tnZ#pCY(rRjw)ei'
    '56QK^?TMn!{w9eDl&fc&H#rMIq<a4K41H#jDa@(yCEd-6=08I!@(Uo41U@<`l-SVoKls<AnsIG;MO*_puMo6Zj14W4)R4^qbr!PH'
    'ywpy5r&^F%om0vt{`yY$B8&F5W&=^Gh+%Wr@V4W(ioOW2dZLip-nVa}(!MJU9G5%aa_OzqOupJM6XFj=iZxj^)r5Vj;(NzQQ(24u'
    'lPAvLo6}N3pN?r%&<%X;qx9}<Q@_1}8oTnCA0%?>g*8?MU!_rV5LU~`Oo#pv3_pBrvO?nVn$Fui!Fo+y5~MO)>Ou{GWzo9B>fPJ!'
    'uBdJCN^2o#2SG{TE!ULTjX*rR26Sgyy8b|xQGWMl$v%w!o6fuXnT#R8Ceim?bs~1ZyWa^9{=|1ncZfEB(o=z;q>WZh5~07^%WL$V'
    '3u6a9Ei`ecUc!vdf_&_&Nm!@hF5dkshfZWb@!?!VvKbD}&|%;mdW6|YQ?96IOuO5mK+~lm2l^jJU3?!mg(^AsU#>@18|ZpGaz>9-'
    '+eR8cAA@NQr5EFJ+j^4SM5{3)G}=3~Sm4_g2;-ck_CwmU3fAhsm1WW;Rfnl722oDq|BsLEL@#05e_NVTrSfx%T*h&fRp_Fvtm~j-'
    'rk>7ok8U|3OhSrDC(G=8GB<CJr@p>HZfWN-cGA0LqaPm7lURMB(kCAKDp7g^XhT7_qnrodkL@}0`an@Orsbk-Ro?|?n|<Sb)K{52'
    'oGeNqtZ?R!gAs<+h}S4Q-pXH<-+49IxL_L0)(TI6_)}cfJ3jm4Ix2x%re>FvkULP%ezKoZIYO9P43v)9+471i6<73HSxXg81Jaog'
    '%~$=Ur8K}+KmKgR)-hlSF($o?I2jb6gjl=n^9({cbU3Sx{#E<?x?&?P0?8|YPAE*<PXq)_M;8F1cv2@<gO%PMGX%igN$ff0q*b-o'
    'xN#T(-CK(&2d@WV*TcxX6w*0I&e$w8((+ny#3nXxPITN`jSdX$TrG3w)%*h_0NGvqL)<g2^mbheheg(eL0>MH5XGA-y|TBPnG=P|'
    '>rgL?3JS4T<Nm@KcK;FQ_-IsrIh85Csj+i&{!y-|Y(ntRZ&p2~E~56$wm(mBWWFgjwZa3}LC4+e&HZQZ2jDus<*1!4EG&d%=0>x^'
    'FM}Xf>_zK}|D~6nqW$>uXi@?X2`RX?gcnuzh#_<BlH(*}&l5SMT7P7_;Fxm%D?${BUtF-ZP*oBPc|Yj%4bQSpfJs|gfVfQ0BplaY'
    '>>72YTSjvhz>u2L4>49d+4r2j#?nhEO+(3{cy1)>%Xtd1rg<SsW0s(`U==FY@!%>hb4(BFQ)Vqpk|9ypqOM-1K@m3u<ntHfTCwc&'
    '8~}v}p0e6N2=yO6CnWr-1R3VHR<Z^vj~#GSEj?w%8Og452Y<Xw{3x&-wuhK>l2-tGsct2ZtwenwPSGyw(asgv>)ctD@sj4-o}pk0'
    '?MY9#E;u8~bJiMu^>`QPF&|bG0`@B4N+32c83b#s>Ymm4Ve8EW@NQ)$=}Q(S8RDu~<4U;J)#{qOrr-Kz%9yhFqAqNg7W29;NONH6'
    'j^-E3%lz|9i_c$dH5cX`G4shi_B}E`8|Xshxm-_S<8XMCb&RKUWF7AJkGwrKy;uN%Wn8rT_yeux?lTGvWl#~n*{UV#^*;Ind+2!k'
    'Avf&ye+-&7l|`xhw;}-7lAg1r4iGTqhRIB~@yFqV+-4p=Da|KLXSkAq4p&eF-*J;*BZAVJhVf{du@AC)b(b|(&I5~QHLIN)2Y$f-'
    '_j{+XLiaK)W0G??9Xyo*G-J2%L|x??P_F>)yCT1m*8=}*Oq2Kwe%#j=b8$dPey-Mq+cA3&n5rzK<(Vd}XSvFxWH{{GX3#dpHo_A3'
    'f)m3yyNl5}D2j}joZQi#j)rI#R0%mN5}iY4lVocW3uhwGWR|N;qXeh1HZU%<VfKNJpOyYE%vY&|Gi+%U!zzR=L`G0PsephzHFFZo'
    'x;{47SirTbQ@aAAuspU{UN+24b3U|TP^1HULg9=%h8$wzOI%C71Vs*p+iM(we1{P_J0DdFk%S|<PxhK>Uz1lKW07GUgTil{Ye*qN'
    'mU?&<hhvuj<{igr4pSertdA3M<{;U#1eEMExR(z&^o0+ZMmbDyFQJUsL6@l`nWlV<*jVv5zcO?mY{-+r>B%_62$G>x^dg0AmV&Xy'
    'a2?AI%-RX#35E@1^J+Je&<@$~+>=0hEl8{$2sV3+y~kjo%lknsRLs&p^x}a)T%b4*$536tI>gqX(D0IP&{c|Ni%<qu)O9|6VdJJ6'
    '6ON<`a|ljwS2%WWzVnf?>Si^ayg-l)k%qMVQ8q+Gc7?}k51IhHWVYQptV%qP7Vm{(<_r_+evzJ@_XNp6+H!u`90+V1jhMnlUg-|6'
    '6S(Qw_6OIYT8#?19h-ZylzknMeYG03a(EXh%M~V8nGEyPFj{>PxV5zUvY|^_Cb57`&+%O-;2x%lh=SKycsLqJ5kX$6mQW0}?nNSe'
    'KFr5c3%t1G?qRo21=B_VBmEq}dIU|-eK?L0C1S^h(Xc(P3XRCm4skDy9I!TSQ--JE6+#pWK17?$O(00d?mGMlj!N|ebcVmU7(L#O'
    'nTv&ragrqp%j5`hQ?a{z_+Bp`a;8|>>uga`ycd2#jMh`lp6-60UTkpN+xUvUc;>Ygb{0FUFCE<w^eMc#=t*qy{~Zf$$iL@Hl+%#r'
    'Q80~zCV*=EMQ8>+-r+5m+-zTyn-C&c63AuGip+W|@_!+S<V1=NIFA>ebmr6QUd1Ct{$lXkdtF6Ng0xp`?Wt<U64Y<TT^LR{l|lBN'
    'VeIp9Vk3P1$jdhXYI9Z#lPAtka0F<+&)b*Fs^*`fPJPE?$Uvs{rVep+!9z>kjnUB8LZJ=sae~H=sN4N}F%-1oI6~vNy*%$@9J-qN'
    't4XkWOGktgV-MTs4F=d-+%+S^%vr#f<uE)!vds>#-{&J{<1`2#$t|j9wM(8gVem5VJOnv1oUVhcJ_khh%F8YigN%zD5aG8-D_?&$'
    'm^(HVBHdMwL48zm89S$en(B;)O|$+A5Iw5!Oz=3wIc>Ry83jQo?YF+o<9HVVD!*Xy2pCwC|Hvo);kJa<M5WV<_CZHgm!}9jPhkru'
    'fu#itGyoy>Guk$Eix&fC)j+bJ?9IA1)pm-@5%R9jy8s@C2`J{8=uMwc``QFRg|3@=a<kN#dJ)Tf$N!!Vu_ZJf_h8}BBJF;Hz;vN^'
    'i_KHSWDeHy@($GRodnJIy=8YYoWra~6!BFNB=RJR6fNR`X`EfRJ|qs2hFjO7V@tghLsoinge{7pqwIOuiCjNE5)L#HY}!gBN@{r6'
    'q;h*G?qpq%AxI;Cw)mzSa&~|h1A8{EW@4T5W4JHU<F(d}WPgJTGp)^Qi$I5CNeJ{%NRi~(7Tq~_UXPq=<;Ppo+(R36$iN;F)e(X6'
    '?rP7b(&uWeI~iX_OuUoeX^VKVONmm`LxHzsw}ff_LUx3weOM<0;uQ1VzW4rY(z&>5rl3Y+Y6tUav*a0!yqy9~N8)UA)XSRCi>BS)'
    'k2&<oGwCndWhMTgu)5r5(KoAk#Qb@0Q-W0mCcjy|?Nsav?&aIo;sPT4<j>OC;Bk{E#%_azP9K`8tD!Q3)WvV<J)jt#4K<%RZ<eYv'
    '!~H!v)Gr-}0`J4G|6h0|*-)<u%ZDPLT8CNvQl7z%d^=pcGMlm!9BJYil~*<HIBe%kgJ~EHId5@RsA^nJ6yrKez4M@XuNYl<q<{>F'
    '(Py`?bKmZQc2bKW+cM<E_Lji_`tIF$%QJQ@j7EROp%yO+;lSr5$6f4R=g=#bdhL4SzGyTkI>Uo-ttHjYZD*oZYVo~~e5kNvUV*9g'
    'Ee0yAuF%j2Qo)NsV~h~B%M=gww{T7a*V_!oltgYl2CmVaXt^`608R1HI`5^4c5!jg{-^bG{)L)j%c%>}Oq+YRV+4rRg;aiP?*l|g'
    'e#_cFqZ|VO*Qp9r$x3N!_f{Z@4lgo_mQ{PPpm0z{AwEliRV-^k@5HF7#Y=b#;_qc5ELM1*HWeHx0Kh?%jAAGtX0ZKsv*mz5h8Qqm'
    'rW584^gm%QI0Ew}X*&~rqQg#YR!qWrQNnwo#r_6+mAhR$maCaR6zv@3h@%Ie2CD+!s!HQNBBx=6u${VT6r?wS$MDY~!C~;%wF3Ey'
    'aVpBP-DcWrB^<M(#VJSWc9H2$G711!4x)YZU+v_gV&+#?8N4|slXU2@igt9*<mW&WMR1d7L>!fS%Y85N2B!<sd$TYnM{wNl^-)Kx'
    's89(~B@kA5Ql4k3QCLK+oRMV*`3A2y7(4B{a(~@-fR7)Pe9k;=c7U^-Muy@{t@azoXg}D4evLs|i!T~+Zj>wE#sk;&v0WY8rb)i1'
    'VgK9HU2cv;JrAe60MXoVS`{gZceJ@a{qs25$Lgl?2$?KIu$$lxLZ`3-Mwiz1WY5w8*7oHhOM5$xGd_~{AHAII5&i2c0NBt@H!qmZ'
    '(`6NFt8f(@QnftkEDfOG!O#>x8sFN%&I3S~f?b{?bm%sW)yyU1B5fOMR}C$Tye}4lr7Ugkp3>yxJkLo92=;p+L0))()S?EfvTUt('
    '>yx1hdT=A@A9$RcJVuBHYUQ{bC1__r(oIG_4%et)JtcKby9Gz!)m&yt#rd#%PJbk)vHsdLWF#2L1r4b12x=~K>1Q(L+>o)HmbHfr'
    'U$oPLi$VjiIH*UBC&4#Evb3)P<Z?_Ns|A`q;0cSN)Wa6?ci<j-&}3B%2|gtuc$22cwK4qnNBK;|h;+z0lD?-UAJEKw&p^-7r6jwf'
    'l!euRfB%`kfTeJD^)-Pg6sK_*X?4dIeLKnJubN*g*ju_f;vJ<Y55EwdEMqBgb1V@=PweF#*Hf|>N4)e<yu6i=Un#N{B;Jw%sZUNS'
    'N<V^4)wL~TvAxs@p(c7PKqXM9g3VGYz%`F(Db)POg79h=vc4)bVFrQnSmOo*sAQktEL78Q1)K7J%I|aBa7ZHf(+*;fYYqTMB{;Q6'
    'D%5c3m{@Qsh&M#I9X48(ML818!wnA+7SPY;p>uyl8#`dq%pIB+=x5*%b=wK;q>wAN7+t+-52->Fi}MPz*X*1Xb2~Q)6?(bcJ6S3E'
    '`|J2&QhV5+*_5X^(q=RvKUNJ@8lvNx=j`PaT24|7ptZfX2ynPagO|Vf=^)J;%+)+9OLW9`YjK?L>x$7@A_{6Ap;}RYa^ga*2zOgf'
    '&ycIYqvwo&>KNEbNOE(1KzysW60Lf2kDB8%-;Ehs=s07t6wUi`$pIV`ty*1U@cFk8R(vd8HuV^a%j8CqZ;a0ymxvaw;r?(8npNKG'
    'pGcxJLe&idDCxQ2@|BA)nKDa~H)zRcYp<%pGz8f$MNa6ElF#g}pZ}chwa;fgA0m1}Thw5QP@W#meCmtkTn+zZUEHP6!-9S5wRaE~'
    '-88-bD>22|@Z)@q;~j*DrYlWEF$ylZVy7FMoN@KgDTeRCx~Q#Ly*lqTA4;FdJ~t%0TeyizDZy9^ES%UNa(os0EwT5kD9e)t%H#U0'
    'Wn9y;iwM_HoKjsFtZC~dZ`z=JJ2{E*G5*7-jn??`_pYH2Oife{Xpv$32Oe%2iQ%FO5Y}M4Yxn)J_%pYqbbbIY$8DUJKM@_Ra%qss'
    '|6MPo4?79nF~~Kf?ex|MYx|v_?sqZ}!Ngh(6&U_7nTtAG&%te!b5%Qvl<1kM939!tv@l;P8^JcpG!DjEF*uS;We3#O`l}vb>a69K'
    'wKP@yZ3{i_SSJ@VhFKPtCYWbxHJsP2MD)@gdRq040#7M=1NGZ@D!;$(6yAH^oW#IphRZ*ZY62`zASFL=U<b4XA5Y@8An(?WYc2>A'
    '7#8e7g_=HDBYdZpDEJ27{UK?~(q_o3IMdXvHDlzAVF2;vW4Xzk#7S7_B7WhGs$kN`Uj=f*w%`naf9rs0TT?b-=2&%rUmJLZKyci4'
    'NN8>c;7cTQ323F?#DP+fbV2m9{UMs@;+B$*miVYrw5@I#e&c5vELQ_%I?I(0r2t(*>Ljr$K^;}Q0S@=s*J*V`N;?b$jh6dYWeey$'
    'XLB0Xg5{U;E4<h}*(y6-_=DG2%btsWTDF}p&qGS5aAgxAxC#uB)C<#Qqv$P@CFhKl75x-7n4ss}BK``G4Lm)JIPY`yls7NlytCxS'
    'm0~0KQYGQAe(<$pcCdTrxpZ@z>y*@Q^-$yweA4<XI{#f)aq@nsnbDEZL`P*YEl#!k-Pm-$;W)(Ggz6S6vAt<+W!l5_yTu-wUq<6E'
    '&%hcXtB&FLc;+Ep%x{4<Bx8r=B1O8gU8nP<dI~HB1L5y|@h3_H5gWd;Mi5&vPL0}I`Bbl;&M0h+GB0H4yb_ek{Ho<nt}9e;ByD8c'
    '<4jOETLq7A17U0#zoTI!=sXrj9S@Z0n^6+TvM~@jz3<vMc2r*9vhe_IIuBNpfb#x!A=Nh<(h0_VLq)~D3hu4fJPl7LJ`AVWx_`$B'
    '0SkTv^a!f1Ka!)dL<e{mu0!46cgtUHBH=bSvax+oQ~`cWTw4{T75SxK&vyN%-W+g<zX1(e#k9Wjsm|@SD0=P}Va=B_WnlhNsrVRy'
    '3}=0d{v98MJ4gdB)OV@&{$60((~_e{6;%?_Gn`;%UQ$6X)}6WJ&DJn^WuQgv1xp3=krmoiQUI>fR`D)lVwpdZpU(e;(<biI%hR<d'
    '{!(=utZmK43F+9_yos!UF(Dka1Eh9d)(>CYN!T}wq(R3HXK;9B?=&J9<-HLSkXGc$&<!CX<B-!29vNgV$lm3w`|HdBH=g~pQOfY<'
    'sdj6FKr?IcE=S>T-qw664}Dig2$pJ47)I_p0D<EsRIdO86d8&y%&L}eW0K{3NTQ&pV}ig(ywk;xe2ahnZc2R-#>Iw$WW&j8by{&E'
    'L4FOyC3qB7O_{JD$dJ!se|)e7G;vf@lJ7s;KD#lTj=}pQnE(WGc$mQkqq)*u_+rXR?p{L)3WqO=;rO7gpyC}e53Nq5=+tXV9l-eq'
    'w~9x*dM)T6Hp!deoYyDa?1<tbkpc?9mKjUPX)1mHv408wjYu<E>_`(w4#NelNgfn0^F2^!p*2{f{?b2CMVVYxvak#Qg{mKW!_VY{'
    '7`{zzdD3ZR6D>3Rns&;J$yJN11oiekSU({00lS0xXzruTvA-PS#p2D6W~Ka1CdN){E)hv%dn#i`mz`)!fTnW(ja|rj-ji80z|E$l'
    'g{06k?Ds#3@l0T*Gd@JAfe6$CIR`5vLP#B9>aw-OU@?}peAH;S{sJdhEk|<RLGQUtuQgtCsS>N4L?k5VPeLl}Z*#ahqLIfz8#(jj'
    'n(+9H(r<uTu<47LNDpvm&$@E^Gx$8Q1D11ei|fl!b!dP7vS3zNQ|<M!sC0P$p_G^zcTnzM9>bV#DrLinYP$R(g}R!KaSH01)CZkW'
    'y{*1W(NobNr)Y8rW8_pD<qEA8g8eF>>2IEG)^KT=-#IMpv$3^9mGEe($5a7@;V;Rj<o4*#tM0G=j60UXhiktDeJW$Rdlue!DF1wF'
    'Uh)SS3aC>R%V9fOyPh(#R9o(rXSJO2o;$ipTk%-ybK!WQ$j=ZjFVc={rfx${1`qGhpL8x&(VuqN??HHxkcFiz#%RMqwPBSdGL`$5'
    'E|r!Br?tO@8fpu2CvFFp%*As<T*11swtFQi=ORRkCq;0qhdW(Mq9-axQ(6rE_90~&ILHcHMf5xGM&cXQ8=9j+ZN1PEJfgb%0Ajpt'
    'y26YlfCk%OpU3|_MIe{h_@p%A--7YoEU8MaU0zfc6HbiJ5YB-8#C^9PlSXFWBK~z1u39xpR)kqJ)Xr2U%xY&iFff><Bo$K5n|mtD'
    '+VV`wrka(|>lCV-<md_q$TO8BEpjeCQ#*aYQMRXNQ)VjC#$NbCLp*We{530DRWR{TzW;7CrL4M?6PomcR=ReBP0V@;Tx{p!acEc6'
    'X_vQc^~<|ox4~JI+hbubwaOQqUj%vCGy<Lt;Jr0OGPZ`c#VA!I9o4$Ys4V|=C7XyOB)L+?=&`ai8EydZq)qSq<x|kl)Xp@kh8PHb'
    '_z#pWHq{Et{A;+jS5DP-oYhNoJ*V`<&a-!pkx2Fm&RY>6MpM_tq+shO(|ED@4YX~m4QMRo9ETrwnoC4s&@p%Z5T)Iiq&8)KtHZCm'
    'fgU=yc~S@D-n`B)#^TQQ6ye~D|IoU_Yk3dkI2)A$E9hXHnksQ&Se24yc%q%7cWtVXhmyxmL{PiAaQMN<H*=-fy6wejAD)UzFYi*7'
    'bL56R!yeDBZ*QFr#n-=!B=~~V-lRp*mgwa+jCXb-OwHYOeiKrvZ=)s|$-(?aN0EzG5(khfCKJwVt7g|pO9V^4RM>Zwe=d>TEDBd?'
    '=YhvXX{da#S?Df@R51A1%?lbuj2O=Bx*p&9b2XwOn(Mx*D`g{jpWP5Lv3o3GnO5zC-S$g$_gUThn5f7D)EUY`2kC2J?IL&dL|a8H'
    'tK2ri<jP6c8i^~etz{GWmWOe_?2U|~hHu60hvVVMCQ^ZoLD+v>5?3G2HpGU-N@@lwSI`NF)|z@}Gx4xlD9u%gcip;Wp2TCc9EH19'
    'EvH&xZ_OUx6l%dsmo~sQ(eLrU?&<W!V7j$-cAof^zwp3$>E~K7)mQkawW60-5SdGi+({r1q$I^+SqYQgZOBDQ)&pr}v6o~zYmu+%'
    'J|jbNqySHN3_AAzu=vIU+-u#Tt6^lRbo>Q4o;JQABFB7FIpQhm>yhO!^t}7Mr;T2s;>iQhzHwMTB`XhiOkv>9o7C9hY1p4wd|y{c'
    'n(Oo_P0!MUDhOB7rT|qMz}v*hTxRsfTt+zcypN<9GiCb}lO6Q0)r{5mJ~XX5ftPP7xzHWpG(GO>So)h@_2Bq@=9iC7*7b8!7spmZ'
    'qSn)9bI7=NlHm-ueT&BJ*KNl7QIiI@1D9~H#A<kXs_hZ(rrd?6u45oL5)`^=ad+%Z-m>&D?75`0&9mYkNd~;7tJYg(W2bfCO!3MG'
    'A!s}r*L`>z1fML4-PO*H4h%YDu9)0qZ-1jJu_Ge~@JxdoFlTSca9%Wf`L3dqa)(tAw0Gc@2l4FI_)_oVJ68|TzzRY>cD01MmkZEZ'
    'm`O-pX8F00qwIJqvLy)c8V045(2t_ntQ+7)E1=X;C<9G+WXtRL`N@TndX%AVWpufb-xI#HsfCnOzV4{uRE}=>Jj5b3(KKVb&{Q=~'
    ';5uYL-TV7aZIKEQ=R$hweq_mR)c4w(mML?<2@bEm&JCWxB}<{R8;gwyuo0@TtP0o#ABMaH#Mg)u3CUXnxtl%zG9@Wf(bMQ$_XOg4'
    'C=_=DYkgJBZe4Hw`G3`h(f!4@SxQqZKg-lzbZkptxuE-zVeM@TMz4pH&q!1xotZ`?r)CABH>7#6q{IvxLz>LZ9j7Z-bk<+N=+=v-'
    '#WOnFUU0_RZf46eT5`Q~)PAjj50q?`If_@qWI+~8j#k<Eh4+<tUwmr5KQqt849mF!qM(eYPVFpI7X>YW59cXi6i8;<b(f_=B)~uU'
    'nc2wcr>w*_90-d1b)~DA2ywcLP{K%>t(!8+<>IQlotfyVeFr?^0#m3mEL<!Pi}@NnzMt{kW?Re5UD3ch_-WrW-JK?3-y=y3B^_Ds'
    '>=b^H1bJ1iZdfw+Uo=BQr8c)J7o^utV&kOXxzwO>hMG$T&te{H#dR_TY5>e&mP_h@uOn!san?ts8Hgx2YHItqxs6v2=~zotcV%`A'
    '+zN@V^mCzR)wbmNDv;U%&mkvJ7L`yWaCHuXx|Jj3G&=|?2{B486W<xScYJW0!S4Kjhoec@jn%~VU_Qq_k!Y7;A$upWlK_W2HBGwb'
    '7a*03%Y!acvsYlj%wOnms8~66+}ay@vT_O3q|R2#=Hwgr4X_dG-Jt>>9v4>JyAe2<m#L4M7an`Z$7(G5IT>W|&T_`Z_IOT;XE-*+'
    'S4%shDV}373MSSMNV_uM#At8y&Ygz#_A<!UIQc99f>4qa@yTI3yYx)$QpRKPUZtJCer`Nsh{nC{Pjda4>OGsjeS7+6Sb!RrkiEp@'
    '{_VHb8Bu2Xs4pqVe%djL`Uc)~nDsE!Pql`))T&lTKNOlQ*NbKl1IDI}M`j{U#vaNpBW?TCWs&M~D6KH^mjQ6D;q0V<I^k=iV2Q7V'
    'DRZ0<m(Zo#^~v!@C3r2Fmw=`~00Jdt0u_HLl`OZl!}PGKxa^L4VJv3DnaRTr67#ir&#CVz>Mnd?8PFW+-#a=)SJcf*KE6r{+RBuO'
    'sxz1ZAnL#`;7uqt0ba81{JRhp8a9a2QErVwTQj=&7ST~DkZ!yilsC!r(00zaTndHVlPq*s-WV!dMZN(&>!H((?w^WbXp{gqC1X5Z'
    'WmleH|0VWhzaX4)pVnLUSeYN+J%^+6^H5n|9w%YbLp`%fw3Vf&^LwYdyPIr5H{#CQ?IRsw7(x5r8=rY;TUBL6*S|;$Y9iYzmkyBn'
    'HJ;#OD+bY}D4b>OSTG2i%=?N1OI@^0USSz|H>zoXPwljtBYWYy=fY*>EEb&IucycDDs^paVQ3_)*@kf>TEi)rl^`0iCsXCdD@l=v'
    'k1#jB_bLsXCGgS}V8R+Bp0FKD`pS$}V}`zFZR$+*9K0~p8&13ChIB~SHY|f?Cl4ONfF~3I=zA<ct(}thBd#YX9|4>b1{g9P1fx-0'
    'g|Y6rvRzfv>~~wkj)aP?gI&+XPM56>p$zXHE@Frz><B(c;7cY`hNQmK$RV7IhH7ahJiT`#qZSQ@^^Bx+Lf^ZbDwrlT(8aTC<x_l8'
    '+5dc6C@ym>nuXVqZ0Rm{4eIjo)r(_DW7To+)Z3JxGk*0$%GvW$5nb;?V&ilhmqoo1UrYBrN){QTSfN_H*6p^CM)!lLRzyVj{Z4+3'
    'U=ax~E$pzBzcbJhTKokhrBcpR-S7AOGu@Kg2#6ROEzyDT$I^;3%DUb|2F`YuDH9P9kOLv&6GAOf7(PE;kQ}@vgrYSQNYgNCcJ_dA'
    'FF(^4)R0>0OuOD=+B6}zufRKEPE@R|d)7S*K%S$?>J<FKJt_Ffz1Z(5*!rufPP-UKL{?Lo&pj5J1y+4rkcn-ljL&zrlm$5k^Kr8M'
    'QmAtm!$-AS-V!OxHf>b)o3IXLsp_a>Khg8L#JrGmd<0~Akb{|Khu{nq*v`<BXhO&m#+K#t$!KpMPbK~=C&Y0%(e*ZVJU{!F2}r{%'
    'BVjDA=yaXxvLaL6FXV55nzFpgIafCDefc2)eO*GSB0!qU^a20?A+RiW+9^%wcm-2SkE=>9&v=o-AzbF73~1+R9FoPn{Xe^?dJx(L'
    'Czy6X;7NfrM@0&uFe$#wArh^6=JUd&Li8=j-!KK84s-H;DlO_j;4HBUH-EP9hgx}C4n%hF&(qGYs**u(V3W8)l^tl_P!uu#jrCjd'
    'i@$%oQ3U{RZVV@V-JA%ys?Nv$80Rg^uzBQzCoeNszKfcGsJ@eOb04)~1k7-%R4t~DFY=lzwK1RElVJL!$SI)_lv>j8ocU^XBQ7})'
    'X={WhWVO$SK1hOC(B*f<6-`S)`_(xlF&^q3_ug$W_d?NtVYPM9caa(f36bUncwwMbjXL+z?50^4B-BbCgj}IuC`Q$NQ;YC^Sl^nX'
    'a}~DHvwg|$yzy8$O=3y8jdN-Jp_ngM#?LXSj9pe|f%L;~5Ctt}AEM~JWCi*r+(+u2Lncq`)?l?xN@ZSG8M5p}s+peexRT^jRk$!6'
    'yWmI;uM>iuPXLI?cX|E~d{^5)zD8KCsdC{H9k>{}KVNf0O6{AWg`gaC-nGJG`;tA!Pw6Z3Aln+)Lw~_F-4v)5CXl&&7TcP#2)YlM'
    'u*W&uP+nIg2o1W=z0ruwMhBHtV==gmV}xP%!St1Xw~Z0hTF=zu{pm8Y>A=~(9s+*<-p(+~^UG+doQ}RLar!Xs{ZIRUd~0*Zdtr5#'
    'QHzB$z)@3`wKUUCllIIY%`jMy`tKJpqk;WNeK^x}g;)ES2A+P{4$QPtg@;)dlGIOPhfX`ZCqLuxkjY*el*)ADaK$E?`Xrx!IF0cA'
    '93s1=`23?rTG4Mb;E1MquWY_hOg`kfg!DF8x@@jD!vDW-f9WhGAf8TU=6q+6^zW*`Ga|606dIt*dIsy%IwqUORCMoRlwfTp>jMB_'
    '@+>jWxgrSW?7b}8=QrAX>PB>&^=0~b$2SqdVZp)QwiaZYn+^AhVIBTw<(OIg4Jl7wVj=s^r)-9sBgJSxlsbqkG>1EH40shRSk!X^'
    'aGhrFL{Wo4iS=`R^oAtA9<U^U4;e5O?m?s!yx?=U`{MWNL?8JX0zFN-IMp?n^A8HFoDR!QTFAtoLp_nP?OHBV)y9&BX{`(>5T#i='
    'i!hVp>!Bf{v}!~c*u0#eg6gm+b6v%J&Z&MwusPvjY_be=vPV`<9_r|wtOenIT;?ABpl2bc>rn3cy_x;<Uxti^@YG^ipq}G@khzAb'
    ')*F52f6r>f5HeFAt@bozs9DP}QkDQm(NcDGE1yMgfE5ZCpx&<Kg<+6B1j#&$Ug53bRv2tULOsb9UBA(VC=&|_<*MD^cW$QOw)#7e'
    'K<lfGGAsIeV1vn60%%kq3cDCYYOUK@*m0}*&s7B8ZmRf2+Ev&|Cz_EV0?J!#bhmlWaBbehZ?VFkE_ZkrE3ydg<Alj=&C*^#>)w)m'
    '{!hG|-FrseE&thz7!t(J71DsxRq)Y#oVl1k9yS5Of{b0jbz+N>RpSr^;MD~xeS>XiHr^V`o}57AwI@)hR8K)~yR?nUFV>U$iv5n+'
    ')TpB2yH+KBE7%u%E7k<vOUq36)x|b^$I92BN}KHbFxc%h%=lI=v@BxtIui;LOpmFz(G@%xVIFMNocDSGHZXq`=O>g3`G_sA_$e2N'
    'c#Tu!d8Xx6_8=P>TK@*X{dd7GN4CsZiU+#zGy&&0U4JLro>C~V&l!<SGX!+Yn3N@iYjzV2ppiCX4o{-@i*MOgGQBU|v>*46#q~3C'
    '>Uf}lousfv!OnuV!Rd#>Yfc$}GsKxU#L^ro-yzj4i)0BVkX4dKi8Y&+3d;LeTv#dxZdvA5$WnK*08;6D<Ogh|en)x06^+<~!cEZ@'
    'F1FadhoALlg`2UmV(@1)zJ`FIWWZVT$|c*c>P9Bc%{y9}2OB*<A$MxCwIQjzIp0JjX+4wa(){={LWO*-07_bP^%qe$k(Dw4g=Can'
    'ctc167WruqPaq%QSkh3erFumFnYpmCa4~(qBe2>zJyhd3ZK(WST2uo&4qPi~Y8S0OLK!aAa|?J0bTr^E7G?*aZjjb?Ku6KN$!{Ph'
    'b&d0l;4$^RowyQ4x8T2}h$Y>D9T61zUo9hf{2K(AIS##}-!21(2@SQDqamDm*c23HmghfVI{%`^De=Cjo>p#Rjpf(Q)sjPMu^z6G'
    '9afjE3M>j8pwP%cTVW&fZm5&QW&K>H|B>6x14mA{7P|mw)bfH563^>g&JLE<Llw%w%Cm}UqYQ`$(3+Na@2n!@hOY6Cd`2_t=4wlN'
    'K)CM}bpd!iT}DNsKsKq_FMW|*FJi&s)N{{ujqs@g{+A;opLte_d$<Y{HI~!K_Kl}XZG%bce<2AgKB)&6$q3HQy|s&#tV_LuqyGwn'
    'RE&0||9@Kd{KOOzcUh<!j*&=nwXFLX)#$`%Fji%ehUeN`^<jv>Rsfg^Z45cMmH;S!q$)W5=MS0r<t6w3b(8uA8)>M**fOUlS@I0r'
    'w`*ENpZPJL`esb{PLJn-uu4opLhnN{H<TDfbSX*kgW_7$Ft*KemWj4pEp81~(m7g69j|9=C}XC(kxdiXHTFuoN{F5NPfZ_@>Cmzq'
    'f?7xh()@Iics~7pyc6V%ZjJ+%Dwy}sv5Z26{Xf8&kzB;!_w-+<6uA*aK2rW7rmHYKlM$_0wN52J81)r*hBF~JreBENnWxLi1R)lV'
    'aYQsd*Sgs>ls>8W46TERr2ZOC4)JCLaGTupvOPAOT@i@fmKJPPP=RX7GxT6Jw0-y4;`@3hotU!)_i!fChyFhN=V2C*VS?h&!$sJ9'
    'E|J1&%rIceR8*`*@vUvLp1OF)&V<7_n+PNp^xYsB^q6dIn}gwTWr@(WK`T=E#gTt#ZK$uwa<^P-I?Eme{664OU9{)wJFlSCU+jG+'
    '%Bd@Hlg%ZoLM57nRG#Q4Tl2xY(9Dtlpu;RXOX1Yv%;da+dx>S7woMtX$H_we!by4<n1_6~3>EPmOAJ$$(rxBi9b>(P_s!)17^DWS'
    'ZEr~Z(rybm<LuGgz`!)bW`8tg<A2i~{bo_zB$#F18y{`2xe6sJpU7`qQEdd_J$vm;a6e;mg-UdXcqjD6ZsU=doeT7qb3i!)h!J^h'
    '7oZl4wL)<o13F#5!9~hKt)J>5+t$p`tVJjcB?-iD`3z1&;Ybuh_Xhi!zd!3@2XiGYj0Ft@#&-coU+~G%FlfPFz!>qnblnFBpZi80'
    '8wQ0r+iUs!DoD?(si|2d5~&u<ijx(dRf!aCUixsNr~RctNb?-Xh@6htCCu3^MPH416A)~G(tn#982gMer}~1*iaj9e8>-SG`y-`G'
    'k(pT?<h)<oVP*YH?*eb`mqOB>F0opsw+zVro*<7+6J%-%!YZ{#6hlhK(RJ5@lyhXKdDB$2UE$`ToXEvN6QmH=b5H~tfNpefmw(o0'
    'oy|r+-K=>kv5B^uUJ!BX4C;?<KabP0;HHDI*MfGc5|B^3wzOyKV_@%VD=Nrxpf0|u{dN0y+t4?NtqcP)Wle(7j^?*5HigtnhZ=r<'
    'j{_lIIZr-lP(^5J&zD6vvtb%NZgwQlCdisQ6EL*xog_i6d3mkx{ASTsTVThTM#7JHJ`F&kzm9gjXuicJ{24&EGv488DV!?dS8j)y'
    'Lxp4J%8g2rcW0#x)RY?5@|lCD*l98XJ2K3<BPM8Qp<8h{A&ZPxGpsbGNc`fsia^Wio8mHGa!vJUj*tCvL!e<KdrW3(h7#&kndg6n'
    'wNq9inq)<I1^~l2SK*f?oF31@RF`nheZ<nM9o!?J=sw+C*VraTRg$@YJeiUQq+iM`|7<fZNKxm{N2P(xd;pVG6@(@}zf55%HoP_k'
    ')s;Zw!Zw9>i-NRYSLmm|@=_N=Zxh4FN_beBD#zk<tII6^*E%MChNM~{twIffb(S4iF0r^wSut>QW&mdQGDQ@Bh|L0e-}BY@U9Jt('
    '7~|5Xy_AkdAIM3T|55P5J(xCZg0{AI5D)V}A7Q8~`aX(8jmnQin+X|xS46&#fxO|M^4E>|?GnCQaaeipW|Y>Qzo0VN7)|`%nAwv4'
    'z1sE}5wZ$ZR(F{^$2f#<FB^tim{l`};?@wiFHS6k95k{c6{brOf+lkKCzLyRzg_IaLo{wRQo)rlV5|DTL0EJ{IcrtB%;<2uW!=kE'
    'v6h=k(2rKCTSI<+EN&e>jn)fgd}i=NTBrO))966bb*-4fScJ<^l%f?Pd9!Rbrcc09h2@}*PA<RJL^0+eGQD3n<aBEM*$01TGX?#{'
    'CKZxJl&haMfIAoOQB$cJ_L^cpNe{x5PHvjYOg<2NCyv$5QjzJ~3M*Z^__!oybIbv5%!C~nwHD`RC{xP3Ys9-*7R;?Jp2rb@6&nrc'
    'M3`aMUV6=j7l?>4>h}Z-G34bcQ2ij?4GyOdCJ!B|+geC5)j%&rFJ>WI^w}7MZQHz_c+4Fi%!Py_r`MeZ&Nc%c4Z>1X<8$jORxxzm'
    'Gm(wnpuAlUtGAPbuE*5aX{A?!*8OqY=CrKGe9WPDjlclk3)!(1X90&Ph1nQ}Xv3R%GA#z#8Q+Lxmx93|#QS?{snfb+$_xT+;KGt~'
    'SBEjiI{;z(z>lBoUHqyaigY|ImIHR0p`SHE-~%p!Y>EV-+o*hbd!eP(qRCH)^&s6I+3T4BJqo!@8nMiVKVv&F=?QoUdF^i8>jUx6'
    'ZMz1vX1)HY?!4CbNBAS@TqiN6Hb!>*LjTj4iiO8M0&<`j%&XmLZqtZglbXBM!=VpGToPS%-6tn&W4x`nQuqeU22M~SJ4!wz`-y@<'
    'D}_`DAvKjX6(_1GOKE&lHPua==`|iI(yiSb+J2S0=Jufbs-BQ@%%6W38?|t((l5(j@h=a=U6G3_(qnAW@5Hov7M$OxCu#Asr|0=X'
    '{wqU~p}G}!{1YRxmXa3#pY2?JuoOU!{dBKYuRtnfoh_WYHva=n+}^{zp7MoLHIqA35k6KL|5SToatEgf#-9iK0z<oqiY__gK}%6+'
    'mnUC>jG<-|O1PJeN=ss@Y2Jfu#W6!_9CSq<!14z{R-t4B>GLBTVS^oPW&?F0rTCpg>-fWyk5D<iM{PW+5RSS7@nKQz5Bzj4e8IF}'
    '3tKR#<3c%)(r#%6P$?&EWiHY@gVQ^UKS>pC+<D4_4Vjfwu%}o3k3s6|Z35N|QY_QzdymT#H$kWeDuq%+V%cRi=o*5-cXW>;Is{~6'
    'otvj`!u+$sm&a1Jh9SeF-%SbDkoa(B<AFc*RY7cfYT^Yk$ix!Wc_?L}Z^jKYNmWv+CU+{vzpJgz<M_!~%mxmt>T9T|=9LCJ609`}'
    '83|!W9n0>!rYQIlF^sP=q+U@>TZLLgGd09yQ#7taSHi{$rW5X$4uq%rjBg>uQ<t4)nBuK8l;A40+NWW`Pwf_=E_#6kM~gv$-T@OO'
    '?S)M@E`1`Ca*swZpqA<NUMEUZ5el)Oh#-kJSRCDe2US%!8>j4yY`KSVj9HzBWP(u~1?f<)X8T(38Y`KvmF$NZNA#V3`vo{&d<cy^'
    'T$ZSBXk5Nz2X?ISN=SmQSKU;Q$4Qm@i_Wv7<gPIEk>nxZ2x=a5&-3Y=gT%5EZvXWEI#?fG6mAb1C_vg-M9}f|{AjQj<U33KbgdL^'
    '&Y%#+H?ML0pQvyFOW?QIO4YvRpsX5ksOUc%uFQMqvA_=MXX&1->IfEvrWbv>9Jh7`Eg;FPe3w(<@EM3zD@rnKV;iXG?1g`z@ovc5'
    'K+@e(=d6W^KGz<2h(rQO-TOHO;tz%ZUO7Dj+E>LU+G58c<2@iL9l0Mo*<EPw(A(4_2Z5b<b1SwFhKA*3r+-c_Ih)+=EL|KHhYb~O'
    '%TUQMV?1#iYO=B5{D|l8D2o{fIw?9JJR~`rqpM2(S=k?zM)mW~z8*I@tE4vU>LTJ)RACz!S@v*ts8lJ-6INyy3q*rnQ(Uva8k7n('
    'I<f3B>gWhCCa)suE{ctl^+eF1U(+2poSA3E+S*1?GL8wunjg9iUi^Kxg#~Tg_AI1S(?iu(P->@CKDBf^Kt*?@)gEeedkAt{fGsBC'
    'nz#fqs}lOyni!WX{4cWALGue&)|o0;j1nd}C(AwD9vs_9!k<0DOwcdCw|xSUt{}~xz3}hZ*6OI{VcsyTQPZ69w=1ZC*|C4KhWD+v'
    'K7<5vc}-`m2QX!fd}R4Odp_v&3IbtwRf@XB_~(|u`@9IPZ0lc;SpK4GYG>u{!tyZ~Eq^Oj>ge_W@8(K}3)tBaljtwsN}?l<c4y~m'
    'Ob&$2oDp;l=%|VP5`6u@@P@#C7_tDN=T1}Uw(Udh)lPtZ`-N4<MIJI0hZQ|j2T6O6B49MR-Ibf6Er5DTe>xw4_dUr4IBj8pfgK8R'
    '@?Qjr!XciSG>(^lJ1#SEpoGG7RgdJL1N4QDe+Qg`J@k9j=+~V#>8@$1xaKWpgukvkDh|YXVg&SckY*|y_roX>T=lYMwFzC);kUa;'
    'lJzAy4KLXQ79fMfZeQ79Ko+4@ND?#dfN61pWk^qp2{2X@aV$2Nk_N_*dCH#Xa3DvUH9QDGc`$7qbkD_Kl=eRpHy`A~-kdmd28DP_'
    '=qw2ZPzQ8>QDS;TfA)IO?WXGc!J>u48=}3~sN|xGVto2<5)%it_mG{DTvED?`!1k}wsJ3i%TZ(yo%qtTAb*zDe2O~!=Ad}?28d+}'
    'v=nIk1#zE(Q8Lq%1K*6WBpnh=`<KP#=25FK#{cb=v`n_&K~6VasB!ij7=^r<nGOnG6Ip;5O$Ut`LDPgs;d1)4y}3R3W6<QSF<JoP'
    '-e=RXZ_#{(|5<og3m}bXp+G80$4n?v(4LGWC*rnkY`<2l`Bh3+JzrNHfE}=rVHHm0R7|(`(YJGL-!Pk&8LyS=lLY>Vjcj}B%D}8<'
    'LfJQ^LC~Z*4<4(HI#SrS?5o<z_jD6p_te`+)!-n5Gp)<qMAY7s|C~#HMTRzCfh_?=;ePxpWT#@HaTtx-v#E3HXzU!62&y_1jCiZ5'
    'sD&OmNxlDoN{%()u1pr}Osa~UaVq2B0yj~wXnO;gj_G!Yl!3oQet!G<+)_K#k5UD$k3mCW;<m^!^1p}Sh3>mMkMQ!@I9PO)Z`B@?'
    'F}^V20@&l(!us9uI?!BCHAo&fY43TAJiz=2Ddc!-k1d<P=zyHl4u}?ziv9z7mz>2$%((|ZuD3ST22>{{b~r?cF)ZrAK*!-L4r?iC'
    '`^VI`j$hPLXN_XB0@w5}?{gpZ!kFo1cB_N0lwo{AXW_m<KMkwq<+az|=MZg!YIPa3KVHAZ?HkE9QURDezex=VeC}+dZ9~L&OC@b='
    ';{IG`LcM<wyl*b@XFkb#Qtyhq0vI3LQ&aWzm6oq7U5<S|Zl#@WYE-=&o<ErUnQf3`TOU?n;eYhxsH%H<btyU;@y>AWO0x<j-7QKH'
    'Fi6gP26zyShK4WFGDBY3pP8H2ZBymh(7k!dkSE@I)BHe%=Y)rYbS-ARr&R52=>u2v&LBjfRY2^#%ky@{ZO1ANLfb0*Dn|=ub4u*9'
    'N!`=a4=k-ON|-l|GbPZrn%Mefo1b54La~Q(USmFTyR&eC*a2Nb9#(FdKw1H{sB3<LH$MEWI<o0A5m-E0>1lz6@8=QD+r9FD*Ul~t'
    'xpuDlw*okmIA;b;#5VKJ6)LgNUaFrlT(Xo2{MX{e8EC4;Ph)cm$R}QJwe=p^3_E=*BhT~iHKufe0uGMZM`{1xAwbtlrpE!D-MtBB'
    '%~X1#6xhL&;NB5MkJ=!^3ghQLh}pnFgDClvoL%V4GS<*q#~HRRxeG%0ZH-2xct*;hYrky*ly+(Z@Ssi8dnrQiMQ`U~_!u^2nrC)u'
    'NVLJhO4r&}u;?KzJI<Wria#E!Xp2(@uhhSoV<LpuFIADX*q3i&+2^pn)05#5KDWqc`%MuNPmm+vwm4O^I58)v)$MV<ws$KR8=NDF'
    '3-3P?;NlY&pc38rW)X|xl6WBDCAXBBled&W#9fhhQH<QRv7dn;jGxkz4T3l#Bm~-a1;DG?{VjY%7g{|Nr7&-K%O+!(B37dK8@m2~'
    'v^7fxM1}219+}KAaOs=jL-ne`=Bos%$gCu0K*9n{Y#h*CBi3TL6HhloxR{6tRx?RK?N3S={i4>Pk2W+~`Bt|?ok_A0xf1}~1C9`2'
    'OuMS^8qbr9C<?Z&%7&%VRL%E+dvbmMDh(f4r-PX|4=12@V|60-q}0l2v`{1n6<!@8z&cwf_Yhe#E_MJMh4c9Ou|n2;4!y;f>hi9>'
    'ig+DAww53H8j^<Z=f!`59~fLh+yo`f6gEiEmHu-(sIH*Qk-hL@GO*b7!6y1Z{D-T{szOhSlsaa&YURVK$6&=FEYF{L>q$$5+>;gq'
    '<YtM9Oyo4Ve*wbcOeWczuLU)XFCY8c=cMbh>t3+7{T|5-Df#`s8d+I4ar_a~n_iqc$LPW=Qe20Uh;VnZz0zf$YY8!g%;~Off2GnX'
    '|M~qF0dBJ^4$u<{XF<#<BMdPs0|nyrZ&VO3pK^-us?xq&>d9U0V03ho24>q8CB^WcE=SvVc9}Y75V<3Yo?=m?PKx-18J5p1u=B@N'
    'BBb)owpQ=HRw@qBB)6w)y~)t0!;#+)(6TW!?-C{P-nNS2WXP@`oi`5!*mssE`BSEwi_TCp0&d<cy@kICn<4)Z*py&tJsMy0_map?'
    'i@!Vvz|oz{bvP(R^fm#@k!A`eHb=ePz7u68fq()zd{GH?T@`^;@ib+U1&7$L&jLO8W5dX`kE)VZt_sY$tQk5r+9#7JEP={RgliyS'
    'f5(7r0U=#f3Ycw#emv=xMlI81Js3aeXHa9oOVY$yvNu8gd?tK6gV->JiLRz%ZHTZEDQs~*|AN9WFn+EFQ1w;#6>;MEcE4xB(|(6$'
    'sHVEEBKBwFB!l(GFjm_)5gwD&qAoJ@h*V{3{BfG*tz%Nq!)M?|)v>gABMyB7+YjY}=I*&X70z%e=WI0QxqD6T7}8;VLjnAX9<|YG'
    ')k<Jh$e@UT)13xqg8~fuZAn=Erx(AJ!#8k9KmK@j14(*;`VS0`IsXz-Hb(tU`mRp<%T99VFgF+j69i~oxyCpoWWIZ!>=O5YgE%T$'
    'H?PGjLij(MkQzim$yd*y@tQAzkuf_-_||SZwFUmsxa;^M<`|yi?{~p0$l?cu(!Hq52<IjcS6kJvc&%`;OyBUWEv)39{Ibf4T$A1E'
    'aJ<SGA2^*EAA#{=CEX-dQ(M~Pu4l^ZV{MAuB(?mjxZtv}*3T&1yHEBQ7z_hdPOc@F(siqBRw{$!e2FW~SxmE7#)9VPV~!4yNR_Op'
    'Xp=qllv^8cE6H9h+JF$I!rs@uHne`2N>loGh{i!GN@c8$A*X2E<E)qx`9JeCUy$8iPz&$eS1YlmTM5G`Ep*1jkV&F}@SF0!{maAo'
    'FY<dx4jC)Oqysw1x~;R7(l;=Teaa%eeU3Wov^2(!e$@m3kL}pw8>Z;rmc(Q~L!~qwC;Okp<n;^Z94|ZX-)J?#&g-Vgu?9P2K?;zU'
    'v-?W*>tO0EBfTD218$kJ8$bC&eYG>;Bmon7+S2wOlj*|ZClV4&Yc)GCSH1gfn<b|iemVfgnyLcYX>?^`Jq9%uZU56{y5UNnH;20k'
    'I6K$IJf{J%j%bBns826D(%bt=<05&SEw9^q2Ehn<40ud(vMSQk_Tq~ev9$&?K)F=dYvs!8<{2ECZZvRhUBa~UbCH<GKD>T|Y~a?c'
    'Ih1I<Jd6dt--fv7OmVY-9Vt*(xBI`u3_k>bt22CNdhf=uEI<6Uk`e(Oy;SFyrejSJa4Q7tbAezoZ4ll~SM79ZA^!58fOWYqVVxg{'
    'Vh*{o&XKP;M0r#CZD7I>++igW?rSYD2Bd!lRyLbxmhY}XSc0~bsgzI$n$NM4=?qcu^-2a`<J7?vJ7y&=Jb*e;;!I&n`=Nb!<sNa}'
    '%00?b^-djXyn|nHrn|Uxz%Q;`xPoKqoe2{4llIQ(?D}K(w;p|$yq~CcmkJRBE2WQ`orf;R+U#9GVPZTefN=h4Na@|n(b2K1tu8+s'
    'O;d@ZH)b@^tSHpIh(x5n5Nl&G&^kZ7`Uqy}JACW*maE~Mr?T`F<cbe#F}{e>{!sHhP<{gCOs^(<dvTQZKKP;9jEr}cw%M==th)@h'
    '$XB_O=1QK64kom{xWeY0&`LN~Z=Np}(C4O##URz-LK*kdYClL22D?ZxcJeY_j}mIbV#Px9^wxDtN^TcZJmQL)@8!P;>?Yt^0U5-k'
    'X%js)ccRLq9J5-SeCwxsnTGLnE?xRo?m%<p0^xL-yspO-VBeQTv~8x;SQhAi6@tVB+xe^dLwtS|+N^YL{b6C8LP*-GoPLVvgV|8x'
    '>q&R*#vF{9*BudaDj+{<PVS`}OHAy+H&HD+^V%I{(xW;z=upn=OR>HJm0}~n&Q#18N~tRZtS6_xd49tCj@aJe)xGPf#bZ0~vDP*B'
    '60w5AQg)kmo#?@Wv0Ax}N+iAFx2dfi`Mf^4hw;X%m=ck)Dw(j5L^!Og-dvF^?MO0(G0AxE=MPYD2@ksS4BOHZpd;G2qoH(%J6lF|'
    'U=yy8kT(z6I}Q;qZvny&R|WuHS5JW`Dm9tnGLCjMArn!Hk)A>6WFDb(7fMuTt@X$bVbapIz9`EL)$g@CGn@w|)jKS*g==ZlX-Y9;'
    'ACYM~IKUp-1kyo2zi3rs=T+=QxLPYkd+N!tymwe%99U-ZM;nMVz4MkpE80A1q4FKaILCin69_4J(LYi#NpbVdpRoLvH^{^sS$RT0'
    'OsdhqBfhQc^dNuT*?&+Zrz!vUWNbQNew1b7X5keq^!9ajVuum~S`~vt;=|Hn0-KE!ebeF`tdCbkFThC&kAh(lcr!_KUzhFk3Xp(S'
    '7usl)JUXVdkJpUC2Aq%}*h@8|HN#4VhQS?a#jNVVku`uX5t6#cw}MYv2On+Gsi?hh_DsEux6q<!@^Dr}a8$k2vDDdsqZ8NMZ>|YU'
    '%TPFhL(Odm;8=emwV;e7_L=ez#S|4cH0l?4tS7?onk%xTE(0&cvigEGNH~0NZQj3+7M~Zm$_Mz2Pp2z^<&Il6muw1@`(8R022vP#'
    '`J<?bupTYRjXY#{$ZS$s;`oVvmFxp6Hn>U!!#9xINRcQ38K?cQpcpZjI(%Igp*I}FmuG6-OSEdm<YNbPfe&LOVsm~mA>^9wdA5FT'
    'nc3Q%>|_=q0{%)l1DvGV^*?mIv70g8?JGYp{@xh%?YbvUP0w&SJHsl=6lM!@M!1`6STQTV7pJ4gdGEVCz@B4!2`U@c3ZuYg%*=Rw'
    'aL{7#(`d*lO7r_&%~CD=%6?Z>@5{clA1Li!#gCfCu55r{pNk2HKYzN6`q#C7(^i8cTxI#F?HakQa|EGWE*1Bmb(61%n+~3f@G##~'
    'PIr>G(w;_T_(~qH?%=Vh7dUTg?%g9g`AUQ8;pi8CqzokLQ>tSGD%7dxdq-9Pf6x!cKg{pPN-)k3wrpWu{~VJ!^l~Bgj{!eMMOLm!'
    'T9){o5Tb;wmLqTT3MrLZVAR&jW{g+V8E36(*<R9X6`I?6oq?s~0alKiN=S|{<Fi43;R45EP{Vr1U}40DIh?5Aq>LbwoCu=l@eQ3c'
    '_QN;X*po%<w(Ub1m|ZYYv;X-Gv-t8A4PG*9wqvn>5ElbSQ-dpRbQ}-a!cI9S|G8PuEQypp*xA<s<5M`P{hh-zkqT@TC*6-^@@xC|'
    'z$hduB4EP1X1o|Q1f2vZz<Uix3zTOB&B57%>1Et&9|5k6?I5h}ZeN}}9;RCi(bX?)rC>Qkio}1z+1$1{kM&*ut8Q!ty7}9<;!GlU'
    'lUa;OaKey>fVJI$glLK5n<U$QAI-}$$&o|HVoRdj-77sFfBVQ_7JOyH7V;zzzF5wVk#hJ9%)2hCPtJr%&ds^+)yXvIo^Eh|e+m&&'
    'gDY&|V`{Op>$dv_8DhN8i3=ktotig&34}5u9ZU6oC%jb%&*%4Z({e7ne-5Ya4_2X;)I+!I4;4<wo@ccRg&LC4H3mC-XxcYRJ0vLd'
    'q9qjMq$7NevFAqFU!p&9-QtF(?lvtW7ufsR_vLIpwWgi)9WSyUzDIN+mF#rZF0l~=p*?zZ`O3U<?^`@tfR`@tGN2M1?<frHI2sdu'
    'Bh<qeOIus1t?p=VDA=JWz$#NtIV(%jbn5oA(E_r>T(;rQr=5AW(IlCyrW)es0MJFD`>+0sSQs5KENBh}$Cw;4qjJ+<=;#B{v3%6$'
    '=tn@)Z=xKS$dqt$^_J>a9?^Esb3im6=9C2*2nv5*>63mLUhu+qoI7a9-AKm0LRe(dI@BiOdWW&BSvU@(%1@g`+}HWO5ytAz+q7?|'
    '2Yc=iFVRkAaHdCoWXs4CkKTTTN7x@kmW<8=1T595e0_caK_AU_z6omfkXBnA^gvZYiW_T(Cdk!9O?(GZkiY-LegKxq;IOd}c8Hcn'
    '8(xawu9TW4j|q+QYX!=qY)v#sfrsac#}ZO7XAtN+t5zems-8y$AFh&rcO$AMN1(iL>0V@8F}m)*9+WLW)T^RM+J1A4gYA?Nwe=*6'
    'gUXqP6yDm{!H;Sbd#F%i49`&+lV-`h>S+toq66$~|2{jD_))VD>-%<8vR<>#Cbo!T8h*3n`cn{^#0rAxC!@4NaAcsc3bj3YHJHCa'
    'xZ?4lT%F02ZOJnu!v`rhn@JG?1Cbn66$KAWhI{Jc)Uc+uFD_U=Z0=E-0hB4pScgKT)f#&!MX_*CyYWHK#3{uR4P{f6;Wj##PGq%#'
    'w!Wk{dojEM9)?g3)17oOb1PsWo4>+u-E4&8;?54v{&de}ueQp!U1PUVWvmVHnFc$5)_52s@2>RFmo|XM`#&ziESxh`MLem(yKm(c'
    '6~Tl&OdxFT`>l87P%*B|fW6m5g}dK=nhL>ji!kTK7xlY!A?h;FB-n2M-|mW+7pThE*Ww|Oan}!!!D$;01$U2^fS4e>#tYmM1e#dv'
    '>w>pq71S6qYLdy~%w@9@f$>)1kPd6&{%8JlEgbw%!P{+Ytxq689BTHnVeTeGeVk%NDJL$J&zBZ0nIEob#YsdI;CP*Jf|x3c@|=Ty'
    'Hete#)=oT%zxoC+S7uo(RTO*py}_sq!bq+7`_THjP2|0=ofA-jOVKs4>?OS}`KhMp8#ZLBSmZ1kwADE~=mOScEIa>yeyeUH%JY;W'
    'p&$8EKZdi%Dw0hQ!l04QonH^!x39z66J$uoI9vLR$uET0iKnacOBo7ekmsTD75zR01s+Pa3|yoP)C39pxNF;kS1pE6bON^(M4DQl'
    '^$i`zwvvHr^uVA=)+@u^ei<@~CdsqY&3;NyYCXGdbhd+$qbWcuN^(*}aYX#-<0`bbRzdUc>xDw1yF3gl3APUF;?;yrG2$Pu2)}i@'
    'eu{&yFkF@6Uh6ZM<?<_WkveDr+@k-w4NfoSqlu(xO}H6$d02;?wr@;|d&{BxM!uWEH3H+XP2c5P<ao2s0Pj-qiEfUP>qIXR5SOV#'
    '2xUvoYNil|(hqwd{$!%|Vs`HU?1__=re>Uv56$7+go48rZt#u6Gp`hYfJQ#-p-~naXLt;71%f`x1)fir;Ocx<%w)^b%J*c9Wkfnw'
    'cfL^d;A(c)rBiUY{Mbk)MvP66$KgGlc54F`kacT^1)~%Poplb&Iuemp3}U_PjhNf;T#CCiAgqg*VZdDI{LH6o6{Q95Cik-AAs+|2'
    'I%>jQC#8?wTj_{m@uidRW#&6rFZRQuXt}GD3Aln}27cA~yG*Z&>ZW2E!`1D#mRwG;ut>ad*Y!T`$T6`7uY#>kDnqdryE8eo<4hJ3'
    'bq7AjvNpTL1LPRI@yoM65RlMm?Bo!gYWctoV%Jqw1Ux1+vp}D4MY?v?eGI&akNH@M#cU^Tgk&n5a(Kwu@du&w5~C}q|9spfe(vyU'
    'jPc3=DvjRwSC<vtBa}NQrWLA3ld><ET-_{A!J_9`wlB_~M#6qxa)CO#QKDMgL1}7;KEi{4i|Mu0N(ye~VBig-PyxP{g*YWNALD#Z'
    '3((KijamS<*$;WH(-4&_SCPcX{M9%=B;H%UQ@dfbzf1&mE?qEKWvls9b#_%Du<=R7h)tBGbbW_fh!Vly`5(1BKRz{#dM-1K`zb*e'
    '>r1sKGrQorGTH+8c#5Y|%BtmEYiaMM*a|v=%%P%s(fEfZhrrv=Eq0bohK)k86lGDHsp*X5bWfjy9l>A)+kiS=%X|~A+}YDfWJxCP'
    'nlii&PC7ifUPeRmrv=@|n#|tAk-{^8q&%l4gnpn%zna0hjDVUcLT<xgh?NI1Y7&Q@XOLX$nT89iLbH%X8m6=z8Gv%->}xzb5ixRW'
    't2|DG;=_wn*2oSA5}~h{73^@HouW+Ovb<vcIZzT*Sfko?=*8z_L9$JC-#_3pfJJRBPOe<G|LKf;NY?maqT9Y%>e_u!g`FB@YQp!H'
    'Rgc23dhtf&qWtOHZLZZuIi(H?U_Pw^5WV>7%*URF5a3Z;SFL)~yR-n=J~}c<IXI%dO65FncXB=gbx!)FwRmXg9EUF77vhiQ7Z^iL'
    '!WlR4dW4G2y&p86xcpWet0I2e^5drSNrY);`2r>8SWp8(j~;etm2#;hMkfM6f9>Z}WJaEIEKa+k9W4ov$r<>&aFy+L%P7l9Cc5f+'
    'AbnnYZwJo3csP&#3-I*yu<A}A%b$gwEa{i?!b`tr!>em28{o-3AzIc**ua2(babEbhX$3qL>o#zeK-)YjHv7pJ+zrn70u`HxAa6H'
    'l^j}n$gR`Ka0}F0;j7{Q$U9r=166;n$E6V_Ql1c;+26@|<9JXO{W*|-a8rt`<BO3kIknA0T|4`~s6FibSj81QcLv11e9O~0A}yww'
    'D&B7l7b&Y!yFuj2lM^1xSHX?u8AqH^m&zm_mb6={5I0@d6+nXwF58q(%f_h8asgk@T4xsMW9VXWVh3FX>$*dlSRbU75*Iw}ayC~S'
    ')EUe<x|%*d+8=pI;oa!GfC7r(Z)8~%qG~VcSS?`u6Hz|v1=YK88A0_`KQLv^g9#rJ!AabkAPd8$KFe+N38&RCS6k!mkL>=-VV6md'
    '2_EQsy><=|aiXbvTvp}jsDTq)-nf1ws<jjd+^%>6m2q%5=swCu(QlZZM@UA5b62KqX40H1UhHg(xB4;MM@OiNz1k69f7&0_?3A}8'
    '+<|%Qz;?oukeMu{eo(|%Xlrj8Kc}S&Dp^o5Uy&(yCuH56);|}TpMP$tHNP$q1Hv9Uy`&c&o(x#}Y09U<&u1FK_5afv4Nt&~Ws$l5'
    'G_e%zXjvwF4j!VDcTnEfWOg4oKuORUiM!x5NuyI_hw#O7+;6JOiuDh^QM*YStzu~N%l?gS&o+_+#3v8Yi@nmfrAV(!FeavECUb?}'
    'cJCN1#`s&ZVUZeIv?GuQ2H==u*>|$gYbdLUTM`%E(3#H>_R63ce#K|Q@w7a-ea(8|m#zh0s^jcO`Qj*cgpjFM9G}H(r9KNqJh-NG'
    '-n~Tix87dVrsa)vv4Et+=3ROfqk^%ne<u~FZfNyUWSH*M?{(PDH;Sb=C}waL3UUTSFZ@q+=ZOE?qT{A2<O;<J^*{zG_O+)d`0Igt'
    '*d86VkeHQWGS<HrJFzBf2#Lfa6A=&Pc!sW~-mRJ_9Jc|Zi$(W2Z99$E2tp_LiU)$4NEkVCv^{D01g+#hkc?dBNThkn8!zZmBXOC^'
    '!SuuEHg^Wb<$B)t%_#<a-NxIU2G1Fw|D|R34+QB5G6ue9WZI@BoyF1$c$-5+CN((dAjv{-@O*56V&qKz3U<w~d%s&R59p~#J<(DG'
    '{YB9keQm?{36mRlkT28ens+l}lG&Z4{<is(a!qfg6vrB;r(++20f`PL649hw0;gQUbibCB(Y7g*UAKD;aXp4LiWx2B=L$xoo{b!c'
    'qus!`)Y@gb5+E?og-a!4kIhifjRiaKOAch3r~!gOMkaJe9>nCXS<{IvoNt*}H2m?_H9%Ilx%G6yIt+5=^RsZ(T~F_C6P}#Mmjv&P'
    '&=*;z8if0)E|m?iP$q*rIr}2v(i1Da5cQih*)sj7adH~I%n@*2d}@AAG`f!VjsbUGjqv3>C56>At_}jYQxcwxsN2-nf$l1#x2#xJ'
    '-Xv#-=~Fj_>Jzwk;#BHzmWy?jT97_w0#jEFY6-fJs7F5rNs`FLK{vK{@^NpvE*UMxBXa$T#>&OTA>){H=H#>vF~j+EcZ%i4lLOSe'
    'kUixR${q@v9{_=~?K_jnlyRT>%lWf)HARhI<Szl}yq7+O#t1r6Y?0PDt0B2Z!V)Vjs|i=wL3O|u*)(<RlW<lXFLaV{3zj_4Z7hg2'
    'SivYBo+Ugiuz;yN<X>fm4mUgk%e(XnmC1pd1w^tn&$j6Fw^a<Z6kqbkGGKGtf1HnH`68fA+Orsxz#xN5Z$?(<hbwC)yA}oWbt1c!'
    'm4b}c422-Ej1cAz7SvLZQ1?|sXL)9>@cc_=3<cI!R=ZHoE?cJqJOXs`1R)g|lnLiiAEpJ3v712Rf7hH?UA2neM4G&R30(mFzW62~'
    'G(WnPdlz}1a<$8*<NRwmyj;ZTGkXk67JY}846T!I&z@mvyo*13-Bh&x*>UFa7Fm{SlZBilYF0D4@P9kiWE#@Kbh^lR{#a1uq!*x{'
    'c{R02aK2GLn+vRw+d?RuM|?r}!2dnftdyd{N5<oDMd+oSBh}7hwk)b<pO~*nPaSx@(Ev$K3wujMyhultMfOEr$HzG4Sm#~P`|l5L'
    'l%J39sO(T04gUQu+NqoAuKltW1e<lG6WulNJ-Gw*G~{=By0LW>ctM$jmD>|zK$nzl#Rg28tl@e~DEopqscjMKu$a{tWsUG?TY5K('
    '2+3beAT6&c;Hb5~)mb=mDglC$_~WX-skbfG%qd(6zAWW6O$V_plh@5cTpVZ1%ypJ!VL1>TN~yXWQoq6<t23g%7hN+@*_GdE$1GR)'
    '#fl+#_Z+hJ)_8C(%BjN{W*UH_szUomn|!4>L*`We^p`%-9RgaoI(D=c-q*)l*=Tjw{9pF5N5X-Kl~#FSl~5|l1WjA?IK_6Yk#v>K'
    'P?JD?s$|^e>w^kbC1S4o9?NJK%q<4!(j(jMKRb?Uk$SJ^cwqpiP|v;t_oFb4TxGn`QT~b%d?lGKT3?%{J|ZOsozBjzj&)YTnrY#D'
    'hkfD8_1d&6>%8epmAFb1YpmvcYq%Qn)1l%Dy+D@i?yQgE_)`azA3jejn+-p--ebg~-AAlJqCx?J5XgvODudQB1;;<<%ngA$?-6^W'
    'cmLaVJnp;sQ)EGfEWQs{6l}*}N$qLQqy3ChWWNe`QFg{0BZ_%H7oNnWa%T<s8#!Yt2664+Q27Q9T5Yaxee*A5a2S-7Fp-8PBvUGU'
    'fts?-a4Jvz2v?_NyK7uXml9Chju;aTfiJ+p?cr;4q&_7A#xJV+3};3~%q$!ewWB4q>4qO?L?4-vZqzb?g5iiIac36b>^<giwJYk&'
    'd$Fq)DCY}=H<vNss*mKd9jZ&&5ai|09YDRequyKI>>`tA0zSQ7_;JU5?*5&3{0Ls;`MTM_Wr9SU@1m6NW_|u57!Ong8U`)6`Iyt^'
    'Tn!bshH<+(@`i*~x@Y|dXp$1zvdPpF$XTrbBLxVxSxzn%2&`)K%(0ZXe8Dl&J7Wef1j*$}^8vPA)qDZMs<oa0O}S>U9XaS%Z6;!G'
    'EcrIcy4Vk9j`n;+C5UNCG))8koi2@|r^2hwIh7^eiR0LNIrQcoWsQuhoKt_--Msd>xTS4_2@8-j-<S(vO)!#9xlqP)Ja8zE@zhCk'
    'RzL;XZBjRwfm^&W*^s)$Eb2W<Q;L<?dZLJss1A;GY6rf<WdjJuHfkWdRh=ZNjfBKmBMiZu3O<qg7@Ifu43g?abj6AHfhJUq;@8tB'
    '*nSVu6A=!SofpGvH%|njHSGV+ZTsRRo6wdIV?Q!sm&2<<q{M_2)L8TKB`{^&z_OTVg#l|z#W}dq5!?BL8S(=Wr6Jx#0-i6#?<qfp'
    'm&r3_Z65-=dYr&#Sxg-_od(N5IvN5XQ96IYs5pVJst+5pU37~@#Tl7k2`YW#ich8xvuxr_@fZTWep<)8x*yoD??rE?<m57Vj`sGZ'
    'UTK1<w^8GjZp9bPI$L^e9r9~DZ{`9+83kldPipRFt_eg)JodHkRuX!|H0>`VXd$tf^}7r1BQGG)7N|4L_p1zA>8W6ODs2-OScJMP'
    'dmJPYpNFZ`>`wcMAUhecypNZzxDLVuuz6aQ!r}8fg*Hh6cnqRi&zYta4boy`{D$P%sdeSq+;EP)UxqRExq#qR`REK%Ra!bI2u0um'
    'Xnl39)37JAFNHZy(nRCWYXwl+;o^(;Dh(}a?>y=fwoIHUf#C~EE2ri#n*40X+^0fWF|6cs&joS9cHiM|k9*8|`<Y*Bm=}Kr&v#vz'
    's;vDI>RNY=>eYLua|@X{H_N7yxx#c`?OcgJzn1n)QeRw2R9a3Ny({+ZV)nq+a!h+RnCMO^cN(fE46OY^b6o=*sp4Z^Yu@+2@Q~Ju'
    '045yw_1qMa`rG|<l2?$H2?nv8MoH)dLYVuj(Xo<N?nC8xIF@GXo6c8C)nrEOuoSjZ`yNNw&~=l860lTc(-}PkWuIjp9FJ1ER{)7f'
    'n96?g1qzP4kM7;REtNz%WRQvck0nMg${jIQmmoRt(Wo6&?Ec3=7phi={kPvMpm7_T&L<n8{?u1O4$KYG;f?r?jvn1uq>uDlzYILT'
    'SrWm;V>0%|Q|H!oN1pvKJ7;ByXw)_iR!fqZ9P#N<Ec%{r(|rZwM_jiH>uOU<4zcFQq&`LZpn{4(d2c*nNPB(I3zKn<zJdZaE!M1T'
    '&(&GZ{4M){BtM-QqBxrr=Hik=_{~Bkc^k{qdo9p;t#&Y#Su<p(mf#=CH~*VQ1rh`KpJj%P$nNg!Qov!)^EW3`@Edu3=nggY`S(lg'
    'FYD}~qh*uP?kMHJxBL*%bkOG;5h29uPOnMV-ee^h6?F{$L2c8IZ`F#d9xev}g4!*#o)V<&NIp<<H#)>U7J&S@&VjKESK9_>frJTF'
    'Tlmvcb2PNyz7>Tnw+?u<;JJQZb*>P)PgWdPMStfZ<xEy*Rfut3W4D34oE7ao6{=l3*TWLpzZ?akn{jpt=QE=Bh=XZ3{b*Hl_qf-L'
    'j`k1s%Ry}164+Yz`N}@bo`^ejBtm>9^NvaKF0VIrx<2d%0)3Q7S>jTC3;4ytjU@xKegFyFv8?bs^<PdfB&7*>eLkZRuh1f^rE&}~'
    'iXnPiESU2MHbh5AhkX{5x&(!A1NA%;ru{;X*=f5siu>#oO@zT-yiKt$iQfmcwcso{Hz_*S*Y^EzqE&zYAii4KW#99|oX96hBJaCo'
    'zHm9?xqvPoIF}Ld)Q$6Wm53+Gf^SBeh=sOwbG$O5roLA`i?gRE%cEY=@1FOBbe<+n#fU{Yy6;>PcAdIUbeOIK85^)^a<s>*y^Tp2'
    'uK{1okILf3wc8WJ-vNo9b{55&UkMd&rpBW9Bw_U++9FHBv1Z1CQ6?*6yv6GLU9Uz-bw5y3(aNA%Eu_Qs;$21i0fH8U%6HR9xZ~9V'
    'gW>rtHy<Jv&=3AKu>y;DXWPlZB6H9ClHvq?!ECl=Kg4LHU=cP3yOU)PRqjrY-bBTD0L*-i%-=_7$x#n3q8F=VbBS(ZI~Q+EfeJ<g'
    'f1i<bA_l<|Y9b!_AW{Gj;KhcHkDUPV1qyPc#H>9(-dOi&cD2#Y6Z)-gEW0ZuohM~Au&W(&93wHSkp$L)5Sqk=qWl}J{aP0UcHjz@'
    '*5>@&*gXh?6(M>e$=|yVo?Z(ISaRNB8G9D_5@%mWul8F>&y;MIT6TSM^l#vElH|fLMzd*_{*aHx1HSt=<Dnl$(1QPX4bl8h^IO;^'
    '45bJ~N?mBHsasVW8k$M}Ua)cN&a<;ITJPzs4pZ_+U9qWtyvl$Xt}{k1?@dOc-doQ%T*lf?_y61(ToGC&-A640SzlQh0et5{q^Vb9'
    '4pRrVP|d>)0D@D)4FU~n!oXI1empuD^wKuJC<2Ri?7T~|MJ?v%wK>GP#8ruYE`9#7qhD<Og(ElJMstren^KbMCX$jq712ZpQ*r{V'
    'yNn@}gD@&YcJx-0eW{>cQwgM#Q^A2Z#7vEB1#oE^CGtZO{OD`Hx9OMzIKkupufZgJ*cNK1kfeMttFVs}8s`1gJ3wP?!)oc#*USc7'
    'dHCHO;(8_a-gG5w>dKdPXXEHzDaLQ<3z#`g`?;zYUKZK1N$o1x2rf|039_u6`5by|NHSVD&X;GH*NMY+N|bZ+;|^bdvR`lnZd2=^'
    'zTxE_?}{OCI3i3fod4lNXWY-~`zh#(h#vZ!GmDdC^YG02cxA;DC}5qkS4xr7+rkn(dE@pY+oy?f{l>6(`9EcY8@;irtZ<};F~hbs'
    'O?y{3x9z^9srmj{_Je!&TCN47BX#o}xM4H97RZ}fCkUW4(Ja|qT1emFgIVn#0dsgI#U&Ysg5i=u@x#TVpJp|xVlp2%cmb77F|Oj5'
    '?|`kPvauK5xS>Urdmba<Bo$j9BeB)fv_?VJ3IHH@NUA#?jTc*J5!F$LL99p1T!lKPQ`;_0w}(7lO6sn2R@}T&_4<L#2oH}|7r=)b'
    'yqTP|<@*fg%7Q;d;zn1P(cs<tU0>^332wlp;k=CNL?jV(iS)jzTp)7c#2S<!h}+EYT9Nvp!=v6ABV&;q3wlbF3bF7GedQmv$M|X!'
    '!wmj7Xhwh9+!2(CRSVBl-dqO@j{0x)D(hTfI)?8AtV+80@!j63KFS<OFbOiSmCZfMEnXW0VV9Y1^YWTN8JfoRC9;FuS?sV&a6O2M'
    'Bog|Nl!9R<hUxOG{jNcVgPQ)OaL%@#cXZkxsT}5~PEgL*L{+=2L?=)rZX(Hvgs&{A{*#8d;q)*_p|0z-`)Q3sIqlf9y-?7PJ;}(k'
    '4s?PnP{r*3rXN!a)2W=T6A6j@^o7}Y&1PHvZ+LQYa~%NY_vDw{Ddb<*w?%`otD)pfZM-ao^ok*ZXh7!f80XVsQ65y-ZSTcJ>AsE_'
    'JLe6MM!zARMUGUD$CBw#Wj!M3saboYl>BP7s#FjG$8;x1ul5$dN())AR^$e8g&P_I+I>q#aVOA^nt8gp0mKWb>;ETg|L#_!Lkv=1'
    'NM<Eoe=bWt=>8sQ;)u=%<UdpuUV)b5Vc`HIvN5u_Euj-xgPSj3!0dCE$ufs9H(WL`c-k7}sLoz)e8H@%bMM%6C=PvaN>P$(yXNjs'
    'J$l#l#3v2T5)UglT;4X6ql*ObA@^+k7zs^SCMWL(bxAv71^?SxQ`&b<lBrBtuyfR}cUunc-Y#T_Mm!QGsMDCez)<#|yZM?SbSS@!'
    'gW)I8-z;Bz3X1Mv;Z??2j7D%;kc17~3eQBvO5CT7XvIPc6Gq2z#r3|Pxy}V|Bihw6qQ;Y>6FpBOe<Se$O!+{m3H?Hb8A>)|c`hsl'
    'M{evYA$XeR6X=NkrHKoiuYQ|mje5Ezg<w5Tg1GVpbA|ASFF}f+Jzd%u0|8jXzv=^FETRnNbX0(JM~r-Y|KL67GiP=PS98be0}Lt{'
    '@3_|?Hy)txth!H%t>ld~Z7*{7^%eZ0*yBG|FRYeB<QAF#KJpiv>Uf~pXo$m8bsk^yeo+U5b(Mib9P*B)lj0U$ZBf_+6xX^_T+nLp'
    'wUlD|<IY_gL~7yYb2QT!Q~*b*dzLf&6tC8Or+H3Z?03le3YzDoX5I<0PF0pV7eoR$BI#;QS~yduzi@H_3^!4X84#8ZN~bfe*lX;4'
    '(svUZKuro9cPq1L&iX+@w1!TYTw!d93%Wn#;<=@cK$O2q1pPvPvJ6-b)~0H{I<M4fXdzEK)R|BaE_dQ!aSTG_SaCDOmto#1oYVw^'
    'Q*iav=s3auf_eHm81}iQOEFQK%e|ck@}hEo-G*0x_xVSZC@F1<a?S!HF}v9C$nc&76pO$^_h$s22n79%Ki^mixm2Jk*H(0L+CZ_h'
    'r*TQ*N5*t7e7Nq6bi0BDn9lGBt?SHP&Z|!A49Oma<f-oZ(s!Uf`Ddh+BipR_N9`x${c7n?J$D|eQE_v=vJb5v_kaN~-eHOlXo9r4'
    '<dXMl;bgWLo@GIUo8o`ZL<~8vS73?m{RuZ%&7|rR1!&2k(4PdYE{O=c&I%14;K>2v;G`x(1ufuxFjgc2vRFNtuU^`147&bvo;MYp'
    '&YQ>yRV*vK?7p%W3$N6Idx2j+c911N{bfn^SC>Gd<I{a3KE~ITi6MQNxPew|40`GSoGO3PFmQUBoQnM$!0jx5HRt<T+Z=+m`D-__'
    '$)~Jn2&yfTHksx(FE`e|Jg9qdZhoN#M4ywwMBkF5jW~!FnLDR9oWLaByr~DckcB22S`b<WhEfR#Nqo`YaEAGgi5L$34sSw5)pz?{'
    '<WK}-1bJ_a|99{I=*HnlaNRO6e-i5IPvgHb-xIA>1JKj%O`<d~FqOz*=tk4kV#{%pjT)vV*G6WwE_f(ro%gXYvW>oGvvS!^&(>@{'
    'RhRq!A<i%Q6{rVH91Lb`qo=1Vr}{#NhVKcHqDSQh0a`y9m(vDFK)foeMU5Adl!cT4CR2dW*X7&(>n_7oey7IYQ8_oCDxmqu;tnW{'
    '586-@xBL9)aAOe!-#PkwP>eQscCfjHrRz6*#+Wa9ivk0u=~H-N4=gZxZ3h#Y{w}thgV|xQl+)#Xbe+i8n09fgqmlt1WJryFKG78I'
    'B&zX&k(~}Cd$Aqq$kcHKy_|`^ep$$Sepql}LEU+p#JAGrShi?;6&ASU)ADiw`AsbC?sc#thfCzdgdwaY2R+7wik2*KOTV26LSf={'
    'ChlrL4f&+te-vY7=xfjBOEtRB1eK|zzgSoaRx0|Xd%&pO<U-8Vqz=u+gdn*3bikBXc4B(vK`FuF9=Ft)9H@T=8fK*POMLY=Ps(%4'
    'quDua<E0m+hxIyweFm_wt&cHvDM~l8us9O{!F1V3)z($8V=cePJlKLT;PyrhoZl4`-*9gbxuMkY(X_5as6k5&1Vc0rJsc0Y!JBGu'
    '>ouT0vtt+Vyt??b%=e{r4<wd)ZnXTe`Kxw~%dr_)X{Wf}gS<75cMw+aJFF^w0kWQ^8c!R9P)OO6<QKKb7mx*DK8!FVr%7RYchRgz'
    'IXxl7>=S;^H?qr^ecGxGxHwFkE}3N`$O<%XJ7YD@kHga-doStuL49rF<;yyw!+qsfcuP&kVodefe@S5@g!U5tR)j+%1+0Ub_SqjB'
    'd2Q9RGd<y!WZ8h5HQ%lXGuhKsqUR^fD~RlvB$`2_6sHX~Uexhsq_x=j+^Z?A^;PW7ADhgq-q-REHOgQt)A5_AC?Dk9p9|^*?X0Z5'
    '|Krakd9;wRH&~IKV?mIGM#2Om?8_1#NlV@WgOhVGN}m4#ElL49G0#g?&1-p4l$8?>uC}r0b=G>iir>ktkiWu4cDn*z=ah4i)J3ua'
    'kqA|2k#qb%6cN##+?C5Q%rE##)QHpV$m7~J#z-nfC-CD7Tg-qAec<sC^Edg)9(MaDJ_$hiy|p$5{^k&^@7rXbhVJ&aYbm0>K@6_b'
    '$x-xwYwKtv)uPHlI04hdU%^;%1pNXVXhCjsqjicUA?mx@<$rhENutfN&gzoZE)-T{qw4}iO&#8u<SJD)uS*`RD0r$SL6rjK{7p8R'
    'g+P^Vdb0_27I@r*%?CIuUb3e(Wk8%xG^f)BGs6ri;`XNh=OQW~S>fxxWH@haJniWu6z_~iwOyQFio=%X)V_(*oWi0s*Y1BPUyY~`'
    'VJ98Qwy)Tm>h7$aP{dRSV^fIsA~cG@hTc5V{Y5$cZ-1bvOtQbNCNU+RVwJ)~)SmHhd)am(2!39eybq?j()XD&fkIgPBq+1^3(+uy'
    ';xZ;58{yWxglwHKA*j_k_#xoR^_?X-7RplB*l}6CB?KQwQ;p7N2FAH@Jd0)i5R9ZJ!zL2mBiGagkJ7LDr(7gUY8S5S5-tPOfmPJz'
    'WoUpIOgCAE<<x;C5o+@RiQH_y(@qa00ygj=l9LvAWNZKcU?pw4)~@<;00Ga51*X;(cdUR`vBYQl0ssI200dcD'
)

_INFINITE_RULE_COUNT = 50
_INFINITE_RULES_XZ_B85 = (
    '{Wp48S^xk9=GL@E0stWa8~^|S5YJf5=a7Y=hg|?I;Dp3sIa(c!;^|CWtR@>(-0PI0G1@A5uQ-5Q;7+FfS^s_${9XjtfTL3MZ2ic~'
    'H_nSyZ_YJ9czz4=xc(U<tQD~Qs{NA3IZ#s_w2E^bc{{!|rqj35YIodYkiqPNZoWU#U0W`H!BpTO$3e*jz+0s-e!0D_em>ctaL~dx'
    'Wb%SenrzUJlYZP`gm00p4SWNGqo@4mk@f0(-WWLX{R8WmkHZGaW3zDtOTt&tV{V=vURni*vFD2<r7_f@G1X;rF=%J;Iy3F*n)u)f'
    '^Y2I{86%w0bLl^;`6U1WO7q-zSI0~at~5T;;@l<#Gv`7(1qx4!PW{|=8qvHg!T^2MvAFyBb06vrB|vma4@`bmBjVCg{>Gw}l~?r6'
    'ACUtuUl?^HqGYDhm7?oJAb*wu<&t!8@1g$pk7cSELV6#2M{ipSiYEn<4_G3;o#Q$Jt47<LvpB)od0B#Q`s_%avMv7%dji_`bqFbQ'
    '&T>NS&|uk~W#Twco?I0MkUy64QP=qAtpmF_aW^;(#cCxhy<0YW)|tldQn?^kO8y+ojt7JBg3LhPkxW!qQVo%_a*@+=U%SbWGA`Jg'
    'YTG3)_8N5>E##eG=T%Bm==e3Hj78xJf>Y#0F!u(^VSl>3u)GYucQGvB1T-uWGN>5s9HnSDUr^KKiWZC&GrDuxRy<WI@EQ5l{DJ9S'
    '!~y(o?|Ca(g0mo<pzt@5Vsu_Y3*RdZ-c$GOd($JP+-95Ph?F@ZsR+E&w~wq^m&+m<q==m&h`F<TZ@jL-zp-tWmhYJ6tQ3Svc0l!y'
    '3wp`Bsz!HqSATx%ntTI3#jU_6Fo!kLXPub8Z-ienT;PS|WI6i-E6*MJCpV5hb_sR`M@1r|rHb^zQl$lizUH|e0BL~bPro45--?0P'
    'WdNqhdT1uzMYX-CdzvT9Sy)FyZ74G;|2|~SqhRxkk+ok^mTXE>tWKk*+3pYVTk^@8emeJ5f|;JZO46w^XQCl0Fw{-YSsl4nid9oa'
    'Yi8zQc7YkO(7!`OW>m{@_OT%{?#95uImB@?y(F6)AD@LEf-nqJN~DN*CoHfodfsX$K<3J0sK*a|>b5=p4laQzi3gTYp`J4!dX%<N'
    'ShmRYCw#jU7BL=q>)=0N2w-kus&$1c@o5Du<$nHwoN{}Sra2#J!hlGsYuhDw73QZyoNPtE>oG4jJ^dEMUBeDS)0uPYWow6$YVjOs'
    '4d$QZgqXITBNtAxSx=O2Az+WT-9Ley*vXkb!2{E|9w(G}8L!vMj0U>}9TRuIR4}PXO}8n6Q&r>VvDGGbfzeskf0BBJ&$ab3iL|b_'
    'r9B<c2A#a%k?0-Uqi#8|3bGKp<B$L?gv+H?Nc}b1-JCH~xIhq53i&We^9Mkj-FX|eN!l)Z7dpoyGgpq!R4Ej0Rp^y>&nl4;Y*=tc'
    '+LXuKW|Wfa1%*2#HHA4Kgz`UGyMJHe<z~1^r0wFJ#F1kc331LKBz{9mf#4u6zGfXwi?Uh%e;h>3q+hpJqTur8kMW}_^(<3NX`>aB'
    'Z4%f@I?!^bWuzHlyQw2hL&#!}GO(*)*hD2+WM;ZUf<pG+E8N$-gsTaN1oTg4)*ItvAuHHhP(C^l!e#(<VYz(w3gTPpKEehpffdT='
    'h@*p43xHM$gd2%a%*Ko=>|S|4BVXKwNlBaU@4XZLxDX=GdL4Nvo+hsE|FrX&DfDp#%{woZy+SUdxC6VmEvcX90J{qo%c14#L767<'
    '+GeR6G$JnXFXfN_7kUK)wKb*EKSJUyJ{kQz0)L&70kZ)1S6Faw%WZqrjnDB`baP++nZhVo2hf8MA<7%WVeU-#`Kz+R3d;e~NIf-K'
    'OF86UY<KyVCW#n;mt&r-g{D%2YdjpJR5ujXf2o@5mRX#y>Gm{l6dpNSybUuT67=z6f=%Ou`ri;GMjIm{KsPx3Mk6h%M(uYp!fA6='
    '=MQua)-KNfwN8diyuyI(T>Z09^FW$Wx2wV9U^^!E!MX<LDF8yP$sj4`A*=K%ltb~~e1p^SUgMi?i6~(+jP+>Soi}uBvH@qUI_4$~'
    'sam%=G`_n);~o*sAoNCBjm-RjGan{jH%QntPSwg`DJT(qr=zDK<teNv0$RBd+Ht^}4p>t)cvTHt*Bd&Nmj@E<w-hBdFF~r$zOe%!'
    '0D>IAAf{q9o}wvEyD*9%rktk^zfFco2G)vyu~3F%)UFHChJJg83>r?IT#%vgM}6LP8To=Flxf3@bTt(0ds8n%9#j!4hIi>HOEtK?'
    'da2?wyX|ePt@Dl?`|^}$LnpxS`kMH*^m_IfO4~jEnV1$CZS313z#W(Vop>Q|V?ai9!b2Gp;$udZ_C)zOgq!Yf^t?$WkG#}@-_?lP'
    'G}bI1kOo=B46~cAWM~<(>7k&p(f||LuU0WPF`JVV9XB;yds&I4v!ngO{Vw#l?<oA?@}3V;>JHpB`BX^UG;pFYSe%<h9(D#NNC~6t'
    'wX=U0shTeoNAW;Zurx%}GG-~^)WVti_`VD((%1y}vQAq2U;c5<%Z}aSt?qrfj7WMi55C)S7-<)Z_WQIy%4#Z-MP?7Jk$aiQ^8MWO'
    'GS_ne7qUMK7)J|0pZlY@d*Si#v1XgfYA20(76TR3#D}i7RDP@z8calu{bq;QEImp4w!$KmISKp5<Y3Gy^}ztsS$E#o?fTbqq4fPt'
    'gC3PWInWxteC4cJtF?oV4^7|kIL9Gl9~Z{w5X)%a8TXQ^3LWWXtpKF@$xG`ZP-zyJ>L*qm(CT+3I_6&GYkBi=X{XiV8mkoO^EHAA'
    'p8H7y1u1vxs6(D2?6he!f`m0)vwAs}yIKPa#b9o(8n$ZeEbJV|5?NzGrfm#UzMaEK90>h0*-Lk>-dKXl2hk0y>(V|MvW!duD{U9d'
    'xT!Sj(|7fbG&s}|pF={C^np4WptC0Bjv0#JMSFf+t@O9PFy!{O#*)j5Koba&v6w_hfjB>r;(0kuRW_yHVOd|c_n?#%@;N0wWliW&'
    'g-lsH$V@+0Szh0`Fa;HXrkLzCZj-(XgtXUbdhl{<h-mMrp4yp|^6<f7<VNZw3)_dZMP?WV)43Yk+rI-E!IP$hN4SgxwR^gDJ!m4u'
    '*<B+!oecT~;j3hq2DoXG;XrRCDl>G#9GOPPi|fMyBy@i-s=g;ech=w9KD-KOnxHt{Uqe*@$R^Uxt2b+*r-G>majxF(Q-b|)bxhTy'
    'V;vOC%=JRbvj~LrD%KS`{M~ddZky<PdK>|(S)#Lz3l#L(PDCtM*-R!hwqVC;IUb{rPuvujISS%n=k;2}OK8Rr3_Ex(d*w)%_=eDl'
    ';Ts_?@$q9($W;B;X`o9US$@)}F*$M+0RzVFRS$4>(WvL@IWkyYvGCe!AVmiPZ;3PNdv0oY5$GN}fTjX&2u^?n&RvHYhg9k{LF@C1'
    'V$V!)QL?>k4$ZUMn$4Yil008kpWd1ip7Wpr(;35iTU|0F#C`K#JIweJyF8mo3hEjd9-+Q-OCxiJ;A6<r8yqrFRMAZy&t3%(A0An-'
    'R4N8++keHgZ#lc;*U3g?{_cznh%p*iCARdAZ*-=O0hor|0j$M{Y!oXxJ->EoBwU$AZ5zfPa`kpH>Y>c6o{SCf81jf6`TBI%Y10&I'
    '{dGKzRH%+NR$0T7-c^TBOxOja^i+^d99S0S-M(R>AM;dS)V$<4lqnf}I?iZrNMNz2Dg>_>V{Xf48M6m|?u)38haip`O}xQ1*yyq('
    'EpmMqnVAD5Zs7X=d+(7P`)u!-`5`2>t!KMP=~IhNA3WXxYUhYzt{x=UZhO>K<j@OuX8AHAo?J9VxAqp<P{Ed=U9v(Yb8l&yrnY4J'
    'ez6`)+^NDhtNg*(&<s+hU5kh#^fS^Dn>hj2je;?ab6Q+*;h6Iyw{RQu6t#{+wK=lZV2klQ$f;YfN1LI0opFtE&X;R7g4s$OKiZRi'
    'HQT3Pz06^AKV>Mg8Yqf;`nYknL}REaY(hN<l=P_=A6E464GkSr2j0zIh^&*<Cjkj7{%!R~n&-K+J|m~|3WD;>{u_9ujqP7hCDB4E'
    'eChn?dUvbR1C{rgvhU8Ov<V{K$i+C#UO8-Ob3N@&Fbi~Ztm1=w2g`TEP5L>rKb7-KX?9}Urn-G$xr;qT7>8SVsvEg3R=sU*G(pg<'
    'BHq>5rxhnkOLiqWa@lF}pH5om(miR6*w-VFOl)#bv!1Y6ZPhCqViX)qtF@j^sMi{80Z{IkW5_RkE>X(n{D9WVtPBYTiqa;p!JAcf'
    '=nL0=bu^PY5|Gh7Gi03$5@=Eb<t5gG@M|Wfe91y&lt=qoOGv5b|NrZB9h^MrOM5B@Lj@&?64?VsCSc{pPjh8VZ$jPlQhqZH*S|!;'
    'owM-rZ4apZ*uJ~Ke86m1e@_e4MAmhRd%V0kEio`&tipSAb@;<X8^qrW#4$}idj?Ta0Qyx$DH-~)MYqk%)5I!U$AddS$7f)V<nB<_'
    'cA=Rjzq0?%iJnS!AN{HcF=SvO&8m&PG?vjYUNYHGq2Azp2pL`&LVVU|9KB8#M^xs~3bV10H&<<WytZm-k&wqcPOV4Moe?Zg%y9$2'
    ')$7K@7Cl6hM4X3LQw4<_%CGb2r&IUw5MoAQ%Ktwarpx+0ups$^)~`-4-^W4J{*xtFf)st>Mwh9LC9F;FwZ!*0q&z-s)jq%?M;W+`'
    'ap|7SB4&}2*{i1q<=R9KA(itmdcG2BC7}UhE1WeJA4Hkgs)gu{OjAu?WDTB?SF-A)3@tDJO4B}iGMOI6`n0~h+!(;53WUyx)VLX2'
    'cWdDAuw0}E*r8k~-IIna)~@l7pOr$_vCJ60)<K1!irX#DmWWm|yI_o*hD(V1A?ATUjJ~m@gV@Pj%l%do$=?nwY!5Yf#@#o&*1C)x'
    '+3~WVkF>$j)GP;^Q<n5s<c{Wc{7@q(e89YBVEZ4UqKzm`e7aFg-!3>#n7W4YnRA-m)H1YmW2yAlZ9~5G!+MqzR2}?0w+rCbZr)*B'
    'aCK@$k@!OUMf1SHeYZo8Tv<|wZ`D3x1r~!4c!)3E0rl)h151T(Qakwpi!gX{Rq#|5AtIGn2?wNAc#uwN$9!vP%w52o0tZ3!!)$J}'
    '@9dMNY{8Z<<&HCz54IHRLtp-k`pw)S{&j#%i*V?JSBs7K6SSZKzWYk^LP9><J&vvP@Cv@{6<rYijvw{ZE~AiW$;ium5ltoES#f25'
    'O39d%{6~S%N*sIw*upH$?3EWBD^2*X=425rpi*95XkAMkdxB7$mj^jyQ`6WD%#*ZKTfevws&;K~6Ii+N6EDLT(@w4SUA6ltbPgx5'
    'Qou~b<m6nhRXxatovTN{KE@Hy{uF#_>LL&p!gJb9+GuC4NJF9)=hz$e`4w7H{TW>>MlUDh=)oB-2HGh^G*36y<D7`SAUPB><)$<O'
    '$}Q|6JQ7FPy;iv(KJ%=B)*oQ<pxm$upGyRV0Dr9vxCw0G5BP;xg<rTN9zM{mdi5^lG4lltG@wmHjI2#be3@CohHzKKj`P$=2`)+0'
    '1c5w=LC*sq#0QLB_ogwL&nt3fuM8liIv#6USi*tqIT>s`<_UJVd@xhpt8Eb;1iuEoA-~^2{}1@C&pIT6$YF5_3*Bu<VGP5H3p@jX'
    '+3Bv!OAR%UHW*o7L5qB1UG9R+wI4OrS`X^@2Mtn@c!7O6pxMICtN<9Gh>wS$sC$XOf;SLAv6AN8{ZYz3Xza|0mLpBkqwsCaBLP>@'
    '(7^dk46m6EHq09_mUWivLNRKeO6<JG3of|?1S~CjzpULi#`Ro}k4ms2)v?YwkoKfk+wHKMp>-vTZnA{e7uW@3tVZZO_o9&<hN!{F'
    '!2~083@}<yo#P$3c9}{Lph4X{H2kSjV1MI*7f)*CzD#76V9D3F`c%4x5X#K*bo2Pxl*A3$=_Wync0RzlkVqI2)<&$rw1FwG9kzM!'
    '&Yl12FLS-@s2)y`kKauO!f4bYG*lOI{ZQg=se)t+WdrlKk>gjG4k8_@UfNY6A;Bz(;spp5tfZsn#pwnzyIcI2O4-k-(5}b;iu{1U'
    '<21GrX0)CuSnMrGUed_@rl0%9p7Z#>b4dLF-^tNPEh(2ktp(o2ed+T0KL|x|t|qZeE8F%f2P9YsiDFKsUXVizu8Rpfw`0>9Q~)aq'
    'jua=T|C;G&70fuKZm?|)xi0$Bw^ft^nCE@BvQ2dCU}oR4c!xCFSGp^VBMV~n291t{%ZRX2Icvs(m7~~gNJ1d(bp4N4`1_{s$T46M'
    '{V0v-IdulPh*g0*OrNmZBWVKUZX2=;#18P?3v)L2XE_l0B5iYRBpUJHg{j+Gs<SK)WxlUG$~)KI!M<-fL0THW@Q#g)7V5nYkU(>5'
    'Nzt}>!L5rR<OEy#M`+Dy5Vv9mj?JM$q4K|HA(2kc{fW<bWmWEr9)rub04;l*dZ;GOHpn_<kN)?Q$FY?>U6g{{O<aRzx-2+ks9Jr|'
    '8-rbH1Jbv<$M2~SpJdZWkiZ;y7Jj=Y&jKx!223E4-TQ8qt%TS6KilezK+*?;X#Y0&fzE@gKN#QlUQv5!Z<yLjf@YKor2G;WFMwd{'
    '_7Elq46A>zS+%|YbMSLh<H#Mn|Lw~|iL-~+PZ#Uo3M@v<E3MU#-ojF!hX3Shi#&;tpnpD*0i)?4xDwHMV12P5O2v>lPAOs=OAEDV'
    '{O&lHv?Oj`tBlI4nxk|({y6n-%m<q?5U@N4XeX%E-G9lHm7B<kF~IpIOc^P1CL=74C$VQGrwDncSR%YzgoT28t6=*5J0RGpg%I*{'
    'y&+f0=Yq_#OF|O1Sddm+(`@LBDy{K=o(NFsiuB0;@VYX7;BZD@roz0`>Qx<gT*Tr1H~~A4(D&<)xGt~wmb?{`P`jRZyt?k*iE-!9'
    'L<nNg`RNwoL^kalyb^u=!*is&W348du=?%av#&!Na~KdgPGI!Cp~Zs(yP#g^=cL*_p-<;F5B^(#e&XqlKc9`^XE)*C3z2r>$s4y{'
    'x7T_I<Da<3Ki*=QYy-yV<IS^_fuX`YGK)xAn)u{NIS+!L&ZDs*CczZDf{sg|YXu5MEq!NEYyOW_CUd(YKeM-y`6I$=e&&t-p!|_6'
    'm`jioUj*It(smM}jwUxq_gc^iNPS9ih5Cn5f&Aqa{rgNGr4%6%+$qM^o9`4aIs*GyD7(-l6?BaJ=M@rpPI)*tmcSxQC?v0wmI5+l'
    'Z`hu`g6X}*?MPL?46J(d_aSPnsf`YlWSJDke{Uck6*uc?{%Cy6NJxlfLkV#y|3ud#p)vladBHp&A2PDw@Vj8vcnF7QZYsrhDLslI'
    'Kf;-OGAzyRx{lK_q_+vaf@x@0U&1;pKn)%WLw3OqK=7D5?bBq&1&O?LV=WLY;uBIq^1m*z)XcK<P00FzrLNsZD8;LjdK}&uQz}mq'
    'xh!ig_G$5a$leyiV(vf*q~P*=vsU<KVbIIu1%JeTweYFB61xB}^jWa+kt7MFf6~}{78tEt42ihl%AlKdoOi%ygRbi%ieB)K_Av5&'
    'q}(*u>tQXAgSIPD^xmwnt+%#;3Y$%A&ovAZ<_3KbVz1s?j<5l~zVaUJ@1tFk+qDgu<0_~*msWs~Ase&bIy{#cl6?ldzJ0m5q91|R'
    '#!HWSgu82ABN3XwU__j!q)95&>?VojvnD=WmYP0}>tDX+$_!zY>SxuPEC?#MR*C_^+yDF8GW7kTz=C<}cZ{Gp1&2k2BBO&*nh4Uf'
    '$!^&cSLSKy1;&!@azEFBaiDo1-7@0O)=k?v#Z~AlRY-agLpZrkT_(Js?cSQ26}!z+UbVWRBGe(-F@2)?8`MG`n<&29BO{XycG~Pz'
    'X{iZ-Zc{dx>XZFm?t(U=Tnos-b9yf~70L^q3w?%O%DH`z`lwfDVHaW)9TGAr==Q(?GzEmvj4?fEtn#3j97Kt|BA+F9i0PbmVIz=0'
    ';D=!)6;5;BO}0EC<77>5`jGf?@;w>dL>09^w_&|{(dgpywqY@DVQ`_Oq<{wr6_;E7H-+@{=dV7i{%PTjT)?$nXvX5_vgEAOs+^4$'
    '81Uq>gG-2Ca@T0F8z&QzlyYK_xoV`;L#ZGIxt&C&m9qQrxP@7oqpBVx;r2}#UM#_;JMtT1q^!2U{&=9nFOSSdFfiEb6Hfb*K6M84'
    '7bk5mvY%ZDN}x|-BS^*wNYCmw!b3}a8t&+xL|?yq=x_A4&Z(SAqrS94rE`n_FN|8xl0#-4$5M7M>CVbu?$y4TCPoevZtQ0ADm=23'
    '=Fvq=L(gx)U~s=J3k0y+*$z=#X>1K#xfdJw6@<hz=Ir3Vp%eeeUS0anmMq;QVjdDA^|5{@$R|e<Zs`Q1P0wCTV*erPVy#G8D$@Ms'
    'AY)Q!8+Z#PNsCN1w`5U>;W=cN5a(b}DR7+a5GO+HG>{|9dnLXL6QwwPNRF9Wac%+iy^*+PO*Xx2<FDMXSLwbvpI-TFn$>H2^0dv$'
    'Heza!2y|b`C*8TDRuu7WI~Lh7l28#1-&xUZo=9riny@GiX(E0)4Uw>pa26wb)!4NrA=1lZzKy(kB6NkH5mFf@C|9k?HLaoF34pum'
    'lp%q-F<^t7lvq_AL{4M)Q03hO9{EOB(_`sn(U2cEs)F3NS%fRc6!bp7NB^OKhBlt~xKP+Q{&q$=s1S@Q9uG+WPErhIB@sB#cqf?V'
    'NMKOK3JQtTmJJ%Sl~;%BRml*c{XGH{M23dZrI{6jtH8aNzBU_)o$cs37Os)<Tyk5qUFdq3`4M7VX*;#wSLS6!W=(3?rfg$C@ua_K'
    ';%imdJbi5C@vKoU2nXZEb{UCbh+#&7!T*k$#6JnfPpJPav2`~V$6sE-deJ@X+&9WtyJ{+0Zt`a(T9<NOvb?lv3thVmsrO60g!)F}'
    'bB0Y9?~dV0xjmM_2)q_{1wjS;F%Zt>!MzLGt`tZh(-_(TJ%fFPSPcHN78_LNm|N6qy6}t+AZrD%<@(7JroZ5lfqri6_2iV%&E-}0'
    'C=PCeO%*8p3F{@)G3-Qrg^;Of>xm3`N>(9lAB6JP&U=pB!^7<nq%I|$A1feK6$j1~#gT?M>1#8@%lHGfujcNDG{5)<?qiOT^`kV_'
    '76d;oK@SBrcB=gX%uDmJ&cE69e#^l%!0Z);jyF5EJMJl*z|~S&8bvc;3=gQ>*P`L5zi>s-R)FXthTDvzI-oEL*m)u`)}{$yQ0(P%'
    'VP;@Xv?!X!jK}>S(+d`0xGGSPh@yrHp64D`FPRAHsz-Bv1Vzuc|Nb?DzT8wtNM`os01hQ^ijCX@{dw39kXZ06C-)=7dJr#`4jkxY'
    'bstD|xRxj<?b%LH3$KQ8h41N0xgj&0q-rxmj{^C()FGpw+VmJNNO`$p9mNb;3oJ#nm+p<qqLaqxkGNWHeP<vQASq%eABfEvVG@|D'
    '9Mr}>l~H_sA{E;@;Mi*5!WS95k%z}`sQ(flZbt#yjuCAX1HI?1$|-esaXl~K0$MXGWJk5jL$UQchC@*!sE7wjN4<8}SteLwBa{Fk'
    'N&G(NG49g>>1*@hVsn$VMR`LCypVw_RU?;%4#Zqus4I=py%=q&<bGoPRrIn|nG94SQ&s&o&z1jGk;E{a0SHWihI=xo%~aOYCwL*e'
    'mrhFJy?umk-F644Y?;Lll)4LYP;c4d0SP7s8u5~2J}Iug7>ePcsuZ82Vt1qW^m5n)Y!*1pTZ=-ZHpRHEZ;mpDExrL{B*Cqz@JD#m'
    '6V#V9Yi#q#M>Cy0Qy*fys;ws7PzPo`sG9WTpI$|hhvY&ZA9&z_TLsQ5Y4?6pW0T*wr}ooe>=&Tk?jF2TGUwMq1G2Y#MI)58_};}j'
    '-cMllIxb5gy`_Og)k_{faz_2+8lJ_90H#5WwDu|6v;SJ7Avc8MvP9yYjDGR6dZXWSV5D-qP<IsY=G$tFw+2R>8_f79DT9fZ7A|*+'
    '$$&a<3(YMZ84%cFaDkuxAT?xXYx0l7pT4+59CT6(Bhg}u@7JAt3X(|Am!h<5FQ-~h4+!ba)aT+O>ieN<CrODMiVxEcJ|f=+5v<Oz'
    'pFFjQ&Fa<KnDTi8a2lk$j9UsrU^LhFPbsoYy`B8yowAa`+}Sr*m9GL`z=~L_x`WIz%2V?HKR0^_Q67*ZhrD8iXH&Q7C%AS#$*JIv'
    'E0NI|zmWYzZ-`3H`D^8pt_c0vi>|AL2r)|{Ey5MZ>YHq-fL+7O{DHOKZcf74Lj*9^7~d~<SrlmQ;AJ_ir;B+3*flXasU%~CaL1QP'
    '5YJR75?j64eRRuXhjUq5QA#fWd0lK4W-STirH3dH!CYzH<~TSku>d7WTQjrya(a&X>p7phEUcm%(<z^u^eE+Y_XfGWhlZwUUAUUF'
    'Zi+33@kzwLs<g074Yb=qee~djMO7WFeD~aEZ)m~Optbs-rP5PWlrVxc?n01%QxF-N-XTbU+gZan=rY=jSrS3HeKL+7TOK<TT@xj?'
    'M2}4CO2X?Nji*t0X76zX9*UeymkBjc&J7)Q-sqHUuvpMD+B$_bE2je~7#%K`RI!q5zF3W>0};%Pq`qou?1qy+HP@g+t4uehX4a=_'
    '^G8)_pe<?JCoiJ`S4av0q95189z~BpICm2d&xzbs$Znx<;yxVo>T07|YFa9CE9aSLkWJT^aL(*eH_CD2H(gGqqa(t?c&&GO-iJ9-'
    '2>P--E?;%f<S0(=#!D`VRY66=_bhQA+xUCOvzJ%h$=eiZA${8i$Ac)A=|p(5dB&lCb|W@Od^nM^a!JKFxDXLUPA{wgB5Us+;C(-D'
    'db?XXI<N?t|C?f%Ud{y$@bPkcX%uS|IfCw|)-q7mDba=%vdT#JX7RS39gj~=28AWd)^Ei~?N?EY%H}vecT+45X7e;K)@{*0>=iaM'
    'b7!gJ7Hw%(hNC&15@*j~m(hFjsl>7TjcpFh_mzc*y0$6FCN-BE9#MT`H6oS{co(ddusTQr<MkL--29;rCQlxy9uQzg5S=vu1#Fz+'
    '130Gmg@C&yNyRYzdyLIObNVY)j3hRFi%S(zS=#)e@DUuRP1TZA=FPfgNj8;TX*f!qNnGa%m#qqtz%tWLete?4eUWjsZ3wA!wdj=A'
    'Kv~UHdho8l^YGbQi+$h1L!h!T71P0#W-C_!Fdd8DCwiAv=u+Q38$$cW)t`w)${A?$mdfnG%U;<i*(6Zgu1&;48CWrK2VrW)Ec5^n'
    'X2CdF22ULu+Z0<!{x~1kQ5On{!IVFf-3>%0@yZ0>4eJ0vj}~0w1zkI=n5l*^nc<IfLlxtFYF$Z-MY=LizCTzU7CxI{BeQ(f+69I7'
    '@@{N<j@+S`AIXc$`o}-RnQXDm<2(=!IRG3nt29POF0Y_RGXH`uA=N{P={mhAJo}n^gy~OSYF_Esw`3KkGL#|)CEIXDx`JGSM3+uN'
    'v6SW9qk?GyB(HCL58)45`MZj?*`ZBw@fmL1BhN8`dai$xhGvtQg5up%Qq;)HxW=3^DB46%B2lq}77c@{W%(5ete+Ke>?c^q1SL7c'
    'KVHAQ6gDm~inZQe6UQ;!GsX7?%gu3cJw#O4De-3J^5mMi`!C<D)xK6kyt$tkjA#7nzAu|YPS5xXA({Fo_nw`H6brid<g{RHU1tNj'
    'w)Z`7i0tf6`H2HQt%cz`O~}5I4G8{)zolcmS3<Pe`K2bzcD;+4;uBjp^$%EBQkOHHu82`e4#D|vSBqe|#n&Ez|8mzZSgqY{Fzwl9'
    '&le$mOY|=pr!9!iltOL=B|O+zqSJ?vmZvPV2&^6$6*0s=Mv3i7y}q5JuXK}ukNlJ1Q8L!fI=m?>|5R0E1SpO+b9hey6Y1CX&9{K}'
    'ym9E8Os%y|>=LxQR!+e>4Ggul#IXrkasYQHMq91~3}K3^Np^R>imFdoP*=GqL5*07pgE@5een#0MTOpjk-K@-A)VaU$7veuz~oGW'
    '^YwS7n>cT@ACh^6wIjysCqi>XTr?dPb&bx%9X#1}qSr;woMA60e=E43Oph!hN2#{;lfILEBvyiu4bCK_sGrLq6+c{$Hi)U-Zvv6f'
    'SMpj-C;E|UEs6vC{Q&1KS!WJS*E(Gy;(E5v*VJf*mEQNp03W;DP4znYgDND2??6l{BGDd4t~#o<_@A1UBGsE3A%)}JY!f_#Tt8<z'
    'Q&5MA5W)qLENIsRo(O`Lq!&ACH4o)ep2v=Pbkt9_kGl}eC9*@(nMYgjAMzofi<ISe>o<^}^If;!7aImg0nO?QQ!L#e610N1#)TPZ'
    'NUG)Fc`CGB!Rd230UT-pI@+Kez@7F>0{3BpaLNR?#5V7D8)M^jrk0$>$e?GBlHCHZu@C%VJ)Ty_xv51x^KZYJ-(bO=pKnG;ltU$6'
    'uF7k?Fci(7B<*noQ>?sH)v}O4x4WoS;>!q7bavuTPk*zEK*hijlfGYU+xr?w-DNGmaPDDP=dnuWPkG>UL7wiX?}gG93v2vbg@Wcs'
    'vGpOaiX+w`%Cj&KA7FFitsnnQ02B>DV~6k4V;W2YdH8$lzjDQlt&|6f4(`yiQ6>~H#QFw!Eci)5?``RhWWR2r6n!6FN>yJ*N#II}'
    '{=ts83qqkwDs}-<Dq3UF55zC<rAXw>4@w*8m{aOy%Agg!Rm5|tbn1fpuv!A)t9v_es{SlN$5@=Xca94N8@zUEa=`}2pfW0tu;sQJ'
    '$i(v*0Z;9lm$aVlmbevRH0KPPPwUFxxH~FRcLJjNi5MQ1;_-5TD!`Xw75}qpegx?`^s!Y;kiR-j_>g5;L#J@3g~TwyNmfCfvRQvK'
    '15CbM^gdyGe52mC+dm9I=zyl-)!O9c$Rw^x6uHPyWw`Q`pe-?G6e9BROe@b#0}J$K;yH_5D!FF_`+3P1dRGym?iKoITZf5^+UUOx'
    '%o7NlOjXGAFGS`hL+ddwHHdlhJ@6thsgzvSdCv2DCOPfg&BlWRz#mI+9cm!J?cxt{wI?Tl715U0GTRDrD!aqt-1e_SHgS*MCY91N'
    'QuqbK9{6EtJn;>cAKYCkZ+2L&Lt(qEJpSQX%S>^u=*@LJM`i<*s4#JHMq*txp(r_JiUSRCI^Pf~g0bVo(lm(v=wVvJlldJXMF#yj'
    'Q5T#{aVTCB)3Arkvror=TL;#9P<1ud!)+<T{EhpaInwviMo)2x_MspR%p>|?`6a$yMUgn08s7DbYmZHz`nC27OJa;aX%qebb+oP|'
    '%Gj9)_T&E~;8e)5h2Ba1QscYI7zYpIxmA5r4(u$1nT+~1EL%Q(qTD-(wv-2$4A6ynJnEf5RwQF5<^IfFiGHEW;n6Qd;S`q=O01en'
    '^{FEaAnbpaj#x~QhH3-}mHnY$Hb_0TU1A0|ntDS59vbO5EO3Rrd<*Ikr;O<s3V)k^WS_CocSZK7J`bL7B%?@z$JB!F2sEijG~ovy'
    'uu2_dva?{arb+D(?yGsm5lH#N#2_XrA;BUEz{pf{P@?8hL0j`zc|e1xX*9;?JXM$IT1c(BSA%x={XY~fWdTAVnGNII<nmR4!Zp(<'
    'dy_y)Xt<Nz!0%tyKP2cjti+My7M{WO+RjAZsjs8c63R7Ro>mNptW+#DH|%KXnoHX-{vi1oNcE#`58SD`X9PdiLue`3Ios#y_nnE}'
    'i6^H%VQD1r*%h*YIc$efo;ZIZg+b_Wrb^cSlEQclkGUFj78KwV#0|>5Idi--nYW7p?KV2a%YUnil8&m#CbTQ=Rza4Xo0WTunz)JT'
    'bL2xtr41nQKvvm~0uMCKq6)ajW#Wbn@duI$SIFoM`E0)6pzWC9CrLQmMm7@YC-BgD<{n`foSY0HXRX0$cQ!Qn`*4%hd(0#2GG=(%'
    'bf7XQOhPYq*#?3IBSxr+V<_Yf6(XJGty9(oTBl|?H*8uDeFjxqO$C>rS9bNy3hFf7>e{4W#9=2G<i^bAYL!FVX3PjG_^vj7Rz-;$'
    'e8)Qdw#h%tVSf`Wpyzis;Xa{r4e@y9*f_}g`3cz$$0Xi#?^Pxc_b@f>2R*Bxm6r~_@qE{1+}%+NQ}ei5f+zvjVnTC^3q;8|a*;xV'
    'JnSgqQ&LrCcW?`;`dObfHJQx{#&I_Sd|;+CWcZe652iEs<td)R`AKnH^jEk|NxZ@=zxcjv>^BeYX)%;aX7W*AM}MBvY#RJ7^9!sI'
    'yyJi+Wz3xI%O^?csMnQ`(mm1J&JhO`HVZbZk9v&|$%;`)XtZ8QG%br=poT_{6t&CT;P0ZHaTgpj;>Yb%w&P0nzlkC-c@>#2LfKSH'
    'E}+E=mEz+6G^a*T@yvkQcxOu$3laI1d^2R&)pNCTI@hdV!{#p=I+MoYUOx8$PV|Gh?n|2HV$%=07h^hjJ54ZaB$i<03ulDw{we;A'
    'F763Bc-PSZufF<XYsBZOW9pRl`yxV$bpD^>HZujxjqFC2u3qkMjHu8M5`ll=k(|P|>{?A$!N3cr43AY1!0Ag+6L{w=bFlQHH#cA2'
    'P7KwOf2PCPLoI9p%}FQZZ~~1fuSEPClV+E%p62=hA0{Dk6x1=2slZ}^#}@0|Y-bhIX4k)58>f(EI72X+Dd#Ht*Yh?X3hL#HfmQ`I'
    'Pjj^gYjXlzej*zBTC@TWE!fQM(2gO^neW!{pkt3yXP74cCW)5t*ww8<RCP+gmFy1CcL#=$M@|$X|2^t<3zTPqRP1_6A)$xv7G~ZP'
    '<@j296J3DSKD)-W3-@TfY}3M2RsVM~?$CsGTYQdYPZ}EZBU;L)AYzUjKwq{=g=qxVzou-A@6ff$2Zwz<G74yAs1Kd%3nO$9xit3c'
    'Idf|S_xT8J;aNo{w>0<1)mb=GW5;7St?cuH4l$CtgmoP1aFvj`JfSW0d|B&WVdI05(E17rbM8GTx}fzuVm-qrAOX?k&E-VANiI!I'
    'K%!1o?vtAi(+G`SFAcWnR&xr7FGIg>6Gpo2NA@%*c84of59R-2RV67|X9X~V?7NO(#NGveg^$3-LbvOpL2=PEH)NuAATY>=c~~|Y'
    '8-uF0jd1q_qVe$Ff#5&(BRc))xxZex60Pi$^lJ5#7U4b%JgmlJyzfX;9yrvt>(ZAgLlgBh;aAIt5oP<^Mb<@0ip8`A+#&tpf}L-H'
    'eO$LZ2>JtSf^_+}QrX}Emf*%6d^8RDMgrqj#J~u{BUhK7N+jik%H$3+oYfhaJZCafh_s(c_L3c!nq7!JHeVWK4IuKUiF6B3!?8_F'
    'UKK{(f5Fqck6FxMYE}x?Arw^&|C#Q|Z}$M2qC8p!7g`HUh!&pPdVfj6)W^WIkkwDD+C8*PpZ4C!)Uv6emX=FtLoOPBvu7JPaDlun'
    'sF|>Z&RIcqoAfLMHLU)rNew}e==M@&@Mw0H6A%^szz?s>26XD%RZbw-WMeLTu%{63CBrEfGztQAWp0{uPU-pec4!_ac*vZbpLN5('
    'kOhiy$>^Ei+UOpB-DI!({A+a==BVD8zvZ@%KW8xic8UkG=EE!@<CbN13@kSJtj?WnQM~$fEZUpjTC5sp3R8jXlYLRY_^w;OH6M%3'
    'Dh<hPsT`3KIOGZk*5hLho`{856Z|{?33M{R>vbci2iQVuF=m?s91GdBy}^2@At`SoD^O)`ZUbu%@-Z7hTZ3U!bis4_Km2+6N>^w>'
    'VWW;(eD2iN1MGuk77qY_A4n*8nD-b{V9xW~$3d)k^4DanD9i0vv!KfQ0rZZgw@M4qg?K4H;BQV&sKkjlLxiyQL78Ulmt?!f(z;rg'
    'B(px$-yoK<fQ=E(lJ^8LosX&-B9f^MSCqBDN9HXp!*0VCx(e*fv*{4s){+_x%Ft2ZTVxDY$3(dbk|a39T6K(O7}Vi0&j>^anF*8T'
    'n$9;z72lQ?^l)0b)MVEeICYog8nrh?;1`KPwC@y{1nzvtbQVDoF(+M@?P%d}e)eY@iD8PyB|572^TdRFyq>9np?5ar4Rx1JuUS=o'
    'iRgZ=f&PH6Yf*b6o~KsNgCa*loip7cd$y6qkjuR~YY7<@^ibk^xQ5*snsS%0O*)!Z!`>Bglt6*T*TRm_C;q9x@yj8%$TtdlZjLz1'
    '-|V2HObX{n)ci&Rdd|<sud<9{oi|!k=q6%>2Jj!T2Ua@}w5pc8tA%xn!dCK_^rEUUE<ZZvLvd2A^FW7u+%{4JO+Adg%l32=<RECX'
    'IsKHp;2k`#z->1L@+(mD3?#9`3Yf=YitSi>9;{u4Ky;OWmk?Y7c%>b|R=PUzaJnzNJ`=1MUvQL*n)Fm9lC?GE9p$0AiAxSo!`A^c'
    'YrRS_8W@o5>6G+W(=*K91oCZ?aYfK{ZyLKYcg!jAl1!KfUPj&c=U`&fNrv|tZiaUas~DQ9rnUpKu>*iqXJaSxW3$EZGGgKPI(uYG'
    'dTC)pcNcMFn?s^KLByjQQxk#?^bW^DpBjA@JiUhvqdJeEI@aTka-*^n2unEtUrp!#Wqz(RWdTDf#pTJOYd@MFL+Kg7(dP1kky<4h'
    'h)3e_QZK9a-MRZ9TS5qq2HDSmC$7jhQi$1>DsAf`vVs(r1lJFSHalqsX9;&q#00#CL(eE-S!&^=Q2{|3G0L$VKHh)1adaCr*WC5q'
    'Lj`eCR-O3>YmmbQ6>?q(hpjrXK%~IOY{-o2DT;@3-B~4*TKwhm-eb>G(^k=06bb1O7i{v{qp0wxIf!yo`VPC;5C-_p1nFV?>lDte'
    '|GW?AXAay8M^Jv(BwvD#LCl;c;xy+_BS<-5`TN#ZCrQ1za~${_HKTuFB^qU{<jWj97$fzcqnVECSH~V)TepEIU~qM(H5$JyGRE0G'
    '+7L^SX0k&#s~A&WzQ@nQ73-~-65Ep3bEPMcbc&`TT`4wZKToT<_Y8pFcr~SH9l>Gk<-axM4s%79qI+$%FjJ2>i;$`}qP8y_7&x{@'
    'kID0_ny`qrZU90Q5y0S@twVBuP3ifV8}=_mV`_53Y4Nt`h5VfO#ZPP4SW2F*faNTR!0b%i)qff$_ED3q#Gx3rlQd|kQ(n4}l@h)T'
    'L<=l_v!vR`w*t_O621)J0+A<=b)_mP!a5#b?hodwaXt^qj@WkYoS#r%__R5&pj)rgE_H8BJh7lmD-%8-Mo<p%jp(6ER+T_<lx<G@'
    'S?vCd37v$kWt^5J6#2_pH?R|{-S&+=I=S`c7r_2{4Nrn46TX!*Ws#1aDul!-q=d~8d>2-oU&C?uyxeG&M2vCf69WP$fo%>HT-gO8'
    'Wx|p?2|9VxJTxG|+Cy&hUS(u%R`9oDkPdbi66O?;xO76vHQR=xjd0O}$2;(l(F-5aPx9kRZkP^eJos)DCVS(&B0HS4G&;7s-rXzZ'
    '%eq6oin05RjEdBkDXNkglU^S2E~?y4tBl1@%exe}J--?`JFNt3ZX`6{Z9JF&%R!SdmDHmXs)@~Kg{fP5CMt+I8y~0D7Jr)^EyXDh'
    '_w#b2Z)EObT=<5pqX>E58t=_w6k1-o?1Gz0NMxbH!OivcGWLyGa7D$so0`S<6{D&bt&D%mnfJG&fi7(Ci~8XXrr_P<OPg}ouB{#1'
    '^y^2$1H-b6C%K;jgQg5_bm07a+b?Xc`3cit_Z-?i^<*Zb`Z3@TXg~AT)k$UpYRE%_@G16UNG0e@OVvAu6@oeVU@)XAcrKCquGxEG'
    'KTlpCxsdeN@?vu8$vdEvDOH&HXpBa0(>!;&7in6SFV?C3#k|lE8HXA>c~in${6nUYywMXx_2GHN;Rb{wusZTc0F}_`eVO-Q(IYP7'
    'xOylNu3R|BSA6zV`Ot1@Ix+E_v~$^mfSV<t8F9dwz|Tf>|C16p4>8D*7&EWih^>Qxi=3L0N{qulb`%CDPTTj*8Qd@#M1GWdPUzBj'
    '2(cj50{-YM@#`{0w7R9`{g|d1$eYeLL9-<0x@98@%HiWP&?z+udb5T+SqA);Kek?Cwp7}V_IR(l{!-eK!B$E^IX4LYUagEA+YmwW'
    'kCz!A;(T||e-3qCgcspL@JuKx5coO?cEH?#sEw4Nhw;u71R(-~olVQ$dUcOx$bo$jI<S6o>KdCgcaF|Zg={kej#;RD*A_=CBFPS5'
    'z6EK{_K#{#=8ZD~fq6n{0^6(My+QJ5$uVDcnOJ(6W-LCO>1g({ofRc)zr?+OCklhjf&$u!J`x!;+>Ki2Yg%&Nm$(0)XU<r$Q;&Pq'
    'PyVfia`5F2r_?%NwDz)^n)0RMRWfv!lu((PjwSMU0Bsf81~=<^pA^JUEIf3JKfcG_1Nv%mhj{%DAIP~Q-~lnBP|iK#&)loKLTXT3'
    'KpyK!vcBXq$mIpTP()r0*SViKOeDnn$xX0<NrOG!gWiFhNqJa;T^|53ucvo+<R0Tt-2@+Ku(i>gT)($Z=5HeA0s2L|(R^AM^<W{N'
    'fEm}rKD>=X{wX%#yd?Vj-E;X|v)5<W@kF}f<Us|{y0QBT^G914<itPomz?W05h^zv7)};7MA=j)1yS0?DY!Y;ANzpDRi803ujzE='
    'o?YZlp(>dQXiw&Qd<*d?B)Sj4E89V9&Fv>zXUsk44_{vNkg+Y)RbuW;N%D4)Qc?&fUO7M%RdvYetj<9wg10rrmvN68HY+4(=&@W_'
    'y<);`7zaQ7LFkp$34g*&Qx9GvtgS|(nufp+LWP-eCV}o#jIj~?be#R!=xS?W^kLPb!w3Xy^0(n--HpMs^IR3NVfDp`|ABcOv~y|k'
    '`7g7@(42`k0wLd-4-+;l!GAU*y0zvj9qH3~YmuE-xnqTMDAF?e8tl7mYL{_Y$Fs<LoE&hANVSlJlfa3dLO#^UGz%<+)H~ACLDQ#o'
    'GMp)T#6`(M*MOG@1Q;I~G~R1`k4Z|2cdD$|@IJ>0V2omdmk`m?R2heEB(wzNdYF%yL4=7R_OoZYBO}>^C}&1gkm-?}*0w~uXEori'
    'S>wKx4oAupBpbL=WOh(S)*9n!C%upDN&|J`eAX7aViq`T*d7c&`O2?_7B&H#z(5cP(7%3buI@|S1iQ8m05?B&pAN3q{DUF{Ga_I-'
    '<+Tm2*YdAK^VgwJcdR%+81}XSLBZSi6LXF6qZYBe%bjt)wmeIl<?PdzPVop9uEbm*h88dHa{JuB9l|&z*Ic7s1r|d9ot$qs;RtR&'
    '4rlnA_vTE%Q?}g*qPS=R;w1hDTj`G}CuZ$|RFZz$A|v@(AFHodqiz#PJv#sWX{FI;`ckzULdy7=A{~$vT43InR8F5J*{zM0=ym<w'
    '%LHw+o8*yng1}5Xcop~Ey90|b8A;3Ce<DC0r!qt5?AJ<0rb9G}0NHEQkTwX<C6uWfD}}W^TZnp~W;Rn+O(Gt#k8g~|c1n}Q5c0sl'
    'A419&*Zy)xxJ)unI}NB?U<wC$b$+iaEQ2oiP=_8iY5>fVU^;LjerqCYN*nh!W(>e$22IxqKi}u$(p2<$C<rirnVy_g<2>rX24PJI'
    'G&Jr8w$w_eUO@J(E*6*3LW%QUe~m|~u5@rFvkbW6Z+SgyEryf6<A4zyZ+8W_(3alxij+F9-)1oySXh~<wO|yj{Bh5}n20T!O0#Y;'
    'hL8y*IudY#Wi3~|D3X&|x8gp5@&v0&O4!knjinCS7({cb_?$Mkgmi{10fm|{Z_uHxs499}mjhGbsB!g4oS9!OslghGZF;|Lv&vDC'
    'sE_sLc5O@U@l|zMHtf74QcexlS9VfP2Y3%(Ss-R!%-j9ohzcI4RKlCB!EPxcE7Er(b3?Ovmkz7=rY~V%tH|wigSSR37Zd2{FDALg'
    'KTz<yOuJT6P#E3(0al5$FoElr6sZTe5IF+Oi*Kg_f!>lTfu05tyOf)4K^ySLCp$bk!uc@3^auelP^ZK#L$FI_XDh4A^DGyw`v$~^'
    'qDffob2OFLbh-tIB6<esfc~cVLC30jW_+B{WY`e;aPVV*SHv;V)?_<`vCyXzK8u{t3?M;Fw-!s$K}0#}dEY9mC1%<xP-m9>lne88'
    'i)cKe&9F(gwCg!f6N;{Zei-Hy9Rn{PfVL-IY15S{Z@5(=_*dG7?!K%Ocsqy~bn{_6wE~{o<oTS~;*9H8XNgK2n{zW40W=}nC8wR@'
    'f|fI{`905}W@jEo_h#4lpixJ|$#}4eo0+1{YHeb5;lsE6ANa}J_oNimSaeXuPDkxRQ_@_W@SRI4SZF%kJc!;r1UjVw&ktNTfN)7b'
    'DqAI+ev9~E2+@eo?@U|s6kDS;=RJV8^_~QaU?@3{B6#n$E5&?HtJj$q_qKL;c@WGW=HWuYz@Hu)$7G5@D}I|msjvBfl^=(1@o`&3'
    '*n!}UbnX26O{B=}!fd=n7qg1FXV0=L6<(G*@qd!qV;wEr*6Y5ypQr<_bdXmN$&W-BjJ3C**MvFmyFP~HboTfgI+aOgo1AA_9iil%'
    'PEU)rdBXe(!k1b=u**fa#oA>m4{|;EHx1D@g2eVDZcJU02JP3S($TInVk&rBZ91R$q%j>*-&Ykk8Z{=k;~mUPXj(>>=}@(s=KIem'
    'P4o31&X1q_Z{+{n!~5Zj|EH{`9^lH-GC&0ExRT^e-RV#`-o&B1<1~$>qmmE57<|rj)d}n%Z6m}^@ER*`L%_Rorw+Ck7V|GZ`Zj4&'
    'oie{u1-`+#Mh*<yZ<HkO8Vu8l#Kd<RF8>o2W<cp(LEU_xV&8p9-^nUxg-VaxXdzCY^;Hm@BMrs?x3Z`Eb)&8FpKrh;>kJ<*ahrS+'
    'Ru&zE6}0{J?zSD<pt3daOkI^>S!YS5`hPM19KUI*`)OUXe@Hs_+#UKi;>EpQjj6z;2-w>AX**P6WGHofj;erZe-~h5By-A?emX<y'
    'SW^7_F#>tRJ?B(K^(1Of^2R{hMdHu?@R6_J`jqLF(dxPM9*@mNNT0Bjce&vLj3)+I<Hty_Y$QC^-}URAa<(?`?L^>lWxeh2X48o7'
    'xYD$GcKZYFJN{FZbSD}!p(rYSf16P^UE70e3>%gE$T9yi-53R8EL-=fKQZ*(rEP*7nO3!43?PgEEu@HADWj~l#UR4vc<hmIWAU?o'
    '?nzj=a!zl7j~23Js2VnEX7DeQbb|Uhz-wf^)`GWNEUG6MFWsRc<x(|K*0%h+)s+j|Xd6`C4|3;Pt`2WFp~4jc5%#%|naL-SX{*A?'
    'D#ry;xaPd1=Yxw40*i@IQZ)@L-;y6F*{!ce1R5GCyJsIG<pl(E4Xnc$1xjh!a6io^1B9^nQ=T?tnp#k<LG9)=_vvO0A%--q!c*Y*'
    '5W30Y<M&aAMB9{-K{Lcx-n$svG}K=wrS_7eAt5YjhSmR53?MjyVh^uBW8&;8PZl@j*vtkvsmH>Sob&b8lm~W^gy8hq3rKd;fQv^t'
    '+iHb85<f+^MWRk>SZTft`32bo2l6e|)tNCjwpofYGh-ciVVTH)8Lx`ys7pW>FmoEciWE44Ja;<jSIY9J%{)UXDMeW?vVZa3qk2}g'
    '?Gs<6hrl?85x0nc`QWx_uQmn4V9&+qdemF5+(b_U5ZwzizaClT0G~vREp?3z(Y-U$$j*bQQ?X64J`dSj?p57d0_mE|`NiP1Rekl$'
    'H|Gr!aXEe)5P{Ej`MX7nRk8s0uzCD!WyNJ~85^Zs-JuG!@pE~UwL49n(DUl~v~a^cLRRM!PAaWO3OxIMz4Q(35+OUo4rh_7Ypi+#'
    'wsk&1BG}aCJ`VhvH*2=N-C1|-0UsJpJZvw3`;H(}j=@d5+k<vQj_dikrX|KS(g8mQVd>+OGf)G_COK35ZPk?aGb87%W@n+t+@!hY'
    'T?t5s9pPr=;xFuv0bRLwpm`M}bsHJL)lGV0SnjPLBmL|!SL^0jI%x{PA3LCiFv0r?kh15m;j?vZQ=`vpc8AzWqVl;$-!aQEK$ZEA'
    '7yy^}X(J}?DE{8-YN?<yS5SFJ!{Qj%kC!D2A<^yBYYWO$hJ}j9Hdk#UCjAo8<GW52uXUZEYeOS`F{s@{-!RG`tlvIFnaAL^Tb4fC'
    'OjZETPG9|^+6J`jnEeL-Y6({o)f2T~9;*%~D_H~+Xk4SPJ270hD0k`T!pWBrIy0veo=G>7o3m_ZebuB6F1Yw@o4})xa4RoYu<&2a'
    'nT~pD$&K8(Tu9vo_a?$T7_vct2-(rT*#NCQM-dqcWJK$n(N6nB@5JHeH<SQzGZeys07@PwBJVlAkGtvEJyv-q`Ha!9cPVq1LD-)m'
    'r4X~IIsf2W1X$2NmyC0>Xb87eSJ(O;_%#HXwRm1hJD?nph3#3Iz}nL?k&_LgN5wJva(j($Z;Za%L$R)xdCbE2NX)z#*28g84tuJU'
    'S>w^UrB5%S+4*Sp8Xu&V%!`{ff}o!jRiplyBF${eV#10+rssgja^E^^QzCJr=Dl@sFM_79jNQl)=PEWcW}^m{MXKwWJ>5=t@4_{e'
    'l{Q`s(n}!s?<C!#MpGmqVhY3n0+gsjA@hg{_0=?&+|b&dnRjX>?nMYCV{0sEaKSKA#O2Sq+`*H=e&H>Wk;UUhX<K~XB+CR1R7T=@'
    'u|XgUMn)y!a4*IvzODmh+$xamVlUeT6Nh=1%?nb4uq_e?e8mJH^*=D>0a;hDcK6c?*LV6w!KBL1P;<K=lfdocjBM~LYIY491Ahyi'
    'tnZ&Ir^P<C9e<pF`DlI;5i`d-gJkqsnn|ZFcv#N{(4kYmZCXz_IHyVJZ=Crc!(u-ffUX|scIedKNxbvL9sQm~4f(tLvGOdIZso~V'
    '`urG!4$)Gx3Qb+0Q<jD~que2A`}ArcB0`3u)LpTq8t5v+7*ZO_vm-9-6)1>(P$Le5W=Hmp`JHZo4~6e4@*7n@>1)_>0_V9ftplot'
    'Z&R_HVK$>&hSV$hHin+SSDFuZ2IHF$ez2tHNR%qEXkN#(s@KbWOD6i+A7XrAUj<{B1&~4>Z!o_Cbf~e_rs7Y=Hk$vpLIj=ZVurL}'
    'ECm*AV4mBj?R_cMRUyN>y%AxNkC&lp`Y>z#lS<ab@zSUlp&c4yF(wa-=oWPCnVlofD0dp$qLhq9n`OsUR3^3*G@~seG$r2K>F+UP'
    '6elO}5mR1y5rG~KY9JXxs=jJXj3o@e$XtVVHE1PROT2;w(QkAo8J(jdmY&}t`QYZZl2^)Lw2@vnD)GxK6}k#np%^JF^llrq<Tkw2'
    '<dM_I;dw(NDAo5kG-V%`r3G>wP4N5FF%Wb$w=jg;k+pVdyscvo)3LfO@WoU%g_~MR5@r<~6~CbxY@ITvz<+9^_keHC`9L1u936=9'
    'q8vi*V|pVmgDy@0S(0jt*DOO;i^69-dX_4g#p0=e=IUAuyFuz_Sqc7NTZzxBL?GpY6$B`t=qg**I`_?-?HBiELGm2GqfB%&+SS$M'
    'D@yj|NK}?Rg#?)V7rv)X%z>&1y4X<1?sL&W<F9OxzxIy|;s0*()!s5zj2sP@AzWNp)49S>B%oC13e}!x6<ZM!AN7IJ5s%f#GD<W1'
    's6RjVR4Q&*R~qx(;;SvwSA&qEaA7DB+G+|~qKV<FFZD%>*NHQcSY_NccxjLMQ`-h=eoYK_e*nEoL^+8M4XWH1;YZ5K>6YE=M1ys}'
    'vJUOTRknNfw7TSr52%iG{dpD~sX348s9?{8;lA!^c+j#gC7yTtDm#-3fd5>ftYs@K>E)r&snAb3o`mE#9WjBo6(%taBTePdsp$oj'
    'U%0u2o+CBbBEOf%2Hs_S3<!d|L0t*{kT1;oJ3C1n^2pRbdqyM8xaP1S<^gRwBnC1(5kup78$`V|wy!;9M6f4Jhq=3o+T(EK^De`S'
    'cUrs3WS1>1(%Mx{BPB>ac&Tc&cG2Q*avOr?MpNH1@O1tNIbb1JJG>;LYR}Wc+`ygU_08q1=fk0wU7*}f{HU=juR-y?ndLgR$|Dm?'
    '1YP4sOvnKTU>4n|zcz$mT<?R{tF2m;<}JhdF1RNa+|L>>82|Yy-Su<1Iz%bFcm^PsN&s=4A3g<QeLv%@Wbl#&#?FncCYc{$;bHO1'
    'mHg|dmwOJRSIjr`V4ipPEK#gjy&>Q#j!Egh`+<_f5bN0jmhm#9$emLc)I;Gb>EID?Vv1|CFHjoj{E`MCcfdW4C!%Y&JJ6Qb8+l)F'
    'IL;ZjB);bUzR;>~R|CQf=>5os=1&F-Uv5e+c9?5vkwobAgiV*bNcPWN#efv<)BM{8R&iskJMnzQ-j~xUJN3b4)(XHlM=F$AGA6;J'
    '{lB<8>Z*)}9ouq+Y=1v@J_wa)hA?-Ah9Msh%zhyJ^7i6Pl+2Nl#iixE2j;uz{6rEeLy_x7S=@LQ?5O9%c;50-&^0z^6{hyxT;=%r'
    'UU+z_NFK1uC_q86vg9J&(qLl6c0lOEk7LldFdfLBzMAct-+$&1vs43S@?>+qt2~{a=HBkcVf*E^8rP>w6=|7KGkGNp@)qJRl(K(2'
    '<J?si6>TQuMq22QZ}_D_^$hhwqB?8i*}w32lcvPf-ENlaW}wqT(6QX~J;>q20<*t2nhbNYQMMWl?FcJ|Dc)Ss<}m9*1{k5%Gcgn_'
    'r+skh<wSKfl=oF}i<)_Oxf$#PX+^)$E?fL@sXmZrGJp<h!{IIywaM@{8NjmMml+Kv6`jDx{RMltABty-a#mp|TVXthPgNACG(jIk'
    'tF2%IViOV9pEi?*>rF**syn$tNxwO*<mQ~jz3_y?@G8Y2{5PggvZ3$P5yCN-4F<VrapBKt=Rw#E!lEafdH7EW(g<8;s&X3*3Eyw)'
    '5+5Z%lcxt8ODhH+CZaDr@Y(H96+&*BT~jk_I6*16|6*%{&~q(A=$Z9seO#w|HY3lc6xXbC?nuwc6l*7dO{jAN1hdmte^}VMGFK^z'
    '>69=+-<s5=iDM+pWSR`gUO-I<Sv;~`niN##4@D21NhC82nCrhAr<hUvxuZGoNFdujSEVyRjHtze^X)DzpQ<J_$PiZHU0vDm?*B)1'
    'Tsn^zCb8UqAQhX<gM{|K58~d13Mxc2%)TuBUJb@`;G9yfp~?_adjVbF#OcfwI*^;PP^E+PZt^s=efo2BQQe183`bea@@gE%LfX7n'
    'MnYgByh(7M`*uFTWRnJ@eE-X<e{(t6J<kM>A-#i;xD&Th#h9;ZTm7;;1&n7{wTrO>bXhKE<JH$XRCsbqgbeL}o0;Bm%q`_q6-fIr'
    'f#$ShchY>6C=DEj2GM%)rDWJaQi&wp)1kEBFdv)+9o+#rH_uf1##nj@-&~o4=^D`YfVms8uHi&PGrhK%S^d$pOiNuqwRulDPGC9j'
    'Fmu25@<YoG0M`tM4g7144k8O)C7GLH&JG*F2Z0WTk(F_>WvVIss(r9v$OT!ZIJMdO-FQ3Q6#eTznKsIE!MI%OKJ=O0(kHm)`0s+<'
    '--9fi4%*FFT`xS1v=R7-EW-OLJJ*UWwHhUHUNfjhV~VG#ix4ifFrV)<cfg;o3LZ0mYz3El<%v(c*M48^=(zECm2P2!MJ1*gpoDA1'
    'x4`fk{uG#;E6>1^nofO{vJ7eYUXWzQC+hD9`t*Bgy{#utx2(U&W>E7|_r}=qkPVvt?^VN#3%PsSw<h$&>m`^v8{|6aeMnG#JGJ?X'
    'ZF?Jw9Pqqww9_eHkKr-8;~qO1bYT2$*y!QkYH_-I?}Kx$hM5Q)v2TxW9E*2#2E13otP=zjI~pbpS2FwLz1m(l<?!)JiE*R>?kEg*'
    '9}!q9_ogRwje;o5kDzgt;*z;OOnDn+zCI|6{jkm~3PY4cAS*xXJw(+5Kocwy>TKGnXnR#Non8H;0W=4ka`_3#LtS_AX>+ba0>f<('
    'CMtiAgq(QzV`b50YBn;N<-XPB_>biharCL@@hJmW71XnHkftF`RC*x6@fxYUeOD^vN+3z1eZx@U2*Cdy;b570sU26JBkn9Qa<(L5'
    '>E>*^`a}jDBe?KYbko%=OqEnQpou@=w_C#^O0I5`lv*#nZkk7QmS6nOVcq4}Sx<=ny63}|vqf?X0JL8|xWBj$M)3fK0=_-3xU)n$'
    'G6aK09UM?}%0y=gCG!|VPsD#28(<u&Tu8-W?rnPg>-$B4l@-0m-BP0jVKr-66g^2vMdt2gB}k3@UfHmR-p|AKwm}0@s{~F+Ed+fo'
    '@Cts^SI=9Yx*JVPM{yqnm*G=b@dPDv9emU5%c)7lbS?UA2N8ZX5<*DowNyyDtR#9um~OPA^2CUW54QnL9-Ch5wfV)tKC;BbK3uC6'
    '4)SXLpBzC(cbp9sQhB{m=B!hP0o6A3Q&44U6LC8MbLjvZQd(TWo@`T3-Wn&cgulQPF{lt2J<vBTkjZ&iGLN?Q9vx5t!tn<Yr@z;a'
    '`E-n{VzZ;&&id4HY_|yIi0_Ya(1Qo^d%yBjq3Nz2Nn`<(ubB(1Gg#r=U@l-2x~M-Ys4x`X9{QJ+{2O<n5YyT(a6%+MZv+Y%M@*MP'
    'Q95E!zK8BtDF}lkmbt-f;t6TQ)J}-){)^HtJ>x0u_Y&ij1*A78hXmTm;sO>K#Gr_$0*>~;Yo&SP(YzcvjyA@ac9kq2!+8Er7X7~A'
    'zWl6Am>=q@{n(~)@&Jn%ToYxqjOM8^)Q!qQt=fF5R&Wu}uix$3;6Yv+*lRH+r4Lyko-wS9QMxGR8ZI^Yp%1vVvm(<kqMONhc9gbz'
    '=AUOTJeEK*u~`pZ2)jw<c);vTy8eO?1iZr2owwnC_j#QZX;z0sVkn)UXHmdrE`N=<y}SfF!NKeWN#|9HxVXIQItE5qj439(3OC6}'
    'T)Ao>2y65kPimbr$Ww)&JnW<)Nd>lO<euXmtZ#jnv%BFIrnst?DtN(X^qmJy+JAIy8;T_n^Y38H;Nh-6`X$r?27K8(q%tz=crb%n'
    'vM?GvlbeQ<Twk=3{HzZ&L`Q`<G=ULJi}50b`w*>VbQF~7#ARs2EURpvA^L=47|lFruvyave1CJ;8L)OLxPJ~j*Sec4TAHXml5HH0'
    '>M(<7rx!Pi(D-|Io?$EaN_O<()U^7zchA~uo1tg_Ln75=pC8e)oN~4JvjNSnf^u!YcJ*R9MIH_I+O>ikl+At8ISrSU;5&q^srP$8'
    'DuCMOD*i2#o)~n+jYkp#NwPId+B3awuJTH0;Beq_tO#H{uthfSY8!Ei4{bJtyf)E@JFh!g{j5L{z>uIIkI&5`FSz>Vk02ld;)<~4'
    'fbq~ZKmyOhIit&`q_+lijmX@~OHTy-kNL>lg1%J+NpB>;Ts=F#*Z+!owVA@m*hjeudSW17R)bYB(wRidpr_eIlfJ}g-nJR`tJOAu'
    '$;Qt%{8CgMcC$o`%@oo+A0bAeQYPV=9AM8JLJ~=IV(#vzjMESLuL^wEf2)E%RLtmiJ4MPX)C+vYqhHKHV)({>%_tz@fZ{K7@yFZk'
    'YhaC!4aN6c0|<o&c5Ozj!qcK*b@cGGWiQUG!yxYdV7@aZ3gf5$)g)uHE)brkj)w>`ZiO=|JOZu91u~LCFgT|RXMhp9U23v!<zH}f'
    '+65Ih_d9EUV-i=WC54+NouA{Qa~3Rxk*Ny~m4?a%F6vV{iSYK`tvrCM1%rP;mBb&H0ye9PUB)E$KAw1um1>2pu79=_mGU?)!Y|w_'
    'RfG)xdP@!}5+0*CKmKeIaQ>y<&HXVnmgIetZ8RKJrzwfd<^i~dGn|vN;D-a5GnG`1SzR{5u*T&#`%)2japL+9nJ2B7o+G^78mNvZ'
    'Im{>}`{V6OIjZsm-N|Myh_eGQTL5?(u(1t<`VKd}>fNb-&gVsQa<Ce;92~4*&cx{1|82GxPW+}CSirfnNxj<{)gJ#LyzvDWcQ|B('
    'W8gmqbIj<UbI}}khxp+HbFA5XqM7?q%B%C~y|8+^1VoRKuyyE0I9}5~C^xX!Xa}ylYhk@^mB-Ryze)G`o8NA*pn(0HPjH~kgk~9Z'
    'wIHtdE*g7rg>pqm_=SisOG7F}mHU*&R99YF<-3Yu);gAbcqAKsN=BD_HVzH&-v%G6UB5yHBiew<lZtBcw=?i5FKMzPoyCCSr$db|'
    'S$XB)rra5(lh4o%+?gow4`<HGM-p1W_RkWa(_3M>FnY;yw*I9cYj$6fnvfZYV#+N<$S>;Vj)i?6+Um4f_MhW2GsFxCvu<wQ`Bx8='
    'ktM4bI7Cv{#(kW6hATTLq)z6zrz)8H9ydrl&Rn38R+uIo?oKuQPm{=^gf?A=J1uLOK67lf`VCyfpJnihh`Xjn9WIwAOQ91ObFIw#'
    'CrlS_Qq=W)Y+R&TNjCMZlzdc5(!NUx;cE1T_HM|_R#pl)JCeU6l`#g!=czDiRzYt%?uH0Ox_elgVP1t99n-4?jD~y&NfvidH-opB'
    'V?bBUkigCYX*#wHs*f%L!ceQs05@cO+`rfZy6=Kp2Bz8g`B<-nNypje>^aS&)yv6zwUNOaw#O&FvnGqSwzJQRGU)7;Sv0VOTn0dH'
    'w}!&|LQ{Gwc<0A7jci3qbJSCmd>#9&01(-iHj2ED*DJo0b~W)H4CGZ~=qWxcs&yuP<e^Fz=BY<o!r=Mz5dnMx&;Pf0KR0vtnDtO-'
    'm()it_B+W|daG8c#L0N6>?t)bW$t~JvuQH|2ahWX2mtO<0z|xqH{<843~8ZVMFu7!Qj225jXVydq5fMCvbR4*t4O8-$e7U`ng@+U'
    '6j;$2H2csYeON(kC($4+VLe?)iB7Q(bY<-62F?=xg+X2N*TPoZGG~nPkgj+0tHck_?3Kq3Ql}2n<papLaUDmb7}}%Q6w@Ko{4<NQ'
    '+tjJUKjod3n#3_`wbbHf>V|^a$rOJr{;^v)H6@bWRFXZ+CNulyi82Tdo_l(feiW)o{LL0hzzh^6!p!X{2B01S9De`0>vMY2Q*!x#'
    '7Ma)Oiwt-rNqgJ|AvBS91ra#aQyDDx{I6`gVH%FCM0|2}*~T`&+KkPaH-XbC>Gqm+{D`-0)(w?A_K7~#GMwRPY{yF&A@l0mCR;yI'
    'U(E?-hZGzKOeAmU$C#q#9nk@WViTv?(N&+e0(e;Dz)FN-HGo{(x~TS(*T)MF#O$Nw@dy75>oy_r_lZROuBE++thqt4Y0@}sRLhiA'
    'S#2M1)ZMokO>%;q32P#ShXu<$?R*R^8yVB&op`Ts9LKumUz`4S9#+t=myvIYcqRX5;kg_+N878;1lR-8CV&40B03J&3=mjw_o5#Q'
    '&x9zPb6$p|T`FlghMG}A+fUc2l6`D?{Q`*(or}wfh#1W3R9+QXs;XM3rZ;oMM)5Ea0_!&_5-%|=z}W^W2KsY%^ZK`hk5N>4eAoJh'
    '%W+@RtFz$`b{`Fk&3Eo8FVhss<Q)9AZcpH8z@snUpLy3Tt&9;%qBzB^Pp;nfA`hwIKP6`5Zaq*dQA5D!3?<6B%;RmECSJ|m25H;4'
    'ZhHOCBiy7~cDSiM3hRBCVlft!(ZPrT5R!du`0h^KlJ9p^WPUe;oem~!#<Cc;qiansOg3bA51@32T+JFa9{!O-d(F~e$E_?RiPPB|'
    'yoC_>+a!QGH56FpM<F23P&O=lJSD@UC7Y?J0~|US&&Mv?hFg*r*Q`L&tCzPtw{kM=XwC&Mk`vkQJ763<<Arc7xNmk2F|bHQv(XEI'
    'IDe40rQ=x$M#vnTc|*v;-+sdnF8adO=dp!#<CwrXIzqRi=u?(lXIUcZ7e?k~zM*u_4eCy4=hi!W)G0EH1uv!m@PGW&t3KgKCFt2y'
    'OtvYBnQHH!9^sCgZV(aLLvu`TfJ)Xg5)mmtdGOJ={rJ`-d*b(_B24U~@+**=)K)9mSS>*B$M68w!aqF|3L{l<r-<L0`HD%i!%1cD'
    'eTpDr<_fE;TD{D2P#A<2bG^N0SJ<I<e1x{+gsy=abQ%2<;gM{)*irI&t2jG_nZJ(`@#(X`f|^OEQ9GDJP;&U{k7=&U`5Xwqn9||4'
    'j2WK^ZWw(BSyvi5=?qm~tf@x7rRP9|_Vnc4=!BkAH?zb{{@5;)Ye)D%x^?a_ejtdO$5qwD)<|f7NO+EKphApIi2rd|eE&v_EVp#V'
    '&|PMB+=R>fzf@9`xT{mO&(T{i@k0Yn*53Mw&Ayq26^uO9aS*xoc%D5>4JAe2kE{)uOJK#H=$u8~E}H3bytSr!D^h1b=$`TrJRv!u'
    '>n!J;6ZI(90x-|Yuexq=BC?N@7L6yIlR3u2MNs=b0foJ1FoeFo7#4!!n0sC`*l@@rIRY+kcXdJ26*~d{7fR8>-D>Q*JvEWh#mdLk'
    'Z8{P>5=&;#kP^upY?Ke5R&G<rK{LwumZeE&kNHDg?s9-S{`NP<G#oovQ9-UN4dg&S<f5YvK(L#*-S8iIrynXlYt8dP)Xw{gBaT|B'
    'K~<i;#2Ts)Q`NC#5DKlP8N}eQQeV<k0`^-va_B2q&7#vIwRxtJG$Oj{>0^jwiNAPF#vF66X3MS1&BQ$`)`)T4YaDVu*5*AdTG#8a'
    'QL-@vX8T%S%-#F0cO+gaS=qKL6eo0cpjZLvMibH0e>cbzUd+rr(VsVaU^~l@l}i0wAXUV_>lR#}x@y(+WlT^O<`od|hFr7MxWVrk'
    'K;e%&3kL~0{M&{AeX^+hjnM_>PQ(w=t!cV|C>}<n{uZ2Qkrot5F=T2R)ic7Pg#p+pGQF{`u=H)&zhQ)i@#|ps=LpGK_(0c#AxtUp'
    'Q{g#tuJO`+bFkm##Y{R3mVonUUj;TTScZ&x_#WXgVIFkH+-6`US?uRT&C{HBg=F0ORBL@z)w*FpC8QOXNZ3z&<|JQh8!!Uzu!+9d'
    'HU{6+`w#dFI7wSJDpV;cF{&?}q{Y<NnPFG161!MjH&U(SjZ$>?fE7osL?2JmU)}pL`tJ)wcZe?s7!U2uCgvQ#jw?YOEkkZn=a8D6'
    'F17&A0a;f0f%m2j)jH+GL=5Efw9P%^P#rDH`$4HL4@R(iu}WS^C!Zu0S7>1R90l}(eKg2KdafgaJCV`acd;AwXn3JT*&=hH?8OG8'
    'rPA6oY$u^H#=&rU?;3|7d;H<c@+Boj#e#H*g&KKY0V2PMkm65b2BzuGLwgU{f>Io4;>!B|Z#Vey&V?bPOs!0zHPC32{F3N*x%#HP'
    '7=I=^x#5PCi`YGVF&keh!oS-lb;T7k<qH6q#dXMJgLYD#7f}X&>24o-VZ9Q_p^2nxt0Ch3QtkXg_y10zo>&9|aC^Rq&s)#Ss^KN^'
    '(1b~b?~@YI&)T?wNs$iF^gHv~KaM_TxAOR*R-xzMdDIvr4cU?BM=qyjfw6SLYinunOD{b`G(^3{iae%WK=5mYy_gZT2ET0%!;+n*'
    '9}^Li>!lyZni5;HTP{IEQ5;{wd2;flO;H4Wd0_sH&pemY`VpJoxC8mNb*xtM<mia^dw8X&a^M9^RhnirPr)OKBXNkNyKF_88r$-_'
    'vcpV?3dbq)Q4h^g{!QfttW>VwT|6Q??O4R67&X?x0jY~9b^;AfJ}iUf>bnjfrH6F5J2BiuH!)SzMkmY5PHo0&Y}GW7+(|WtS484Z'
    ';6#6U)&#lM30>TZ#|o3nA*lxj#x^td<pRm~vZSEwM?)3+E4Utn>)Yyn9fcaK+cv%kP*ocNAs_$IhG_l0m1!z=?xp+D3KGK=r}xv^'
    'i!hCxG6;?p-2y|n^=g=c65qH`bW@+Fo?QgLBL?9p1`5`~OC<+vh|hq2?3W>I<@!X2?h+J{SdMzJ>bUAT=1sOPaI*7*()_Vy+3|<9'
    'zWEe+(<E@W7>Fzd!!x<@1w(PE!0LeqXlB!yaZ+i78<t{FC4Vxjx-AZLl%z`C;O6!wd=1fsFI@fEw0SegANun-fS^#2l*?=c*?6a}'
    '3}IrHN9)DEO{wCCN{DF|81YPN>PFm5qF~<=?#rtD6jNVBAGp}pIOe#yD{Q4Y8XJCz*xaDIe>*Q6jVr~xby#;2e@32x=C20Q5mE_k'
    'M5dL3CEy=M2&Bir8uZwUUbU?UtRgdf!G@m_^*5!)TG6WMedXq`be_W92#@*$!+Lso`(kXQzq>GHu&Qwm4!S8~Q#ow@!T48kIfZ%('
    'eKb8tbdb$@9-!LP;hZK4V-g*mb`ih%#75{iW1ua*)AxjlEgX-$C9-yjon%qk=;T1s_`AZ9yG*tMWU|y9*#6_N{@`rM+Ihkhq`75d'
    'af5P9m4v#VmTzqV%0eUsxN6q;_1)HCQ?{s`e~$y#v*<n!W=f8HID86%ssQ#N>7=B@n;qRHc$~!y$tYrkPZPiqhi!l|43K8y|G}Zb'
    'hY)Jc+8I35XQr%#Wu(psreb)*@61W?_GT3UW?Q0G;|`eEi-@NX?V^;mdpX!Zza`nOPca68-)GJ`Ar^V3smB|cBX!+n|6n3c{4=`A'
    'e(-iYQ+Gn68~e`-CHm#gd1A+%lRcGS{>O*aW}!-AUDa$O)v8E$bBQXh;5o7Mmuqb8!#)oHdwf816S^w|Mpw9!>M|)7v0BUn(=#|<'
    '>~Bk-(9<5`^}``!;k6dxfj|UW2O!&WVx$<D?8S+LWnrn^;X7|r3odwLmlRvg0KD9jZ9Sk|QiDdISEHE&SxSNmF)$<UqX0Q%hju2W'
    '`MJLqhg_bor5oq0`DeKHLO1)6nNg_ws+Z>*L%2;*3vfhsGmV6_<1Nsh=*+RP$}01FH)6E3Kx{A;j*$jz{EN1FGaN;i?={mWJ7V_e'
    'hC26>5I&(_{iA=}Y=x@{_)Q{cP~gE9{ZyOykj-r%bJ2hy9oJ`<WC-qOG-x;nAJ#4({f0d})cm4k`{bAF-DW)QNoc)-{RlbxWwsT}'
    'jRi8ofiwpvJuOEIdX)hKGZ`XVm)zyj<!Kxh-RvvNhGo8DBXn>l?Y5QDulE{We?aRcoZm3Vy{}$Iau4hiodhXT#vTa1vz%lqnHjs`'
    'O*#PhFq}P@Q=1<AyM=sn{5-a$CVQwsBP#pT_{`_y?K{ItkduT1e&SFVRmK`GqFlz4KVaPN>u~+&q&Rdhy9r?}=79<G;k~+^1*Jl2'
    '&sP$l9ZLwpC)rbl-%bZ`yF@$r##Sro49$q~A|d~qwoGqr$z`_kwst4Sb@+{xMr4Qvmv^w7@UuItyNBgy1MV(gPR?L>N_OU*r|bSa'
    'A@=)?EtGmcdHa&{xyGv0`c`@{2zWT&^H(}KgxrB6FC~l}C~Y4MqLXN4$es6`?eJy1^;?AL4L`~>rg>`LNcpIt+{x8=5^d^@1<R{r'
    'Na!NCndNf~!nz(Ey1AccSoM|3L<Yg=*aa=PxpB>sN$!;`!?TQNs1R<SY=ni1S}fy|Y3;u664qTG;Wln#Cd?yKY~u#d8VGlX+x*UN'
    'V32U_43@bs^<@~^^rv4lLxyA9DLWw7L&sRka}-!PORRI&A`Zz#{sNC;FT*xBlqGFpuw`8jvmS)y`{qXS6oj}%Ax-~@1L5;}SABf*'
    '7WCtn)ND=&o!t9998DU8dY6QjRpQBAt)Eg@=+bb@s8cCVN7*f<ZpNkB+#kV-mc}V3i92jB(|6&!w6PZ#v3L>o6M-zSo&!;vCDN1$'
    '<N-6z<ZLs<s!22A9y&If=tH0|8H2~FbVs!!Ku;Rt7=$i>bPbb30fQf*`qazS31KG^vy?fI(24KEJDf(z2-eLdg%})KX)4(f<89x7'
    'UV+wnBn_%sT>Zx@07y-uMQ$D7WGjl8EkF|x^9(zT(K=r2#<=1qXf>3?4YA_lDhN0VBca5a<X`xTdqin>Y`DE3!ntZAD}Do)ed$Fh'
    'fc#$zWKhf{bF|%g9Pb2X^ECPqh84Eds%jEZEE_J3fB{1Q+d$G;az8!|wM*uo|8S?r{4hb(&3zocEVJJs@zrcN4s`7Syk!N(=bF#4'
    'a&15a#Yb2~u#zj*kV54+mQV0UY9_zEbpKwetqBOqQGyRU=X=(Bbg%OW6C!%Wvf|_BHiyV47H47zJlZK%9ULrA?(JxDCCPir`gD(('
    'EzehKUtdeT5}oRgq3Ty<;wq(cHgD!8B2f-;>Ae7e3M@}+2{ohG3>+*+QUeR;zcfwXyne^y@#EqEqx=G=mJx>YOp*d6Sf!rz>O%XF'
    '1+Mk>GK#9sO^+J#N1|ax;Y+GU1L-qPj4AMoz*+_2hea~~OzR|xT2<LrP^cx$h<QU=9P@uo(zrj^kwT~!YCLEN@aqLHAu&OkpBcrM'
    '5hNi4Q<8o~g(0G6?rY9v7A5YL?76GmEe<b+PfO6r#K!l(={65i4XUBtVI_w-lzjp;Uw-*MxRxjO_x?{C4CwUjof*_SqykXOe{r4O'
    '$$FZrICT@87x+8<!G;S*J2)(MG+bU%3k+0b+D`-ZKI9O!1t@MFEj~Fh7{W@#HOd-`9K)j(zu|YyA%Ag#IAc2PZVxV02$bQZBy!12'
    'EE=eiV}>Jv*rGdR9*;Iu=U0+dik10wEuhvxHj21Nf=FAF^k}(sg5O*JUD3`y0*iq&`g<nl(KJ0nNv4!9?EU^zC&0_C8*S8x{xuM2'
    'wI~=Edga#m%PmTh{P3RpJm9QG9j`<Hm~&XiKvjm4puP;v4%(I%JlD4Na9GYhG8LW58shWTGN0kp8)L^orO+rIRdi~Ttt`;8Va?i*'
    '@qYeghO3c-RVeTx3Y2xgEtO$INtvh^GEAO*KN%nGArzfGY7|5mpW0|CWgMWBT5H|oHkp`UHDDL)+E;D|2)JHH<Tm#r+*r0<naT+W'
    '%O45W3o3u~yS|?G===&5>+C!+fcDFnSR0`LkulbSkWH-BJ(y$V^6?Eg^~gsWQ#}=#$Lj2Edhi%2x{}X#s~zH<@b~OL#S&Xnj{e2p'
    'YKt-`Y4gxv#|b-PTZ(Ox)*Bu4I~Xlu-bc`DAwiuND8_!OILL^8ovl4Q1<;J6L_;yWmoCxp(48`w`L}#<Ac=pYfO&J{BR_Fd)eEdf'
    '-F)<cbkOV+JO+;f`_EvX676y5GG#VUIX)$pE&C=;&@BFn((il@3=|80+Y9<-?1Tt!G=sq~(e6jK(UF%xC&N9N>BUs6jya0|2YyuB'
    'hG~P(j{?=7+^|k~-qP)i^6G(Wd6p2RyZTx7r~nG5!c_XIRA!R9U)`9fb<gy&Yt$1EvsJ(Pk%A)zQo9Mzm$$VU_m#vJS7<yyBu<HB'
    'unezXKK59;81(c{(}~%-J)-SvJ-3T?%4+G6OcEnU$~%%<Q!P+=F8R1Sy53{%V9i)Q?BQSXac1C_g)owx9YxqTJMuyETXMrYq)8ic'
    'd*W4CJG4hl4Jl)^p2aMTf*rO}p~q?UR?^7D`H~^I&}ro;?BK*On8{?}mTdS7vS>TZWs)kJ^SKHWhlQ8v99ZO(HJnxxg*4#BnKULJ'
    '&zTg0Dtje+gmdhX&0jGhnY6)ZZJO}q!f6$b*1xMzqfFNO;M{+VUwRBWZZ+v#vui*%IfYWV4I2P5gBcDZ^MCv)pEb_xRjeJaL=N1{'
    'K_}R!@&p5@=ylQC<lqfR<#`N^l6Q0JM4Ev8N!%KSx&y?1Y^HH7-u(Gt*8njjBo_*&nCg3=-5|=V_mic%M_$5sXrh-Za+&MCNUBrd'
    'ZcsP00oc107|$iH9n4flt;_CqQ+tJdzi`sS4>|lw%>1A7F??YTICK!6>Km)q*E_2Z9hMF~LAGp**%*<YS46KJj@TKpNzWCU&uH=l'
    'NH0gOgunkzeuRJ59#bt%#>>(q<CK-}fu%ve*w+WTx=X!I*rDQ=Dc{PiyXqB7xcX1YO^Jl>y(coJI5Cz!T&V@I9oRG@4;h^9rHqW7'
    '9BHkJE|;E}`WGW!rA0&`W^-VRl}$yhJrfp!Mrp@s-4IN?*`J%f57F(b3vZZoPDnz8an%d;fe`3F$ziP@sz?nS6fT`!s(VGj>8*Gg'
    'dj)ujRw9Ws+}V$K3{nRp`j__aXr1U|lIg0>o$8DM*KCZ8)(Cp>wXU<m672qgMM|E(jF#9c)xZ+UL>eJk+eAfEnE~fAf9&@0MWM)#'
    'oyGe<h07ob*)^lqjGB3tCjwI|?e|6G*U4tL+ab$itA1nXx`6jhD|2q1Qt~{?W)CI}c#{<o(?tie^uhl@ekYH#bAwPqTZ2!wi*jN?'
    '$`Hj`2&V;8XAVrLM#SVL-VMHuLm(xba+D2;6VCBcI=G&xh`%9i5ut9fhnnp*$TIKqTt9R9DuSsWa<9gai=B6HAn>y8tW0RtZ)IcD'
    '_43tS4A$sE7<=E8RsGiM*Qb1ZQHmbO@S{5?m=-8jGVk9x<zX5}MZ*X^!4-v0NVj3n7@x@0%H~m8AGPooIr;))cydE^=C#l-Fmhnr'
    'jHyjfs~SAw!;p#d_dV{_eC~7*!doK`1d<R}#%(>$Z<|8`+=on*#3HlKZW&7Q{Cs8N2zbrRDw(cW?~80sMKTu<4VZWFS>v#>$90&W'
    '^jx(g_ejKl>G*03JtExU2@)<-Uwmhr2iJR}lQz(+SB+Rv6Dw5rKfNJ-3s#joyAuzGUgKz;$&E?;?__Gx-usbo()*6)&gZK4V)+_v'
    '(1B_zDK>VN#e<`F@QU4%EGWzxih_~W))fT>fqs^Zx_Piy+#IDQ(Hxbi#cNXdS?~LhU_VN8V3hEUOzI*<n#0Bl+Yy>-yBZUm#bExX'
    'X?IsWeb)iPo=?fl@s~&v51lm)9*Rc<=0aiP)-au2jKh}BCB6Icc4t_)5$(}{CmTHhJg1D~9Y-ZVv}}9`xRQVER&E@SPSaMRF9~nI'
    'XkF<|L<QEM>+eRAH5H_Dv|EnJ{c)$^*--VdVjWZ#e6lUoItj+uGbi_+KIzL-qc^fY&E~!YvGSw%SH$JiESUFfq>f-)iSA68%HJeo'
    'y5Le!fz)guB(b!1LOnYyr=JRkw>~Uh2co!#=4F84KrEW0s<!VJPg#H`L})F6{Jpn7RL?(G3-#bSvb`lUx>(2ii?f!cuj?rb9Yx+Z'
    'u^NUb3K%Z?@-l7Z1KbJPY#lFcMZ3Bpuf3>WCOo_0-CG0NO-D@>z`_)EcGl&;)4G5(5lp_;&JMk%^xeT-Ho)8HvwTtc`txM<fq-u&'
    '?AUpm2scHe3Pc%yA8VA2oa7EHfAU?}SsBIA=}vH(A2k@~74f^TH&;i9b+#BA4Ja7HcG2ka%a(^jk~=G$uFK{i*4s9al<eHJ?zuv8'
    'HESzmKqK2+1Mf-No`KR9JExu2H*$#aY*{xl{bcwN<?>mu%j2~XUQ*~awZS<omO408q^+FFt__`gq;f%=>fuAC+w#ZJ25A$dZT!|n'
    '^Pk{9!WvmvR=0U3^Z9jP0x>Ru)n-bWO8ducu{I$K8Eaq?XisI3JVO218XdWYaQ>o6V#<oHh^N0Xm0Pd(G;h8;4*<OO^@pYa+WuMK'
    'W+^loRu{yq57A^ArU{*?6Q@e)hX4a-_&i^=Q$mn3)@~4%qH3xD)N(JT>l`dOk5$9{{<YvM<DQo7ZGN_cU#(WJaL6=Vwmg$?AI(Yf'
    'aal$cAph}+<r=csUio!<OVJ;GpFMXc+u;xh^5={dUTexvRGxEej>8$ab1<M#jNw@DYuorr8Go*UaOQ0s6_(4pmNwD<AKwwBcLP@T'
    '`**z79EvW95bc-f=yO}K5II5`37mo^f@Q%|_HSV7XW9yn5WePnMA!qmwgv?2QkRs41e_Li-RVo|w#rA_l^67fYI0&41v#EsiLxk*'
    'zuqlofZFT8N>OJ4Ec;k{WVDyQRs0dCkPw>^Rz)L4Y@>JQz(WN+?&!gQ9XIq3XXJI9^h;^6=cockIAYQi<O+&zODko@ige0{ikJ_v'
    'y$;w$4~<}Y??;Hk3w&>(Xa9KoQtV$Hg5x~SdKB@yoL1VmUl|QJW}w*_D<P~^(iU4lxuxw!S_?kol@ZkETcOCDd3qh=5E-b~K779$'
    'gDvDb;dDa}6VSA>%MYTN)J`M3=KavjhMgMyB|4dbmjwjS2zzRnA2FQyjK8xjBNQn3#Pjy__bR<_{(wCpPRBt~3S$>13%WTUIxP~b'
    'Z(JW8@V(}4oLzCaem<Nu^6Z0LC<PiBs=%Z8l;p7%dt(7dV!w~S|K|T+p1`|eio^_T&xCx)Qg%Ga?{j7OJ53t6wX)H+!@B!wGlJdj'
    'u;w%Sl28>@GjrO8#7RsSWc4>%%v0+Sk?R&J-`W-$wtLIt!QgTbuL<@v7fkP#DbIV0A=HWDpOn;#HdR4lAUPYB8&{DDU;M+3^m4K}'
    'NS@6c6ToXAs&iN!@J{j?GUnZDXZPKZ40^KnrAI)7vXMEUM)->p6?*MvS->x23ORp;vDB}KP-l@dUOUC)577ZBb>%+Aix7=_?4qIW'
    'Od2y(&qQVfc7miSgn78j#RZ0FGK6Vh*(}FG%NYt@zhY3rSt!w>X^})E1RetSU9RA1U0bBpe(dX05fXZbsn&{Eb%mjdjH<|soW95V'
    'f^FTDs3eb1kVUG?{-(4BZ|2J4z*?+v4U%A=_W#9O3UE>n=SLNuz|KR8YD&K*@>zXxVdK`J?Og&P>Ndo$`dkk%JvBQkz@>_Ack7Bx'
    'ay2!zX8XM!BE)>Ho^+%Im~-18<n4$++qt6_b<$ej-K_+mS&(9Rjkj0imt_Km?o(;NPbTeUJOStL{8b&5K#p$(L$b2lz4u$}tEA@!'
    'fPtZOrguqt&?h-eFgLp5foD^m4`vNkdoa7L_l9y!_$67-Bs5rP2lw8%0r8B0r{W(+iChVIUQKq;4M|I?DLPYUAiha^IWTXs-;`Yh'
    'OG@J!hCb(E7d>$9J8pU#SAAc(hJVZ(Ux(NR<R@Z!Kw3n=k~<D!(cG^B<{<ALP1L(8?Tq>CZFoSF<NDAm@wBX{b>7_^q|QtF%xv@~'
    'A2I*9Wg_7rtaaV)iUP0cp-hmTd~{YSx;=P%Ezz{5M!LTuMt)Uey`p;Ogu6I?Z+_saqjge2JE0_dkA2;ksv6Vu|20b!EzRLrWHd~}'
    'W0m**v#2Jj_~z0K3=rho|8QMs`nu+73P?lnkHnP?*DHwN;`-)?k2_HW@<-=6KnfP7<z-L;qn0V?S42CXsDlN7T}g7%%qYpu1>j2R'
    'BT8b^aOB~uw_Z2RmE6E?`wnkz&D}dV#?7!hesu~-!xzpw{U4xB!g@%7;DZC#O87*2+UNj<6>6y>O$in6oHLn*r++5pd!H>FzrQ~w'
    't<YZtNd<I3z}mj}p;C469BU=O!;7v*II^PCnDBV`=q2EDHS`}7r%S&zd&4H~B-ee(7L?BpdNEUpI|!jt0Uzj?|DO3_pm^AO6OpBP'
    '86D_N?yC&EECIn7`@8_;X&k(cR_6ZoAAVgRA8QF~kF4fE+zFl~<B{QzTT~G4u3L{)U*4tDjox8oHsius9fg!8)wr5B`ZKq^>4%hS'
    'H@LD3dp*d%F4@~Y_&b)|F17b4kuW*FZ6aSh(rT9eY?@G8P02R*lwfE-)qb;`oHipDq6;H1YqZHvFQaUWJTY8B)=DULANI!2k~!*e'
    'G52?dlY&9r)is|43bFotq5E{BKakd~;$oSv+(JLd*vZX53Gf6<%c@GOo~dfu0uOF{h*l_#bpM7*<{pQA?R<EG2S>AEl7eN316Ue`'
    '%Mu1j8tc%y{OBfECrQb%Ot=i2<RHm=&ro7Ms$>Bmg%ssnn0x*mt=5-$Lktgqok$x8hN0`+#4lfITG3^m$euSS&y@_)sytTa%Myl2'
    '?gIC(1~C;SrI!;i0g;A`-=t2($5cOyt_YZZ8aw;&CHOcUzks=}dK`I}QmCZxpa@w5zK>OM)bN;HQyloS3Fx)17x^Uq^wUL&O%5yl'
    'Aa~mGUfcOe^@*`}DEHo|LCZJfJjhRFH=pSVi`><L^rj4Kcc0T@)U<*tV1Nb5@(7>5tDD^~9_ovb&3W2!S6(3jUo#B+bzWx?7|vw('
    'V$hi0=M0$&D_nRB|5p&kDl!K(JWeG$ew+R>7?CJ{i?p0dkxp(Xp9hjFk|@%1A%Rc;IkwC@jjj3$rS@XUBY#I*frj9~mv2GkX2Mh|'
    '>C8=H<_*xE31@MsEM;&{&qAhWHw5$3G3XCp;{K4!l3~M%Ik6&qiJxQuIQgK0qsMplw*%+Vhg_4l%0UE=>s|`Y{G05~LOyNDXUL1u'
    '!4krHYIDy9QvJI8TWpwPw#m(H7dRr3J^6p!1LKJaa-+dd0Z8vDI8^eQ32Xcp^sQU=x$C&0gWFOd-(4)~r)$md`BfD2ih6ZT>V5vW'
    'A6m(S5c(n26ca>=CX0+gSps19s2C4=vlQ8U!Cgga$dsH`Wc9dG1A=Tg+7a3Dd+F*ox0CLhf<_J`PUpy4ecvJSA-~6Qhi(Q6<-F<I'
    ';7iMuiJE&FcT9Yr6c}EGAIKM^fKapqcNE4wr&Jniv8GVRDWWjWn(gE{@y4y8>i<7vE4E$x3GU)@@<I4nFuj5Q79_J@PKvz^2>s}{'
    'Jn^Kg4ta^6amv3vzWQ^f-w-cEqf#fwaNa&Ekzj;8&`-F1%gCg*Fa#7XY2Q<?#Jk1y4o!0u&D`<i!72C_j;q#*cAMHIt}~K3PN1N?'
    's&wn7#F@drfPY;b4NdyP@!%CI1pFz+<F0lRrSyI3=vvVs<GlU-v@sj>&fsK@l<SE=sYTKQ>Ur;To02-FC4&}L^)y2NX;p3I8WT+Q'
    '5Zok|Y9&Ayc@Zojy3Te<u<l_b;Cz3RTYZ4ygA2<L)*kN^9Z5~zMu$#sX{jl1EhbS90WEI*uB7R2%eZ8MFCx|TUyw&OK7-t-;4V%8'
    'W0qUi<DJlk=8u&@E~oYH0|Q(hoYahH$g&AYq6vzdpBfiU;;#r%#;)r|^(9QzE#qcQz)ObLM$8Z(>T>TLIsl@+u_&`?h5D8?4uu3*'
    '1#0mlQ4b364+!_Zg$<P$I<@CI4F*XC1BZlb=21fxtsFaLOe>pz)OlE<OYmjj2!o#D5sOfdE+W5+l8^JgUrzP;^dHe7AHB+$H#(gd'
    'ZeakzSeNDiU)XEY?^BeO^t>3s0FMsz{Px6G?bY>nABQ;DEB6U9wo0|6ULjS2(dZCd7uAvWcQ=jJAv=9nOBm;J&ql8Qp6#slg_-of'
    'Ev{Q<7dI+4y}C{)H8g}V%JUi(*VC&_!0*WQn}wGUZ7wLK9c&}H@OI#elI)^pH67{2k=Ex{fQvfnCnXL|y_t~3)^@<cjbSGJ?PKz6'
    '+vw(-WAOgK1ynE+oMmj~-6S4$+H%WmSRD(fHNIJF$r4oPg9MBa$-MM#CRyniZSQoy^X7Kd1V}OiZT`3`9O%r?&+_Rmx8NpdeP8fI'
    'c|vJo6~UhVu`6cqKTgWXr=*_&oyGv{PwE;$m2a!Pnn}A3z*FloP6=x08(kXw3ejw{nXt$Ax0eI?25{)gm@^S*0yI=mF?ZoS28{E$'
    '58=853!Vansm10o*&K!6aD_<KdZ3F{7WL2%$x<8MvVuyk|9Xov2~+(z`L+z^#Fj_aA-2!%Oa|11HgMRQ=_;2hcV-?JOR<PhO~AAs'
    'aZN#eeMcwnb*PBNk_vAqeoa+kjyT`;z7>#o$5HBCA~B~P$jy(glFg|Oe>?c-bF}WuR#S*uwtdiqH!^Wy;0R7X5y|C;bx*nhaX(ab'
    '0FQwjFO}_;ZForcr4Y&ru=rZAd_|1S03YWtmk!v@UaR#<c5~7caxiJJ`zZ_b6os^uM-$g|MG$a?u*!EbVQErF(gEM2ie1dV_L%;Z'
    'xQElji(3Lbw0+7CDZ_VxfS%(8M<m)c!4u6K{rqV{kGw!4_c1An#tbjWoZ}=G&=e*MFUm3D<smu3gHl}wm<fw{;pYE0=$?pgdgGlE'
    '<gZb0BjaT$$tEsgI@xEzf9wwco*1ew2py-T85l9%tLGNDhkpX5Gvv_pb85u1m8`+J?MrT=0lf6o`n<7e(S_V_XRh(H@uQn2*R4|^'
    '09&wc<p}Gvf}>^*twCcak&uASyEe{ME!*G7<~qH^E$`3zU3n_FS^*I?Jzlqb<UkVte21&=AOBc5rZ>mBhcrgju}n<7q6g#NzWqQ}'
    '`FTH|bjZ&{{0pN9Jz;$q>v#HD-n8b;sny@VF#vohD7XzgMtLgKk?6PZ60;@LL^c2FmmKmHa^aH~&422~?jpcfq|7Rviz$$*+bW<|'
    ';D>=@4|!&3JoNCSNIxQ-J-K_xHybZ)0a#RldS7qP`k^+Vd*IZ+q>D$qS^3#~NhQ$sEkYD<w#h-10aq4FHnvls)IqJSSDb$A466=H'
    'kM-D==BWB3yOZuZZ%@JUmF6?c10nj*qT<GfJjY<*B&TbFL!l;ay0C5FxA#bcX~gMATL%~D$d1-wf(4Z>Nyi0v!O&kIy2Y^+uw%;w'
    '0yU^Af!0OD1nOf|snR?3K6gF`bkxge=$qe?h3t3QyhCLzjUyB&Nla=!3lt&FOjhz1$uJ$Xzr~8#@??BGeAADTwnyNf9BY-B156@m'
    'YC$waP9U>j;`4toomOto2CC^>hOzMuXNdKZU-+~dUKvkM8I#(Pm;jgaUfn$b-Au+nkhSxen4D=vV%S_Xfh$PhGlRH*UXMw$eR+1W'
    '=<DGMpz@lM0$h2FR4NiHnD5QcAUfAz2arF^mdim>jsP#NX7k)~Vl^eZ5J;mS_&S?K@)#i!pFX-(S3N8D9sRPcIEeX4K^kK7D_xb!'
    '4A05nY$eRGXxoF*_~@fQ4+d4_-1$C(Ve6PJL~apDO;SIJ1H>)`>sqX9blN4PHRs-t><>Kl9RS_{Bx)Ro9MP$X^&!Ilw^{XGw3J2t'
    '9y!1W@x)Yo@kj-!8yzoZ2`K4CDI!5>JZ*t{o#W>6&j~Ho&h{v&-(*5X9f|_B*_<pV;*A)*feo}|WOBi}%@4DSn)bA|CxP*K+S~Bb'
    's3@oF8ANH<-yjeYK?X>t%C~I2RDDHTMki}egR%=LU9fHMy4@4{B75r%ku{YD%S?A6+v$a-5E)i(Zn!f$)M|B$j~d>VLPPnB+&PzE'
    '@%)I}5Ma?DhFyikc*Ce=Dq|A?;&sAVog(bS%BTIjGmm(Pwe*$OH1&2~Za2Y5fZjm7j@r=h1f`tEFLc2Rf*H9<9P<n{Wgun6y+Txv'
    'Dd|Wc8$hnU+==B>wS5^fTtfBSjo%wUoJYWlC4}<gQRC#lXKc>!={E{K_Tty4A@PPGtCNbuF3m~14Wx{*%sAqdrLN8RG<F>4^pdCQ'
    'g2ckz$qF_u1^XM*4c6;8Qf4$K-AS0u0t06-HT3qD4ZX;*JH?8{g!}m_Y3nFR=a614!rfJ9!z$|0Y^?|KDrE2en7}sbkaMK*sB!2{'
    'f{{^8KC}QML(FitD2xTR&n$)$<UE?CReAkSreP2n8IOU~r7(zS_#~3xS={OZ!aj#)Kc^2LIBqOb=(%QZvhTvA8E=YuZg_~OwC#!?'
    '5byAnh9rrM5&x_0Ao3h@B`;o;`;<A{{Zl_eNE<7nOj5S&^KDwXf;bw8oZVK^if^T%qnx^FkBGK%$$#l`BX?QFDMEpwI?&ZRq+`uU'
    'W_T<B*B=sv=5R4&=5b3nl)VjQ^DbRRlhzXkhmG&A+l=DZh+cj{netj@@GSpu!b52eZX5$TiG-zzZq49F`eYAlxo_iLMX&rOCsq>U'
    '%gks;>n`Ljk;#Js>6=bol~=lLYHE-U2KU7xei<OWM5V)|xMTsw#Fr(BYf^%rP^f1Lw}s`4GazYR==k3S?sDM$FHBT-jJ*H$?iuJ5'
    '(}dqm5)yrAJSzbRutUN$_(Nk1hy4W%X!@Bn!^)*ZqTQKgA^I&+FyCjOE0@W>H{=OVTMnSoed2|6=6Ek<pZX8jLWuB?>eaoM`;w_m'
    'c-c?8$KiUhzc+;R`Ot$%EJDM79oRK<rFM>0TbcjtR6dnn;jr|Z7&b368pV;u#S}iov6d8P(Jm)b&{ctQkwwha!uKWsQ3#1#60!e{'
    'zhbFGoYN&BG7hb8i79;ktj9LKAa9T#C&!P<M09%lbN@<X@J*EI#9jC=0;yoeBlmi8<>VkTmqO)aw@PH&#cOOg3bs>YCXsh4o=+<>'
    '50O}E)eyW>?O{~=!Fptv!YW@Sw<9Y|`YSQFA6y$0`@k>6(2O-eEvrO<Y?vBOLLH_ba%T92$tYu7ShJHdE8=Ph=;Q+6t5Yd(eF%PN'
    ')&VPs;xSGDXaLY6ZQMXk*VXz!1h8DaDhA>X*cSqYR@ynh*~I`qmiI-Dy6XCta^*wELDCQQG?fI51w{yI$x>>Hh%3I9E<!#ySScrS'
    'riBcq*T^Uu<)5!^6Bxu6<O~CkrvVu9sEXvgd?Fl=_M=+is{=-eXVFt##pZ}v@h-x=+v;9_hV(~5aXjH2<ef*t)%(3JZ6dC|gV*=k'
    ')bndX3^trk9}nt1xk|YG4Xv3|SU*19e7qD8!YbeHsv-(D#iv5BUrAKzeD~S=c3z(%cQd_kDmg26#BxmY=81Yk9$p?HTp|vQ-`A`O'
    ';=A#5ZE)8qWKGG+eHT0MvY!dXOG{Q=dO0|5YY#ld6$ZNvzItSTBCk2#SX;Z%Cpx8%)0)@Zed9)BXIOk0?_wpV-)0X`!k%E5epw+t'
    'FnRM(I3QXgO~}SuYkZGwhAqw)Q$M&VEv+W9UtTYRw_um<e&=*><1lU^!^6559B5>TP>*-&fKVlVBa8Vngm!%df(BJ!a#k=Jl6F2s'
    '#1L$+#lx#|3(L>hAW90-w3_xg4;gv};tWp#a9uZ7ml3juFe$J|<}cH$8sE+YNkXY{X^z4uxa1K*I%Wy4WbSw^0yFi5L5F;yR2S4n'
    'mtw*k@1`=k#|(*J#-t#zCCLuA*sRh~OyDb|ZuVdp(gl<Gde|9H()GszTZEl=?Ehi-`mXkuzF7~g<ckEdNd)Oy<2~^rE6uhjX4*tS'
    '&uRsy_x<d1XZmpWhv6WQC4V$Ueh}?g%#2#Gm@R66M2=EMx)ZFA*(RLMSJ%-&4cD>H^py|oz9}mjALw9B)Xonhr#Wo=cH%cWf%um7'
    'U(;OgH%weCJ|GOs=q;5IM#uL&-)d>EY7hCQYx}W;!5eB`BPgkUfbFwyD{<q(EUJab!k9}tdnqiRbb*<G!xO(609@eIu7H<;JRI4;'
    '96`Zu!X$jRG3^%fP@y1de!n(Zj$iA+haAalK23I7P+&rFLS&Pi%I4xJ+IZB3x_+Y|2PKJwBDw9QX6(7C3iDD@S8t%4(nZ@2JvI5y'
    'vbt5?b722=(Sr2V;&-evN#iLfG}_+EpZ@Ead1rkbc{y+ItENqS;cN&;ki0FFV*Jy<t^UJ3Ub!)^!3aTs?d?AG`G!=ahI;OI=HPD0'
    'oT`^kU=uP~%ptcH*Hz-tM&cd2prN*=H<gn_QzI=O(BilAYmfQ7uBB#vl<XD-fR=_TMr{dJ8azfrOh(lOTrzd!n|g_4J5};3{TwdK'
    'qo~3P-P>Mg*{i_ZPOr;eh?}4=hM;2gQGCRgjB<ZZaF18$IOrc!!D@Q72#Ba^hGtJo3|ij#EM-_?r726b)B|8tkdxpRfS}XQ;8!Ha'
    'vsX6{<_BAraGgg2&!_#aor3_vntvn8qzv2N@%G=~S0L;i6nMH;!VtS&!XFgu00$;wk8cd6FMgM=borxe@9{87_wU7p=1XFOcX~dC'
    'yQdz#rfLI(Tef@bW|be0=Kw4dArw#Vx{G#K#$tf)JO>wLHzaxLj0HrYi-(?haxhzgE;6<Sn5O^<xtKaAKPnnCRzLnNiFnoOs8<Hq'
    '^#}()632&z?{z5VIpl_}<lURyY^eGS<q8@P4>_stPfB&Rd!Fo3<&vjZ%^@=>Eum#;M}}UOtFKMM9?I1k1%q{dKG2k<Qv~{`jBXPp'
    '&f>Rr=E(-qF~K7fTqxGaA-NHtn`WNx#csF6+Fw_NSF2>DJ?-0b*vAK^>o+1)$}IKz_1M_Gugx5FUMVu*6PlYkDSK+g=bzc`wc8=4'
    'y;JpG$m^a6`k8KzSYp312&?N|)ri_AoIj5W$81`%KxW%R{O{k^pzJW1392}mbvo1jnXWw>mozxaZU_qc@DOmsGcPqHFxRRh5e-2A'
    '?WeVo;zgD!uW3gtX;y7(%8nufP#?xDZz03LAo55nOlL#&@g>N-JIVbhld#EY5)7iMm-qecaU|`Fi&KiZNi=9>!U2Fnw?144`DZWU'
    'yR;(;`-iK9*1RQFit>2+d-J^hhGr@3-9*K&OH2l58$@NI8jq|z*XNVV4ancl>Pfr!rtZzpa6qDDjZJddg*M2l%ObTFdH{4r41RU<'
    'z|D~D&l!n;$)P^({1sc#k6z;0u+oyl+t=aKg^Hw{+fDic>B{871h?NlDO`3_U77zsxdZH)^8dZd{<iVe4a-mM;Qkukwqt^q+1YNd'
    '>s;;C4_jRW#EH}Rij>s|d!zc_<?lrrl4bALck(7&`EL`pv92ToK!EOe7C7Gv1zlTPB1X*xqE4lTvTVSs4O0uT!xl6p&S`GJa2AhA'
    'or&{|4Su0hG)KQme`QoS(|qM>W!?Z-mU(s=AsWqU;&`rbP}W6R!&LI69AiruTq~NI`Ss%grLX3Z&By2zBWIiO3oRaDC#$>O1G-@1'
    '^egzJuE(7VzCi}{&!c0y5NWR-aZQIN+q49KWjo$M<IJC{;aeelIedHgmwj*Uy4jXLRo+UklhIH^fl8^}3&J)`-=4l8bAt|``&yM_'
    'uc?LRE^AQsY$Icz(W12nmuy!=A|=$v_F;FQ2Eq^jK)cpg$;*ok9gKE9iv)Fm{QkXC)c~nq2>txAOxAqd2MfMOc9tThY0Rbv)yR?I'
    'ia+{XgjCR1HFWALzMl?K?z9TmYkxRSv3hYzWO(nPLv`n)|8lwkAD_LfI){^0WM1ocUvuQK;d=Td=l#v=;$upz@dOw+Ki#+#ONml-'
    'H<DaiuKE?Mhop;3E9K6+=Q()8cfIi71^hZib(GALsoA7A%#~P8DmaQ%ZvYAge_FC97PG=iRSYm!4llzu(aep|o*p}9-*h(ccX(=h'
    '=q4UU28D+K0ZLaUM>$}R5AthCW^XE?fQXsDvL!9TN**0*`-4LJkW&~8Jt#wI(t?C}mQKeaRr71g^a61!d~nlrO~27CPAt~g7voqw'
    '*7kh2D};q};>3M5wo}TKJ(-K;<2G!->c+?D5m1xhxL<)O3w#)Xo~6z8n1w@RoLZS$I-BO!<`$77#*4>0&&1=CYbc`0MwDOy*(81%'
    'T3~2eba|Ac$jq0>a>Jn?n;6Q;e3HW=v!B1{fasIu!NA`PI@<O)Ca*kGiSDpz;ds!Ep8njXB=LHG)^r&HHpOD&1f5A~ZjeYS-Bvj@'
    '4H2P^HI<};5vt^{v5cY=&E;)iKB)xOLANg2%#*XRi(V>f-xCZJQ3pxVd6ofTuBl^dNA>=37rRM$rOZG5$-Zwy{&;BC^$-wblM%z)'
    'AJ()K=oqjw+u(v<MZ;oMzp;tp`0KcdD8JTUjs{m}A{%9w;=10gs`fheN;&pkrJxoH|Lu|2#dxL$2S&~_Fa(C$#@HJ!cazV+HebXF'
    'C^1SpMVgg}<h81YS{ftR{r4=!gf7B<U580C>Bxk{Ii4XdXTb&#uxnk71b>%3w$+wGMGKye+Ptho2s!jN4eB7F6jx91V~7|5u#tXp'
    ')HCka5A!cOlgHDg+uPm0fv-)=lTxb-e?kM9C`V4-nFBf48$>^ob^+VcR;>s2=rZsG;u2_j@PAH;ba@7Wua{J-umlI99T~ZgPpX`$'
    '{n?1Mdx%o|QdMxGYW*hn=~_)^6P9D#Al;})jBgPlg#rr_K;OSE*s{h@ju7aGW{sgjI0`Sc`D%*fn`|J!MJxeg0S#H358yJ#k%%aR'
    '&KqCZ?ESgK<D$H6!!;XM4tHy3G^G~UB|OgwjINiL8f=s?x)3TQa1l<t&+E}7$sLceu}`oK1R)J~>5%l?|7~XlivxHHn7}u7dbcjs'
    'yH+Hfzq<E)gU5_(xE-ulPp*_{n<GkLZ1+UdH`tx5M$Vrd)3GCaB2SavCxPG0Yds+HlR;G38L5yyg*D+#`~uN8BieF{c-qdx+pCS7'
    'xkU^I4v#6HqAzV#bDGXO1R<;h>^Um;3$OWVLxt^3X~d<Vn7oSs`!Wz8XPubVo#41q6otGDMO+{hS7aN<Sp`<HNZf;Es<!pa>sjZs'
    'PbKy1YIvAtl7t(VGMoK3;7{#v1e&hP_x11-LUIjC;o1ouc35=na2V~dYC~u2{0U+lSODFg&%qF;a*4v~c7;V<#FX~1))&u4n$y2_'
    'RrjicB{zioSw*HWw!`%dGHzT1=Q%^VP$Hbr!KuJ!B5FqO^ypS@f)cngow)FAv1<_Ky$V}$5;d|t5}T|JzC`(Kammm!ScDa01w_TT'
    '7vlIF_XxJ@4CzwO{vnrW^CD)WXBU_Qh-qTBVOOu5Bi3l<)KyOjR}5u&`(2XbB^4_@FXf+{Xt3`xmhxcmrWqva5=OBuh-`UX2Dsjb'
    'm5cCe=`nT_jOkd^cK)9DsNwD&Y(WCo_G)3qL?u&--Bt+2z(N1)xZFP!d@`y<m<6U=_}r{SEM>rJN>-83ed8`$-c_@!I1J#t4+59r'
    'u9^0E<V7Bj?0!#@dpxl$uD_ZIth!jrNW~Rz+xug-J}u)i+GBOl{ZR0Jd9Dp8ohlZX2B}jtWsID`-xcGgR0iTZ2~#BSIpyrTasXDr'
    'HnT#j$ln>&21d|mO#%{d^s(@w)^*d`KxFqOum{bU@}ih;3slP0@FFg(9*tTkRp1DZT216u@tdnsw`Z7Ih_B_M0Lki}mFg;`=dy1n'
    'Dn><QtWnFVs=%g|*q_-eQ7|N7+xD(H@5)}tlWmV}M?f@^;_3P}l2MN)or|CahRGkF)-i#YaFv>nnBRhJ=q2Wb#<~AR8fAg)9;VuJ'
    'l}ue1wm8RblLaUy*kR^UM`raEaipx$TUgea#;`*l<co$_1<HSr|M{r*S20i3KbMO*Ew5m3DrB_kd0UMN(%)HeT~SS@v*x*9ax_o4'
    'KdkQvqOVZOG)lY9&qb=pU|r$ApwJWLwD+*{o8qj(Y_`1YfQ&re_5TLCYfky!X`?w@7G;9A@o*#2L~_?9k~*@;GG<WI^l8(Y^sCH='
    '<^~>3j}VPLB}>S-PSI>e<~rh1PFz_5sekN^5PnAWG?CsRJeDVZ4e{T{zuug)51a0IC&Or-|DJ+=Q|JI~?iJkcF}KQE+9JvKF@{EX'
    '7InD4uCXG#e=AR4yucBs_>P;#it}@+eh(79;eEyE6Rz(~#>r^P1O|D@a#O0$a9KyUiQ6jUH7&L`gq|z=-4iO^KKg16EL{3}Q*g3@'
    'vKYmhv|g)ss?7>#uI_Nb%<q6gXLSQLOv)lW{!DytjS^(ccQHiH0Xo&GwNT#S_fW<y{|Q>5G3Qp{{AzrE{(GzUS}nH4G*uFc>3^{f'
    '3o`N#$5!uWH_w7R-Lbh9J<3G4mZWH%CeJ2cq{n;I#{_Ef1=dE7m(IP4f_zN%+{U1046k(0rY^gSf|xY5H*N`w09kOKQYnf~3xKiX'
    'h0KX_CE2GCJD}4tW-IeEZr;B0Vo6kq(w>mqYBVO1yjvpSJN!o~HzP%?8!ATO-a;TpsW!dOZ3A|)i6nnHUj$NnXA=(XbmCxP@@E=d'
    'Ib7$2jep!yz-LA4Terx2)ctVJA|4!iKh70=%z%+O{r4`lH@&es$RvjD6p;9Ce)6n?Hu(?pj2c#IQkcdZ^9H#b$5DU1Hvj4&besF6'
    'Ob3@Fe{J~`{4PGla{jO`C)_J01DoTG)gXg2%ScWEso}53gr;2bSaHrT>r`QF;!Ls1@OQ4N_?q~;Ni5wO>v#uHFV#B|QGlTO+nm|D'
    'nu8}&Bex{twqf8f8}MniJ*`regyK7rb4(>_HM1+0-MRfCli%F9Zqz{NR+g*LgrHcGG4D^iur6VzeCp7rnHz>z!ORU0Wq}B(wi(vd'
    'Yau}D!a<gtGUuUxjmi=U_*xMihpzJl(~VQYv$P~X@U^IDL{{~qv`Q_Y8WE6Wi}^K95~M`KUlQ3aSAKj3f>$*qxH#Oi=a+=MZrjRl'
    'l;Dv_03^Hatz{j-EqiuRa+kT^jR()X4MI!E6h_Rh#*Sbo`F4>Llnl@*U)w7G4XF~^3-nXrZ45kir9cIX$==KKX{suhcK_6&Tn1TV'
    'sHaWnHbS~>0A6RTf_s+n75s};K2tw(fO%;~(*uFr7NS~i{A?Ts(8xzg`R1l%1{BRIE)rh2@_mjRLJskmu7cwBj9GC+#3`h_Y@$lc'
    'g3Kd*35HmAg<(sga(&T%L-vEh=gg-iqZ%c+31?<VHBR$5Ih=TOo`cFyLjZ6;-q!6b5?dd_U|1$`Wm9>=jMmr{V<uuto?u79otCrS'
    'Tt)_;Qi$~~lG#5+4a*S}UA(CZ99x;BYk>}lN)}FBwZZ8*X}t<E<DSRRHkjND8Xuoi%WI$<x*?Q6ZyVxG&qI8Y2^TUoFdnWf7-fIS'
    'o~GDR`o+ljicOLMFfycleScfqwvAu893ife)TsurTc(fQdaN$L(y5LgpON9Ijw|LxBvdtnscc-lxkz>N9??&76e$1Xef_`(c3}mk'
    'J7M9c0&^B{@ar~yDwmCoUh<|Mr4m}<7UrT`7_FphZ<~LR=d1g}!6U)Gki~E~Sjnsxee#F{37bv5dHaoGJc_5ogez9XO2Q=hJq;}B'
    'r&#$TWv8+@ovfr&Ms$>d0N>R1pbh{=jRa;Deax{*F%GJzk$SS<tb1u5urlcat;eH@lY>E9abPzrn?xq#BBbT{@zn%!{~|k+CE|6}'
    'Y)HLHHuoC~M%S;mj1xt0QEt=}IUDc@yj47N9fEBCqU3T(jREHd>dn?K96$WE!qb|n*ToaaQ^jIXU+ion@YZpUAu*j*%87k5!RV~m'
    'zg8n$M{FPrAEyko|MpjG@RJ*UYcbECy@KUaz>$ci-$CRvS_2Hg7M+3wk|XC#Cok_M_*Q9I1i?%!PQ?}Nzj{68n(@z!AGI}gD@usV'
    '2&#K7QPTbLjKO0-gkMF^&ugApHj&2^dAhETSqEcw$Z+8#oI;^S7?W=LH3wN1t#gaX%#sBB9iSDDw&<->lferN$k`h>pfoGkZp?~b'
    '<8znD1C`2m!lPT-)F7u;?AT}lHNiWL7e4tiTDb{OL3mL~K;T@Cthr8knLrTz7j&qiG~<R~FcHT<9<VvEmemf#VzA8sy>y3LNBGUY'
    't6<G@%HGh+LqH9GB|2enOdI4}rkOm0dL%^C35}O)q|T;IRxC@v&*1!oB{%1AX;jJ~&)(q?G|ftS32!=@e^GzM(iJ;U#na%it0zWW'
    'Fu%hGi*ahAV_NR&0c-FRjjR^WxdqcazwAvTHpKA}l-J(+ow}%@9K`}4ofL+WzF+WjznMb>F}^rROFZ=E`wvHPC%PLs(-LWM;}7G&'
    '7lTbR1^l~^G@${$RuJZ<P*#uzi@`*sVfCSGcQ+bBtsgO{+gj^0>`F2~DboGW@0<Kg3$_$wAR_3}8$Gs?NlI`|)P^d??}9fKpu`2>'
    'I%dwmbKc#HUHQ*OZfqaxZ7O|GYpDwwrybZoH!%x7DN*)ycF(%U@t=7Qm?>O$x`Vc|6aOzpt*f?~aLLKs3I;>A97}{cqYi$YQsR$6'
    'zi!nUT0mRt(^L-R4E}n@i`M#n0Wg(0?kY$nnpdxy89XT)tl-1h<;1A06w@PaZeFn*Y)`rlr^?MF*9kk1L{2BS(T?HmiKY;^S8h6D'
    'cZkb-)O*o!h${H!_c{(726-;PHEz(XB{8J=sos*_s$yR@YYBt_hPL(fIf2y0_XG;|z^hPl`4DuyE&k4<pvnb|f6Jm>fXLrNKtq#I'
    'vrM-=#W<8lcGzO03kwR-Kb4fdgi^sgrzt}I=xI1`ko#kcy7quafU@`%Lnyq)WL{Prkf>Cj7TSD^1LZVwLO^Qpq9^-rolzcVbuV<L'
    'JQ`=xN~Flc>g!ikK?xz>xkACSF!&XWr}l%O+4!kwcm7&8JA$J=xO@HlzlxOHx5YDHPZ{cr))`(-1G59UNV;kOl&?ojs^9Utm|8Td'
    'VgT{uu2^6nK+}<K9uW_8i&Pg|LOA<@SZj#&tCyNOE}vl&6`)Z+@WS`gC;*m39>5%Ps9+<9T59roVI(1_R+3`KOm$R3h@sKpwYs*;'
    'MF1hVH=;hy*ez1>I<y0>z$7-I4xpE$ByQ^?`os8QfokiIsquk0hO0?!Y{k;8B+w1+LF(f!!7E3&8e;VE2Tgmn+^}M|2Wrgg)8dpZ'
    'CyZqjTFQt|2;*6qy+edv{)JN-3eZjo+LpI{=liR$(Gpg}7@+j^$rq=?ZuX@FtE;mLfi!`zKcp9t(kp4qGud^&5`6koi?dE{&Ye7%'
    'g(FPe>I!EEb)ZeQrs-V&a<ACI_7qSwLMT5T^jkIy2BL6kXL&mnVmf3yJ4jF_a<VQHg<VO{5F^dlN?mlZ;K*pi-W_b+mF@$7fitfU'
    'u%|W%j0Y?Hn$)v?q)eO`c;{Il7`wu|sRCDUMp;j4J}8(|CjJaR*|61S2>dH{lMUL?@B-vlyO)H}L(B-KXBnMN1K(tBC?2l(BJCN-'
    '0(T1|y#Q8SYP+W|btbJtqGKzmH)reMY2^k{zhjOQ4zL58rzjeQ`kH_b!j)9tuj7=&ZaA_GRMq?v%l+O@=NeL0%2cL}>YWYjKI<Kz'
    'bZ8*sMr+Na?CR!=&N2(62mFm3Tdgx%WoIs4qp~zegaxhBA)Qk}-<~#ze?hUQ{bg@(?l=Dt{$RcywC)GWM?4)x_PTxG5->24Deb>h'
    'P&Fg0PSBn=mp+@6vpr$XQjhqT4KS|HYnBC%x=NAK>@2*j4z%Imv?STAgbYLiGe6Nl&@*c!D%!pKo^v4r4=hW!8(j?d<o$Z&%#hb8'
    'l0U`9zr|ys1Y3H==^+Ky+=+x{6FGrT=VJECzGtXEQUG2={}dM4qd<^?fsE`Pj01vB6Op{3vh4uVM@25RG3{8wxdM$Rjl?F6B+c=o'
    'Y?EcYLYTsTTIX^b1}0Bm$Q@1ylg`>cb4)}sWlTi5dgFDa)M+1d1Yt3kGlF~KP03giS#dEBu=3o4wt1{X4lF&FR}$i&l9p>#?8#?K'
    'B|~hS+T`3K4BsARw<Al0U<0+Uy7n<&zAiBj)+$t3V9#sZgWNy*bHq!=5@q|p<~rpNGoyFcF)z2mBTDm=w2<5RPioo3ezFizcc%E='
    'l@YPFo!6`Gai)wFbs2M1*lH=10#jLHTEp7PkEMST$CMk-usXj9vT{=cm|zl!t~-7UrSB^g0@^YJ_r^ZTMI)IPK}JYQ2=kaS1+ssk'
    'Tc{b!M~YWVad!^8PTxQ23WpWq0F|VxJivHkjxX9BC%&bBpA!@_GHPlbFN<Y5#l^lV*2mJSGje`nbCen-NG9VxDo-KcntcoD{+2^w'
    'XueRUjm%VIc3Vku@4}1~;JR&YR@;rgFCZz=fJaJK6?n(st&OceijEQY8XeDQ-VQB!EDnaP>LaD4vMhTazZG56a0ps?dkv@i$6TkT'
    'DTr`Hr_m^$$sTSOSavIC;w@KXr^lf2ohPAxEkX6T8!y>r_-29YDHLGJ>FVOxpTyZO$y{}V_yBrR7wypU%&*&MbnMen^#{<R$=4O9'
    '4xm^;z^JWU&8DcQRbdiEIUz7Z1s@D5<<T`7(Zs;o3L*zoC-`y;r;OW618qX<ZH3^D5mB<3t#V{qE<C9hk1JsZA3TW}y(c+nnHJf!'
    '_nXTcB3oD&-pyHJup{uEwGoONC;{WT-)g=4eP?Ff!-o1H#=_@h=Ik=xO(~baq?0{t59()){%J?|fF`+$d6nLuAD;N!IN!ZUKl`t1'
    '*w2LPrJsoW3fJWeIZ)fFfW8m=agn*ybjlkm&r%3_SOUg#-gQzyAYfYHcYjC)*->kzTl!3msg-F`P2{hZrl;k~KoAL0#ZdN8wtyEY'
    'TtRSO6VHS0GDc^)fH1hzBGcF#P9P<wdd__j83I{WDr!7R5og<xdeMyJ{;Lh>Ju9n~LHQ;kg<U#FLef`=;4(mzDPJ;@8$y5e*n`D7'
    'Q;cf8IHZw?k1{U7T4FKXP0;|T=6ZekAKFPZGZLGzz3|4#NGHYN-P>8V#3xW_F?Gt}?06Cve+D#pHG|Ah5j4+@_J%7ZuSo2}nf*?A'
    'UI>@0E<kKHa~-W0!Eo&n7q0bKO&w+zInkOdV&wE@_(0@oVVq+8PUSqa-2xn5tPQNNGFB7JyWLG+ovTscJ1U^DoAa5X{qLZz`L_9k'
    'ROYs~82|o^e)6G-dbA_D7N^_&tytN(Lfjz+Wfh~JLlVS#@Smm7Gp+U1Eyl%N8%Vz|?VfhIG+-|#<h1DRj{KRGi#wBu7k4l}m!>j#'
    'SPMOMMq>YLU52>!%Ve)7uc>DO<g?0#Hz7g6q7#V=&#IHfhT?jMGP!Gud7A!3+CmHUxgOE@biMA&uw*|KRqt|}ld<16WXCVlx13%='
    'E)we6PUzRR52m&Dcja67XvDsYc5|8SI}sPuJezhK5N}tPrA*rlW5+x#a}d&$yi%{Us(EIZ#EaA%9M@8f!vv7%x?71!_|AJH_;3R?'
    'M~Ss<91KC=g6Ukk#fIrU7pl%G?f?J)XII4hq?1qE00E=J0*0X;<T}dmvBYQl0ssI200dcD'
)
PROVER_NAME = "false-solver-d15"
PROVER_SCHEMA = "stage2-false-countermodel-prover-result-v1"
MAX_FALSE_CERTIFICATE_BYTES = 20_000

_TABLE_BYTES = None
_INFINITE_RULE_ROWS = None


class _SafetyWallExpired(Exception):
    pass


def _safety_wall_handler(_signum, _frame):
    raise _SafetyWallExpired("False prover safety wall expired")


def _arm_safety_wall(seconds):
    if not (
        hasattr(signal, "setitimer")
        and hasattr(signal, "SIGALRM")
        and hasattr(signal, "ITIMER_REAL")
    ):
        return None
    previous = signal.signal(signal.SIGALRM, _safety_wall_handler)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    return previous


def _disarm_safety_wall(previous):
    if previous is None:
        return
    signal.setitimer(signal.ITIMER_REAL, 0.0)
    signal.signal(signal.SIGALRM, previous)


def _runtime_config(config):
    if not isinstance(config, dict):
        raise TypeError("config must be an object")
    copied = dict(config)
    save_mode = copied.pop("result_save_mode", "minimal")
    if save_mode not in ("minimal", "full"):
        raise ValueError("result_save_mode must be minimal or full")
    nested = copied.pop("search_config", None)
    if nested is not None:
        if copied:
            raise ValueError("nested search_config cannot be mixed with top-level fields")
        if not isinstance(nested, dict):
            raise TypeError("search_config must be an object")
        copied = dict(nested)
    unknown = sorted(
        set(copied)
        - {"safety_wall_seconds", "use_finite_model_bank", "use_infinite_family_bank", "use_dynamic_model_search", "dynamic_search_seconds", "use_formula_cdcl_search", "formula_cdcl_search_seconds", "formula_cdcl_min_size", "formula_cdcl_max_size", "use_scalar_affine_search"}
    )
    if unknown:
        raise ValueError(f"unknown config fields: {unknown}")
    seconds = float(copied.get("safety_wall_seconds", 295.0))
    enabled = copied.get("use_finite_model_bank", True)
    infinite_enabled = copied.get("use_infinite_family_bank", True)
    scalar_affine_enabled = copied.get("use_scalar_affine_search", True)
    dynamic_enabled = copied.get("use_dynamic_model_search", True)
    dynamic_seconds = float(copied.get("dynamic_search_seconds", 1.0))
    formula_cdcl_enabled = copied.get("use_formula_cdcl_search", True)
    formula_cdcl_seconds = float(copied.get("formula_cdcl_search_seconds", 300.0))
    formula_cdcl_min_size = copied.get("formula_cdcl_min_size", 2)
    formula_cdcl_max_size = copied.get("formula_cdcl_max_size", 9)
    if not 0.01 <= seconds <= 3600.0:
        raise ValueError("safety_wall_seconds must be in [0.01, 3600]")
    if type(enabled) is not bool:
        raise TypeError("use_finite_model_bank must be a boolean")
    if type(infinite_enabled) is not bool:
        raise TypeError("use_infinite_family_bank must be a boolean")
    if type(scalar_affine_enabled) is not bool:
        raise TypeError("use_scalar_affine_search must be a boolean")
    if type(dynamic_enabled) is not bool:
        raise TypeError("use_dynamic_model_search must be a boolean")
    if not 0.0 <= dynamic_seconds <= 30.0:
        raise ValueError("dynamic_search_seconds must be in [0, 30]")
    if type(formula_cdcl_enabled) is not bool:
        raise TypeError("use_formula_cdcl_search must be a boolean")
    if not 0.0 <= formula_cdcl_seconds <= 300.0:
        raise ValueError("formula_cdcl_search_seconds must be in [0, 300]")
    if type(formula_cdcl_min_size) is not int or type(formula_cdcl_max_size) is not int:
        raise TypeError("formula CDCL domain bounds must be integers")
    if not 2 <= formula_cdcl_min_size <= formula_cdcl_max_size <= 9:
        raise ValueError("formula CDCL domain bounds must satisfy 2 <= min <= max <= 9")
    return (save_mode, seconds, enabled, infinite_enabled, scalar_affine_enabled,
            dynamic_enabled, dynamic_seconds, formula_cdcl_enabled,
            formula_cdcl_seconds, formula_cdcl_min_size, formula_cdcl_max_size)


def _case_formulas(case):
    if not isinstance(case, dict):
        raise TypeError("case must be an object")
    source = case.get("source_formula")
    target = case.get("target_formula")
    if not isinstance(source, str) or not source.strip():
        raise ValueError("case.source_formula must be a non-empty string")
    if not isinstance(target, str) or not target.strip():
        raise ValueError("case.target_formula must be a non-empty string")
    return case.get("ordinal"), case.get("id"), source, target


def _strip_outer_parentheses(text):
    text = text.strip()
    while len(text) >= 2 and text[0] == "(" and text[-1] == ")":
        depth = 0
        covers_all = True
        for index, character in enumerate(text):
            if character == "(":
                depth += 1
            elif character == ")":
                depth -= 1
                if depth < 0:
                    raise ValueError("unbalanced equation parentheses")
            if depth == 0 and index < len(text) - 1:
                covers_all = False
                break
        if not covers_all:
            break
        if depth != 0:
            raise ValueError("unbalanced equation parentheses")
        text = text[1:-1].strip()
    return text


def _parse_term(text, variable_indices):
    text = _strip_outer_parentheses(text)
    depth = 0
    last_operation = -1
    for index, character in enumerate(text):
        if character == "(":
            depth += 1
        elif character == ")":
            depth -= 1
            if depth < 0:
                raise ValueError("unbalanced equation parentheses")
        elif character == "◇" and depth == 0:
            last_operation = index
    if depth != 0:
        raise ValueError("unbalanced equation parentheses")
    if last_operation >= 0:
        return (
            _parse_term(text[:last_operation], variable_indices),
            _parse_term(text[last_operation + 1 :], variable_indices),
        )
    if len(text) == 1 and text in variable_indices:
        return variable_indices[text]
    raise ValueError(f"cannot parse term: {text!r}")


def _parse_equation(text):
    normalized = text.replace("*", "◇")
    if normalized.count("=") != 1 or "≠" in normalized:
        raise ValueError("formula must contain exactly one equality")
    variables = []
    seen = set()
    for variable in re.findall(r"\b([a-z])\b", normalized):
        if variable not in seen:
            seen.add(variable)
            variables.append(variable)
    if not variables:
        raise ValueError("formula has no variables")
    indices = {variable: index for index, variable in enumerate(variables)}
    lhs, rhs = normalized.split("=", 1)
    return variables, _parse_term(lhs, indices), _parse_term(rhs, indices)


def _source_pattern(parsed):
    _variables, lhs, rhs = parsed

    def encode(term):
        if type(term) is int:
            return term
        return ["op", encode(term[0]), encode(term[1])]

    return json.dumps([encode(lhs), encode(rhs)], separators=(",", ":"))


def _source_schema_match(source_pattern, parsed_source):
    """Match canonical source metavariables to arbitrary incoming terms."""

    pattern = json.loads(source_pattern)
    _variables, incoming_left, incoming_right = parsed_source
    environment = {}

    def match(pattern_term, incoming_term):
        if type(pattern_term) is int:
            if pattern_term in environment:
                return environment[pattern_term] == incoming_term
            environment[pattern_term] = incoming_term
            return True
        return (
            isinstance(pattern_term, list)
            and len(pattern_term) == 3
            and pattern_term[0] == "op"
            and type(incoming_term) is tuple
            and match(pattern_term[1], incoming_term[0])
            and match(pattern_term[2], incoming_term[1])
        )

    if not (
        match(pattern[0], incoming_left)
        and match(pattern[1], incoming_right)
    ):
        return None
    return environment


def _expanded_witness_vectors(witness_vectors, target_arity):
    ordered = []
    for vector in witness_vectors:
        vector = tuple(vector)
        if len(vector) == target_arity and vector not in ordered:
            ordered.append(vector)
    pool = []
    for vector in witness_vectors:
        for value in vector:
            if value not in pool:
                pool.append(value)
    products = sorted(
        product(pool, repeat=target_arity),
        key=lambda values: -len(set(values)),
    )
    for vector in products:
        if vector not in ordered:
            ordered.append(vector)
        if len(ordered) >= 8:
            break
    return tuple(ordered)


def _lean_open_term(term, variable_names):
    if type(term) is int:
        return variable_names[term]
    return (
        f"({_lean_open_term(term[0], variable_names)} ◇ "
        f"{_lean_open_term(term[1], variable_names)})"
    )


def _rewrite_source_branch(code, parsed_source, substitution, marker):
    marker_position = code.index(marker)
    branch_start = code.rfind("\n  · intro ", 0, marker_position)
    if branch_start < 0:
        return None
    branch_start += 1
    original = code[branch_start:marker_position].rstrip()
    lines = original.splitlines()
    introduction = re.fullmatch(r"  · intro (.+)", lines[0])
    if introduction is None:
        return None
    binders = introduction.group(1).split()
    if set(substitution) != set(range(len(binders))):
        return None
    incoming_variables = parsed_source[0]
    fresh_names = tuple(
        f"_d10v{index}" for index in range(len(incoming_variables))
    )
    replacements = {
        binder: _lean_open_term(substitution[index], fresh_names)
        for index, binder in enumerate(binders)
    }
    body = "\n".join(lines[1:])
    for variable in sorted(replacements, key=len, reverse=True):
        body = re.sub(
            rf"\b{re.escape(variable)}\b",
            f"({replacements[variable]})",
            body,
        )
    rewritten = "  · intro " + " ".join(fresh_names)
    if body:
        rewritten += "\n" + body
    return code[:branch_start] + rewritten + "\n" + code[marker_position:]


def _infinite_rules():
    global _INFINITE_RULE_ROWS
    if _INFINITE_RULE_ROWS is None:
        payload = lzma.decompress(base64.b85decode(_INFINITE_RULES_XZ_B85.encode("ascii")))
        rows = json.loads(payload.decode("utf-8"))
        if not isinstance(rows, list) or len(rows) != _INFINITE_RULE_COUNT:
            raise RuntimeError("infinite family payload count drift")
        _INFINITE_RULE_ROWS = rows
    return _INFINITE_RULE_ROWS


def _lean_closed_term(
    term,
    values,
    carrier_type,
    magma_instance,
    target_eval_function="",
    target_eval_opposite=False,
):
    if type(term) is int:
        return values[term]
    left = _lean_closed_term(
        term[0], values, carrier_type, magma_instance,
        target_eval_function, target_eval_opposite,
    )
    right = _lean_closed_term(
        term[1], values, carrier_type, magma_instance,
        target_eval_function, target_eval_opposite,
    )
    if target_eval_function:
        if target_eval_opposite:
            left, right = right, left
        return f"({target_eval_function} {left} {right})"
    return f"(@Magma.op {carrier_type} {magma_instance} {left} {right})"


def _symbolic_target_branch(
    parsed_target,
    witness_vectors,
    carrier_type,
    magma_instance,
    project_subtype_value,
    target_simp_lemmas,
    target_eval_function,
    target_eval_opposite,
    target_stepwise_raw,
):
    variables, left, right = parsed_target
    compatible = list(dict.fromkeys(
        tuple(values)
        for values in witness_vectors
        if len(values) == len(variables)
    ))
    if not compatible:
        return None
    if (
        type(target_stepwise_raw) is dict
        and target_stepwise_raw.get("mode") == "d14_named_value_rewrites"
    ):
        return _d14_named_value_target_branch(
            parsed_target,
            compatible,
            carrier_type,
            magma_instance,
            target_eval_function,
            target_eval_opposite,
            target_stepwise_raw,
        )
    lines = ["  · intro target", "    first"]
    for values in compatible:
        application = " ".join(values)
        typed_values = tuple(f"({value} : {carrier_type})" for value in values)
        symbolic_left = _lean_closed_term(
            left, typed_values, carrier_type, magma_instance,
            target_eval_function, target_eval_opposite,
        )
        symbolic_right = _lean_closed_term(
            right, typed_values, carrier_type, magma_instance,
            target_eval_function, target_eval_opposite,
        )
        original_left, original_right = symbolic_left, symbolic_right
        step_lines = []
        rewrites = []
        if target_stepwise_raw is True:
            constructor = f"{carrier_type.split('.')[0]}.p"
            cache = {}

            def evaluate(term):
                if type(term) is int:
                    return typed_values[term]
                left_value = evaluate(term[0])
                right_value = evaluate(term[1])
                call_left, call_right = left_value, right_value
                if target_eval_opposite:
                    call_left, call_right = call_right, call_left
                call = f"{target_eval_function} ({call_left}) ({call_right})"
                result = f"({constructor} ({call_left}) ({call_right}))"
                if call not in cache:
                    name = f"d10step{len(cache)}"
                    cache[call] = name
                    step_lines.extend(
                        (
                            f"      have {name} : {call} = {result} := by",
                            f"        simp [{', '.join(target_simp_lemmas)}]",
                        )
                    )
                    rewrites.append(name)
                return result

            symbolic_left = evaluate(left)
            symbolic_right = evaluate(right)
        lines.extend(
            (
                f"    | have bad := target {application}",
                *step_lines,
                f"      change {original_left} = {original_right} at bad",
                *((f"      rw [{', '.join(rewrites)}] at bad",) if rewrites else ()),
                *((f"      change {symbolic_left} = {symbolic_right} at bad",) if rewrites else ()),
                *(("      have badv := congrArg Subtype.val bad",) if project_subtype_value else ()),
                (
                    f"      simpa [{', '.join(target_simp_lemmas)}] using "
                    f"{'badv' if project_subtype_value else 'bad'}"
                    if target_simp_lemmas
                    else "      exact nomatch badv"
                    if project_subtype_value
                    else "      exact nomatch bad"
                ),
            )
        )
    if target_stepwise_raw == "d14_decide_closed_equality":
        lines = [
            (
                "      exact (show Not (_ = _) from by decide) bad"
                if line == "      exact nomatch bad"
                else line
            )
            for line in lines
        ]
    return "\n".join(lines)



def _d14_named_value_target_branch(
    parsed_target,
    compatible,
    carrier_type,
    magma_instance,
    target_eval_function,
    target_eval_opposite,
    normalization_spec,
):
    """Render exact value-lemma rewrites selected from the target AST."""

    if not target_eval_function:
        return None
    rules = {
        (left, right): (result, lemma)
        for left, right, result, lemma in normalization_spec["rules"]
    }
    aliases = normalization_spec.get("aliases", {})

    def normalize(term, values):
        if type(term) is int:
            value = values[term]
            return aliases.get(value, value), ()
        left = normalize(term[0], values)
        right = normalize(term[1], values)
        if left is None or right is None:
            return None
        left_value, left_lemmas = left
        right_value, right_lemmas = right
        if target_eval_opposite:
            left_value, right_value = right_value, left_value
        rule = rules.get((left_value, right_value))
        if rule is None:
            return None
        result, lemma = rule
        return result, (*left_lemmas, *right_lemmas, lemma)

    variables, left, right = parsed_target
    lines = ["  · intro target", "    first"]
    branch_count = 0
    for values in compatible:
        rendered_values = tuple(aliases.get(value, value) for value in values)
        normalized_left = normalize(left, rendered_values)
        normalized_right = normalize(right, rendered_values)
        if normalized_left is None or normalized_right is None:
            continue
        left_value, left_lemmas = normalized_left
        right_value, right_lemmas = normalized_right
        if left_value == right_value:
            continue
        lemmas = tuple(dict.fromkeys((*left_lemmas, *right_lemmas)))
        typed_values = tuple(
            f"({value} : {carrier_type})" for value in rendered_values
        )
        original_left = _lean_closed_term(
            left,
            typed_values,
            carrier_type,
            magma_instance,
            target_eval_function,
            target_eval_opposite,
        )
        original_right = _lean_closed_term(
            right,
            typed_values,
            carrier_type,
            magma_instance,
            target_eval_function,
            target_eval_opposite,
        )
        application = " ".join(rendered_values)
        lines.extend(
            (
                f"    | have bad := target {application}",
                f"      change {original_left} = {original_right} at bad",
                *((f"      rw [{', '.join(lemmas)}] at bad",) if lemmas else ()),
                "      exact nomatch bad",
            )
        )
        branch_count += 1
    return "\n".join(lines) if branch_count else None


_D14_AFFINE_PRIMES = (2, 3, 5, 7, 11, 13, 17, 19)


def _d14_affine_coefficients(term, variable_count, left_coefficient,
                               right_coefficient, constant, prime):
    """Return exact affine coefficients, with the constant in the last slot."""

    if type(term) is int:
        values = [0] * (variable_count + 1)
        values[term] = 1
        return tuple(values)
    left = _d14_affine_coefficients(
        term[0], variable_count, left_coefficient, right_coefficient,
        constant, prime,
    )
    right = _d14_affine_coefficients(
        term[1], variable_count, left_coefficient, right_coefficient,
        constant, prime,
    )
    values = [
        (left_coefficient * left[index] + right_coefficient * right[index])
        % prime
        for index in range(variable_count + 1)
    ]
    values[-1] = (values[-1] + constant) % prime
    return tuple(values)


def _d14_affine_difference(parsed, left_coefficient, right_coefficient,
                            constant, prime):
    variables, lhs, rhs = parsed
    left = _d14_affine_coefficients(
        lhs, len(variables), left_coefficient, right_coefficient, constant, prime
    )
    right = _d14_affine_coefficients(
        rhs, len(variables), left_coefficient, right_coefficient, constant, prime
    )
    return tuple((a - b) % prime for a, b in zip(left, right))


def _d14_scalar_affine_countermodel(parsed_source, parsed_target, metrics):
    """Exactly enumerate scalar-affine prime-field models through order 19."""

    checks = 0
    for prime in _D14_AFFINE_PRIMES:
        for left_coefficient in range(prime):
            for right_coefficient in range(prime):
                for constant in range(prime):
                    checks += 1
                    source_difference = _d14_affine_difference(
                        parsed_source,
                        left_coefficient,
                        right_coefficient,
                        constant,
                        prime,
                    )
                    if any(source_difference):
                        continue
                    target_difference = _d14_affine_difference(
                        parsed_target,
                        left_coefficient,
                        right_coefficient,
                        constant,
                        prime,
                    )
                    if not any(target_difference):
                        continue
                    table = [
                        [
                            (
                                left_coefficient * row
                                + right_coefficient * column
                                + constant
                            )
                            % prime
                            for column in range(prime)
                        ]
                        for row in range(prime)
                    ]
                    metrics["scalar_affine_parameter_checks"] = checks
                    metrics["scalar_affine_found_order"] = prime
                    return table, {
                        "prime": prime,
                        "left_coefficient": left_coefficient,
                        "right_coefficient": right_coefficient,
                        "constant": constant,
                    }
    metrics["scalar_affine_parameter_checks"] = checks
    return None



_D15_EXP5_FAMILY = "opposite_exp5_group_core_zmod5_power4"
_D15_EXP5_MODEL_CORE = 'import JudgeProblem\nimport Mathlib.Tactic.NormNum\nimport Mathlib.Tactic.Ring.RingNF\n\nopen scoped Fin.CommRing\n\nset_option maxRecDepth 1000000\nset_option maxHeartbeats 0\n\nnamespace submission\n\n@[ext] structure G where\n  a : Fin 5\n  b : Fin 5\n  c : Fin 5\n  d : Fin 5\n\nnamespace G\n\ndef q (x : Fin 5) : Fin 5 := 3 * x * (x + 1)\n\ndef mul (x y : G) : G :=\n  ⟨x.a + y.a,\n   x.b + y.b + x.a * y.d,\n   x.c + y.c + x.a * q y.d + x.b * y.d,\n   x.d + y.d⟩\n\ndef inv (x : G) : G :=\n  ⟨-x.a,\n   -x.b + x.a * x.d,\n   -x.c + x.a * q x.d + x.b * x.d - x.a * x.d * x.d,\n   -x.d⟩\n\ndef coreOp (x y : G) : G := mul (mul x (inv y)) x\n\ndef op (x y : G) : G := coreOp y x\n\ninstance instMagma : Magma G where\n  op := op\n\n'
_D15_EXP5_SOURCE_PROOFS = {'[0,["op",1,["op",0,["op",1,["op",["op",0,2],2]]]]]': 'lemma source_holds : EquationLHS G := by\n  intro x y z\n  change x = op y (op x (op y (op (op x z) z)))\n  rcases x with ⟨xa, xb, xc, xd⟩\n  rcases y with ⟨ya, yb, yc, yd⟩\n  rcases z with ⟨za, zb, zc, zd⟩\n  have h6 : (6 : Fin 5) = 1 := by decide\n  have h5 : (5 : Fin 5) = 0 := by decide\n  have h15 : (15 : Fin 5) = 0 := by decide\n  have h20 : (20 : Fin 5) = 0 := by decide\n  have h25 : (25 : Fin 5) = 0 := by decide\n  have h40 : (40 : Fin 5) = 0 := by decide\n  have h45 : (45 : Fin 5) = 0 := by decide\n  have h55 : (55 : Fin 5) = 0 := by decide\n  have h70 : (70 : Fin 5) = 0 := by decide\n  have h80 : (80 : Fin 5) = 0 := by decide\n  have h100 : (100 : Fin 5) = 0 := by decide\n  have h105 : (105 : Fin 5) = 0 := by decide\n  have h120 : (120 : Fin 5) = 0 := by decide\n  have h130 : (130 : Fin 5) = 0 := by decide\n  have h145 : (145 : Fin 5) = 0 := by decide\n  have h165 : (165 : Fin 5) = 0 := by decide\n  have h200 : (200 : Fin 5) = 0 := by decide\n  have h240 : (240 : Fin 5) = 0 := by decide\n  apply G.ext <;> simp [op, coreOp, mul, inv, q] <;> ring_nf\n  all_goals simp only [h6, h5, h15, h20, h25, h40, h45, h55, h70, h80, h100, h105, h120, h130, h145, h165, h200, h240, mul_zero, zero_mul, mul_one, one_mul, add_zero, zero_add, sub_zero]\n\n', '[0,["op",1,["op",["op",0,1],["op",["op",0,2],2]]]]': 'lemma source_holds : EquationLHS G := by\n  intro x y z\n  change x = op y (op (op x y) (op (op x z) z))\n  rcases x with ⟨xa, xb, xc, xd⟩\n  rcases y with ⟨ya, yb, yc, yd⟩\n  rcases z with ⟨za, zb, zc, zd⟩\n  have h6 : (6 : Fin 5) = 1 := by decide\n  have h5 : (5 : Fin 5) = 0 := by decide\n  have h15 : (15 : Fin 5) = 0 := by decide\n  have h20 : (20 : Fin 5) = 0 := by decide\n  have h25 : (25 : Fin 5) = 0 := by decide\n  have h40 : (40 : Fin 5) = 0 := by decide\n  have h45 : (45 : Fin 5) = 0 := by decide\n  have h55 : (55 : Fin 5) = 0 := by decide\n  have h70 : (70 : Fin 5) = 0 := by decide\n  have h80 : (80 : Fin 5) = 0 := by decide\n  have h100 : (100 : Fin 5) = 0 := by decide\n  have h105 : (105 : Fin 5) = 0 := by decide\n  have h120 : (120 : Fin 5) = 0 := by decide\n  have h130 : (130 : Fin 5) = 0 := by decide\n  have h145 : (145 : Fin 5) = 0 := by decide\n  have h165 : (165 : Fin 5) = 0 := by decide\n  have h200 : (200 : Fin 5) = 0 := by decide\n  have h240 : (240 : Fin 5) = 0 := by decide\n  apply G.ext <;> simp [op, coreOp, mul, inv, q] <;> ring_nf\n  all_goals simp only [h6, h5, h15, h20, h25, h40, h45, h55, h70, h80, h100, h105, h120, h130, h145, h165, h200, h240, mul_zero, zero_mul, mul_one, one_mul, add_zero, zero_add, sub_zero]\n\n'}
_D15_EXP5_WITNESS_POOL = (
    (0, 0, 0, 0),
    (1, 0, 0, 0),
    (0, 0, 0, 1),
)


def _d15_exp5_q(value):
    return (3 * value * (value + 1)) % 5


def _d15_exp5_mul(left, right):
    xa, xb, xc, xd = left
    ya, yb, yc, yd = right
    return (
        (xa + ya) % 5,
        (xb + yb + xa * yd) % 5,
        (xc + yc + xa * _d15_exp5_q(yd) + xb * yd) % 5,
        (xd + yd) % 5,
    )


def _d15_exp5_inv(value):
    xa, xb, xc, xd = value
    return (
        (-xa) % 5,
        (-xb + xa * xd) % 5,
        (-xc + xa * _d15_exp5_q(xd) + xb * xd - xa * xd * xd) % 5,
        (-xd) % 5,
    )


def _d15_exp5_op(left, right):
    # Opposite of coreOp: coreOp right left.
    return _d15_exp5_mul(
        _d15_exp5_mul(right, _d15_exp5_inv(left)), right
    )


def _d15_exp5_eval(term, values):
    if type(term) is int:
        return values[term]
    return _d15_exp5_op(
        _d15_exp5_eval(term[0], values),
        _d15_exp5_eval(term[1], values),
    )


def _d15_exp5_literal(value):
    return "(⟨" + ", ".join(str(item) for item in value) + "⟩ : G)"


def _d15_exp5_lean_term(term, values):
    if type(term) is int:
        return _d15_exp5_literal(values[term])
    return (
        "(G.op "
        + _d15_exp5_lean_term(term[0], values)
        + " "
        + _d15_exp5_lean_term(term[1], values)
        + ")"
    )


def _d15_exp5_candidate(parsed_source, parsed_target):
    source_pattern = _source_pattern(parsed_source)
    source_proof = _D15_EXP5_SOURCE_PROOFS.get(source_pattern)
    if source_proof is None:
        return None
    variables, left, right = parsed_target
    if not 1 <= len(variables) <= 4:
        return None
    for values in product(_D15_EXP5_WITNESS_POOL, repeat=len(variables)):
        left_value = _d15_exp5_eval(left, values)
        right_value = _d15_exp5_eval(right, values)
        if left_value == right_value:
            continue
        applications = " ".join(_d15_exp5_literal(value) for value in values)
        closed_left = _d15_exp5_lean_term(left, values)
        closed_right = _d15_exp5_lean_term(right, values)
        target_proof = (
            "lemma target_fails : ¬ EquationRHS G := by\n"
            "  intro target\n"
            f"  have bad := target {applications}\n"
            "  have hc := congrArg G.c bad\n"
            f"  change ({closed_left}).c = ({closed_right}).c at hc\n"
            f"  exact (show Not (({closed_left}).c = ({closed_right}).c) "
            "from by decide) hc\n\n"
        )
        suffix = (
            "end G\n\n"
            "def certificate : Goal :=\n"
            "  ⟨G, G.instMagma, G.source_holds, G.target_fails⟩\n\n"
            "end submission\n\n"
            "def submission : Goal := submission.certificate\n"
        )
        return (
            _D15_EXP5_FAMILY,
            _D15_EXP5_MODEL_CORE + source_proof + target_proof + suffix,
            "alpha_exact_source_law_and_bounded_target_ast_witness",
        )
    return None



_D15_ACCEPTED_CM_FAMILY = "d15_inductive_accepted_cm_transfer"
_D15_ACCEPTED_CM_MODEL_CORE = 'import JudgeProblem\nimport Mathlib\n\nset_option maxRecDepth 10000\n\nnamespace submission\n\nabbrev NE {α : Type} (a b : α) : Prop := Not (a = b)\ninfix:50 " ≢ " => NE\n\ndef condEq {α β : Type} [DecidableEq α] (a b : α) (yes no : β) : β :=\n  match decEq a b with\n  | isTrue _ => yes\n  | isFalse _ => no\n\nlemma condEq_pos {α β : Type} [DecidableEq α]\n    {a b : α} {yes no : β} (h : a = b) : condEq a b yes no = yes := by\n  subst b\n  unfold condEq\n  cases decEq a a with\n  | isTrue _ => rfl\n  | isFalse h => exact (h rfl).elim\n\nlemma condEq_neg {α β : Type} [DecidableEq α]\n    {a b : α} {yes no : β} (h : a ≢ b) : condEq a b yes no = no := by\n  unfold condEq\n  cases decEq a b with\n  | isTrue hab => exact (h hab).elim\n  | isFalse _ => rfl\n\ninductive CM where\n  | e : CM\n  | k : CM → CM\n  | p : CM → CM → CM\n\nnamespace CM\n\ndef cmDecEq : (a b : CM) → Decidable (a = b)\n  | .e, .e => isTrue rfl\n  | .e, .k _ => isFalse (fun h => CM.noConfusion h)\n  | .e, .p _ _ => isFalse (fun h => CM.noConfusion h)\n  | .k _, .e => isFalse (fun h => CM.noConfusion h)\n  | .p _ _, .e => isFalse (fun h => CM.noConfusion h)\n  | .k a, .k b =>\n      match cmDecEq a b with\n      | isTrue h => isTrue (congrArg CM.k h)\n      | isFalse h => isFalse (fun hab => h (CM.k.inj hab))\n  | .k _, .p _ _ => isFalse (fun h => CM.noConfusion h)\n  | .p _ _, .k _ => isFalse (fun h => CM.noConfusion h)\n  | .p a b, .p c d =>\n      match cmDecEq a c with\n      | isFalse h => isFalse (fun hab => h (CM.p.inj hab).1)\n      | isTrue hac =>\n          match cmDecEq b d with\n          | isFalse h => isFalse (fun hab => h (CM.p.inj hab).2)\n          | isTrue hbd => isTrue (by cases hac; cases hbd; rfl)\n\ninstance instDecidableEq : DecidableEq CM := cmDecEq\n\ndef sz : CM → Nat\n  | .e => 0\n  | .k x => sz x + 1\n  | .p x y => (sz x + 1) + (sz y + 1)\n\ndef dec : CM → CM\n  | .e => .e\n  | .k x => x\n  | .p a b =>\n      condEq b a (.k a)\n        (match b with\n        | .p c x => condEq c a x .e\n        | _ => .e)\n\nlemma dec_p_eq (a b : CM) :\n    dec (.p a b) = condEq b a (.k a)\n      (match b with\n      | .p c x => condEq c a x .e\n      | _ => .e) := rfl\n\nlemma dec_p_p_eq (a c x : CM) :\n    dec (CM.p a (CM.p c x)) =\n      condEq (CM.p c x) a (CM.k a) (condEq c a x CM.e) := rfl\n\ndef op (a b : CM) : CM :=\n  condEq b .e (dec a) (condEq a (.p b b) .e (.p a b))\n\ninstance instMagma : Magma CM where\n  op := op\n\nlemma sz_p_pos (a b : CM) : 0 < sz (.p a b) := by\n  change 0 < (sz a + 1) + (sz b + 1)\n  exact Nat.lt_of_lt_of_le (Nat.zero_lt_succ (sz a))\n    (Nat.le_add_right (sz a + 1) (sz b + 1))\n\nlemma sz_lt_p_left (a b : CM) : sz a < sz (.p a b) := by\n  change sz a < (sz a + 1) + (sz b + 1)\n  exact Nat.lt_of_lt_of_le (Nat.lt_succ_self (sz a))\n    (Nat.le_add_right (sz a + 1) (sz b + 1))\n\nlemma sz_dec_le (a : CM) : sz (dec a) ≤ sz a := by\n  cases a with\n  | e => exact Nat.le_refl 0\n  | k x =>\n      change sz x ≤ sz x + 1\n      exact Nat.le_add_right (sz x) 1\n  | p a b =>\n      by_cases hba : b = a\n      · subst b\n        rw [dec_p_eq]\n        rw [condEq_pos rfl]\n        change sz a + 1 ≤ (sz a + 1) + (sz a + 1)\n        exact Nat.le_add_right (sz a + 1) (sz a + 1)\n      · cases b with\n        | e =>\n            rw [dec_p_eq]\n            rw [condEq_neg hba]\n            exact Nat.zero_le _\n        | k b =>\n            rw [dec_p_eq]\n            rw [condEq_neg hba]\n            exact Nat.zero_le _\n        | p c x =>\n            by_cases hca : c = a\n            · subst c\n              rw [dec_p_p_eq]\n              rw [condEq_neg hba, condEq_pos rfl]\n              change sz x ≤ (sz a + 1) + (((sz a + 1) + (sz x + 1)) + 1)\n              exact Nat.le_trans (Nat.le_add_right (sz x) 1)\n                (Nat.le_trans (Nat.le_add_left (sz x + 1) (sz a + 1))\n                  (Nat.le_trans\n                    (Nat.le_add_right ((sz a + 1) + (sz x + 1)) 1)\n                    (Nat.le_add_left (((sz a + 1) + (sz x + 1)) + 1) (sz a + 1))))\n            · rw [dec_p_p_eq]\n              rw [condEq_neg hba, condEq_neg hca]\n              exact Nat.zero_le _\n\nlemma sz_dec_lt_of_ne_e (a : CM) (ha : a ≢ .e) : sz (dec a) < sz a := by\n  cases a with\n  | e => exact (ha rfl).elim\n  | k x =>\n      change sz x < sz x + 1\n      exact Nat.lt_succ_self (sz x)\n  | p a b =>\n      by_cases hba : b = a\n      · subst b\n        rw [dec_p_eq]\n        rw [condEq_pos rfl]\n        change sz a + 1 < (sz a + 1) + (sz a + 1)\n        exact Nat.lt_add_of_pos_right (Nat.zero_lt_succ (sz a))\n      · cases b with\n        | e =>\n            rw [dec_p_eq]\n            rw [condEq_neg hba]\n            exact sz_p_pos _ _\n        | k b =>\n            rw [dec_p_eq]\n            rw [condEq_neg hba]\n            exact sz_p_pos _ _\n        | p c x =>\n            by_cases hca : c = a\n            · subst c\n              rw [dec_p_p_eq]\n              rw [condEq_neg hba, condEq_pos rfl]\n              change sz x < (sz a + 1) + (((sz a + 1) + (sz x + 1)) + 1)\n              exact Nat.lt_of_lt_of_le (Nat.lt_succ_self (sz x))\n                (Nat.le_trans (Nat.le_add_left (sz x + 1) (sz a + 1))\n                  (Nat.le_trans\n                    (Nat.le_add_right ((sz a + 1) + (sz x + 1)) 1)\n                    (Nat.le_add_left (((sz a + 1) + (sz x + 1)) + 1) (sz a + 1))))\n            · rw [dec_p_p_eq]\n              rw [condEq_neg hba, condEq_neg hca]\n              exact sz_p_pos _ _\n\nlemma ne_self_p (a b : CM) : a ≢ .p a b := by\n  intro h\n  have hs := congrArg sz h\n  exact (Nat.ne_of_lt (sz_lt_p_left a b)) hs\n\nlemma dec_ne_p_self (a b : CM) : dec a ≢ .p a b := by\n  intro h\n  have hle := sz_dec_le a\n  have hs := congrArg sz h\n  rw [hs] at hle\n  exact (Nat.lt_irrefl (sz a))\n    (Nat.lt_of_lt_of_le (sz_lt_p_left a b) hle)\n\nlemma dec_ne_self_of_dec_ne_e (a : CM) (ha : dec a ≢ .e) : dec a ≢ a := by\n  have hae : a ≢ .e := by\n    intro h\n    subst a\n    exact ha rfl\n  intro h\n  have hlt := sz_dec_lt_of_ne_e a hae\n  have hs := congrArg sz h\n  rw [hs] at hlt\n  exact (Nat.lt_irrefl (sz a)) hlt\n\nlemma dec_p_default (a b : CM) (hba : b ≢ a)\n    (hshape : ∀ x, b ≢ .p a x) : dec (.p a b) = .e := by\n  cases b with\n  | e =>\n      rw [dec_p_eq]\n      rw [condEq_neg hba]\n  | k x =>\n      rw [dec_p_eq]\n      rw [condEq_neg hba]\n  | p c x =>\n      have hca : c ≢ a := by\n        intro h\n        subst c\n        exact hshape x rfl\n      rw [dec_p_p_eq]\n      rw [condEq_neg hba, condEq_neg hca]\n\nlemma dec_p_same (a : CM) : dec (.p a a) = .k a := by\n  rw [dec_p_eq]\n  rw [condEq_pos rfl]\n\nlemma dec_p_nested (a x : CM) : dec (.p a (.p a x)) = x := by\n  have hba : .p a x ≢ a := by\n    intro h\n    exact ne_self_p a x h.symm\n  rw [dec_p_p_eq]\n  rw [condEq_neg hba, condEq_pos rfl]\n\nlemma op_right_e (a : CM) : op a .e = dec a := by\n  unfold op\n  rw [condEq_pos rfl]\n\nlemma op_normal (a b : CM) (hb : b ≢ .e) (ha : a ≢ .p b b) :\n    op a b = .p a b := by\n  unfold op\n  rw [condEq_neg hb, condEq_neg ha]\n\nlemma op_special (a b : CM) (hb : b ≢ .e) (ha : a = .p b b) :\n    op a b = .e := by\n  unfold op\n  rw [condEq_neg hb, condEq_pos ha]\n\nlemma decode_twice (y x : CM) : dec (op y (op y x)) = x := by\n  by_cases hx : x = .e\n  · subst x\n    by_cases hd : dec y = .e\n    · calc\n        dec (op y (op y .e)) = dec (op y (dec y)) := by rw [op_right_e]\n        _ = dec (op y .e) := by rw [hd]\n        _ = dec (dec y) := by rw [op_right_e]\n        _ = dec .e := by rw [hd]\n        _ = .e := rfl\n    · by_cases hy : y = .p (dec y) (dec y)\n      · have oy : op y (dec y) = .e := op_special y (dec y) hd hy\n        calc\n          dec (op y (op y .e)) = dec (op y (dec y)) := by rw [op_right_e]\n          _ = dec .e := by rw [oy]\n          _ = .e := rfl\n      · have hdy : dec y ≢ y := dec_ne_self_of_dec_ne_e y hd\n        have hshape : ∀ q, dec y ≢ .p y q := fun q => dec_ne_p_self y q\n        have hdefault : dec (.p y (dec y)) = .e :=\n          dec_p_default y (dec y) hdy hshape\n        have oy : op y (dec y) = .p y (dec y) := op_normal y (dec y) hd hy\n        calc\n          dec (op y (op y .e)) = dec (op y (dec y)) := by rw [op_right_e]\n          _ = dec (.p y (dec y)) := by rw [oy]\n          _ = .e := hdefault\n  · by_cases hy : y = .p x x\n    · subst y\n      have hinner : op (.p x x) x = .e := op_special (.p x x) x hx rfl\n      calc\n        dec (op (.p x x) (op (.p x x) x)) = dec (op (.p x x) .e) := by rw [hinner]\n        _ = dec (dec (.p x x)) := by rw [op_right_e]\n        _ = dec (.k x) := by rw [dec_p_same]\n        _ = x := rfl\n    · have hbig : y ≢ .p (.p y x) (.p y x) := by\n        intro h\n        have hs := congrArg sz h\n        have hlt := Nat.lt_trans (sz_lt_p_left y x)\n          (sz_lt_p_left (.p y x) (.p y x))\n        exact (Nat.ne_of_lt hlt) hs\n      have hpxe : CM.p y x ≢ CM.e := by\n        intro h\n        exact CM.noConfusion h\n      have hinner : op y x = .p y x := op_normal y x hx hy\n      have houter : op y (.p y x) = .p y (.p y x) :=\n        op_normal y (.p y x) hpxe hbig\n      calc\n        dec (op y (op y x)) = dec (op y (.p y x)) := by rw [hinner]\n        _ = dec (.p y (.p y x)) := by rw [houter]\n        _ = x := dec_p_nested y x\n\nlemma triple (z : CM) : op (op z z) z = .e := by\n  by_cases hz : z = .e\n  · subst z\n    have hee : op CM.e CM.e = CM.e := by\n      calc\n        op CM.e CM.e = dec CM.e := op_right_e CM.e\n        _ = CM.e := rfl\n    exact (congrArg (fun q => op q CM.e) hee).trans hee\n  · have hself : z ≢ .p z z := ne_self_p z z\n    have hinner : op z z = .p z z := op_normal z z hz hself\n    calc\n      op (op z z) z = op (.p z z) z := by rw [hinner]\n      _ = .e := op_special (.p z z) z hz rfl\n\nend CM\n\nend submission\n\nopen submission\n\nopen submission\n\n'
_D15_ACCEPTED_CM_SOURCE_BRANCHES = {'[0,["op",["op",1,["op",1,1]],["op",["op",0,1],1]]]': '  · intro x y\n    change x = CM.op (CM.op y (CM.op y x)) (CM.op (CM.op y y) y)\n    rw [CM.triple]\n    change x = CM.dec (CM.op y (CM.op y x))\n    exact (CM.decode_twice y x).symm\n', '[0,["op",["op",1,["op",1,1]],["op",["op",0,2],2]]]': '  · intro x y z\n    change x = CM.op (CM.op z (CM.op z x)) (CM.op (CM.op y y) y)\n    rw [CM.triple]\n    change x = CM.dec (CM.op z (CM.op z x))\n    exact (CM.decode_twice z x).symm\n'}
_D15_ACCEPTED_CM_WITNESS_POOL = (
    ("e",),
    ("k", ("e",)),
)


def _d15_accepted_cm_dec(value):
    tag = value[0]
    if tag == "e":
        return value
    if tag == "k":
        return value[1]
    left, right = value[1], value[2]
    if right == left:
        return ("k", left)
    if right[0] == "p" and right[1] == left:
        return right[2]
    return ("e",)


def _d15_accepted_cm_core_op(left, right):
    if right == ("e",):
        return _d15_accepted_cm_dec(left)
    if left == ("p", right, right):
        return ("e",)
    return ("p", left, right)


def _d15_accepted_cm_opposite(left, right):
    return _d15_accepted_cm_core_op(right, left)


def _d15_accepted_cm_eval(term, values):
    if type(term) is int:
        return values[term]
    return _d15_accepted_cm_opposite(
        _d15_accepted_cm_eval(term[0], values),
        _d15_accepted_cm_eval(term[1], values),
    )


def _d15_accepted_cm_literal(value):
    tag = value[0]
    if tag == "e":
        return "CM.e"
    if tag == "k":
        return f"(CM.k {_d15_accepted_cm_literal(value[1])})"
    return (
        f"(CM.p {_d15_accepted_cm_literal(value[1])} "
        f"{_d15_accepted_cm_literal(value[2])})"
    )


def _d15_accepted_cm_lean_term(term, values):
    if type(term) is int:
        return _d15_accepted_cm_literal(values[term])
    left = _d15_accepted_cm_lean_term(term[0], values)
    right = _d15_accepted_cm_lean_term(term[1], values)
    return f"(CM.op {right} {left})"


def _d15_accepted_cm_candidate(parsed_source, parsed_target):
    source_pattern = _source_pattern(parsed_source)
    source_branch = _D15_ACCEPTED_CM_SOURCE_BRANCHES.get(source_pattern)
    if source_branch is None:
        return None
    variables, left, right = parsed_target
    if not 1 <= len(variables) <= 4:
        return None
    for values in product(_D15_ACCEPTED_CM_WITNESS_POOL, repeat=len(variables)):
        if _d15_accepted_cm_eval(left, values) == _d15_accepted_cm_eval(right, values):
            continue
        applications = " ".join(_d15_accepted_cm_literal(value) for value in values)
        closed_left = _d15_accepted_cm_lean_term(left, values)
        closed_right = _d15_accepted_cm_lean_term(right, values)
        target_branch = (
            "  · intro target\n"
            f"    have bad := target {applications}\n"
            f"    change {closed_left} = {closed_right} at bad\n"
            f"    exact (show Not ({closed_left} = {closed_right}) "
            "from by decide) bad\n"
        )
        submission = (
            "def submission.d15OppositeMagmaCM : Magma CM where\n"
            "  op a b := CM.op b a\n\n"
            "def submission : Goal := by\n"
            "  refine ⟨CM, d15OppositeMagmaCM, ?_, ?_⟩\n"
        )
        return (
            _D15_ACCEPTED_CM_FAMILY,
            _D15_ACCEPTED_CM_MODEL_CORE + submission + source_branch + target_branch,
            "alpha_exact_source_law_and_bounded_target_ast_witness",
        )
    return None



_D15_PATTERN_CM_FAMILY = "d15_inductive_pattern_cm_transfer"
_D15_PATTERN_CM_MODEL_CORE = "import JudgeProblem\nimport Mathlib\n\nset_option maxRecDepth 10000\n\nnamespace submission\n\ninductive CM where\n  | e : CM\n  | k : CM → CM\n  | p : CM → CM → CM\n\nnamespace CM\n\ndef cmDecEq : (a b : CM) → Decidable (a = b)\n  | CM.e, CM.e => isTrue rfl\n  | CM.e, CM.k _ => isFalse (fun h => CM.noConfusion h)\n  | CM.e, CM.p _ _ => isFalse (fun h => CM.noConfusion h)\n  | CM.k _, CM.e => isFalse (fun h => CM.noConfusion h)\n  | CM.p _ _, CM.e => isFalse (fun h => CM.noConfusion h)\n  | CM.k a, CM.k b =>\n      match cmDecEq a b with\n      | isTrue h => isTrue (congrArg CM.k h)\n      | isFalse h => isFalse (fun hab => h (CM.k.inj hab))\n  | CM.k _, CM.p _ _ => isFalse (fun h => CM.noConfusion h)\n  | CM.p _ _, CM.k _ => isFalse (fun h => CM.noConfusion h)\n  | CM.p a b, CM.p c d =>\n      match cmDecEq a c with\n      | isFalse h => isFalse (fun hab => h (CM.p.inj hab).1)\n      | isTrue hac =>\n          match cmDecEq b d with\n          | isFalse h => isFalse (fun hab => h (CM.p.inj hab).2)\n          | isTrue hbd => isTrue (by cases hac; cases hbd; rfl)\n\ninstance instDecidableEq : DecidableEq CM := cmDecEq\n\ndef sz : CM → Nat\n  | CM.e => 0\n  | CM.k x => sz x + 1\n  | CM.p x y => (sz x + 1) + (sz y + 1)\n\nlemma sz_lt_p_left (a b : CM) : sz a < sz (CM.p a b) := by\n  change sz a < (sz a + 1) + (sz b + 1)\n  exact Nat.lt_of_lt_of_le (Nat.lt_succ_self (sz a))\n    (Nat.le_add_right (sz a + 1) (sz b + 1))\n\nlemma sz_lt_p_right (a b : CM) : sz b < sz (CM.p a b) := by\n  change sz b < (sz a + 1) + (sz b + 1)\n  exact Nat.lt_of_lt_of_le (Nat.lt_succ_self (sz b))\n    (Nat.le_add_left (sz b + 1) (sz a + 1))\n\nstructure Pat1 where\n  y : CM\n  x : CM\n  z : CM\n\nstructure Pat2 where\n  a : CM\n  b : CM\n  c : CM\n\ndef left1 (m : Pat1) : CM := CM.p m.y (CM.p m.x m.x)\ndef right1 (m : Pat1) : CM := CM.p (CM.p m.y m.z) m.y\ndef left2 (m : Pat2) : CM := CM.p (CM.p m.a (CM.p m.b m.b)) (CM.p m.c m.c)\ndef right2 (m : Pat2) : CM := CM.p m.b (CM.p m.a (CM.p m.b m.b))\n\nabbrev No1 (a b : CM) := (m : Pat1) → a = left1 m → b = right1 m → False\nabbrev No2 (a b : CM) := (m : Pat2) → a = left2 m → b = right2 m → False\n\ndef get1Y : CM → CM\n  | CM.p y _ => y\n  | _ => CM.e\n\ndef get1X : CM → CM\n  | CM.p _ (CM.p x _) => x\n  | _ => CM.e\n\ndef get1Z : CM → CM\n  | CM.p (CM.p _ z) _ => z\n  | _ => CM.e\n\ndef get2A : CM → CM\n  | CM.p (CM.p a _) _ => a\n  | _ => CM.e\n\ndef get2B : CM → CM\n  | CM.p (CM.p _ (CM.p b _)) _ => b\n  | _ => CM.e\n\ndef get2C : CM → CM\n  | CM.p _ (CM.p c _) => c\n  | _ => CM.e\n\ninductive Detect1 (a b : CM) where\n  | yes (m : Pat1) (ha : a = left1 m) (hb : b = right1 m)\n  | no (h : No1 a b)\n\ninductive Detect2 (a b : CM) where\n  | yes (m : Pat2) (ha : a = left2 m) (hb : b = right2 m)\n  | no (h : No2 a b)\n\ndef detect1 (a b : CM) : Detect1 a b :=\n  let m : Pat1 := ⟨get1Y a, get1X a, get1Z b⟩\n  match cmDecEq a (left1 m) with\n  | isFalse ha => .no (fun q hqa _ => by cases hqa; exact ha rfl)\n  | isTrue ha =>\n      match cmDecEq b (right1 m) with\n      | isFalse hb => .no (fun q hqa hqb => by\n          cases hqa\n          cases hqb\n          exact hb rfl)\n      | isTrue hb => .yes m ha hb\n\ndef detect2 (a b : CM) : Detect2 a b :=\n  let m : Pat2 := ⟨get2A a, get2B a, get2C a⟩\n  match cmDecEq a (left2 m) with\n  | isFalse ha => .no (fun q hqa _ => by cases hqa; exact ha rfl)\n  | isTrue ha =>\n      match cmDecEq b (right2 m) with\n      | isFalse hb => .no (fun q hqa hqb => by\n          cases hqa\n          cases hqb\n          exact hb rfl)\n      | isTrue hb => .yes m ha hb\n\ninductive View (a b : CM) where\n  | r1 (m : Pat1) (ha : a = left1 m) (hb : b = right1 m)\n  | r2 (m : Pat2) (ha : a = left2 m) (hb : b = right2 m)\n  | raw (h1 : No1 a b) (h2 : No2 a b)\n\ndef view (a b : CM) : View a b :=\n  match detect1 a b with\n  | .yes m ha hb => .r1 m ha hb\n  | .no h1 =>\n      match detect2 a b with\n      | .yes m ha hb => .r2 m ha hb\n      | .no h2 => .raw h1 h2\n\ndef op (a b : CM) : CM :=\n  match view a b with\n  | .r1 m _ _ => m.x\n  | .r2 m _ _ => m.c\n  | .raw _ _ => CM.p a b\n\ninstance instMagma : Magma CM where\n  op := op\n\nlemma pat_disjoint (m : Pat1) (n : Pat2)\n    (hl : left1 m = left2 n) (hr : right1 m = right2 n) : False := by\n  have hy : m.y = CM.p n.a (CM.p n.b n.b) := (CM.p.inj hl).1\n  have hb : CM.p m.y m.z = n.b := (CM.p.inj hr).1\n  have hby : sz n.b < sz m.y := by\n    have h1 : sz n.b < sz (CM.p n.b n.b) := sz_lt_p_left n.b n.b\n    have h2 : sz (CM.p n.b n.b) < sz (CM.p n.a (CM.p n.b n.b)) :=\n      sz_lt_p_right n.a (CM.p n.b n.b)\n    exact Nat.lt_of_lt_of_eq (Nat.lt_trans h1 h2) (congrArg sz hy).symm\n  have hyb : sz m.y < sz n.b :=\n    Nat.lt_of_lt_of_eq (sz_lt_p_left m.y m.z) (congrArg sz hb)\n  exact (Nat.lt_irrefl (sz n.b)) (Nat.lt_trans hby hyb)\n\nlemma op_rule1 (m : Pat1) : op (left1 m) (right1 m) = m.x := by\n  unfold op view\n  cases hd : detect1 (left1 m) (right1 m) with\n  | yes q hq _ =>\n      change q.x = m.x\n      have hp : CM.p m.x m.x = CM.p q.x q.x := (CM.p.inj hq).2\n      exact (CM.p.inj hp).1.symm\n  | no hn => exact (hn m rfl rfl).elim\n\nlemma op_rule2 (m : Pat2) : op (left2 m) (right2 m) = m.c := by\n  unfold op view\n  cases hd1 : detect1 (left2 m) (right2 m) with\n  | yes q hq1 hq2 => exact (pat_disjoint q m hq1.symm hq2.symm).elim\n  | no _ =>\n      cases hd2 : detect2 (left2 m) (right2 m) with\n      | yes q hq _ =>\n          change q.c = m.c\n          have hp : CM.p m.c m.c = CM.p q.c q.c := (CM.p.inj hq).2\n          exact (CM.p.inj hp).1.symm\n      | no hn => exact (hn m rfl rfl).elim\n\nlemma op_raw {a b : CM} (h1 : No1 a b) (h2 : No2 a b) : op a b = CM.p a b := by\n  unfold op view\n  cases hd1 : detect1 a b with\n  | yes m ha hb => exact (h1 m ha hb).elim\n  | no _ =>\n      cases hd2 : detect2 a b with\n      | yes m ha hb => exact (h2 m ha hb).elim\n      | no _ => rfl\n\nlemma no1_same (t : CM) : No1 t t := by\n  intro m hl hr\n  have h : left1 m = right1 m := hl.symm.trans hr\n  have hy : m.y = CM.p m.y m.z := (CM.p.inj h).1\n  exact (Nat.ne_of_lt (sz_lt_p_left m.y m.z)) (congrArg sz hy)\n\nlemma no2_same (t : CM) : No2 t t := by\n  intro m hl hr\n  have h : left2 m = right2 m := hl.symm.trans hr\n  have hb : CM.p m.a (CM.p m.b m.b) = m.b := (CM.p.inj h).1\n  have hlt : sz m.b < sz (CM.p m.a (CM.p m.b m.b)) :=\n    Nat.lt_trans (sz_lt_p_left m.b m.b)\n      (sz_lt_p_right m.a (CM.p m.b m.b))\n  exact (Nat.ne_of_lt hlt) (congrArg sz hb).symm\n\nlemma no1_encode (y x : CM) : No1 y (CM.p x x) := by\n  intro m _ hr\n  have hx1 : x = CM.p m.y m.z := (CM.p.inj hr).1\n  have hx2 : x = m.y := (CM.p.inj hr).2\n  have hy : m.y = CM.p m.y m.z := hx2.symm.trans hx1\n  exact (Nat.ne_of_lt (sz_lt_p_left m.y m.z)) (congrArg sz hy)\n\nlemma no2_encode (y x : CM) : No2 y (CM.p x x) := by\n  intro m _ hr\n  have hx1 : x = m.b := (CM.p.inj hr).1\n  have hx2 : x = CM.p m.a (CM.p m.b m.b) := (CM.p.inj hr).2\n  have hb : m.b = CM.p m.a (CM.p m.b m.b) := hx1.symm.trans hx2\n  have hlt : sz m.b < sz (CM.p m.a (CM.p m.b m.b)) :=\n    Nat.lt_trans (sz_lt_p_left m.b m.b)\n      (sz_lt_p_right m.a (CM.p m.b m.b))\n  exact (Nat.ne_of_lt hlt) (congrArg sz hb)\n\nlemma no1_after1 (m : Pat1) : No1 m.x (left1 m) := by\n  intro q hl hr\n  have hright : CM.p m.x m.x = q.y := (CM.p.inj hr).2\n  have hqx : sz q.y < sz m.x :=\n    Nat.lt_of_lt_of_eq (sz_lt_p_left q.y (CM.p q.x q.x)) (congrArg sz hl).symm\n  have hxq : sz m.x < sz q.y :=\n    Nat.lt_of_lt_of_eq (sz_lt_p_left m.x m.x) (congrArg sz hright)\n  exact (Nat.lt_irrefl (sz q.y)) (Nat.lt_trans hqx hxq)\n\nlemma no2_after1 (m : Pat1) : No2 m.x (left1 m) := by\n  intro q hl hr\n  have hxq : m.x = q.a := (CM.p.inj (CM.p.inj hr).2).1\n  have hqa : sz q.a < sz m.x :=\n    Nat.lt_of_lt_of_eq\n      (Nat.lt_trans (sz_lt_p_left q.a (CM.p q.b q.b))\n        (sz_lt_p_left (CM.p q.a (CM.p q.b q.b)) (CM.p q.c q.c)))\n      (congrArg sz hl).symm\n  exact (Nat.ne_of_lt hqa) (congrArg sz hxq).symm\n\nlemma no1_after2 (m : Pat2) : No1 m.c (left2 m) := by\n  intro q hl hr\n  have hcy : CM.p m.c m.c = q.y := (CM.p.inj hr).2\n  have hyc : sz q.y < sz m.c :=\n    Nat.lt_of_lt_of_eq (sz_lt_p_left q.y (CM.p q.x q.x)) (congrArg sz hl).symm\n  have hcy' : sz m.c < sz q.y :=\n    Nat.lt_of_lt_of_eq (sz_lt_p_left m.c m.c) (congrArg sz hcy)\n  exact (Nat.lt_irrefl (sz q.y)) (Nat.lt_trans hyc hcy')\n\nlemma no2_after2 (m : Pat2) : No2 m.c (left2 m) := by\n  intro q hl hr\n  have hcq : m.c = q.a := (CM.p.inj (CM.p.inj hr).2).1\n  have hqa : sz q.a < sz m.c :=\n    Nat.lt_of_lt_of_eq\n      (Nat.lt_trans (sz_lt_p_left q.a (CM.p q.b q.b))\n        (sz_lt_p_left (CM.p q.a (CM.p q.b q.b)) (CM.p q.c q.c)))\n      (congrArg sz hl).symm\n  exact (Nat.ne_of_lt hqa) (congrArg sz hcq).symm\n\nlemma no1_after_raw (y z : CM) : No1 (CM.p y z) y := by\n  intro m hl hr\n  have hy : y = m.y := (CM.p.inj hl).1\n  have hself : m.y = right1 m := hy.symm.trans hr\n  have hlt : sz m.y < sz (right1 m) := by\n    unfold right1\n    exact sz_lt_p_right (CM.p m.y m.z) m.y\n  exact (Nat.ne_of_lt hlt) (congrArg sz hself)\n\nlemma no2_after_raw (y z : CM) : No2 (CM.p y z) y := by\n  intro m hl hr\n  have hy : y = CM.p m.a (CM.p m.b m.b) := (CM.p.inj hl).1\n  have hself : CM.p m.a (CM.p m.b m.b) =\n      CM.p m.b (CM.p m.a (CM.p m.b m.b)) := hy.symm.trans hr\n  have hlt : sz (CM.p m.a (CM.p m.b m.b)) <\n      sz (CM.p m.b (CM.p m.a (CM.p m.b m.b))) :=\n    sz_lt_p_right m.b (CM.p m.a (CM.p m.b m.b))\n  exact (Nat.ne_of_lt hlt) (congrArg sz hself)\n\nlemma square (x : CM) : op x x = CM.p x x := op_raw (no1_same x) (no2_same x)\n\nlemma encode (y x : CM) : op y (CM.p x x) = CM.p y (CM.p x x) :=\n  op_raw (no1_encode y x) (no2_encode y x)\n\nlemma return_right (y z : CM) : op (op y z) y = CM.p (op y z) y := by\n  cases hv : view y z with\n  | r1 m ha hb =>\n      have hop : op y z = m.x := by unfold op; rw [hv]\n      rw [hop, ha]\n      exact op_raw (no1_after1 m) (no2_after1 m)\n  | r2 m ha hb =>\n      have hop : op y z = m.c := by unfold op; rw [hv]\n      rw [hop, ha]\n      exact op_raw (no1_after2 m) (no2_after2 m)\n  | raw h1 h2 =>\n      have hop : op y z = CM.p y z := by unfold op; rw [hv]\n      rw [hop]\n      exact op_raw (no1_after_raw y z) (no2_after_raw y z)\n\n"
_D15_PATTERN_CM_SOURCE_ROUTES = {'[0,["op",["op",1,["op",2,1]],["op",["op",0,0],1]]]': ('lemma source_holds (x y z : CM) :\n    x = op (op y (op x x)) (op (op y z) y) := by\n  rw [square x, encode y x, return_right y z]\n  cases hv : view y z with\n  | r1 m ha hb =>\n      have hop : op y z = m.x := by unfold op; rw [hv]\n      rw [hop, ha]\n      exact (op_rule2 ⟨m.y, m.x, x⟩).symm\n  | r2 m ha hb =>\n      have hop : op y z = m.c := by unfold op; rw [hv]\n      rw [hop, ha]\n      exact (op_rule2 ⟨CM.p m.a (CM.p m.b m.b), m.c, x⟩).symm\n  | raw h1 h2 =>\n      have hop : op y z = CM.p y z := by unfold op; rw [hv]\n      rw [hop]\n      exact (op_rule1 ⟨y, x, z⟩).symm\n\n', '  · intro x y z\n    change x = CM.op (CM.op y (CM.op x x)) (CM.op (CM.op y z) y)\n    exact CM.source_holds x y z\n')}
_D15_PATTERN_CM_WITNESS_POOL = (("e",),)


def _d15_pattern_cm_p(left, right):
    return ("p", left, right)


def _d15_pattern_cm_left1(match):
    y, x, _z = match
    return _d15_pattern_cm_p(y, _d15_pattern_cm_p(x, x))


def _d15_pattern_cm_right1(match):
    y, _x, z = match
    return _d15_pattern_cm_p(_d15_pattern_cm_p(y, z), y)


def _d15_pattern_cm_left2(match):
    a, b, c = match
    return _d15_pattern_cm_p(
        _d15_pattern_cm_p(a, _d15_pattern_cm_p(b, b)),
        _d15_pattern_cm_p(c, c),
    )


def _d15_pattern_cm_right2(match):
    a, b, _c = match
    return _d15_pattern_cm_p(b, _d15_pattern_cm_p(a, _d15_pattern_cm_p(b, b)))


def _d15_pattern_cm_match1(left, right):
    y = left[1] if left[0] == "p" else ("e",)
    x = (
        left[2][1]
        if left[0] == "p" and left[2][0] == "p"
        else ("e",)
    )
    z = (
        right[1][2]
        if right[0] == "p" and right[1][0] == "p"
        else ("e",)
    )
    match = (y, x, z)
    return match if left == _d15_pattern_cm_left1(match) and right == _d15_pattern_cm_right1(match) else None


def _d15_pattern_cm_match2(left, right):
    a = (
        left[1][1]
        if left[0] == "p" and left[1][0] == "p"
        else ("e",)
    )
    b = (
        left[1][2][1]
        if (
            left[0] == "p"
            and left[1][0] == "p"
            and left[1][2][0] == "p"
        )
        else ("e",)
    )
    c = (
        left[2][1]
        if left[0] == "p" and left[2][0] == "p"
        else ("e",)
    )
    match = (a, b, c)
    return match if left == _d15_pattern_cm_left2(match) and right == _d15_pattern_cm_right2(match) else None


def _d15_pattern_cm_core_op(left, right):
    match1 = _d15_pattern_cm_match1(left, right)
    if match1 is not None:
        return match1[1]
    match2 = _d15_pattern_cm_match2(left, right)
    if match2 is not None:
        return match2[2]
    return _d15_pattern_cm_p(left, right)


def _d15_pattern_cm_opposite(left, right):
    return _d15_pattern_cm_core_op(right, left)


def _d15_pattern_cm_eval(term, values):
    if type(term) is int:
        return values[term]
    return _d15_pattern_cm_opposite(
        _d15_pattern_cm_eval(term[0], values),
        _d15_pattern_cm_eval(term[1], values),
    )


def _d15_pattern_cm_literal(value):
    tag = value[0]
    if tag == "e":
        return "CM.e"
    if tag == "k":
        return f"(CM.k {_d15_pattern_cm_literal(value[1])})"
    return (
        f"(CM.p {_d15_pattern_cm_literal(value[1])} "
        f"{_d15_pattern_cm_literal(value[2])})"
    )


def _d15_pattern_cm_lean_term(term, values):
    if type(term) is int:
        return _d15_pattern_cm_literal(values[term])
    left = _d15_pattern_cm_lean_term(term[0], values)
    right = _d15_pattern_cm_lean_term(term[1], values)
    return f"(CM.op {right} {left})"


def _d15_pattern_cm_candidate(parsed_source, parsed_target):
    source_pattern = _source_pattern(parsed_source)
    source_route = _D15_PATTERN_CM_SOURCE_ROUTES.get(source_pattern)
    if source_route is None:
        return None
    source_proof, source_branch = source_route
    variables, left, right = parsed_target
    if not 1 <= len(variables) <= 6:
        return None
    for values in product(_D15_PATTERN_CM_WITNESS_POOL, repeat=len(variables)):
        if _d15_pattern_cm_eval(left, values) == _d15_pattern_cm_eval(right, values):
            continue
        applications = " ".join(_d15_pattern_cm_literal(value) for value in values)
        closed_left = _d15_pattern_cm_lean_term(left, values)
        closed_right = _d15_pattern_cm_lean_term(right, values)
        target_branch = (
            "  · intro target\n"
            f"    have bad := target {applications}\n"
            f"    change {closed_left} = {closed_right} at bad\n"
            f"    exact (show Not ({closed_left} = {closed_right}) "
            "from by decide) bad\n"
        )
        submission = (
            "end CM\n\n"
            "end submission\n\n"
            "open submission\n\n"
            "def submission.d15OppositeMagmaPatternCM : Magma CM where\n"
            "  op a b := CM.op b a\n\n"
            "def submission : Goal := by\n"
            "  refine ⟨CM, d15OppositeMagmaPatternCM, ?_, ?_⟩\n"
        )
        return (
            _D15_PATTERN_CM_FAMILY,
            _D15_PATTERN_CM_MODEL_CORE
            + source_proof
            + submission
            + source_branch
            + target_branch,
            "alpha_exact_source_law_and_singleton_target_ast_witness",
        )
    return None



_D15_KBO_FAMILY = "d15_kbo_completion_transfer"
_D15_KBO_MODEL_CORE = 'import JudgeProblem\nimport Mathlib\n\nset_option maxRecDepth 10000\n\nnamespace submission\n\ninductive CM where\n  | e : CM\n  | p : CM → CM → CM\nderiving DecidableEq\n\nnamespace CM\n\ndef sz : CM → Nat\n  | e => 0\n  | p a b => sz a + sz b + 1\n\ndef sq (a : CM) : CM := p a a\n\ndef d (a b : CM) : CM :=\n  p (p (sq b) (sq a)) (sq b)\n\ndef lhs0 (a x : CM) : CM :=\n  p (p (p a (sq x)) a) a\n\ndef lhs1 (a b : CM) : CM :=\n  p (p a (d a b)) (d a b)\n\ndef get0a : CM → CM\n  | p _ a => a\n  | _ => e\n\ndef get0x : CM → CM\n  | p (p (p _ (p x _)) _) _ => x\n  | _ => e\n\ndef get1a : CM → CM\n  | p (p a _) _ => a\n  | _ => e\n\ndef get1b : CM → CM\n  | p _ (p (p (p b _) _) _) => b\n  | _ => e\n\ndef root (t : CM) : CM :=\n  let a0 := get0a t\n  let x0 := get0x t\n  if t = lhs0 a0 x0 then\n    x0\n  else\n    let a1 := get1a t\n    let b1 := get1b t\n    if t = lhs1 a1 b1 then b1 else t\n\ndef op (a b : CM) : CM := root (p a b)\n\ninstance instMagma : Magma CM where\n  op := op\n\ntheorem lhs1_not_lhs0 (a b c x : CM) :\n    lhs1 a b = lhs0 c x → False := by\n  intro h\n  have hr : d a b = c := (CM.p.inj h).2\n  have hl : a = p c (sq x) := (CM.p.inj (CM.p.inj h).1).1\n  have hself : a = p (d a b) (sq x) := by\n    exact hl.trans (congrArg (fun q => p q (sq x)) hr.symm)\n  have hs := congrArg sz hself\n  simp [d, sq, sz] at hs\n  omega\n\ntheorem root_lhs0 (a x : CM) : root (lhs0 a x) = x := by\n  change\n    (if lhs0 a x = lhs0 a x then x\n      else\n        if lhs0 a x =\n            lhs1 (get1a (lhs0 a x)) (get1b (lhs0 a x))\n          then get1b (lhs0 a x) else lhs0 a x) = x\n  rw [if_pos rfl]\n\ntheorem root_lhs1 (a b : CM) : root (lhs1 a b) = b := by\n  change\n    (if lhs1 a b = lhs0 (d a b) (get0x (lhs1 a b))\n      then get0x (lhs1 a b)\n      else if lhs1 a b = lhs1 a b then b else lhs1 a b) = b\n  rw [if_neg (lhs1_not_lhs0 a b _ _), if_pos rfl]\n\ntheorem root_eq_self {t : CM}\n    (h0 : t = lhs0 (get0a t) (get0x t) → False)\n    (h1 : t = lhs1 (get1a t) (get1b t) → False) :\n    root t = t := by\n  unfold root\n  rw [if_neg h0, if_neg h1]\n\ntheorem op_rule0 (a x : CM) :\n    op (p (p a (sq x)) a) a = x := by\n  exact root_lhs0 a x\n\ntheorem op_rule1 (a b : CM) :\n    op (p a (d a b)) (d a b) = b := by\n  exact root_lhs1 a b\n\ntheorem no_xx_lhs0 (q a x : CM) :\n    p q q = lhs0 a x → False := by\n  intro h\n  have hl : q = p (p a (sq x)) a := (CM.p.inj h).1\n  have hr : q = a := (CM.p.inj h).2\n  have hself : a = p (p a (sq x)) a := hr.symm.trans hl\n  have hs := congrArg sz hself\n  simp [sq, sz] at hs\n  omega\n\ntheorem no_xx_lhs1 (q a b : CM) :\n    p q q = lhs1 a b → False := by\n  intro h\n  have hl : q = p a (d a b) := (CM.p.inj h).1\n  have hr : q = d a b := (CM.p.inj h).2\n  have hself : d a b = p a (d a b) := hr.symm.trans hl\n  have hs := congrArg sz hself\n  simp [d, sq, sz] at hs\n  omega\n\ntheorem op_xx_raw (q : CM) : op q q = p q q := by\n  unfold op\n  apply root_eq_self\n  · exact no_xx_lhs0 q _ _\n  · exact no_xx_lhs1 q _ _\n\ntheorem mid_not_lhs1 (x y a b : CM) :\n    p y (sq x) = lhs1 a b → False := by\n  intro h\n  have hr : sq x = d a b := (CM.p.inj h).2\n  have hleft : x = p (sq b) (sq a) := (CM.p.inj hr).1\n  have hright : x = sq b := (CM.p.inj hr).2\n  have hself : sq b = p (sq b) (sq a) :=\n    hright.symm.trans hleft\n  have hs := congrArg sz hself\n  simp [sq, sz] at hs\n  omega\n\ntheorem prefix0_not_lhs0 (x y a b : CM) :\n    p (p y (sq x)) y = lhs0 a b → False := by\n  intro h\n  have hr : y = a := (CM.p.inj h).2\n  have hl : y = p a (sq b) := (CM.p.inj (CM.p.inj h).1).1\n  have hself : a = p a (sq b) := hr.symm.trans hl\n  have hs := congrArg sz hself\n  simp [sq, sz] at hs\n  omega\n\ntheorem prefix0_not_lhs1 (x y a b : CM) :\n    p (p y (sq x)) y = lhs1 a b → False := by\n  intro h\n  have hr : y = d a b := (CM.p.inj h).2\n  have hl : y = a := (CM.p.inj (CM.p.inj h).1).1\n  have hself : a = d a b := hl.symm.trans hr\n  have hs := congrArg sz hself\n  simp [d, sq, sz] at hs\n  omega\n\ntheorem op_prefix0_raw (x y : CM) :\n    op (p y (sq x)) y = p (p y (sq x)) y := by\n  unfold op\n  apply root_eq_self\n  · exact prefix0_not_lhs0 x y _ _\n  · exact prefix0_not_lhs1 x y _ _\n\ntheorem prefix1_not_lhs0 (a b c x : CM) :\n    p a (d a b) = lhs0 c x → False := by\n  intro h\n  have hr : d a b = c := (CM.p.inj h).2\n  have hl : a = p (p c (sq x)) c := (CM.p.inj h).1\n  have hself : a = p (p (d a b) (sq x)) (d a b) := by\n    exact hl.trans\n      (congrArg (fun q => p (p q (sq x)) q) hr.symm)\n  have hs := congrArg sz hself\n  simp [d, sq, sz] at hs\n  omega\n\ntheorem prefix1_not_lhs1 (a b c x : CM) :\n    p a (d a b) = lhs1 c x → False := by\n  intro h\n  have hr : d a b = d c x := (CM.p.inj h).2\n  have hl : a = p c (d c x) := (CM.p.inj h).1\n  have hs1 := congrArg sz hr\n  have hs2 := congrArg sz hl\n  simp [d, sq, sz] at hs1 hs2\n  omega\n\ntheorem op_prefix1_raw (a b : CM) :\n    op a (d a b) = p a (d a b) := by\n  unfold op\n  apply root_eq_self\n  · exact prefix1_not_lhs0 a b _ _\n  · exact prefix1_not_lhs1 a b _ _\n\n'
_D15_KBO_SOURCE_ROUTES = {'[0,["op",1,["op",1,["op",["op",0,0],1]]]]': ('theorem source_holds (x y : CM) :\n    x = op (op (op y (op x x)) y) y := by\n  rw [op_xx_raw]\n  change x = op (op (op y (sq x)) y) y\n  let b := get0x (p y (sq x))\n  by_cases h : p y (sq x) = lhs0 (sq x) b\n  · have hy : y = d b x := by\n      simpa [lhs0, d] using (CM.p.inj h).1\n    have hmid : op y (sq x) = b := by\n      unfold op\n      rw [h]\n      exact root_lhs0 (sq x) b\n    rw [hmid, hy, op_prefix1_raw]\n    exact (op_rule1 b x).symm\n  · have hmid : op y (sq x) = p y (sq x) := by\n      unfold op\n      apply root_eq_self\n      · exact h\n      · exact mid_not_lhs1 x y _ _\n    rw [hmid, op_prefix0_raw]\n    exact (op_rule0 y x).symm\n', '  · intro x y\n    change x = CM.op (CM.op (CM.op y (CM.op x x)) y) y\n    exact CM.source_holds x y\n')}
_D15_KBO_WITNESS_POOL = (("e",),)


def _d15_kbo_p(left, right):
    return ("p", left, right)


def _d15_kbo_sq(value):
    return _d15_kbo_p(value, value)


def _d15_kbo_d(left, right):
    return _d15_kbo_p(
        _d15_kbo_p(_d15_kbo_sq(right), _d15_kbo_sq(left)),
        _d15_kbo_sq(right),
    )


def _d15_kbo_lhs0(left, value):
    return _d15_kbo_p(
        _d15_kbo_p(_d15_kbo_p(left, _d15_kbo_sq(value)), left),
        left,
    )


def _d15_kbo_lhs1(left, right):
    delta = _d15_kbo_d(left, right)
    return _d15_kbo_p(_d15_kbo_p(left, delta), delta)


def _d15_kbo_get0a(term):
    return term[2] if term[0] == "p" else ("e",)


def _d15_kbo_get0x(term):
    if (
        term[0] == "p"
        and term[1][0] == "p"
        and term[1][1][0] == "p"
        and term[1][1][2][0] == "p"
    ):
        return term[1][1][2][1]
    return ("e",)


def _d15_kbo_get1a(term):
    if term[0] == "p" and term[1][0] == "p":
        return term[1][1]
    return ("e",)


def _d15_kbo_get1b(term):
    if (
        term[0] == "p"
        and term[2][0] == "p"
        and term[2][1][0] == "p"
        and term[2][1][1][0] == "p"
    ):
        return term[2][1][1][1]
    return ("e",)


def _d15_kbo_root(term):
    left0 = _d15_kbo_get0a(term)
    value0 = _d15_kbo_get0x(term)
    if term == _d15_kbo_lhs0(left0, value0):
        return value0
    left1 = _d15_kbo_get1a(term)
    right1 = _d15_kbo_get1b(term)
    if term == _d15_kbo_lhs1(left1, right1):
        return right1
    return term


def _d15_kbo_core_op(left, right):
    return _d15_kbo_root(_d15_kbo_p(left, right))


def _d15_kbo_opposite(left, right):
    return _d15_kbo_core_op(right, left)


def _d15_kbo_eval(term, values):
    if type(term) is int:
        return values[term]
    return _d15_kbo_opposite(
        _d15_kbo_eval(term[0], values),
        _d15_kbo_eval(term[1], values),
    )


def _d15_kbo_literal(value):
    if value[0] == "e":
        return "CM.e"
    return (
        f"(CM.p {_d15_kbo_literal(value[1])} "
        f"{_d15_kbo_literal(value[2])})"
    )


def _d15_kbo_lean_term(term, values):
    if type(term) is int:
        return _d15_kbo_literal(values[term])
    left = _d15_kbo_lean_term(term[0], values)
    right = _d15_kbo_lean_term(term[1], values)
    return f"(CM.op {right} {left})"


def _d15_kbo_candidate(parsed_source, parsed_target):
    source_pattern = _source_pattern(parsed_source)
    source_route = _D15_KBO_SOURCE_ROUTES.get(source_pattern)
    if source_route is None:
        return None
    source_proof, source_branch = source_route
    variables, left, right = parsed_target
    if not 1 <= len(variables) <= 6:
        return None
    for values in product(_D15_KBO_WITNESS_POOL, repeat=len(variables)):
        if _d15_kbo_eval(left, values) == _d15_kbo_eval(right, values):
            continue
        applications = " ".join(_d15_kbo_literal(value) for value in values)
        closed_left = _d15_kbo_lean_term(left, values)
        closed_right = _d15_kbo_lean_term(right, values)
        target_branch = (
            "  · intro target\n"
            f"    have bad := target {applications}\n"
            f"    change {closed_left} = {closed_right} at bad\n"
            f"    exact (show Not ({closed_left} = {closed_right}) "
            "from by decide) bad\n"
        )
        submission = (
            "end CM\n\n"
            "end submission\n\n"
            "open submission\n\n"
            "def submission.d15OppositeMagmaKBO : Magma CM where\n"
            "  op a b := CM.op b a\n\n"
            "def submission : Goal := by\n"
            "  refine ⟨CM, d15OppositeMagmaKBO, ?_, ?_⟩\n"
        )
        return (
            _D15_KBO_FAMILY,
            _D15_KBO_MODEL_CORE
            + source_proof
            + submission
            + source_branch
            + target_branch,
            "alpha_exact_source_law_and_singleton_target_ast_witness",
        )
    return None



_D15_NF_FAMILY = "d15_normal_form_normalization_transfer"
_D15_NF_MODEL_CORE = 'import JudgeProblem\n\nset_option maxRecDepth 100000\n\nnamespace submission\n\ninductive Raw where\n  | e : Raw\n  | p : Raw → Raw → Raw\nderiving DecidableEq\n\nnamespace Raw\n\ndef sq (a : Raw) : Raw := p a a\ndef q (a b : Raw) : Raw := p (sq a) b\n\ndef nodes : Raw → Nat\n  | e => 0\n  | p a b => nodes a + nodes b + 1\n\ntheorem nodes_lt_p_left (a b : Raw) : nodes a < nodes (p a b) := by\n  simp [nodes] <;> omega\n\ntheorem nodes_lt_p_right (a b : Raw) : nodes b < nodes (p a b) := by\n  simp [nodes] <;> omega\n\ndef try0 : Raw → Option Raw\n  | p (p (p y₁ y₂) x₁) (p x₂ _) =>\n      if y₁ = y₂ ∧ x₁ = x₂ then some x₁ else none\n  | _ => none\n\ndef try1 : Raw → Option Raw\n  | p (p (p y₁ y₂) (p (p a₁ a₂) x₁)) x₂ =>\n      if y₁ = y₂ ∧ a₁ = a₂ ∧ x₁ = x₂\n      then some (q a₁ x₁) else none\n  | _ => none\n\ndef try2 : Raw → Option Raw\n  | p (p y₁ y₂) (p (p (p v₁ v₂) x) _) =>\n      if y₁ = y₂ ∧ v₁ = v₂ ∧ y₁ = v₁\n      then some (q y₁ x) else none\n  | _ => none\n\ndef try3 : Raw → Option Raw\n  | p (p (p y₁ y₂) x₁)\n      (p (p (p (p v₁ v₂) x₂) a) _) =>\n      if y₁ = y₂ ∧ v₁ = v₂ ∧ y₁ = v₁ ∧ x₁ = x₂\n      then some (p (q y₁ x₁) a) else none\n  | _ => none\n\ndef lhs0 (y x a : Raw) : Raw := p (q y x) (p x a)\ndef lhs1 (y a x : Raw) : Raw := p (q y (q a x)) x\ndef lhs2 (y x b : Raw) : Raw := p (sq y) (p (q y x) b)\ndef lhs3 (y x a b : Raw) : Raw :=\n  p (q y x) (p (p (q y x) a) b)\n\ntheorem try0_sound {t u : Raw} (h : try0 t = some u) :\n    ∃ y x a, t = lhs0 y x a ∧ u = x := by\n  cases t with\n  | e => simp [try0] at h\n  | p l r =>\n    cases l with\n    | e => simp [try0] at h\n    | p ll x =>\n      cases ll with\n      | e => simp [try0] at h\n      | p y₁ y₂ =>\n        cases r with\n        | e => simp [try0] at h\n        | p x₂ a =>\n          by_cases hc : y₁ = y₂ ∧ x = x₂\n          · rw [try0, if_pos hc] at h\n            have hu : x = u := Option.some.inj h\n            exact ⟨y₁, x, a, by simp [lhs0, q, sq, hc], hu.symm⟩\n          · simp [try0, hc] at h\n\ntheorem try1_sound {t u : Raw} (h : try1 t = some u) :\n    ∃ y a x, t = lhs1 y a x ∧ u = q a x := by\n  cases t with\n  | e => simp [try1] at h\n  | p l x₂ =>\n    cases l with\n    | e => simp [try1] at h\n    | p ll ar =>\n      cases ll with\n      | e => simp [try1] at h\n      | p y₁ y₂ =>\n        cases ar with\n        | e => simp [try1] at h\n        | p aar x₁ =>\n          cases aar with\n          | e => simp [try1] at h\n          | p a₁ a₂ =>\n            by_cases hc : y₁ = y₂ ∧ a₁ = a₂ ∧ x₁ = x₂\n            · rw [try1, if_pos hc] at h\n              have hu : q a₁ x₁ = u := Option.some.inj h\n              exact ⟨y₁, a₁, x₁,\n                by simp [lhs1, q, sq, hc], hu.symm⟩\n            · simp [try1, hc] at h\n\ntheorem try2_sound {t u : Raw} (h : try2 t = some u) :\n    ∃ y x b, t = lhs2 y x b ∧ u = q y x := by\n  cases t with\n  | e => simp [try2] at h\n  | p l r =>\n    cases l with\n    | e => simp [try2] at h\n    | p y₁ y₂ =>\n      cases r with\n      | e => simp [try2] at h\n      | p rl b =>\n        cases rl with\n        | e => simp [try2] at h\n        | p rll x =>\n          cases rll with\n          | e => simp [try2] at h\n          | p v₁ v₂ =>\n            by_cases hc : y₁ = y₂ ∧ v₁ = v₂ ∧ y₁ = v₁\n            · rw [try2, if_pos hc] at h\n              have hu : q y₁ x = u := Option.some.inj h\n              have hv₂y₂ : v₂ = y₂ :=\n                hc.2.1.symm.trans (hc.2.2.symm.trans hc.1)\n              exact ⟨y₁, x, b,\n                by simp [lhs2, q, sq, hc, hv₂y₂], hu.symm⟩\n            · simp [try2, hc] at h\n\ntheorem try3_sound {t u : Raw} (h : try3 t = some u) :\n    ∃ y x a b, t = lhs3 y x a b ∧ u = p (q y x) a := by\n  cases t with\n  | e => simp [try3] at h\n  | p l r =>\n    cases l with\n    | e => simp [try3] at h\n    | p ll x₁ =>\n      cases ll with\n      | e => simp [try3] at h\n      | p y₁ y₂ =>\n        cases r with\n        | e => simp [try3] at h\n        | p rl b =>\n          cases rl with\n          | e => simp [try3] at h\n          | p rll a =>\n            cases rll with\n            | e => simp [try3] at h\n            | p rlll x₂ =>\n              cases rlll with\n              | e => simp [try3] at h\n              | p v₁ v₂ =>\n                by_cases hc :\n                    y₁ = y₂ ∧ v₁ = v₂ ∧ y₁ = v₁ ∧ x₁ = x₂\n                · rw [try3, if_pos hc] at h\n                  have hu : p (q y₁ x₁) a = u :=\n                    Option.some.inj h\n                  have hv₂y₂ : v₂ = y₂ :=\n                    hc.2.1.symm.trans (hc.2.2.1.symm.trans hc.1)\n                  exact ⟨y₁, x₁, a, b,\n                    by simp [lhs3, q, sq, hc, hv₂y₂], hu.symm⟩\n                · simp [try3, hc] at h\n\ndef root (t : Raw) : Option Raw :=\n  match try0 t with\n  | some u => some u\n  | none =>\n    match try1 t with\n    | some u => some u\n    | none =>\n      match try2 t with\n      | some u => some u\n      | none => try3 t\n\ndef rawOp (a b : Raw) : Raw :=\n  (root (p a b)).getD (p a b)\n\ninductive Step : Raw → Raw → Prop where\n  | rule0 (y x a) : Step (lhs0 y x a) x\n  | rule1 (y a x) (miss0 : try0 (lhs1 y a x) = none) :\n      Step (lhs1 y a x) (q a x)\n  | rule2 (y x b) (miss0 : try0 (lhs2 y x b) = none)\n      (miss1 : try1 (lhs2 y x b) = none) :\n      Step (lhs2 y x b) (q y x)\n  | rule3 (y x a b) (miss0 : try0 (lhs3 y x a b) = none)\n      (miss1 : try1 (lhs3 y x a b) = none)\n      (miss2 : try2 (lhs3 y x a b) = none) :\n      Step (lhs3 y x a b) (p (q y x) a)\n  | raw (t) (miss0 : try0 t = none) (miss1 : try1 t = none)\n      (miss2 : try2 t = none) (miss3 : try3 t = none) : Step t t\n\ndef StepCases (t u : Raw) : Prop :=\n  (∃ y x a, t = lhs0 y x a ∧ u = x) ∨\n  (∃ y a x, t = lhs1 y a x ∧ u = q a x ∧\n    try0 t = none) ∨\n  (∃ y x b, t = lhs2 y x b ∧ u = q y x ∧\n    try0 t = none ∧ try1 t = none) ∨\n  (∃ y x a b, t = lhs3 y x a b ∧ u = p (q y x) a ∧\n    try0 t = none ∧ try1 t = none ∧ try2 t = none) ∨\n  (t = u ∧ try0 t = none ∧ try1 t = none ∧\n    try2 t = none ∧ try3 t = none)\n\ntheorem step_cases {t u : Raw} (h : Step t u) : StepCases t u := by\n  cases h with\n  | rule0 y x a =>\n    exact Or.inl ⟨y, _, a, rfl, rfl⟩\n  | rule1 y a x m0 =>\n    exact Or.inr (Or.inl ⟨y, a, x, rfl, rfl, m0⟩)\n  | rule2 y x b m0 m1 =>\n    exact Or.inr (Or.inr (Or.inl\n      ⟨y, x, b, rfl, rfl, m0, m1⟩))\n  | rule3 y x a b m0 m1 m2 =>\n    exact Or.inr (Or.inr (Or.inr (Or.inl\n      ⟨y, x, a, b, rfl, rfl, m0, m1, m2⟩)))\n  | raw t m0 m1 m2 m3 =>\n    exact Or.inr (Or.inr (Or.inr (Or.inr\n      ⟨rfl, m0, m1, m2, m3⟩)))\n\ntheorem rawOp_step (a b : Raw) : Step (p a b) (rawOp a b) := by\n  unfold rawOp root\n  cases h0 : try0 (p a b) with\n  | some u =>\n    obtain ⟨y, x, c, ht, hu⟩ := try0_sound h0\n    have hs : Step (p a b) u := by\n      rw [ht, hu]\n      exact Step.rule0 y x c\n    simpa [h0] using hs\n  | none =>\n    cases h1 : try1 (p a b) with\n    | some u =>\n      obtain ⟨y, c, x, ht, hu⟩ := try1_sound h1\n      have m0 : try0 (lhs1 y c x) = none := by\n        rw [← ht]\n        exact h0\n      have hs : Step (p a b) u := by\n        rw [ht, hu]\n        exact Step.rule1 y c x m0\n      simpa [h0, h1] using hs\n    | none =>\n      cases h2 : try2 (p a b) with\n      | some u =>\n        obtain ⟨y, x, c, ht, hu⟩ := try2_sound h2\n        have m0 : try0 (lhs2 y x c) = none := by\n          rw [← ht]\n          exact h0\n        have m1 : try1 (lhs2 y x c) = none := by\n          rw [← ht]\n          exact h1\n        have hs : Step (p a b) u := by\n          rw [ht, hu]\n          exact Step.rule2 y x c m0 m1\n        simpa [h0, h1, h2] using hs\n      | none =>\n        cases h3 : try3 (p a b) with\n        | some u =>\n          obtain ⟨y, x, c, d, ht, hu⟩ := try3_sound h3\n          have m0 : try0 (lhs3 y x c d) = none := by\n            rw [← ht]\n            exact h0\n          have m1 : try1 (lhs3 y x c d) = none := by\n            rw [← ht]\n            exact h1\n          have m2 : try2 (lhs3 y x c d) = none := by\n            rw [← ht]\n            exact h2\n          have hs : Step (p a b) u := by\n            rw [ht, hu]\n            exact Step.rule3 y x c d m0 m1 m2\n          simpa [h0, h1, h2, h3] using hs\n        | none =>\n          simpa [h0, h1, h2, h3] using\n            Step.raw (p a b) h0 h1 h2 h3\n\ndef NF : Raw → Prop\n  | e => True\n  | p a b => NF a ∧ NF b ∧ root (p a b) = none\n\ntheorem try0_nf {a b u : Raw} (ha : NF a)\n    (h : try0 (p a b) = some u) : NF u := by\n  cases a with\n  | e => simp [try0] at h\n  | p al ar =>\n    cases al with\n    | e => simp [try0] at h\n    | p y₁ y₂ =>\n      cases b with\n      | e => simp [try0] at h\n      | p x₂ tail =>\n        by_cases hc : y₁ = y₂ ∧ ar = x₂\n        · simp [try0, hc] at h\n          subst u\n          simpa [hc.2] using ha.2.1\n        · simp [try0, hc] at h\n\ntheorem try1_nf {a b u : Raw} (ha : NF a)\n    (h : try1 (p a b) = some u) : NF u := by\n  cases a with\n  | e => simp [try1] at h\n  | p al ar =>\n    cases al with\n    | e => simp [try1] at h\n    | p y₁ y₂ =>\n      cases ar with\n      | e => simp [try1] at h\n      | p aar x₁ =>\n        cases aar with\n        | e => simp [try1] at h\n        | p a₁ a₂ =>\n          by_cases hc : y₁ = y₂ ∧ a₁ = a₂ ∧ x₁ = b\n          · simp [try1, hc] at h\n            subst u\n            rcases hc with ⟨rfl, rfl, rfl⟩\n            simpa [q, sq] using ha.2.1\n          · simp [try1, hc] at h\n\ntheorem try2_nf {a b u : Raw} (hb : NF b)\n    (h : try2 (p a b) = some u) : NF u := by\n  cases a with\n  | e => simp [try2] at h\n  | p y₁ y₂ =>\n    cases b with\n    | e => simp [try2] at h\n    | p bl tail =>\n      cases bl with\n      | e => simp [try2] at h\n      | p bll x =>\n        cases bll with\n        | e => simp [try2] at h\n        | p v₁ v₂ =>\n          by_cases hc : y₁ = y₂ ∧ v₁ = v₂ ∧ y₁ = v₁\n          · simp [try2, hc] at h\n            rcases h with ⟨hyv, rfl⟩\n            rcases hc with ⟨_, hv, _⟩\n            simpa [q, sq, hyv, hv] using hb.1\n          · simp [try2, hc] at h\n\ntheorem try3_nf {a b u : Raw} (hb : NF b)\n    (h : try3 (p a b) = some u) : NF u := by\n  cases a with\n  | e => simp [try3] at h\n  | p al x₁ =>\n    cases al with\n    | e => simp [try3] at h\n    | p y₁ y₂ =>\n      cases b with\n      | e => simp [try3] at h\n      | p bl tail =>\n        cases bl with\n        | e => simp [try3] at h\n        | p bll aa =>\n          cases bll with\n          | e => simp [try3] at h\n          | p blll x₂ =>\n            cases blll with\n            | e => simp [try3] at h\n            | p v₁ v₂ =>\n              by_cases hc :\n                  y₁ = y₂ ∧ v₁ = v₂ ∧ y₁ = v₁ ∧ x₁ = x₂\n              · simp [try3, hc] at h\n                rcases h with ⟨hyv, rfl⟩\n                rcases hc with ⟨_, hv, _, _⟩\n                simpa [q, sq, hyv, hv] using hb.1\n              · simp [try3, hc] at h\n\ntheorem root_nf {a b u : Raw} (ha : NF a) (hb : NF b)\n    (h : root (p a b) = some u) : NF u := by\n  unfold root at h\n  split at h\n  · simp_all only [Option.some.injEq]\n    exact try0_nf ha ‹try0 (p a b) = some u›\n  · split at h\n    · simp_all only [Option.some.injEq]\n      exact try1_nf ha ‹try1 (p a b) = some u›\n    · split at h\n      · simp_all only [Option.some.injEq]\n        exact try2_nf hb ‹try2 (p a b) = some u›\n      · exact try3_nf hb h\n\ntheorem rawOp_nf {a b : Raw} (ha : NF a) (hb : NF b) :\n    NF (rawOp a b) := by\n  unfold rawOp\n  cases h : root (p a b) with\n  | none => simp [NF, ha, hb, h]\n  | some u => simpa [h] using root_nf ha hb h\n\ndef Carrier := {t : Raw // NF t}\n\ndef op (a b : Carrier) : Carrier :=\n  ⟨rawOp a.1 b.1, rawOp_nf a.2 b.2⟩\n\ninstance instMagma : Magma Carrier where\n  op := op\n\ntheorem lhs2_not_nf (y x b : Raw) : ¬ NF (lhs2 y x b) := by\n  intro hnf\n  have hr : root (lhs2 y x b) = none := hnf.2.2\n  unfold root at hr\n  cases h0 : try0 (lhs2 y x b) with\n  | some u => simp [h0] at hr\n  | none =>\n    cases h1 : try1 (lhs2 y x b) with\n    | some u => simp [h0, h1] at hr\n    | none =>\n      have h2 : try2 (lhs2 y x b) = some (q y x) := by\n        simp [try2, lhs2, q, sq]\n      simp [h0, h1, h2] at hr\n\ntheorem step_self_square {y yy : Raw} (h : Step (p y y) yy) :\n    ∃ k, yy = sq k := by\n  have c := step_cases h\n  clear h\n  rcases c with c0 | c1 | c2 | c3 | c4\n  · rcases c0 with ⟨a, x, b, ht, hu⟩\n    refine ⟨a, ?_⟩\n    grind [lhs0, q, sq]\n  · rcases c1 with ⟨a, b, x, ht, hu, hm0⟩\n    exfalso\n    grind [lhs1, q, sq, nodes_lt_p_left, nodes_lt_p_right]\n  · rcases c2 with ⟨a, x, b, ht, hu, hm0, hm1⟩\n    exfalso\n    grind [lhs2, q, sq, nodes_lt_p_left, nodes_lt_p_right]\n  · rcases c3 with ⟨a, x, b, d, ht, hu, hm0, hm1, hm2⟩\n    exfalso\n    grind [lhs3, q, sq, nodes_lt_p_left, nodes_lt_p_right]\n  · rcases c4 with ⟨ht, hm0, hm1, hm2, hm3⟩\n    exact ⟨y, by simpa [sq] using ht.symm⟩\n\n'
_D15_NF_SOURCE_ROUTES = {'[0,["op",["op",["op",1,1],0],["op",0,2]]]': ('theorem step_source_kernel\n    {k x zw yx xzw out : Raw}\n    (hx : NF x) (hkk_nf : NF (sq k))\n    (hyx_nf : NF yx) (hzw_nf : NF zw) (hxzw_nf : NF xzw)\n    (hyx : Step (p (sq k) x) yx)\n    (hxzw : Step (p x zw) xzw)\n    (hout : Step (p yx xzw) out) :\n    out = x := by\n  have cyx := step_cases hyx\n  have cxzw := step_cases hxzw\n  have cout := step_cases hout\n  clear hyx hxzw hout\n  rcases cout with c0 | c1 | c2 | c3 | c4\n  · rcases c0 with ⟨yo, xo, ao, hto, huo⟩\n    grind (config := { splits := 12, gen := 10 })\n      [StepCases, NF, root, try0, try1, try2, try3, lhs0, lhs1,\n        lhs2, lhs3, q, sq, lhs2_not_nf,\n        nodes_lt_p_left, nodes_lt_p_right]\n  · rcases c1 with ⟨yo, ao, xo, hto, huo, hm0o⟩\n    grind (config := { splits := 12, gen := 10 })\n      [StepCases, NF, root, try0, try1, try2, try3, lhs0, lhs1,\n        lhs2, lhs3, q, sq, lhs2_not_nf,\n        nodes_lt_p_left, nodes_lt_p_right]\n  · rcases c2 with ⟨yo, xo, bo, hto, huo, hm0o, hm1o⟩\n    grind (config := { splits := 12, gen := 10 })\n      [StepCases, NF, root, try0, try1, try2, try3, lhs0, lhs1,\n        lhs2, lhs3, q, sq, lhs2_not_nf,\n        nodes_lt_p_left, nodes_lt_p_right]\n  · rcases c3 with ⟨yo, xo, ao, bo, hto, huo, hm0o, hm1o, hm2o⟩\n    grind (config := { splits := 12, gen := 10 })\n      [StepCases, NF, root, try0, try1, try2, try3, lhs0, lhs1,\n        lhs2, lhs3, q, sq, lhs2_not_nf,\n        nodes_lt_p_left, nodes_lt_p_right]\n  · rcases c4 with ⟨hto, hm0o, hm1o, hm2o, hm3o⟩\n    grind (config := { splits := 12, gen := 10 })\n      [StepCases, NF, root, try0, try1, try2, try3, lhs0, lhs1,\n        lhs2, lhs3, q, sq, lhs2_not_nf,\n        nodes_lt_p_left, nodes_lt_p_right]\n\ntheorem step_source_nf\n    {x y z w yy yx zw xzw out : Raw}\n    (hx : NF x) (hy : NF y) (hz : NF z) (hw : NF w)\n    (hyy_nf : NF yy) (hyx_nf : NF yx)\n    (hzw_nf : NF zw) (hxzw_nf : NF xzw)\n    (hyy : Step (p y y) yy)\n    (hyx : Step (p yy x) yx)\n    (hzw : Step (p z w) zw)\n    (hxzw : Step (p x zw) xzw)\n    (hout : Step (p yx xzw) out) :\n    out = x := by\n  obtain ⟨k, hsq⟩ := step_self_square hyy\n  subst yy\n  exact step_source_kernel hx hyy_nf hyx_nf hzw_nf hxzw_nf\n    hyx hxzw hout\n\ntheorem source_raw (x y z w : Raw)\n    (hx : NF x) (hy : NF y) (hz : NF z) (hw : NF w) :\n    rawOp (rawOp (rawOp y y) x) (rawOp x (rawOp z w)) = x := by\n  apply step_source_nf hx hy hz hw\n  · exact rawOp_nf hy hy\n  · exact rawOp_nf (rawOp_nf hy hy) hx\n  · exact rawOp_nf hz hw\n  · exact rawOp_nf hx (rawOp_nf hz hw)\n  · exact rawOp_step y y\n  · exact rawOp_step (rawOp y y) x\n  · exact rawOp_step z w\n  · exact rawOp_step x (rawOp z w)\n  · exact rawOp_step (rawOp (rawOp y y) x) (rawOp x (rawOp z w))\n\ntheorem source_holds (x y z w : Carrier) :\n    x = op (op (op y y) x) (op x (op z w)) := by\n  apply Subtype.ext\n  exact (source_raw x.1 y.1 z.1 w.1 x.2 y.2 z.2 w.2).symm\n\n\ntheorem source_raw_general (x y z : Raw)\n    (hx : NF x) (hy : NF y) (hz : NF z) :\n    rawOp (rawOp (rawOp y y) x) (rawOp x z) = x := by\n  have hyy := rawOp_step y y\n  obtain ⟨k, hk⟩ := step_self_square hyy\n  apply step_source_kernel (k := k) hx\n  · rw [← hk]\n    exact rawOp_nf hy hy\n  · exact rawOp_nf (rawOp_nf hy hy) hx\n  · exact hz\n  · exact rawOp_nf hx hz\n  · rw [← hk]\n    exact rawOp_step (rawOp y y) x\n  · exact rawOp_step x z\n  · exact rawOp_step (rawOp (rawOp y y) x) (rawOp x z)\n\ntheorem source_holds_general (x y z : Carrier) :\n    x = op (op (op y y) x) (op x z) := by\n  apply Subtype.ext\n  exact (source_raw_general x.1 y.1 z.1 x.2 y.2 z.2).symm\n', '  · intro x y z\n    exact Raw.source_holds_general x y z\n')}
_D15_NF_WITNESS_POOL = (("e",),)


def _d15_nf_p(left, right):
    return ("p", left, right)


def _d15_nf_sq(value):
    return _d15_nf_p(value, value)


def _d15_nf_q(left, right):
    return _d15_nf_p(_d15_nf_sq(left), right)


def _d15_nf_try0(term):
    if (
        term[0] == "p"
        and term[1][0] == "p"
        and term[1][1][0] == "p"
        and term[2][0] == "p"
    ):
        y1, y2 = term[1][1][1], term[1][1][2]
        x1, x2 = term[1][2], term[2][1]
        if y1 == y2 and x1 == x2:
            return x1
    return None


def _d15_nf_try1(term):
    if (
        term[0] == "p"
        and term[1][0] == "p"
        and term[1][1][0] == "p"
        and term[1][2][0] == "p"
        and term[1][2][1][0] == "p"
    ):
        y1, y2 = term[1][1][1], term[1][1][2]
        a1, a2 = term[1][2][1][1], term[1][2][1][2]
        x1, x2 = term[1][2][2], term[2]
        if y1 == y2 and a1 == a2 and x1 == x2:
            return _d15_nf_q(a1, x1)
    return None


def _d15_nf_try2(term):
    if (
        term[0] == "p"
        and term[1][0] == "p"
        and term[2][0] == "p"
        and term[2][1][0] == "p"
        and term[2][1][1][0] == "p"
    ):
        y1, y2 = term[1][1], term[1][2]
        v1, v2 = term[2][1][1][1], term[2][1][1][2]
        x = term[2][1][2]
        if y1 == y2 and v1 == v2 and y1 == v1:
            return _d15_nf_q(y1, x)
    return None


def _d15_nf_try3(term):
    if (
        term[0] == "p"
        and term[1][0] == "p"
        and term[1][1][0] == "p"
        and term[2][0] == "p"
        and term[2][1][0] == "p"
        and term[2][1][1][0] == "p"
        and term[2][1][1][1][0] == "p"
    ):
        y1, y2 = term[1][1][1], term[1][1][2]
        x1 = term[1][2]
        v1, v2 = term[2][1][1][1][1], term[2][1][1][1][2]
        x2, middle = term[2][1][1][2], term[2][1][2]
        if y1 == y2 and v1 == v2 and y1 == v1 and x1 == x2:
            return _d15_nf_p(_d15_nf_q(y1, x1), middle)
    return None


def _d15_nf_op(left, right):
    raw = _d15_nf_p(left, right)
    for attempt in (_d15_nf_try0, _d15_nf_try1, _d15_nf_try2, _d15_nf_try3):
        reduced = attempt(raw)
        if reduced is not None:
            return reduced
    return raw


def _d15_nf_eval(term, values):
    if type(term) is int:
        return values[term]
    return _d15_nf_op(
        _d15_nf_eval(term[0], values),
        _d15_nf_eval(term[1], values),
    )


def _d15_nf_raw_literal(value):
    if value[0] == "e":
        return "Raw.e"
    return (
        f"(Raw.p {_d15_nf_raw_literal(value[1])} "
        f"{_d15_nf_raw_literal(value[2])})"
    )


def _d15_nf_candidate(parsed_source, parsed_target):
    source_pattern = _source_pattern(parsed_source)
    source_route = _D15_NF_SOURCE_ROUTES.get(source_pattern)
    if source_route is None:
        return None
    source_proof, source_branch = source_route
    variables, left, right = parsed_target
    if not 1 <= len(variables) <= 6:
        return None
    for values in product(_D15_NF_WITNESS_POOL, repeat=len(variables)):
        left_value = _d15_nf_eval(left, values)
        right_value = _d15_nf_eval(right, values)
        if left_value == right_value:
            continue
        applications = " ".join("E" for _ in values)
        closed_left = _d15_nf_raw_literal(left_value)
        closed_right = _d15_nf_raw_literal(right_value)
        target_branch = (
            "  · intro target\n"
            "    let E : Raw.Carrier := ⟨Raw.e, True.intro⟩\n"
            f"    have bad := target {applications}\n"
            "    have badv := congrArg Subtype.val bad\n"
            f"    change {closed_left} = {closed_right} at badv\n"
            f"    exact (show Not ({closed_left} = {closed_right}) "
            "from by decide) badv\n"
        )
        submission = (
            "end Raw\n\n"
            "end submission\n\n"
            "open submission\n\n"
            "def submission : Goal := by\n"
            "  refine ⟨Raw.Carrier, Raw.instMagma, ?_, ?_⟩\n"
        )
        return (
            _D15_NF_FAMILY,
            _D15_NF_MODEL_CORE
            + source_proof
            + submission
            + source_branch
            + target_branch,
            "alpha_exact_source_law_and_singleton_target_ast_witness",
        )
    return None


def _infinite_candidate(parsed_source, parsed_target):
    d15_candidate = _d15_exp5_candidate(parsed_source, parsed_target)
    if d15_candidate is not None:
        return d15_candidate
    d15_candidate = _d15_accepted_cm_candidate(parsed_source, parsed_target)
    if d15_candidate is not None:
        return d15_candidate
    d15_candidate = _d15_pattern_cm_candidate(parsed_source, parsed_target)
    if d15_candidate is not None:
        return d15_candidate
    d15_candidate = _d15_kbo_candidate(parsed_source, parsed_target)
    if d15_candidate is not None:
        return d15_candidate
    d15_candidate = _d15_nf_candidate(parsed_source, parsed_target)
    if d15_candidate is not None:
        return d15_candidate
    incoming_pattern = _source_pattern(parsed_source)
    marker = "  -- __D10_TARGET_AST_SYMBOLIC_BRANCH__"
    matches = []
    for row in _infinite_rules():
        source_pattern = row[1]
        substitution = _source_schema_match(source_pattern, parsed_source)
        if substitution is None:
            continue
        exact_source = source_pattern == incoming_pattern
        matches.append((not exact_source, len(row[-1]), row, substitution))
    for _nonexact, _template_bytes, row, substitution in sorted(
        matches, key=lambda item: (item[0], item[1], item[2][0], item[2][1])
    ):
        family, source_pattern, witness_vectors, carrier_type, magma_instance, project_subtype_value, _constructive_model, target_simp_lemmas, target_eval_function, target_eval_opposite, target_stepwise_raw, code_template = row
        exact_source = source_pattern == incoming_pattern
        exact_arity_vectors = tuple(
            tuple(vector) for vector in witness_vectors
            if len(vector) == len(parsed_target[0])
        )
        if exact_source and exact_arity_vectors:
            witness_vectors = exact_arity_vectors
        else:
            witness_vectors = _expanded_witness_vectors(
                witness_vectors, len(parsed_target[0])
            )
        branch = _symbolic_target_branch(
            parsed_target,
            witness_vectors,
            carrier_type,
            magma_instance,
            project_subtype_value,
            target_simp_lemmas,
            target_eval_function,
            target_eval_opposite,
            target_stepwise_raw,
        )
        if branch is None or code_template.count(marker) != 1:
            continue
        template = code_template
        if not exact_source:
            template = _rewrite_source_branch(
                template, parsed_source, substitution, marker
            )
            if template is None:
                continue
        if ("theorem family_submission" in template or
                "-- d14-direct-template" in template):
            code = template.replace(marker, branch)
        else:
            helper_scope = carrier_type
            local_witness_lets = tuple(dict.fromkeys(
                match.group(0).strip()
                for vector in witness_vectors
                for value in vector
                if re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", value)
                for match in [re.search(
                    rf"^[ \t]*let[ \t]+{re.escape(value)}[ \t]*:[^\n]+$",
                    template,
                    re.MULTILINE,
                )]
                if match is not None
            ))
            branch_lines = branch.splitlines()
            if not branch_lines or branch_lines[0] != "  · intro target":
                continue
            helper_body = "\n".join(
                line[2:] if line.startswith("  ") else line
                for line in branch_lines[1:]
            )
            if local_witness_lets:
                helper_body = (
                    "\n".join(f"  {line}" for line in local_witness_lets)
                    + "\n"
                    + helper_body
                )
            helper = (
                f"namespace submission.{helper_scope}\n\n"
                f"theorem d10TargetRefutation\n"
                f"    (target : @EquationRHS {carrier_type} {magma_instance}) : False := by\n"
                f"{helper_body}\n\n"
                f"end submission.{helper_scope}\n\n"
            )
            final_submission = "def submission : Goal := by"
            if template.rfind(final_submission) < 0:
                continue
            simple_branch = (
                "  · intro target\n"
                f"    exact {helper_scope}.d10TargetRefutation target"
            )
            code = template.replace(marker, simple_branch)
            position = code.rfind(final_submission)
            code = code[:position] + helper + code[position:]
        return (
            family,
            code,
            "alpha_exact_source_law"
            if exact_source
            else "uniform_term_substitution_source_schema",
        )
    return None


def _staged_certificate(stage, code):
    """Return the exact Judge payload and its UTF-8 size, or fail closed."""

    staged = f"-- stage:{stage}\n" + code
    size = len(staged.encode("utf-8"))
    if size > MAX_FALSE_CERTIFICATE_BYTES:
        return None, size
    return staged, size


def _eval_term(term, values, table):
    if type(term) is int:
        return values[term]
    return table[_eval_term(term[0], values, table)][
        _eval_term(term[1], values, table)
    ]


def _equation_holds(parsed, table):
    variables, lhs, rhs = parsed
    checked = 0
    for values in product(range(len(table)), repeat=len(variables)):
        checked += 1
        left = _eval_term(lhs, values, table)
        right = _eval_term(rhs, values, table)
        if left != right:
            return False, checked, {
                "assignment": dict(zip(variables, values)),
                "lhs": left,
                "rhs": right,
            }
    return True, checked, None



"""Bounded formula-only finite magma synthesis for False Solver d11.

This file is injected into the generated single-file runtime.  It deliberately
uses no problem IDs, formula hashes, frozen countermodels, or third-party SAT
libraries.  Search is fail-closed: every returned table is exhaustively checked
against the complete source and target equations by the caller.
"""

import random


class _D11Deadline(Exception):
    pass


def _d11_ref_domain(domains, reference):
    if reference < 0:
        return 1 << (-reference - 1)
    return domains[reference]


def _d11_restricted_growth_vectors(length, order):
    """Yield one representative of every carrier-renaming witness orbit."""

    if length <= 0:
        yield ()
        return
    vector = [0] * length

    def visit(index, maximum):
        if index == length:
            yield tuple(vector)
            return
        for value in range(min(order - 1, maximum + 1) + 1):
            vector[index] = value
            yield from visit(index + 1, max(maximum, value))

    yield from visit(1, 0)


def _d11_source_failures(parsed_source, table, limit=1):
    variables, lhs, rhs = parsed_source
    failures = []
    for values in product(range(len(table)), repeat=len(variables)):
        if _eval_term(lhs, values, table) != _eval_term(rhs, values, table):
            failures.append(values)
            if len(failures) >= limit:
                break
    return failures


def _d11_first_source_failure(parsed_source, table):
    failures = _d11_source_failures(parsed_source, table, 1)
    return failures[0] if failures else None


def _d11_target_failure(parsed_target, table):
    variables, lhs, rhs = parsed_target
    for values in _d11_restricted_growth_vectors(len(variables), len(table)):
        left = _eval_term(lhs, values, table)
        right = _eval_term(rhs, values, table)
        if left != right:
            return values, left, right
    return None


def _d11_eval_with_cells(term, values, table):
    if type(term) is int:
        return values[term], ()
    left, left_cells = _d11_eval_with_cells(term[0], values, table)
    right, right_cells = _d11_eval_with_cells(term[1], values, table)
    cell = left * len(table) + right
    return table[left][right], left_cells + right_cells + (cell,)


def _d11_structured_seeds(order):
    """Small formula-independent phase seeds, not a frozen problem lookup."""

    yield [[0 for _column in range(order)] for _row in range(order)]
    yield [[row for _column in range(order)] for row in range(order)]
    yield [[column for column in range(order)] for _row in range(order)]
    yield [[(row + column) % order for column in range(order)] for row in range(order)]
    yield [[(row - column) % order for column in range(order)] for row in range(order)]
    yield [[min(row, column) for column in range(order)] for row in range(order)]
    yield [[max(row, column) for column in range(order)] for row in range(order)]


class _D11ClauseModel:
    """Compact categorical CNF: every group always has exactly one value."""

    def __init__(self, order):
        self.order = order
        self.table_group_count = order * order
        self.group_count = self.table_group_count
        self.clauses = []
        self.operation_groups = {}

    @staticmethod
    def _constant(value):
        return -value - 1

    def _new_group(self):
        group = self.group_count
        self.group_count += 1
        return group

    def _literal(self, reference, value, positive):
        if reference < 0:
            actual = -reference - 1
            truth = actual == value
            return True if truth == positive else False
        atom = reference * self.order + value + 1
        return atom if positive else -atom

    def _add_clause(self, literal_specs):
        clause = []
        for reference, value, positive in literal_specs:
            literal = self._literal(reference, value, positive)
            if literal is True:
                return
            if literal is False:
                continue
            if -literal in clause:
                return
            if literal not in clause:
                clause.append(literal)
        self.clauses.append(tuple(clause))

    def _compile_term(self, term, assignment, memo, references=False):
        if type(term) is int:
            return assignment[term] if references else self._constant(assignment[term])
        if term in memo:
            return memo[term]
        left = self._compile_term(term[0], assignment, memo, references)
        right = self._compile_term(term[1], assignment, memo, references)
        result = self._new_group()
        self.operation_groups[result] = (left, right)
        for row in range(self.order):
            for column in range(self.order):
                cell = row * self.order + column
                for value in range(self.order):
                    self._add_clause(
                        (
                            (left, row, False),
                            (right, column, False),
                            (cell, value, False),
                            (result, value, True),
                        )
                    )
        memo[term] = result
        return result

    def compile_equation(self, parsed, assignment, equality, references=False):
        _variables, lhs, rhs = parsed
        memo = {}
        left = self._compile_term(lhs, assignment, memo, references)
        right = self._compile_term(rhs, assignment, memo, references)
        for value in range(self.order):
            if equality:
                self._add_clause(((left, value, False), (right, value, True)))
                self._add_clause(((right, value, False), (left, value, True)))
            else:
                self._add_clause(((left, value, False), (right, value, False)))


def _d11_clause_parts(literal, order):
    atom = abs(literal) - 1
    return atom // order, atom % order, literal > 0


def _d11_clause_satisfied(clause, assignment, order, override_group=-1, override_value=-1):
    for literal in clause:
        group, value, positive = _d11_clause_parts(literal, order)
        actual = override_value if group == override_group else assignment[group]
        if (actual == value) == positive:
            return True
    return False


def _d11_local_assignment(model, phase_table, deadline, seed, metrics):
    """Finite-domain WalkSAT with one-value groups preserved by construction."""

    order = model.order
    occurrences = [[] for _ in range(model.group_count)]
    for clause_index, clause in enumerate(model.clauses):
        seen = set()
        for literal in clause:
            group, _value, _positive = _d11_clause_parts(literal, order)
            if group not in seen:
                seen.add(group)
                occurrences[group].append(clause_index)

    rng = random.Random(seed)
    restart = 0
    while time.monotonic() < deadline:
        restart += 1
        metrics["dynamic_local_restarts"] += 1
        assignment = [rng.randrange(order) for _ in range(model.group_count)]
        if phase_table is not None:
            for row in range(order):
                for column in range(order):
                    value = phase_table[row][column]
                    if restart > 1 and rng.random() < min(0.5, 0.08 * restart):
                        value = rng.randrange(order)
                    assignment[row * order + column] = value
        # Term-result groups are created bottom-up.  Initialize them by actual
        # evaluation in the phase table so operation clauses start satisfied;
        # only source equality and target disequality need repair.
        for group in range(model.table_group_count, model.group_count):
            operation = model.operation_groups.get(group)
            if operation is None:
                continue
            left, right = operation
            left_value = -left - 1 if left < 0 else assignment[left]
            right_value = -right - 1 if right < 0 else assignment[right]
            assignment[group] = assignment[left_value * order + right_value]

        satisfied = [False] * len(model.clauses)
        unsatisfied = []
        positions = {}

        def add_unsatisfied(index):
            if index not in positions:
                positions[index] = len(unsatisfied)
                unsatisfied.append(index)

        def remove_unsatisfied(index):
            position = positions.pop(index, None)
            if position is None:
                return
            tail = unsatisfied.pop()
            if position < len(unsatisfied):
                unsatisfied[position] = tail
                positions[tail] = position

        for index, clause in enumerate(model.clauses):
            value = _d11_clause_satisfied(clause, assignment, order)
            satisfied[index] = value
            if not value:
                add_unsatisfied(index)
        if not unsatisfied:
            return assignment

        step_limit = max(2_000, min(80_000, 160 * len(model.clauses)))
        for _step in range(step_limit):
            metrics["dynamic_local_steps"] += 1
            if metrics["dynamic_local_steps"] & 1023 == 0 and time.monotonic() >= deadline:
                return None
            if not unsatisfied:
                return assignment
            clause_index = unsatisfied[rng.randrange(len(unsatisfied))]
            clause = model.clauses[clause_index]
            moves = []
            for literal in clause:
                group, literal_value, positive = _d11_clause_parts(literal, order)
                if positive:
                    candidate_values = (literal_value,)
                else:
                    candidate_values = tuple(
                        value for value in range(order) if value != literal_value
                    )
                for new_value in candidate_values:
                    if assignment[group] == new_value:
                        continue
                    delta = 0
                    for affected in occurrences[group]:
                        new_satisfied = _d11_clause_satisfied(
                            model.clauses[affected],
                            assignment,
                            order,
                            group,
                            new_value,
                        )
                        if new_satisfied != satisfied[affected]:
                            delta += -1 if new_satisfied else 1
                    moves.append((delta, rng.random(), group, new_value))
            if not moves:
                break
            if rng.random() < 0.12:
                _delta, _tie, group, new_value = moves[rng.randrange(len(moves))]
            else:
                _delta, _tie, group, new_value = min(moves)
            assignment[group] = new_value
            for affected in occurrences[group]:
                new_satisfied = _d11_clause_satisfied(
                    model.clauses[affected], assignment, order
                )
                if new_satisfied == satisfied[affected]:
                    continue
                satisfied[affected] = new_satisfied
                if new_satisfied:
                    remove_unsatisfied(affected)
                else:
                    add_unsatisfied(affected)
    return None


def _d11_solve_local(order, parsed_source, parsed_target, source_assignments, phase_table, deadline, metrics):
    model = _D11ClauseModel(order)
    target_references = [model._constant(0)]
    target_references.extend(
        model._new_group() for _ in range(len(parsed_target[0]) - 1)
    )
    model.compile_equation(parsed_target, target_references, False, True)
    for assignment in source_assignments:
        model.compile_equation(parsed_source, assignment, True)
    metrics["dynamic_max_groups"] = max(
        metrics.get("dynamic_max_groups", 0), model.group_count
    )
    metrics["dynamic_max_clauses"] = max(
        metrics.get("dynamic_max_clauses", 0), len(model.clauses)
    )
    solved = _d11_local_assignment(
        model,
        phase_table,
        deadline,
        0xD110000 + order * 1009 + len(source_assignments) * 9176,
        metrics,
    )
    if solved is None:
        return None
    return [
        solved[row * order : (row + 1) * order]
        for row in range(order)
    ]


def _d11_full_source_local(parsed_source, parsed_target, seed_tables, deadline, metrics):
    """Repair a source-valid bank model while retaining every small-domain law instance."""

    if not seed_tables:
        return None
    order = len(seed_tables[0])
    assignment_count = order ** len(parsed_source[0])
    if assignment_count > 125:
        return None
    source_assignments = list(
        product(range(order), repeat=len(parsed_source[0]))
    )
    model = _D11ClauseModel(order)
    target_references = [model._constant(0)]
    target_references.extend(
        model._new_group() for _ in range(len(parsed_target[0]) - 1)
    )
    model.compile_equation(parsed_target, target_references, False, True)
    for assignment in source_assignments:
        model.compile_equation(parsed_source, assignment, True)
    metrics["dynamic_full_source_groups"] = max(
        metrics.get("dynamic_full_source_groups", 0), model.group_count
    )
    metrics["dynamic_full_source_clauses"] = max(
        metrics.get("dynamic_full_source_clauses", 0), len(model.clauses)
    )
    phases = seed_tables[: min(12, len(seed_tables))]
    for index, phase in enumerate(phases):
        if time.monotonic() >= deadline:
            return None
        remaining = len(phases) - index
        slice_deadline = min(
            deadline,
            time.monotonic() + max(0.03, (deadline - time.monotonic()) / remaining),
        )
        solved = _d11_local_assignment(
            model,
            phase,
            slice_deadline,
            0xD11F011 + index * 65537 + order,
            metrics,
        )
        if solved is None:
            continue
        table = [
            solved[row * order : (row + 1) * order]
            for row in range(order)
        ]
        if _d11_first_source_failure(parsed_source, table) is None and (
            _d11_target_failure(parsed_target, table) is not None
        ):
            return table
    return None


def _d11_equation_trace(parsed, assignment, table):
    left, left_cells = _d11_eval_with_cells(parsed[1], assignment, table)
    right, right_cells = _d11_eval_with_cells(parsed[2], assignment, table)
    return left == right, tuple(set(left_cells + right_cells))


def _d11_direct_repair(parsed_source, parsed_target, seed_tables, deadline, metrics):
    """Min-conflicts repair over table cells with exact incremental source checks."""

    if not seed_tables:
        return None
    order = len(seed_tables[0])
    source_assignment_count = order ** len(parsed_source[0])
    if source_assignment_count > 125:
        return None
    source_assignments = list(
        product(range(order), repeat=len(parsed_source[0]))
    )
    witnesses = list(
        _d11_restricted_growth_vectors(len(parsed_target[0]), order)
    )
    rng = random.Random(0xD11D1EC7 + order)
    phases = seed_tables[: min(32, len(seed_tables))]
    restart = 0
    while time.monotonic() < deadline:
        metrics["dynamic_direct_restarts"] += 1
        phase = phases[restart % len(phases)]
        restart += 1
        table = [row[:] for row in phase]
        witness = witnesses[rng.randrange(len(witnesses))]
        records = []
        cell_users = [set() for _ in range(order * order)]
        violations = set()
        for index, assignment in enumerate(source_assignments):
            holds, cells = _d11_equation_trace(parsed_source, assignment, table)
            records.append((holds, cells))
            if not holds:
                violations.add(index)
            for cell in cells:
                cell_users[cell].add(index)

        for _step in range(900):
            metrics["dynamic_direct_steps"] += 1
            if metrics["dynamic_direct_steps"] & 127 == 0 and time.monotonic() >= deadline:
                return None
            target_holds, target_cells = _d11_equation_trace(
                parsed_target, witness, table
            )
            if not violations and not target_holds:
                return table

            candidate_cells = set(target_cells)
            if violations:
                for index in rng.sample(
                    tuple(violations), min(4, len(violations))
                ):
                    candidate_cells.update(records[index][1])
            while len(candidate_cells) < min(8, order * order):
                candidate_cells.add(rng.randrange(order * order))

            moves = []
            for cell in candidate_cells:
                old_value = table[cell // order][cell % order]
                for new_value in range(order):
                    if new_value == old_value:
                        continue
                    table[cell // order][cell % order] = new_value
                    new_violation_count = len(violations)
                    for index in cell_users[cell]:
                        old_holds = records[index][0]
                        new_holds, _new_cells = _d11_equation_trace(
                            parsed_source, source_assignments[index], table
                        )
                        if old_holds != new_holds:
                            new_violation_count += -1 if new_holds else 1
                    new_target_holds, _cells = _d11_equation_trace(
                        parsed_target, witness, table
                    )
                    table[cell // order][cell % order] = old_value
                    score = new_violation_count + (10 if new_target_holds else 0)
                    moves.append((score, rng.random(), "cell", cell, new_value))

            for variable in range(1, len(witness)):
                for new_value in range(order):
                    if new_value == witness[variable]:
                        continue
                    candidate_witness = list(witness)
                    candidate_witness[variable] = new_value
                    new_target_holds, _cells = _d11_equation_trace(
                        parsed_target, tuple(candidate_witness), table
                    )
                    score = len(violations) + (10 if new_target_holds else 0)
                    moves.append(
                        (score, rng.random(), "witness", variable, new_value)
                    )
            if not moves:
                break
            if rng.random() < 0.10:
                move = moves[rng.randrange(len(moves))]
            else:
                move = min(moves)
            _score, _tie, kind, location, new_value = move
            if kind == "witness":
                updated = list(witness)
                updated[location] = new_value
                witness = tuple(updated)
                continue

            cell = location
            affected = tuple(cell_users[cell])
            table[cell // order][cell % order] = new_value
            for index in affected:
                old_holds, old_cells = records[index]
                new_holds, new_cells = _d11_equation_trace(
                    parsed_source, source_assignments[index], table
                )
                if old_holds and not new_holds:
                    violations.add(index)
                elif not old_holds and new_holds:
                    violations.discard(index)
                if old_cells != new_cells:
                    for old_cell in old_cells:
                        cell_users[old_cell].discard(index)
                    for new_cell in new_cells:
                        cell_users[new_cell].add(index)
                records[index] = (new_holds, new_cells)
    return None


class _D11CSP:
    """Tiny finite-domain CSP specialized to an unknown binary operation."""

    def _new_variable(self):
        variable = len(self.domains)
        self.domains.append(self.full)
        return variable

    @staticmethod
    def _constant(value):
        return -value - 1

    def _compile_term(self, term, assignment, memo, references=False):
        if type(term) is int:
            if references:
                return assignment[term]
            return self._constant(assignment[term])
        if term in memo:
            return memo[term]
        left = self._compile_term(term[0], assignment, memo, references)
        right = self._compile_term(term[1], assignment, memo, references)
        result = self._new_variable()
        self.operations.append((left, right, result))
        memo[term] = result
        return result

    def _compile_equation(self, parsed, assignment, equality, references=False):
        _variables, lhs, rhs = parsed
        memo = {}
        left = self._compile_term(lhs, assignment, memo, references)
        right = self._compile_term(rhs, assignment, memo, references)
        if equality:
            self.equalities.append((left, right))
        else:
            self.disequalities.append((left, right))

    def _set_domain(self, reference, mask):
        if reference < 0:
            return bool(mask & _d11_ref_domain(self.domains, reference)), False
        new_mask = self.domains[reference] & mask
        if not new_mask:
            return False, False
        if new_mask == self.domains[reference]:
            return True, False
        self.domains[reference] = new_mask
        return True, True

    def _propagate(self):
        order = self.order
        while True:
            if time.monotonic() >= self.deadline:
                raise _D11Deadline
            changed = False
            self.metrics["dynamic_propagation_rounds"] += 1

            for left, right in self.equalities:
                common = _d11_ref_domain(self.domains, left) & _d11_ref_domain(self.domains, right)
                if not common:
                    return False
                ok, did_change = self._set_domain(left, common)
                if not ok:
                    return False
                changed |= did_change
                ok, did_change = self._set_domain(right, common)
                if not ok:
                    return False
                changed |= did_change

            for left, right in self.disequalities:
                left_domain = _d11_ref_domain(self.domains, left)
                right_domain = _d11_ref_domain(self.domains, right)
                if left_domain.bit_count() == right_domain.bit_count() == 1:
                    if left_domain == right_domain:
                        return False
                    continue
                if left_domain.bit_count() == 1:
                    ok, did_change = self._set_domain(right, self.full ^ left_domain)
                    if not ok:
                        return False
                    changed |= did_change
                if right_domain.bit_count() == 1:
                    ok, did_change = self._set_domain(left, self.full ^ right_domain)
                    if not ok:
                        return False
                    changed |= did_change

            for left, right, result in self.operations:
                left_domain = _d11_ref_domain(self.domains, left)
                right_domain = _d11_ref_domain(self.domains, right)
                result_domain = self.domains[result]
                supported_left = 0
                supported_right = 0
                supported_result = 0
                for row in range(order):
                    row_bit = 1 << row
                    if not left_domain & row_bit:
                        continue
                    for column in range(order):
                        column_bit = 1 << column
                        if not right_domain & column_bit:
                            continue
                        cell_domain = self.domains[row * order + column]
                        common = cell_domain & result_domain
                        if common:
                            supported_left |= row_bit
                            supported_right |= column_bit
                            supported_result |= common
                if not supported_left or not supported_right or not supported_result:
                    return False
                ok, did_change = self._set_domain(left, supported_left)
                if not ok:
                    return False
                changed |= did_change
                ok, did_change = self._set_domain(right, supported_right)
                if not ok:
                    return False
                changed |= did_change
                ok, did_change = self._set_domain(result, supported_result)
                if not ok:
                    return False
                changed |= did_change

                left_domain = _d11_ref_domain(self.domains, left)
                right_domain = _d11_ref_domain(self.domains, right)
                if left_domain.bit_count() == right_domain.bit_count() == 1:
                    row = left_domain.bit_length() - 1
                    column = right_domain.bit_length() - 1
                    cell = row * order + column
                    common = self.domains[cell] & self.domains[result]
                    if not common:
                        return False
                    if common != self.domains[cell]:
                        self.domains[cell] = common
                        changed = True
                    if common != self.domains[result]:
                        self.domains[result] = common
                        changed = True

            if not changed:
                return True

    def _candidate_table(self):
        table = []
        for row in range(self.order):
            output_row = []
            for column in range(self.order):
                domain = self.domains[row * self.order + column]
                if domain.bit_count() != 1:
                    return None
                output_row.append(domain.bit_length() - 1)
            table.append(output_row)
        return table

    def _choose_variable(self):
        best = None
        best_key = None
        for variable, domain in enumerate(self.domains):
            size = domain.bit_count()
            if size <= 1:
                continue
            # Term results are selected before equally sized table cells so
            # operation inputs become concrete and constrain the relevant cell.
            key = (size, variable < self.table_variable_count, variable)
            if best_key is None or key < best_key:
                best_key = key
                best = variable
        return best

    def _value_order(self, variable):
        domain = self.domains[variable]
        values = []
        if variable < self.table_variable_count and self.phase_table is not None:
            row, column = divmod(variable, self.order)
            phase = self.phase_table[row][column]
            if domain & (1 << phase):
                values.append(phase)
            for peer in (
                self.phase_table[max(0, row - 1)][column],
                self.phase_table[row][max(0, column - 1)],
            ):
                if domain & (1 << peer) and peer not in values:
                    values.append(peer)
        for value in range(self.order):
            if domain & (1 << value) and value not in values:
                values.append(value)
        return values

    def search(self):
        self.metrics["dynamic_search_nodes"] += 1
        if self.metrics["dynamic_search_nodes"] & 255 == 0 and time.monotonic() >= self.deadline:
            raise _D11Deadline
        snapshot = self.domains[:]
        if not self._propagate():
            self.metrics["dynamic_conflicts"] += 1
            self.domains = snapshot
            return None
        table = self._candidate_table()
        if table is not None:
            if _d11_target_failure(self.parsed_target, table) is None or any(
                _eval_term(self.parsed_source[1], assignment, table)
                != _eval_term(self.parsed_source[2], assignment, table)
                for assignment in self.source_assignments
            ):
                self.metrics["dynamic_conflicts"] += 1
                self.domains = snapshot
                return None
            self.domains = snapshot
            return table
        variable = self._choose_variable()
        if variable is None:
            self.domains = snapshot
            return None
        propagated = self.domains[:]
        for value in self._value_order(variable):
            self.domains = propagated[:]
            self.domains[variable] = 1 << value
            result = self.search()
            if result is not None:
                self.domains = snapshot
                return result
        self.domains = snapshot
        return None


def _d11_solve_csp(order, parsed_source, parsed_target, source_assignments, phase_table, deadline, metrics):
    solver = _D11CSP.__new__(_D11CSP)
    solver.order = order
    solver.full = (1 << order) - 1
    solver.table_variable_count = order * order
    solver.domains = [solver.full] * solver.table_variable_count
    solver.operations = []
    solver.equalities = []
    solver.disequalities = []
    solver.deadline = deadline
    solver.metrics = metrics
    solver.phase_table = phase_table
    solver.parsed_source = parsed_source
    solver.parsed_target = parsed_target
    solver.source_assignments = source_assignments
    # Search for the target witness together with the table.  Fixing the first
    # target variable to zero is sound under carrier relabeling and removes the
    # largest symmetry orbit without enumerating witness equality patterns.
    target_references = [solver._constant(0)]
    target_references.extend(
        solver._new_variable() for _ in range(len(parsed_target[0]) - 1)
    )
    solver._compile_equation(parsed_target, target_references, False, True)
    for assignment in source_assignments:
        solver._compile_equation(parsed_source, assignment, True)
    return solver.search()


def _d11_seed_neighborhood(parsed_source, parsed_target, seed_tables, deadline, metrics):
    """Search small Hamming neighborhoods of source-valid bank models."""

    rng = random.Random(0xD11CEED)
    for seed in seed_tables:
        order = len(seed)
        if order not in (4, 5):
            continue
        flat = [value for row in seed for value in row]
        witnesses = sorted(
            _d11_restricted_growth_vectors(len(parsed_target[0]), order),
            key=lambda values: (-len(set(values)), values),
        )
        mutation_jobs = []
        for witness in witnesses:
            left, left_cells = _d11_eval_with_cells(parsed_target[1], witness, seed)
            right, right_cells = _d11_eval_with_cells(parsed_target[2], witness, seed)
            if left != right:
                return seed
            relevant = tuple(sorted(set(left_cells + right_cells)))
            mutation_jobs.extend(((witness, (cell,)) for cell in relevant))
            mutation_jobs.extend(
                (witness, (first, second))
                for position, first in enumerate(relevant)
                for second in relevant[position + 1 :]
            )
            if len(relevant) >= 3:
                mutation_jobs.extend(
                    (witness, tuple(sorted(rng.sample(relevant, 3))))
                    for _ in range(min(24, len(relevant) * 3))
                )
        for witness, cells in mutation_jobs:
            value_choices = [[]]
            for cell in cells:
                value_choices = [
                    prefix + [value]
                    for prefix in value_choices
                    for value in range(order)
                    if value != flat[cell]
                ]
            for values in value_choices:
                metrics["dynamic_seed_mutations"] += 1
                if metrics["dynamic_seed_mutations"] & 255 == 0 and time.monotonic() >= deadline:
                    return None
                candidate_flat = flat[:]
                for cell, value in zip(cells, values):
                    candidate_flat[cell] = value
                table = [
                    candidate_flat[row * order : (row + 1) * order]
                    for row in range(order)
                ]
                if _d11_first_source_failure(parsed_source, table) is None:
                    left = _eval_term(parsed_target[1], witness, table)
                    right = _eval_term(parsed_target[2], witness, table)
                    if left != right:
                        return table
    return None


def _d11_dynamic_countermodel(parsed_source, parsed_target, seconds, metrics, seed_tables=()):
    """Find a verified Fin4/Fin5 table within a strict local wall budget."""

    started = time.monotonic()
    deadline = started + max(0.0, seconds)
    metrics.setdefault("dynamic_orders_attempted", 0)
    metrics.setdefault("dynamic_witnesses_attempted", 0)
    metrics.setdefault("dynamic_cegis_rounds", 0)
    metrics.setdefault("dynamic_source_instances", 0)
    metrics.setdefault("dynamic_search_nodes", 0)
    metrics.setdefault("dynamic_propagation_rounds", 0)
    metrics.setdefault("dynamic_conflicts", 0)
    metrics.setdefault("dynamic_local_restarts", 0)
    metrics.setdefault("dynamic_local_steps", 0)
    metrics.setdefault("dynamic_seed_mutations", 0)
    metrics.setdefault("dynamic_direct_restarts", 0)
    metrics.setdefault("dynamic_direct_steps", 0)

    usable_seeds = [
        table for table in seed_tables
        if len(table) in (4, 5)
        and _d11_first_source_failure(parsed_source, table) is None
    ]
    metrics["dynamic_source_valid_seeds"] = len(usable_seeds)
    neighborhood_deadline = min(deadline, started + max(0.02, seconds * 0.35))
    seeded = _d11_seed_neighborhood(
        parsed_source, parsed_target, usable_seeds, neighborhood_deadline, metrics
    )
    if seeded is not None:
        metrics["dynamic_elapsed_seconds"] = round(time.monotonic() - started, 6)
        return seeded

    direct_deadline = min(deadline, started + max(0.04, seconds * 0.72))
    for order in (4, 5):
        order_seeds = [table for table in usable_seeds if len(table) == order]
        repaired = _d11_direct_repair(
            parsed_source, parsed_target, order_seeds, direct_deadline, metrics
        )
        if repaired is not None:
            metrics["dynamic_elapsed_seconds"] = round(time.monotonic() - started, 6)
            return repaired

    full_source_deadline = min(deadline, started + max(0.04, seconds * 0.88))
    for order in (4, 5):
        order_seeds = [table for table in usable_seeds if len(table) == order]
        repaired = _d11_full_source_local(
            parsed_source,
            parsed_target,
            order_seeds,
            full_source_deadline,
            metrics,
        )
        if repaired is not None:
            metrics["dynamic_elapsed_seconds"] = round(time.monotonic() - started, 6)
            return repaired

    for order in (4, 5):
        if time.monotonic() >= deadline:
            break
        metrics["dynamic_orders_attempted"] += 1
        for seed in _d11_structured_seeds(order):
            if _d11_first_source_failure(parsed_source, seed) is None:
                target_failure = _d11_target_failure(parsed_target, seed)
                if target_failure is not None:
                    metrics["dynamic_elapsed_seconds"] = round(time.monotonic() - started, 6)
                    return seed

        metrics["dynamic_witnesses_attempted"] += 1
        source_assignments = []
        order_seeds = [table for table in usable_seeds if len(table) == order]
        phase_table = (
            order_seeds[0] if order_seeds else next(_d11_structured_seeds(order))
        )
        while time.monotonic() < deadline:
            metrics["dynamic_cegis_rounds"] += 1
            try:
                table = _d11_solve_local(
                    order,
                    parsed_source,
                    parsed_target,
                    source_assignments,
                    phase_table,
                    deadline,
                    metrics,
                )
            except _D11Deadline:
                metrics["dynamic_elapsed_seconds"] = round(time.monotonic() - started, 6)
                return None
            if table is None:
                break
            phase_table = table
            failures = _d11_source_failures(parsed_source, table, 16)
            if not failures:
                if _d11_target_failure(parsed_target, table) is not None:
                    metrics["dynamic_elapsed_seconds"] = round(time.monotonic() - started, 6)
                    return table
                break
            new_failures = [
                failure for failure in failures if failure not in source_assignments
            ]
            if not new_failures:
                break
            source_assignments.extend(new_failures)
            metrics["dynamic_source_instances"] += len(new_failures)
    metrics["dynamic_elapsed_seconds"] = round(time.monotonic() - started, 6)
    return None



ENGINE = "standalone-py-cdcl"


class ParseError(ValueError):
    pass


class SearchTimeout(RuntimeError):
    pass


class Term:
    __slots__ = ("id", "key", "name", "left", "right", "variables")

    def __init__(self, ident, key, name=None, left=None, right=None, variables=()):
        self.id = ident
        self.key = key
        self.name = name
        self.left = left
        self.right = right
        self.variables = variables


class TermFactory:
    __slots__ = ("by_key", "next_id")

    def __init__(self):
        self.by_key = {}
        self.next_id = 1

    def leaf(self, name):
        node = self.by_key.get(name)
        if node is not None:
            return node
        node = Term(self.next_id, name, name=name, variables=(name,))
        self.next_id += 1
        self.by_key[name] = node
        return node

    def product(self, left, right):
        key = "(" + left.key + "*" + right.key + ")"
        node = self.by_key.get(key)
        if node is not None:
            return node
        variables = tuple(sorted(set(left.variables + right.variables)))
        node = Term(self.next_id, key, left=left, right=right, variables=variables)
        self.next_id += 1
        self.by_key[key] = node
        return node


class TermParser:
    __slots__ = ("text", "factory", "pos")

    def __init__(self, text, factory):
        self.text = text
        self.factory = factory
        self.pos = 0

    def parse(self):
        term = self.expression()
        self.space()
        if self.pos != len(self.text):
            raise ParseError(f"unexpected input at {self.pos}")
        return term

    def space(self):
        text = self.text
        length = len(text)
        while self.pos < length and text[self.pos].isspace():
            self.pos += 1

    def expression(self):
        node = self.atom()
        while True:
            self.space()
            if self.pos >= len(self.text) or self.text[self.pos] != "*":
                return node
            self.pos += 1
            node = self.factory.product(node, self.atom())

    def atom(self):
        self.space()
        if self.pos >= len(self.text):
            raise ParseError("unexpected end of term")
        if self.text[self.pos] == "(":
            self.pos += 1
            node = self.expression()
            self.space()
            if self.pos >= len(self.text) or self.text[self.pos] != ")":
                raise ParseError(f"missing ')' at {self.pos}")
            self.pos += 1
            return node
        start = self.pos
        first = self.text[self.pos]
        if not (first.isalpha() or first == "_"):
            raise ParseError(f"expected variable at {self.pos}")
        self.pos += 1
        while self.pos < len(self.text):
            char = self.text[self.pos]
            if not (char.isalnum() or char == "_"):
                break
            self.pos += 1
        return self.factory.leaf(self.text[start:self.pos])


def parse_equation(text, factory=None):
    if factory is None:
        factory = TermFactory()
    parts = text.split("=")
    if len(parts) != 2:
        raise ParseError(f"expected one equality: {text}")
    return TermParser(parts[0], factory).parse(), TermParser(parts[1], factory).parse()


class CNF:
    __slots__ = ("next_var", "data", "offsets", "lengths")

    def __init__(self):
        self.next_var = 1
        self.data = []
        self.offsets = []
        self.lengths = []

    @property
    def variable_count(self):
        return self.next_var - 1

    @property
    def clause_count(self):
        return len(self.offsets)

    def fresh_vector(self, size):
        start = self.next_var
        self.next_var += size
        return list(range(start, start + size))

    def add(self, literals):
        self.offsets.append(len(self.data))
        self.lengths.append(len(literals))
        self.data.extend(literals)

    def exactly_one(self, literals):
        self.add(literals)
        length = len(literals)
        for i in range(length):
            left = -literals[i]
            for j in range(i + 1, length):
                self.add((left, -literals[j]))


class MagmaEncoder:
    __slots__ = (
        "size", "deadline", "fix_first_witness", "witness_pattern", "cnf",
        "decision_variables", "decision_groups", "table", "structure",
        "ground_cache", "symbolic_cache", "witness", "grounding_count",
    )

    def __init__(self, size, deadline=math.inf, fix_first_witness=True,
                 structure="none", witness_pattern=None):
        self.size = size
        self.deadline = deadline
        self.fix_first_witness = fix_first_witness
        self.witness_pattern = witness_pattern
        self.cnf = CNF()
        self.decision_variables = []
        self.decision_groups = []
        self.table = [[None] * size for _ in range(size)]
        clone_first = size - 2 if structure == "idempotent-clone" else -1
        clone_second = size - 1 if structure == "idempotent-clone" else -1
        if structure == "idempotent-clone" and size < 4:
            raise ValueError("idempotent-clone needs a domain of size at least 4")
        for left in range(size):
            for right in range(size):
                shared = None
                if structure == "idempotent-clone":
                    if left == clone_second and right != clone_second:
                        shared = self.table[clone_first][right]
                    elif right == clone_second and left != clone_second:
                        shared = self.table[left][clone_first]
                if shared is not None:
                    self.table[left][right] = shared
                    continue
                cell = self.cnf.fresh_vector(size)
                self.decision_variables.extend(cell)
                self.decision_groups.append(cell)
                self.table[left][right] = cell
                self.cnf.exactly_one(cell)
        if structure in ("idempotent", "idempotent-clone"):
            for value in range(size):
                self.cnf.add((self.table[value][value][value],))
        self.structure = structure
        self.ground_cache = {}
        self.symbolic_cache = {}
        self.witness = {}
        self.grounding_count = 0

    def check_time(self):
        if time.perf_counter() > self.deadline:
            raise SearchTimeout("encoding timeout")

    def new_value(self):
        result = self.cnf.fresh_vector(self.size)
        self.cnf.exactly_one(result)
        return result

    def product(self, left, right):
        output = self.new_value()
        left_const = isinstance(left, int)
        right_const = isinstance(right, int)
        same = not left_const and not right_const and left is right
        left_values = range(left, left + 1) if left_const else range(self.size)
        right_values = range(right, right + 1) if right_const else range(self.size)
        for a in left_values:
            for b in right_values:
                if same and a != b:
                    continue
                prefix = []
                if not left_const:
                    prefix.append(-left[a])
                if not right_const and not (same and a == b):
                    prefix.append(-right[b])
                cell = self.table[a][b]
                for c in range(self.size):
                    self.cnf.add((*prefix, -cell[c], output[c]))
        return output

    def ground(self, node, assignment):
        if node.name is not None:
            return assignment[node.name]
        key = (node.id,) + tuple(assignment[name] for name in node.variables)
        cached = self.ground_cache.get(key)
        if cached is not None:
            return cached
        left = self.ground(node.left, assignment)
        right = self.ground(node.right, assignment)
        result = self.table[left][right] if isinstance(left, int) and isinstance(right, int) else self.product(left, right)
        self.ground_cache[key] = result
        return result

    def symbolic(self, node):
        if node.name is not None:
            return self.witness[node.name]
        cached = self.symbolic_cache.get(node.id)
        if cached is not None:
            return cached
        result = self.product(self.symbolic(node.left), self.symbolic(node.right))
        self.symbolic_cache[node.id] = result
        return result

    def equal(self, left, right):
        left_const = isinstance(left, int)
        right_const = isinstance(right, int)
        if left_const and right_const:
            if left != right:
                self.cnf.add(())
            return
        if left_const:
            self.cnf.add((right[left],))
            return
        if right_const:
            self.cnf.add((left[right],))
            return
        if left is right:
            return
        for value in range(self.size):
            self.cnf.add((-left[value], right[value]))
            self.cnf.add((-right[value], left[value]))

    def encode(self, premise, target):
        premise_vars = tuple(sorted(set(premise[0].variables + premise[1].variables)))
        assignment = {}

        def visit(index):
            if index < len(premise_vars):
                name = premise_vars[index]
                for value in range(self.size):
                    assignment[name] = value
                    visit(index + 1)
                return
            self.grounding_count += 1
            if (self.grounding_count & 255) == 0:
                self.check_time()
            self.equal(self.ground(premise[0], assignment), self.ground(premise[1], assignment))

        visit(0)
        target_vars = tuple(sorted(set(target[0].variables + target[1].variables)))
        for name in target_vars:
            vector = self.cnf.fresh_vector(self.size)
            self.decision_variables.extend(vector)
            self.decision_groups.append(vector)
            self.cnf.exactly_one(vector)
            self.witness[name] = vector
        if self.witness_pattern is not None:
            if len(self.witness_pattern) != len(target_vars):
                raise ValueError(f"witness pattern needs {len(target_vars)} values")
            for index, name in enumerate(target_vars):
                value = self.witness_pattern[index]
                if value < 0 or value >= self.size:
                    raise ValueError("witness pattern value outside domain")
                self.cnf.add((self.witness[name][value],))
        if self.fix_first_witness:
            # Restricted-growth tuples remove only witness renamings.
            for index, name in enumerate(target_vars):
                vector = self.witness[name]
                for value in range(index + 1, self.size):
                    self.cnf.add((-vector[value],))
        left = self.symbolic(target[0])
        right = self.symbolic(target[1])
        for value in range(self.size):
            self.cnf.add((-left[value], -right[value]))
        self.check_time()


def lit_index(literal):
    return literal << 1 if literal > 0 else ((-literal) << 1) | 1


class VarHeap:
    __slots__ = ("activity", "allowed", "heap", "pos")

    def __init__(self, activity, allowed=None):
        self.activity = activity
        self.allowed = allowed
        self.heap = [0]
        self.pos = [0] * len(activity)
        for variable in range(1, len(activity)):
            self.insert(variable)

    def better(self, left, right):
        difference = self.activity[left] - self.activity[right]
        return difference > 0.0 or (difference == 0.0 and left < right)

    def up(self, index):
        value = self.heap[index]
        while index > 1:
            parent = index >> 1
            if not self.better(value, self.heap[parent]):
                break
            self.heap[index] = self.heap[parent]
            self.pos[self.heap[index]] = index
            index = parent
        self.heap[index] = value
        self.pos[value] = index

    def down(self, index):
        value = self.heap[index]
        length = len(self.heap)
        while True:
            child = index << 1
            if child >= length:
                break
            if child + 1 < length and self.better(self.heap[child + 1], self.heap[child]):
                child += 1
            if not self.better(self.heap[child], value):
                break
            self.heap[index] = self.heap[child]
            self.pos[self.heap[index]] = index
            index = child
        self.heap[index] = value
        self.pos[value] = index

    def insert(self, variable):
        if self.allowed is not None and not self.allowed[variable]:
            return
        if self.pos[variable]:
            return
        self.heap.append(variable)
        self.pos[variable] = len(self.heap) - 1
        self.up(len(self.heap) - 1)

    def remove(self, variable):
        index = self.pos[variable]
        if not index:
            return
        last = self.heap.pop()
        self.pos[variable] = 0
        if index < len(self.heap):
            self.heap[index] = last
            self.pos[last] = index
            if index > 1 and self.better(last, self.heap[index >> 1]):
                self.up(index)
            else:
                self.down(index)

    def update(self, variable):
        index = self.pos[variable]
        if index:
            self.up(index)

    def pop(self):
        if len(self.heap) == 1:
            return 0
        result = self.heap[1]
        self.remove(result)
        return result


def luby(base, index):
    size = 1
    sequence = 0
    while size < index + 1:
        size = 2 * size + 1
        sequence += 1
    while size - 1 != index:
        size = (size - 1) >> 1
        sequence -= 1
        index %= size
    return base ** sequence


class CDCLSolver:
    __slots__ = (
        "cnf", "deadline", "nvars", "original_clauses", "assigns", "level",
        "reason", "phase", "phase_mode", "seed", "decision_mask", "branch_mode",
        "restart_base", "decision_groups", "group_of", "activity", "seen",
        "trail", "qhead", "trail_lim", "watches", "units", "learnt_ids",
        "learnt_deleted", "learnt_activity", "learnt_lbd", "var_inc",
        "clause_inc", "conflicts", "decisions", "propagations", "restarts",
        "aborted", "inconsistent", "heap",
    )

    def __init__(self, cnf, deadline=math.inf, options=None):
        options = options or {}
        self.cnf = cnf
        self.deadline = deadline
        self.nvars = cnf.variable_count
        self.original_clauses = cnf.clause_count
        self.assigns = [0] * (self.nvars + 1)
        self.level = [0] * (self.nvars + 1)
        self.reason = [-1] * (self.nvars + 1)
        self.phase = [0] * (self.nvars + 1)
        self.phase_mode = options.get("phase", "negative")
        self.seed = int(options.get("seed", 1)) & 0xFFFFFFFF
        for variable in range(1, self.nvars + 1):
            if self.phase_mode == "positive":
                self.phase[variable] = 1
            elif self.phase_mode == "mixed":
                value = ((variable ^ self.seed ^ 0x9E3779B9) * 0x85EBCA6B) & 0xFFFFFFFF
                value ^= value >> 13
                self.phase[variable] = 1 if value & 1 else -1
            else:
                self.phase[variable] = -1
        decision_variables = options.get("decision_variables")
        self.decision_mask = None
        if decision_variables is not None:
            self.decision_mask = [False] * (self.nvars + 1)
            for variable in decision_variables:
                self.decision_mask[variable] = True
        self.branch_mode = options.get("branch", "boolean")
        self.restart_base = int(options.get("restart_base", 100))
        self.decision_groups = options.get("decision_groups", [])
        self.group_of = [-1] * (self.nvars + 1)
        for group_index, group in enumerate(self.decision_groups):
            for variable in group:
                self.group_of[variable] = group_index
        self.activity = [0.0] * (self.nvars + 1)
        self.seen = [False] * (self.nvars + 1)
        self.trail = []
        self.qhead = 0
        self.trail_lim = []
        self.watches = [None] * ((self.nvars + 1) * 2 + 2)
        self.units = []
        self.learnt_ids = []
        self.learnt_deleted = []
        self.learnt_activity = []
        self.learnt_lbd = []
        self.var_inc = 1.0
        self.clause_inc = 1.0
        self.conflicts = 0
        self.decisions = 0
        self.propagations = 0
        self.restarts = 0
        self.aborted = False
        self.inconsistent = False
        self.initialize()

    @property
    def decision_level(self):
        return len(self.trail_lim)

    def watch(self, literal):
        index = lit_index(literal)
        watched = self.watches[index]
        if watched is None:
            watched = []
            self.watches[index] = watched
        return watched

    def initialize(self):
        occurrence = [0] * (self.nvars + 1)
        data = self.cnf.data
        for cid in range(self.original_clauses):
            offset = self.cnf.offsets[cid]
            length = self.cnf.lengths[cid]
            if length == 0:
                self.inconsistent = True
                continue
            for index in range(offset, offset + length):
                occurrence[abs(data[index])] += 1
            if length == 1:
                self.units.append((data[offset], cid))
            else:
                self.watch(data[offset]).append(cid)
                self.watch(data[offset + 1]).append(cid)
        maximum = max(1, max(occurrence))
        for variable in range(1, self.nvars + 1):
            noise = ((variable ^ self.seed) * 0x27D4EB2D) & 0xFFFFFFFF
            noise ^= noise >> 15
            self.activity[variable] = occurrence[variable] / maximum + noise / 0xFFFFFFFF * 1e-5
        self.heap = VarHeap(self.activity, self.decision_mask)
        for literal, reason in self.units:
            if not self.enqueue(literal, reason):
                self.inconsistent = True

    def value(self, literal):
        assigned = self.assigns[abs(literal)]
        return assigned if literal > 0 else -assigned

    def enqueue(self, literal, reason):
        value = self.value(literal)
        if value:
            return value > 0
        variable = abs(literal)
        assigned = 1 if literal > 0 else -1
        self.assigns[variable] = assigned
        self.phase[variable] = assigned
        self.level[variable] = self.decision_level
        self.reason[variable] = reason
        self.trail.append(literal)
        self.heap.remove(variable)
        return True

    def is_deleted(self, cid):
        return cid >= self.original_clauses and self.learnt_deleted[cid - self.original_clauses] == 1

    def propagate(self):
        data = self.cnf.data
        offsets = self.cnf.offsets
        lengths = self.cnf.lengths
        while self.qhead < len(self.trail):
            false_literal = -self.trail[self.qhead]
            self.qhead += 1
            self.propagations += 1
            watched = self.watches[lit_index(false_literal)]
            if watched is None:
                continue
            write = 0
            read = 0
            watched_length = len(watched)
            while read < watched_length:
                cid = watched[read]
                read += 1
                if self.is_deleted(cid):
                    continue
                offset = offsets[cid]
                length = lengths[cid]
                if data[offset] == false_literal:
                    data[offset], data[offset + 1] = data[offset + 1], data[offset]
                if data[offset + 1] != false_literal:
                    watched[write] = cid
                    write += 1
                    continue
                other = data[offset]
                if self.value(other) > 0:
                    watched[write] = cid
                    write += 1
                    continue
                replacement = 2
                while replacement < length and self.value(data[offset + replacement]) < 0:
                    replacement += 1
                if replacement < length:
                    next_literal = data[offset + replacement]
                    data[offset + 1] = next_literal
                    data[offset + replacement] = false_literal
                    self.watch(next_literal).append(cid)
                    continue
                watched[write] = cid
                write += 1
                if self.value(other) < 0 or not self.enqueue(other, cid):
                    while read < watched_length:
                        watched[write] = watched[read]
                        write += 1
                        read += 1
                    del watched[write:]
                    return cid
            del watched[write:]
            if (self.propagations & 8191) == 0 and time.perf_counter() > self.deadline:
                self.aborted = True
                return -1
        return -1

    def bump_variable(self, variable):
        self.activity[variable] += self.var_inc
        if self.activity[variable] > 1e100:
            for index in range(1, self.nvars + 1):
                self.activity[index] *= 1e-100
            self.var_inc *= 1e-100
        self.heap.update(variable)

    def bump_clause(self, cid):
        if cid < self.original_clauses:
            return
        index = cid - self.original_clauses
        self.learnt_activity[index] += self.clause_inc
        if self.learnt_activity[index] > 1e20:
            self.learnt_activity = [value * 1e-20 for value in self.learnt_activity]
            self.clause_inc *= 1e-20

    def analyze(self, conflict):
        learnt = [0]
        touched = []
        path_count = 0
        pivot = 0
        trail_index = len(self.trail) - 1
        cid = conflict
        while True:
            self.bump_clause(cid)
            offset = self.cnf.offsets[cid]
            length = self.cnf.lengths[cid]
            for index in range(offset, offset + length):
                literal = self.cnf.data[index]
                if pivot and literal == pivot:
                    continue
                variable = abs(literal)
                if not self.seen[variable] and self.level[variable] > 0:
                    self.seen[variable] = True
                    touched.append(variable)
                    self.bump_variable(variable)
                    if self.level[variable] == self.decision_level:
                        path_count += 1
                    else:
                        learnt.append(literal)
            while True:
                pivot = self.trail[trail_index]
                trail_index -= 1
                if self.seen[abs(pivot)]:
                    break
            self.seen[abs(pivot)] = False
            path_count -= 1
            cid = self.reason[abs(pivot)]
            if path_count <= 0:
                break
        learnt[0] = -pivot

        for literal in learnt:
            self.seen[abs(literal)] = True
        minimized = [learnt[0]]
        for literal in learnt[1:]:
            variable = abs(literal)
            redundant = self.reason[variable] >= 0
            stack = [variable] if redundant else []
            added = []
            while redundant and stack:
                current = stack.pop()
                reason = self.reason[current]
                if reason < 0:
                    redundant = False
                    break
                offset = self.cnf.offsets[reason]
                length = self.cnf.lengths[reason]
                for index in range(offset, offset + length):
                    dependency = abs(self.cnf.data[index])
                    if dependency == current or self.level[dependency] == 0 or self.seen[dependency]:
                        continue
                    if self.reason[dependency] < 0:
                        redundant = False
                        break
                    self.seen[dependency] = True
                    added.append(dependency)
                    stack.append(dependency)
            for dependency in added:
                self.seen[dependency] = False
            if not redundant:
                minimized.append(literal)
        learnt = minimized
        for variable in touched:
            self.seen[variable] = False
        for literal in learnt:
            self.seen[abs(literal)] = False

        backtrack = 0
        if len(learnt) > 1:
            best = 1
            for index in range(2, len(learnt)):
                if self.level[abs(learnt[index])] > self.level[abs(learnt[best])]:
                    best = index
            learnt[1], learnt[best] = learnt[best], learnt[1]
            backtrack = self.level[abs(learnt[1])]
        lbd = len({self.level[abs(literal)] for literal in learnt})
        return learnt, backtrack, lbd

    def add_learnt(self, literals, lbd):
        cid = self.cnf.clause_count
        self.cnf.add(literals)
        self.learnt_deleted.append(0)
        self.learnt_activity.append(self.clause_inc)
        self.learnt_lbd.append(lbd)
        self.learnt_ids.append(cid)
        if len(literals) >= 2:
            self.watch(literals[0]).append(cid)
            self.watch(literals[1]).append(cid)
        return cid

    def backtrack(self, target_level):
        if self.decision_level <= target_level:
            return
        target_trail = self.trail_lim[0] if target_level == 0 else self.trail_lim[target_level]
        for literal in reversed(self.trail[target_trail:]):
            variable = abs(literal)
            self.assigns[variable] = 0
            self.reason[variable] = -1
            self.level[variable] = 0
            self.heap.insert(variable)
        del self.trail[target_trail:]
        self.qhead = min(self.qhead, target_trail)
        del self.trail_lim[target_level:]

    def reduce_learnts(self):
        locked = set()
        for literal in self.trail:
            reason = self.reason[abs(literal)]
            if reason >= self.original_clauses:
                locked.add(reason)
        candidates = [
            cid for cid in self.learnt_ids
            if not self.is_deleted(cid) and self.cnf.lengths[cid] > 2 and cid not in locked
        ]
        candidates.sort(key=lambda cid: (
            -self.learnt_lbd[cid - self.original_clauses],
            self.learnt_activity[cid - self.original_clauses],
        ))
        for cid in candidates[:len(candidates) // 2]:
            self.learnt_deleted[cid - self.original_clauses] = 1

    def solve(self):
        if self.inconsistent:
            return "UNSAT"
        conflict = self.propagate()
        if self.aborted:
            return "TIMEOUT"
        if conflict >= 0:
            return "UNSAT"
        restart_index = 1
        restart_limit = self.restart_base * luby(2, restart_index)
        since_restart = 0
        next_reduction = 5000
        while True:
            conflict = self.propagate()
            if self.aborted:
                return "TIMEOUT"
            if conflict >= 0:
                self.conflicts += 1
                since_restart += 1
                if self.decision_level == 0:
                    return "UNSAT"
                learnt, backtrack, lbd = self.analyze(conflict)
                self.backtrack(backtrack)
                reason = self.add_learnt(learnt, lbd)
                if not self.enqueue(learnt[0], reason):
                    return "UNSAT"
                self.var_inc *= 1.0 / 0.95
                self.clause_inc *= 1.0 / 0.999
                if self.conflicts >= next_reduction:
                    self.reduce_learnts()
                    next_reduction = self.conflicts + 5000 + self.conflicts // 20
                if since_restart >= restart_limit:
                    self.backtrack(0)
                    self.restarts += 1
                    restart_index += 1
                    restart_limit = self.restart_base * luby(2, restart_index)
                    since_restart = 0
                if (self.conflicts & 255) == 0 and time.perf_counter() > self.deadline:
                    return "TIMEOUT"
                continue
            variable = self.heap.pop()
            while variable and self.assigns[variable] != 0:
                variable = self.heap.pop()
            if not variable:
                return "SAT"
            if self.branch_mode == "group" and self.group_of[variable] >= 0:
                group = self.decision_groups[self.group_of[variable]]
                best = variable
                for candidate in group:
                    if self.assigns[candidate] == 0 and self.activity[candidate] > self.activity[best]:
                        best = candidate
                if best != variable:
                    self.heap.insert(variable)
                    self.heap.remove(best)
                    variable = best
            self.decisions += 1
            self.trail_lim.append(len(self.trail))
            if self.branch_mode == "group" and self.group_of[variable] >= 0:
                literal = variable
            else:
                literal = variable if self.phase[variable] > 0 else -variable
            self.enqueue(literal, -1)
            if (self.decisions & 4095) == 0 and time.perf_counter() > self.deadline:
                return "TIMEOUT"


def evaluate(node, assignment, table):
    if node.name is not None:
        return assignment[node.name]
    return table[evaluate(node.left, assignment, table)][evaluate(node.right, assignment, table)]


def enumerate_assignments(names, size, callback):
    assignment = {}
    count = 0

    def visit(index):
        nonlocal count
        if index == len(names):
            count += 1
            callback(assignment)
            return
        name = names[index]
        for value in range(size):
            assignment[name] = value
            visit(index + 1)

    visit(0)
    return count


def validate_countermodel(premise_text, target_text, size, table):
    factory = TermFactory()
    premise = parse_equation(premise_text, factory)
    target = parse_equation(target_text, factory)
    premise_vars = tuple(sorted(set(premise[0].variables + premise[1].variables)))
    premise_checks = 0
    premise_error = None

    def check_premise(assignment):
        nonlocal premise_checks, premise_error
        premise_checks += 1
        if premise_error is None and evaluate(premise[0], assignment, table) != evaluate(premise[1], assignment, table):
            premise_error = dict(assignment)

    enumerate_assignments(premise_vars, size, check_premise)
    if premise_error is not None:
        return {
            "valid": False, "error": "premise failure", "premise_failure": premise_error,
            "premise_assignments": premise_checks, "target_assignments": 0, "target_failures": 0,
        }
    target_vars = tuple(sorted(set(target[0].variables + target[1].variables)))
    target_checks = 0
    failures = 0
    witness = None
    witness_values = None

    def check_target(assignment):
        nonlocal target_checks, failures, witness, witness_values
        target_checks += 1
        left = evaluate(target[0], assignment, table)
        right = evaluate(target[1], assignment, table)
        if left != right:
            failures += 1
            if witness is None:
                witness = dict(assignment)
                witness_values = [left, right]

    enumerate_assignments(target_vars, size, check_target)
    return {
        "valid": witness is not None,
        "witness": witness,
        "witness_values": witness_values,
        "premise_assignments": premise_checks,
        "target_assignments": target_checks,
        "target_failures": failures,
        "error": None if witness is not None else "target never fails",
    }


def decode_vector(vector, assignments):
    selected = -1
    for value, variable in enumerate(vector):
        if assignments[variable] > 0:
            if selected >= 0:
                raise RuntimeError("non one-hot model")
            selected = value
    if selected < 0:
        raise RuntimeError("missing one-hot model value")
    return selected


def solve_fixed(premise_text, target_text, size, timeout=300.0, *, structure="none",
                witness_pattern=None, phase="negative", branch="boolean",
                restart_base=100, seed=1, fix_first_witness=True):
    started = time.perf_counter()
    deadline = started + max(0.001, float(timeout))
    try:
        factory = TermFactory()
        premise = parse_equation(premise_text, factory)
        target = parse_equation(target_text, factory)
        encoder = MagmaEncoder(
            size, deadline, fix_first_witness=fix_first_witness,
            structure=structure, witness_pattern=witness_pattern,
        )
        encoder.encode(premise, target)
        encoded_at = time.perf_counter()
        solver = CDCLSolver(encoder.cnf, deadline, {
            "phase": phase,
            "decision_variables": encoder.decision_variables,
            "decision_groups": encoder.decision_groups,
            "branch": branch,
            "restart_base": restart_base,
            "seed": seed,
        })
        status = solver.solve()
        common = {
            "size": size,
            "status": status,
            "variables": encoder.cnf.variable_count,
            "clauses": encoder.cnf.clause_count,
            "original_clauses": solver.original_clauses,
            "encoding_seconds": encoded_at - started,
            "seconds": time.perf_counter() - started,
            "conflicts": solver.conflicts,
            "decisions": solver.decisions,
            "propagations": solver.propagations,
            "restarts": solver.restarts,
            "engine": ENGINE,
            "phase": solver.phase_mode,
            "branch": solver.branch_mode,
            "structure": encoder.structure,
            "restart_base": solver.restart_base,
            "seed": solver.seed,
        }
        if status != "SAT":
            return common
        table = [
            [decode_vector(encoder.table[left][right], solver.assigns) for right in range(size)]
            for left in range(size)
        ]
        sat_witness = {
            name: decode_vector(vector, solver.assigns) for name, vector in encoder.witness.items()
        }
        validation = validate_countermodel(premise_text, target_text, size, table)
        common["status"] = "SAT" if validation["valid"] else "INVALID_MODEL"
        common["seconds"] = time.perf_counter() - started
        common["table"] = table
        common["sat_witness"] = sat_witness
        common["validation"] = validation
        return common
    except SearchTimeout:
        return {"size": size, "status": "TIMEOUT", "seconds": time.perf_counter() - started, "engine": ENGINE}
    except Exception as error:  # Keep the CLI result machine-readable.
        return {
            "size": size, "status": "ERROR", "seconds": time.perf_counter() - started,
            "engine": ENGINE, "error": "".join(traceback.format_exception(error)),
        }


def solve_portfolio(premise_text, target_text, size, timeout=300.0, *,
                    general_slice=30.0, seed=1, fix_first_witness=True):
    started = time.perf_counter()
    attempts = []

    def remaining():
        return max(0.0, timeout - (time.perf_counter() - started))

    def run(budget, **extra):
        result = solve_fixed(
            premise_text, target_text, size, min(budget, remaining()), seed=seed,
            fix_first_witness=fix_first_witness, **extra,
        )
        attempts.append({
            "status": result["status"], "seconds": result.get("seconds", 0.0),
            "structure": result.get("structure", "none"),
            "conflicts": result.get("conflicts", 0), "decisions": result.get("decisions", 0),
        })
        return result

    first_slice = min(timeout, general_slice)
    result = run(first_slice, structure="none", witness_pattern=None, branch="boolean")
    if result["status"] in ("SAT", "UNSAT", "ERROR") or remaining() <= 0:
        result["seconds"] = time.perf_counter() - started
        result["portfolio"] = attempts
        return result
    if size >= 4:
        factory = TermFactory()
        target = parse_equation(target_text, factory)
        target_vars = tuple(sorted(set(target[0].variables + target[1].variables)))
        canonical = [min(index, size - 1) for index in range(len(target_vars))]
        result = run(
            min(remaining(), max(1.0, timeout * 0.4)),
            structure="idempotent-clone", witness_pattern=canonical, branch="group",
        )
        if result["status"] == "SAT":
            result["seconds"] = time.perf_counter() - started
            result["portfolio"] = attempts
            return result
    if remaining() > 0:
        result = run(remaining(), structure="none", witness_pattern=None, branch="boolean")
    result["seconds"] = time.perf_counter() - started
    result["portfolio"] = attempts
    return result


def default_domain_budget(size, max_size, remaining):
    if size >= max_size:
        return remaining
    caps = {2: 2.0, 3: 4.0, 4: 8.0, 5: 20.0, 6: 40.0, 7: 70.0, 8: 120.0}
    return min(remaining, caps.get(size, max(2.0, remaining / max(1, max_size - size + 1))))


def solve_problem(premise_text, target_text, timeout=300.0, min_size=2, max_size=9,
                  general_slice=30.0, seed=1, fix_first_witness=True):
    # Parse before beginning domain attempts so malformed input fails immediately.
    factory = TermFactory()
    parse_equation(premise_text, factory)
    parse_equation(target_text, factory)
    if min_size < 1 or max_size < min_size:
        raise ValueError("invalid domain range")
    started = time.perf_counter()
    domain_attempts = []
    last_result = None
    for size in range(min_size, max_size + 1):
        remaining = timeout - (time.perf_counter() - started)
        if remaining <= 0:
            break
        budget = default_domain_budget(size, max_size, remaining)
        result = solve_portfolio(
            premise_text, target_text, size, budget,
            general_slice=min(general_slice, budget), seed=seed,
            fix_first_witness=fix_first_witness,
        )
        domain_attempts.append({
            "size": size, "status": result["status"], "seconds": result.get("seconds", 0.0),
            "variables": result.get("variables"), "clauses": result.get("clauses"),
            "conflicts": result.get("conflicts", 0), "structure": result.get("structure", "none"),
        })
        last_result = result
        if result["status"] == "SAT":
            result["seconds"] = time.perf_counter() - started
            result["domain_attempts"] = domain_attempts
            result["searched_automatically"] = True
            return result
        if result["status"] == "ERROR":
            break
    if last_result is None:
        last_result = {"status": "TIMEOUT", "engine": ENGINE}
    elif last_result["status"] == "UNSAT" and domain_attempts[-1]["size"] < max_size:
        last_result = {"status": "TIMEOUT", "engine": ENGINE}
    last_result["seconds"] = time.perf_counter() - started
    last_result["domain_attempts"] = domain_attempts
    last_result["searched_automatically"] = True
    if all(item["status"] == "UNSAT" for item in domain_attempts) and domain_attempts and domain_attempts[-1]["size"] == max_size:
        last_result["status"] = "UNSAT_UP_TO_MAX_SIZE"
    elif last_result.get("status") == "UNSAT":
        last_result["status"] = "TIMEOUT"
    return last_result

def _d12_cadical_formula(text):
    """Translate the Stage 2 magma glyph to cadical_baseline syntax."""

    return text.replace("◇", "*")


def _d12_record_search_metrics(metrics, result, effective_seconds):
    attempts = result.get("domain_attempts", [])
    metrics["formula_cdcl_effective_seconds"] = round(effective_seconds, 6)
    metrics["formula_cdcl_elapsed_seconds"] = round(
        float(result.get("seconds", 0.0)), 6
    )
    metrics["formula_cdcl_status"] = result.get("status", "ERROR")
    metrics["formula_cdcl_engine"] = result.get("engine", ENGINE)
    metrics["formula_cdcl_found_order"] = result.get("size")
    metrics["formula_cdcl_domain_attempts"] = len(attempts)
    metrics["formula_cdcl_domain_statuses"] = [
        f"{item.get('size')}:{item.get('status')}" for item in attempts
    ]
    metrics["formula_cdcl_conflicts"] = sum(
        int(item.get("conflicts") or 0) for item in attempts
    )


def _table_bytes():
    global _TABLE_BYTES
    if _TABLE_BYTES is None:
        raw = lzma.decompress(base64.b85decode(_TABLES_XZ_B85))
        if len(raw) != _TABLE_RAW_BYTES:
            raise ValueError("finite-model payload length drift")
        _TABLE_BYTES = raw
    return _TABLE_BYTES


def _tables():
    raw = _table_bytes()
    position = 0
    for model_index in range(_MODEL_COUNT):
        if position >= len(raw):
            raise ValueError("finite-model payload ended early")
        order = raw[position]
        end = position + 1 + order * order
        if order == 0 or end > len(raw):
            raise ValueError("invalid finite-model payload")
        flat = raw[position + 1 : end]
        if any(value >= order for value in flat):
            raise ValueError("finite-model entry outside carrier")
        yield model_index, [
            list(flat[row * order : (row + 1) * order])
            for row in range(order)
        ]
        position = end
    if position != len(raw):
        raise ValueError("finite-model payload has trailing bytes")


def _table_sha256(table):
    canonical = json.dumps(
        table, ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _countermodel(parsed_source, parsed_target, table, metrics):
    source_holds, checked, _failure = _equation_holds(parsed_source, table)
    metrics["assignments_checked"] += checked
    if not source_holds:
        return None
    target_holds, checked, failure = _equation_holds(parsed_target, table)
    metrics["assignments_checked"] += checked
    if target_holds:
        if len(table) in (4, 5):
            metrics.setdefault("_dynamic_seed_tables", []).append(table)
        return None
    return {
        "order": len(table),
        "carrier": list(range(len(table))),
        "table": table,
        "source_verified": True,
        "target_counterexample": failure,
        "validation_mode": "exhaustive_finite_table_full_scan",
    }


def _affine_parameters(table):
    order = len(table)
    constant = table[0][0]
    left = (table[1][0] - constant) % order if order > 1 else 0
    right = (table[0][1] - constant) % order if order > 1 else 0
    if all(
        table[row][column]
        == (left * row + right * column + constant) % order
        for row in range(order)
        for column in range(order)
    ):
        return left, right, constant
    return None


def _small_table_false_code(table):
    order = len(table)
    encoded = "[" + ",".join(
        "[" + ",".join(str(value) for value in row) + "]" for row in table
    ) + "]"
    return (
        "import JudgeProblem\n"
        "import JudgeDecide.DecideBang\n"
        "import JudgeFinOp.MemoFinOp\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n"
        "open MemoFinOp\n\n"
        "def submission : Goal := by\n"
        f"  let m : Magma (Fin {order}) := {{\n"
        f'    op := finOpTable "{encoded}"\n'
        "  }\n"
        f"  refine ⟨Fin {order}, m, ?_⟩\n"
        "  decideFin!\n"
    )


def _lean_term(term, variables, operation="d6Affine"):
    if type(term) is int:
        return variables[term]
    left = _lean_term(term[0], variables, operation)
    right = _lean_term(term[1], variables, operation)
    return f"{operation} ({left}) ({right})"


def _affine_false_code(table, parameters, parsed_source, parsed_target, failure):
    order = len(table)
    left, right, constant = parameters
    source_variables, source_lhs, source_rhs = parsed_source
    target_variables, target_lhs, target_rhs = parsed_target
    source_left = _lean_term(source_lhs, source_variables)
    source_right = _lean_term(source_rhs, source_variables)
    witness = failure["assignment"]
    target_arguments = " ".join(
        f"({witness[variable]} : Fin {order})" for variable in target_variables
    )
    witness_variables = {
        index: f"({witness[variable]} : Fin {order})"
        for index, variable in enumerate(target_variables)
    }
    target_left = _lean_term(target_lhs, witness_variables)
    target_right = _lean_term(target_rhs, witness_variables)
    failure_left = failure["lhs"]
    failure_right = failure["rhs"]
    return (
        "import JudgeProblem\n"
        "import Mathlib.Tactic\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n\n"
        f"abbrev d6Carrier := Fin {order}\n\n"
        f"def d6Affine (i j : Fin {order}) : Fin {order} :=\n"
        f"  ({left} : Fin {order}) * i + ({right} : Fin {order}) * j + "
        f"({constant} : Fin {order})\n\n"
        f"@[reducible] def d6Magma : Magma (Fin {order}) := "
        "{ op := d6Affine }\n\n"
        f"local instance : Magma (Fin {order}) := d6Magma\n\n"
        f"def d6Source : EquationLHS (Fin {order}) := by\n"
        f"  intro {' '.join(source_variables)}\n"
        f"  change {source_left} = {source_right}\n"
        "  apply Fin.ext\n"
        "  simp [d6Affine] <;> omega\n\n"
        f"def d6Target : ¬ EquationRHS (Fin {order}) := by\n"
        "  intro h\n"
        f"  have bad := h {target_arguments}\n"
        f"  change {target_left} = {target_right} at bad\n"
        f"  change ({failure_left} : Fin {order}) = "
        f"({failure_right} : Fin {order}) at bad\n"
        f"  exact (show ({failure_left} : Fin {order}) ≠ "
        f"({failure_right} : Fin {order}) by decide) bad\n\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        "  exact ⟨MemoFinOp.d6Carrier, MemoFinOp.d6Magma, "
        "MemoFinOp.d6Source, MemoFinOp.d6Target⟩\n"
    )


def _prime_power(order):
    for prime in (2, 3, 5, 7, 11, 13):
        value = order
        exponent = 0
        while value > 1 and value % prime == 0:
            value //= prime
            exponent += 1
        if value == 1 and exponent >= 2:
            return prime, exponent
    return None


def _vector_digits(value, prime, dimension):
    digits = []
    for _ in range(dimension):
        digits.append(value % prime)
        value //= prime
    return digits


def _vector_value(digits, prime):
    value = 0
    place = 1
    for digit in digits:
        value += digit * place
        place *= prime
    return value


def _vector_add(left, right, prime, dimension):
    return _vector_value(
        [
            (x + y) % prime
            for x, y in zip(
                _vector_digits(left, prime, dimension),
                _vector_digits(right, prime, dimension),
            )
        ],
        prime,
    )


def _vector_sub(left, right, prime, dimension):
    return _vector_value(
        [
            (x - y) % prime
            for x, y in zip(
                _vector_digits(left, prime, dimension),
                _vector_digits(right, prime, dimension),
            )
        ],
        prime,
    )


def _vector_affine_parameters(table):
    decomposition = _prime_power(len(table))
    if decomposition is None:
        return None
    prime, dimension = decomposition
    order = len(table)
    constant = table[0][0]
    left_map = [
        _vector_sub(table[value][0], constant, prime, dimension)
        for value in range(order)
    ]
    right_map = [
        _vector_sub(table[0][value], constant, prime, dimension)
        for value in range(order)
    ]
    if not all(
        table[i][j]
        == _vector_add(
            _vector_add(left_map[i], right_map[j], prime, dimension),
            constant,
            prime,
            dimension,
        )
        for i in range(order)
        for j in range(order)
    ):
        return None
    if not all(
        left_map[_vector_add(i, j, prime, dimension)]
        == _vector_add(left_map[i], left_map[j], prime, dimension)
        and right_map[_vector_add(i, j, prime, dimension)]
        == _vector_add(right_map[i], right_map[j], prime, dimension)
        for i in range(order)
        for j in range(order)
    ):
        return None
    left_columns = [
        _vector_digits(left_map[prime**index], prime, dimension)
        for index in range(dimension)
    ]
    right_columns = [
        _vector_digits(right_map[prime**index], prime, dimension)
        for index in range(dimension)
    ]
    return {
        "prime": prime,
        "dimension": dimension,
        "left_columns": left_columns,
        "right_columns": right_columns,
        "constant": _vector_digits(constant, prime, dimension),
    }


def _product_type(prime, dimension):
    result = f"Fin {prime}"
    for _ in range(dimension - 1):
        result = f"Fin {prime} × ({result})"
    return result


def _coordinate(variable, index, dimension):
    if index == dimension - 1:
        return variable + ".2" * index
    return variable + ".2" * index + ".1"


def _tuple_expression(expressions):
    result = expressions[-1]
    for expression in reversed(expressions[:-1]):
        result = f"⟨{expression}, {result}⟩"
    return result


def _linear_coordinate(variable, row, columns, prime, dimension):
    terms = []
    for column in range(dimension):
        coefficient = columns[column][row]
        if coefficient == 0:
            continue
        coordinate = _coordinate(variable, column, dimension)
        if coefficient == 1:
            terms.append(coordinate)
        else:
            terms.append(f"({coefficient} : ℕ) • {coordinate}")
    return " + ".join(terms) if terms else f"(0 : Fin {prime})"


def _vector_literal(value, prime, dimension):
    return _tuple_expression(
        [f"({digit} : Fin {prime})" for digit in _vector_digits(value, prime, dimension)]
    )


def _integer_linear_term(term, variable_count, parameters):
    dimension = parameters["dimension"]
    if type(term) is int:
        return [
            {(term, coordinate): 1} for coordinate in range(dimension)
        ]
    left = _integer_linear_term(term[0], variable_count, parameters)
    right = _integer_linear_term(term[1], variable_count, parameters)
    result = []
    for row in range(dimension):
        combined = {}
        for columns, values in (
            (parameters["left_columns"], left),
            (parameters["right_columns"], right),
        ):
            for column in range(dimension):
                multiplier = columns[column][row]
                for key, coefficient in values[column].items():
                    combined[key] = combined.get(key, 0) + multiplier * coefficient
        result.append({key: value for key, value in combined.items() if value})
    return result


def _source_zsmul_coefficients(parsed_source, parameters):
    source_variables, source_lhs, source_rhs = parsed_source
    coefficients = set()
    for term in (source_lhs, source_rhs):
        for coordinate in _integer_linear_term(
            term, len(source_variables), parameters
        ):
            coefficients.update(value for value in coordinate.values() if value > 1)
    return sorted(coefficients)


def _vector_affine_false_code(
    table, parameters, parsed_source, parsed_target, failure
):
    prime = parameters["prime"]
    dimension = parameters["dimension"]
    carrier = _product_type(prime, dimension)
    coordinates = []
    for row in range(dimension):
        left = _linear_coordinate(
            "i", row, parameters["left_columns"], prime, dimension
        )
        right = _linear_coordinate(
            "j", row, parameters["right_columns"], prime, dimension
        )
        constant = parameters["constant"][row]
        coordinates.append(f"({left}) + ({right}) + ({constant} : Fin {prime})")
    affine_body = _tuple_expression(coordinates)
    source_variables, source_lhs, source_rhs = parsed_source
    target_variables, target_lhs, target_rhs = parsed_target
    source_left = _lean_term(source_lhs, source_variables)
    source_right = _lean_term(source_rhs, source_variables)
    witness = failure["assignment"]
    target_arguments = " ".join(
        _vector_literal(witness[variable], prime, dimension)
        for variable in target_variables
    )
    witness_variables = {
        index: _vector_literal(witness[variable], prime, dimension)
        for index, variable in enumerate(target_variables)
    }
    target_left = _lean_term(target_lhs, witness_variables)
    target_right = _lean_term(target_rhs, witness_variables)
    left_digits = _vector_digits(failure["lhs"], prime, dimension)
    right_digits = _vector_digits(failure["rhs"], prime, dimension)
    different_index = next(
        index
        for index, (left, right) in enumerate(zip(left_digits, right_digits))
        if left != right
    )
    projection = _coordinate("q", different_index, dimension)
    failure_left = left_digits[different_index]
    failure_right = right_digits[different_index]
    zsmul_coefficients = _source_zsmul_coefficients(parsed_source, parameters)
    if any(coefficient % prime not in (0, 1) for coefficient in zsmul_coefficients):
        raise ValueError("vector source coefficients do not reduce to identity")
    zsmul_lemmas = "".join(
        f"theorem d6Zsmul{coefficient} (x : Fin {prime}) : "
        f"({coefficient} : ℤ) • x = "
        f"{'0' if coefficient % prime == 0 else 'x'} := by\n"
        "  fin_cases x <;> decide\n\n"
        for coefficient in zsmul_coefficients
    )
    zsmul_names = ", ".join(
        f"d6Zsmul{coefficient}" for coefficient in zsmul_coefficients
    )
    if zsmul_names:
        source_proof = (
            "  ext <;> simp [d6Affine] <;> abel_nf <;>\n"
            f"    simp only [{zsmul_names}, zero_add, add_zero]\n\n"
        )
    else:
        source_proof = "  ext <;> simp [d6Affine] <;> abel_nf\n\n"
    return (
        "import JudgeProblem\n"
        "import Mathlib.Tactic\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n\n"
        f"abbrev d6Carrier := {carrier}\n\n"
        "def d6Affine (i j : d6Carrier) : d6Carrier :=\n"
        f"  {affine_body}\n\n"
        f"{zsmul_lemmas}"
        "@[reducible] def d6Magma : Magma d6Carrier := { op := d6Affine }\n\n"
        "local instance : Magma d6Carrier := d6Magma\n\n"
        "def d6Source : EquationLHS d6Carrier := by\n"
        f"  intro {' '.join(source_variables)}\n"
        f"  change {source_left} = {source_right}\n"
        f"{source_proof}"
        "def d6Target : ¬ EquationRHS d6Carrier := by\n"
        "  intro h\n"
        f"  have bad := h {target_arguments}\n"
        f"  change {target_left} = {target_right} at bad\n"
        f"  have badCoordinate := congrArg (fun q : d6Carrier => {projection}) bad\n"
        f"  change ({failure_left} : Fin {prime}) = "
        f"({failure_right} : Fin {prime}) at badCoordinate\n"
        f"  exact (show ({failure_left} : Fin {prime}) ≠ "
        f"({failure_right} : Fin {prime}) by decide) badCoordinate\n\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        "  exact ⟨MemoFinOp.d6Carrier, MemoFinOp.d6Magma, "
        "MemoFinOp.d6Source, MemoFinOp.d6Target⟩\n"
    )


def _compact_table_false_code(table):
    order = len(table)
    alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if order > len(alphabet):
        raise ValueError("compact Base36 table only supports orders up to 36")
    encoded = "".join(alphabet[value] for row in table for value in row)
    if len(encoded) != order * order:
        raise ValueError("compact finite-table encoding length drift")
    return (
        "import JudgeProblem\n"
        "import JudgeDecide.DecideBang\n"
        "import JudgeFinOp.MemoFinOp\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n\n"
        "private def decodeBase36V2 (c : Char) : Nat :=\n"
        "  if c.isDigit then c.toNat - '0'.toNat\n"
        "  else c.toNat - 'A'.toNat + 10\n\n"
        "def base36TableV2 (s : String) (i j : Fin n) : Fin n :=\n"
        "  let vals := s.toList.map decodeBase36V2\n"
        "  let idx := i.val * n + j.val\n"
        "  ⟨(vals.getD idx 0) % n,\n"
        "    Nat.mod_lt _ (Nat.lt_of_le_of_lt (Nat.zero_le i.val) i.isLt)⟩\n\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        f"  let m : Magma (Fin {order}) := {{\n"
        f'    op := MemoFinOp.base36TableV2 "{encoded}"\n'
        "  }\n"
        f"  refine ⟨Fin {order}, m, ?_⟩\n"
        "  decideFin!\n"
    )


def _false_code(table, parsed_source, parsed_target, failure):
    order = len(table)
    if order <= 10:
        return _small_table_false_code(table), "finOpTable_single_digit_decideFin"
    parameters = _affine_parameters(table)
    if parameters is not None:
        return (
            _affine_false_code(
                table, parameters, parsed_source, parsed_target, failure
            ),
            "fin_scalar_affine_symbolic",
        )
    vector_parameters = _vector_affine_parameters(table)
    if (
        vector_parameters is not None
        and not any(vector_parameters["constant"])
        and all(
            coefficient % vector_parameters["prime"] in (0, 1)
            for coefficient in _source_zsmul_coefficients(
                parsed_source, vector_parameters
            )
        )
    ):
        return (
            _vector_affine_false_code(
                table,
                vector_parameters,
                parsed_source,
                parsed_target,
                failure,
            ),
            "fin_vector_affine_symbolic",
        )
    return _compact_table_false_code(table), "base36_compact_table_decideFin"


def _base_result(ordinal, case_id, status, stop_reason, save_mode, metrics):
    return {
        "schema_version": PROVER_SCHEMA,
        "prover_name": PROVER_NAME,
        "ordinal": ordinal,
        "id": case_id,
        "status": status,
        "stop_reason": stop_reason,
        "result_save_mode": save_mode,
        "certificate_valid": None,
        "verdict": None,
        "judge_verdict": None,
        "metrics": {key: value for key, value in metrics.items() if not key.startswith("_")},
    }


def prove(case, config):
    """Try generalized infinite source rules, then the d6 finite-model bank."""

    started = time.monotonic()
    ordinal = case.get("ordinal") if isinstance(case, dict) else None
    case_id = case.get("id") if isinstance(case, dict) else None
    save_mode = "minimal"
    previous_alarm = None
    trace = []
    metrics = {
        "architecture": "false-solver-d15-exp5-group-core-plus-d14-v1",
        "infinite_family_checks": 0,
        "model_checks": 0,
        "assignments_checked": 0,
        "oversize_certificates_skipped": 0,
        "maximum_candidate_certificate_bytes": 0,
        "stage_events": 0,
        "scalar_affine_enabled": False,
        "scalar_affine_parameter_checks": 0,
        "scalar_affine_found_order": None,
        "dynamic_enabled": False,
        "dynamic_search_seconds": 0.0,
        "formula_cdcl_enabled": False,
        "formula_cdcl_configured_seconds": 0.0,
        "formula_cdcl_effective_seconds": 0.0,
        "formula_cdcl_elapsed_seconds": 0.0,
        "formula_cdcl_status": "NOT_RUN",
        "elapsed_seconds": 0.0,
    }
    try:
        (save_mode, safety_seconds, enabled, infinite_enabled, scalar_affine_enabled,
         dynamic_enabled, dynamic_seconds, formula_cdcl_enabled,
         formula_cdcl_seconds, formula_cdcl_min_size,
         formula_cdcl_max_size) = _runtime_config(config)
        ordinal, case_id, source, target = _case_formulas(case)
        parsed_source = _parse_equation(source)
        parsed_target = _parse_equation(target)
        previous_alarm = _arm_safety_wall(safety_seconds)
        if infinite_enabled:
            metrics["infinite_family_checks"] = (_INFINITE_RULE_COUNT + 7)
            candidate = _infinite_candidate(parsed_source, parsed_target)
            if candidate is not None:
                family, code, source_recognition = candidate
                if family == _D15_EXP5_FAMILY:
                    stage = "stage0_d15_exp5_group_core"
                elif family == _D15_ACCEPTED_CM_FAMILY:
                    stage = "stage0_d15_inductive_cm_transfer"
                elif family == _D15_PATTERN_CM_FAMILY:
                    stage = "stage0_d15_pattern_cm_transfer"
                elif family == _D15_KBO_FAMILY:
                    stage = "stage0_d15_kbo_completion"
                elif family == _D15_NF_FAMILY:
                    stage = "stage0_d15_normal_form_normalization"
                else:
                    stage = "stage0_generalized_infinite_source_family"
                judge_lean, certificate_bytes = _staged_certificate(stage, code)
                metrics["maximum_candidate_certificate_bytes"] = max(
                    metrics["maximum_candidate_certificate_bytes"], certificate_bytes
                )
                if judge_lean is None:
                    metrics["oversize_certificates_skipped"] += 1
                    if save_mode == "full":
                        trace.append(
                            {
                                "seq": len(trace) + 1,
                                "stage": stage,
                                "event": "certificate_too_large",
                                "certificate_bytes": certificate_bytes,
                                "limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                            }
                        )
                else:
                    metrics["stage_events"] = 1
                    metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                    result = _base_result(
                        ordinal,
                        case_id,
                        "REFUTED",
                        "INFINITE_COUNTERMODEL_CANDIDATE",
                        save_mode,
                        metrics,
                    )
                    result.update(
                        {
                            "certificate_valid": None,
                            "certificate_kind": (
                                "d15_exp5_group_source_model"
                                if family == _D15_EXP5_FAMILY
                                else "d15_inductive_cm_source_model"
                                if family == _D15_ACCEPTED_CM_FAMILY
                                else "d15_pattern_cm_source_model"
                                if family == _D15_PATTERN_CM_FAMILY
                                else "d15_kbo_source_model"
                                if family == _D15_KBO_FAMILY
                                else "d15_normal_form_source_model"
                                if family == _D15_NF_FAMILY
                                else "generalized_infinite_source_model"
                            ),
                            "certificate_bytes": certificate_bytes,
                            "certificate_limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                            "verdict": False,
                            "judge_verdict": "false",
                            "stage": stage,
                            "countermodel": {
                                "carrier_class": "infinite",
                                "construction_family": family,
                                "recognition": source_recognition,
                                "target_index_used": False,
                                "target_validation": "target_ast_symbolic_reduction_then_constructor_nomatch_then_current_judge",
                            },
                            "judge_lean": judge_lean,
                        }
                    )
                    if save_mode == "full":
                        result["trace"] = trace + [
                            {
                                "seq": len(trace) + 1,
                                "stage": stage,
                                "event": "candidate",
                                "construction_family": family,
                                "certificate_bytes": certificate_bytes,
                            }
                        ]
                    return result
        if enabled:
            for model_index, table in _tables():
                metrics["model_checks"] += 1
                details = _countermodel(
                    parsed_source, parsed_target, table, metrics
                )
                if details is None:
                    continue
                model_sha256 = _table_sha256(table)
                metrics.pop("_dynamic_seed_tables", None)
                metrics["stage_events"] = 1
                metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                details.update(
                    {
                        "frozen_model_sha256": model_sha256,
                        "frozen_model_index": model_index,
                        "frozen_library": "unified_static_finite_bank",
                    }
                )
                stage = "stage0_unified_finite_model_full_scan"
                trace.append(
                    {
                        "seq": 1,
                        "stage": stage,
                        "event": "hit",
                        "models_scanned": metrics["model_checks"],
                        "model_index": model_index,
                        "model_sha256": model_sha256,
                    }
                )
                judge_lean, certificate_encoding = _false_code(
                    table,
                    parsed_source,
                    parsed_target,
                    details["target_counterexample"],
                )
                staged_judge_lean, certificate_bytes = _staged_certificate(
                    stage, judge_lean
                )
                metrics["maximum_candidate_certificate_bytes"] = max(
                    metrics["maximum_candidate_certificate_bytes"], certificate_bytes
                )
                if staged_judge_lean is None:
                    metrics["oversize_certificates_skipped"] += 1
                    if save_mode == "full":
                        trace.append(
                            {
                                "seq": len(trace) + 1,
                                "stage": stage,
                                "event": "certificate_too_large",
                                "model_index": model_index,
                                "certificate_bytes": certificate_bytes,
                                "limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                            }
                        )
                    continue
                details["certificate_encoding"] = certificate_encoding
                result = _base_result(
                    ordinal,
                    case_id,
                    "REFUTED",
                    "COUNTERMODEL_FOUND",
                    save_mode,
                    metrics,
                )
                result.update(
                    {
                        "certificate_valid": True,
                        "certificate_kind": "finite_magma_countermodel",
                        "certificate_bytes": certificate_bytes,
                        "certificate_limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                        "verdict": False,
                        "judge_verdict": "false",
                        "stage": stage,
                        "countermodel": details,
                        "judge_lean": staged_judge_lean,
                    }
                )
                if save_mode == "full":
                    result["trace"] = trace
                return result
        if scalar_affine_enabled:
            metrics["scalar_affine_enabled"] = True
            affine_candidate = _d14_scalar_affine_countermodel(
                parsed_source, parsed_target, metrics
            )
            if affine_candidate is not None:
                affine_table, affine_parameters = affine_candidate
                details = _countermodel(
                    parsed_source, parsed_target, affine_table, metrics
                )
                if details is None:
                    raise RuntimeError(
                        "scalar-affine table failed exhaustive d14 revalidation"
                    )
                stage = "stage0_scalar_affine_exact_enumerator"
                details.update(
                    {
                        "construction_family": "scalar_affine_prime_field",
                        "discovery_route": "scalar_affine_exact_enumerator",
                        "formula_only": True,
                        "searched_automatically": True,
                        "parameters": affine_parameters,
                    }
                )
                judge_lean, certificate_encoding = _false_code(
                    affine_table,
                    parsed_source,
                    parsed_target,
                    details["target_counterexample"],
                )
                staged_judge_lean, certificate_bytes = _staged_certificate(
                    stage, judge_lean
                )
                metrics["maximum_candidate_certificate_bytes"] = max(
                    metrics["maximum_candidate_certificate_bytes"],
                    certificate_bytes,
                )
                if staged_judge_lean is not None:
                    metrics["stage_events"] = 1
                    metrics["elapsed_seconds"] = round(
                        time.monotonic() - started, 6
                    )
                    details["certificate_encoding"] = certificate_encoding
                    result = _base_result(
                        ordinal,
                        case_id,
                        "REFUTED",
                        "SCALAR_AFFINE_COUNTERMODEL_FOUND",
                        save_mode,
                        metrics,
                    )
                    result.update(
                        {
                            "certificate_valid": True,
                            "certificate_kind": "finite_magma_countermodel",
                            "certificate_bytes": certificate_bytes,
                            "certificate_limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                            "verdict": False,
                            "judge_verdict": "false",
                            "stage": stage,
                            "countermodel": details,
                            "judge_lean": staged_judge_lean,
                        }
                    )
                    if save_mode == "full":
                        result["trace"] = trace + [
                            {
                                "seq": len(trace) + 1,
                                "stage": stage,
                                "event": "hit",
                                "order": len(affine_table),
                            }
                        ]
                    return result
                metrics["oversize_certificates_skipped"] += 1
        dynamic_seed_tables = metrics.pop("_dynamic_seed_tables", [])
        if dynamic_enabled and dynamic_seconds > 0.0:
            metrics["dynamic_enabled"] = True
            metrics["dynamic_search_seconds"] = dynamic_seconds
            dynamic_table = _d11_dynamic_countermodel(
                parsed_source,
                parsed_target,
                dynamic_seconds,
                metrics,
                dynamic_seed_tables,
            )
            if dynamic_table is not None:
                details = _countermodel(
                    parsed_source, parsed_target, dynamic_table, metrics
                )
                if details is None:
                    raise RuntimeError("dynamic table failed exhaustive revalidation")
                stage = "stage1_dynamic_fin45_model_synthesis"
                details.update(
                    {
                        "construction_family": "source_seed_neighborhood_or_cegis",
                        "dynamic_model_search": True,
                        "formula_only": True,
                    }
                )
                judge_lean, certificate_encoding = _false_code(
                    dynamic_table,
                    parsed_source,
                    parsed_target,
                    details["target_counterexample"],
                )
                staged_judge_lean, certificate_bytes = _staged_certificate(
                    stage, judge_lean
                )
                metrics["maximum_candidate_certificate_bytes"] = max(
                    metrics["maximum_candidate_certificate_bytes"], certificate_bytes
                )
                if staged_judge_lean is not None:
                    metrics["stage_events"] = 1
                    metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                    details["certificate_encoding"] = certificate_encoding
                    result = _base_result(
                        ordinal,
                        case_id,
                        "REFUTED",
                        "DYNAMIC_COUNTERMODEL_FOUND",
                        save_mode,
                        metrics,
                    )
                    result.update(
                        {
                            "certificate_valid": True,
                            "certificate_kind": "finite_magma_countermodel",
                            "certificate_bytes": certificate_bytes,
                            "certificate_limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                            "verdict": False,
                            "judge_verdict": "false",
                            "stage": stage,
                            "countermodel": details,
                            "judge_lean": staged_judge_lean,
                        }
                    )
                    if save_mode == "full":
                        result["trace"] = trace + [
                            {
                                "seq": len(trace) + 1,
                                "stage": stage,
                                "event": "hit",
                                "order": len(dynamic_table),
                            }
                        ]
                    return result
                metrics["oversize_certificates_skipped"] += 1
        if formula_cdcl_enabled and formula_cdcl_seconds > 0.0:
            metrics["formula_cdcl_enabled"] = True
            metrics["formula_cdcl_configured_seconds"] = formula_cdcl_seconds
            elapsed_before_cdcl = time.monotonic() - started
            effective_seconds = min(
                formula_cdcl_seconds,
                max(0.0, safety_seconds - elapsed_before_cdcl - 1.0),
            )
            if effective_seconds > 0.0:
                formula_result = solve_problem(
                    _d12_cadical_formula(source),
                    _d12_cadical_formula(target),
                    timeout=effective_seconds,
                    min_size=formula_cdcl_min_size,
                    max_size=formula_cdcl_max_size,
                    general_slice=min(30.0, effective_seconds),
                    seed=1,
                    fix_first_witness=True,
                )
                _d12_record_search_metrics(
                    metrics, formula_result, effective_seconds
                )
                if formula_result.get("status") == "SAT":
                    formula_table = formula_result.get("table")
                    details = _countermodel(
                        parsed_source, parsed_target, formula_table, metrics
                    )
                    if details is None:
                        raise RuntimeError(
                            "formula CDCL table failed exhaustive d12 revalidation"
                        )
                    stage = "stage2_formula_cdcl_fin2to9_model_synthesis"
                    details.update(
                        {
                            "construction_family": "formula_driven_cnf_cdcl_portfolio",
                            "dynamic_model_search": True,
                            "formula_only": True,
                            "searched_automatically": True,
                            "search_engine": formula_result.get("engine", ENGINE),
                            "search_seconds": round(
                                float(formula_result.get("seconds", 0.0)), 6
                            ),
                        }
                    )
                    judge_lean, certificate_encoding = _false_code(
                        formula_table,
                        parsed_source,
                        parsed_target,
                        details["target_counterexample"],
                    )
                    staged_judge_lean, certificate_bytes = _staged_certificate(
                        stage, judge_lean
                    )
                    metrics["maximum_candidate_certificate_bytes"] = max(
                        metrics["maximum_candidate_certificate_bytes"],
                        certificate_bytes,
                    )
                    if staged_judge_lean is not None:
                        metrics["stage_events"] = 1
                        metrics["elapsed_seconds"] = round(
                            time.monotonic() - started, 6
                        )
                        details["certificate_encoding"] = certificate_encoding
                        result = _base_result(
                            ordinal,
                            case_id,
                            "REFUTED",
                            "FORMULA_CDCL_COUNTERMODEL_FOUND",
                            save_mode,
                            metrics,
                        )
                        result.update(
                            {
                                "certificate_valid": True,
                                "certificate_kind": "finite_magma_countermodel",
                                "certificate_bytes": certificate_bytes,
                                "certificate_limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                                "verdict": False,
                                "judge_verdict": "false",
                                "stage": stage,
                                "countermodel": details,
                                "judge_lean": staged_judge_lean,
                            }
                        )
                        if save_mode == "full":
                            result["trace"] = trace + [
                                {
                                    "seq": len(trace) + 1,
                                    "stage": stage,
                                    "event": "hit",
                                    "order": len(formula_table),
                                    "engine": formula_result.get("engine", ENGINE),
                                }
                            ]
                        return result
                    metrics["oversize_certificates_skipped"] += 1
            else:
                metrics["formula_cdcl_status"] = "SKIPPED_NO_SAFETY_BUDGET"
        metrics["stage_events"] = 1
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        if save_mode == "full":
            trace.append(
                {
                    "seq": 1,
                    "stage": "stage0_unified_finite_model_full_scan",
                    "event": "miss",
                    "models_scanned": metrics["model_checks"],
                }
            )
        result = _base_result(
            ordinal, case_id, "UNKNOWN", "COUNTERMODEL_NOT_FOUND", save_mode, metrics
        )
        if save_mode == "full":
            result["trace"] = trace
        return result
    except _SafetyWallExpired:
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        result = _base_result(
            ordinal, case_id, "UNKNOWN", "SAFETY_WALL", save_mode, metrics
        )
        if save_mode == "full":
            result["trace"] = trace
        return result
    except Exception as error:
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        result = _base_result(
            ordinal, case_id, "ERROR", "PROVER_ERROR", save_mode, metrics
        )
        result.update(
            {"error_type": type(error).__name__, "diagnostic": str(error)}
        )
        return result
    finally:
        _disarm_safety_wall(previous_alarm)


def _read_message():
    line = sys.stdin.readline()
    if not line:
        raise SystemExit(0)
    return json.loads(line)


def _send_message(message):
    print(json.dumps(message, ensure_ascii=False, separators=(",", ":")), flush=True)


def _call_judge(verdict, code):
    if len(code.encode("utf-8")) > MAX_FALSE_CERTIFICATE_BYTES:
        return {"status": "rejected", "reason": "local_false_certificate_20kb_guard"}
    _send_message({"call": "judge", "verdict": verdict, "code": code})
    return _read_message()


def _d12_solo_config(infinite_enabled):
    return {
            "result_save_mode": "minimal",
            "safety_wall_seconds": 305.0,
            "use_finite_model_bank": True,
            "use_infinite_family_bank": infinite_enabled,
            "use_scalar_affine_search": True,
            "use_dynamic_model_search": True,
            "dynamic_search_seconds": 1.0,
            "use_formula_cdcl_search": True,
            "formula_cdcl_search_seconds": 300.0,
            "formula_cdcl_min_size": 2,
            "formula_cdcl_max_size": 9,
        }


def _solver_main():
    startup = _read_message()
    problem = startup["problem"]
    case = {
        "id": problem.get("id"),
        "source_formula": problem["equation1"],
        "target_formula": problem["equation2"],
    }
    result = prove(case, _d12_solo_config(True))
    if result.get("status") == "REFUTED":
        judge_result = _call_judge("false", result["judge_lean"])
        if (
            judge_result.get("status") != "accepted"
            and result.get("stage") == "stage0_generalized_infinite_source_family"
        ):
            fallback = prove(case, _d12_solo_config(False))
            if fallback.get("status") == "REFUTED":
                _call_judge("false", fallback["judge_lean"])


__all__ = ["PROVER_NAME", "PROVER_SCHEMA", "prove"]


if __name__ == "__main__":
    _solver_main()
