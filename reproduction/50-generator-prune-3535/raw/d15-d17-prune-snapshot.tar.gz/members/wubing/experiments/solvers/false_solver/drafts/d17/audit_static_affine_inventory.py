#!/usr/bin/env python3
"""Inventory inherited scalar-affine tables and audit frozen 1,195 coverage."""

from __future__ import annotations

from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import runpy
import sys
import time


HERE = Path(__file__).resolve().parent
ROOT = next(parent for parent in HERE.parents if (parent / ".git").exists())
D14 = ROOT / "members/wubing/experiments/solvers/false_solver/drafts/d14/solver.py"
D15 = ROOT / "members/wubing/experiments/solvers/false_solver/drafts/d15/solver.py"
CANDIDATE = HERE / "v97-pure-affine-search-candidate.py"
BUILD = HERE / "candidate-build.json"
RESULTS = ROOT / (
    "members/wubing/artifacts/runs/false_solver/"
    "false-solver-d14-known-false1195-candidate-regression-20260810-v2/"
    "results.jsonl"
)
OUTPUT = HERE / "static-affine-inventory.json"


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def peak_rss_mib() -> float:
    value = float(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    divisor = 1024.0 * 1024.0 if sys.platform == "darwin" else 1024.0
    return value / divisor


def main() -> int:
    started = time.perf_counter()
    d14 = runpy.run_path(str(D14), run_name="_d17_d14_static_inventory")
    d15 = runpy.run_path(str(D15), run_name="_d17_d15_static_inventory")
    payload14 = d14["_TABLES_XZ_B85"].encode("ascii")
    payload15 = d15["_TABLES_XZ_B85"].encode("ascii")
    if payload14 != payload15 or d14["_MODEL_COUNT"] != d15["_MODEL_COUNT"]:
        raise RuntimeError("d14 and d15 inherited finite-model banks differ")

    models = []
    order_counts = Counter()
    total = 0
    for model_index, table in d14["_tables"]():
        total += 1
        parameters = d14["_affine_parameters"](table)
        if parameters is None:
            continue
        model = (len(table), *parameters)
        models.append({"model_index": model_index, "model": list(model)})
        order_counts[len(table)] += 1
    if total != 10_059 or len(models) != 227:
        raise RuntimeError(f"unexpected inventory: total={total}, affine={len(models)}")
    if len({tuple(row["model"]) for row in models}) != len(models):
        raise RuntimeError("duplicate scalar-affine parameter model in static bank")

    build = json.loads(BUILD.read_text(encoding="utf-8"))
    search_moduli = set(int(value) for value in build["search_moduli"])
    static_orders = set(order_counts)
    if not static_orders <= search_moduli:
        raise RuntimeError(f"search misses static orders: {sorted(static_orders-search_moduli)}")

    candidate = load_module("v97_d17_static_inventory_candidate", CANDIDATE)
    hit_stage_counts = Counter()
    hit_modulus_counts = Counter()
    examples_by_modulus = {}
    row_count = 0
    search_seconds = 0.0
    max_query_seconds = 0.0
    with RESULTS.open(encoding="utf-8") as handle:
        for line in handle:
            row = json.loads(line)
            row_count += 1
            query_started = time.perf_counter()
            model = candidate.find_rulebook_affine_counterexample(
                row["equation1"], row["equation2"]
            )
            query_seconds = time.perf_counter() - query_started
            search_seconds += query_seconds
            max_query_seconds = max(max_query_seconds, query_seconds)
            if model is None:
                continue
            modulus = int(model[0])
            hit_stage_counts[row["d14_candidate_stage"]] += 1
            hit_modulus_counts[modulus] += 1
            examples_by_modulus.setdefault(str(modulus), {
                "equation_pair": row["equation_pair"],
                "model": list(model),
                "d14_candidate_stage": row["d14_candidate_stage"],
            })
    if row_count != 1_195:
        raise RuntimeError(f"expected 1,195 frozen rows, got {row_count}")

    result = {
        "schema_version": "false-solver-d17-static-scalar-affine-inventory-v1",
        "inherited_static_bank": {
            "d14_d15_payload_identical": True,
            "payload_sha256": hashlib.sha256(payload14).hexdigest(),
            "total_models": total,
            "scalar_affine_models": len(models),
            "unique_scalar_affine_models": len(models),
            "order_counts": {
                str(key): value for key, value in sorted(order_counts.items())
            },
            "models": models,
        },
        "pure_search_domain": {
            "moduli": build["search_moduli"],
            "covers_every_static_scalar_affine_order": True,
        },
        "frozen_known_false1195_side_audit": {
            "rows": row_count,
            "pure_scalar_affine_hits": sum(hit_stage_counts.values()),
            "hits_by_existing_d14_stage": dict(sorted(hit_stage_counts.items())),
            "hit_modulus_counts": {
                str(key): value for key, value in sorted(hit_modulus_counts.items())
            },
            "examples_by_modulus": examples_by_modulus,
            "search_seconds": round(search_seconds, 6),
            "max_query_seconds": round(max_query_seconds, 6),
        },
        "resources": {
            "elapsed_seconds": round(time.perf_counter() - started, 6),
            "peak_rss_mib": round(peak_rss_mib(), 3),
            "sequential": True,
        },
        "controls": {
            "production_solver_mutated": False,
            "remote_services_used": False,
            "judge_called": False,
            "lean_compilation_run": False,
        },
    }
    OUTPUT.write_text(
        json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "static_affine_models": len(models),
        "static_orders": sorted(static_orders),
        "known_false1195_affine_hits": sum(hit_stage_counts.values()),
        "hits_from_static_stage": hit_stage_counts[
            "stage0_unified_finite_model_full_scan"
        ],
        "search_seconds": round(search_seconds, 6),
        "peak_rss_mib": result["resources"]["peak_rss_mib"],
    }, ensure_ascii=False, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
