#!/usr/bin/env python3
"""Formula-only finite and target-symbolic infinite-model False solver runtime."""

from __future__ import annotations

import base64
import bisect
import ctypes
import gc
import hashlib
from itertools import product
import json
import lzma
import math
import os
import re
import signal
import sys
import time
import traceback
from array import array


_MODEL_COUNT = 3535
_TABLE_RAW_BYTES = 237631
_TABLES_XZ_B85 = (
    '{Wp48S^xk9=GL@E0stWa761SMbT8$j<DfppbX@=ffJFsL+nPk~Dyfy8oBnU^`xOxs;Cu9+pD|sMy@pod2(O{03a87Dctcg%Gn}r*'
    '3IA|%w{p=4I@Uh~L;BT@fGIwONXI2n>_L|APy<oUV|fXXf7X3#(~Npo$BAz2nyxtajHRtWgyGQI)3+D1ewPfmay~cYKvZAeQ|A`N'
    '%S<6{7s-9O)y8U{K*8p#Xyzci(dGuglnx&P6ss6VM#+s^ejBM-0xYdg)}nyS1u#@Y#HM(;eZ+lz3SxO0t?ggHV)Z?{dE#dRB|fHv'
    'DulppXm<W(51e}*{+ds%Cu%P`y(oq#Fvtr0we3)}RWB&M$V}n2Lqh~p^gnEh>4_x4QxCkT_hDDus;M=~3`*F+da#pJDPpB^_YVmH'
    '@=g%bjNLcSnB%CbWQ-WtBK}pd<1x;KK(E30=Y+l58!-?>GPY1_cx<10^?c`Mj??AyPn8A#)Y9D(V@ydLl4J;<P@zd2-<<41`P8(4'
    'Wsl*(l_yFS4Jnm8=B8pfA|z69+nrj*bjz|>Urd4TT`Cc@|D|t*Bk#iukCg;N<Sz8a5qVJH1mIT>HyLAl=mRQSe;>x8By|Z}CC)nU'
    '%vB}nAc4Q)gTY3`zR>On4>Xwr<*)R~<0^AYoGn;Bk@B7Kg%pti1{oDLzfoNj8-~mn#@!MH5|VJ5D?mxO+>=F*s(34j;T`>Yq^;|B'
    'I0mX`ZfbSgs~*B>-Sw~vHdbfS(lS{&1%E8D4@8O)c%c!@ewMCy8Zv1%=n{u>3iXkge2N<{Z~tEb1&Y|0_G9O9z?lTw&6wM9*c5;o'
    'vlIv62PjsImp>Y)_eLc0PM<cX`7)N_%bH)uI<2a#n6XXk)~Q#rUx<oib+_(O=f4LvfiC?83Ze*wzKew>k?UdgY4GXMb6@R1`0)=z'
    '&(QRlY17b*=~adnd6$Dh^RDg-G|9q~>H!8SQB<QdQ$LN@Y~Xtf@wWP!=nYb|e?ij$#gtTP`9_{~ZU1E;^#^tq6Kkn&hc$s=fe18P'
    'F^Xp@?xJXf4Q>56z_uvSw?pc8f)aY472=ZqqtyjKLwLKVK;{PHQ3;QftE9QO?0eO~mg4O(T|n&1VG^vylTM{w_h0FX3cLi@yGbGi'
    '&%{%$HXViE7krX+2GaO`>UxPpEccvk&N~-DX|DWj%i1e^&^H5vki8q)CCI_kJ)E4kpo?aXtB8z08q<$Z(a>_c_@kOm+Cr_6Xb^P&'
    '!(<P*l#HG5J3elwgKGVVjO-09O+@f4KlZR<x87!+6OrBeiABNb99w6_5^R`gq&aD@!GgUHR)2-mJpO%w4c8K-H`9+p<Zh!h1*xK)'
    '87342T4}(6+(kGp%_`}c(xK`Y!JEH0p=M2lODR<r1K1u<ji8NwKhP_e@04+y;G+)v2_w<KfNo`FAAq96HPq8zrM+n5;kU~=*U=ds'
    '_9QIJJ{^UOXu*be?YwjT4qB?NuV&1eYOVcL0xzG{TP@=Y3}k1(0B;N%A-N4(4=iWEw$>5IzGk<X3)qMG)&Bo8e${Ww#<%|()?**V'
    'xGCD`;Ya19q0RAGuTOg+>(5CFJ&gY(ji}4QrCI*clRbc1_B?iQJ?@zqqYJtF2zH6<JV+3p67Y|xBKL0X+L6S?3S%fH-gO(qJl^`r'
    'bv`+ptKknLVZ(m%UbG&jL1T^anqczFe=FOAp>R_{XC`2W4}kg*^H{5@^bc0!=*$7&0#QNKg*Pr0Nc;UQteUh6J_0UM)z*K~of}gu'
    'LWS@`57zwmz!DGF$T2$EGwDz73d}_DVZCS|ATB$lc)Yx+PhAJJ)b+YC7JS#)DIVdLs0UESB~3()bV`u7A=#3Hq&3;z#v4tw*MB-#'
    'x88C$0)$73E`mWavP6{7qz|6FkK5In;w(ie{u%T-@>qd6&tPA1-Z-@)PO>Aftf(D8RTNTCVNOy?%Ggx2ggH)l@Z)%naTDoP%oIL^'
    '{uk!OK>Ky0@lF(v_f2!0kw%w^a&c&vGOgp_iL?=xBWA-6kUXt#+51LM2x3PoV_@uJ@I5{(W4lR*l8^K(vKe6KepkB~m213h0aNTj'
    'kl57q+H~3FqQO~+NB1fF+(pOvo;$qDD&`VvMf@q*hptlg?nNpoyg)V927g^3e;uN`)^I#-!3H@Y0BZ1s9=Xy{ce7lL?(HF?VG=ZE'
    'Wx$ot6s&ACd;0Lx#n2!<Kv?C#X!m<4)D&o7q^Hgv#ujH@=iJTBbl89NIXsQ!CY4ZP@v&^4jy!p<QjSx+>QM(HTrh3(Q{MGZ`P^^;'
    'UfmHLv=gwEN96gIk}h0dUbrxt9o8nBua+0V0oLsO%!$tXo(eU`78M@ci-VfORGkSaRwqJ%=H&kv_S$nL4zIM{mauZi9=OB_^Q#0z'
    'ueZ0S{9r_K>;wJCR+hHPYK`7vfI%bE9M;1_cCiV~Bt-H4rd=nS-f+_~%Enn@#~H_n;^CDp%~>(|^Lu20RpBuQ3IqG3`XgQJYS^T*'
    '8^5a&{5VA*?A>^9PyySy2j@tVpuKSshK<|S>k9;(t|$3=@(}5yz{$1WeHCk7e8TJGcM?=$gl8KpT5-nAkmg{V7n90aUDXJo)-6|r'
    'WUO~Sg0c(3KVPn*<J4OL2dz2Wjh*!YUXB~TKL!OqO2iZ8Y<eyV_6rW|JVT?5H@UhwFYpNIP47jqW1jnz0gQ4B4V6=#VF^Nq9RnJS'
    'XuGR@vb)^BoUnxesO=$6O?99c89%c_O>x!C8P(|0&E&7}9LtVs^94p3*=bGh6sc<>R<zF7TM0bPB1i;0L%@C+lC{kl?y7cn$p>TR'
    'LU!008Q193?8V}IfRUe7K+Ut^1cxS;1{b}#KK!<2UP#0ixs|+5f#c^=7NQ}3nh)Ev4W>QlF#Pl|yTHOBmk@5qWibcb3NU?<ig)zE'
    '=av)^gfahxfH+*9sKBmd!eNIb3vBSmtJd1_Jrqm7$dAB<m5Vj{S$(aVsor3X{)Cu{>ms?M(D9zd-k;z{AaKZ%@-2c}F?3vL0*8&l'
    'Q|TzX{GaOa(j1r?*TkT(Bxs3)o1jq*CGuXFbeLv&Fj|D>)Tb;~K~+Zzvrr^Z9869B7}*kFhALz?x~yaq+h#!p{2IxvBFm_MoJT<!'
    '*nqoI(F)2W2Uu9PLk3?oxM_4Dn2DTy6=sc=yMc|yz?<}+T;+=cxR@>Q)!%-cq`=(HAjILthE39MbBe4vpRD7m`+Dltx_=i$v7<GT'
    'tu*kfmbqr6#q>_fri9gfYyNmLEkB%JPjAkK{WLql&@beyhS^XUq@5KmIzh3_SC^EVbBgp1_W-6LudETdUy8$O`TqH^<LzOANV6uf'
    'sY0bUVcGV67k4L6CZ4>az>YzYmLaoqPOgFLAAuTImWOP}M7fuj15Pilo~P@(C*<ujpPX=XYzmi&GCJsNkLK~+Dgx*O6_8<04d7{R'
    'eQl{+!`#5p0^KeOH*dufV$spy(~f5AUa?9ZK*}&M7Pew3vP)@rj>OOt)}aRDQS&}M`&2V|(J*K7L^{Ur&+yl6ZGH7n*;<N9!SqQ7'
    'nq`kf&G$vXJ$O=67M-AR%fwVQURN~iG+g6RX9Wd8$q59d6t(Iwucf^99J{ANySb8y2aynlYK*=07nw{E#QbbVhOEG+*=aKa>rRFs'
    '){6Lf#Hl|7euLv8FH^5*6-}Md(%s}fwc?yuOwnpl^oHdQoF|P0)hXO~DoDXm!;KJ}Jgj01xjvj@&Yt`kUrDcZk#its6sY9$T$)(m'
    '!@L(v!BGuUJvIX+Mi3c?K?v!|<oFVxNnqS19e<jR=x5&}@(DZ;1Cj<Rvw`4dTgJl~jExh&vN^EY<d|G%q`{7AAX+~K7F7j+C)?lx'
    '_CT(*es@IKSP8xSS-8Tj`!oX04H=%U4>X}i{j<xzZ(74vVHv)o=pFPe40-91zHf?vNO68&@h=3Hp|0IB1LdR?3kc8ja<Ra^+=^QY'
    'X|`$&KxDX^KQXA#yoUL*d3%d^9s$9kIyeY<soRPLT3A}`=5X<C!4ZR*FGY^hKYSMeEi{4n=eWZSIyWd=5gYBMJ(@zZ3c{9$6lU07'
    'tn2isDhQ4x0VxM#%Q~2{EiVK({ek(m{fo`{UVVj{p;KRm;n)^OEnjVu=A}PGRda2B`*b*=M)VP6219$+6rURS{RK7K!w#};{s;}0'
    'bX8VrkQK8{v(Z<|i|b)urIz6?34we6OtaWi5ku{BSJoVB{yuDpJe`N#4l!bNb@bNrd19u?w><PkUgdd<>wN2rE>ZK}eFjGEz<EM@'
    'mRD#kZe`~JDtkYxAtj}QD8cs-eXObfu6{VAE{$L87Oe3!`)4myV$>0%CI1l|*vvsz;BOYcRXlWcT`*7vc<@}$jI0(HBTlU;D465^'
    '#)jI~{fmv420S+K*!@rN2^+`{{(7Det|$UOIu!R4^%D(uzbW=YdEdQ-0ke4{>I)(cgx`w0_-sG)!uC5NH?5kxI#6<6H}l9O*PgW2'
    '+?Bw#qp#_n^}8GTh5k*ZT<WXP-mmfCDPx`d4%^~MuM!&>Y{_vxF=-s-$1SPI4a5`&$f7Ait^ra@JKG0R<G5QUT+1F~#hOVFa3kO6'
    '<0d-{p}u!;!W9qT8Et}oBLtZel3$?C#L^(<Ti6sd{P*X{BcvdLe>@PIrRhrq9v4F@wn8*jRgX^=mLNCT+1<XcF9)1;GZ3svv&Edc'
    'uEC$A2ydzppPec>1!mgIhZi+za|nKYyA@HFvM8gjN%7Jl4=5{2n1t+m)jbW6po@YO;_g4YWyTr@Y*0P~4kJ$ssqDtRtQazMS+KQB'
    'W|VnrKkoZ<${cr4$f`IlOPr-fz%szWNz=-iErPuCR+6ZQ7`+J2`K=xpF)z<3#I4vrc6J%*QdkVT^+*D2hyM_~w^?jZ69H|W(MqX)'
    'B?9!{9*n2bVqEPRr)SF?QBzXg!lkJ0#YW;2i54M#%XOa%BAzZl-)A<7A*QQ-XS!-O*0Z1LdZ9qs+vk4XRYj|}`E9vBo9dWB$YfXR'
    'cU5EVjcttn`&^6m|H+VbY>0Phg$H5ufzbJkAN8~F+jkw}9Nal=R3Bj#4YNQ$B{NeR0mvcs(Y=mt5LT6$mNWXpPD#=;!<&-r1yDXd'
    '(?1as{hjjOE!K{Kwh9{rEZT_*$Gp*Qz;a~&ooC7=QcK8s%x&|EaDo=Z+|9Kn=7U!wT3`7z5kUEkJyZl<bd+wJ0i88eYKzLZFl89G'
    'TxkjBZG0NJl0#5gON1Cq;?6v+)a-y(Z;_$9v$SB3ME!?X&n!X?wIv?_hCMGs3r+ssa&@fCCtyJ6Ibrq2Y}UT3x~)^vnQ2>&Ns~`{'
    ')5vXqVQ6Al9M`3Zo|sLXM>}8dCs_Y1y5V|{@Y93ZS+T?|Y#c+nymr~~u2$zeF!Xh6G@IOaF1{Tsetp7I&C1YR-&{_mS~s%~Cxn&R'
    'T|t9@M-}es3}un9Bs2=L-U!~`gQyECcNS{2V7nNUdU>ho33x%Q3-i0VPbhpcLrzNu2lR&(V4fX~r2OXh*fd7lrO5=IMV>_WNINJs'
    '<|w-(Zg1mm?!GEe3pnD#QhdYICSA%Ps@>%d^Q`$s_KKg$XLT1CTQ%0g-&_LF$MA<A3xy8`{_LhF{Cve9pjQB5qxpl7%i|b+t1v)<'
    '0~3Y!WHSQI+`{qQC>8G39(plgh@!>IrnQC(7|2TyBn-?d^N0WpzU^>wma!TnRGMlqipujQM#Cy0MY7RU<21M;QHYVU|GU4g)O=Fj'
    'u+`v=5x$vPP*9-{%AknJ<8E|X>4gnzI>u~R9_N$@JBs~Sv{6ro;gVXwKjdp-cm%E6cZ1eIH#TFIs3Q>|#SxSIPb=$-K>>?JTmcjk'
    '$tg6F;|JF_!;s4o+zxUN=&pAA0Jj%=@a40bs5Pqn7`EbDUn!)0Ok0+2F@Y+tD{M3H<Rc`*A4A*)M42PQf=sy@!!oRIH^4czuQzP1'
    '+&ECR*(g*@M9EW_IugW2Q(GUk@5zi;p`YAmx>hC|I3B_EAz`#;xn65ifOM+SlvtbgBoNl#XbG8vb!cFAi#lz>T?)(GB7TK;jMJsE'
    '7xZt=r8r}TnI#4IGLHN7&IyI^<uzNpJKjom1kcr9v>8FO5jn|0*mK1|msK(co}I#AkF_f$>>EJy2SZJV^D~-jsX5Pp3n!p=SYfbt'
    'C1jyv`{+nwjjal3rOw6`01z^%n_6!z@h!6dY&uCHK#hkbP!j|h96FUO=iYbJbh~~D*D*gwuj%P4hZ8^2<%Z(7I~>!_7r@HAd!v@v'
    'I_&rcp7m(i5nT>u$5K|Qdz@XeUDx%4Or5Ft(u7+fFEOWu{c);uyxZTO)Mse&+EHnI=Fj!byZo0Mt~l^xH1@o-0rJ1LR4$iL7dtPL'
    'MjT&20gqx~U5N5oi==$yPI3CR!7M`Z#)N=H`E-#8Repad;*ckLSi^W>uYaxPeE}$TLLV7++H&ZnvlnM+*qjQLPSkIA-teW{Jk;|R'
    'QKRfnq&t-lPxbPd-dSxL)cq1VaKf?r<hPC8`npe|$%$HB7}QA!N+K5+cUtW%PZu<L0#|dsu;>o94^y4f!C4DEbg;erH_Ns9Je%o+'
    '8KjcnD<g`15*Z1N5xF+Eg6)#3M$a<Bh&lJL<OMVGR?9*y$oi~FR@~w&F<CM!0_ZZ=A}UA11RMNBl6SMh;g4!YWK?Lplmj`#;^Ozi'
    'A0ooGd*=z4@Ndrb@1Ct>+)ViYqQaFdtLK*Hxa4_QqVE$tf7Zj&S7uxW@0aolGXxc$W9v&JC%+b=r^w|xH^i63Yo?$hB{<H~vRMLW'
    'g6>rENnq3V9$i8JDnz5f_wcj3wA?YZvE<v8nwP;+g%(R=@Jq!-{-TO*QRG{7wK==zSNJQn9EP~glqh3~&<u#^tzX=l72C%w3@I+L'
    '{cEWZ?h1ql?g|DU#)Qvv_ut$iO@M%SE*Vp{9$T0yKV;#>u0lBWlTx3<z&{qZowR*OuVnHPE@t@|H-PK%LR}S36$>T+M<>>*O}51g'
    '1A-&}s{5uYa3dn@K`AZ%5j@J-W;?&!qMs`G2Nxda%fdT&x|}+TQ|6G=%~(dnZ7L5}+_Nc2({&&FSvG1uUZO)Rag)Lvf0;4X8i}Wh'
    ';k4D#DkknS-j@jU=g-SPfqJ$tMoRW8d3O`8820z|gcvUb%<AvtCW`<~7%O9b`B=(Mnr2QM_&(WPkS^)Fk+j)NO_IoeqTp|lq^J=J'
    'IbD9^ENr6j52-2~)5{=(SFn^XN<e)ju&bB79XyV-2#A80o^MDz?jH;oJE9!`^WICE%O1%Jj=#fl+T9Eq&yIj6QY3Dixqx#XT})F;'
    'nbI1!`7A&&T0L?%&|D<4?pUgj{9zEb{h=zKa@K?a1=yxX`Nje-K~(U4>zV?y=@EZN&s~c#7dD!Wrmi*>f!c)GWc^xp`C;tZ>?_*2'
    '1^sh{rFar3zEV@;-!Q@Sjk}SpP6RTk*-|-vsFl*T+V5@MD5=Nc*al)?4`&|R|ENZK*U9-Otg}l3WangKdnGx^g(cX)G_Fsh+}_Bo'
    'wrFfl@FQISyAFP7tO@ZiN9fnA|NQ#4f6{9MS|082s)a0fsn|6ypI^br&?P|>^VM^Eni}zZKktJA@T)zS2;V*Yj8i}P)lEO!)O#fk'
    ')1u{-nl|oB>;%;umlEZ$b$;WY#lEssa|P2*#iXpeb+N^rCgd6+N!Op4lbBC_I~fmdw96M-T>9L&V4N9Og2Y1*9c79T!!Sj*yNpc`'
    'tJ|ZzoufEaS|Oj+p3z%`t=bY)m~X3X@w`qICxnXpYvKyL4ghzn!+c5;!f*N0RPw<(GxFeh2(9kbyj}Y${;_m0EF!6NZ&u#~mB<Y{'
    '@gM*>8X8Rz@v@)WI%hjCc2D1@2MUb!`su%H;80Jr;L(0&1lo2B1i#->Sm^1lnPNG?6zXlpWnp7GIB`8Hf@;Z?_e{^UHhL>q2F9`u'
    '<p)1=L`Io<j|tAGCY|XDxYPH8>*e+0QCMARvOx3V7c(NCP$9`9Xa4>bl$bAh;{#paK6C2{cdb-((mi8P#7cbBGrIo?{6@r|^7(0='
    'm}qmSP!kS9<=Uh#Xf{1879xlEk|ew$caul4IM@lDli{t)Im{=JrX;kq?zjs&==S^Ky5$T>wgCcLws<vFr;TK?slT%SH5uODI0|4X'
    'clH|cjU5<@VJ!h^v2*9oQHEW;2EZGTcQo(6bbm4=xN-Pc;$=eL8#-^I!LF<MlM1FXlfvgk6k4x3Q{$V7f~Y36unOS5wNE<<Umjcl'
    '&wjh+cfEyTGD&Z^Hh3JSk)n4f{2PtlA~od!&Ms?!_PgmufgGRFBL3E$X{ue{4{w*I@^T0Ib|%ZF8eSxV`BLa^HO$!kFl}mx{BN=k'
    'aEmD#8B9ct!h@cBd>35o1^lGLM2xc1)b8iKsmnu0#qVGAWaW)cucjAd+c&wVk+3Ga&A?>)=6wIV>Dlr*tmL2*T>(v9$A~69ko-+1'
    'bR6x>7&L*03V;uvBBcs@%b34?Tg0$tLb{8?zmuKrhVX95T}~EnCOjhLC6k-Fi$y?mE_BnjdNxO9%mwjFE^kAw>?4j{v~Nb4P8X!8'
    '0v=8OKth(d%Wzt2D<hF290lH>l^=JO%OEYgv+0}4hEN5bwv5zI@^QL}Un%r70N0C1UJ-2#Jt2U%Q!e(pzG-gzba$Do{grX8mC;ro'
    'e6FDJmnIgU7;Si43QQ+21ev7CBzg@M#3ieK8#>N;AINTreb>}5nqXXoU(k<4V+f#58>Rk4@m6M<fG)v!<(5WHA{}2owwa)G4{jP?'
    ')o)zfkU=hr-|jSL)qld4)YBGUL>|}P{%FB-lk^`5)<Gz8G(!h}NH(%3h@APlAOF`NsO5>a8Jmj;06=#ZcchBLy)v<vqMXz9baC(<'
    'gDRTn3aWVaf8RodM?u}1M59o~DRZdl+o#Lpsf~VIcS22KVbnUXrNcp04z-U5s>X@0c4Qj68ozv}28h1B@UIynSsg_2;H7==9-=Ia'
    'sZ{Ca5@F#b*ec-^<31X-6z9(p)@LwHpJgjboE+(s%?vUPH;$P#`*9Z|%Z-`JC5^Jgsm%NlpP`T8mp!pNpWW@r#iHNB-AIwqp`ZSh'
    '4Rt^(F*+PYA^DLtcg{7Ts{2fX^Q>RA!%6(d$6>TadPmupln1nX-hhonD>Yvybx_1mQtUiItp8+8CuT6|9)Fc0PeO3_t>)sz$g-Pk'
    'fcUGjB`*~8=3B;)<D%BK_FUm_)O#w5zTsVqEbk@=8~lbh1xC%{s_2{l{!;|`(9*aRus8<r3=E0e=uB~0T=WJv!CFVBVRNZ2V3rKE'
    'g*5tsfbzj%9yt%DCa@HhPjf(Ol6#?3YUwQ5vBW-fHb>Qs-QQxYNHC<(qDeJ&U+qiW;W<hXIzt;_4V~){qD9N{lBISOPp-mE<rLDH'
    'tIbC1dU))_0wgMi{nA~HUjS(Ke^E#x<%H^J`Ho-u=;C~}{CTRK@-my{>1A|JrUkHtpe4T&^ehH>wZMqEnFSl8b`oG34}(XDc{f)2'
    'QK648++@t254Wr?>@bf7)G9nU#*(BM55eCnF{oQ(eR{InR*0B@5jQPar(9C(0DGIbw(&YGH{=CyTqw&U4$B~R*+BCWQbL9Z4Dw;E'
    'BouJVgLR1Eji*VjP`O^U3#3K-i6uvmZK!T_7E+C>SY>&4x2Hp`-s8MHv=X@Oxi+0@xLibH{Pubf<-Vgis<37)9-G+n`yaB2WS-N;'
    'cl(OhHdB!bDw2nZiPsr=Q^t^=t4hnluuK9DJsAG#6zTcoXsLLb>emksNr~Vm7iK_dYzapq8Y?*bDjMWl%K#xTOt@VtuCI<uX1aZ#'
    '30z^VpW><VCLBH@=GmXpB}C9u1=`GCy9z{Wk3MMij)*wPWNYcOT~7L4;7wr$H|B-4JR@LB-%V&OkQ{KIZZh3*8I#l!A>L1pW>JJW'
    'FW@J-ZK%c}gqfr0Q@9(v9?;aUIj@-ua87YwpY+Vc8N1EyTL$pUujdY-;-!M-JQB;)ya8?r^c|m@s6mePW`zF~W>fC9S&NDp)4TGy'
    'ZMx;Y#(Sp-tSZaB&fKV-W@TLCcH*bbK5}s&O2OzT(!%Hw2&lZbd6*W(3q^reg)}ozm-XP#2Pf^YgCn7x>Tz=%8&*jOZKHL-_^Ybj'
    '7#ii@aXlJ#dvaz@VmHLs_~SP+3NmAh7sIyB8JAFbqAzsR2kn|tNu(X43S!LBDhJ!X1Bb~ey<#-7q~c$k{|3#_g9Lp8ZM;SYsxfBk'
    '(`L~iE^X$d)#~p?kF|BO=I#>T=1&eW{Fq{CE}q0Irt&=#C@M8IK8z^+9H$??Ol9Zg`q<RrGj6mQ2yaqF5k6D<%FtZf@qGh|P|*V<'
    'WYcuHH4*04f*0XSHZcOV?Lbc_fec~dB|U^GzgSD$&PH!rJFt=VZNt=h&QAb#?o2wPZn(`gIlPbZ33gqr%d<Iy&yfp_fAh<Cm|B}a'
    'ueI0XSk{$YkZ=H&oOm4=G-L$$_f}8Q*LV169Qul)6TA~BZ9;5(ez!2ng-p^2LGOZutU8<_louMML<2&}@R22ucap8SDdf{X$spS+'
    '2A=h`=n~$C7JHo6cqH-tYzDVoEV`}ToX;ELHTGV1lY=$Y1a0qvq8N}YE_eUgD_F+~hN0tOg)dXaL!3!`s|TlUQQT~p^0I3?!-3j)'
    'J|Y!yX-8Fy&E5o%foE)GnuxNG_Nfp&eo0^4O1RC)>|`)ojY{m5Bw_YB{np&DW=8fhOZHkHiXl=`6H$CYW9xSuSBEQ!Slalo7{DjW'
    'd#2-LV+rz=Pbn{D!$d_^VRU3hrGxsw{tVrU>0F5|w$Mf+`j18H`x!)hm2yI+Kok(3Iq=+oe1B(nZ5qM0LZV4zB@pb9Im(!58>F|w'
    '2a@+@(ojZ?l7}xT^1KCs=QhoV#-^66uz<(|-!N;+Ca3+c9$l?9i}O-B-q3?Wo|N#R3M=xuYkP|6W$IO^QA|&Aer(x~**NHS{s_X;'
    '?`M+NyncotG=&@WQnej%YIrjk5nQ=BDb4%#9)&!)Srfn{(p!^0M4cY~B`Zg22RE0ealDwH|NiEibZ7lxf$#P0=X+_tzpVz?+6DX5'
    'XKzfBB>Q_QGvIMzwOGzMvOapxKtE!wCqIgl_(DSC`s1sZ*VFU(xLb!Q%i)ES^2A*K-uE!q1EcpWYogGFPMfBnect!DLu_+Ik$Mna'
    'T%EC1QCHdt-q-8W#B>_)Bs%Q_>~{W+HGyMyH340L-&kOWBvm`JZr(RMUNwA)LBAPKcu@uR1YDzbs--nErF9D#Yi|k8W?(F^=obW^'
    '1X~mv+j&FmD$|D1Y8{sN;t`*5?4UJ{fYX7X*rZS~+prjj{02!<d4yUMS$$so1{>H*0=(l3&n%+}x{sE2xR@rar`_mFRcH>+aSWmV'
    '-g}3<ozx1-+Rv~{?{$OKhP^4!P<e4%e6xnz><vN#n=676JB||PtvAzoXYf3l+oR(_T;q)LC&68*m8vQlZt%rXCt=~hkE9*xB`-`|'
    'gm`cy+(Wi~7Sq~6c$R@!6ybAi*b<HvnK?gzjGrBsO;<sR{Y!B>6g7QK<U^A583kwkA-$KaF}k#*hdBUZt{4bdUWSl`rgo=6v_f+n'
    'JrG0{f`VHW)T}2@T~JpHF*slUeT+4*r?k|%#FshseKr~ms9(WHd<W`5@-^!DfBaj8TE6}iLg|PcfCMgxY?0SgwdSs=f~If0!c_+o'
    'xvl&A(0W~VGwmpAf)KRWIkvCqIy;sNFHN9>?1O~D=S$z0@wB<hk8m5_)c58)fG{(M2q8u3%Z7S1$Thw=&zXqeNhy=mqT$Ic_F(!>'
    'sc-YCV%h*Zsi5#k*j9Oy3mSswwj$2tpiovnjUMOB<b-qC={_<>gQ@SE0LyUEWeCw_<^{U1eSO=&7SV4dvOVx=M1PG_KUcBW4^Zvq'
    '8y{j1#g+5=LxrN=czIL5;Q(f35TukpXUQGQT9%wsyZG=X%w4gSNpGgA?9Lpv!cN@t4~p2qsloqA@$0<>8@+*rMra04*JwbGM#?4a'
    '%TfNMPqD%#vnRDD`gvL;>5G^nfUW49$?jhUN6(yJb&zfVVPUd=tTC)8R68bBLOM)cqn6Ol53qU5JsFs+uoRy0{+rH>TWh<4=cfS('
    'SZ3IM_QGDjal$B%!pW(fJPW7OW9zvB{Tq5VjxW<~4KK}W>Lr)hntQleK)%{Ia(<1%*o7SpLK#Gb<2TC&Rmj6F_`Ud?!_?k@&~wUj'
    '5RsU=bf5?|F8$V2=bI5N*#hF`aFJf~*ED4Gd+xWsR*0`2fF&ZkeEc&{WXOt~hqhe^B+t0Z96tC0PUn=vD>rw<lWwsw7PaG{WKO+P'
    '<t8-zSy~Ge(&>aYb9y$v+&7ni@}f$9|CI4_^S!GsQZPCyhk@PW{N?+2l&oRd7e%Ib_t#`?>`UFQ2&`^&!Szhz`S?#n1^Olr|8$-I'
    'kboekSR+@I2L^wanxP$ozi<1id=;qY4t;v<e1}UVH(@sZQ@H%Lfb9Eg1xBJ@=(iH&f)LrzT~xfU25TkED=5C4SgM7;9qCw$8>On|'
    '+%L>I1a?iRwqw5G7X7Pzc`8VPeC%X@Cig#kEdj**csy5|BXL>F2=o`#m}G~6;xJ!6SxkTQ{SG4uK-j5F<CAdTjW|p53fQ#$2KTts'
    '7N;;5ozCgrn`uhiZMareFRh1d_L4Zpw5vDG!}C`BG75mt3f4g$pc<L>HuME3weR4K?N}_%ZuMPx^yjZjoLBb8u_$=xKjk*U=J1BU'
    '25ljt|MlXJ>0<Hb04`BTT$jt;HCH*eF3i|owu3*5!Vf+^kv(qeRkc{Q6ODbvFa|NyHQTE38Zy|HjbALVB?6EMWP!5kXE0vdI0x>8'
    '&PKiy2xy@VeN4waMQh{!_VZW`aoncN%P?RpD23ilc;P!U<a`{>Ov+cSmh76iOhESU!vg@PA1Da`sYf$DqgKN@fJ9){D6k7rl%{j}'
    'nL=lrPV)EPE1(KprxJzkE8#)OKXo0^tPSKcj{dBIW0Pzb_j#}3G+C(}Rp+54s_N*od7?U5kEoDZ&B3v_NUV<P@ZthE5K%N?>d8vV'
    'v_^?9BLI`J1<yRTlZ&_f?OmqMEHOM^L0@3{irAPY{WF$u=Rlx=LTqZy*;sp23VI)DRq6%;T|?7zTdav!q<Fc{QgX|4&OW3r{o%;R'
    'OWiNhQIVmvy70xp2%|OSGCrGgV}YC^9gY`A>z%b}#24o-Nf5{W#m`82>Bvr}sV+Vk5Bmz<k2rzvr`8!HUQsi)TWux)AjOFnL&~;F'
    'm(6SdhDPd%#JqV!Yu{Uz_RpF%a+CL7Y06LR1YOeSy=E9T$BOa>lIv6m8=L0`=k!b<y<8(#N#SF5K^Vwz%&q$n?NhD>r8=&S9AO4P'
    '{tv{`XM!m#JUkAfT{DhiWKYXPc4<thxc-_K96j7{F0e@`0=U&`=#`5zaNIdX-?qE|4A0%u2@cSrJe`{*85P-BS%OATjOoW*t7{ih'
    'Uj@?U#bIeLON|Bn7n!77diOvUJ%c?f9vzJ0b58kCfK7R!6p@(g<;LN_YOYp>#gVj)vFZ}$YJ9KmANQGT`gRAEvtkIN@C{LeqBs;&'
    'N%ZU8`b#vmROcGx`DRV}iUWr6b#>-~j%2{tNjt5nEdX0<T0ansy(Im-`%uQ#f?o~)O}J8)$kbv#PQNu(AfP%<VDHBG7;>9fZMK~e'
    ';rXuf`V5p@SyIi1ywCRcSk03d6&h;Ig);me(vQA|LtMq6mUYT4Fc6F$(&k=SiE?K%>Wvqwzy8b&kWmBWdQQa@fRPsr9@)9n%J+6v'
    'qt#qE!Y~lUA?e<zfBV^6tw#10^CTU%q&dcXyu!i@eV^!jZ@MN!;EG6U3&`%|4V@ir1eBx6fESzPHVjkr)I=#dXf-524*y?UTBS5U'
    'a^`mUEzJRnV!L!Ki1cZ#x&l_pu%JMsY=JFHo3G-)Q8|8#)0@us93G5W!gf9S1ahlG@IVr$RhO#1_&Fj+!VP1>JU*7Clo1$6jc0iv'
    'N=V{UOFLe!kZ+)GIu~cRtV>tH<87NfQp&hkWbwo{IrH$bL%641z4P;chwodX41AJi$0b0R!nptR$6&+0i2qdjx09683fUDqW&`5t'
    'LyYzf6YU*Ct^xB;5~0e;(?f!byva-EO&cCN%s^v`0sQ8{>f%909I(Z}D(hm(KI2D1Y0!mz6FqAE^V=1Wi=#w90$gRO8b0*%3Y+;E'
    'e==$%wLjVI`F!nuVl?~e;sBf4OH6eM(f;%V1$NZ?5dH$h4Cj1Y&&Fey$$<G*i$;!B8&|f6y=j-TGf)r*T5%p=bNYj`+dEnS#=9i~'
    'owaH+>@g9`{a1MHAKCf_!=txqVO2H5wALSdyc|%)WE#JjajBct=aHRgVyyh30s$&ybwj%@ow5%SRmIQ{x$tMMh0Ww!Ex>p*%}`Cg'
    'QC|n+kmy3KRQ}9pT(AXpiKpnn$4FdjV-pm0;)*;}@s(><-UWaxAgj#K=esKH|7&Ngv=X0=haa&?ojDORA<?!e0QrEl?c^$b?^uP<'
    'U0U@-^z%TK`V$hkh`3}nP58GEpYsH_6X9r>g30z*uG`z_yjrB))U6Au0-JkW2pi6MC;weFOJh5TkgfVEk`%-mw!UTi<eAi>Jlg3l'
    'I0no{;C>9p%J<K`?rKo5S|gF94npMs4}TKbSCCl6Hu8s#R;Lipt1^Um`igN%gJ3(P#ntEC9JGoQf>U&oK>rvo*LA4E<@AvBUdDV1'
    '#=UfEM`q6zTj&GBS_m-x6W9a+DcWe}xVI98P%kHHMh}zmB?OICB)c)R&n|otz0qY;mu)mL=!&r(#@6_~`2|yd7Bu4T-3t1!XkMJ2'
    'I<0W3hOrQf4mR1#M(cL3m|E$eHa#ed-;*jC;VGLw+SgejgsFSAannMD7@C4dD0g<~y2pIAS?)c*3N=}mvks=;*Il~3)4%#WOB5>S'
    'Ua6^!vFMSeCNiB+{9Sm3X5riQ&al+}4Kw?<2ctZxzg0>@jHl*;DTK&Bv+)p8m=C|a50`jg{y27`RexKymM5Ec$t+cABNpUQ{DDKm'
    'Om$g%OrWHu(EnsP^3e#A17pd1G*GH0Dc%_Qh;KEB#FwPn{lY+ggh)xz8|8|Mkf<QjT4I@Y*JY8Ok0;+Q`{?*aSvdj5s>}eK6EaD3'
    'szn3MY$^l6qRfM|1Z-su(&gr$WG=~Z+f5)+B<gZ+b&OhKD{JNwgiMQ~B4Q<o1KK?B-(=YkY@w;9nT%+qjt4dOKu};!qN(%&Eq4b}'
    'tI!%DjRb>1`!GP0r|=zg|4aAN;^A!$U2D~VgBc5q?K9Y&x@L3y<0JNK3Pulo@IU|h8Wm1?trjeV@dH^vd91y7*xkyw@aU%Tf=rA?'
    'CyIf8TqqupI@dl-C=*GL4V4C&`a(?0E}bd1f^}c~Y#Ak073J(;;M4Ip!_N7Y`CLx=alwcX&rX<W$y$RA{s@K#YY98)DVr$j(h!DF'
    '3=fM|>>{b<3MRP!dUzCk`f^LM#X9D%4(LkBhp;6Y=J*4uu?a8vdn;}(nbZT!uwGYOD0@r7Uvt}aE4UY5r$y3Fk!My?;*x{oRlGfp'
    '@487Ya|`_@Al-TeTP8YA4qCgi-sNHj*VJp!Ql0F}ICGgf25;g`g^~VFfV-qA#1D9bp}P1iz=tkBp+=<6)zL}z!?oHOc=bsG>0qIY'
    'Z5asK=YDs1f=7mo0v58W#5Pl*(>j@CO-f!{Cd;pan*M!cJ72?Z{yywop^IS`h1TNV+6u7(L+IGoHPIG6e!Q|TGO!wq*~i$!6s1P#'
    '^WHCksm{DrcW3o{&FncNa|K<-sHE1woQI9u=Ww`%8@d2I#ZzZq?;`MheRY0NlGl=BW0vUvJnw!2>M_qMr?RRMiL%;P6goH#CQw-W'
    'k*4^r0)+iIFVTOZdHybUG*f(fRA#(${)#kSQq9%LwB}CV!#MK|AkGP;D<{#4*eT6R5~kuhGPj}zmfg`MRwQLqSkKVL|5LDE>^Tu`'
    '%*$XA5BpFG=TAgYZ^J=-(zrOf03<gg%p{GzL#n{<fYvMwPKSHR=^DnK)y-pEaL9<N_JryTI7;}ds*TZh-`wk<B;kassu)zecHX({'
    'A)qk!5D+S9TJ%D^>|=sF*AD>4VXGew)%M0FJ>`feL<ZW(L8kqinO~<9<Pgo)`EkWf{`kM#uj0V7QTT|3qf-f|Y3>z99Bcb3N&wKD'
    'A0SNM*!-ZQW9hx82(>~4%>W97*p~qz3F7XpHW}eXlQ4aI0gH?z#-+j8M-&Fap5PG6$Cw|xl^{p4mH&JoKnK~-Cx#I|ejog}>^XqX'
    '($ny`<@w2)Pq)9sW6PL=ufc|aMx#BwhVpQ(jN(wvlGh*PKC}gz$*;(>;Sy&XTYe|R(6L0p(~5_sG+riE5Ca#4(l=nalOt;>!{kVW'
    '^bX%RH~74BpzHc?N5Yh!%(G(_g+iOjwlD^Q?x{wa8V$M{a3D^lpE*1ObD%zIZ~t}Ep>=)ub_48Xcz*2Egs0Yg_hxy1bfH#kZ=RA6'
    '>%*gAoz92DBZhz!?xMCW{LUiYP8us-QPw92DZM{Z{>5~kyz2OzYq1wOXPl*Ag@)8x%2JudQRb~wWkEE4648PTU&~AJIE9BquOY6u'
    '5Sy~vC=Vy&frNF2eRPwiDDUfx$x@5s1NrD_t{#m>5Ld>-5gRGcPo>d2%B_Z~Sq(V_=^ti8V~85UlsBR7S>b;tMu}X|K|ry`Nh(|T'
    'Ru}5uQEKX7aD0$XLXBu*QYmN;sTyiA_l|YwqMvyX5jpk-0Ezp%l`_=TJ2NtVgpjxH?Xz<vx+m8~6LbQd0v;r-Sk$P8U=8)a#Td@&'
    'a7A*T4$(2wnNoAdzsFdt<bA(TMa-vr#)#^`3>fKBSbzl}kuSr-+%T>>PfN88j5e*QKXViMxiE+3w`Rtx@ShyW<>7Vm`^@3dhzkl2'
    'lcXI;4pZ)>B4AODaTLGa1ry;pJY{x`moNZo@WWwtd#RLEqvd=&_FU@?%kb=H8G@J2;T4?WtBL5$`|xeRFT<k*hxptRK*<Cm)JfB;'
    '*qE1A-8LSJ=EP%-3S&9h*G0ewfqDXzVMWaAkJtn(`+g>90_}1hZ2LHk#~4mGN3fZ&upi;!)>by<(cTcM9yM%;eZ%P=#$8*Odrhrk'
    'W-iTBpyruVN5yVzzFECxI}3>rs6m<I#-26ov%XZ2cy{6lp{Bb0FyaZxb&VWvT6bGAfo7G{k^GR%{=Fy+y;|L`;{RbKGP^>g!SfEM'
    'zY!~eyz!+k=~as$*Zn=-kGHVlQ=G5ag{*BiEMsQ2I>;=$oOj)N$lS+|F@qx~$1I8KU~t8YJ@K8QZgx^o6`^-eCecQ6YiL6y#Ai@Y'
    'goGzD5{9C(aFDR&9B5GZiAw|TmQd^y*+_gQ@!t_5CZGG2UW$x60@~M;n}JOBzXrF~fh~>8pm38WvYx^u5<VXtCXV($U3XdBuEx=E'
    'yxbwkS0qC+Y}u6fSlhe04$SJaYmp2vYu)f&JXt>qx^$&0nmJO>-`72}#<I4W<LSXJGlAN5<&$>ZUfo&(t)SSGxv2F2%%p)LsUw>C'
    '12HyGp$0=S|D|bPgj=+fbo&BhvMP6eQoIDAGvPm0Ph&PLrj&-1kuw$D5~m@576Ioe?aIFY_x(2P#FwS<p6Zom-H+?s#v^cA9bH3J'
    '1k-Q#maF|+rN7ubA_FRhoEB<qUsnH7y0kq81Q4V2izhF36csAj2h6_$mb};`j7lX)C>%-bJF=OOpv<)xBXGr&o5IYG8<8PP(^=K@'
    'RW?UxAEQ2NG0Sm9c3Jj2=xKm;Uni$3`^No*!s2ekVP(rCv<daUC)%;<uLW6V6gM3&j9Kv`xDHSrf^oN_MyI9a{a}kdxe4grDsgXy'
    'h38d)BpwKNjj(}42CB0@`obx(OCrxz0d5s1C5X#V6;$EMA!=mnoxRq-(?yK4Tz^gZogcNe&|qy?!JOfe^!zx7TF3a8DzsNnA_^>3'
    '&yg1CfRjbX+>wuN+`gLf-?K#JSm7>FKST$%oazkbipSG$4a|VsY~=wg80OfE3X|O))iZ(wZ@L%tB$7XlTo|C>0S@H<a}u&Iv5N55'
    '3h8g5eVxwy!TITVcsIJM6G$^Hehv8o2iLqc2uK~mKvHvPXE3_eB?=}{){+)|=-EpELT#~Fm7DRV6(U;-e95KEPnYl9aCHIJyZ<oP'
    'p(L+xzvp}tg<-nk+-fUDip9=)Ok<ba_CSfYK#5j2-st3-`2-XP5nJCFF+L?e&)GEQ1hd1s1iKUQ3E;1w@Fi`uGq<PuWk{03$^!!}'
    'xoQX>bT}&UePNwdfPjDo2j2}s&yz1?Ci|rUkTavrcUJzs=PZ0`a@SI_fRqH;IptvkRy&@U(|VO+*B@$BXbCNOJdLi-K(DSxrce+J'
    '78+C1|BKj&^1O?!3cp%D;^DC#{*HM`xejL-&r7N+AWTNvb#QFFM6FeQwOXCL{%~UkAOaXt?2VQ4yKFCZjAYQ#IYnlaYK-MXzj)HU'
    'Zd@9GRjK3_qpNPHA1+OJry1c68Xy#FBKf)qv`-c}h!{#gSjmIOzJb^mPP&z}S$tOCWD<n<*U&x~M6ohvVq(Q5yDhVd)^i-=IlN)b'
    '-%@#Ro0)@NJ79BHv>J+@fQkl?&IA=hG5<40JK8Mo(I#SkVk4uH@q$@|<eC*O_o*cRoCHO*?8eGDw23T^<tn&a=><gY&SDt<d$ly!'
    '`sqJ*2>9P8+nf)=!!u31#<quU$3OKdyXaU6ctMc`BB!c?{IUh?!JHU$)}gFkcyP62NW5CJ6T+SyiykrQEa^bn^1glz96P?~S>(R1'
    '?S5csRPX3wO=x$jI^5w9WPw*y1n3qUb*^R)<ld3?qGoe5)bO2Afn)x{+){s8CTX%|xT9|sL~>mu+znkri@KRc<aUP*D{6pR>d{E3'
    'Wod5%2mj0>N>TB*Rz#J6P4H-6lASPha~B(vgGq4CHjb>4Ni@{jY{HSVvO{7~?Nm%`uF^D^Q}==Ul;-WOyMT{*LzjoM@<XQfq`%dC'
    'h#5q+y?z4zL$RPaUVY*!%CcK-SZCQwQaU1PIKps6;X;Tyar~wf5IKFV0jGmmLm%Xm#%_XkP4@RwOUG6Ny6o-sL|h{5<rCdOek=E!'
    'kL<HG9e&3K;Q^VXq6YAdIf=cF$#|;avC~b>fXHT0ULE%?R##M1F}!W;^=Gl14r7wco={CdPv=Ro&wK65_BhGKi9xI$x{nMLL?gMt'
    't$Lk%;pjQwm2hN+Blx8fS-<aCu=#Zj0ruWwJdK_E5VKhMro47RE`Gl(dKfG?Q@Z%qKeeMM9c1m}9JVAxfp{oVTG0Jd)3K#ZW!=S5'
    '_K{5iEyMh#XdSCu;FHTboyA;I;+@&7;6wh_1$^%<wNDpR(1Z%-yJVXal5l&A19v>@2O~WY2U5wm%e|rs%&@+8qc)UAi$A|0MUxFH'
    'rY&S}!^RrxcSAkd_#d+D^BHxA!@f5G%!_v%#MQnq(I{PT(WnYDhorx<YCZ9=6rcbKJmO@7KhzaS+i!JQu{Y8JB{LIhe?2Q3u%M;1'
    's_p*EyH*dl*yEez`M0<%dxgQ#p1fvJq{T1;0Q)*i7}n>>m>(yvG19eq@*k#e84qP69UM)Df8o`ZK+Tz(fjosplCk`BvOh^{#pY+U'
    'u3@<%xmf!2w~nls+6E_KrpC~cpCu1Wu$KVSB11|55v9LRCi{%7D+HD5u+1O(4>{P5-*41`(1U9Kr-HJJE_K$o|1i6-<pU4_d-_~K'
    'KbJ54+*EX~yXrK$00;c+we&zwSfP3yo}vm!<BqTD*}yf)Gn85+O&Z~n+m*Mc&e4;{JTkzUo~nyx&dnXvvoahT;a{!oFi{=jCQa`n'
    '<lR53At0LR%6uxTYd)hXj8I<yo4CZ55j>K{1>9)Xx`2c=wLWo{zgp|Gox*qpAb-n2-n5DG?k}Wv=o4sMbxgj$%f>?Edor4KwA;wB'
    'dD{g}iHF`jT%wXUY-Izt1$L-0_z5+1etu_K@eor5+b#t%80T7Vs<w1ZQe{=s9>SbDC~2~^wy)Mt1b&E!mC*4dZ5qxFaT1FVPh>WQ'
    'm`dIUCcLA#XC5%IpMHO7cOsB>Tck`*CJ0%U*_kC8!K-h=Fv5h*$z_);K)IJs?tY7gRL;RX0H(q1qAne9NL#%osn)UjQ3It<n4RY~'
    'hoeL|45}oErILJ5Z$q1!-YgRKim>6+C`OrY8XtKWT9Y1ZbX80rJgWZiQ(~PwCnr+Ok$u7gcW|55nFQD*z<vwp_$J%7#+U_Vm;&*i'
    '@P%mpD>31>pRwMoh$pGni-S%}wolD|my%?46Swz!)7i|>=O2oy-lRWe4hd|C_X%4<8=v=o^hi2$>T$&k6WaTFJq$bghw@F6SLtcV'
    'x<d0804%3LPpz?KSGkGEW>5g_A0Z8)Y*0(0P$1O|0oI?z5>!UBSD5ho-W$2|)H-1$((yjJJd+}OWNBn$K<QnHVAKh3L-0SOj!Zx<'
    'h^E9Tl;g;PAWO=Z|0Fd#8yyTmofTpuki8KoHyS{Z$4*pozT^&rZBW5br=D0yQkl31-(Q=kd`VR(Gsd#2JYrUd@#DR@yK^9fM^0RT'
    'ARQe$bd#d#8#l>}g<zTbj;?Rnv4<OzyFGQisv|q%0J)(aI0(B!Hn8-+EstcJj!r+jOW&U&hcfoe+^EIl$DLE|pS<>7a>!r+bM&|U'
    'd7HHsolQ(1UIHi~iUP}~v1u$SUs}JeM}W8t2xA}IMga=#xbunr2wqZeL0-Am?xh<31V%Yne4^Z6CEXroLx{nB>b`Be=^fERU!OF@'
    'un|R9=>&mlTyG8r2h98qs<0wgR%U3O9;xt&)DqDm<#ey?<;(t9tfhX&4ia$B;@&z`gMACDdE4{rsyRHW$gkueR@5`lYR*<kZ3ji1'
    '&}{nT?c}L6t|ei4G1xEMp^rB*T{YD2bD>A-rP2$uS9TUEgMNV3_}Ciwz$>xlv3xKH0N^UXg>A2R1P}~?c)JfuqzJb<GO)rG7edg-'
    'feNIouaE#316iu?nVPELRP=J#CSUnuTMPbRnwzYx7Zl(JU+*J!vY~+b4|G{0&145b^-jL7I_!IG%@6JoS~XGqMRaugCA%~N^=xB~'
    'U|Fbde}z4XRAgCKO9yxc#|Bwd0)H7_AbRfjnN2lgmx^%0k@;-pyS<+omui%nD^B;vr<~HHq#RDpaEP_H)Mjv-kt&Ql7B?sRY48&l'
    ')d{W&*R^n9tViA(YLoEXab{6hOlfc02=FO|5J2=#1GeJoz0s9i`*2O!u&_pVNfthqJ_N(Kj#4ImF*u9r&4D^!G5?O>fWEG@#A6VT'
    '8lz0Bu#R==xgxdo-1ax)cI8QL^m$4)t|w-zAaw;13@kB)U=-}r;}(|o{D9(@omf-e{UGyN(7EGjjt%gxmE4|!nF?J_i*!C+16f*<'
    'P}WUtK7#tMgSaFIe#)k3Q7CwSYR7*>T`&?wt`c^;)w}&?i>Z)hG8MzX%3g8M3Ft;(DG+QSalePBKM(scJX8$RMF+t|P;%dlhg8q%'
    '+_=xFlQlrSx=a>KXLz)M;g(nnC8QR>Tg)No<+v;#WZBz(sJ_>iu>CPO(GT5IpM{a;mDnjrv9Szx-o6@IYD+V7;NgS?I_Ld3)IVd$'
    'o>jf8?oGvMQ*bU|4D{45yez6}B=AS~-q0M6Ca8bKSRiBz1GJq=x1OlrEE4;}+_y1e<L9yqXIm3tZ5ppu``MHxC_Vy;sw-Oc#KR7t'
    'EE_cx7jOhne+vD>isBvu!U<CV>|dUOdrrEm^UdSF>exLC!5I7S#0gS4lvM|8OoJ>jHJwQN{DCz+M&=Z1Z3lu<<w||-27h%1X@<*&'
    'Q&MtUuw+Z<<SgpEwH|SWtMwO-!2dcE8NANxD4<B>8-}hNau#$nI^F@lCW9MASkOglBuh<qZfR9DKb)0|KW`W?UgIOvLOj;x1pwnA'
    '6~6KG19y+aJ~gLu2sL|>Zc%H-=5sNqj&6^@&ouT!IGgY%!8k^nCoXTXa|kxpp2>|mZi^wE$J9p)t>mGr+|1Z6Mu%hsGdFiERY=Ux'
    'q_PiMu0IvcIZtdro`7@~sO0#eDTrt`PR^3xo;Qlw7zdeuG}b$Utzt6R`q`SVu<rJv;+_5*PX?az;jz^b7Cq89^;zfG+U$0qIhaT>'
    'qG^iN^37T_&g-+VnN{r)p`@RW4cl8{xpw7zYq>m7HF1hWJDPL*RJZWpu`l&*MKXxs6f|ZItAJTl(FNy-5vW?T>D78d{|WJrEM=j?'
    'aSf{_pv_cT58iP1G-z>VjT|=#o9T&G+ZU+ehUgR~kix;X6-ql&Ly=yb_eyGeFEno3cp3QLFEL{|^EaNxoZ+?X#&z0x^0|*mqBG&H'
    '_lKHz<ihcVjPRtHJI=}&wB)T<iH5VHQF~JoC+E($r>mjdU`S>(w}+XDlW-2FjERShtl_QPc~lGrswVldsCX}^q~y##Xr2~^*hkOd'
    'NkV(~?@B~&iS4iA$w~Ds5>ZVpuI{!vd!zCkl2NK2suTb=4b1WVK&66@LrcsQE%fk{lEG(^(cwP;a3wo=t&LrE1AoEs`j8X>pfS1u'
    '{y>2*&<EUJzykPyr?-QsM2<{|bB$q@;TGZVfdU0V^<p=tD{{(hB<mDkBXO)kYG_sG{Ii}|q0gkzx7N2#?u?Tgw~OOzXmsm%fPD1T'
    '>PeYoi_r5Z>NMY5nAJ;7FGbG~R-0k-<CqiXk@P<^O`1{CznZAI=I`wMwjo^c@gkh$^F3hFv%o~3ONFp1VX|S`G8Ft$JUa@(htg~u'
    'H|-0->e2DXD@T+4E30MtWM<=>UKgP3d^LSCaUC7QD;jJME+xvK{@(;+lkGdAd3N3mU8TrYQFM;a@ECJ7gx5Ma_q@-O8i$h7ew=_$'
    'SA6Pgfx#dVPKFX>eCA2KEXC(9m7!#@*7e|8cpot?TyQ~&p-jFr|7_)IY{dj_GsraLU5N=ki|;|6SnX9l{6)+s^4<&@3C*pB!7xYd'
    'kH+<lU~|KiEf=${8W~ye*TQIK)Pe2XJW6SOkl;)ne7CKdQ6=ZzabT}nENw@73(w}_q13v(9<^o`51yoH!=md?6YKXG@y+6WsJSt6'
    '2;a6r<QG^A_tTfp+kV9%x1;g^!7Wa9hr|$gkJq>zUtUjdb?)lyEDPlS`TRiE8#cR7Oe31Y%R?pdKun$lLl67nnD2ehfs3mD@W!X+'
    '+(Q>xO6fY%3P%HPU-lBX6qEJp|7Y&Lw*(*WZ=3zITEcWnJ7d(%yKI6dVM7AsubSI*F-bx5Wvk&_h$o!cvuO-q^GaWcsFPDyWJTjZ'
    'EA%rtJGQ_Xf9Q{RgAwcu4{-cj!+c8k9t%BCKM#e5wH=E5MGOf7;yl=HcMzn%jeh$FkaB<xqB6P(uuFcQhhRJf0m{gs6#V`Xrl(&D'
    'Sz8VJJ7O6&QD&^oK3SDBYx56?GtZ=3Ytb;GK(7+9G0e8jrS>B^M^WQWJ{qs6VC>o~xn5Q$!9uMBW`=^$(i-D6C?s!5TP+b9>ep3Y'
    'nL^;4IGHl_smrKZ6l-SCzUn||$qOK|nb8NDK<?rSaaAHVkrm{T?8Z=rdY79nQJIw~U;0lrmI6yGoh<0>+(GM*fY&LK**FaPT(f_t'
    '#yDc=$!<A~u9>@-y(=t#t6jIQ&km-n4o>{(Vwf|I9N{5RS>TNQ5%ok31+ndm=Zq;9jf6vB*xg4rKD{oH_r@dj7hfS8a`eMJw@{SI'
    '4|T{@93McSAM?aH%7qhTa>F``x%B(LE-Y_&Xp!0KHI}ssW)qjH&C@$Ku#Q%9U;YP5x#)?Y({0QgQBesZB<x0`PXe{*@bbc;wHQdK'
    'z!@}V1ywa^(sfa76Sq}q!Pi!Gig>9tV3AF7Y>+Fy11JJ-yLX&dL##WVU^o)HL&v{T@uF`@-0B0iCZsqW^EU(FD&JwJ2HmN#&q=IS'
    'vBRHZh!ATvs@gpuK{#wR$#Gh=O^U7$V4PP#kW*Jz6-{0J!RlkC4YOK&XwAU{jDaoic1usd#lZ~v4VO5w!Mho>J{z@n8z?(NHmc%n'
    'xMO=6cCl96!%5z4c2swKFVHio6UG)m#Kjsclk-Bm8)lC-6~u9}z96Fs3X1+dL-N=?QO%BeVbw}&Y8ey`M|=J@RZ<FWn{B|<nOL=&'
    'kn4K0jHz<bD<Ek4{-QXaB}fz+ReMpICE2m<H}4Vap7kx-TkCo`|5tULL<a%a_BT{cmv0_Ckc`R44&`%bZz*&G<JaREJ<LXvf-Ge0'
    'L!=o-9wXRw)$IkOakBhjMRg;9(PW$t=79NqZ3}fQh$UCBbmOmmFa9O9Hl=7miJ;=fh%-o6)LM<l>A}%8DbgzUY+6EdQ4@jZAVLmC'
    'lRX5sJE-Rdxaq{eY-$F80WhZzWpYrxJrB7LCY>;`B0j>JF;x19^nh@5hA;2ceQr*)lsBw|?6e<X|L4E$4d>=a+|f1AOR9U6#pH$z'
    'S4igdCD)BPoT_OhCNOlDKQ6NdX~u3a1{%|!=-D=dYs$EAm@7JOe*I_2grtVbI6SP{Dj6)y5imEWp4M$SZa8|q;=h<aV1R|!Y-~rM'
    '*<wBy=*#o`*gZ95UDSF8*-}BEUyntBal<i7kX>*A;SvEI9KRHj1zhJT=6t)$;|T{t)vFVbcu_L`ThcT6?BT^hQ@}L`--HKby@jc9'
    '5sP2em=GX$7b0|x1c;-q2&a)tEvj$)?IW?8$6)33QH)DLymClZf{qfON>fedz;S7y&pbs}b4NtZ^+^m%IcNL&VJVlU+FV?8gx11)'
    'zO-rOD7;qjV77hH{m$o<x-GM(vF*n&ff1gB0hH0z4}%@ftqs0|M$6pk1EMKiJ)awhB9C3k&jwz$uYp>Fa1I*U5atm)FUm~rm+IOj'
    'n0?_y^J~#Dr|6_7@=!(1(O+o8MzF=t#iO~;1yc#eH+<$v5CIYQax40TRX?jR(3Dr>NG?BIjQwA1K=vwTyk6$H5y}3VJ5*0gXIsxQ'
    '<C#Mp%M1=T$s`pdm@TRkPoW6OmVfvjCz!rZZWvB}eySQ?yZb{ltwgiuT2NKeZMJTm|FPkI^iwX<>r&~lh^OTBIEC1We$xn~AkDXZ'
    '(fJ84u@e^On^UOXzR9A`h+*M-*bR75wIJk5eGJy^hIV16oS)&du2hj6)TPq3udXZuyfM$=I?v!w6Q4NFfinMJHknu#g&YOn^I><G'
    '72*g|UrdCB%+?oYq!C^@b#H*YCSfUS&S|JZICQr)g*JHq#@zUiF0fjX6c$|3zfV}@Sg6*($fYOl9zKG!NqB)5y*n7hGPwxgNe)u|'
    'NOy8>0B^InFtcRudBZ>-76nta_O)I>%=BGy+pWK-KfUqYpowFzmY%{1i0drQgwjIxij2%Rc%ZYB;&Vh|+s69O$J7S#Dm1J(kv*&('
    '6@>MCFq5os-mz8&<?G;?Zn9a-VFfDmwX#moeB~oLbr~}v!Mi@2=|7HHvsTQC&(tq)c;bh814lb8qbzos1Kng@p@d9@I?p_&U%T5h'
    '^{2WdV{q+|VITHNp>*6ec#g!4Pd?~gkCj)LBekyEh3LG?2Z%|#0PNZhTf`#6?Z4|S*#k}9i^IKzK;bs}?F*?T^dC)s#3LB+je;?7'
    'a!Pi5Afx3VK=^6J=QOBK(AmSvyfp>OLqFR7q#k8RGOb})rc|!OTrUd(S<SJ3V=~!o$i>ULr5}w=SuV|AG6s3FZGl?pePar~WLfn@'
    'RI(lSa7V;aJjcVR3^0hnhWpXR2n-b>h#O}DLdtgsh6k;~i^?EP8{sUtOM<g4tY6kNIiHc$aUu@g`Lzv+lIC>YA2O^ET@Tn-+mihN'
    'z=qK%!!y={W_@S_Hxo%Of(_{`N*<Cyoc0Q`%}zh(fl1*cNHSskCo&4FbYXyt1d!-IC0QI)Za(*Jt3?Z`<iF+a+w#{D;J2AwnNl<s'
    '$0ttAFIw)}IARTs_7Xp**omIoc?YOXjrP#5Ld{0ywGO9KAZjMU_y_rJQPLX+Snv?~LnWWadwYP&@D3;xCmP|3>e9qH;LJO!7qZKo'
    'N49pW_78i;pENg^E-n0jB|#@0;<gbYk^-%_+b4OkA#}96)W(W_98V?Bs!c;b=@&VP*-CAPrIqwt>MMH9G0U0n*m0~c;52`Wm)*KI'
    'a)S!=m!O?C#mPqwM_G2=uiebOaLL3}d|<C<_$9ALHW;RTL+6ItbjtR<Aln8{kTpb9ShZ66{bVzS#D6qyN?B<VJ?2WMox*)K7Ea1l'
    'I9IHoE&HkY#dEkE7_{$L{zfyzhX&Mv2@bF`D%(a9-r6GXzGH<{D%q8r(cqS+3<V_8@%?!XAAnUJUym#a>c4L7!kPL@<f$pb-56i+'
    '4{*#j$v=~Nrt+2*Aqa;+UsL7s=+Ff|1B!+vhP99^>F1n@-^jtKq4&O~$<N0_y99}70|>AmnVIJmlxElc|E0$HysB%4YvkKNqJT0*'
    'H`FwA?-A|lrhC+!;)iuZyf%I!yK}CZa6q2UN5?ZuIJQEv@Zq12{yV~2(M+PwM>ivvYT+HisdxHX?G|c*B+X|Du%j1|wAvBM7cpRZ'
    '-SCQdL+u|G!J!EA4lOV}>QalE%R#Kh8zbz2KLd3R_n#ITq0d4KSDg@V&gYSXY|qRFpfTr>^ZAuX6eu2&TEd#6ayWYQvLV_1lA^|D'
    '79sEV7QgDes|?*^#5t8=owO;MVf2UW#f<+#Ee)@>BLV#_^uUtrs1cCzE*0XW-NrschIZK&q+}`2fo6w$^bcTm-~~QKu(WoFpf+Ik'
    '*UpSZ2!I&STUBXESNlL>RFQdV3VU24Y8IT~VEF#Ga#-x})bJpu1}e}JG*?1I4arNJ_%B2akayOv388Ks<q#$M?M6oSFWoJ$q5=@^'
    'iys|rs25sU0i-WAoj}3(Ze0R_)b;}^S~NZ6eGyT)HYy>Q5-EIw^;|Rijv1V2?`bpLw7v0;Otb`o2>Jj)G)TNGSm+u}nt!66BnE6M'
    'p_q4dn)$Ig&7eA|$;=7|^l^Zf_VZ1vqv~@k#K?bGO7oZ<6^zcybddjO7ZE<=;meFUnM#Y$x?^CXZDihnS-?)#ir!wv|E;3Mfyl4e'
    '*96D{5C=QZAFeZ%h&0<yImM=MnsmX@))%&%VkR-;n=0DCtQdUGl;R{c_hZBN73j4@$}r`zL&I&$bryDmv-ljyiom;)-_|}hlD!1B'
    'GGF#WN5+%td=@ximORIbCcw-XTT&5-IlfvKVOT4{aIQ~wUG)F3HKGNOrGF-Bv}jt7;x$Q?$cpcFDr$5BU15G|F)vV~eNu!As`2on'
    '`I<jl+8eIj`=^{k-9*lThiM3{6BtxQmD_EF+3Zo{(eBxziOq5CQDRNIzGE#q$k`})I?T|8d;m$%xvnzUk@gZl_$lBX)`fI#@I4D_'
    'Hh1X4iZNxUtzk-mp5XRKtuC1^SwY4~JlCc$@2A=M1A5zGXT%d9QRpDsKY)=|Mb>eblg+4WWvpCIqh=-LsjWs0B>sjOSR{52l)q_m'
    'E8=$g^oT2gKppSyGd5N}Hl5Q{l|DZ@4ldmJq7D=(izh}hejo^(x5=;Q5e5bJZ<V~yl-T91$&{wm8&#t&2l(Mr-5bpaxLfG;+@)_^'
    '%noGAG3I5bg$BpzrlA!-Wy~l~utrXd*#9BDM{yqbg+@@FNZEHp)Tm^%u?*OG8KGLFsAyO#gr<;mS#5^_tEB#{V`L~fOaTpkS_)r@'
    '8mKjs(s;`a_XK!5ov*&ZvP;7P0h1cGB@`ti=|Tvp#;h_T#Z8*}e$EZY^5X%u%+v2tKK_9F%sy3aE0es!{>GTSIjy-8^d&j<&<a7a'
    'LUXcnb<vW_T4@dZ`&IclUB+=&<p%ROr7oJs=2-Cs@;-U(4(Q<3$sd4rARTRa-hGH&uQ(32nZC>w3w51OZ}z>x%#%JahMl78?TFyT'
    '#1X8O(3?>aldvQ0Cod#havRs~a5xi5q_X}cFd7@9?j5XjB|7e%p~4*CW)t1I6*eNVBqy8eOQ-&=4i@Pl<w~49-^Ah%Q&T1>e{LKp'
    'HX5DQvpmD>s-W<Cbc>$BZg*Tw_f5$L%t;m_`|hbnMtF3XTy=n}YkdSTbdaTnClO}@h`y8`aOpE$*i_@iHhv3AE{Xt@^6QXyIXwMc'
    'nwn$luM&cFi1J*5)LieqtU8tYnO|;9D-nZAFEkIY;3kgYU<_8+J9*MWA%=2ehQ0?2<Mh1o!YKV-d!J&V^!dqu^=@Nuv=Ha}7EttI'
    '<?UYrT+c?y6f%QdjECnVfg>az4ev%o+z}9Ld~hso_SeekPEj=&`AxU|rxB-~;rqWT9Y0N=T`(WpDI8ZbL~4qO2>JU+8c_pyT3Q7D'
    'ffV@vKXu+T(0d9b6A$S^b+wE{r+l#C;n0`CJ1vyn>>I_t@FFx=Tw?hg%$Xcb@f3%t^kvg~>^>&W_W8HLWtQz(LQvML9P7Qj#wosB'
    '%|Hfi_34P2>1trvzU+gMUX_wX5Npkj;8V_W5kuFE+kP`JgoWpzNhHCeCD4m(b;T&kQ0TuoqejoVT2aD>8q+XF8ky?Kdoch|>mwwb'
    'IHA`thV%i2|I&cOCYVGr+<7&^QJ;Zd-$rE1#iIg{b<;G3<G@}xlc?hnQflVMXxjDR8+diaH%S&aj#Z{W3|d1HRbF(67YMf2AE-Du'
    'Rr~aSO+afZfz(Cb=Xn7{Z5I2x#X02VM7zLmdWR}zcKClwhYlE{&;dvKC`(9?weT#(L2mPOVrTS=bmr8o#(+tKm)TDdq$5@s52pDV'
    'e5G^U(dBQ(8>Tk@bVvR@y2>wok|G)Cg$@Yyc&X2qWU1R2vfZRQ>3I7lJ$w=w9E=ARSN&F*35Q-RizgygHdpuYTyg4wF>VWEaPN+@'
    'QT48-t-fa2&qKOF@!KyMv$}lHRPogf$cnjuZliq!A)cp=YV<bSQ7li8w@EtP23CJJ_ryd2wYxMB?`E-jP;}UA)w@)OQu>hu(=|*8'
    '<me%ECl=OFEpQ`pl<}`CbeTl%jfyZ^@&RQ##MTeYMRJU?Qj6n}@P`N<#wmC4LkIQ^lB)x79h}dUGY`({yv{xz?Ki^Ijy*t<?QnTJ'
    'OyT=L0Y;W3wDlWlv9*m*5t_+&VttJ?g^6I7qxsH@84hj9Y00fo5FO;%5hWuzo-bU%FSs%qgEb25XwhRS_iDY!^m&u#HYhv@l?r7c'
    'H$uPFkOJ;bgu^B4u%h+c04k<(q<JR@vYN-=Qt1a>gsZZ@>*{EBkyPoO)R6!`cI?YLEgF`k)NQx?3#vSSU2_uyOYdsQ2jrUhe?gbF'
    '=^7E>M(}ezOo-~|pciwP8_k<6R=5Z-s8Lv;=}|<l{#*1%fPGay4I7<Jm)a#3HX&)NhODJPuy4iTPPH(xw?i$yb!4?pUDkhz<@6C_'
    'Y-hC5%q5kXXSMph$lnwA_Z7nx@JtY=8Da$0LY%~o@owKXv~Tp^C~15Ar}m&1p~)y=8Qi$WBx;ms44QMP4oG<{Wzvj&FiW!!O!P;S'
    '-xEi5tCs*fq00kF=x<MFq;3LbMguk#P6UcI{-p1=lIV^mg(6sJz#tA|jv>S%te`p@D$_A%GA|Q*Jw{;NV10B!p`*f!gEQ+T?E+!$'
    'r<5!%&_pcjYhUpp@WOOBEs*lhO@6l(^kb&1BN8r7MIE0iw%BWv$T|!U<^fbx*~?v9GV=U+`}_GJvuuDTF!M`FSFDCMXhXTLCF9^)'
    '?NRNrJECp8EihG|Ueb_s`6Wens=E5SrJ<b%$U@ht`|s2Z`L;&dIaWPkc6zzlLB2nLD7hg}<n*P0P+gcpUCLLGsR=Uxa*kzz7}n=R'
    '$cUh8P}zaG>cXr!F}v|Od#>L-u`<*}KLt8x*pIlMbKtH^@Fx!U79L2d{!Fox?ys8eDhefJylLx482eMRs!1Y^KFb$4ojeL}{(UN^'
    '3o|oi?R{%{{i~_tpEp+?r*GvVsSk_lj!#+B6N72w25>HhZ9pO*>AO}B0?h}~)`C%QST6E!)ptVgyf~qk^SUI-@{G(vo+A7qGkvr&'
    'q$J#vaU<+JV%=)j-M>-giMKY>bg%Wl!^{K2DNxFD!!?)47f$*53W~>6TARz+zXSQuMiCyiB3-C=C*}@b9i{Fu-<{s93+lDABXN(W'
    'D<u$b-W?jIshO?giKa0M$<tp(wPaqT26r2s<xp@~o`g}}`HxLPlE3BBiM9bnDVCYMU<BS6C9DeH*BOeUObT)&YPVZ}DO8{qC0&~5'
    'p=ZNEaW<=N1DY!*cz`d!a!>B_QsPm!T(8OD>Ml|S4z+SK{`@CzBqZX*PQ&4IVvvDPKYW$?N=m9t#bsf#uk1Z4-#aQV<Ab^_Q)2Pf'
    '>7;++3E@Ty`%GstC!}xNED5@U^HVyHkZM%bV54BHK9l+3FuQ$PY6#V-dEYtc*=$E1BHnaS5NfbT|2+3m!<eY#bsN1skGu1>V|UAk'
    'rPDqNSPVE}FVAxv=*7};KXW8sHfQQ(TN#B7L}L<Akzb8O=olqRFrN<%MOw}A|8mv}r=3~hhNLzGBOhcIxb0B?F?hU*?STOZKya7g'
    'P4s?7;)TiTz*K*gYJn)MWZ3j+*oxAcR5NlX*4@UQfUXS5PM|XAX+f_}7U*lVe?0}PG*n)<uiIGBplVx?)Da=A)Y(=(`pUFv#CVDd'
    'n{M?9E|S3K65-Ej^U{j9vS(zp?N~oNyf<alC%cIZejK044RoU0=_CZGRPo=M9Gx=!oKQeYGg)YAZig%QZ?MaY8{CBlO*-z0fl_h-'
    '1_8yGwxVhm-S%T^lPsIlRMYfIZGb#^<NSD#!D#FR<f4^A%);|UhH(~E`srWF5d9FF9Ot9l%bdS_<>|F!i~fLZu^-}zrb(+VJ?S-V'
    'Qk_!{JB$C^!?kTi=}!|qxf9i9Xg51U?*l5Nswg0XyNYrtF*MmQt7qsIKdKdMCrB!zG1CIh_6ugj?${|$TFab<BbEMa!U?G(CaC}v'
    '`c6p+YMC#0UZ_vdOfbZ^1But<#Exnb=tMXJ-x3+z46ZDkVGiQ<pK*|X{p#J(J=Y3S+lcFIA(euMK??Jc$eD^u0mT!-76%n0P#rBD'
    'kYwD&Hb*mg3fmw<eY(T8BidMSctbGz;{l+mHAxleQQjdlle4ya;-@#_x5$iT9-=?<N$=-p4M$B(BhrqAX<P<0#dw<P(}ssptP?26'
    '_Z-G%33^zSSdpNc`pzkEkfb?)f*x&53@DIhuQ;U!Sjj~Z&Yokd+ame^lTAfuzTbcaEN=LajoLTIMtY&_26dytv|O2-zvMV++3NTM'
    'yc(${u|5w!nq!uat(R<QN>20?{}y0RzistdF4$G4-#E~#7U#-08bAKf@z>7by1|x41Gv|!DYj1kNw>xg&riROT_M(;Bjqz=Jv<i9'
    'P%~)Y9=&k-axJ9dl_<7{)~H>hSHT>fK6mxkX+N0u(zsS5zMtBQUN5YPB9$W(&vuetOxHid`9ay*#>l5V)v0Hto*?xOt^xa^PN@X$'
    '2@)YHi;g~gWsj`6^iGu#RnqRNN+L^c)Fvg#tV&*n!jtJ6u;)R_;8l|~eC98ZVC2swjdO3DYn+e`?d(Kem%IW{qb+%K-A|X-^JLa0'
    'Y@a~E$>P1#A;a@KxN$4zoWXM3a*U-%y;37<W>i9mJIw?~<|*{h%d(aLY?ZlX?5dKuU81c?@KtRPnfuo9u`j7N#CR1{Y<UdrlK0_%'
    '*Y2D+5=rhc;I&eYXh0uL1^`D$+_h9zwxSprp(4)JNM!hnIv<ujDedFToL<-1r03Jp65f?*T3eekNn^&RvsL4cEuQKEAW-C*rB)+R'
    'rc5S*h<nlInN5n4(*L~u3MoK`ecHy>n&XH@LCr?~R@%SX*<D5{OFaco+RfZ#&DWZ8%4QhQ4-vTlP|^*0T&RJ!Fb)a4xlT8?tXXgh'
    '$mxczk4VyUTW)lFh|DEZ;RD@@Yd2p%MI~w?tlVmL{ftAPA$DZ&``1r<0qvXg>Au+fqg5rdLrCN1EV2@ePd+M>Ueg(4MeAw}>9L~t'
    'MR1VTYzTz)xX3EGH>#)f&G6q}$MqDYwh{S$F?~e0Dy?LU(L10uhpc9kKj3Uf1weuo-5KgzcaWXBkE<o>rgip22ukKPt#+_Jquut*'
    'i^K=-i%CfuA+^8eBzU(`B^<g&VTK=QP9}<mVeR;sme2gNLK>NcxE1{8q>FDd{!)kZ<BHGpbdEOo*xoVx>$5vsav+LIuL&fbL}z8O'
    '!xSxXCqL0a2|n6<OU-Uki7NZEL80T`5Rjpf3yZ<+R^@O-_x#XLJbflUB+!a~k?sBL!qvs2R}7fSfas*G>K>;c@+xP{Aft9!vqehM'
    '>0>4Ez?M*cQUblktH-$rrr#Wh)3$c-qskL-Nh<ZF_2++&xtKfjI(@NgRU;++`K@zbBXd70SMy?qeLx3LqEN`)jKuLSz4EHM_Sn~s'
    '(BN(6+E*jGiW~tkvS@)iWyKf=JWbS-;>v_6obrXjXPI@ym6{-;Za^&-JL_<2CqVE2RExr2`01!r8>)V_8nTLz+vnAJ7<k0}631wU'
    'FvRB_nAb3cgbt`t!D)#kpAhONVD?p%gqQ-GL8?8ye<&6K-Fm2#_*IWh&jRaW;(&a~@X^7V<&FwxUq5P>%ch2_fu+f<FZ7TY1&<gp'
    '180S+wwv;!t@LTCX_^=D!iY%CNwj+Ot}leR=r^rgNA7=7yyd}eNXWw6DUBR84h<qEV!%#!Qqc>QSZi)T-DYOcFfl;r-cW@(yO>f5'
    '0sWS<twSsd^yNR@jfken%MyUx!V7=41la?Ta~@m|*i(_enva=-OqdV{%ySMfvHJD3(J{%CTIN!29ChP)Mxa4oVISiq(%G(7!WJGS'
    'HJ)#wr0Pff#{9_iWLm+IyLWO|>%tleaMCoU6y}M;NG*dh%xAJcoxO)WEqcL+dK#R?w4?h0OVp?vZQq2PdvDV;d~Rmdu+YyAu|qx!'
    '2@OuAimsBXvzr7ePPfjQadCOtqQ{@Cr3{6{Dkg-!14-r!Yd&Qu6*IT`%#|_P)m|`(<6_7>4S~U`#D)*+L=4dv%3Q_GyDlX!l{b-?'
    'TltLEV^W^M-yVv{T)J}jZ-8Q0Fr&K4L^$s<s)dWKiu<u@-TfVGZhLEXoY|*75PZa#YY6R+wX;CT2nhUhfA`i=)4Qc|^i@TyBAf6%'
    '_ZgaXJ%gJhAfOD^&1q39Y2(w}ora|pqJk>@08CF7Ph!q8)wywAL-7+nwoAN_qT-rjCA+rLv19U{+ce#wlFh!e34k0I09Ba`J+p<A'
    'L@^DSbphn6TPN@Ep9piM4RjH|p)Mt2!nlIDc`^V53&x#g?MxWUQV;ERU?fI1e*F4c7@=&Kt*=li=#X{5t2IS%EF?BarDIM6n#`ox'
    'bLB1#(UKU&QlyhDIM%{xMb0T1zJ<A@^BhCX4~H*bp=%wKttYp<s<j09kByR{m&$BY!XML4VsP0G?!h#i=QlhE|1F1%cb&w4&nLwP'
    '$Az>oZ8gf;Ai8N2Q}Fe8B($(LH+S!?bZ6-eT@ZOdOp*>Z;Wnw?M(tw6A&J#0;L2m95kjNQ<dch&{IHnC_Y>?V+sS=^qvUanK%&8T'
    'qy-qnHBK|~uQyAWoXM9-nFvvf-#twJqEz%3Kr(@dfg}Yj*#rkjToeG!$w=h!JSUR*IoY5V9-rPgM>J%ULE03;mw@ckZcm=1zx936'
    'foxoj0I(IqTg(r~IE+-d31zymB%6GRlsWQ%MWuYCGG{otrpHO|!z)YNsP8}BbD-xgHEM_*i;5G!wo|&;6yHc}LNC*;aYCjGtB=o~'
    'C%NaSQGe7m)%rf?DAh|MF?r`lLn!6>Xd5kl8@ZjJfu!3dO)@;J!C%;flX}s}l%R_9-vp`}1~oz9t2+X$leaN-0-OgxTL>=T_zUFt'
    'K!hXJM2_(i1cAhxn{9MWQVA)QIiRko_h@v%!iZk{TX3rC0)VF7=F*?;%)zBffbF%miJLTCk6_eVC+h<+WelA2RFw`y0L}WGYI=cS'
    'gj|5*Xi(D|U%ckTb4GO2)1V>F6wq-`AZLX9tM=3rC^hvb{g^<{)NBPz<-|L%7tMskt!X`Y`-CqOn%&9r#>@4yH>?RD4Pug!u=R4A'
    '#ia>C9@^%O;~)$G+x<kZoWH8Y2-R9r<c9AZZH$_jt_)qfLA~O}c@~Z~TtOK2I+%`tLgF(RXT~Vk>Sw+ZLuIM&ECAb|bdHq&_5OU%'
    'qdY%uoj+ar`sb*JCYS|KUftRof*RE2g3j}mm#2Gu1j=B_RQEjvauQbepZeClw86%S+Iyu7qqvg;v+yM>dhjEv%fe3JW2#J1aBD*o'
    'jV|B-s6Xp*VC4Zk8a`b+>cjry7AgQHy-`)LdkJ^btEL>~ZG)MoR#71V(@4pSxCz<!b9cdZpsP(qvHa$?v!USY6VweRKty+-exW!B'
    'FXz?S*wn#=wI?OpOaKY;v-j2sP0KUv4+^MEMBpJ;#+q&#3TLuaXj|x1*=5*Da7(HDnHT|8qw@i5W$jE1P#{jO=nF|u*c;O~aoL7w'
    '*iQz6n+3h{jXAWeZ>FX;upa*!oX2#>#-*R5rQbqmQ6;UUU*U<FO>(&p;SIjhelqQeFxri@Smtj?C%UF}uz7xR=CF4WrOP#KAEF`F'
    '1Kv*8KCNlVxdar^5B;~g6Kuo2GbPrGf-(K_4g-Y4jvTy7#APy<f$UWwn#mGKFX$P4!hYS~l*nYLsucpnIS1zjCB=GsMWu5rnU=ka'
    '0mN(ON+aP%rV3iHiz$hZMiKsq;x9tT@-nr6o5sVVd$2HD7m(-pS&H7boRXcRsS262jSSI+v3&aHbBWt>(GhhSmjAY3EV0GTpsJH$'
    'j&#_iEzBXEC1_tI%mJ;H-Z|g%*#TjpFi8$Nk=jDAHhkZ4T|(n2uwKkgN*6!p>&dbjx+ZD~_VTxkjt~S8IV^(xOM1`k(*YP!<$y$S'
    'lNroe+(TSgd*@<96~q3+CSz#SVE!f&f76w;gv?urwui_V7`z99*%BHYi(YzEb~@kP6mdzRomc*OaE|SP2#6q{TqVK{1o`6Xq9eY_'
    'yKttnDg2@umINPNF93wv_+n)y)->%mK3HsNmC{r=K%j<rhw6s42k!nU(<kjS;Q05XCCv4PUa4c}lfbZJ?!_ilF`+`4yBu+R-Bc~A'
    'nT+j>UEEP$!uCRun<KnCKZ7}74P<gq=vYZiB<Xz(_L-vc96ur}rRt><QR>Wa=ZcKM^5ZE&EMO@_<53kO{k!R7uMBXyO;Ssz+$+Z*'
    '@=J*c0dlQ6YoBW=?n`i*ob-ZE2uPJ6493A5b7RUlEBe5k0E>j}E!J=DOo@mgA=<WzGirZ{`RRW&Edj(XorWO~wHq87=%gOX8H_x%'
    'nel&NUqK|q*M?(ZHi;C7+VJ(G2Hi5p-sovOQYRIa5)`0LHneWqL5M&`dh1#VvY&6ewX~)Gi8h4Ok39O<2tv5A9Sq-UnO^g!lm%nq'
    'oS+|lmgPhNGMr&nQDrQ!gmn&3b|9JhXvtLGR~?H@ZXQ?Wu3@Ls<q`o7O*50xh;7tptMq=jLNN(>MFLXF6;x6zLuGIXcTNZ1Is!ED'
    '(gfrRa}ckGxk9zh%m~hrPZ>Tikib@V2pZ~q4DWo>HSH$_j!<(S{0W948$$4m$f)stPcot%7$M`)4d3qItlIg6zu6y9B5D-^xl}<6'
    'wEm+2ATsXpYy4-?dy5+Lh!vye*>rr_`5@kAhOs%_s>MRo33VKmlUtk9vSjf9o>#0u=RP1wK`ATg<6DIp!@;oND859vvPXZfHog&J'
    '(w$9@K->J!&@i$_gtv{_OpjghuJQfQ3<iaL$qzb16!4BXb-83CyG-cCUCLKNJxsvvQh|k6aHB;TeILw1wLqeCT$BirC_NBRf1n5~'
    'h=i<4k;@o(lr$dzQnP^rhywjoW)8X@YpacHtSu$>Lp7>f2>ookqPx+HudtslO##4kvsr_dw>q-dYiZrgdx|-6V3^F)UwrG;d#E?D'
    '_r?8A=2=FFW44RjPOl^C19%ycZk^yKzp2ywyCl>rgJo_MIzu26@r}A*e#UaWTga9=k=qvP1=qvhg-Cc@WD5J4)Y)24o9xaSP{o|~'
    'l@=l-!1mL+%se_5kpe*1&ADD0Wer0?Itr2whHc!8KyfP0>jb}BMYmz=y^JHiiL3LrA~Le&+w0WfeF&u+*Y^?#&9#l|gWQtMOKci}'
    'Eg?)6uh91E8@V;?8|k_ENG4uu0U?~&SZVhu0$Q#%OaD5ukibPN;V#Ja33*OZSs?lFt}D1#@<Y0d3JAXQFf6?qQH{xIj=ZHNqo9`q'
    'hx8FX_A+-IMN#DtToQC(v>3K6+IPS*N8WBgk#IIU_NR>f(B|P2CME&)E#*c3%=!OYF~q0f^j<0!R>U?NT#hAnd5Ch(ZSVegK2=M?'
    'Eu0B0r3>oM_r)wUtl{bXWi0-br|h5jy2KkR&`G-9bGueZKDum-tqINE`Elu&z*2=_l<X3gmx}C7s9JxG;jTEzqS`_Gtg~pcmtauG'
    'C$V`HsQ<K=!S7zVPCFfQVVX@7QzCYp>i+ZYUG<VErrC9&tY1j9Ad9eN;{I+;<A_bjOl&0G=+PN*oY1!;6JapJ=5xiEr>CJ<AYntm'
    'vLN6pNotqX-lq`)p6s9B>;w{eo{PGhdrdbRy2i{#M2a(%X97g-ZRC}WGmFv9MDW^|bWBbM=~KM2w6w*23i?fA(+4VRGns2GObyzH'
    '%1t-(+PoP4l*y-am$3De6VKDi*!)JPLwA~7MctA}a;yS2kV}@$$MI@IvI@r~p!Lew9${c;L6uk+<IJ#Kqbp<)&7g5JEFPFods%HM'
    '5EFjc*Tc7~$3VaS%4Zqjte1XnN!=Vx&O>6*O=La*XSKx%PTO%SKHHPWq-z??j5mqG;e^46>;fxn7E?ZwVtQYU`cfKCc38V706)FP'
    ')mkT<Lu@{y*jM%8d*_N&7er|Fe&Hs(s>Tt2(I7~Wsq$TAp-OZB26|f-A;bsc<3kpnx>x2FhdEBQOK&$6<k{2;LLK{L@KHv{UzZke'
    '5YiHMu-EI2bvggwA0<q|HMTzY?@>}Z)M%sd@@TmC=tYKFxFHwv+ld4ZA2Fz<CTJ0gD&<?7y|E8seX4g;OctcnuIk6onPrp90#^IF'
    'A0d@u!o)^Y3@Q-4^(zK30hzrbsji@0f67g#&NmFK*9+fOiB4&76g<N<IHgLu(kJm*oA_5UM>@*S+mngWWPczC=|kO}j(efNq>|ct'
    'I>-<77E3AhzsYUZUy$|A*v17_8-GJYqA$v?2G(r6wY9~$?b$^tb*WSWFSoD48yTDB7w&O^;Xt3;ni|@IyqlGmccCGBBJc(}KrgWC'
    'AzAY!G<d}#p&<<rHHbQOnL&orTKwVvM3h&t%s|h@xQ@iEy9|=oX&1P9UX?&Zp}P%Lcr5uWjpDw~*|D|aiN6tizAv58gEpQ_g+HX-'
    '%)C}>nTg)VI&19xIgePRYV)C0=`>FAXjg7*=nD|{oA*C|G)kYOw%%?kzT?dFj>H9!^6Y`O;H)_JbcXR)EyTMd1M3=uCp({;jJ>ua'
    'apG`LiN^K9I?e5OHTF>9jNpm_9#7wT?k9y_cqTb>lw~DI*U1A=1-_uP-?h_+9Nk7o0`4)fe0|-d4k@E<MLvM942zv9X0NF*C$nI#'
    'E?E6@*Kn1}shhjfYP&laUW1(&w7!QgqEP@QUmBTn)TeI(C3*U9+BB+FiA*9+tdp-ez@H@Fh$duNrGYP~zWUTt?n`w#3(m1j#y)kZ'
    '!WRO%Zz`^h(D6un`|*{-GqT<Zh*f;$ZAnTPKg+Yn7Zf0=Mg|{Q(Ec0?+tUvCjKWZb)tLL_xm4(XVGC3^=A}51H-j!;dS2$uU*UZf'
    '_|qvDOD|&1QBcA>ZYCkp>h`~`bP-R+%h9@K!JvZM=Fpxv9rxo6G~E^nLIJqF?VDjX(<;{djgF$KpY0f-yf`3FyvPr_N5p0q4vfYx'
    ';3ZJaaAGsJUYgHPmJ&GgCcGDxhFn&@haWj#_&-LQ#PpXnXi$uvK-+U0jb{8R?4pV1n*ByKob8j9_(R&`>7TU{#M8397zRe%Pdb6<'
    'H?l%V;(`Ym3G(A96!|>H53v>v?6MOFfuSgY9-44bN=~+F{<585z)weQSfL8ftQl$=t2{)9g(wyehI*YPPGNas@^GADR}P*xBV9&o'
    'ccQ*+8t{OCQ4tgI#a9vvbKFAUC1b+Cozrk1vCZaU>uVFYD-tjs%GA4Qh+tNzXNp&h#mPg;wElKNR8jP$bZ+&83oDd-`L!F?JScs&'
    '2}lU)jtyy-!=f>T=p2JyLFocfa#DVFJyf0B6abbP`+Vu+iknHqABMdHxbX-k`1C9S5ycg}Xt9yV8>kxWj}EbEJR}n^yF{ykCQ@u{'
    '_F5W7r0sB>I8eaL`B3UA0d!&>q?JjSieN>pTTz%{o_Q)q#8zX`w&gxvj4P0%>^3hr4s}?*8H{NVxvhby_&R${18s^ovFGk7QF<#e'
    '@MW7H4(S}*h2zT@(;rq_Ygn$l-L_z?V6UcpEZ_}fq5e6xFWJFol_b~(SYFm(kK~}6@aLWK7q8!i`8#y!s$B&A<`2j20dU8Iz9sRN'
    ';!3T4ZwAP<ZtEC`WFvk%D<cHL-K6g86BAtJuih0x+|<Y#`nu~=jkalW2N4f$BKNlQUmxfi2I-OMq7ou>&+uHnGGza2@k8ppzVYA_'
    'q4JlqfX>L-a6uUEM6^+7*&7n-gU$#{i!Y@sC~+)B!w*ih+z34WS)q{Ed2G58Cs8vJX2o-BkLcoA@bfg6#K)tN9zW8<GO~vU_W=A6'
    '8?m?`%5|CINMGzPs2ZbzwIqUC)+7*9FBp1NLTIs8E^gc<rl+X)GJa8q1GAE^$y^M^>TW~8g5|QZ*o#65+pMKNdlS8YMZ^HW=vziK'
    'n0%P|;eB?|4_u``YGZ_JW6KPrBJ!u%oIv0Dp%Voo796-O?P_)2ho^&GrH)wC`aIZQeIV9>MDsQD7I3RO(`+BGQx!n@!XLU^SUv~5'
    'CdcjvJ0*iruJhjE5^JyP!d5qpVEF{0R@ReXs~7nL)Yfp{v*M{E>7cmd2+yHWeLT*i;&WClVE#n?pOEmV9LH6Emj9j<z!NHN2M4pj'
    '%m*MDSV?~{Uq67E(C1O;UT}PbHg(q8MPmNF-vj}HeZ*=G?-`*L_X~Ose4e3+!frRxq^vf;M}dWK_#LV_moN7E7zKtokYUzTWJ%gq'
    'V71lUTdJ#$V}KpQBGNeAQ01b4Wb%;R17m;C#KikPg=py(nu0uDrQDFg1W$h<fGWLH+80=EKl@@8S@gx>U$Y%}x?pqFa_V9@iALvT'
    ';X*rV4Kg3j3e<Pi4zZ0fJw3n1?>?XAk_(BZC~|EA<|9lcd_?gcH_7%RTjl+)^5qN)DXaaFTTAK*d_Qok5=O^R%>FvuKzR_+Oo@Xi'
    'd7I24g|UuW6$6Ef6$SI5LqZPtShv8ls7+wgk;hk%R_3yjko4P|WJ-n#wgJ{FahEuImy;4J6Uw;`zY%^Cx-JXGbCNORKJ*rnDSBDD'
    'Li&-P-W8BFYSI4~K_z*u9KW`-iN1ZQl7a3Geu-h?_mJ=wCFwgqj^0=DY2l&a8&3r93tOYaV5j{z6N5AM-l*6V2}5UPGeLv!64kv^'
    '{HbI5`?KE$qH^6ORlty7xOvii>Zpbe!Z+|ewDzJ6z-BKqB#h;Aq9dKV@_8=B&>#a@Msa0M1k+Sj+xiZ)7@E?<gztYFV}574|IzQ4'
    '%u6H({V#RObPuZ818TvD6I?KIgpuHM%<1%Fj5zvbv-SLJ`gOBVe&4?x!lLc*eX}~Ps}Eq^5-_KIVru!1ZDCZ?R9v=aG%8^ke`nh&'
    '(}C>fr-ap?=&hIY`&{g7OhO#?;5+$0vVbFaMR3M;+MgJd!?WEZX}M+GBd~vNureF)m`9NJEnIlNDeqSyx5A@_)(qob|CMsX#5gah'
    'TCehsAm?kDrPD9KiI9*zGPk8@=Bi%d><6U&*^>#vh+?EcP|4@;&kYLoK5bCj^Si^jh6OMd%6(5KU9_YEnAa8YF&tJ414{AfU|T(<'
    'i!9jf^}LeawIA$5wSl9^JBRp<m0`x~at*LpCNCq;BykzzFZk1w1_OQD?rqne%~67M;BIh5a!T``jd{y(z&O~A+UV387~g8!|E<YV'
    'f!5Rt=O5M4JOP;00n3M52rV^1$V@haSeg+C)ZZRNM|tNN?td@m2Ge6xZ@&}aGCkQ8)1F-%&x@1xaR0{xVj6VMfU{e(fZif1B3PLG'
    'j1sdWT+-19`z&T6Fabzj5yxXgsb}Ivz#%zTUgPrLf6gRx3AQ$2Q-b7C6jJ#XvhjF>A0PR{L+xfnm}|Lf4urZlujOzfPe2Rg^D_R~'
    '`}OC*q$d;pazN2i$~o+mNEIPj;4wTi-I6^`-WS4!76!ox<onGI;hLi_-m>yv2VnIaM}RVp!RF49(SyvYZ}=M>{I9>Q`2?g1A7sap'
    '<43uSWxQO$4SNle(xC*IG-)4{hAr7S+3H!V=JG3SOti4S4(Ys*s9nSyX(3c+c6>lux_e}i&}f$8^iJXUu+R`zwsZRF8XUBXm2*!I'
    '1MyLAqPqUqV)SavG@PM1^}RBfLO$Agww5fbYfUoP>FE!+j?rA3?1<7m5y7tsa*U0c<bs=+3s9^E?>*OIn~tMUWU|KwQFUGHo{@$p'
    'BIMHVZ0PFvl0kFjifwv##?I7S5GRKgQ^y}ZB26graY8t@uwL9IZD%LL8tH!2Yo!$F^C;l8ERxsh{?l{R&eGmRxbwvt2dIHvtG}B!'
    'A*&lLH@CGuuZeVBd*&ZMP)-83{f+8)=lJbaSMJuf1Bl&0k@)Xmeyvy@KUt*UVFadNR5bmYe_1w(U0Mo0&(2Y22v4;@J2B%Q{Q*Wd'
    '-s(X~YB04x@Av=&V+z>gI_5uU0#CBJfqm%xm06-Z{sk<0$xi<7<g+kvUMLNp_k8RFm37-l8z%q=Sf7mhL75YhAUkO9GS+i;eX!$m'
    'jpB+RmvHVAg+P8{8x<^Jkh?PgDV+a!m8f?$fqbDUJw-)ecHR(2lRHQH?(7bDe2j$yN<Ec*G=MH^f>noODz}PgCix3~B(M<?EOyl$'
    '@qywY0t5@^TYVBGL&gl7m65t0w$N0T&D@dHCqg9|JLX}^1U&z0Wx`xu?tyfFU=@0BkxU|y=%<?waREl1x-Az)-IkmB?9KI#!z-s0'
    '2RVpauZANntBn`Z5!40xCZ_p-Ek;479-61fR4KXsn?940j$4_IM)N>;QD<yx-><H5t@W7aWbgwDIY$NNS*6<2wKzBdE7jF18zZ+o'
    '5W0+_>6QlSbPB*D;~xTioACZ&fi@peyg<4tgLQ6a{41G>_q*fF(>Oo=g7ur{#_T5-&gn&xQNyjFi8m9Xv={gei|1k=d&04J#BZSz'
    'J@V+?yOpG#6ZP#{C<4;mTrbL&Wdzt_oQhy?Cwkqoq1i{|qUZzb>>Bjyrs34SxftrtyiG2R@fcmtts+p5wXDJo=-YYg=kE2u1r?l1'
    'U=6pFV+q9ltiU=TMtJTi(u1DUmuESqzjZ!8KjD0PkGYCE*^H;Uyj^WUTHM=pJ!>^msXO+oP#79{A54#pCnw<zY)9p_)&+TE-<@SF'
    'h|+Q>p`9;r_)0Ojmf17xa>4IAW-))!vJ!MEHcj*$&I7a@nb?r2*g&-{W9bEtDc^1llkH>IBRqsOm?y=#6?(ykDFJWpGCV8Q2{j`V'
    'NaiQ2F82~J4XrU`4sj8IFaGE71{wA>i66x@v6c)NDKyel5C#}OyT_$Otftx#IEX877yfHM)vvuP_GbcWp61uzeqw%$MVeFjfo!M1'
    'hOMD};w(O`<+35xoiTRIQR&{pdb+m?p@##{g~l=w^86P-GsXv>Soq8BlI$J*dw>y%Blgtn;!n1y47(6xk}D!HcssVrFT|Hn>ZXB0'
    'GfOY3^wc0XcZ>x^$(k|RVw>&WYBI}eREck!)(xD4t7|+@iY)0Zb2C#>EB>5oG+1Rb>O;6O<s;;4=n(<S1$^GV#8pbwvc?mq<jGg3'
    'Q=)G))!LoH){dKAvoxzDH|kV+=(y@RnDAUy>m1^;3_I?iku96rLO^NUC9hTgS|1$`M@sT9y-<5^Bym$Qen^2@9@Se8jd}E1lm9Ft'
    't9=O<AXjnSO_Jj##|a!tfp*<K`ypE7yXm@L{nUpDIy<C&LxLO{^wKuoqr#;?5rx9u8duJNqh{<`FC_G_kaCD`ZVELS=T>g_?k$)Z'
    'ohQkORa}D`OydZ<+LToL@Y2V8Yk_FbmNbc3Ra0NpqGrQ_gW*W=5t0{tZ`hcnrw;M3$t~q^gzN>0i*;d0obrOCW<$g2kh^b!4!$fh'
    'AQ)^qH}6z3V$BH@E&cUhCi{DWWw7}x`!#A|q&xKX8sY++FtDQTERG^qHxI1S93y`TAD19TUF?-a>BEj}QcMjEP4G84d#pdv54tLD'
    'TWi=mZHX(@qyOPXHxEg*!k0Q_Hm)eyaP`CBEb8-)g}rLC9{M$ey_?@XpSD$-qp2INNxi%q05gVtR1mcR*vul`|MVs$A!Jdrs4h9M'
    'SItq7T?#UVFevJn;pC=qA*7cXG=1|xK?lADmp+7Sv5_LBxI%gSB#z7dX}j}20Y{O!^=f_T?fFwKQw(J+Jjg|e^;wfh`wxPc{H6iA'
    ')N~|7N<$jBWKG{gyJN1S6s-am<!WDd7x%fkK?yYp+pEH0BGZ^Bsa?Q)dT!?O^ef6n%VNM`_%~L&zCuz_nqw%h!HdVWPMGE(JLqq#'
    '6%G@cTQ2y%IdLx~VqCxUfGwDq%i#qd-CT3)nHR2a$itH>pI&5NYLe1rnko0lXN-xL>ShlQft#<@Z~Omg^K(@Q_Sks@J?)d*ErnJb'
    ';6l~I&F<<Hb8_lioWX(GaF2=~#8&_-A|nAjC0*3TjefE<b9$!Cv-iGJeigpiIJd4Yx9LpgeywAL>;A8vdGijXJCJk<^qHo_oO}bA'
    '5YTtVg8^C|^mlXf1Kj!#Fzydtl@7OU@ycHK5%frBK>AOxXCSDWBIsh{GO*Q6CUToG1Bt2-fc}D*hs(#O`8Xb8l?skQ((%hTt>IQr'
    '@k(yq7k1sK2=(#oUs!A@d<A?Q<z+g4(%PY)mQ^l?(mI?bZIj=a23#>>+ieqfc;1c8#M7DEd{}to*~nqo(jY>}C{XXrWWB&kH#a(K'
    '0Uy(!Nfb?S;3-Lnn)NH+C~(YU@rR~X(<TgXiQHJAzai$~p9kd*#?p@BmkI+1>pO+cB#j0Caal&d$Fw+rUo-(|hViw6e?d$hd{*?S'
    'Zh-Y-I6#8AWrU<Sp>2*vcJ8%{`R8b)k!zM5tyIol9WA5uVV7~B{1y=s+gR>|z{`LevWXy~`$j6jV=qKDAgF-e6>yHuw5lx~9**O-'
    'wbTA8PF<KQ2Qd+G<&U^z{h8!DL%LHvEvVhl%DC}1kTKn33qO~ad3n9zZZ=*iI`35E%rYSro3p@C&Z`^Vor;DqeYz<EV))3`7)`t2'
    'XHlKq)d=iB5=EavC?a=UEb|CABvMJ4XD!Y}72`l1M#+997ZM@L+fdj1)cRJPQ5Y_Z)~m7lj;XdXblx-BlE9@3yG!ejHPgLt!eqFR'
    'm18htmCc7Z=UVy)slA73d>k|U`gm<(_~e-rHrqvgcuJybcaHXP4ipQrvGr+TO0I&ED;L#*8CyzZJS-^CC7lTSz@b=BI{ZP(7{{Aq'
    'S0)?>5$I+0r@Bl&2lQCJh|hT=12Ej^NxAsOmmoom$QJUhOdZtl5P66aLO|BdJF>;t;?S#`c#m#DNL$u(Zsa#Ve{u5|CCbjdJ6KmZ'
    'x(5$P7~x3alO%|%<T8r0Hq>@QMRM6{_TY1{pQH|*M{)!}vH1<g<`=+98x~J73;E?z_|Fr2MO61PGj1Y{%V}Nih6#=tHVF>aITt3i'
    'y#XsW2&-q~(~z~2;NlZj>X~unQHb99T%U6iIqfY2uA$($eYD3aUSZZ=E^%+3rww#LG^{UUP8emqB93f?Hk-Np6V?=%EMMEuUcw1E'
    'b5qSSV81(uqYY3-in=GBFqBJ}?#;@A2)to+AaZ5oA3;5f7f1!nNf`0*j{xv|oR94`X=_zpvD9$U)AiTm68S%Amz9t%jJjMj9)uV3'
    'n930@>$yG>yR9nuljwX*kfv-HRx_17`(!A#Q_aNm)7;gjXumz&<0&|2Pa6XDXe6q<&yv1>6nNq#U6M@ZoS<JHWx=k7)kQmKOYcqW'
    'R4__35M=fa1~ue$+uu|l4HG5a?7Gpf#jL_CG~<m2;wtLQ%TaVSuJK<S0(ai`Sr9v69gO_b539g{-yA8Th$S#roIRGN8Qy{qdJ)jm'
    '7aG5NI3=8H*gg{2N92(giTNpFyI>uirHU|m=|Pux*R7hZDp9UdAJB$PPh1R7u0wsO4|MuttpQH9a5bSq@^uYKGtFbcL=cq1TG`_l'
    'f}Hn>jdnd(##J}r3k|I_{dRMUPDDxd0satLP3p-yG{-kk2rSGeps)#EYix8!gA-UGbR%o}xZSX>-$i!D0x30{V_S25d2Rn|$NcX1'
    '+IdY(7Je-?7LG4r`Ba<fk7#C%=-z9MHGuIQoL4Wu(ES_^*4tW<rSFNe3}WtC_|!}SKc05#7rdZ!=4Ef(hm~CeopkULz)tm)Pg^#a'
    'n3SEfjzLIQDp9YY0#Ay<WMe0p1XQP6LGSkF)$rA<rT!kBgsxnWchF&ZhPH0Uf@IERHZ|TnZRLjiJ6G53lnW<Y^UaD}a<$z@XI~AF'
    'Y{zUh4C=0allVE6vNs_~!_SWc*Rs+*{f)w@J|@Qk4DM5Q(Rs7Pge@GAdrcSOOL@D-%1q60H6xRkO;v@v?ayGb>B=R8yuqMYbUj?z'
    '<mAcZr?>uC#B(%##Wt48;u!}E)4$|_%(gACEKx^-cD-%!dTU9WcXF*OcM<MgRY6oIU|Odbcqc`km9(O<^3BM9xQyu^Yy-Ntiv~p9'
    '=SQzfLa5oS1@)7@Ax7{lbJEyA#(^=mwqLwuAMuT+`+^*gRu(rsu-*#f0LJlR*)GXO8wkNk|B6tV?AkPaz>*Df6QK6s7O63<=*1^K'
    'E*MX>aG}6dQoACQ8;k{IJnG<QzAj`iT@F9%5=sy)jeRtan^`;!8g|)R*e8k#r9$y*Sh1w7q1U}t8Q_)1YuNp+|J}dg9=QPBV%X1C'
    '-zp(=?@@!o(>K(8%I^LWZSHn@V7lb;p|ENck#!xF|6T+uHsBfRH#C)gm>AHdohO?t>M2`tw{SZSau-U8YVQdsNZrq^5rL_=d|Q_m'
    'VM6vCDOm)JT-(fLZ*N7NlA-}<XVKCCkR!nX^k4+dv_JZyJP>z2=0FLx6!097m9WFPbUoj4Z=mP$8+Os82<b?Q-p1V26^naAdWfnB'
    '%BHXbe-VkXN*2kjkAwPj9l8JA{(=Ylc!YDI2s)bD=}h=hA7EIU>-6AaKc+?na@h@}H(m`lW|SZZ@L;+k`|2AoqVC=4gj`R#D)$Qd'
    'xO=BtUdi+;_3;}RGJU8UK#aXJ1uRZV47c4j<pq4S=yEzxX=g7cS5a|jjN**osMLz_#2z)jeAhCHhu4;r^B&gg>K)QmLitZCA4z~%'
    '6+ymFAEHaNesa`t0%oUk#9sMjia9-??kFJ3p5+@(*_tLfbS3*8p;+Hgggqa*W<&JjRT1B!MTymFViNM+ftP^<Y5UT5kgi->ihefZ'
    '#IGW+RnzQz6tyb!Kse5jO)=LO!1GZ-X8G87=g`jdOWLiuN}NE%ijF~>H@~Gi^ef)OZeK8<D@h2P-C|+s5Mu9~Q1uo5A#@vjL70T7'
    's!6!I$hnkO!m-Ud7ypUswdNUrk3D?Vo?&8)T%gcp56~~wy|Nw@PVW9Zh<eNmr1Pcn>`Ytf(vZ2v%Lk(&LBU|`G5+pYZI4@G?hSk6'
    '7AJtKEKXQmVx=PM-w|6?tMtVs&=5e&!d`!{amrKp?0<^^C}}(m9S+G=T)WgQD~lGWi5G$RwzVHz*AD6+{O^+Q_TVS8R_TkLf4x&^'
    'G}i?Kwbyx=Ve@SxAG2HZw*g#FY8|?jePhX7P0}H=4?78di^1!r&x*Ednvs#*mp4<A9+^eZ*}@*V?s|*lx{5fi2|%vdeNx|ds*|o}'
    '1#Ykk*Ypq*^E_xu`3kWTMyykJ5-XM9CaHP+mO#T+@*Ivt#oSI_lzkGEa0W3tkH<nD@6t<zk}n_(-Za-BX5#+%lqe#eVr0CHz#<Lg'
    'i+B8NKx{0s%Sjkbpr(z)G&GpIpXE@CJxeaab2v5_GEzW&v4oRXDM^5it8kj|K-Jvdt}qzNVLixqsmM9tqgJlgMploif`A(eOSr|f'
    'fPeBP8=*u*coSFMZS6$;D7Q5pQa-$%?^g(s9z)TAm!`>2q)ldUgFu};Mw5!e{ygg6sq?(yrAOi339dUAn1d-(r>Ktzn7`m;(lIM|'
    'tX13l%7cAYE@w*>*=b8n;wn=d=55HXJgnY=-D0$8jwEnEXvvNT@zdI2C(0q>E`LtqqdfPkj}xclG$@&HCzsp9B4x5nFXTu>2bzBg'
    '$${e*M9&X#1%O5V^;xEOb493g0zD>eZyxOe+I$@>8?wVSk)u2@&A#XOG!I>##@$3WeU(HoXV~*Fl}}ky4C$#BoD0{haJLXfG~q%C'
    'm{Bq-;RD^rO~2U-UR#%-#MtGVlf?u1v?fzncXt$FDkn{wffA{8)=|V@Q>9u%%^VrxAWdqW9qUO%by~=WL8)I#uE<TRrXkV{=4pk!'
    'd;l)IeU3mXI7CUok9~3}udi+BxhfvFrh2>9E)lmoE;x4QN@hYwJX+jJ*K|f+BxS)AAAGk7{5XpyUkb*d89ze&basM=OL3L4T*rIy'
    '+*%oq_EcEC%kF;~3k$O4;uSI174Y>@LnfV-lUpRB9ipBG`34K&OzQnGiu0X<pHZ1V00|d%ES|^t4Zl_Wk1jHe;@0dOL3BqbIuh&R'
    '6BZQ1l+r}&4t0p=lIXFMVdIoX^S{Txy3av6S1upgvOekG!Dd#F5oXV5<O6{Ua2S3LZ3kv#RX#$|_u)2wu@!$Z&ehRI{<`zz+@<{~'
    'V@I)Oao`eALIWl!QJNfTPJZqbEKOfQum8de3-H{J<9v+rnHkh)S6e?7w}QCED4D_(isNlo#Km-`uMNeGPrneeT9v}ZT~nt7OFMj+'
    'hq)H$+V+GDD^@s5R6l1p=&1;L*DLK_i6trw&Dhjy-Z=v$5qxkZ9y71?N7;SFK?B3|Pac(+8r{5?E2_uM>TNWZ7Oos#_mTXrG<$Vo'
    'wQ+w{YO8Qq%#*#&NU_{e@$Ozay4mS&!QvT6l<|BlcInA`^J4Dsc{SX?@_9H?RrtLZVH!0WwfiC$`C|<&((Bms_=@#({J4u>o7;s6'
    '(c~nET-FOY_(^3Bjk1`9HAAAdN{Mj9-f4I&1jvilC>hBtf;qp*+N2SWfh!~2?nVKM+SO#YzKSG+g3QoOt}8%{%&lwHT`A1YPBI0z'
    'o$E6_l<CqOy0>BKPN*PMqK5zuL8fb@aqH)3LRn{k6du_`C^28#YjSw~;U%WepiIfZqX+ofs7ru8nNgos3;jO|x-}!@{MBA#zUQro'
    '@X&$b1$m8IR4ob6wneV3R^nB8$vupjG7Jeo%ds+w1fhKbqksHStezHUjq{Kr?9R&!o11V{0L;Wloil$5|95YBJP%xD;AnRU{_799'
    'Q$`TF9~M3qez&M#1T&_Oz1AXe2D1DrBhO`TG3gPhZ61^=*&`*uZKO*RD0(pIWTm@)%>{yvgTe`eI3tRN^d|J!t{)8cZ=iy&+Tq&Y'
    'p3{S0QL#|O$ixE%Y`33>;h>u0Wnw^Z<o+@%E)Xlr)9O*HH(Vj@zpsOiJM$zWNYat!L0ZR$7Pf3qjgDxpKT0{aR4kgi!hx0^vlzE$'
    ')7pp9$61j_>rsObjNMljc^5mCKx7XrO*l16)Z-Rs*rnumhdQ?y7ZCZr`dl8G*|eJcx!;q{eYNcMry~RnPC?`EIS#s5=904|-r+j>'
    'sTXbHjvag~5Jvd1Nsy>&ru4huqLPIhG^*2}1IFR13%5?hWRM5Y$*L!Cx^5rV{`i-n43ij3x2A75ZaO~GUlve_W2ZQoJ4d%xRk^$B'
    '3Tl9EUl<GC;g%F?p@zAPi3T{BHSijS#dNtM=aR&vVCN1xkD&Ui+#f4bE4z38<Qd{89wtoc?T4Ot#5jGC36fV2B$3`8_D;rbfve2B'
    'T~ex>*N5Bi!1*B=@07Z09;)5;srJlBSWmrGij>xXRtamh&P#0XW~)!jc~Jt|N$F+6)^t-dO$swaHbMKcXD9Ntj-tX#%{NwG+erPU'
    'vH8_FuTe>6=Y-_;MPzj64rU_xu=IIqZh%#@;Dh@(+YLH9=8QL8a5;n2b{18F$NB<S+Dte(%3rgGz|v^#h!WBL<To3@B}-lyGoY3k'
    'fK<_8j^kJ};^3Hab?e;D14{3ELPkrrJ?mR-(4#BU5dN_6y)s`A_e)w}m=ISAkQd0XfMX6?Jt+<8$>m>}U^MyN#?9@ub{M32x4SN)'
    'Y|{-(sg*MkBv+3ne54OoQ3%ml`yvtnns}tKXbs5DPJ>W@MwYGQp2Pd6*92%%->9m9i-_NcL!%^r?jWGbdcd;p;h1ex9`0Hs3=-=1'
    'Q?F|hF~Uk`cypj03pgm8n*b<(e|4hbas)$^bbD10y+_#<>R<5?|7FaNC4K$A`jMF=^`|r+)GxWbv+wT&1Y=)=hHDHf8RK4@ax6-z'
    'ZyH;DxBh0xYU;f1?=3mtmiHCxfwn>-^qkaxk1MNZGPG#-)AUPEuLZPB*8MF3w^MP?I8uzK-GijMUbCrQiZ)Nv5^;VB@$FdnlX_F0'
    'D_^P2pw>k;+24wOa8$SiJE#XX*_l0zYk}bWU0%PP8Br%}Rd0#<5^317Z?s|=tTKAq4&`2q9~s8evTR|Zros2jhu5EVAl-uku>{X1'
    'kolx4@D=#9PhhdM0iEAF-gBldgHr7#YJvsrMYKAZcZ<F3P;ny;W%H+c!8U-&Yw`6srKh2yuKHBfp_*M~x=(5AK={sr-U=02DMpf3'
    '-m2bzhpoY%`{E@kp5Ejy)<ht7BCR}ewl-RHz`g=6uohjSIS1=u8B(`%-mVeZRp1EzNNik<@s}-;uJV(<g5_q!^ZVo->+}5XpMuLg'
    'bw(~+bX_m68hIk5CLlVJncjTrHof;bbIjpQH+oMBB07U2r~b4!5zG7vtThMCp6{M&$>YhueND=f1gMz!L9STbrV{-@jAEq|AJPG~'
    'x+RH+Z*I5f^j&YD>UEFbJNMUHx`+Gs6l5L&CI1fw<}?iB1nhAa&JXy5BW(*8XjLcy#dr41IF~A#A7nHj=1*|(gdEsR_(n=KY-gcx'
    '!TK@J9Z)pqP#&nGTw1hauPk&)kGYD&2AU@KP|nPTgHB&`J}LTIfFydZ(Z>4?0g?r=y!p>A5lF7b2|jxGNSu}rG|xljLvg$nu)Kw$'
    'ioX-LfG-<W)hP#QzG_k}4I!9VpGeJhu_KN*%=Vu+jz$$6f|PdNh7%=Z{3Z;EAn!v65A{9d-7%%ex#ei+@cakoIQk<mwx*y~wlUdX'
    'Oj}0LvDcn~E8QYOWTW-_EHP`*J?y|boYznFX<NTc<V`TuEoBTAU@j7irdct7{Sb>8Bz8V1d$iL2jx({Fzhz}#)Au{&FPS|@dzm;&'
    'u}qLWbi}cGX<@}=_M`8!75X23+C)bTCm0@{UHqFUD1Ib$rtp2yuf>v{2(^N|ah_`B0|EkxzG`m%$dHLcgMwsw^9+j2H)E%p4&FO0'
    'wDIC#Q3GWoT^(iFd~zTahG;4HEL`*5?w)gSHj9n#c@QmVLTg{yB-K3JqPCtH@+aRs-T@9p=j(;xrUn=7Y!`@u$fkp{Len$bfE}2N'
    'ATBCU+)j;7w^`4$Ep|$y3XXitU@j}sg$3D_r9?E`60sH^9psW9(o<MMl)x#rW!iu2bEdL*0Z=6WzJlKoUt2Uu+!f!rAMA{Qu^tQY'
    'P``efoVArAh}PG3Jp*KFxhv}QCM*QnSnA^OoE#%YNVq;*TX*s<nI0i*HL{Z}KO=B>SYQ4)dtvT-el>-XD@5_PqtK<K&IS{i>oM>x'
    'k8#0}>o%Lujio~G-&Z5fJ_<pR5mL&p(nHN!V~w57P}Zf%_kAp{<2Jg!7;=@n<;NGk0z<S$PG4hP<R|(48rGzkM))}1HZnX$I02N%'
    'TKw)ta$raqF+Ccqc=Y`Cj?_i58UXt(n#6``i5^eghX*q73<_mPjrQvNoj2<WKdX-Y=JT{>zP{jIg<806txK2z(zmt=Kvq|B4zOl-'
    'L*?EhGcL+Pjy#T}Tp6)}eN(bhqg5K)tneJt{GuQW+W+CMF(b*2(>!>UaT+rV1AjZ1;e?5XqD~zsYKpM<6Hie2%@7ICiwq*f(Opd*'
    'Yhps$KYX?vTJ{>!Pave9IUosxoMAJg*bS+nPfw&-@J7ViH$VbHEF?F{n#DZPwsG6Y-&MQPbz|D6$8wh(l`V&(M-gnGQF+DOe}r{+'
    '88FsY4`DJ2b<n}S4s2n^i{Eg?(gMXKJ1>u*Dt}q7$5tH@gccqL6AI*k6Y}{)5&bj8Jk7qnT(dRW26z7I7j|8>IKMVEfkuH5?#MIk'
    '$5j*AU9PjJJXyi>R%jh2MDY#(m@pF2X+roLpc-5VrQ8*L+aW4l!5($<dI?G{wL&v?am;Q<nBG#wDtU3GFvC!)@+X$>QO|q}pz-am'
    '&io9WL26~ago<+2fnz>ms2bKKyz@^L$i+5NT`vc0A#xKJ5nzD#20*Ky$$!<}F;nvp!Wq@oT-sEwLR9{F`-AAa_`g;{rM!%x<SU>3'
    '^sn4m?$2%4)(XAOp3oX*jk~P?p)F9I8tv>kv<)QEHTFUH8a^-)JwvcT1@|(UGwj0#sxU7@_e5msVoTs_l}mC<>4&akFCDA#y1sui'
    '6NTRd?BAP%oR0P5YPbD44<qxT2vhHeibLaxI9a|o>bc02l`wVz2Vz^<IjkzP$~%|VD^;s%={#V(hIsU)z9ncV!TH7FZ>iITTD~j1'
    'z^&HsxoeP5g6$nyzUq#T7=Uq;xVF8ai7qa$Fq(WF!TWNQ)x-s1fuQyacI*o@<g54|1O^9rW?`>y)LL|o`3C_7!-SC0<fc(n*N$oX'
    'DFD=@sLPK2H%q;y{f_2l-?T<rOzYEexuG?iK=YK12D72xDKN<makm0CWItb`x|Wgm`8paL?uyxO+-~-1lNhmv73uw82{|f=ccY~U'
    'UOGQ9$lN{u^d<aRO=`~Ei_zrvT9%-}$YH4@W1-*i0-!lNHu?tp*Nr0yR_D3h-4*=o!>fSixt@Pif^=T_c!ThD*=vX3B%**2mJB6z'
    '4591jFP-w*Q+~S^mmq#ceCn?CAdu?Jf#GK`tW%VH)fWgy0Lv*}#YByfgI9;EI|*0hGcRGbVzF^ykyY5Pq_6!hG#uT}Cu`{KMG4!*'
    'QlGu<1shGw7Ijq}&R+v+-QOmrQE+r%#bV%wTl=4s*1T!!AJ61o&oF)_!o#ydc)cObpI5(nr$JHWH)$hsuvZ6n9}S&By!g!OZdPqm'
    '@pln9+h!nnqnh2qIKtdH&)peV+#Fzv_VMX7YhYY?jn~V@e5H6Dy8HToNe7hXs-@MD76JKV`f%Z{tH^deM#!<7-YYAiB<;GOi)tOw'
    '$aR~pZI|S*lC|h!ukrCApgZ`zT<0DniipTB6@c3?z9%XUXp1?d*^xvyClEel!0o&3kE>F)z)%Sw1RANXqI7UQLT#k%##qK63xyg~'
    '>H`GYMPXjcmM1|UO=h@uNHGHBM)gM7f>js<blx)}zT5%S|8qB4RCY(R?mtUv1nGX7hkv)h<S@ZlL?@f^g2cJ6tLwv78<dVl6Mz92'
    'diq67fJm0tRR8qS(_6w(*{fsO`Pqy|T#xg1Q_iz`haITAYDgY|b*t&(7|Ac_S9cLK(~r0Z&;>Yo)I%Jy_VW)1?ot@E(EQS8+%>r*'
    'zqbwz^;1)ip-A}19iKmfcLXgEh=Q7?VZI1YZ$o%1ajMA?3;PemrndJwyC`2n;G`fp$se9$3=l)YG|v8Q2bKg-Do<Rj*=0!0J!~w9'
    'aEa^=28eODWCf&U=%Y3FI~dxI^xq#ehIT`f%l>%!tK{crzfhZto)$;~KrHRWy^r8`f{S$Hst25M*x;IJk+$6v8gWVk5XQI6*`5(5'
    'm(f*+&W)(+3hHrcj|b2<*F=S)fl>kJ$>ON~qKJQKz%*l6cZ1CAMSB^cs2PAf!xkctsX@xy=nnFEddgJJZdOkg*aw5lTgR0Qv{8=A'
    '$w@!nqQ}@bGQu4<>hWvv41l!4)(jtxgWB!$3ssHUEIZ7mm(D{K|1;?T@1hLBT}btKKTPmSrrjNiJe@|o<nkOR3jTx<C>-YkXCL`D'
    'Relqo;|v2AhiY-!o50Y_&Z3~>T_rYw(k^P5;qYVIyWdvs(9XYFmUdq^>|?5_pvHMs=czC(bRH@D;!ldlkOw>NGu9%+)Uf9LW&9!*'
    'aKEl!2aQr{Ji=cr=9N>209->{5gfNXL~;tjhBRyx24;wvPktp$!tiMPXSEZpQZ0nKM@2P7?y14FcW~_uBvtM1c`L1d!G#Mrg`6Fw'
    'L2dQGMm6^r?_Sn1HaOf=_z~{*RswWFRL~c_E1yHHZO+7wqQW$^9KnJK5jV_dIM;4&Bh<>Xi*=^z#9aONK`qNM%}D6181N+1N()%R'
    '6A5p|5*^mlMoYwAb(K5P*p~8VB#-glBn9F_w5bDdkBY0z18%xs5(DD{Nx-Y1ptMGsis#1Mri8#{L%AqqltQEas$3u9<?N+yJ6!fA'
    'JYJF0*(=cLV|eJS6c<*SL&wgFoA3p1wkGo{v03M<hilLz<_mexx;cds>*XZ2JxC@whPLF4@vYwWT^9zHY;5~asJ3!dySt3%u0cFk'
    'y|G#w065eIfiU-`F>VPU%7ljuXwqBvSHIF-45U&De*hL^cY}uAl$Aj_qalYhYW_53P3lBrjsRB!Q^D8F+(E%FZg<{1XA_af$<5^4'
    't%Pb4dQ+h<-PDgFi;53}9bBu`LRo^aYA_&w{~)?_873X<0gIgUlO%Zia?iOM^sI&T{d&#~zzmr@a6%6XRV;t_h*$Hv$H<Lt;sa~r'
    'A%N(c_bVV~x+$Thof`f?PdwhiMxMZ988LR?saLFA!*LqUC5DA57nq=<xtViWI&uh}SXH;0mPn2~^2WrmU$rcKt-F;?+W30;+A$ch'
    'ZTW17Ak=e(k>4*HmKHh`f=A+KS#KaLexOk6rU6d}$y^N8KU8R;QJe|-S3`dn^GI3fGuS*{>$=74AhQM?Ynq4Z!ElN(*(A1|3&mo>'
    '!+_xw^<livUh`-tO^$Kt$zzh(IyKJ9V00rhfrd({f^ATnD~frwBZlS4OqhBf_(>x8bq0hkz0L?IH=^zbSXBcs_%=csgMilFqU?ir'
    'mtytdnk^Co<O;_NsVifY8C`j3Voz-x;glu?IkzQmZT{HZP3sCyR)|dyFLfv3u9dPQy~0oWCKbP~#u4sO#AO9W3$0Cs!;6I_Mw?JM'
    '8edjM!&HdYNvk9X&+|zX>^v?@G~R=VMz;0ys@VvsY13{Svh~lm&{Nz^oeqicxIQ1-VCAx#b*ydz8x{ttZpc+{(eKMLgpG^tizOKg'
    'IvZ@NxVp|_T~ac@;UdJ)eVP(Mh8j?vH1A>eumc!dUZuo5^-4V#K6_zlje0(|%HWWLaPCP^Ck*fP9j?@CqKy0@mN=P}9C*MJEECpc'
    'Q+_I`Gm8E>EFNGdok_S78@AGa4cCH$vcdj1FUHxAJs@CKVA$;doDhGSdn3Waa~-wbvtsni7TGADRD_>Qaz^n_n1+8DnCu@Cq@M+p'
    'D;5hOP=jrA*nJy=eXa(uZyQV=OnJ}NsyCsZQiW1o!A)StFynROEL*(ebknXq`qV%K_mq%l5$5X0998~Bg(Y4=?s1Zc*N@vTk77^l'
    '^o$M~Wu=GP4mT&H<^%j1qWs7@KJ4>q6-p3xRw4f}*(I!q=JaCB0Fo{^VP*Y}RZHogdS>g!(r3}SM=`jdZXl=Oh!$C=MQK8aBKBv8'
    'O-+<<Wuov8iwRa|_=L4525fJk8}i*_ee~GAICCTO*(BVGmvnB7);Q4#L*KYcdtN>&HQ?#cFM(Mon5E3|xrF?)WuK3CRdj8SpFvEM'
    '4L32%-2|$^0g%8WSg`yK{;`=6`8NU?l5qg*fYs28oRU0TYg4yf5`ipp&POEnhRnC}67r{A>^h*T{<n!Q93Ci8Z&b~gqq>O7fs3_e'
    'YSEkaIA?%F`PuBQDzo+!`Cu}3F88XiY3KY$wKmRD7L>fl?X*_*I|sfJctWpb25R5}69M`T!ZeT<zU1sm#`wWo>1ga~C2L^z*CRdg'
    'lN$~<T250%?c&EjL)ns4pEbGDJZXbm3=XN?v%Adoy=2iW0DT|=(jA#fYzZy(X3Ht9+=O!wtV^ZI?CwZl*4&TT0j79H75U-7(PJk{'
    'vKk$i2U0`G9@&_8@%?W}PRkEkRv&L9OTyH@fo=h8ELXUZW5u+zEm3F9-igfXo$$kmu_mQx(y)vj>V#BJMg)1kl~O9<e{-`19mcJT'
    'SfFUwhSNq>VY;Y2%Ti2MPRrZ5K~KBQ;}s8U$Hp~;8@?HS_84oq(;K&ELjvU^U5OUX9C|+J;d7gyac6N5%J_5iQ|C3PkvcN^eBMpP'
    'dk^=>g+GQ66nbX)j-QHPO7JpIEV;q4TVTARQYlS&d)C1h_Ek9Z3Yj4{PUKCbWW<y3IZZ);;w)SCl1H!7@~5wfuG+)aCfoU4CX~(W'
    'qC>!;QEma7PX1Yy+O`V{R`y^qpdwa%`0zu}TR6}&UhkS@go=XQutzjEOqVeftD3S~kVWf(S?xs$=tB0emmqg?SFtE^o24!1HO=$f'
    'bML1}My>zXrpEY5e^Ds7ZYqk3`X0a<2uI5;TO8ZUEoCeUz&rpC6J-a;-YY7LV1DT|o7c`3kUwo03nZh#MhDhv${{{7zFdvv7O1ad'
    '$~`q3@6f4d{BxCSL=F+z?kpnmDv0*;!O<+uLXjUDZo#mIr4Zo}qT@7GMU{ZddWiZ~m6=nopKqkI0N+_#JMQlF;eLtrPY13tE-w*!'
    '0yPHJ0`23uL5e;hkS7hpdtbP=#BW7S!ow-|E{)<t;lsQG-PpMeTOCUQv}y3h<@Qa%b}UVx^e}pHE`&5ya*-7m(6t3X4-9-UDkDKj'
    '2KM~6iIz3Nk!UJ4FHn*Wm^iv>-Ahcu1=QFEJj&tYFPOFphN3hny;TXK1)}FV`!h*$RBMk+45SqTO*D#wdR7F-o<`DmEb@F3+GH(3'
    'JEj@c_gQJ?0q|f4fq;&5-7&#`DRyK4eBZ$QM?1%S9Et-rFQ%v^YA%icezoG7AOF^(5fVzT$CAi1_c|gJl5ptP826oRiKuqvvfJeH'
    '(<;XO-oQhuE3U}vUNw?Xg3eH7T8SZ58#|q_amCsWAY=j>FX_}87DA49V}Y+cFHKF#b-E!KoL<8DK)LkRtcoDNk0m5QGWGbW|7dm$'
    'y+(u@2cJUgJO9W^kz_glP|+x*Gr)YoWmCm_h~Ze*2TgE@YnjQV&-<OV&N>P?AEh~KyIFz_uLJaSH(XwH7-IYWl>G*-n#$9d7&Ep9'
    'c=-$cZd{>X9TlQi+WT14)FHO5HBDti^HL{aiPLHZcc-D%{2x;Y0$QP8g!aury?H7ml(}8s|2pwQwocGLu*VXOpnXkR72z;=VH*#+'
    '{*~P#5mvZZ-B`kTm*pfp^Py2uE0@gX4M;ve89;Gia-`;ase+J(Sd@8WIwFJHsG)fT2f{@`%(_Ok9WyDMKoiq#_0TErE#6Y=((UzX'
    ';3H0DLVXrUEd)2+%SaEO6>AmzcJWnE?;i#A@CFz@5HHujVs)hm9Mh+@Dd3%!m>5JZHBe$1UZs2@xwO?Izgi>dYxm$v`oPb>cq4k0'
    '1<-9O2`O-4{AkIfy??zLkg%#!mT<^jid?*T{kGdH8_)(C;3@mXr&R4wmSQ@)R~~4Z8w`TYIBZn3W5b_xPqrir6uJNej_d8U)^(*b'
    'dP41h3J#jm7W+!c<@}8f6|74^9fwe`kDdZ|XtFXC13=x@3>GYOSw2cab0)p+c3*HV8-t>26izI??O{$frbh$ws#R4xjVXFeu1K0E'
    'A#AJ|R<tTbyHI-{eei&qI0;kM5YkX^9ToA&;&*5+!Lf4sy-d6AvBQqG{VfnY7V#E?R77S8@+#q$`ahfwQUDMs5ISTcIF8GzeYp%j'
    'iff8Bj`C`N0fo9UOwNSS99}Ku^=u)wDQ@eGMNTs#-zH=FEu6OeenPC4;PsE!`)kVEFG3&siD>q_+^Y^6^FKcgYTe221OlSC&Jd~m'
    '!>&8}mG}v{?v<M(8pj7ceb6p-D9=;(W}YJ7g^BUoPCuI^qB@PfIdV>}nw<40h!HqFBx5SwCF!1l^!vN^2*M?I`G=@)yh3Z-`<ZQI'
    'm}D7=;5Dz!=Ly@J$|2r=^g}fVB$5{n=x_|XS;e3`G^aIR?4Ugf({{INu@Z=<erI<Vqj>2`AG;9^2r@&Fx%RQ<0i%29dksvkGO9+5'
    '9b4`PwBmywR7jMS&emKI+-9!ko14g;Tbz3ZcO|RFel>iX+f@7Aecz1lPvf7~5`unJ%nK2RqOctxH#9!}2a4!2LK5I$5pbbqt{tyE'
    'TuV9N*>m<*AfKm+V1WPa4E?XEYDZFVATq^R3Al9`jvu(zxCd0AgPyu}A+BxI^+7Nw2ut0i2#4~zl&M9lbpJ`to^CfoL@tqp;yU&V'
    'z^iAUR+FEvq?OPmFhha8u_j(okMvzVF7x*AOO^tq5i0W1XE#~o?RvCOxXFDqk4-EYt0u-yg<k_1h*Fwn#7?Y4JMeF6r3C2;Uw{ca'
    '&n@*E{{&pq_s1TzXSyDN1KfO^#gTvPE{z(NZwT&+00a|3IAHy_ysidk0XP>%Duup6Ar(l=mrc?{Nf!Bnv)p7Sjb<Hh!9Qp?V?=zQ'
    '5+FV~<W!7N<cH2QtcSU82x_<(aqLek^kB0Csm}X{(BR77&rN;tYG-6ew3Y-y3PfZgJO!MEBGa;oYxqOJIzO8@Oh~hbkN28hzXELV'
    'UR<~r8Ou_tf#Wmd<RJ0+l6M9}l@-OP1Ax0+Mby|qt&vFxbrHRoC|-tCxOLD^4SzJR7J(F^G-?A8_?;^^IJ9tyoo`^=jGFk6806h;'
    'AOKDkC-sHyccHQEg1C?&sAYzfY9*UBeAa#uiJ?t*zQ((C4L(SgqCaJCe%yV3?^DPTw-Mz9c$|ft0Ql(XtKNw521I@*6rz$BQI>0B'
    'B(9ih*2ewukV<x8eG5oJpk2~7{hy%kP4KG7-x>zn>}Sl4j*Zqdu1zW&(P^-f2n%jj3a#!YI<Gu+sKQ|U4yfFSQy0{sQeB{U(cJ^y'
    'so`Gt2cOCGKoy%7_W7iGbk93$xD-!sW}I;;Gm$%xJ@*`$^>z&xgr!zF8ag7p?4sz9WTRLAoCGfN3}XxNo&@oF>7jaEBXS?&yf|0j'
    'cO3+vx`WWiV33c;@+AaYx>!&ty@{ofV?}!SVW$BEpsBr8PL}J_Vb%dP<{X`ob*6^BSg2ENqJI;KVMP1mVhee4i8D@v*Q4p1Ks=lM'
    'V#}Ven3{=F0A!VD%lW&~IyML4RD8m;W_F;APIpKKwkqAnZKi1w4;GDt2Z$3K1k_wWg#aMt9=unNYZv=al0-rva|BvoN&xcxx68&+'
    '!zg?GsrLB*E7`DQI;%rWXth6FCKqun$MXTt^U+R^mdFu8hy=&gmahItKEUn}no!NLkC-K)QEnFc><sI-){#*=R{&b6=c}ji-XIjV'
    'nz29}+nai-0MB^S1E`S2XY8j<KX1@3yS53~B^5_~XtZRAV)wyPJPjN0HO4hJ;WtCCyfnmAsQ<J8_@D5D;wU^`kRn^AD5t89AZPnP'
    'lGEHctIEF1zcKE)Hfty9YCvB8=uY6UUtJL&;jwGco=HGClb^9~G~2#BZhs+?#Y_(D0&C2bX@YFKDXcMXC~29ASI=&|aeY1|Vayjg'
    '#qW>LBds&hcPYB`aHN@sa#EEffKP(Xg*bB;gl)}!T=L}sJpwU)zS&6=!-u_BQ_Ki`2yd8N3Q*#QMffwAphqBIUQ94>xA{C7ZQb#F'
    'N&yak^IFQQx8uKa=lFM}y|~iGHr~-#`vuP0J?WOpZ=r8{ruJMG<E<9(DPTxVYH}n$E(F`F{LL=@A3WAc=?Vd?A_bq0w5+*Rk+*aD'
    'aku>F=`qbEsDg#mK+acKVQ|Co5}WH~b``PhDm3!~CpBmrZ922`$<CY9S{BSlJw5e!7C$j%!P;X|a^bxbIQM&)&mZicCldPE-h)m~'
    '^Vp~2<C5*qfGCPbK!`>fDyGnLrETW$R0mkq-s5B_n}O(f?I*P{vz;dx2hBhr_S#Q|J&{}Z0NmosMzVtWNGO38ohxTTFVBd=_qtix'
    'U9v|D<g`Q&UZ}L8EIyW8fwhGF=U_N6sRE6=Zgw~0T=?Zz!sr46jglQ{uhz>}UbwI$=89BwlnOxcnMQ&E9CGRP!eR6Tcy^5%Yg_ST'
    '18PwPW6}G#miY3CVf&wyGa1A1<y1)OQ?r#yJa@t9zzS=qD8@h=X?SaiVI&yX>f75ILPH-0{5W17t_%V+)9}Gv#C4L8DMuhddZwkJ'
    'MA#_d&n+7oBAomY&IYD3@JZh?iN5kp@eT1llIG`nA6MbG^?`OxL3EH5BlMe&%P!r+0T%Mvq-u&Rl>Y}pDeiSa)0ks*3zXxQ_{3Cl'
    'pR1<>Ly9+0Vq6x(m2nFJn<9a_tTEu<>{)HZtnUUJoe?f@5Nvj$G}iWSgIMAxOFKZhF$}yTsIW=fXs%5Kr;@JPPFdgKC?r~Gxy2I8'
    'P`?y%a!FDJL9igqHqLkeK|s!1As$@|NY?I@r#G{b2Oo<hbL{z=x~6)oK>&{&I0GXJiOBpVRs9SrLH#2t(S6<LyD?v?{ZKe6PAM15'
    'R!$d5Y}Tlo{@V9>h2P6QX2R$RNS8Jj&(I?5a7bus4B2><LcYPvwNoZ4XbKxrPr6L>G=L}lN8^@Sy)3+&k@YG8dL@vmUz$EMW`|jn'
    '{u>fcU)jcSGrp<Dm!u^ufYG)BY#nE2mRKaD&fnwdOD`PnEps8BURnxq1Ap-^$R@vJ?Bo!DsHoF@3d`(nam%M5MU*J`54IUaFFW5h'
    'GGO`Q1>!_nt-|{lQKVQX7}uEFk8|4T1%4{N2cp2|ME1IRGzHrb9!GFG7HM}ra;CTjfh^~xIway=sg^n~i|?uE_$N8ZrBXNq4*LP?'
    '?ZEKjd08wNfBLwX{6frn{)<DjfZq+!hbj!)he2_Ie36=o!a{*D5J}GpX?{lLbObe{dUXed@R?P%IkD`VZ3!t%Mk&oUhVk9-Nx0X)'
    'F1~6PWNf*iEeUnKl5Z3(I)P1rpb7SVJCIZxJndQ+tB{@lqiV$4mr0T07&U<Q4S|CWu$Ix=M*IgFE=QJM_!Ob7N-_c1v1J8x+pG@G'
    'phyU9O;ii_UYG$h_$pJq<7?_WT;4L|9t}Ze#G$xM6xB$$9pD`OzV4Bu#zV5#K}8R1sofKN_x1c5AxSB;{-6SQI)^jla8s_hB`vIy'
    'dF&?eN|$atyu0Cqre}?eE8Z(c&YbyOspSnRio4z)3H{=JR|Gw0fU9$94wgUcwIh0NYKsJY>7PA*n}#D~ZIG)XFRpW}tY(zL1<!5C'
    'ZPLrqS^#dQwEh5FN~8it$k8h8E4l0#lz;bg72Ve=l!32nH(dga+mc}Lg%i{%ol#Z2DOBW-aRBm|eR1zKR{mN2E7XG^_;Ku%+jm>z'
    'Pi%SF!QewMwqfeKG>B+@09$+^+HyNcZ2p?G><U6m$va2ZpEY)?;~JJg?q=LWiy7m2ml}3WB$)sPHUZJ&G;fpFV(aQ9C5qmWN%;Z+'
    'eq7;kxT6Eog?9U#w^-=m!%NPcVf!`qm}LYJ$=uwS-wX(^;Ez>ry44h+kYqZx&XBeAmL~`)dFTpw1SKt65$P8O^WrVC=_}VoD|A(N'
    '4B*#t*kB8qU3<t6y1OMkp=zD&mh6@2Apd}~l1`yt=>op67wOFlSJyE3u2$<?n|@_{?cEwclDR}^1S_fMd=IlFa~&O!??insYMS>4'
    '&CqP;Z!Ot1vKPqM(JyWb;wNmty_2hfdcu{0d#?K6)3ZlU1vB-E%m!Q{^fgI}pL%#<3`-+V-bdkhST88YWTPyJMiQvt3HxfF!2Y@q'
    '++Y?rvkHk5@fARkyrIVrmWe=&j74Zd7p{Y&aVZwZL>4$>Q3-iW9PYLaN8+iYWc&8{#G@UKT97aj2JKU}SZM^DZ*FkT@{BBJtt!)t'
    'hpT$dpK(VEtxG8jbsTl7>h(KZc&;}8{%?afH&O#nqVG@Er0WUZ2tY`nOl@TN-&$dw+RW5TU|<1HpKgv-xnZ@#z&Arv-s?ob8QczD'
    'iiL!%pRSWGUI2to9ltW{Hhn>FgV}%y#<1UHl|c8hE-n^BM<9)Xc0C_I$u{(;dx1sziBzG7uysW3p*XgeV^najW_mp%xjmgR@0Yj{'
    'G1@mdwzndNV1P(J`nP`VOpz@nh$QZ5?IHERg}NP<6^gwe5cbSD3>*1I@au}xa}a<{T#<Zb$yO_uhRWlE#g+~2cJgPd9#;ElS1<yD'
    '$TLhA<y9YkJFjS}B7g;We#n}GF`ebA+L?o$zbsc4-T(7WlC{OD7J)Yqp6((cvy*^s^}k0<(V7ascF4{T-^KHDR94Q0+Cqykf^H$}'
    'Eo+T$o?h3;ke=pK72$aDsV|^T&=!HmC~0$=6Q^$bSJdUg`%C@7VtJ0ya)G3tWjQ(CH9daPplv~-Ci`W9QXu92yIsHyp}M*`V=lXB'
    'ZzwYdl#Ho>fQ6?h@E)bB^5H3YhzW3s6~^C*UJ2swQNN_>DDF4<oOSBmKkDWdiFR?qsA4QI{B3HH!^$)%ZNr95OMhcx!cqiwcPe8c'
    '=btY6mWh8W<WPMTB8z^qR=Kr$<k4=fWm<aONu|>aMk<nl5dBas#PlMBmy{A)v}K>nAaR`azYYdyp2O43$;P^xOXK!%wPY|;&UBJo'
    'HNZAhwbcc7@^>u>O7PQ2ykJBnA@NZ1D>*{wOob~~Ow8`u%N8}(=|xe;a0DGeqt-Ztb*5@_B|fGqgj`+)ik@K#9k~f|$kTqLvP3%d'
    'fw}ssZp0)}veIRUHuvp>I`9_?ru&~@quvB)xQ<*8*nDMT(Z7pcyn`62aZV)H-u{^|9@~7d+qEX+AMvWYA-~_jqxD(8<Bu}l8(XBB'
    'PvP`Y82LThsx0MU15P4j+44=fK7ik=DyRa76KWZ%X&l;lo4B_9Rp_pW8dd>7!U2Zd2>np6=f%@vu5xe?h)H<M|NmEHsUkOnP4;ob'
    'j#lHsd69Y66l>1N`StFMbFx(C53H@kO0=4VLB+3!0mqMY#r66|+*ke?hj_VlFFO7Ri%zH->gK^dvWVYam!zc^2_rN-QP5%J|5|oE'
    '&#%-J&GF-qV?mr0oPFY*{dtjkkFLLyI{QGTRhW+?Lc!Dx1m1A^hTUGOIfl{ieOR=}crP21KfSOMnCpCwCQT?}WgK-#VkdV$OTDrK'
    '_&A4V97H&TtLkVPadDk$o!AeY*Ab`~O7BMZahPL{DJ=HO+3s;iIj5^QBwR!bOS9OWtb@K*T~@id9jw2lD}=EUs(>si!`gMff7gkZ'
    '-SI4wv@nIR(`bFZh*`9gI7})UTJKUQLxJs!5((KD`h&V@$8xn*wxJ9cM5m7Lu(~Qse&!2!ysGo*ng7uc&!j2bI4$oW4^ftcV3>Xb'
    'Va!F}N^p4red_k_j9}U9x97rH@9<mU<Sq>!(b~i_Or+rCJ{UhhPh~@WD~42K*S?ZfcuqbO?_8Z*2(qXpH0>1%lkVRXP*zH{3OB3Y'
    ')lJ)*1i6%<T=CkHI&w83h`RO|;c$5%LbEbN3;61`3up05h}!0GFb61Kr=k9Sa&;wHK6X{O&^y7X4v5r`<|ba^*va>Gmk&#%m3D5r'
    'D2covh3Zl(+GgYii;ODzK}5UNHi^>2I|lV{qxt|hchJEdhA*Cd`Pd42cDv13uJ{#<MprfB9K|3;fglm)jL1CQJofj-g3ARiLAQ`='
    'xrb4qZd!}j!47w;;H+1tfL;MVJ<zB>We8m4Z^nXEy^unOM;OY&IAc<zf<LIGktwgzFG4q5_mm{oIgMitg>3bY`)*|yiL(w+R%i`{'
    'fL7CT&g?Ao!4;I8t(cOZu^fu}Frk(U5$U+7CUL{n5A9>Fw~G*)4jkOP-F(q8B7F~Y#|<S@&-f{K7e1cxozG41Y~230{%hAYB<Ri2'
    '3_1Cj4p=#<sYXR(RW7lm@H8AR-ueFr9Lo0lFqPT9mnS?NvG#Lj-D<-Ks5))oUe*jt({O%|@^33iBE*oZS#_0X5@%Ryh2?Njx<M=u'
    '66{;UlvS$}zAoJM-657PLFKE>+nj6h`9UI6ni^;vG69nbv*!v@wxvbr3-w^}2a)eRQ&6`$K21MJvxGxe^E5eORPPy%Yw%S)s8By}'
    'Oint;T77R#>cC5MxEnOT$btb`(fT4t@GWQ%tD?}F)y1?O2)%&TfBl?Nu-3Bcq8!)Yn{8YozZkBid)_nn2Y3<Q@u&c&8Z%~d7H>&#'
    'C>vFQiT83JUpngjF)pA(L{Q;dMy<k_2H2w&Qb-WdxpJN>>%{(?L+oCpML`U(bI%E4QO2IZ>y#&pr%7k;-BC|;Sj=02pr!ldUB7Q2'
    'kpWAV0YwHeNwTF8T;4lc?s9W9@R0-31TR-0rM1$nrA^d3se-$%Vv5(xdfcW#0pCIKD3|5CVS$gwx#u*`no4ZrB-hbyhe*R(M@C}-'
    'fjOxY9`Swa9z4yC`;WvhU>Ub7;@)6${-kJwV1_sfCmwGDjdT=yzWy$2xAe^yL@k-DlJ`KqX>2#ibTlvd?7<87+D-<K1`IVxW^cB='
    '%wE>xPrRqMLZWv=LMUYf4ka#cqd@km5QPRCtQ06SY3mY0-BMAJI5!C_v>|@!cG-^Fm70orEG0`y7gcObYNXaAowr4(L$91tn071$'
    'g9j&7YP~M#HQNmqBjuQ}r&GcXXA%@Hia8_gTJ$uWL-}gyWf#xK-Iy95zXx5flgryGOmKDpRrA3LJG9%MV<2gn*ITq{S;E%CAV_4U'
    'ZWFg>a^@c(#3_G_x*dh1<%govVf;slM|4uqV@-#pN!+gXvh#)m@l%SxLNHI|2nkoS)JDJzojaZS5~-vG0&^O`L$`XD7rau75u}dg'
    'h7XCWkW(Ia2&p=A;dvP@z7z?}f-$Kn$Q1;{oq^3gAUkk$l99Wo&M3~~H)*<};1p4~1VS*jRga4M)+!R2ln@q>LoyWbi7qi8?3M@p'
    'u4d||&S^E(1!wFm>1$1EJYAf%HHXh>^U+J(iVE@8qh#AyMtE_j81P|))wL!SwhovSL_WRA1PcTOF<FVtL?b*iXqK<0HXp<bgxZ1$'
    '^fvosP}pJb-AGE=4A=&}CEYAI@=Y$y-p-lg3y76jg-jFT(G2|rdV#mng=6bSNW)@iVck*?VRl=7dHNw=jI_j;L^`-f%xi+5;=3(|'
    '{@0<K$Wk30@{#5mMGr!*VtYOt9c%cJGgxZ6g-U9zyqfN6KeYr$A$jW)QM^N*XpAesE+MqeJ08e&s8aH<qk%MGfG#UzKD;Zho%CRj'
    '^&S1OTsV3=?riFgQAufy{Uzd17ZAs@L4Flwk8$K2K7fYk^D^ljI|Bb2>jIo1IwwKP>@C^+w6+ZkML}A(zincFb-WGtdvGP*N!W<A'
    'Hhm8qgD1qIT`F^+%}l%Jcm~0ie`R)W6X~i+h?)FYE;(PAV~v}a{EjqqwhA5E`Q4sY;I*UF(hXHXYb@5gwcob$rXW~)`1j&JWC29X'
    '(_Dtry{9-I38z5iT}sKjE^|G@{vcxry6n8=KuYua4BOAyrI53KO~oCP34+Gz2-|w<OLVv=Ph1Ya8Y^5zj=XxS8>KNZWB!BQkG(p{'
    'gdkA2L$-W&QY*%LN4uT}i;K47?>J44DUh|2<^KnN8QTOgb2>;8qG0@11}mXk6lt8q&23ri_r7v;Vg(IHyGN@lb7WUNW>k>sLwd>|'
    '=zLJ6Pr^L!wxRjo-MNf%kltQg0{xU34O(q!TF0AVIDGe9KDK7e5LEPz=wefL`PrLt!8@yB<(gP00v7LG*KGem%p8U+#Aemr0bQdL'
    '!0>)Uliu-KW{QJrEj53h0#Z2iM`I-t8-O^!&83K)Cbaz^7j;V~$#{vTPnrbF_07~zwMR}kRn@<*C<9WLUt!jbpiF*ZMIFhL>&-ks'
    'V`ax^?*%vgbJYhYk4d#K<!2sH%ku29QdqJE-H&oaSJmn6gCF_yz@s|uJxa4_b2Tm5dDzC)E&w?zdT{S+_fvGXw7ujc_~wWls`c@k'
    '5drPWI<Z7=?487dYdPIT+QMLLLZ*PY#l0=J!0+lfQ7(|$55`jgs{d%UQO7>nyShY4n&H9Jtu<6|up;^_b;Pz&U46aE+<q#|)h6eo'
    'sew>`<`~)vx)SufY@w_g0wk3}Uk+!u;=F?kI8by253$KtXspO)XOoDz_5XUBA&xCq2tm%3d4d$UloBRdRh$}<FLxmwH!<5Lsmf*z'
    '$vNwk9h#+W8^WWz`P2OROSFr0GUHy;es~b=e}sxIW2ae(Qo+9qF6W|`HsmlgTHn6R0M)ejmwyPOs^Q$jt#!qFiS?)?TlpmChQ}P`'
    'wzH<kit$j^h24Q`+HP{>4Jk@aaF0$pP6!;_51pW{z%s{|R>xFGU(dcYrgm{k;|l3~2+X|U9*AT^wFy^T66ZBN6ZUetc^4!5Bzd8='
    'JCT($8mzadk*=uI4mvv|NQ8ZHVqs-8vWu10af4QgO0mm;;*YH4U?olPNrW{xR!KH+{d1q)4s?cm-~WF96rH3zJ*x|;hdno~m2$fz'
    ')v>pO+<+4~o|k)|eKnz#Du{G{4wi7)BN9j$f~^)i<Cfp=y?*>RA({VjZT}#+bU6{7>p;3IJMSfz{{5O|+ue63Hy37k9Og#*k}S2k'
    '+sh|ik<g?IrP%HX>o;9#ss0GD@Nan(;^P9mfPK224$31<bK-W)3pADQ@nZZnIWo}LBkDSwgge^D;oj{Nn}cE8&p%OPGMU4!uFdE_'
    'kPar2^%FVY-t7%d5tIQNGnY8+PslwJ^FCMug-WVl6S4WV1d~@o<cNWYv4LZ!8LIz_w2%;AUIgQdaS3W=js#2lTJyFr++p`PK@yQ='
    'UV(&E)kbZR7>iVR2y$3e)6)cwr#<D`n4lB%<f&-vUE6C1bsEZDKoe3bUE1$j-wq4;JnjtdCQx&kg)I!b1s>L?T6c)hwc)!CpQ27;'
    'jdr)$D1rIAD*CVlolg*dhtV$uvBwB0H8znPxL8nuqu1dAu9X)y?B0so*$>QLVw8~^iZGpB@PL|j)hG#>HH&{<6QKjH_#2e=LPnJ}'
    'T5&drMN-M}792#ka%7bK?{$5+VCN{f5*&c&&!`M}qZb<;Er)15#@I1&x6Zvb2K(1;FZ@0;@^79N=<ZJ9St(`E-<|%9t7Xmpa1%V>'
    '58e7Z+RT#K`V?}?mP%dzYu|b)_c-z+EE*6kg2qt@drnn1#>mtZr>&>t=o~k*VlZrdyifTfY)B8qY?->)*_r?Tivsi4<!|LjY>XB@'
    'M9j|mLxWa;dYZ2Mas4c&W7bhuKjej*0A+M&Z?Vq_Y7R1u?I1tz`w$dznkUA%m^0waW_|JrhzMMp(y9w25p9-U;4C>4z~Aft(Z@kE'
    'tPd{0SG5D+o<|m_AbA(Db%{8=G?v#(0naCXZx?y5w3f5vtZ|Pc-DTHE-(Z{9xmVR7?aZC&6__p~AM`&#AC*3-vT$ZR3v^gAa=hDq'
    '2H#`f$x?u5!GQ35X`VQbsb+C#hvMsNSHv%$&j~iWwo+j0v<h!`1e8QI1k4va+_BcK&y8m_FWbSZQZ>KD#L4(V@C(|tp(G@4B&4RN'
    'H}Z3>$pQ&+0G{pj_KmkrjrNda27B`I5ypR*z0y*W#%j|2Sd!UnBRWcA@fsSGZNNM2-fjA7L@Ut~Z((^~f&wLOsf8*OGqG)scDh8d'
    'JBwFKB#pMrP*}O>^e4rluiyXxzf<NZy`CxH00EGT1HZrym#^^XvBYQl0ssI200dcD'
)

_INFINITE_RULE_COUNT = 50
_INFINITE_RULES_XZ_B85 = (
    '{Wp48S^xk9=GL@E0stWa8~^|S5YJf5=a7Y=hg|?I;Dp3sIa(c!;^|CWtR@>(-0PI0G1@A5uQ-5Q;7+FfS^s_${9XjtfTL3MZ2ic~'
    'H_nSyZ_YJ9czz4=xc(U<tQD~Qs{NA3IZ#s_w2E^bc{{!|rqj35YIodYkiqPNZoWU#U0W`H!BpTO$3e*jz+0s-e!0D_em>ctaL~dx'
    'Wb%SenrzUJlYZP`gm00p4SWNGqo@4mk@f0(-WWLX{R8WmkHZGaW3zDtOTt&tV{V=vURni*vFD2<r7_f@G1X;rF=%J;Iy3F*n)u)f'
    '^Y2I{86%w0bLl^;`6U1WO7q-zSI0~at~5T;;@l<#Gv`7(1qx4!PW{|=8qvHg!T^2MvAFyBb06vrB|vma4@`bmBjVCg{>Gw}l~?r6'
    'ACUtuUl?^HqGYDhm7?oJAb*wu<&t!8@1g$pk7cSELV6#2M{ipSiYEn<4_G3;o#Q$Jt47<LvpB)od0B#Q`s_%avMv7%dji_`bqFbQ'
    '&T>NS&|uk~W#Twco?I0MkUy64QP=qAtpmF_aW^;(#cCxhy<0YW)|tldQn?^kO8y+ojt7JBg3LhPkxW!qQVo%_a*@+=U%SbWGA`Jg'
    'YTG3)_8N5>E##eG=T%Bm==e3Hj78xJf>Y#0F!u(^VSl>3u)GYucQGvB1T-uWGN>5s9HnSDUr^KKiWZC&GrDuxRy<WI@EQ5l{DJ9S'
    '!~y(o?|Ca(g0mo<pzt@5Vsu_Y3*RdZ-c$GOd($JP+-95Ph?F@ZsR+E&w~wq^m&+m<q==m&h`F<TZ@jL-zp-tWmhYJ6tQ3Svc0l!y'
    '3wp`Bsz!HqSATx%ntTI3#jU_6Fo!kLXPub8Z-ienT;PS|WI6i-E6*MJCpV5hb_sR`M@1r|rHb^zQl$lizUH|e0BL~bPro45--?0P'
    'WdNqhdT1uzMYX-CdzvT9Sy)FyZ74G;|2|~SqhRxkk+ok^mTXE>tWKk*+3pYVTk^@8emeJ5f|;JZO46w^XQCl0Fw{-YSsl4nid9oa'
    'Yi8zQc7YkO(7!`OW>m{@_OT%{?#95uImB@?y(F6)AD@LEf-nqJN~DN*CoHfodfsX$K<3J0sK*a|>b5=p4laQzi3gTYp`J4!dX%<N'
    'ShmRYCw#jU7BL=q>)=0N2w-kus&$1c@o5Du<$nHwoN{}Sra2#J!hlGsYuhDw73QZyoNPtE>oG4jJ^dEMUBeDS)0uPYWow6$YVjOs'
    '4d$QZgqXITBNtAxSx=O2Az+WT-9Ley*vXkb!2{E|9w(G}8L!vMj0U>}9TRuIR4}PXO}8n6Q&r>VvDGGbfzeskf0BBJ&$ab3iL|b_'
    'r9B<c2A#a%k?0-Uqi#8|3bGKp<B$L?gv+H?Nc}b1-JCH~xIhq53i&We^9Mkj-FX|eN!l)Z7dpoyGgpq!R4Ej0Rp^y>&nl4;Y*=tc'
    '+LXuKW|Wfa1%*2#HHA4Kgz`UGyMJHe<z~1^r0wFJ#F1kc331LKBz{9mf#4u6zGfXwi?Uh%e;h>3q+hpJqTur8kMW}_^(<3NX`>aB'
    'Z4%f@I?!^bWuzHlyQw2hL&#!}GO(*)*hD2+WM;ZUf<pG+E8N$-gsTaN1oTg4)*ItvAuHHhP(C^l!e#(<VYz(w3gTPpKEehpffdT='
    'h@*p43xHM$gd2%a%*Ko=>|S|4BVXKwNlBaU@4XZLxDX=GdL4Nvo+hsE|FrX&DfDp#%{woZy+SUdxC6VmEvcX90J{qo%c14#L767<'
    '+GeR6G$JnXFXfN_7kUK)wKb*EKSJUyJ{kQz0)L&70kZ)1S6Faw%WZqrjnDB`baP++nZhVo2hf8MA<7%WVeU-#`Kz+R3d;e~NIf-K'
    'OF86UY<KyVCW#n;mt&r-g{D%2YdjpJR5ujXf2o@5mRX#y>Gm{l6dpNSybUuT67=z6f=%Ou`ri;GMjIm{KsPx3Mk6h%M(uYp!fA6='
    '=MQua)-KNfwN8diyuyI(T>Z09^FW$Wx2wV9U^^!E!MX<LDF8yP$sj4`A*=K%ltb~~e1p^SUgMi?i6~(+jP+>Soi}uBvH@qUI_4$~'
    'sam%=G`_n);~o*sAoNCBjm-RjGan{jH%QntPSwg`DJT(qr=zDK<teNv0$RBd+Ht^}4p>t)cvTHt*Bd&Nmj@E<w-hBdFF~r$zOe%!'
    '0D>IAAf{q9o}wvEyD*9%rktk^zfFco2G)vyu~3F%)UFHChJJg83>r?IT#%vgM}6LP8To=Flxf3@bTt(0ds8n%9#j!4hIi>HOEtK?'
    'da2?wyX|ePt@Dl?`|^}$LnpxS`kMH*^m_IfO4~jEnV1$CZS313z#W(Vop>Q|V?ai9!b2Gp;$udZ_C)zOgq!Yf^t?$WkG#}@-_?lP'
    'G}bI1kOo=B46~cAWM~<(>7k&p(f||LuU0WPF`JVV9XB;yds&I4v!ngO{Vw#l?<oA?@}3V;>JHpB`BX^UG;pFYSe%<h9(D#NNC~6t'
    'wX=U0shTeoNAW;Zurx%}GG-~^)WVti_`VD((%1y}vQAq2U;c5<%Z}aSt?qrfj7WMi55C)S7-<)Z_WQIy%4#Z-MP?7Jk$aiQ^8MWO'
    'GS_ne7qUMK7)J|0pZlY@d*Si#v1XgfYA20(76TR3#D}i7RDP@z8calu{bq;QEImp4w!$KmISKp5<Y3Gy^}ztsS$E#o?fTbqq4fPt'
    'gC3PWInWxteC4cJtF?oV4^7|kIL9Gl9~Z{w5X)%a8TXQ^3LWWXtpKF@$xG`ZP-zyJ>L*qm(CT+3I_6&GYkBi=X{XiV8mkoO^EHAA'
    'p8H7y1u1vxs6(D2?6he!f`m0)vwAs}yIKPa#b9o(8n$ZeEbJV|5?NzGrfm#UzMaEK90>h0*-Lk>-dKXl2hk0y>(V|MvW!duD{U9d'
    'xT!Sj(|7fbG&s}|pF={C^np4WptC0Bjv0#JMSFf+t@O9PFy!{O#*)j5Koba&v6w_hfjB>r;(0kuRW_yHVOd|c_n?#%@;N0wWliW&'
    'g-lsH$V@+0Szh0`Fa;HXrkLzCZj-(XgtXUbdhl{<h-mMrp4yp|^6<f7<VNZw3)_dZMP?WV)43Yk+rI-E!IP$hN4SgxwR^gDJ!m4u'
    '*<B+!oecT~;j3hq2DoXG;XrRCDl>G#9GOPPi|fMyBy@i-s=g;ech=w9KD-KOnxHt{Uqe*@$R^Uxt2b+*r-G>majxF(Q-b|)bxhTy'
    'V;vOC%=JRbvj~LrD%KS`{M~ddZky<PdK>|(S)#Lz3l#L(PDCtM*-R!hwqVC;IUb{rPuvujISS%n=k;2}OK8Rr3_Ex(d*w)%_=eDl'
    ';Ts_?@$q9($W;B;X`o9US$@)}F*$M+0RzVFRS$4>(WvL@IWkyYvGCe!AVmiPZ;3PNdv0oY5$GN}fTjX&2u^?n&RvHYhg9k{LF@C1'
    'V$V!)QL?>k4$ZUMn$4Yil008kpWd1ip7Wpr(;35iTU|0F#C`K#JIweJyF8mo3hEjd9-+Q-OCxiJ;A6<r8yqrFRMAZy&t3%(A0An-'
    'R4N8++keHgZ#lc;*U3g?{_cznh%p*iCARdAZ*-=O0hor|0j$M{Y!oXxJ->EoBwU$AZ5zfPa`kpH>Y>c6o{SCf81jf6`TBI%Y10&I'
    '{dGKzRH%+NR$0T7-c^TBOxOja^i+^d99S0S-M(R>AM;dS)V$<4lqnf}I?iZrNMNz2Dg>_>V{Xf48M6m|?u)38haip`O}xQ1*yyq('
    'EpmMqnVAD5Zs7X=d+(7P`)u!-`5`2>t!KMP=~IhNA3WXxYUhYzt{x=UZhO>K<j@OuX8AHAo?J9VxAqp<P{Ed=U9v(Yb8l&yrnY4J'
    'ez6`)+^NDhtNg*(&<s+hU5kh#^fS^Dn>hj2je;?ab6Q+*;h6Iyw{RQu6t#{+wK=lZV2klQ$f;YfN1LI0opFtE&X;R7g4s$OKiZRi'
    'HQT3Pz06^AKV>Mg8Yqf;`nYknL}REaY(hN<l=P_=A6E464GkSr2j0zIh^&*<Cjkj7{%!R~n&-K+J|m~|3WD;>{u_9ujqP7hCDB4E'
    'eChn?dUvbR1C{rgvhU8Ov<V{K$i+C#UO8-Ob3N@&Fbi~Ztm1=w2g`TEP5L>rKb7-KX?9}Urn-G$xr;qT7>8SVsvEg3R=sU*G(pg<'
    'BHq>5rxhnkOLiqWa@lF}pH5om(miR6*w-VFOl)#bv!1Y6ZPhCqViX)qtF@j^sMi{80Z{IkW5_RkE>X(n{D9WVtPBYTiqa;p!JAcf'
    '=nL0=bu^PY5|Gh7Gi03$5@=Eb<t5gG@M|Wfe91y&lt=qoOGv5b|NrZB9h^MrOM5B@Lj@&?64?VsCSc{pPjh8VZ$jPlQhqZH*S|!;'
    'owM-rZ4apZ*uJ~Ke86m1e@_e4MAmhRd%V0kEio`&tipSAb@;<X8^qrW#4$}idj?Ta0Qyx$DH-~)MYqk%)5I!U$AddS$7f)V<nB<_'
    'cA=Rjzq0?%iJnS!AN{HcF=SvO&8m&PG?vjYUNYHGq2Azp2pL`&LVVU|9KB8#M^xs~3bV10H&<<WytZm-k&wqcPOV4Moe?Zg%y9$2'
    ')$7K@7Cl6hM4X3LQw4<_%CGb2r&IUw5MoAQ%Ktwarpx+0ups$^)~`-4-^W4J{*xtFf)st>Mwh9LC9F;FwZ!*0q&z-s)jq%?M;W+`'
    'ap|7SB4&}2*{i1q<=R9KA(itmdcG2BC7}UhE1WeJA4Hkgs)gu{OjAu?WDTB?SF-A)3@tDJO4B}iGMOI6`n0~h+!(;53WUyx)VLX2'
    'cWdDAuw0}E*r8k~-IIna)~@l7pOr$_vCJ60)<K1!irX#DmWWm|yI_o*hD(V1A?ATUjJ~m@gV@Pj%l%do$=?nwY!5Yf#@#o&*1C)x'
    '+3~WVkF>$j)GP;^Q<n5s<c{Wc{7@q(e89YBVEZ4UqKzm`e7aFg-!3>#n7W4YnRA-m)H1YmW2yAlZ9~5G!+MqzR2}?0w+rCbZr)*B'
    'aCK@$k@!OUMf1SHeYZo8Tv<|wZ`D3x1r~!4c!)3E0rl)h151T(Qakwpi!gX{Rq#|5AtIGn2?wNAc#uwN$9!vP%w52o0tZ3!!)$J}'
    '@9dMNY{8Z<<&HCz54IHRLtp-k`pw)S{&j#%i*V?JSBs7K6SSZKzWYk^LP9><J&vvP@Cv@{6<rYijvw{ZE~AiW$;ium5ltoES#f25'
    'O39d%{6~S%N*sIw*upH$?3EWBD^2*X=425rpi*95XkAMkdxB7$mj^jyQ`6WD%#*ZKTfevws&;K~6Ii+N6EDLT(@w4SUA6ltbPgx5'
    'Qou~b<m6nhRXxatovTN{KE@Hy{uF#_>LL&p!gJb9+GuC4NJF9)=hz$e`4w7H{TW>>MlUDh=)oB-2HGh^G*36y<D7`SAUPB><)$<O'
    '$}Q|6JQ7FPy;iv(KJ%=B)*oQ<pxm$upGyRV0Dr9vxCw0G5BP;xg<rTN9zM{mdi5^lG4lltG@wmHjI2#be3@CohHzKKj`P$=2`)+0'
    '1c5w=LC*sq#0QLB_ogwL&nt3fuM8liIv#6USi*tqIT>s`<_UJVd@xhpt8Eb;1iuEoA-~^2{}1@C&pIT6$YF5_3*Bu<VGP5H3p@jX'
    '+3Bv!OAR%UHW*o7L5qB1UG9R+wI4OrS`X^@2Mtn@c!7O6pxMICtN<9Gh>wS$sC$XOf;SLAv6AN8{ZYz3Xza|0mLpBkqwsCaBLP>@'
    '(7^dk46m6EHq09_mUWivLNRKeO6<JG3of|?1S~CjzpULi#`Ro}k4ms2)v?YwkoKfk+wHKMp>-vTZnA{e7uW@3tVZZO_o9&<hN!{F'
    '!2~083@}<yo#P$3c9}{Lph4X{H2kSjV1MI*7f)*CzD#76V9D3F`c%4x5X#K*bo2Pxl*A3$=_Wync0RzlkVqI2)<&$rw1FwG9kzM!'
    '&Yl12FLS-@s2)y`kKauO!f4bYG*lOI{ZQg=se)t+WdrlKk>gjG4k8_@UfNY6A;Bz(;spp5tfZsn#pwnzyIcI2O4-k-(5}b;iu{1U'
    '<21GrX0)CuSnMrGUed_@rl0%9p7Z#>b4dLF-^tNPEh(2ktp(o2ed+T0KL|x|t|qZeE8F%f2P9YsiDFKsUXVizu8Rpfw`0>9Q~)aq'
    'jua=T|C;G&70fuKZm?|)xi0$Bw^ft^nCE@BvQ2dCU}oR4c!xCFSGp^VBMV~n291t{%ZRX2Icvs(m7~~gNJ1d(bp4N4`1_{s$T46M'
    '{V0v-IdulPh*g0*OrNmZBWVKUZX2=;#18P?3v)L2XE_l0B5iYRBpUJHg{j+Gs<SK)WxlUG$~)KI!M<-fL0THW@Q#g)7V5nYkU(>5'
    'Nzt}>!L5rR<OEy#M`+Dy5Vv9mj?JM$q4K|HA(2kc{fW<bWmWEr9)rub04;l*dZ;GOHpn_<kN)?Q$FY?>U6g{{O<aRzx-2+ks9Jr|'
    '8-rbH1Jbv<$M2~SpJdZWkiZ;y7Jj=Y&jKx!223E4-TQ8qt%TS6KilezK+*?;X#Y0&fzE@gKN#QlUQv5!Z<yLjf@YKor2G;WFMwd{'
    '_7Elq46A>zS+%|YbMSLh<H#Mn|Lw~|iL-~+PZ#Uo3M@v<E3MU#-ojF!hX3Shi#&;tpnpD*0i)?4xDwHMV12P5O2v>lPAOs=OAEDV'
    '{O&lHv?Oj`tBlI4nxk|({y6n-%m<q?5U@N4XeX%E-G9lHm7B<kF~IpIOc^P1CL=74C$VQGrwDncSR%YzgoT28t6=*5J0RGpg%I*{'
    'y&+f0=Yq_#OF|O1Sddm+(`@LBDy{K=o(NFsiuB0;@VYX7;BZD@roz0`>Qx<gT*Tr1H~~A4(D&<)xGt~wmb?{`P`jRZyt?k*iE-!9'
    'L<nNg`RNwoL^kalyb^u=!*is&W348du=?%av#&!Na~KdgPGI!Cp~Zs(yP#g^=cL*_p-<;F5B^(#e&XqlKc9`^XE)*C3z2r>$s4y{'
    'x7T_I<Da<3Ki*=QYy-yV<IS^_fuX`YGK)xAn)u{NIS+!L&ZDs*CczZDf{sg|YXu5MEq!NEYyOW_CUd(YKeM-y`6I$=e&&t-p!|_6'
    'm`jioUj*It(smM}jwUxq_gc^iNPS9ih5Cn5f&Aqa{rgNGr4%6%+$qM^o9`4aIs*GyD7(-l6?BaJ=M@rpPI)*tmcSxQC?v0wmI5+l'
    'Z`hu`g6X}*?MPL?46J(d_aSPnsf`YlWSJDke{Uck6*uc?{%Cy6NJxlfLkV#y|3ud#p)vladBHp&A2PDw@Vj8vcnF7QZYsrhDLslI'
    'Kf;-OGAzyRx{lK_q_+vaf@x@0U&1;pKn)%WLw3OqK=7D5?bBq&1&O?LV=WLY;uBIq^1m*z)XcK<P00FzrLNsZD8;LjdK}&uQz}mq'
    'xh!ig_G$5a$leyiV(vf*q~P*=vsU<KVbIIu1%JeTweYFB61xB}^jWa+kt7MFf6~}{78tEt42ihl%AlKdoOi%ygRbi%ieB)K_Av5&'
    'q}(*u>tQXAgSIPD^xmwnt+%#;3Y$%A&ovAZ<_3KbVz1s?j<5l~zVaUJ@1tFk+qDgu<0_~*msWs~Ase&bIy{#cl6?ldzJ0m5q91|R'
    '#!HWSgu82ABN3XwU__j!q)95&>?VojvnD=WmYP0}>tDX+$_!zY>SxuPEC?#MR*C_^+yDF8GW7kTz=C<}cZ{Gp1&2k2BBO&*nh4Uf'
    '$!^&cSLSKy1;&!@azEFBaiDo1-7@0O)=k?v#Z~AlRY-agLpZrkT_(Js?cSQ26}!z+UbVWRBGe(-F@2)?8`MG`n<&29BO{XycG~Pz'
    'X{iZ-Zc{dx>XZFm?t(U=Tnos-b9yf~70L^q3w?%O%DH`z`lwfDVHaW)9TGAr==Q(?GzEmvj4?fEtn#3j97Kt|BA+F9i0PbmVIz=0'
    ';D=!)6;5;BO}0EC<77>5`jGf?@;w>dL>09^w_&|{(dgpywqY@DVQ`_Oq<{wr6_;E7H-+@{=dV7i{%PTjT)?$nXvX5_vgEAOs+^4$'
    '81Uq>gG-2Ca@T0F8z&QzlyYK_xoV`;L#ZGIxt&C&m9qQrxP@7oqpBVx;r2}#UM#_;JMtT1q^!2U{&=9nFOSSdFfiEb6Hfb*K6M84'
    '7bk5mvY%ZDN}x|-BS^*wNYCmw!b3}a8t&+xL|?yq=x_A4&Z(SAqrS94rE`n_FN|8xl0#-4$5M7M>CVbu?$y4TCPoevZtQ0ADm=23'
    '=Fvq=L(gx)U~s=J3k0y+*$z=#X>1K#xfdJw6@<hz=Ir3Vp%eeeUS0anmMq;QVjdDA^|5{@$R|e<Zs`Q1P0wCTV*erPVy#G8D$@Ms'
    'AY)Q!8+Z#PNsCN1w`5U>;W=cN5a(b}DR7+a5GO+HG>{|9dnLXL6QwwPNRF9Wac%+iy^*+PO*Xx2<FDMXSLwbvpI-TFn$>H2^0dv$'
    'Heza!2y|b`C*8TDRuu7WI~Lh7l28#1-&xUZo=9riny@GiX(E0)4Uw>pa26wb)!4NrA=1lZzKy(kB6NkH5mFf@C|9k?HLaoF34pum'
    'lp%q-F<^t7lvq_AL{4M)Q03hO9{EOB(_`sn(U2cEs)F3NS%fRc6!bp7NB^OKhBlt~xKP+Q{&q$=s1S@Q9uG+WPErhIB@sB#cqf?V'
    'NMKOK3JQtTmJJ%Sl~;%BRml*c{XGH{M23dZrI{6jtH8aNzBU_)o$cs37Os)<Tyk5qUFdq3`4M7VX*;#wSLS6!W=(3?rfg$C@ua_K'
    ';%imdJbi5C@vKoU2nXZEb{UCbh+#&7!T*k$#6JnfPpJPav2`~V$6sE-deJ@X+&9WtyJ{+0Zt`a(T9<NOvb?lv3thVmsrO60g!)F}'
    'bB0Y9?~dV0xjmM_2)q_{1wjS;F%Zt>!MzLGt`tZh(-_(TJ%fFPSPcHN78_LNm|N6qy6}t+AZrD%<@(7JroZ5lfqri6_2iV%&E-}0'
    'C=PCeO%*8p3F{@)G3-Qrg^;Of>xm3`N>(9lAB6JP&U=pB!^7<nq%I|$A1feK6$j1~#gT?M>1#8@%lHGfujcNDG{5)<?qiOT^`kV_'
    '76d;oK@SBrcB=gX%uDmJ&cE69e#^l%!0Z);jyF5EJMJl*z|~S&8bvc;3=gQ>*P`L5zi>s-R)FXthTDvzI-oEL*m)u`)}{$yQ0(P%'
    'VP;@Xv?!X!jK}>S(+d`0xGGSPh@yrHp64D`FPRAHsz-Bv1Vzuc|Nb?DzT8wtNM`os01hQ^ijCX@{dw39kXZ06C-)=7dJr#`4jkxY'
    'bstD|xRxj<?b%LH3$KQ8h41N0xgj&0q-rxmj{^C()FGpw+VmJNNO`$p9mNb;3oJ#nm+p<qqLaqxkGNWHeP<vQASq%eABfEvVG@|D'
    '9Mr}>l~H_sA{E;@;Mi*5!WS95k%z}`sQ(flZbt#yjuCAX1HI?1$|-esaXl~K0$MXGWJk5jL$UQchC@*!sE7wjN4<8}SteLwBa{Fk'
    'N&G(NG49g>>1*@hVsn$VMR`LCypVw_RU?;%4#Zqus4I=py%=q&<bGoPRrIn|nG94SQ&s&o&z1jGk;E{a0SHWihI=xo%~aOYCwL*e'
    'mrhFJy?umk-F644Y?;Lll)4LYP;c4d0SP7s8u5~2J}Iug7>ePcsuZ82Vt1qW^m5n)Y!*1pTZ=-ZHpRHEZ;mpDExrL{B*Cqz@JD#m'
    '6V#V9Yi#q#M>Cy0Qy*fys;ws7PzPo`sG9WTpI$|hhvY&ZA9&z_TLsQ5Y4?6pW0T*wr}ooe>=&Tk?jF2TGUwMq1G2Y#MI)58_};}j'
    '-cMllIxb5gy`_Og)k_{faz_2+8lJ_90H#5WwDu|6v;SJ7Avc8MvP9yYjDGR6dZXWSV5D-qP<IsY=G$tFw+2R>8_f79DT9fZ7A|*+'
    '$$&a<3(YMZ84%cFaDkuxAT?xXYx0l7pT4+59CT6(Bhg}u@7JAt3X(|Am!h<5FQ-~h4+!ba)aT+O>ieN<CrODMiVxEcJ|f=+5v<Oz'
    'pFFjQ&Fa<KnDTi8a2lk$j9UsrU^LhFPbsoYy`B8yowAa`+}Sr*m9GL`z=~L_x`WIz%2V?HKR0^_Q67*ZhrD8iXH&Q7C%AS#$*JIv'
    'E0NI|zmWYzZ-`3H`D^8pt_c0vi>|AL2r)|{Ey5MZ>YHq-fL+7O{DHOKZcf74Lj*9^7~d~<SrlmQ;AJ_ir;B+3*flXasU%~CaL1QP'
    '5YJR75?j64eRRuXhjUq5QA#fWd0lK4W-STirH3dH!CYzH<~TSku>d7WTQjrya(a&X>p7phEUcm%(<z^u^eE+Y_XfGWhlZwUUAUUF'
    'Zi+33@kzwLs<g074Yb=qee~djMO7WFeD~aEZ)m~Optbs-rP5PWlrVxc?n01%QxF-N-XTbU+gZan=rY=jSrS3HeKL+7TOK<TT@xj?'
    'M2}4CO2X?Nji*t0X76zX9*UeymkBjc&J7)Q-sqHUuvpMD+B$_bE2je~7#%K`RI!q5zF3W>0};%Pq`qou?1qy+HP@g+t4uehX4a=_'
    '^G8)_pe<?JCoiJ`S4av0q95189z~BpICm2d&xzbs$Znx<;yxVo>T07|YFa9CE9aSLkWJT^aL(*eH_CD2H(gGqqa(t?c&&GO-iJ9-'
    '2>P--E?;%f<S0(=#!D`VRY66=_bhQA+xUCOvzJ%h$=eiZA${8i$Ac)A=|p(5dB&lCb|W@Od^nM^a!JKFxDXLUPA{wgB5Us+;C(-D'
    'db?XXI<N?t|C?f%Ud{y$@bPkcX%uS|IfCw|)-q7mDba=%vdT#JX7RS39gj~=28AWd)^Ei~?N?EY%H}vecT+45X7e;K)@{*0>=iaM'
    'b7!gJ7Hw%(hNC&15@*j~m(hFjsl>7TjcpFh_mzc*y0$6FCN-BE9#MT`H6oS{co(ddusTQr<MkL--29;rCQlxy9uQzg5S=vu1#Fz+'
    '130Gmg@C&yNyRYzdyLIObNVY)j3hRFi%S(zS=#)e@DUuRP1TZA=FPfgNj8;TX*f!qNnGa%m#qqtz%tWLete?4eUWjsZ3wA!wdj=A'
    'Kv~UHdho8l^YGbQi+$h1L!h!T71P0#W-C_!Fdd8DCwiAv=u+Q38$$cW)t`w)${A?$mdfnG%U;<i*(6Zgu1&;48CWrK2VrW)Ec5^n'
    'X2CdF22ULu+Z0<!{x~1kQ5On{!IVFf-3>%0@yZ0>4eJ0vj}~0w1zkI=n5l*^nc<IfLlxtFYF$Z-MY=LizCTzU7CxI{BeQ(f+69I7'
    '@@{N<j@+S`AIXc$`o}-RnQXDm<2(=!IRG3nt29POF0Y_RGXH`uA=N{P={mhAJo}n^gy~OSYF_Esw`3KkGL#|)CEIXDx`JGSM3+uN'
    'v6SW9qk?GyB(HCL58)45`MZj?*`ZBw@fmL1BhN8`dai$xhGvtQg5up%Qq;)HxW=3^DB46%B2lq}77c@{W%(5ete+Ke>?c^q1SL7c'
    'KVHAQ6gDm~inZQe6UQ;!GsX7?%gu3cJw#O4De-3J^5mMi`!C<D)xK6kyt$tkjA#7nzAu|YPS5xXA({Fo_nw`H6brid<g{RHU1tNj'
    'w)Z`7i0tf6`H2HQt%cz`O~}5I4G8{)zolcmS3<Pe`K2bzcD;+4;uBjp^$%EBQkOHHu82`e4#D|vSBqe|#n&Ez|8mzZSgqY{Fzwl9'
    '&le$mOY|=pr!9!iltOL=B|O+zqSJ?vmZvPV2&^6$6*0s=Mv3i7y}q5JuXK}ukNlJ1Q8L!fI=m?>|5R0E1SpO+b9hey6Y1CX&9{K}'
    'ym9E8Os%y|>=LxQR!+e>4Ggul#IXrkasYQHMq91~3}K3^Np^R>imFdoP*=GqL5*07pgE@5een#0MTOpjk-K@-A)VaU$7veuz~oGW'
    '^YwS7n>cT@ACh^6wIjysCqi>XTr?dPb&bx%9X#1}qSr;woMA60e=E43Oph!hN2#{;lfILEBvyiu4bCK_sGrLq6+c{$Hi)U-Zvv6f'
    'SMpj-C;E|UEs6vC{Q&1KS!WJS*E(Gy;(E5v*VJf*mEQNp03W;DP4znYgDND2??6l{BGDd4t~#o<_@A1UBGsE3A%)}JY!f_#Tt8<z'
    'Q&5MA5W)qLENIsRo(O`Lq!&ACH4o)ep2v=Pbkt9_kGl}eC9*@(nMYgjAMzofi<ISe>o<^}^If;!7aImg0nO?QQ!L#e610N1#)TPZ'
    'NUG)Fc`CGB!Rd230UT-pI@+Kez@7F>0{3BpaLNR?#5V7D8)M^jrk0$>$e?GBlHCHZu@C%VJ)Ty_xv51x^KZYJ-(bO=pKnG;ltU$6'
    'uF7k?Fci(7B<*noQ>?sH)v}O4x4WoS;>!q7bavuTPk*zEK*hijlfGYU+xr?w-DNGmaPDDP=dnuWPkG>UL7wiX?}gG93v2vbg@Wcs'
    'vGpOaiX+w`%Cj&KA7FFitsnnQ02B>DV~6k4V;W2YdH8$lzjDQlt&|6f4(`yiQ6>~H#QFw!Eci)5?``RhWWR2r6n!6FN>yJ*N#II}'
    '{=ts83qqkwDs}-<Dq3UF55zC<rAXw>4@w*8m{aOy%Agg!Rm5|tbn1fpuv!A)t9v_es{SlN$5@=Xca94N8@zUEa=`}2pfW0tu;sQJ'
    '$i(v*0Z;9lm$aVlmbevRH0KPPPwUFxxH~FRcLJjNi5MQ1;_-5TD!`Xw75}qpegx?`^s!Y;kiR-j_>g5;L#J@3g~TwyNmfCfvRQvK'
    '15CbM^gdyGe52mC+dm9I=zyl-)!O9c$Rw^x6uHPyWw`Q`pe-?G6e9BROe@b#0}J$K;yH_5D!FF_`+3P1dRGym?iKoITZf5^+UUOx'
    '%o7NlOjXGAFGS`hL+ddwHHdlhJ@6thsgzvSdCv2DCOPfg&BlWRz#mI+9cm!J?cxt{wI?Tl715U0GTRDrD!aqt-1e_SHgS*MCY91N'
    'QuqbK9{6EtJn;>cAKYCkZ+2L&Lt(qEJpSQX%S>^u=*@LJM`i<*s4#JHMq*txp(r_JiUSRCI^Pf~g0bVo(lm(v=wVvJlldJXMF#yj'
    'Q5T#{aVTCB)3Arkvror=TL;#9P<1ud!)+<T{EhpaInwviMo)2x_MspR%p>|?`6a$yMUgn08s7DbYmZHz`nC27OJa;aX%qebb+oP|'
    '%Gj9)_T&E~;8e)5h2Ba1QscYI7zYpIxmA5r4(u$1nT+~1EL%Q(qTD-(wv-2$4A6ynJnEf5RwQF5<^IfFiGHEW;n6Qd;S`q=O01en'
    '^{FEaAnbpaj#x~QhH3-}mHnY$Hb_0TU1A0|ntDS59vbO5EO3Rrd<*Ikr;O<s3V)k^WS_CocSZK7J`bL7B%?@z$JB!F2sEijG~ovy'
    'uu2_dva?{arb+D(?yGsm5lH#N#2_XrA;BUEz{pf{P@?8hL0j`zc|e1xX*9;?JXM$IT1c(BSA%x={XY~fWdTAVnGNII<nmR4!Zp(<'
    'dy_y)Xt<Nz!0%tyKP2cjti+My7M{WO+RjAZsjs8c63R7Ro>mNptW+#DH|%KXnoHX-{vi1oNcE#`58SD`X9PdiLue`3Ios#y_nnE}'
    'i6^H%VQD1r*%h*YIc$efo;ZIZg+b_Wrb^cSlEQclkGUFj78KwV#0|>5Idi--nYW7p?KV2a%YUnil8&m#CbTQ=Rza4Xo0WTunz)JT'
    'bL2xtr41nQKvvm~0uMCKq6)ajW#Wbn@duI$SIFoM`E0)6pzWC9CrLQmMm7@YC-BgD<{n`foSY0HXRX0$cQ!Qn`*4%hd(0#2GG=(%'
    'bf7XQOhPYq*#?3IBSxr+V<_Yf6(XJGty9(oTBl|?H*8uDeFjxqO$C>rS9bNy3hFf7>e{4W#9=2G<i^bAYL!FVX3PjG_^vj7Rz-;$'
    'e8)Qdw#h%tVSf`Wpyzis;Xa{r4e@y9*f_}g`3cz$$0Xi#?^Pxc_b@f>2R*Bxm6r~_@qE{1+}%+NQ}ei5f+zvjVnTC^3q;8|a*;xV'
    'JnSgqQ&LrCcW?`;`dObfHJQx{#&I_Sd|;+CWcZe652iEs<td)R`AKnH^jEk|NxZ@=zxcjv>^BeYX)%;aX7W*AM}MBvY#RJ7^9!sI'
    'yyJi+Wz3xI%O^?csMnQ`(mm1J&JhO`HVZbZk9v&|$%;`)XtZ8QG%br=poT_{6t&CT;P0ZHaTgpj;>Yb%w&P0nzlkC-c@>#2LfKSH'
    'E}+E=mEz+6G^a*T@yvkQcxOu$3laI1d^2R&)pNCTI@hdV!{#p=I+MoYUOx8$PV|Gh?n|2HV$%=07h^hjJ54ZaB$i<03ulDw{we;A'
    'F763Bc-PSZufF<XYsBZOW9pRl`yxV$bpD^>HZujxjqFC2u3qkMjHu8M5`ll=k(|P|>{?A$!N3cr43AY1!0Ag+6L{w=bFlQHH#cA2'
    'P7KwOf2PCPLoI9p%}FQZZ~~1fuSEPClV+E%p62=hA0{Dk6x1=2slZ}^#}@0|Y-bhIX4k)58>f(EI72X+Dd#Ht*Yh?X3hL#HfmQ`I'
    'Pjj^gYjXlzej*zBTC@TWE!fQM(2gO^neW!{pkt3yXP74cCW)5t*ww8<RCP+gmFy1CcL#=$M@|$X|2^t<3zTPqRP1_6A)$xv7G~ZP'
    '<@j296J3DSKD)-W3-@TfY}3M2RsVM~?$CsGTYQdYPZ}EZBU;L)AYzUjKwq{=g=qxVzou-A@6ff$2Zwz<G74yAs1Kd%3nO$9xit3c'
    'Idf|S_xT8J;aNo{w>0<1)mb=GW5;7St?cuH4l$CtgmoP1aFvj`JfSW0d|B&WVdI05(E17rbM8GTx}fzuVm-qrAOX?k&E-VANiI!I'
    'K%!1o?vtAi(+G`SFAcWnR&xr7FGIg>6Gpo2NA@%*c84of59R-2RV67|X9X~V?7NO(#NGveg^$3-LbvOpL2=PEH)NuAATY>=c~~|Y'
    '8-uF0jd1q_qVe$Ff#5&(BRc))xxZex60Pi$^lJ5#7U4b%JgmlJyzfX;9yrvt>(ZAgLlgBh;aAIt5oP<^Mb<@0ip8`A+#&tpf}L-H'
    'eO$LZ2>JtSf^_+}QrX}Emf*%6d^8RDMgrqj#J~u{BUhK7N+jik%H$3+oYfhaJZCafh_s(c_L3c!nq7!JHeVWK4IuKUiF6B3!?8_F'
    'UKK{(f5Fqck6FxMYE}x?Arw^&|C#Q|Z}$M2qC8p!7g`HUh!&pPdVfj6)W^WIkkwDD+C8*PpZ4C!)Uv6emX=FtLoOPBvu7JPaDlun'
    'sF|>Z&RIcqoAfLMHLU)rNew}e==M@&@Mw0H6A%^szz?s>26XD%RZbw-WMeLTu%{63CBrEfGztQAWp0{uPU-pec4!_ac*vZbpLN5('
    'kOhiy$>^Ei+UOpB-DI!({A+a==BVD8zvZ@%KW8xic8UkG=EE!@<CbN13@kSJtj?WnQM~$fEZUpjTC5sp3R8jXlYLRY_^w;OH6M%3'
    'Dh<hPsT`3KIOGZk*5hLho`{856Z|{?33M{R>vbci2iQVuF=m?s91GdBy}^2@At`SoD^O)`ZUbu%@-Z7hTZ3U!bis4_Km2+6N>^w>'
    'VWW;(eD2iN1MGuk77qY_A4n*8nD-b{V9xW~$3d)k^4DanD9i0vv!KfQ0rZZgw@M4qg?K4H;BQV&sKkjlLxiyQL78Ulmt?!f(z;rg'
    'B(px$-yoK<fQ=E(lJ^8LosX&-B9f^MSCqBDN9HXp!*0VCx(e*fv*{4s){+_x%Ft2ZTVxDY$3(dbk|a39T6K(O7}Vi0&j>^anF*8T'
    'n$9;z72lQ?^l)0b)MVEeICYog8nrh?;1`KPwC@y{1nzvtbQVDoF(+M@?P%d}e)eY@iD8PyB|572^TdRFyq>9np?5ar4Rx1JuUS=o'
    'iRgZ=f&PH6Yf*b6o~KsNgCa*loip7cd$y6qkjuR~YY7<@^ibk^xQ5*snsS%0O*)!Z!`>Bglt6*T*TRm_C;q9x@yj8%$TtdlZjLz1'
    '-|V2HObX{n)ci&Rdd|<sud<9{oi|!k=q6%>2Jj!T2Ua@}w5pc8tA%xn!dCK_^rEUUE<ZZvLvd2A^FW7u+%{4JO+Adg%l32=<RECX'
    'IsKHp;2k`#z->1L@+(mD3?#9`3Yf=YitSi>9;{u4Ky;OWmk?Y7c%>b|R=PUzaJnzNJ`=1MUvQL*n)Fm9lC?GE9p$0AiAxSo!`A^c'
    'YrRS_8W@o5>6G+W(=*K91oCZ?aYfK{ZyLKYcg!jAl1!KfUPj&c=U`&fNrv|tZiaUas~DQ9rnUpKu>*iqXJaSxW3$EZGGgKPI(uYG'
    'dTC)pcNcMFn?s^KLByjQQxk#?^bW^DpBjA@JiUhvqdJeEI@aTka-*^n2unEtUrp!#Wqz(RWdTDf#pTJOYd@MFL+Kg7(dP1kky<4h'
    'h)3e_QZK9a-MRZ9TS5qq2HDSmC$7jhQi$1>DsAf`vVs(r1lJFSHalqsX9;&q#00#CL(eE-S!&^=Q2{|3G0L$VKHh)1adaCr*WC5q'
    'Lj`eCR-O3>YmmbQ6>?q(hpjrXK%~IOY{-o2DT;@3-B~4*TKwhm-eb>G(^k=06bb1O7i{v{qp0wxIf!yo`VPC;5C-_p1nFV?>lDte'
    '|GW?AXAay8M^Jv(BwvD#LCl;c;xy+_BS<-5`TN#ZCrQ1za~${_HKTuFB^qU{<jWj97$fzcqnVECSH~V)TepEIU~qM(H5$JyGRE0G'
    '+7L^SX0k&#s~A&WzQ@nQ73-~-65Ep3bEPMcbc&`TT`4wZKToT<_Y8pFcr~SH9l>Gk<-axM4s%79qI+$%FjJ2>i;$`}qP8y_7&x{@'
    'kID0_ny`qrZU90Q5y0S@twVBuP3ifV8}=_mV`_53Y4Nt`h5VfO#ZPP4SW2F*faNTR!0b%i)qff$_ED3q#Gx3rlQd|kQ(n4}l@h)T'
    'L<=l_v!vR`w*t_O621)J0+A<=b)_mP!a5#b?hodwaXt^qj@WkYoS#r%__R5&pj)rgE_H8BJh7lmD-%8-Mo<p%jp(6ER+T_<lx<G@'
    'S?vCd37v$kWt^5J6#2_pH?R|{-S&+=I=S`c7r_2{4Nrn46TX!*Ws#1aDul!-q=d~8d>2-oU&C?uyxeG&M2vCf69WP$fo%>HT-gO8'
    'Wx|p?2|9VxJTxG|+Cy&hUS(u%R`9oDkPdbi66O?;xO76vHQR=xjd0O}$2;(l(F-5aPx9kRZkP^eJos)DCVS(&B0HS4G&;7s-rXzZ'
    '%eq6oin05RjEdBkDXNkglU^S2E~?y4tBl1@%exe}J--?`JFNt3ZX`6{Z9JF&%R!SdmDHmXs)@~Kg{fP5CMt+I8y~0D7Jr)^EyXDh'
    '_w#b2Z)EObT=<5pqX>E58t=_w6k1-o?1Gz0NMxbH!OivcGWLyGa7D$so0`S<6{D&bt&D%mnfJG&fi7(Ci~8XXrr_P<OPg}ouB{#1'
    '^y^2$1H-b6C%K;jgQg5_bm07a+b?Xc`3cit_Z-?i^<*Zb`Z3@TXg~AT)k$UpYRE%_@G16UNG0e@OVvAu6@oeVU@)XAcrKCquGxEG'
    'KTlpCxsdeN@?vu8$vdEvDOH&HXpBa0(>!;&7in6SFV?C3#k|lE8HXA>c~in${6nUYywMXx_2GHN;Rb{wusZTc0F}_`eVO-Q(IYP7'
    'xOylNu3R|BSA6zV`Ot1@Ix+E_v~$^mfSV<t8F9dwz|Tf>|C16p4>8D*7&EWih^>Qxi=3L0N{qulb`%CDPTTj*8Qd@#M1GWdPUzBj'
    '2(cj50{-YM@#`{0w7R9`{g|d1$eYeLL9-<0x@98@%HiWP&?z+udb5T+SqA);Kek?Cwp7}V_IR(l{!-eK!B$E^IX4LYUagEA+YmwW'
    'kCz!A;(T||e-3qCgcspL@JuKx5coO?cEH?#sEw4Nhw;u71R(-~olVQ$dUcOx$bo$jI<S6o>KdCgcaF|Zg={kej#;RD*A_=CBFPS5'
    'z6EK{_K#{#=8ZD~fq6n{0^6(My+QJ5$uVDcnOJ(6W-LCO>1g({ofRc)zr?+OCklhjf&$u!J`x!;+>Ki2Yg%&Nm$(0)XU<r$Q;&Pq'
    'PyVfia`5F2r_?%NwDz)^n)0RMRWfv!lu((PjwSMU0Bsf81~=<^pA^JUEIf3JKfcG_1Nv%mhj{%DAIP~Q-~lnBP|iK#&)loKLTXT3'
    'KpyK!vcBXq$mIpTP()r0*SViKOeDnn$xX0<NrOG!gWiFhNqJa;T^|53ucvo+<R0Tt-2@+Ku(i>gT)($Z=5HeA0s2L|(R^AM^<W{N'
    'fEm}rKD>=X{wX%#yd?Vj-E;X|v)5<W@kF}f<Us|{y0QBT^G914<itPomz?W05h^zv7)};7MA=j)1yS0?DY!Y;ANzpDRi803ujzE='
    'o?YZlp(>dQXiw&Qd<*d?B)Sj4E89V9&Fv>zXUsk44_{vNkg+Y)RbuW;N%D4)Qc?&fUO7M%RdvYetj<9wg10rrmvN68HY+4(=&@W_'
    'y<);`7zaQ7LFkp$34g*&Qx9GvtgS|(nufp+LWP-eCV}o#jIj~?be#R!=xS?W^kLPb!w3Xy^0(n--HpMs^IR3NVfDp`|ABcOv~y|k'
    '`7g7@(42`k0wLd-4-+;l!GAU*y0zvj9qH3~YmuE-xnqTMDAF?e8tl7mYL{_Y$Fs<LoE&hANVSlJlfa3dLO#^UGz%<+)H~ACLDQ#o'
    'GMp)T#6`(M*MOG@1Q;I~G~R1`k4Z|2cdD$|@IJ>0V2omdmk`m?R2heEB(wzNdYF%yL4=7R_OoZYBO}>^C}&1gkm-?}*0w~uXEori'
    'S>wKx4oAupBpbL=WOh(S)*9n!C%upDN&|J`eAX7aViq`T*d7c&`O2?_7B&H#z(5cP(7%3buI@|S1iQ8m05?B&pAN3q{DUF{Ga_I-'
    '<+Tm2*YdAK^VgwJcdR%+81}XSLBZSi6LXF6qZYBe%bjt)wmeIl<?PdzPVop9uEbm*h88dHa{JuB9l|&z*Ic7s1r|d9ot$qs;RtR&'
    '4rlnA_vTE%Q?}g*qPS=R;w1hDTj`G}CuZ$|RFZz$A|v@(AFHodqiz#PJv#sWX{FI;`ckzULdy7=A{~$vT43InR8F5J*{zM0=ym<w'
    '%LHw+o8*yng1}5Xcop~Ey90|b8A;3Ce<DC0r!qt5?AJ<0rb9G}0NHEQkTwX<C6uWfD}}W^TZnp~W;Rn+O(Gt#k8g~|c1n}Q5c0sl'
    'A419&*Zy)xxJ)unI}NB?U<wC$b$+iaEQ2oiP=_8iY5>fVU^;LjerqCYN*nh!W(>e$22IxqKi}u$(p2<$C<rirnVy_g<2>rX24PJI'
    'G&Jr8w$w_eUO@J(E*6*3LW%QUe~m|~u5@rFvkbW6Z+SgyEryf6<A4zyZ+8W_(3alxij+F9-)1oySXh~<wO|yj{Bh5}n20T!O0#Y;'
    'hL8y*IudY#Wi3~|D3X&|x8gp5@&v0&O4!knjinCS7({cb_?$Mkgmi{10fm|{Z_uHxs499}mjhGbsB!g4oS9!OslghGZF;|Lv&vDC'
    'sE_sLc5O@U@l|zMHtf74QcexlS9VfP2Y3%(Ss-R!%-j9ohzcI4RKlCB!EPxcE7Er(b3?Ovmkz7=rY~V%tH|wigSSR37Zd2{FDALg'
    'KTz<yOuJT6P#E3(0al5$FoElr6sZTe5IF+Oi*Kg_f!>lTfu05tyOf)4K^ySLCp$bk!uc@3^auelP^ZK#L$FI_XDh4A^DGyw`v$~^'
    'qDffob2OFLbh-tIB6<esfc~cVLC30jW_+B{WY`e;aPVV*SHv;V)?_<`vCyXzK8u{t3?M;Fw-!s$K}0#}dEY9mC1%<xP-m9>lne88'
    'i)cKe&9F(gwCg!f6N;{Zei-Hy9Rn{PfVL-IY15S{Z@5(=_*dG7?!K%Ocsqy~bn{_6wE~{o<oTS~;*9H8XNgK2n{zW40W=}nC8wR@'
    'f|fI{`905}W@jEo_h#4lpixJ|$#}4eo0+1{YHeb5;lsE6ANa}J_oNimSaeXuPDkxRQ_@_W@SRI4SZF%kJc!;r1UjVw&ktNTfN)7b'
    'DqAI+ev9~E2+@eo?@U|s6kDS;=RJV8^_~QaU?@3{B6#n$E5&?HtJj$q_qKL;c@WGW=HWuYz@Hu)$7G5@D}I|msjvBfl^=(1@o`&3'
    '*n!}UbnX26O{B=}!fd=n7qg1FXV0=L6<(G*@qd!qV;wEr*6Y5ypQr<_bdXmN$&W-BjJ3C**MvFmyFP~HboTfgI+aOgo1AA_9iil%'
    'PEU)rdBXe(!k1b=u**fa#oA>m4{|;EHx1D@g2eVDZcJU02JP3S($TInVk&rBZ91R$q%j>*-&Ykk8Z{=k;~mUPXj(>>=}@(s=KIem'
    'P4o31&X1q_Z{+{n!~5Zj|EH{`9^lH-GC&0ExRT^e-RV#`-o&B1<1~$>qmmE57<|rj)d}n%Z6m}^@ER*`L%_Rorw+Ck7V|GZ`Zj4&'
    'oie{u1-`+#Mh*<yZ<HkO8Vu8l#Kd<RF8>o2W<cp(LEU_xV&8p9-^nUxg-VaxXdzCY^;Hm@BMrs?x3Z`Eb)&8FpKrh;>kJ<*ahrS+'
    'Ru&zE6}0{J?zSD<pt3daOkI^>S!YS5`hPM19KUI*`)OUXe@Hs_+#UKi;>EpQjj6z;2-w>AX**P6WGHofj;erZe-~h5By-A?emX<y'
    'SW^7_F#>tRJ?B(K^(1Of^2R{hMdHu?@R6_J`jqLF(dxPM9*@mNNT0Bjce&vLj3)+I<Hty_Y$QC^-}URAa<(?`?L^>lWxeh2X48o7'
    'xYD$GcKZYFJN{FZbSD}!p(rYSf16P^UE70e3>%gE$T9yi-53R8EL-=fKQZ*(rEP*7nO3!43?PgEEu@HADWj~l#UR4vc<hmIWAU?o'
    '?nzj=a!zl7j~23Js2VnEX7DeQbb|Uhz-wf^)`GWNEUG6MFWsRc<x(|K*0%h+)s+j|Xd6`C4|3;Pt`2WFp~4jc5%#%|naL-SX{*A?'
    'D#ry;xaPd1=Yxw40*i@IQZ)@L-;y6F*{!ce1R5GCyJsIG<pl(E4Xnc$1xjh!a6io^1B9^nQ=T?tnp#k<LG9)=_vvO0A%--q!c*Y*'
    '5W30Y<M&aAMB9{-K{Lcx-n$svG}K=wrS_7eAt5YjhSmR53?MjyVh^uBW8&;8PZl@j*vtkvsmH>Sob&b8lm~W^gy8hq3rKd;fQv^t'
    '+iHb85<f+^MWRk>SZTft`32bo2l6e|)tNCjwpofYGh-ciVVTH)8Lx`ys7pW>FmoEciWE44Ja;<jSIY9J%{)UXDMeW?vVZa3qk2}g'
    '?Gs<6hrl?85x0nc`QWx_uQmn4V9&+qdemF5+(b_U5ZwzizaClT0G~vREp?3z(Y-U$$j*bQQ?X64J`dSj?p57d0_mE|`NiP1Rekl$'
    'H|Gr!aXEe)5P{Ej`MX7nRk8s0uzCD!WyNJ~85^Zs-JuG!@pE~UwL49n(DUl~v~a^cLRRM!PAaWO3OxIMz4Q(35+OUo4rh_7Ypi+#'
    'wsk&1BG}aCJ`VhvH*2=N-C1|-0UsJpJZvw3`;H(}j=@d5+k<vQj_dikrX|KS(g8mQVd>+OGf)G_COK35ZPk?aGb87%W@n+t+@!hY'
    'T?t5s9pPr=;xFuv0bRLwpm`M}bsHJL)lGV0SnjPLBmL|!SL^0jI%x{PA3LCiFv0r?kh15m;j?vZQ=`vpc8AzWqVl;$-!aQEK$ZEA'
    '7yy^}X(J}?DE{8-YN?<yS5SFJ!{Qj%kC!D2A<^yBYYWO$hJ}j9Hdk#UCjAo8<GW52uXUZEYeOS`F{s@{-!RG`tlvIFnaAL^Tb4fC'
    'OjZETPG9|^+6J`jnEeL-Y6({o)f2T~9;*%~D_H~+Xk4SPJ270hD0k`T!pWBrIy0veo=G>7o3m_ZebuB6F1Yw@o4})xa4RoYu<&2a'
    'nT~pD$&K8(Tu9vo_a?$T7_vct2-(rT*#NCQM-dqcWJK$n(N6nB@5JHeH<SQzGZeys07@PwBJVlAkGtvEJyv-q`Ha!9cPVq1LD-)m'
    'r4X~IIsf2W1X$2NmyC0>Xb87eSJ(O;_%#HXwRm1hJD?nph3#3Iz}nL?k&_LgN5wJva(j($Z;Za%L$R)xdCbE2NX)z#*28g84tuJU'
    'S>w^UrB5%S+4*Sp8Xu&V%!`{ff}o!jRiplyBF${eV#10+rssgja^E^^QzCJr=Dl@sFM_79jNQl)=PEWcW}^m{MXKwWJ>5=t@4_{e'
    'l{Q`s(n}!s?<C!#MpGmqVhY3n0+gsjA@hg{_0=?&+|b&dnRjX>?nMYCV{0sEaKSKA#O2Sq+`*H=e&H>Wk;UUhX<K~XB+CR1R7T=@'
    'u|XgUMn)y!a4*IvzODmh+$xamVlUeT6Nh=1%?nb4uq_e?e8mJH^*=D>0a;hDcK6c?*LV6w!KBL1P;<K=lfdocjBM~LYIY491Ahyi'
    'tnZ&Ir^P<C9e<pF`DlI;5i`d-gJkqsnn|ZFcv#N{(4kYmZCXz_IHyVJZ=Crc!(u-ffUX|scIedKNxbvL9sQm~4f(tLvGOdIZso~V'
    '`urG!4$)Gx3Qb+0Q<jD~que2A`}ArcB0`3u)LpTq8t5v+7*ZO_vm-9-6)1>(P$Le5W=Hmp`JHZo4~6e4@*7n@>1)_>0_V9ftplot'
    'Z&R_HVK$>&hSV$hHin+SSDFuZ2IHF$ez2tHNR%qEXkN#(s@KbWOD6i+A7XrAUj<{B1&~4>Z!o_Cbf~e_rs7Y=Hk$vpLIj=ZVurL}'
    'ECm*AV4mBj?R_cMRUyN>y%AxNkC&lp`Y>z#lS<ab@zSUlp&c4yF(wa-=oWPCnVlofD0dp$qLhq9n`OsUR3^3*G@~seG$r2K>F+UP'
    '6elO}5mR1y5rG~KY9JXxs=jJXj3o@e$XtVVHE1PROT2;w(QkAo8J(jdmY&}t`QYZZl2^)Lw2@vnD)GxK6}k#np%^JF^llrq<Tkw2'
    '<dM_I;dw(NDAo5kG-V%`r3G>wP4N5FF%Wb$w=jg;k+pVdyscvo)3LfO@WoU%g_~MR5@r<~6~CbxY@ITvz<+9^_keHC`9L1u936=9'
    'q8vi*V|pVmgDy@0S(0jt*DOO;i^69-dX_4g#p0=e=IUAuyFuz_Sqc7NTZzxBL?GpY6$B`t=qg**I`_?-?HBiELGm2GqfB%&+SS$M'
    'D@yj|NK}?Rg#?)V7rv)X%z>&1y4X<1?sL&W<F9OxzxIy|;s0*()!s5zj2sP@AzWNp)49S>B%oC13e}!x6<ZM!AN7IJ5s%f#GD<W1'
    's6RjVR4Q&*R~qx(;;SvwSA&qEaA7DB+G+|~qKV<FFZD%>*NHQcSY_NccxjLMQ`-h=eoYK_e*nEoL^+8M4XWH1;YZ5K>6YE=M1ys}'
    'vJUOTRknNfw7TSr52%iG{dpD~sX348s9?{8;lA!^c+j#gC7yTtDm#-3fd5>ftYs@K>E)r&snAb3o`mE#9WjBo6(%taBTePdsp$oj'
    'U%0u2o+CBbBEOf%2Hs_S3<!d|L0t*{kT1;oJ3C1n^2pRbdqyM8xaP1S<^gRwBnC1(5kup78$`V|wy!;9M6f4Jhq=3o+T(EK^De`S'
    'cUrs3WS1>1(%Mx{BPB>ac&Tc&cG2Q*avOr?MpNH1@O1tNIbb1JJG>;LYR}Wc+`ygU_08q1=fk0wU7*}f{HU=juR-y?ndLgR$|Dm?'
    '1YP4sOvnKTU>4n|zcz$mT<?R{tF2m;<}JhdF1RNa+|L>>82|Yy-Su<1Iz%bFcm^PsN&s=4A3g<QeLv%@Wbl#&#?FncCYc{$;bHO1'
    'mHg|dmwOJRSIjr`V4ipPEK#gjy&>Q#j!Egh`+<_f5bN0jmhm#9$emLc)I;Gb>EID?Vv1|CFHjoj{E`MCcfdW4C!%Y&JJ6Qb8+l)F'
    'IL;ZjB);bUzR;>~R|CQf=>5os=1&F-Uv5e+c9?5vkwobAgiV*bNcPWN#efv<)BM{8R&iskJMnzQ-j~xUJN3b4)(XHlM=F$AGA6;J'
    '{lB<8>Z*)}9ouq+Y=1v@J_wa)hA?-Ah9Msh%zhyJ^7i6Pl+2Nl#iixE2j;uz{6rEeLy_x7S=@LQ?5O9%c;50-&^0z^6{hyxT;=%r'
    'UU+z_NFK1uC_q86vg9J&(qLl6c0lOEk7LldFdfLBzMAct-+$&1vs43S@?>+qt2~{a=HBkcVf*E^8rP>w6=|7KGkGNp@)qJRl(K(2'
    '<J?si6>TQuMq22QZ}_D_^$hhwqB?8i*}w32lcvPf-ENlaW}wqT(6QX~J;>q20<*t2nhbNYQMMWl?FcJ|Dc)Ss<}m9*1{k5%Gcgn_'
    'r+skh<wSKfl=oF}i<)_Oxf$#PX+^)$E?fL@sXmZrGJp<h!{IIywaM@{8NjmMml+Kv6`jDx{RMltABty-a#mp|TVXthPgNACG(jIk'
    'tF2%IViOV9pEi?*>rF**syn$tNxwO*<mQ~jz3_y?@G8Y2{5PggvZ3$P5yCN-4F<VrapBKt=Rw#E!lEafdH7EW(g<8;s&X3*3Eyw)'
    '5+5Z%lcxt8ODhH+CZaDr@Y(H96+&*BT~jk_I6*16|6*%{&~q(A=$Z9seO#w|HY3lc6xXbC?nuwc6l*7dO{jAN1hdmte^}VMGFK^z'
    '>69=+-<s5=iDM+pWSR`gUO-I<Sv;~`niN##4@D21NhC82nCrhAr<hUvxuZGoNFdujSEVyRjHtze^X)DzpQ<J_$PiZHU0vDm?*B)1'
    'Tsn^zCb8UqAQhX<gM{|K58~d13Mxc2%)TuBUJb@`;G9yfp~?_adjVbF#OcfwI*^;PP^E+PZt^s=efo2BQQe183`bea@@gE%LfX7n'
    'MnYgByh(7M`*uFTWRnJ@eE-X<e{(t6J<kM>A-#i;xD&Th#h9;ZTm7;;1&n7{wTrO>bXhKE<JH$XRCsbqgbeL}o0;Bm%q`_q6-fIr'
    'f#$ShchY>6C=DEj2GM%)rDWJaQi&wp)1kEBFdv)+9o+#rH_uf1##nj@-&~o4=^D`YfVms8uHi&PGrhK%S^d$pOiNuqwRulDPGC9j'
    'Fmu25@<YoG0M`tM4g7144k8O)C7GLH&JG*F2Z0WTk(F_>WvVIss(r9v$OT!ZIJMdO-FQ3Q6#eTznKsIE!MI%OKJ=O0(kHm)`0s+<'
    '--9fi4%*FFT`xS1v=R7-EW-OLJJ*UWwHhUHUNfjhV~VG#ix4ifFrV)<cfg;o3LZ0mYz3El<%v(c*M48^=(zECm2P2!MJ1*gpoDA1'
    'x4`fk{uG#;E6>1^nofO{vJ7eYUXWzQC+hD9`t*Bgy{#utx2(U&W>E7|_r}=qkPVvt?^VN#3%PsSw<h$&>m`^v8{|6aeMnG#JGJ?X'
    'ZF?Jw9Pqqww9_eHkKr-8;~qO1bYT2$*y!QkYH_-I?}Kx$hM5Q)v2TxW9E*2#2E13otP=zjI~pbpS2FwLz1m(l<?!)JiE*R>?kEg*'
    '9}!q9_ogRwje;o5kDzgt;*z;OOnDn+zCI|6{jkm~3PY4cAS*xXJw(+5Kocwy>TKGnXnR#Non8H;0W=4ka`_3#LtS_AX>+ba0>f<('
    'CMtiAgq(QzV`b50YBn;N<-XPB_>biharCL@@hJmW71XnHkftF`RC*x6@fxYUeOD^vN+3z1eZx@U2*Cdy;b570sU26JBkn9Qa<(L5'
    '>E>*^`a}jDBe?KYbko%=OqEnQpou@=w_C#^O0I5`lv*#nZkk7QmS6nOVcq4}Sx<=ny63}|vqf?X0JL8|xWBj$M)3fK0=_-3xU)n$'
    'G6aK09UM?}%0y=gCG!|VPsD#28(<u&Tu8-W?rnPg>-$B4l@-0m-BP0jVKr-66g^2vMdt2gB}k3@UfHmR-p|AKwm}0@s{~F+Ed+fo'
    '@Cts^SI=9Yx*JVPM{yqnm*G=b@dPDv9emU5%c)7lbS?UA2N8ZX5<*DowNyyDtR#9um~OPA^2CUW54QnL9-Ch5wfV)tKC;BbK3uC6'
    '4)SXLpBzC(cbp9sQhB{m=B!hP0o6A3Q&44U6LC8MbLjvZQd(TWo@`T3-Wn&cgulQPF{lt2J<vBTkjZ&iGLN?Q9vx5t!tn<Yr@z;a'
    '`E-n{VzZ;&&id4HY_|yIi0_Ya(1Qo^d%yBjq3Nz2Nn`<(ubB(1Gg#r=U@l-2x~M-Ys4x`X9{QJ+{2O<n5YyT(a6%+MZv+Y%M@*MP'
    'Q95E!zK8BtDF}lkmbt-f;t6TQ)J}-){)^HtJ>x0u_Y&ij1*A78hXmTm;sO>K#Gr_$0*>~;Yo&SP(YzcvjyA@ac9kq2!+8Er7X7~A'
    'zWl6Am>=q@{n(~)@&Jn%ToYxqjOM8^)Q!qQt=fF5R&Wu}uix$3;6Yv+*lRH+r4Lyko-wS9QMxGR8ZI^Yp%1vVvm(<kqMONhc9gbz'
    '=AUOTJeEK*u~`pZ2)jw<c);vTy8eO?1iZr2owwnC_j#QZX;z0sVkn)UXHmdrE`N=<y}SfF!NKeWN#|9HxVXIQItE5qj439(3OC6}'
    'T)Ao>2y65kPimbr$Ww)&JnW<)Nd>lO<euXmtZ#jnv%BFIrnst?DtN(X^qmJy+JAIy8;T_n^Y38H;Nh-6`X$r?27K8(q%tz=crb%n'
    'vM?GvlbeQ<Twk=3{HzZ&L`Q`<G=ULJi}50b`w*>VbQF~7#ARs2EURpvA^L=47|lFruvyave1CJ;8L)OLxPJ~j*Sec4TAHXml5HH0'
    '>M(<7rx!Pi(D-|Io?$EaN_O<()U^7zchA~uo1tg_Ln75=pC8e)oN~4JvjNSnf^u!YcJ*R9MIH_I+O>ikl+At8ISrSU;5&q^srP$8'
    'DuCMOD*i2#o)~n+jYkp#NwPId+B3awuJTH0;Beq_tO#H{uthfSY8!Ei4{bJtyf)E@JFh!g{j5L{z>uIIkI&5`FSz>Vk02ld;)<~4'
    'fbq~ZKmyOhIit&`q_+lijmX@~OHTy-kNL>lg1%J+NpB>;Ts=F#*Z+!owVA@m*hjeudSW17R)bYB(wRidpr_eIlfJ}g-nJR`tJOAu'
    '$;Qt%{8CgMcC$o`%@oo+A0bAeQYPV=9AM8JLJ~=IV(#vzjMESLuL^wEf2)E%RLtmiJ4MPX)C+vYqhHKHV)({>%_tz@fZ{K7@yFZk'
    'YhaC!4aN6c0|<o&c5Ozj!qcK*b@cGGWiQUG!yxYdV7@aZ3gf5$)g)uHE)brkj)w>`ZiO=|JOZu91u~LCFgT|RXMhp9U23v!<zH}f'
    '+65Ih_d9EUV-i=WC54+NouA{Qa~3Rxk*Ny~m4?a%F6vV{iSYK`tvrCM1%rP;mBb&H0ye9PUB)E$KAw1um1>2pu79=_mGU?)!Y|w_'
    'RfG)xdP@!}5+0*CKmKeIaQ>y<&HXVnmgIetZ8RKJrzwfd<^i~dGn|vN;D-a5GnG`1SzR{5u*T&#`%)2japL+9nJ2B7o+G^78mNvZ'
    'Im{>}`{V6OIjZsm-N|Myh_eGQTL5?(u(1t<`VKd}>fNb-&gVsQa<Ce;92~4*&cx{1|82GxPW+}CSirfnNxj<{)gJ#LyzvDWcQ|B('
    'W8gmqbIj<UbI}}khxp+HbFA5XqM7?q%B%C~y|8+^1VoRKuyyE0I9}5~C^xX!Xa}ylYhk@^mB-Ryze)G`o8NA*pn(0HPjH~kgk~9Z'
    'wIHtdE*g7rg>pqm_=SisOG7F}mHU*&R99YF<-3Yu);gAbcqAKsN=BD_HVzH&-v%G6UB5yHBiew<lZtBcw=?i5FKMzPoyCCSr$db|'
    'S$XB)rra5(lh4o%+?gow4`<HGM-p1W_RkWa(_3M>FnY;yw*I9cYj$6fnvfZYV#+N<$S>;Vj)i?6+Um4f_MhW2GsFxCvu<wQ`Bx8='
    'ktM4bI7Cv{#(kW6hATTLq)z6zrz)8H9ydrl&Rn38R+uIo?oKuQPm{=^gf?A=J1uLOK67lf`VCyfpJnihh`Xjn9WIwAOQ91ObFIw#'
    'CrlS_Qq=W)Y+R&TNjCMZlzdc5(!NUx;cE1T_HM|_R#pl)JCeU6l`#g!=czDiRzYt%?uH0Ox_elgVP1t99n-4?jD~y&NfvidH-opB'
    'V?bBUkigCYX*#wHs*f%L!ceQs05@cO+`rfZy6=Kp2Bz8g`B<-nNypje>^aS&)yv6zwUNOaw#O&FvnGqSwzJQRGU)7;Sv0VOTn0dH'
    'w}!&|LQ{Gwc<0A7jci3qbJSCmd>#9&01(-iHj2ED*DJo0b~W)H4CGZ~=qWxcs&yuP<e^Fz=BY<o!r=Mz5dnMx&;Pf0KR0vtnDtO-'
    'm()it_B+W|daG8c#L0N6>?t)bW$t~JvuQH|2ahWX2mtO<0z|xqH{<843~8ZVMFu7!Qj225jXVydq5fMCvbR4*t4O8-$e7U`ng@+U'
    '6j;$2H2csYeON(kC($4+VLe?)iB7Q(bY<-62F?=xg+X2N*TPoZGG~nPkgj+0tHck_?3Kq3Ql}2n<papLaUDmb7}}%Q6w@Ko{4<NQ'
    '+tjJUKjod3n#3_`wbbHf>V|^a$rOJr{;^v)H6@bWRFXZ+CNulyi82Tdo_l(feiW)o{LL0hzzh^6!p!X{2B01S9De`0>vMY2Q*!x#'
    '7Ma)Oiwt-rNqgJ|AvBS91ra#aQyDDx{I6`gVH%FCM0|2}*~T`&+KkPaH-XbC>Gqm+{D`-0)(w?A_K7~#GMwRPY{yF&A@l0mCR;yI'
    'U(E?-hZGzKOeAmU$C#q#9nk@WViTv?(N&+e0(e;Dz)FN-HGo{(x~TS(*T)MF#O$Nw@dy75>oy_r_lZROuBE++thqt4Y0@}sRLhiA'
    'S#2M1)ZMokO>%;q32P#ShXu<$?R*R^8yVB&op`Ts9LKumUz`4S9#+t=myvIYcqRX5;kg_+N878;1lR-8CV&40B03J&3=mjw_o5#Q'
    '&x9zPb6$p|T`FlghMG}A+fUc2l6`D?{Q`*(or}wfh#1W3R9+QXs;XM3rZ;oMM)5Ea0_!&_5-%|=z}W^W2KsY%^ZK`hk5N>4eAoJh'
    '%W+@RtFz$`b{`Fk&3Eo8FVhss<Q)9AZcpH8z@snUpLy3Tt&9;%qBzB^Pp;nfA`hwIKP6`5Zaq*dQA5D!3?<6B%;RmECSJ|m25H;4'
    'ZhHOCBiy7~cDSiM3hRBCVlft!(ZPrT5R!du`0h^KlJ9p^WPUe;oem~!#<Cc;qiansOg3bA51@32T+JFa9{!O-d(F~e$E_?RiPPB|'
    'yoC_>+a!QGH56FpM<F23P&O=lJSD@UC7Y?J0~|US&&Mv?hFg*r*Q`L&tCzPtw{kM=XwC&Mk`vkQJ763<<Arc7xNmk2F|bHQv(XEI'
    'IDe40rQ=x$M#vnTc|*v;-+sdnF8adO=dp!#<CwrXIzqRi=u?(lXIUcZ7e?k~zM*u_4eCy4=hi!W)G0EH1uv!m@PGW&t3KgKCFt2y'
    'OtvYBnQHH!9^sCgZV(aLLvu`TfJ)Xg5)mmtdGOJ={rJ`-d*b(_B24U~@+**=)K)9mSS>*B$M68w!aqF|3L{l<r-<L0`HD%i!%1cD'
    'eTpDr<_fE;TD{D2P#A<2bG^N0SJ<I<e1x{+gsy=abQ%2<;gM{)*irI&t2jG_nZJ(`@#(X`f|^OEQ9GDJP;&U{k7=&U`5Xwqn9||4'
    'j2WK^ZWw(BSyvi5=?qm~tf@x7rRP9|_Vnc4=!BkAH?zb{{@5;)Ye)D%x^?a_ejtdO$5qwD)<|f7NO+EKphApIi2rd|eE&v_EVp#V'
    '&|PMB+=R>fzf@9`xT{mO&(T{i@k0Yn*53Mw&Ayq26^uO9aS*xoc%D5>4JAe2kE{)uOJK#H=$u8~E}H3bytSr!D^h1b=$`TrJRv!u'
    '>n!J;6ZI(90x-|Yuexq=BC?N@7L6yIlR3u2MNs=b0foJ1FoeFo7#4!!n0sC`*l@@rIRY+kcXdJ26*~d{7fR8>-D>Q*JvEWh#mdLk'
    'Z8{P>5=&;#kP^upY?Ke5R&G<rK{LwumZeE&kNHDg?s9-S{`NP<G#oovQ9-UN4dg&S<f5YvK(L#*-S8iIrynXlYt8dP)Xw{gBaT|B'
    'K~<i;#2Ts)Q`NC#5DKlP8N}eQQeV<k0`^-va_B2q&7#vIwRxtJG$Oj{>0^jwiNAPF#vF66X3MS1&BQ$`)`)T4YaDVu*5*AdTG#8a'
    'QL-@vX8T%S%-#F0cO+gaS=qKL6eo0cpjZLvMibH0e>cbzUd+rr(VsVaU^~l@l}i0wAXUV_>lR#}x@y(+WlT^O<`od|hFr7MxWVrk'
    'K;e%&3kL~0{M&{AeX^+hjnM_>PQ(w=t!cV|C>}<n{uZ2Qkrot5F=T2R)ic7Pg#p+pGQF{`u=H)&zhQ)i@#|ps=LpGK_(0c#AxtUp'
    'Q{g#tuJO`+bFkm##Y{R3mVonUUj;TTScZ&x_#WXgVIFkH+-6`US?uRT&C{HBg=F0ORBL@z)w*FpC8QOXNZ3z&<|JQh8!!Uzu!+9d'
    'HU{6+`w#dFI7wSJDpV;cF{&?}q{Y<NnPFG161!MjH&U(SjZ$>?fE7osL?2JmU)}pL`tJ)wcZe?s7!U2uCgvQ#jw?YOEkkZn=a8D6'
    'F17&A0a;f0f%m2j)jH+GL=5Efw9P%^P#rDH`$4HL4@R(iu}WS^C!Zu0S7>1R90l}(eKg2KdafgaJCV`acd;AwXn3JT*&=hH?8OG8'
    'rPA6oY$u^H#=&rU?;3|7d;H<c@+Boj#e#H*g&KKY0V2PMkm65b2BzuGLwgU{f>Io4;>!B|Z#Vey&V?bPOs!0zHPC32{F3N*x%#HP'
    '7=I=^x#5PCi`YGVF&keh!oS-lb;T7k<qH6q#dXMJgLYD#7f}X&>24o-VZ9Q_p^2nxt0Ch3QtkXg_y10zo>&9|aC^Rq&s)#Ss^KN^'
    '(1b~b?~@YI&)T?wNs$iF^gHv~KaM_TxAOR*R-xzMdDIvr4cU?BM=qyjfw6SLYinunOD{b`G(^3{iae%WK=5mYy_gZT2ET0%!;+n*'
    '9}^Li>!lyZni5;HTP{IEQ5;{wd2;flO;H4Wd0_sH&pemY`VpJoxC8mNb*xtM<mia^dw8X&a^M9^RhnirPr)OKBXNkNyKF_88r$-_'
    'vcpV?3dbq)Q4h^g{!QfttW>VwT|6Q??O4R67&X?x0jY~9b^;AfJ}iUf>bnjfrH6F5J2BiuH!)SzMkmY5PHo0&Y}GW7+(|WtS484Z'
    ';6#6U)&#lM30>TZ#|o3nA*lxj#x^td<pRm~vZSEwM?)3+E4Utn>)Yyn9fcaK+cv%kP*ocNAs_$IhG_l0m1!z=?xp+D3KGK=r}xv^'
    'i!hCxG6;?p-2y|n^=g=c65qH`bW@+Fo?QgLBL?9p1`5`~OC<+vh|hq2?3W>I<@!X2?h+J{SdMzJ>bUAT=1sOPaI*7*()_Vy+3|<9'
    'zWEe+(<E@W7>Fzd!!x<@1w(PE!0LeqXlB!yaZ+i78<t{FC4Vxjx-AZLl%z`C;O6!wd=1fsFI@fEw0SegANun-fS^#2l*?=c*?6a}'
    '3}IrHN9)DEO{wCCN{DF|81YPN>PFm5qF~<=?#rtD6jNVBAGp}pIOe#yD{Q4Y8XJCz*xaDIe>*Q6jVr~xby#;2e@32x=C20Q5mE_k'
    'M5dL3CEy=M2&Bir8uZwUUbU?UtRgdf!G@m_^*5!)TG6WMedXq`be_W92#@*$!+Lso`(kXQzq>GHu&Qwm4!S8~Q#ow@!T48kIfZ%('
    'eKb8tbdb$@9-!LP;hZK4V-g*mb`ih%#75{iW1ua*)AxjlEgX-$C9-yjon%qk=;T1s_`AZ9yG*tMWU|y9*#6_N{@`rM+Ihkhq`75d'
    'af5P9m4v#VmTzqV%0eUsxN6q;_1)HCQ?{s`e~$y#v*<n!W=f8HID86%ssQ#N>7=B@n;qRHc$~!y$tYrkPZPiqhi!l|43K8y|G}Zb'
    'hY)Jc+8I35XQr%#Wu(psreb)*@61W?_GT3UW?Q0G;|`eEi-@NX?V^;mdpX!Zza`nOPca68-)GJ`Ar^V3smB|cBX!+n|6n3c{4=`A'
    'e(-iYQ+Gn68~e`-CHm#gd1A+%lRcGS{>O*aW}!-AUDa$O)v8E$bBQXh;5o7Mmuqb8!#)oHdwf816S^w|Mpw9!>M|)7v0BUn(=#|<'
    '>~Bk-(9<5`^}``!;k6dxfj|UW2O!&WVx$<D?8S+LWnrn^;X7|r3odwLmlRvg0KD9jZ9Sk|QiDdISEHE&SxSNmF)$<UqX0Q%hju2W'
    '`MJLqhg_bor5oq0`DeKHLO1)6nNg_ws+Z>*L%2;*3vfhsGmV6_<1Nsh=*+RP$}01FH)6E3Kx{A;j*$jz{EN1FGaN;i?={mWJ7V_e'
    'hC26>5I&(_{iA=}Y=x@{_)Q{cP~gE9{ZyOykj-r%bJ2hy9oJ`<WC-qOG-x;nAJ#4({f0d})cm4k`{bAF-DW)QNoc)-{RlbxWwsT}'
    'jRi8ofiwpvJuOEIdX)hKGZ`XVm)zyj<!Kxh-RvvNhGo8DBXn>l?Y5QDulE{We?aRcoZm3Vy{}$Iau4hiodhXT#vTa1vz%lqnHjs`'
    'O*#PhFq}P@Q=1<AyM=sn{5-a$CVQwsBP#pT_{`_y?K{ItkduT1e&SFVRmK`GqFlz4KVaPN>u~+&q&Rdhy9r?}=79<G;k~+^1*Jl2'
    '&sP$l9ZLwpC)rbl-%bZ`yF@$r##Sro49$q~A|d~qwoGqr$z`_kwst4Sb@+{xMr4Qvmv^w7@UuItyNBgy1MV(gPR?L>N_OU*r|bSa'
    'A@=)?EtGmcdHa&{xyGv0`c`@{2zWT&^H(}KgxrB6FC~l}C~Y4MqLXN4$es6`?eJy1^;?AL4L`~>rg>`LNcpIt+{x8=5^d^@1<R{r'
    'Na!NCndNf~!nz(Ey1AccSoM|3L<Yg=*aa=PxpB>sN$!;`!?TQNs1R<SY=ni1S}fy|Y3;u664qTG;Wln#Cd?yKY~u#d8VGlX+x*UN'
    'V32U_43@bs^<@~^^rv4lLxyA9DLWw7L&sRka}-!PORRI&A`Zz#{sNC;FT*xBlqGFpuw`8jvmS)y`{qXS6oj}%Ax-~@1L5;}SABf*'
    '7WCtn)ND=&o!t9998DU8dY6QjRpQBAt)Eg@=+bb@s8cCVN7*f<ZpNkB+#kV-mc}V3i92jB(|6&!w6PZ#v3L>o6M-zSo&!;vCDN1$'
    '<N-6z<ZLs<s!22A9y&If=tH0|8H2~FbVs!!Ku;Rt7=$i>bPbb30fQf*`qazS31KG^vy?fI(24KEJDf(z2-eLdg%})KX)4(f<89x7'
    'UV+wnBn_%sT>Zx@07y-uMQ$D7WGjl8EkF|x^9(zT(K=r2#<=1qXf>3?4YA_lDhN0VBca5a<X`xTdqin>Y`DE3!ntZAD}Do)ed$Fh'
    'fc#$zWKhf{bF|%g9Pb2X^ECPqh84Eds%jEZEE_J3fB{1Q+d$G;az8!|wM*uo|8S?r{4hb(&3zocEVJJs@zrcN4s`7Syk!N(=bF#4'
    'a&15a#Yb2~u#zj*kV54+mQV0UY9_zEbpKwetqBOqQGyRU=X=(Bbg%OW6C!%Wvf|_BHiyV47H47zJlZK%9ULrA?(JxDCCPir`gD(('
    'EzehKUtdeT5}oRgq3Ty<;wq(cHgD!8B2f-;>Ae7e3M@}+2{ohG3>+*+QUeR;zcfwXyne^y@#EqEqx=G=mJx>YOp*d6Sf!rz>O%XF'
    '1+Mk>GK#9sO^+J#N1|ax;Y+GU1L-qPj4AMoz*+_2hea~~OzR|xT2<LrP^cx$h<QU=9P@uo(zrj^kwT~!YCLEN@aqLHAu&OkpBcrM'
    '5hNi4Q<8o~g(0G6?rY9v7A5YL?76GmEe<b+PfO6r#K!l(={65i4XUBtVI_w-lzjp;Uw-*MxRxjO_x?{C4CwUjof*_SqykXOe{r4O'
    '$$FZrICT@87x+8<!G;S*J2)(MG+bU%3k+0b+D`-ZKI9O!1t@MFEj~Fh7{W@#HOd-`9K)j(zu|YyA%Ag#IAc2PZVxV02$bQZBy!12'
    'EE=eiV}>Jv*rGdR9*;Iu=U0+dik10wEuhvxHj21Nf=FAF^k}(sg5O*JUD3`y0*iq&`g<nl(KJ0nNv4!9?EU^zC&0_C8*S8x{xuM2'
    'wI~=Edga#m%PmTh{P3RpJm9QG9j`<Hm~&XiKvjm4puP;v4%(I%JlD4Na9GYhG8LW58shWTGN0kp8)L^orO+rIRdi~Ttt`;8Va?i*'
    '@qYeghO3c-RVeTx3Y2xgEtO$INtvh^GEAO*KN%nGArzfGY7|5mpW0|CWgMWBT5H|oHkp`UHDDL)+E;D|2)JHH<Tm#r+*r0<naT+W'
    '%O45W3o3u~yS|?G===&5>+C!+fcDFnSR0`LkulbSkWH-BJ(y$V^6?Eg^~gsWQ#}=#$Lj2Edhi%2x{}X#s~zH<@b~OL#S&Xnj{e2p'
    'YKt-`Y4gxv#|b-PTZ(Ox)*Bu4I~Xlu-bc`DAwiuND8_!OILL^8ovl4Q1<;J6L_;yWmoCxp(48`w`L}#<Ac=pYfO&J{BR_Fd)eEdf'
    '-F)<cbkOV+JO+;f`_EvX676y5GG#VUIX)$pE&C=;&@BFn((il@3=|80+Y9<-?1Tt!G=sq~(e6jK(UF%xC&N9N>BUs6jya0|2YyuB'
    'hG~P(j{?=7+^|k~-qP)i^6G(Wd6p2RyZTx7r~nG5!c_XIRA!R9U)`9fb<gy&Yt$1EvsJ(Pk%A)zQo9Mzm$$VU_m#vJS7<yyBu<HB'
    'unezXKK59;81(c{(}~%-J)-SvJ-3T?%4+G6OcEnU$~%%<Q!P+=F8R1Sy53{%V9i)Q?BQSXac1C_g)owx9YxqTJMuyETXMrYq)8ic'
    'd*W4CJG4hl4Jl)^p2aMTf*rO}p~q?UR?^7D`H~^I&}ro;?BK*On8{?}mTdS7vS>TZWs)kJ^SKHWhlQ8v99ZO(HJnxxg*4#BnKULJ'
    '&zTg0Dtje+gmdhX&0jGhnY6)ZZJO}q!f6$b*1xMzqfFNO;M{+VUwRBWZZ+v#vui*%IfYWV4I2P5gBcDZ^MCv)pEb_xRjeJaL=N1{'
    'K_}R!@&p5@=ylQC<lqfR<#`N^l6Q0JM4Ev8N!%KSx&y?1Y^HH7-u(Gt*8njjBo_*&nCg3=-5|=V_mic%M_$5sXrh-Za+&MCNUBrd'
    'ZcsP00oc107|$iH9n4flt;_CqQ+tJdzi`sS4>|lw%>1A7F??YTICK!6>Km)q*E_2Z9hMF~LAGp**%*<YS46KJj@TKpNzWCU&uH=l'
    'NH0gOgunkzeuRJ59#bt%#>>(q<CK-}fu%ve*w+WTx=X!I*rDQ=Dc{PiyXqB7xcX1YO^Jl>y(coJI5Cz!T&V@I9oRG@4;h^9rHqW7'
    '9BHkJE|;E}`WGW!rA0&`W^-VRl}$yhJrfp!Mrp@s-4IN?*`J%f57F(b3vZZoPDnz8an%d;fe`3F$ziP@sz?nS6fT`!s(VGj>8*Gg'
    'dj)ujRw9Ws+}V$K3{nRp`j__aXr1U|lIg0>o$8DM*KCZ8)(Cp>wXU<m672qgMM|E(jF#9c)xZ+UL>eJk+eAfEnE~fAf9&@0MWM)#'
    'oyGe<h07ob*)^lqjGB3tCjwI|?e|6G*U4tL+ab$itA1nXx`6jhD|2q1Qt~{?W)CI}c#{<o(?tie^uhl@ekYH#bAwPqTZ2!wi*jN?'
    '$`Hj`2&V;8XAVrLM#SVL-VMHuLm(xba+D2;6VCBcI=G&xh`%9i5ut9fhnnp*$TIKqTt9R9DuSsWa<9gai=B6HAn>y8tW0RtZ)IcD'
    '_43tS4A$sE7<=E8RsGiM*Qb1ZQHmbO@S{5?m=-8jGVk9x<zX5}MZ*X^!4-v0NVj3n7@x@0%H~m8AGPooIr;))cydE^=C#l-Fmhnr'
    'jHyjfs~SAw!;p#d_dV{_eC~7*!doK`1d<R}#%(>$Z<|8`+=on*#3HlKZW&7Q{Cs8N2zbrRDw(cW?~80sMKTu<4VZWFS>v#>$90&W'
    '^jx(g_ejKl>G*03JtExU2@)<-Uwmhr2iJR}lQz(+SB+Rv6Dw5rKfNJ-3s#joyAuzGUgKz;$&E?;?__Gx-usbo()*6)&gZK4V)+_v'
    '(1B_zDK>VN#e<`F@QU4%EGWzxih_~W))fT>fqs^Zx_Piy+#IDQ(Hxbi#cNXdS?~LhU_VN8V3hEUOzI*<n#0Bl+Yy>-yBZUm#bExX'
    'X?IsWeb)iPo=?fl@s~&v51lm)9*Rc<=0aiP)-au2jKh}BCB6Icc4t_)5$(}{CmTHhJg1D~9Y-ZVv}}9`xRQVER&E@SPSaMRF9~nI'
    'XkF<|L<QEM>+eRAH5H_Dv|EnJ{c)$^*--VdVjWZ#e6lUoItj+uGbi_+KIzL-qc^fY&E~!YvGSw%SH$JiESUFfq>f-)iSA68%HJeo'
    'y5Le!fz)guB(b!1LOnYyr=JRkw>~Uh2co!#=4F84KrEW0s<!VJPg#H`L})F6{Jpn7RL?(G3-#bSvb`lUx>(2ii?f!cuj?rb9Yx+Z'
    'u^NUb3K%Z?@-l7Z1KbJPY#lFcMZ3Bpuf3>WCOo_0-CG0NO-D@>z`_)EcGl&;)4G5(5lp_;&JMk%^xeT-Ho)8HvwTtc`txM<fq-u&'
    '?AUpm2scHe3Pc%yA8VA2oa7EHfAU?}SsBIA=}vH(A2k@~74f^TH&;i9b+#BA4Ja7HcG2ka%a(^jk~=G$uFK{i*4s9al<eHJ?zuv8'
    'HESzmKqK2+1Mf-No`KR9JExu2H*$#aY*{xl{bcwN<?>mu%j2~XUQ*~awZS<omO408q^+FFt__`gq;f%=>fuAC+w#ZJ25A$dZT!|n'
    '^Pk{9!WvmvR=0U3^Z9jP0x>Ru)n-bWO8ducu{I$K8Eaq?XisI3JVO218XdWYaQ>o6V#<oHh^N0Xm0Pd(G;h8;4*<OO^@pYa+WuMK'
    'W+^loRu{yq57A^ArU{*?6Q@e)hX4a-_&i^=Q$mn3)@~4%qH3xD)N(JT>l`dOk5$9{{<YvM<DQo7ZGN_cU#(WJaL6=Vwmg$?AI(Yf'
    'aal$cAph}+<r=csUio!<OVJ;GpFMXc+u;xh^5={dUTexvRGxEej>8$ab1<M#jNw@DYuorr8Go*UaOQ0s6_(4pmNwD<AKwwBcLP@T'
    '`**z79EvW95bc-f=yO}K5II5`37mo^f@Q%|_HSV7XW9yn5WePnMA!qmwgv?2QkRs41e_Li-RVo|w#rA_l^67fYI0&41v#EsiLxk*'
    'zuqlofZFT8N>OJ4Ec;k{WVDyQRs0dCkPw>^Rz)L4Y@>JQz(WN+?&!gQ9XIq3XXJI9^h;^6=cockIAYQi<O+&zODko@ige0{ikJ_v'
    'y$;w$4~<}Y??;Hk3w&>(Xa9KoQtV$Hg5x~SdKB@yoL1VmUl|QJW}w*_D<P~^(iU4lxuxw!S_?kol@ZkETcOCDd3qh=5E-b~K779$'
    'gDvDb;dDa}6VSA>%MYTN)J`M3=KavjhMgMyB|4dbmjwjS2zzRnA2FQyjK8xjBNQn3#Pjy__bR<_{(wCpPRBt~3S$>13%WTUIxP~b'
    'Z(JW8@V(}4oLzCaem<Nu^6Z0LC<PiBs=%Z8l;p7%dt(7dV!w~S|K|T+p1`|eio^_T&xCx)Qg%Ga?{j7OJ53t6wX)H+!@B!wGlJdj'
    'u;w%Sl28>@GjrO8#7RsSWc4>%%v0+Sk?R&J-`W-$wtLIt!QgTbuL<@v7fkP#DbIV0A=HWDpOn;#HdR4lAUPYB8&{DDU;M+3^m4K}'
    'NS@6c6ToXAs&iN!@J{j?GUnZDXZPKZ40^KnrAI)7vXMEUM)->p6?*MvS->x23ORp;vDB}KP-l@dUOUC)577ZBb>%+Aix7=_?4qIW'
    'Od2y(&qQVfc7miSgn78j#RZ0FGK6Vh*(}FG%NYt@zhY3rSt!w>X^})E1RetSU9RA1U0bBpe(dX05fXZbsn&{Eb%mjdjH<|soW95V'
    'f^FTDs3eb1kVUG?{-(4BZ|2J4z*?+v4U%A=_W#9O3UE>n=SLNuz|KR8YD&K*@>zXxVdK`J?Og&P>Ndo$`dkk%JvBQkz@>_Ack7Bx'
    'ay2!zX8XM!BE)>Ho^+%Im~-18<n4$++qt6_b<$ej-K_+mS&(9Rjkj0imt_Km?o(;NPbTeUJOStL{8b&5K#p$(L$b2lz4u$}tEA@!'
    'fPtZOrguqt&?h-eFgLp5foD^m4`vNkdoa7L_l9y!_$67-Bs5rP2lw8%0r8B0r{W(+iChVIUQKq;4M|I?DLPYUAiha^IWTXs-;`Yh'
    'OG@J!hCb(E7d>$9J8pU#SAAc(hJVZ(Ux(NR<R@Z!Kw3n=k~<D!(cG^B<{<ALP1L(8?Tq>CZFoSF<NDAm@wBX{b>7_^q|QtF%xv@~'
    'A2I*9Wg_7rtaaV)iUP0cp-hmTd~{YSx;=P%Ezz{5M!LTuMt)Uey`p;Ogu6I?Z+_saqjge2JE0_dkA2;ksv6Vu|20b!EzRLrWHd~}'
    'W0m**v#2Jj_~z0K3=rho|8QMs`nu+73P?lnkHnP?*DHwN;`-)?k2_HW@<-=6KnfP7<z-L;qn0V?S42CXsDlN7T}g7%%qYpu1>j2R'
    'BT8b^aOB~uw_Z2RmE6E?`wnkz&D}dV#?7!hesu~-!xzpw{U4xB!g@%7;DZC#O87*2+UNj<6>6y>O$in6oHLn*r++5pd!H>FzrQ~w'
    't<YZtNd<I3z}mj}p;C469BU=O!;7v*II^PCnDBV`=q2EDHS`}7r%S&zd&4H~B-ee(7L?BpdNEUpI|!jt0Uzj?|DO3_pm^AO6OpBP'
    '86D_N?yC&EECIn7`@8_;X&k(cR_6ZoAAVgRA8QF~kF4fE+zFl~<B{QzTT~G4u3L{)U*4tDjox8oHsius9fg!8)wr5B`ZKq^>4%hS'
    'H@LD3dp*d%F4@~Y_&b)|F17b4kuW*FZ6aSh(rT9eY?@G8P02R*lwfE-)qb;`oHipDq6;H1YqZHvFQaUWJTY8B)=DULANI!2k~!*e'
    'G52?dlY&9r)is|43bFotq5E{BKakd~;$oSv+(JLd*vZX53Gf6<%c@GOo~dfu0uOF{h*l_#bpM7*<{pQA?R<EG2S>AEl7eN316Ue`'
    '%Mu1j8tc%y{OBfECrQb%Ot=i2<RHm=&ro7Ms$>Bmg%ssnn0x*mt=5-$Lktgqok$x8hN0`+#4lfITG3^m$euSS&y@_)sytTa%Myl2'
    '?gIC(1~C;SrI!;i0g;A`-=t2($5cOyt_YZZ8aw;&CHOcUzks=}dK`I}QmCZxpa@w5zK>OM)bN;HQyloS3Fx)17x^Uq^wUL&O%5yl'
    'Aa~mGUfcOe^@*`}DEHo|LCZJfJjhRFH=pSVi`><L^rj4Kcc0T@)U<*tV1Nb5@(7>5tDD^~9_ovb&3W2!S6(3jUo#B+bzWx?7|vw('
    'V$hi0=M0$&D_nRB|5p&kDl!K(JWeG$ew+R>7?CJ{i?p0dkxp(Xp9hjFk|@%1A%Rc;IkwC@jjj3$rS@XUBY#I*frj9~mv2GkX2Mh|'
    '>C8=H<_*xE31@MsEM;&{&qAhWHw5$3G3XCp;{K4!l3~M%Ik6&qiJxQuIQgK0qsMplw*%+Vhg_4l%0UE=>s|`Y{G05~LOyNDXUL1u'
    '!4krHYIDy9QvJI8TWpwPw#m(H7dRr3J^6p!1LKJaa-+dd0Z8vDI8^eQ32Xcp^sQU=x$C&0gWFOd-(4)~r)$md`BfD2ih6ZT>V5vW'
    'A6m(S5c(n26ca>=CX0+gSps19s2C4=vlQ8U!Cgga$dsH`Wc9dG1A=Tg+7a3Dd+F*ox0CLhf<_J`PUpy4ecvJSA-~6Qhi(Q6<-F<I'
    ';7iMuiJE&FcT9Yr6c}EGAIKM^fKapqcNE4wr&Jniv8GVRDWWjWn(gE{@y4y8>i<7vE4E$x3GU)@@<I4nFuj5Q79_J@PKvz^2>s}{'
    'Jn^Kg4ta^6amv3vzWQ^f-w-cEqf#fwaNa&Ekzj;8&`-F1%gCg*Fa#7XY2Q<?#Jk1y4o!0u&D`<i!72C_j;q#*cAMHIt}~K3PN1N?'
    's&wn7#F@drfPY;b4NdyP@!%CI1pFz+<F0lRrSyI3=vvVs<GlU-v@sj>&fsK@l<SE=sYTKQ>Ur;To02-FC4&}L^)y2NX;p3I8WT+Q'
    '5Zok|Y9&Ayc@Zojy3Te<u<l_b;Cz3RTYZ4ygA2<L)*kN^9Z5~zMu$#sX{jl1EhbS90WEI*uB7R2%eZ8MFCx|TUyw&OK7-t-;4V%8'
    'W0qUi<DJlk=8u&@E~oYH0|Q(hoYahH$g&AYq6vzdpBfiU;;#r%#;)r|^(9QzE#qcQz)ObLM$8Z(>T>TLIsl@+u_&`?h5D8?4uu3*'
    '1#0mlQ4b364+!_Zg$<P$I<@CI4F*XC1BZlb=21fxtsFaLOe>pz)OlE<OYmjj2!o#D5sOfdE+W5+l8^JgUrzP;^dHe7AHB+$H#(gd'
    'ZeakzSeNDiU)XEY?^BeO^t>3s0FMsz{Px6G?bY>nABQ;DEB6U9wo0|6ULjS2(dZCd7uAvWcQ=jJAv=9nOBm;J&ql8Qp6#slg_-of'
    'Ev{Q<7dI+4y}C{)H8g}V%JUi(*VC&_!0*WQn}wGUZ7wLK9c&}H@OI#elI)^pH67{2k=Ex{fQvfnCnXL|y_t~3)^@<cjbSGJ?PKz6'
    '+vw(-WAOgK1ynE+oMmj~-6S4$+H%WmSRD(fHNIJF$r4oPg9MBa$-MM#CRyniZSQoy^X7Kd1V}OiZT`3`9O%r?&+_Rmx8NpdeP8fI'
    'c|vJo6~UhVu`6cqKTgWXr=*_&oyGv{PwE;$m2a!Pnn}A3z*FloP6=x08(kXw3ejw{nXt$Ax0eI?25{)gm@^S*0yI=mF?ZoS28{E$'
    '58=853!Vansm10o*&K!6aD_<KdZ3F{7WL2%$x<8MvVuyk|9Xov2~+(z`L+z^#Fj_aA-2!%Oa|11HgMRQ=_;2hcV-?JOR<PhO~AAs'
    'aZN#eeMcwnb*PBNk_vAqeoa+kjyT`;z7>#o$5HBCA~B~P$jy(glFg|Oe>?c-bF}WuR#S*uwtdiqH!^Wy;0R7X5y|C;bx*nhaX(ab'
    '0FQwjFO}_;ZForcr4Y&ru=rZAd_|1S03YWtmk!v@UaR#<c5~7caxiJJ`zZ_b6os^uM-$g|MG$a?u*!EbVQErF(gEM2ie1dV_L%;Z'
    'xQElji(3Lbw0+7CDZ_VxfS%(8M<m)c!4u6K{rqV{kGw!4_c1An#tbjWoZ}=G&=e*MFUm3D<smu3gHl}wm<fw{;pYE0=$?pgdgGlE'
    '<gZb0BjaT$$tEsgI@xEzf9wwco*1ew2py-T85l9%tLGNDhkpX5Gvv_pb85u1m8`+J?MrT=0lf6o`n<7e(S_V_XRh(H@uQn2*R4|^'
    '09&wc<p}Gvf}>^*twCcak&uASyEe{ME!*G7<~qH^E$`3zU3n_FS^*I?Jzlqb<UkVte21&=AOBc5rZ>mBhcrgju}n<7q6g#NzWqQ}'
    '`FTH|bjZ&{{0pN9Jz;$q>v#HD-n8b;sny@VF#vohD7XzgMtLgKk?6PZ60;@LL^c2FmmKmHa^aH~&422~?jpcfq|7Rviz$$*+bW<|'
    ';D>=@4|!&3JoNCSNIxQ-J-K_xHybZ)0a#RldS7qP`k^+Vd*IZ+q>D$qS^3#~NhQ$sEkYD<w#h-10aq4FHnvls)IqJSSDb$A466=H'
    'kM-D==BWB3yOZuZZ%@JUmF6?c10nj*qT<GfJjY<*B&TbFL!l;ay0C5FxA#bcX~gMATL%~D$d1-wf(4Z>Nyi0v!O&kIy2Y^+uw%;w'
    '0yU^Af!0OD1nOf|snR?3K6gF`bkxge=$qe?h3t3QyhCLzjUyB&Nla=!3lt&FOjhz1$uJ$Xzr~8#@??BGeAADTwnyNf9BY-B156@m'
    'YC$waP9U>j;`4toomOto2CC^>hOzMuXNdKZU-+~dUKvkM8I#(Pm;jgaUfn$b-Au+nkhSxen4D=vV%S_Xfh$PhGlRH*UXMw$eR+1W'
    '=<DGMpz@lM0$h2FR4NiHnD5QcAUfAz2arF^mdim>jsP#NX7k)~Vl^eZ5J;mS_&S?K@)#i!pFX-(S3N8D9sRPcIEeX4K^kK7D_xb!'
    '4A05nY$eRGXxoF*_~@fQ4+d4_-1$C(Ve6PJL~apDO;SIJ1H>)`>sqX9blN4PHRs-t><>Kl9RS_{Bx)Ro9MP$X^&!Ilw^{XGw3J2t'
    '9y!1W@x)Yo@kj-!8yzoZ2`K4CDI!5>JZ*t{o#W>6&j~Ho&h{v&-(*5X9f|_B*_<pV;*A)*feo}|WOBi}%@4DSn)bA|CxP*K+S~Bb'
    's3@oF8ANH<-yjeYK?X>t%C~I2RDDHTMki}egR%=LU9fHMy4@4{B75r%ku{YD%S?A6+v$a-5E)i(Zn!f$)M|B$j~d>VLPPnB+&PzE'
    '@%)I}5Ma?DhFyikc*Ce=Dq|A?;&sAVog(bS%BTIjGmm(Pwe*$OH1&2~Za2Y5fZjm7j@r=h1f`tEFLc2Rf*H9<9P<n{Wgun6y+Txv'
    'Dd|Wc8$hnU+==B>wS5^fTtfBSjo%wUoJYWlC4}<gQRC#lXKc>!={E{K_Tty4A@PPGtCNbuF3m~14Wx{*%sAqdrLN8RG<F>4^pdCQ'
    'g2ckz$qF_u1^XM*4c6;8Qf4$K-AS0u0t06-HT3qD4ZX;*JH?8{g!}m_Y3nFR=a614!rfJ9!z$|0Y^?|KDrE2en7}sbkaMK*sB!2{'
    'f{{^8KC}QML(FitD2xTR&n$)$<UE?CReAkSreP2n8IOU~r7(zS_#~3xS={OZ!aj#)Kc^2LIBqOb=(%QZvhTvA8E=YuZg_~OwC#!?'
    '5byAnh9rrM5&x_0Ao3h@B`;o;`;<A{{Zl_eNE<7nOj5S&^KDwXf;bw8oZVK^if^T%qnx^FkBGK%$$#l`BX?QFDMEpwI?&ZRq+`uU'
    'W_T<B*B=sv=5R4&=5b3nl)VjQ^DbRRlhzXkhmG&A+l=DZh+cj{netj@@GSpu!b52eZX5$TiG-zzZq49F`eYAlxo_iLMX&rOCsq>U'
    '%gks;>n`Ljk;#Js>6=bol~=lLYHE-U2KU7xei<OWM5V)|xMTsw#Fr(BYf^%rP^f1Lw}s`4GazYR==k3S?sDM$FHBT-jJ*H$?iuJ5'
    '(}dqm5)yrAJSzbRutUN$_(Nk1hy4W%X!@Bn!^)*ZqTQKgA^I&+FyCjOE0@W>H{=OVTMnSoed2|6=6Ek<pZX8jLWuB?>eaoM`;w_m'
    'c-c?8$KiUhzc+;R`Ot$%EJDM79oRK<rFM>0TbcjtR6dnn;jr|Z7&b368pV;u#S}iov6d8P(Jm)b&{ctQkwwha!uKWsQ3#1#60!e{'
    'zhbFGoYN&BG7hb8i79;ktj9LKAa9T#C&!P<M09%lbN@<X@J*EI#9jC=0;yoeBlmi8<>VkTmqO)aw@PH&#cOOg3bs>YCXsh4o=+<>'
    '50O}E)eyW>?O{~=!Fptv!YW@Sw<9Y|`YSQFA6y$0`@k>6(2O-eEvrO<Y?vBOLLH_ba%T92$tYu7ShJHdE8=Ph=;Q+6t5Yd(eF%PN'
    ')&VPs;xSGDXaLY6ZQMXk*VXz!1h8DaDhA>X*cSqYR@ynh*~I`qmiI-Dy6XCta^*wELDCQQG?fI51w{yI$x>>Hh%3I9E<!#ySScrS'
    'riBcq*T^Uu<)5!^6Bxu6<O~CkrvVu9sEXvgd?Fl=_M=+is{=-eXVFt##pZ}v@h-x=+v;9_hV(~5aXjH2<ef*t)%(3JZ6dC|gV*=k'
    ')bndX3^trk9}nt1xk|YG4Xv3|SU*19e7qD8!YbeHsv-(D#iv5BUrAKzeD~S=c3z(%cQd_kDmg26#BxmY=81Yk9$p?HTp|vQ-`A`O'
    ';=A#5ZE)8qWKGG+eHT0MvY!dXOG{Q=dO0|5YY#ld6$ZNvzItSTBCk2#SX;Z%Cpx8%)0)@Zed9)BXIOk0?_wpV-)0X`!k%E5epw+t'
    'FnRM(I3QXgO~}SuYkZGwhAqw)Q$M&VEv+W9UtTYRw_um<e&=*><1lU^!^6559B5>TP>*-&fKVlVBa8Vngm!%df(BJ!a#k=Jl6F2s'
    '#1L$+#lx#|3(L>hAW90-w3_xg4;gv};tWp#a9uZ7ml3juFe$J|<}cH$8sE+YNkXY{X^z4uxa1K*I%Wy4WbSw^0yFi5L5F;yR2S4n'
    'mtw*k@1`=k#|(*J#-t#zCCLuA*sRh~OyDb|ZuVdp(gl<Gde|9H()GszTZEl=?Ehi-`mXkuzF7~g<ckEdNd)Oy<2~^rE6uhjX4*tS'
    '&uRsy_x<d1XZmpWhv6WQC4V$Ueh}?g%#2#Gm@R66M2=EMx)ZFA*(RLMSJ%-&4cD>H^py|oz9}mjALw9B)Xonhr#Wo=cH%cWf%um7'
    'U(;OgH%weCJ|GOs=q;5IM#uL&-)d>EY7hCQYx}W;!5eB`BPgkUfbFwyD{<q(EUJab!k9}tdnqiRbb*<G!xO(609@eIu7H<;JRI4;'
    '96`Zu!X$jRG3^%fP@y1de!n(Zj$iA+haAalK23I7P+&rFLS&Pi%I4xJ+IZB3x_+Y|2PKJwBDw9QX6(7C3iDD@S8t%4(nZ@2JvI5y'
    'vbt5?b722=(Sr2V;&-evN#iLfG}_+EpZ@Ead1rkbc{y+ItENqS;cN&;ki0FFV*Jy<t^UJ3Ub!)^!3aTs?d?AG`G!=ahI;OI=HPD0'
    'oT`^kU=uP~%ptcH*Hz-tM&cd2prN*=H<gn_QzI=O(BilAYmfQ7uBB#vl<XD-fR=_TMr{dJ8azfrOh(lOTrzd!n|g_4J5};3{TwdK'
    'qo~3P-P>Mg*{i_ZPOr;eh?}4=hM;2gQGCRgjB<ZZaF18$IOrc!!D@Q72#Ba^hGtJo3|ij#EM-_?r726b)B|8tkdxpRfS}XQ;8!Ha'
    'vsX6{<_BAraGgg2&!_#aor3_vntvn8qzv2N@%G=~S0L;i6nMH;!VtS&!XFgu00$;wk8cd6FMgM=borxe@9{87_wU7p=1XFOcX~dC'
    'yQdz#rfLI(Tef@bW|be0=Kw4dArw#Vx{G#K#$tf)JO>wLHzaxLj0HrYi-(?haxhzgE;6<Sn5O^<xtKaAKPnnCRzLnNiFnoOs8<Hq'
    '^#}()632&z?{z5VIpl_}<lURyY^eGS<q8@P4>_stPfB&Rd!Fo3<&vjZ%^@=>Eum#;M}}UOtFKMM9?I1k1%q{dKG2k<Qv~{`jBXPp'
    '&f>Rr=E(-qF~K7fTqxGaA-NHtn`WNx#csF6+Fw_NSF2>DJ?-0b*vAK^>o+1)$}IKz_1M_Gugx5FUMVu*6PlYkDSK+g=bzc`wc8=4'
    'y;JpG$m^a6`k8KzSYp312&?N|)ri_AoIj5W$81`%KxW%R{O{k^pzJW1392}mbvo1jnXWw>mozxaZU_qc@DOmsGcPqHFxRRh5e-2A'
    '?WeVo;zgD!uW3gtX;y7(%8nufP#?xDZz03LAo55nOlL#&@g>N-JIVbhld#EY5)7iMm-qecaU|`Fi&KiZNi=9>!U2Fnw?144`DZWU'
    'yR;(;`-iK9*1RQFit>2+d-J^hhGr@3-9*K&OH2l58$@NI8jq|z*XNVV4ancl>Pfr!rtZzpa6qDDjZJddg*M2l%ObTFdH{4r41RU<'
    'z|D~D&l!n;$)P^({1sc#k6z;0u+oyl+t=aKg^Hw{+fDic>B{871h?NlDO`3_U77zsxdZH)^8dZd{<iVe4a-mM;Qkukwqt^q+1YNd'
    '>s;;C4_jRW#EH}Rij>s|d!zc_<?lrrl4bALck(7&`EL`pv92ToK!EOe7C7Gv1zlTPB1X*xqE4lTvTVSs4O0uT!xl6p&S`GJa2AhA'
    'or&{|4Su0hG)KQme`QoS(|qM>W!?Z-mU(s=AsWqU;&`rbP}W6R!&LI69AiruTq~NI`Ss%grLX3Z&By2zBWIiO3oRaDC#$>O1G-@1'
    '^egzJuE(7VzCi}{&!c0y5NWR-aZQIN+q49KWjo$M<IJC{;aeelIedHgmwj*Uy4jXLRo+UklhIH^fl8^}3&J)`-=4l8bAt|``&yM_'
    'uc?LRE^AQsY$Icz(W12nmuy!=A|=$v_F;FQ2Eq^jK)cpg$;*ok9gKE9iv)Fm{QkXC)c~nq2>txAOxAqd2MfMOc9tThY0Rbv)yR?I'
    'ia+{XgjCR1HFWALzMl?K?z9TmYkxRSv3hYzWO(nPLv`n)|8lwkAD_LfI){^0WM1ocUvuQK;d=Td=l#v=;$upz@dOw+Ki#+#ONml-'
    'H<DaiuKE?Mhop;3E9K6+=Q()8cfIi71^hZib(GALsoA7A%#~P8DmaQ%ZvYAge_FC97PG=iRSYm!4llzu(aep|o*p}9-*h(ccX(=h'
    '=q4UU28D+K0ZLaUM>$}R5AthCW^XE?fQXsDvL!9TN**0*`-4LJkW&~8Jt#wI(t?C}mQKeaRr71g^a61!d~nlrO~27CPAt~g7voqw'
    '*7kh2D};q};>3M5wo}TKJ(-K;<2G!->c+?D5m1xhxL<)O3w#)Xo~6z8n1w@RoLZS$I-BO!<`$77#*4>0&&1=CYbc`0MwDOy*(81%'
    'T3~2eba|Ac$jq0>a>Jn?n;6Q;e3HW=v!B1{fasIu!NA`PI@<O)Ca*kGiSDpz;ds!Ep8njXB=LHG)^r&HHpOD&1f5A~ZjeYS-Bvj@'
    '4H2P^HI<};5vt^{v5cY=&E;)iKB)xOLANg2%#*XRi(V>f-xCZJQ3pxVd6ofTuBl^dNA>=37rRM$rOZG5$-Zwy{&;BC^$-wblM%z)'
    'AJ()K=oqjw+u(v<MZ;oMzp;tp`0KcdD8JTUjs{m}A{%9w;=10gs`fheN;&pkrJxoH|Lu|2#dxL$2S&~_Fa(C$#@HJ!cazV+HebXF'
    'C^1SpMVgg}<h81YS{ftR{r4=!gf7B<U580C>Bxk{Ii4XdXTb&#uxnk71b>%3w$+wGMGKye+Ptho2s!jN4eB7F6jx91V~7|5u#tXp'
    ')HCka5A!cOlgHDg+uPm0fv-)=lTxb-e?kM9C`V4-nFBf48$>^ob^+VcR;>s2=rZsG;u2_j@PAH;ba@7Wua{J-umlI99T~ZgPpX`$'
    '{n?1Mdx%o|QdMxGYW*hn=~_)^6P9D#Al;})jBgPlg#rr_K;OSE*s{h@ju7aGW{sgjI0`Sc`D%*fn`|J!MJxeg0S#H358yJ#k%%aR'
    '&KqCZ?ESgK<D$H6!!;XM4tHy3G^G~UB|OgwjINiL8f=s?x)3TQa1l<t&+E}7$sLceu}`oK1R)J~>5%l?|7~XlivxHHn7}u7dbcjs'
    'yH+Hfzq<E)gU5_(xE-ulPp*_{n<GkLZ1+UdH`tx5M$Vrd)3GCaB2SavCxPG0Yds+HlR;G38L5yyg*D+#`~uN8BieF{c-qdx+pCS7'
    'xkU^I4v#6HqAzV#bDGXO1R<;h>^Um;3$OWVLxt^3X~d<Vn7oSs`!Wz8XPubVo#41q6otGDMO+{hS7aN<Sp`<HNZf;Es<!pa>sjZs'
    'PbKy1YIvAtl7t(VGMoK3;7{#v1e&hP_x11-LUIjC;o1ouc35=na2V~dYC~u2{0U+lSODFg&%qF;a*4v~c7;V<#FX~1))&u4n$y2_'
    'RrjicB{zioSw*HWw!`%dGHzT1=Q%^VP$Hbr!KuJ!B5FqO^ypS@f)cngow)FAv1<_Ky$V}$5;d|t5}T|JzC`(Kammm!ScDa01w_TT'
    '7vlIF_XxJ@4CzwO{vnrW^CD)WXBU_Qh-qTBVOOu5Bi3l<)KyOjR}5u&`(2XbB^4_@FXf+{Xt3`xmhxcmrWqva5=OBuh-`UX2Dsjb'
    'm5cCe=`nT_jOkd^cK)9DsNwD&Y(WCo_G)3qL?u&--Bt+2z(N1)xZFP!d@`y<m<6U=_}r{SEM>rJN>-83ed8`$-c_@!I1J#t4+59r'
    'u9^0E<V7Bj?0!#@dpxl$uD_ZIth!jrNW~Rz+xug-J}u)i+GBOl{ZR0Jd9Dp8ohlZX2B}jtWsID`-xcGgR0iTZ2~#BSIpyrTasXDr'
    'HnT#j$ln>&21d|mO#%{d^s(@w)^*d`KxFqOum{bU@}ih;3slP0@FFg(9*tTkRp1DZT216u@tdnsw`Z7Ih_B_M0Lki}mFg;`=dy1n'
    'Dn><QtWnFVs=%g|*q_-eQ7|N7+xD(H@5)}tlWmV}M?f@^;_3P}l2MN)or|CahRGkF)-i#YaFv>nnBRhJ=q2Wb#<~AR8fAg)9;VuJ'
    'l}ue1wm8RblLaUy*kR^UM`raEaipx$TUgea#;`*l<co$_1<HSr|M{r*S20i3KbMO*Ew5m3DrB_kd0UMN(%)HeT~SS@v*x*9ax_o4'
    'KdkQvqOVZOG)lY9&qb=pU|r$ApwJWLwD+*{o8qj(Y_`1YfQ&re_5TLCYfky!X`?w@7G;9A@o*#2L~_?9k~*@;GG<WI^l8(Y^sCH='
    '<^~>3j}VPLB}>S-PSI>e<~rh1PFz_5sekN^5PnAWG?CsRJeDVZ4e{T{zuug)51a0IC&Or-|DJ+=Q|JI~?iJkcF}KQE+9JvKF@{EX'
    '7InD4uCXG#e=AR4yucBs_>P;#it}@+eh(79;eEyE6Rz(~#>r^P1O|D@a#O0$a9KyUiQ6jUH7&L`gq|z=-4iO^KKg16EL{3}Q*g3@'
    'vKYmhv|g)ss?7>#uI_Nb%<q6gXLSQLOv)lW{!DytjS^(ccQHiH0Xo&GwNT#S_fW<y{|Q>5G3Qp{{AzrE{(GzUS}nH4G*uFc>3^{f'
    '3o`N#$5!uWH_w7R-Lbh9J<3G4mZWH%CeJ2cq{n;I#{_Ef1=dE7m(IP4f_zN%+{U1046k(0rY^gSf|xY5H*N`w09kOKQYnf~3xKiX'
    'h0KX_CE2GCJD}4tW-IeEZr;B0Vo6kq(w>mqYBVO1yjvpSJN!o~HzP%?8!ATO-a;TpsW!dOZ3A|)i6nnHUj$NnXA=(XbmCxP@@E=d'
    'Ib7$2jep!yz-LA4Terx2)ctVJA|4!iKh70=%z%+O{r4`lH@&es$RvjD6p;9Ce)6n?Hu(?pj2c#IQkcdZ^9H#b$5DU1Hvj4&besF6'
    'Ob3@Fe{J~`{4PGla{jO`C)_J01DoTG)gXg2%ScWEso}53gr;2bSaHrT>r`QF;!Ls1@OQ4N_?q~;Ni5wO>v#uHFV#B|QGlTO+nm|D'
    'nu8}&Bex{twqf8f8}MniJ*`regyK7rb4(>_HM1+0-MRfCli%F9Zqz{NR+g*LgrHcGG4D^iur6VzeCp7rnHz>z!ORU0Wq}B(wi(vd'
    'Yau}D!a<gtGUuUxjmi=U_*xMihpzJl(~VQYv$P~X@U^IDL{{~qv`Q_Y8WE6Wi}^K95~M`KUlQ3aSAKj3f>$*qxH#Oi=a+=MZrjRl'
    'l;Dv_03^Hatz{j-EqiuRa+kT^jR()X4MI!E6h_Rh#*Sbo`F4>Llnl@*U)w7G4XF~^3-nXrZ45kir9cIX$==KKX{suhcK_6&Tn1TV'
    'sHaWnHbS~>0A6RTf_s+n75s};K2tw(fO%;~(*uFr7NS~i{A?Ts(8xzg`R1l%1{BRIE)rh2@_mjRLJskmu7cwBj9GC+#3`h_Y@$lc'
    'g3Kd*35HmAg<(sga(&T%L-vEh=gg-iqZ%c+31?<VHBR$5Ih=TOo`cFyLjZ6;-q!6b5?dd_U|1$`Wm9>=jMmr{V<uuto?u79otCrS'
    'Tt)_;Qi$~~lG#5+4a*S}UA(CZ99x;BYk>}lN)}FBwZZ8*X}t<E<DSRRHkjND8Xuoi%WI$<x*?Q6ZyVxG&qI8Y2^TUoFdnWf7-fIS'
    'o~GDR`o+ljicOLMFfycleScfqwvAu893ife)TsurTc(fQdaN$L(y5LgpON9Ijw|LxBvdtnscc-lxkz>N9??&76e$1Xef_`(c3}mk'
    'J7M9c0&^B{@ar~yDwmCoUh<|Mr4m}<7UrT`7_FphZ<~LR=d1g}!6U)Gki~E~Sjnsxee#F{37bv5dHaoGJc_5ogez9XO2Q=hJq;}B'
    'r&#$TWv8+@ovfr&Ms$>d0N>R1pbh{=jRa;Deax{*F%GJzk$SS<tb1u5urlcat;eH@lY>E9abPzrn?xq#BBbT{@zn%!{~|k+CE|6}'
    'Y)HLHHuoC~M%S;mj1xt0QEt=}IUDc@yj47N9fEBCqU3T(jREHd>dn?K96$WE!qb|n*ToaaQ^jIXU+ion@YZpUAu*j*%87k5!RV~m'
    'zg8n$M{FPrAEyko|MpjG@RJ*UYcbECy@KUaz>$ci-$CRvS_2Hg7M+3wk|XC#Cok_M_*Q9I1i?%!PQ?}Nzj{68n(@z!AGI}gD@usV'
    '2&#K7QPTbLjKO0-gkMF^&ugApHj&2^dAhETSqEcw$Z+8#oI;^S7?W=LH3wN1t#gaX%#sBB9iSDDw&<->lferN$k`h>pfoGkZp?~b'
    '<8znD1C`2m!lPT-)F7u;?AT}lHNiWL7e4tiTDb{OL3mL~K;T@Cthr8knLrTz7j&qiG~<R~FcHT<9<VvEmemf#VzA8sy>y3LNBGUY'
    't6<G@%HGh+LqH9GB|2enOdI4}rkOm0dL%^C35}O)q|T;IRxC@v&*1!oB{%1AX;jJ~&)(q?G|ftS32!=@e^GzM(iJ;U#na%it0zWW'
    'Fu%hGi*ahAV_NR&0c-FRjjR^WxdqcazwAvTHpKA}l-J(+ow}%@9K`}4ofL+WzF+WjznMb>F}^rROFZ=E`wvHPC%PLs(-LWM;}7G&'
    '7lTbR1^l~^G@${$RuJZ<P*#uzi@`*sVfCSGcQ+bBtsgO{+gj^0>`F2~DboGW@0<Kg3$_$wAR_3}8$Gs?NlI`|)P^d??}9fKpu`2>'
    'I%dwmbKc#HUHQ*OZfqaxZ7O|GYpDwwrybZoH!%x7DN*)ycF(%U@t=7Qm?>O$x`Vc|6aOzpt*f?~aLLKs3I;>A97}{cqYi$YQsR$6'
    'zi!nUT0mRt(^L-R4E}n@i`M#n0Wg(0?kY$nnpdxy89XT)tl-1h<;1A06w@PaZeFn*Y)`rlr^?MF*9kk1L{2BS(T?HmiKY;^S8h6D'
    'cZkb-)O*o!h${H!_c{(726-;PHEz(XB{8J=sos*_s$yR@YYBt_hPL(fIf2y0_XG;|z^hPl`4DuyE&k4<pvnb|f6Jm>fXLrNKtq#I'
    'vrM-=#W<8lcGzO03kwR-Kb4fdgi^sgrzt}I=xI1`ko#kcy7quafU@`%Lnyq)WL{Prkf>Cj7TSD^1LZVwLO^Qpq9^-rolzcVbuV<L'
    'JQ`=xN~Flc>g!ikK?xz>xkACSF!&XWr}l%O+4!kwcm7&8JA$J=xO@HlzlxOHx5YDHPZ{cr))`(-1G59UNV;kOl&?ojs^9Utm|8Td'
    'VgT{uu2^6nK+}<K9uW_8i&Pg|LOA<@SZj#&tCyNOE}vl&6`)Z+@WS`gC;*m39>5%Ps9+<9T59roVI(1_R+3`KOm$R3h@sKpwYs*;'
    'MF1hVH=;hy*ez1>I<y0>z$7-I4xpE$ByQ^?`os8QfokiIsquk0hO0?!Y{k;8B+w1+LF(f!!7E3&8e;VE2Tgmn+^}M|2Wrgg)8dpZ'
    'CyZqjTFQt|2;*6qy+edv{)JN-3eZjo+LpI{=liR$(Gpg}7@+j^$rq=?ZuX@FtE;mLfi!`zKcp9t(kp4qGud^&5`6koi?dE{&Ye7%'
    'g(FPe>I!EEb)ZeQrs-V&a<ACI_7qSwLMT5T^jkIy2BL6kXL&mnVmf3yJ4jF_a<VQHg<VO{5F^dlN?mlZ;K*pi-W_b+mF@$7fitfU'
    'u%|W%j0Y?Hn$)v?q)eO`c;{Il7`wu|sRCDUMp;j4J}8(|CjJaR*|61S2>dH{lMUL?@B-vlyO)H}L(B-KXBnMN1K(tBC?2l(BJCN-'
    '0(T1|y#Q8SYP+W|btbJtqGKzmH)reMY2^k{zhjOQ4zL58rzjeQ`kH_b!j)9tuj7=&ZaA_GRMq?v%l+O@=NeL0%2cL}>YWYjKI<Kz'
    'bZ8*sMr+Na?CR!=&N2(62mFm3Tdgx%WoIs4qp~zegaxhBA)Qk}-<~#ze?hUQ{bg@(?l=Dt{$RcywC)GWM?4)x_PTxG5->24Deb>h'
    'P&Fg0PSBn=mp+@6vpr$XQjhqT4KS|HYnBC%x=NAK>@2*j4z%Imv?STAgbYLiGe6Nl&@*c!D%!pKo^v4r4=hW!8(j?d<o$Z&%#hb8'
    'l0U`9zr|ys1Y3H==^+Ky+=+x{6FGrT=VJECzGtXEQUG2={}dM4qd<^?fsE`Pj01vB6Op{3vh4uVM@25RG3{8wxdM$Rjl?F6B+c=o'
    'Y?EcYLYTsTTIX^b1}0Bm$Q@1ylg`>cb4)}sWlTi5dgFDa)M+1d1Yt3kGlF~KP03giS#dEBu=3o4wt1{X4lF&FR}$i&l9p>#?8#?K'
    'B|~hS+T`3K4BsARw<Al0U<0+Uy7n<&zAiBj)+$t3V9#sZgWNy*bHq!=5@q|p<~rpNGoyFcF)z2mBTDm=w2<5RPioo3ezFizcc%E='
    'l@YPFo!6`Gai)wFbs2M1*lH=10#jLHTEp7PkEMST$CMk-usXj9vT{=cm|zl!t~-7UrSB^g0@^YJ_r^ZTMI)IPK}JYQ2=kaS1+ssk'
    'Tc{b!M~YWVad!^8PTxQ23WpWq0F|VxJivHkjxX9BC%&bBpA!@_GHPlbFN<Y5#l^lV*2mJSGje`nbCen-NG9VxDo-KcntcoD{+2^w'
    'XueRUjm%VIc3Vku@4}1~;JR&YR@;rgFCZz=fJaJK6?n(st&OceijEQY8XeDQ-VQB!EDnaP>LaD4vMhTazZG56a0ps?dkv@i$6TkT'
    'DTr`Hr_m^$$sTSOSavIC;w@KXr^lf2ohPAxEkX6T8!y>r_-29YDHLGJ>FVOxpTyZO$y{}V_yBrR7wypU%&*&MbnMen^#{<R$=4O9'
    '4xm^;z^JWU&8DcQRbdiEIUz7Z1s@D5<<T`7(Zs;o3L*zoC-`y;r;OW618qX<ZH3^D5mB<3t#V{qE<C9hk1JsZA3TW}y(c+nnHJf!'
    '_nXTcB3oD&-pyHJup{uEwGoONC;{WT-)g=4eP?Ff!-o1H#=_@h=Ik=xO(~baq?0{t59()){%J?|fF`+$d6nLuAD;N!IN!ZUKl`t1'
    '*w2LPrJsoW3fJWeIZ)fFfW8m=agn*ybjlkm&r%3_SOUg#-gQzyAYfYHcYjC)*->kzTl!3msg-F`P2{hZrl;k~KoAL0#ZdN8wtyEY'
    'TtRSO6VHS0GDc^)fH1hzBGcF#P9P<wdd__j83I{WDr!7R5og<xdeMyJ{;Lh>Ju9n~LHQ;kg<U#FLef`=;4(mzDPJ;@8$y5e*n`D7'
    'Q;cf8IHZw?k1{U7T4FKXP0;|T=6ZekAKFPZGZLGzz3|4#NGHYN-P>8V#3xW_F?Gt}?06Cve+D#pHG|Ah5j4+@_J%7ZuSo2}nf*?A'
    'UI>@0E<kKHa~-W0!Eo&n7q0bKO&w+zInkOdV&wE@_(0@oVVq+8PUSqa-2xn5tPQNNGFB7JyWLG+ovTscJ1U^DoAa5X{qLZz`L_9k'
    'ROYs~82|o^e)6G-dbA_D7N^_&tytN(Lfjz+Wfh~JLlVS#@Smm7Gp+U1Eyl%N8%Vz|?VfhIG+-|#<h1DRj{KRGi#wBu7k4l}m!>j#'
    'SPMOMMq>YLU52>!%Ve)7uc>DO<g?0#Hz7g6q7#V=&#IHfhT?jMGP!Gud7A!3+CmHUxgOE@biMA&uw*|KRqt|}ld<16WXCVlx13%='
    'E)we6PUzRR52m&Dcja67XvDsYc5|8SI}sPuJezhK5N}tPrA*rlW5+x#a}d&$yi%{Us(EIZ#EaA%9M@8f!vv7%x?71!_|AJH_;3R?'
    'M~Ss<91KC=g6Ukk#fIrU7pl%G?f?J)XII4hq?1qE00E=J0*0X;<T}dmvBYQl0ssI200dcD'
)
PROVER_NAME = "false-solver-d17"
PROVER_SCHEMA = "stage2-false-countermodel-prover-result-v1"
MAX_FALSE_CERTIFICATE_BYTES = 20_000

_TABLE_BYTES = None
_INFINITE_RULE_ROWS = None


class _SafetyWallExpired(Exception):
    pass


def _safety_wall_handler(_signum, _frame):
    raise _SafetyWallExpired("False prover safety wall expired")


def _arm_safety_wall(seconds):
    if not (
        hasattr(signal, "setitimer")
        and hasattr(signal, "SIGALRM")
        and hasattr(signal, "ITIMER_REAL")
    ):
        return None
    previous = signal.signal(signal.SIGALRM, _safety_wall_handler)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    return previous


def _disarm_safety_wall(previous):
    if previous is None:
        return
    signal.setitimer(signal.ITIMER_REAL, 0.0)
    signal.signal(signal.SIGALRM, previous)


def _runtime_config(config):
    if not isinstance(config, dict):
        raise TypeError("config must be an object")
    copied = dict(config)
    save_mode = copied.pop("result_save_mode", "minimal")
    if save_mode not in ("minimal", "full"):
        raise ValueError("result_save_mode must be minimal or full")
    nested = copied.pop("search_config", None)
    if nested is not None:
        if copied:
            raise ValueError("nested search_config cannot be mixed with top-level fields")
        if not isinstance(nested, dict):
            raise TypeError("search_config must be an object")
        copied = dict(nested)
    unknown = sorted(
        set(copied)
        - {"safety_wall_seconds", "use_finite_model_bank", "use_infinite_family_bank", "use_formula_cdcl_search", "formula_cdcl_search_seconds", "formula_cdcl_min_size", "formula_cdcl_max_size", "use_scalar_affine_search"}
    )
    if unknown:
        raise ValueError(f"unknown config fields: {unknown}")
    seconds = float(copied.get("safety_wall_seconds", 295.0))
    enabled = copied.get("use_finite_model_bank", True)
    infinite_enabled = copied.get("use_infinite_family_bank", True)
    scalar_affine_enabled = copied.get("use_scalar_affine_search", True)
    formula_cdcl_enabled = copied.get("use_formula_cdcl_search", True)
    formula_cdcl_seconds = float(copied.get("formula_cdcl_search_seconds", 300.0))
    formula_cdcl_min_size = copied.get("formula_cdcl_min_size", 2)
    formula_cdcl_max_size = copied.get("formula_cdcl_max_size", 9)
    if not 0.01 <= seconds <= 3600.0:
        raise ValueError("safety_wall_seconds must be in [0.01, 3600]")
    if type(enabled) is not bool:
        raise TypeError("use_finite_model_bank must be a boolean")
    if type(infinite_enabled) is not bool:
        raise TypeError("use_infinite_family_bank must be a boolean")
    if type(scalar_affine_enabled) is not bool:
        raise TypeError("use_scalar_affine_search must be a boolean")
    if type(formula_cdcl_enabled) is not bool:
        raise TypeError("use_formula_cdcl_search must be a boolean")
    if not 0.0 <= formula_cdcl_seconds <= 300.0:
        raise ValueError("formula_cdcl_search_seconds must be in [0, 300]")
    if type(formula_cdcl_min_size) is not int or type(formula_cdcl_max_size) is not int:
        raise TypeError("formula CDCL domain bounds must be integers")
    if not 2 <= formula_cdcl_min_size <= formula_cdcl_max_size <= 9:
        raise ValueError("formula CDCL domain bounds must satisfy 2 <= min <= max <= 9")
    return (save_mode, seconds, enabled, infinite_enabled, scalar_affine_enabled,
            formula_cdcl_enabled, formula_cdcl_seconds,
            formula_cdcl_min_size, formula_cdcl_max_size)


def _case_formulas(case):
    if not isinstance(case, dict):
        raise TypeError("case must be an object")
    source = case.get("source_formula")
    target = case.get("target_formula")
    if not isinstance(source, str) or not source.strip():
        raise ValueError("case.source_formula must be a non-empty string")
    if not isinstance(target, str) or not target.strip():
        raise ValueError("case.target_formula must be a non-empty string")
    return case.get("ordinal"), case.get("id"), source, target


def _strip_outer_parentheses(text):
    text = text.strip()
    while len(text) >= 2 and text[0] == "(" and text[-1] == ")":
        depth = 0
        covers_all = True
        for index, character in enumerate(text):
            if character == "(":
                depth += 1
            elif character == ")":
                depth -= 1
                if depth < 0:
                    raise ValueError("unbalanced equation parentheses")
            if depth == 0 and index < len(text) - 1:
                covers_all = False
                break
        if not covers_all:
            break
        if depth != 0:
            raise ValueError("unbalanced equation parentheses")
        text = text[1:-1].strip()
    return text


def _parse_term(text, variable_indices):
    text = _strip_outer_parentheses(text)
    depth = 0
    last_operation = -1
    for index, character in enumerate(text):
        if character == "(":
            depth += 1
        elif character == ")":
            depth -= 1
            if depth < 0:
                raise ValueError("unbalanced equation parentheses")
        elif character == "◇" and depth == 0:
            last_operation = index
    if depth != 0:
        raise ValueError("unbalanced equation parentheses")
    if last_operation >= 0:
        return (
            _parse_term(text[:last_operation], variable_indices),
            _parse_term(text[last_operation + 1 :], variable_indices),
        )
    if len(text) == 1 and text in variable_indices:
        return variable_indices[text]
    raise ValueError(f"cannot parse term: {text!r}")


def _parse_equation(text):
    normalized = text.replace("*", "◇")
    if normalized.count("=") != 1 or "≠" in normalized:
        raise ValueError("formula must contain exactly one equality")
    variables = []
    seen = set()
    for variable in re.findall(r"\b([a-z])\b", normalized):
        if variable not in seen:
            seen.add(variable)
            variables.append(variable)
    if not variables:
        raise ValueError("formula has no variables")
    indices = {variable: index for index, variable in enumerate(variables)}
    lhs, rhs = normalized.split("=", 1)
    return variables, _parse_term(lhs, indices), _parse_term(rhs, indices)


def _source_pattern(parsed):
    _variables, lhs, rhs = parsed

    def encode(term):
        if type(term) is int:
            return term
        return ["op", encode(term[0]), encode(term[1])]

    return json.dumps([encode(lhs), encode(rhs)], separators=(",", ":"))


def _source_schema_match(source_pattern, parsed_source):
    """Match canonical source metavariables to arbitrary incoming terms."""

    pattern = json.loads(source_pattern)
    _variables, incoming_left, incoming_right = parsed_source
    environment = {}

    def match(pattern_term, incoming_term):
        if type(pattern_term) is int:
            if pattern_term in environment:
                return environment[pattern_term] == incoming_term
            environment[pattern_term] = incoming_term
            return True
        return (
            isinstance(pattern_term, list)
            and len(pattern_term) == 3
            and pattern_term[0] == "op"
            and type(incoming_term) is tuple
            and match(pattern_term[1], incoming_term[0])
            and match(pattern_term[2], incoming_term[1])
        )

    if not (
        match(pattern[0], incoming_left)
        and match(pattern[1], incoming_right)
    ):
        return None
    return environment


def _expanded_witness_vectors(witness_vectors, target_arity):
    ordered = []
    for vector in witness_vectors:
        vector = tuple(vector)
        if len(vector) == target_arity and vector not in ordered:
            ordered.append(vector)
    pool = []
    for vector in witness_vectors:
        for value in vector:
            if value not in pool:
                pool.append(value)
    products = sorted(
        product(pool, repeat=target_arity),
        key=lambda values: -len(set(values)),
    )
    for vector in products:
        if vector not in ordered:
            ordered.append(vector)
        if len(ordered) >= 8:
            break
    return tuple(ordered)


def _lean_open_term(term, variable_names):
    if type(term) is int:
        return variable_names[term]
    return (
        f"({_lean_open_term(term[0], variable_names)} ◇ "
        f"{_lean_open_term(term[1], variable_names)})"
    )


def _rewrite_source_branch(code, parsed_source, substitution, marker):
    marker_position = code.index(marker)
    branch_start = code.rfind("\n  · intro ", 0, marker_position)
    if branch_start < 0:
        return None
    branch_start += 1
    original = code[branch_start:marker_position].rstrip()
    lines = original.splitlines()
    introduction = re.fullmatch(r"  · intro (.+)", lines[0])
    if introduction is None:
        return None
    binders = introduction.group(1).split()
    if set(substitution) != set(range(len(binders))):
        return None
    incoming_variables = parsed_source[0]
    fresh_names = tuple(
        f"_d10v{index}" for index in range(len(incoming_variables))
    )
    replacements = {
        binder: _lean_open_term(substitution[index], fresh_names)
        for index, binder in enumerate(binders)
    }
    body = "\n".join(lines[1:])
    for variable in sorted(replacements, key=len, reverse=True):
        body = re.sub(
            rf"\b{re.escape(variable)}\b",
            f"({replacements[variable]})",
            body,
        )
    rewritten = "  · intro " + " ".join(fresh_names)
    if body:
        rewritten += "\n" + body
    return code[:branch_start] + rewritten + "\n" + code[marker_position:]


def _infinite_rules():
    global _INFINITE_RULE_ROWS
    if _INFINITE_RULE_ROWS is None:
        payload = lzma.decompress(base64.b85decode(_INFINITE_RULES_XZ_B85.encode("ascii")))
        rows = json.loads(payload.decode("utf-8"))
        if not isinstance(rows, list) or len(rows) != _INFINITE_RULE_COUNT:
            raise RuntimeError("infinite family payload count drift")
        _INFINITE_RULE_ROWS = rows
    return _INFINITE_RULE_ROWS


def _lean_closed_term(
    term,
    values,
    carrier_type,
    magma_instance,
    target_eval_function="",
    target_eval_opposite=False,
):
    if type(term) is int:
        return values[term]
    left = _lean_closed_term(
        term[0], values, carrier_type, magma_instance,
        target_eval_function, target_eval_opposite,
    )
    right = _lean_closed_term(
        term[1], values, carrier_type, magma_instance,
        target_eval_function, target_eval_opposite,
    )
    if target_eval_function:
        if target_eval_opposite:
            left, right = right, left
        return f"({target_eval_function} {left} {right})"
    return f"(@Magma.op {carrier_type} {magma_instance} {left} {right})"


def _symbolic_target_branch(
    parsed_target,
    witness_vectors,
    carrier_type,
    magma_instance,
    project_subtype_value,
    target_simp_lemmas,
    target_eval_function,
    target_eval_opposite,
    target_stepwise_raw,
):
    variables, left, right = parsed_target
    compatible = list(dict.fromkeys(
        tuple(values)
        for values in witness_vectors
        if len(values) == len(variables)
    ))
    if not compatible:
        return None
    if (
        type(target_stepwise_raw) is dict
        and target_stepwise_raw.get("mode") == "d14_named_value_rewrites"
    ):
        return _d14_named_value_target_branch(
            parsed_target,
            compatible,
            carrier_type,
            magma_instance,
            target_eval_function,
            target_eval_opposite,
            target_stepwise_raw,
        )
    lines = ["  · intro target", "    first"]
    for values in compatible:
        application = " ".join(values)
        typed_values = tuple(f"({value} : {carrier_type})" for value in values)
        symbolic_left = _lean_closed_term(
            left, typed_values, carrier_type, magma_instance,
            target_eval_function, target_eval_opposite,
        )
        symbolic_right = _lean_closed_term(
            right, typed_values, carrier_type, magma_instance,
            target_eval_function, target_eval_opposite,
        )
        original_left, original_right = symbolic_left, symbolic_right
        step_lines = []
        rewrites = []
        if target_stepwise_raw is True:
            constructor = f"{carrier_type.split('.')[0]}.p"
            cache = {}

            def evaluate(term):
                if type(term) is int:
                    return typed_values[term]
                left_value = evaluate(term[0])
                right_value = evaluate(term[1])
                call_left, call_right = left_value, right_value
                if target_eval_opposite:
                    call_left, call_right = call_right, call_left
                call = f"{target_eval_function} ({call_left}) ({call_right})"
                result = f"({constructor} ({call_left}) ({call_right}))"
                if call not in cache:
                    name = f"d10step{len(cache)}"
                    cache[call] = name
                    step_lines.extend(
                        (
                            f"      have {name} : {call} = {result} := by",
                            f"        simp [{', '.join(target_simp_lemmas)}]",
                        )
                    )
                    rewrites.append(name)
                return result

            symbolic_left = evaluate(left)
            symbolic_right = evaluate(right)
        lines.extend(
            (
                f"    | have bad := target {application}",
                *step_lines,
                f"      change {original_left} = {original_right} at bad",
                *((f"      rw [{', '.join(rewrites)}] at bad",) if rewrites else ()),
                *((f"      change {symbolic_left} = {symbolic_right} at bad",) if rewrites else ()),
                *(("      have badv := congrArg Subtype.val bad",) if project_subtype_value else ()),
                (
                    f"      simpa [{', '.join(target_simp_lemmas)}] using "
                    f"{'badv' if project_subtype_value else 'bad'}"
                    if target_simp_lemmas
                    else "      exact nomatch badv"
                    if project_subtype_value
                    else "      exact nomatch bad"
                ),
            )
        )
    if target_stepwise_raw == "d14_decide_closed_equality":
        lines = [
            (
                "      exact (show Not (_ = _) from by decide) bad"
                if line == "      exact nomatch bad"
                else line
            )
            for line in lines
        ]
    return "\n".join(lines)



def _d14_named_value_target_branch(
    parsed_target,
    compatible,
    carrier_type,
    magma_instance,
    target_eval_function,
    target_eval_opposite,
    normalization_spec,
):
    """Render exact value-lemma rewrites selected from the target AST."""

    if not target_eval_function:
        return None
    rules = {
        (left, right): (result, lemma)
        for left, right, result, lemma in normalization_spec["rules"]
    }
    aliases = normalization_spec.get("aliases", {})

    def normalize(term, values):
        if type(term) is int:
            value = values[term]
            return aliases.get(value, value), ()
        left = normalize(term[0], values)
        right = normalize(term[1], values)
        if left is None or right is None:
            return None
        left_value, left_lemmas = left
        right_value, right_lemmas = right
        if target_eval_opposite:
            left_value, right_value = right_value, left_value
        rule = rules.get((left_value, right_value))
        if rule is None:
            return None
        result, lemma = rule
        return result, (*left_lemmas, *right_lemmas, lemma)

    variables, left, right = parsed_target
    lines = ["  · intro target", "    first"]
    branch_count = 0
    for values in compatible:
        rendered_values = tuple(aliases.get(value, value) for value in values)
        normalized_left = normalize(left, rendered_values)
        normalized_right = normalize(right, rendered_values)
        if normalized_left is None or normalized_right is None:
            continue
        left_value, left_lemmas = normalized_left
        right_value, right_lemmas = normalized_right
        if left_value == right_value:
            continue
        lemmas = tuple(dict.fromkeys((*left_lemmas, *right_lemmas)))
        typed_values = tuple(
            f"({value} : {carrier_type})" for value in rendered_values
        )
        original_left = _lean_closed_term(
            left,
            typed_values,
            carrier_type,
            magma_instance,
            target_eval_function,
            target_eval_opposite,
        )
        original_right = _lean_closed_term(
            right,
            typed_values,
            carrier_type,
            magma_instance,
            target_eval_function,
            target_eval_opposite,
        )
        application = " ".join(rendered_values)
        lines.extend(
            (
                f"    | have bad := target {application}",
                f"      change {original_left} = {original_right} at bad",
                *((f"      rw [{', '.join(lemmas)}] at bad",) if lemmas else ()),
                "      exact nomatch bad",
            )
        )
        branch_count += 1
    return "\n".join(lines) if branch_count else None


_D16_AFFINE_MAX_N = 1000


def _d16_poly_add(left, right, scale=1):
    result = dict(left)
    for monomial, coefficient in right.items():
        result[monomial] = result.get(monomial, 0) + scale * coefficient
        if not result[monomial]:
            del result[monomial]
    return result


def _d16_poly_shift(poly, left_degree, right_degree):
    return {
        (i + left_degree, j + right_degree): coefficient
        for (i, j), coefficient in poly.items()
    }


def _d16_term_polynomials(term, variable_count):
    if type(term) is int:
        variables = [{} for _ in range(variable_count)]
        variables[term] = {(0, 0): 1}
        return variables, {}
    left_variables, left_constant = _d16_term_polynomials(
        term[0], variable_count
    )
    right_variables, right_constant = _d16_term_polynomials(
        term[1], variable_count
    )
    variables = [
        _d16_poly_add(
            _d16_poly_shift(left_variables[index], 1, 0),
            _d16_poly_shift(right_variables[index], 0, 1),
        )
        for index in range(variable_count)
    ]
    constant = _d16_poly_add(
        _d16_poly_shift(left_constant, 1, 0),
        _d16_poly_shift(right_constant, 0, 1),
    )
    constant[(0, 0)] = constant.get((0, 0), 0) + 1
    return variables, constant


def _d16_poly_items(poly):
    return tuple(
        (i, j, coefficient)
        for (i, j), coefficient in sorted(poly.items())
        if coefficient
    )


def _d16_compile_affine(parsed):
    variables, lhs, rhs = parsed
    left_variables, left_constant = _d16_term_polynomials(lhs, len(variables))
    right_variables, right_constant = _d16_term_polynomials(rhs, len(variables))
    variable_polynomials = tuple(
        _d16_poly_items(
            _d16_poly_add(left_variables[index], right_variables[index], -1)
        )
        for index in range(len(variables))
    )
    constant_polynomial = _d16_poly_items(
        _d16_poly_add(left_constant, right_constant, -1)
    )
    return variable_polynomials, constant_polynomial


def _d16_poly_value(poly, left_powers, right_powers):
    return sum(
        coefficient * left_powers[i] * right_powers[j]
        for i, j, coefficient in poly
    )


def _d16_prime_powers(max_n):
    sieve = bytearray(b"\1") * (max_n + 1)
    sieve[:2] = b"\0\0"
    for prime in range(2, math.isqrt(max_n) + 1):
        if sieve[prime]:
            sieve[prime * prime : max_n + 1 : prime] = b"\0" * (
                (max_n - prime * prime) // prime + 1
            )
    powers = {}
    for prime in range(2, max_n + 1):
        if not sieve[prime]:
            continue
        order, exponent = prime, 1
        while order <= max_n:
            powers[order] = (prime, exponent)
            if order > max_n // prime:
                break
            order *= prime
            exponent += 1
    return tuple((order, *powers[order]) for order in sorted(powers))


def _d16_affine_c_solution(order, source_c, target_variables, target_c):
    for index, value in enumerate(target_variables):
        if value % order:
            return 0, index
    step = order // math.gcd(order, source_c)
    if step < order and target_c * step % order:
        return step, None
    return None


def _d16_eval_affine_term(term, values, order, left, right, constant):
    if type(term) is int:
        return values[term]
    return (
        left
        * _d16_eval_affine_term(
            term[0], values, order, left, right, constant
        )
        + right
        * _d16_eval_affine_term(
            term[1], values, order, left, right, constant
        )
        + constant
    ) % order


def _d16_scalar_affine_countermodel(parsed_source, parsed_target, metrics):
    """Search every scalar-affine prime-power model through order 1000."""

    started = time.perf_counter()
    source_variables, source_c_poly = _d16_compile_affine(parsed_source)
    target_variables, target_c_poly = _d16_compile_affine(parsed_target)
    powers = _d16_prime_powers(_D16_AFFINE_MAX_N)
    orders = tuple(item[0] for item in powers)
    degree = max(
        (
            max(i, j)
            for poly in (
                *source_variables,
                source_c_poly,
                *target_variables,
                target_c_poly,
            )
            for i, j, _coefficient in poly
        ),
        default=0,
    )
    limit = orders[-1]
    power_table = []
    for value in range(limit):
        row = [1]
        for _ in range(degree):
            row.append(row[-1] * value)
        power_table.append(tuple(row))

    source_filters = tuple(poly for poly in source_variables if poly)
    best = None
    best_order = _D16_AFFINE_MAX_N + 1
    integer_pairs = 0
    for left in range(limit):
        if left >= best_order - 1:
            break
        left_powers = power_table[left]
        for right in range(limit):
            if right >= best_order - 1:
                break
            integer_pairs += 1
            right_powers = power_table[right]
            divisor = 0
            for poly in source_filters:
                divisor = math.gcd(
                    divisor,
                    _d16_poly_value(poly, left_powers, right_powers),
                )
                if divisor == 1:
                    break
            divisor = abs(divisor)
            if divisor == 1:
                continue
            low = bisect.bisect_right(orders, max(left, right))
            high = bisect.bisect_left(orders, best_order)
            if low >= high:
                continue
            delayed = None
            for order_index in range(low, high):
                order, prime, exponent = powers[order_index]
                if divisor and divisor % order:
                    continue
                if delayed is None:
                    source_c = _d16_poly_value(
                        source_c_poly, left_powers, right_powers
                    )
                    target_values = tuple(
                        _d16_poly_value(poly, left_powers, right_powers)
                        for poly in target_variables
                    )
                    target_c = _d16_poly_value(
                        target_c_poly, left_powers, right_powers
                    )
                    delayed = source_c, target_values, target_c
                source_c, target_values, target_c = delayed
                solution = _d16_affine_c_solution(
                    order, source_c, target_values, target_c
                )
                if solution is None:
                    continue
                constant, witness_index = solution
                witness = [0] * len(parsed_target[0])
                if witness_index is not None:
                    witness[witness_index] = 1
                target_lhs = _d16_eval_affine_term(
                    parsed_target[1], witness, order, left, right, constant
                )
                target_rhs = _d16_eval_affine_term(
                    parsed_target[2], witness, order, left, right, constant
                )
                source_values = tuple(
                    _d16_poly_value(poly, left_powers, right_powers) % order
                    for poly in source_variables
                )
                if (
                    any(source_values)
                    or source_c * constant % order
                    or target_lhs == target_rhs
                ):
                    raise AssertionError("invalid scalar-affine countermodel")
                best_order = order
                best = {
                    "order": order,
                    "prime": prime,
                    "exponent": exponent,
                    "left_coefficient": left,
                    "right_coefficient": right,
                    "constant": constant,
                    "source_variable_coefficients": dict(
                        zip(parsed_source[0], source_values, strict=True)
                    ),
                    "source_c_coefficient": source_c % order,
                    "target_variable_coefficients": dict(
                        zip(
                            parsed_target[0],
                            (value % order for value in target_values),
                            strict=True,
                        )
                    ),
                    "target_c_coefficient": target_c % order,
                    "target_counterexample": {
                        "assignment": dict(
                            zip(parsed_target[0], witness, strict=True)
                        ),
                        "lhs": target_lhs,
                        "rhs": target_rhs,
                    },
                }
                break

    if best is None:
        moduli_checked = len(orders)
        logical_pairs = sum(order * order for order in orders)
    else:
        found_index = orders.index(best["order"])
        moduli_checked = found_index + 1
        logical_pairs = sum(order * order for order in orders[:found_index])
        logical_pairs += (
            best["left_coefficient"] * best["order"]
            + best["right_coefficient"]
            + 1
        )
    metrics["scalar_affine_parameter_checks"] = integer_pairs
    metrics["scalar_affine_integer_pairs_evaluated"] = integer_pairs
    metrics["scalar_affine_logical_ab_pairs"] = logical_pairs
    metrics["scalar_affine_moduli_checked"] = moduli_checked
    metrics["scalar_affine_candidate_moduli"] = len(orders)
    metrics["scalar_affine_search_seconds"] = round(
        time.perf_counter() - started, 6
    )
    metrics["scalar_affine_found_order"] = (
        None if best is None else best["order"]
    )
    return best



_D15_EXP5_FAMILY = "opposite_exp5_group_core_zmod5_power4"
_D15_EXP5_MODEL_CORE = 'import JudgeProblem\nimport Mathlib.Tactic.NormNum\nimport Mathlib.Tactic.Ring.RingNF\n\nopen scoped Fin.CommRing\n\nset_option maxRecDepth 1000000\nset_option maxHeartbeats 0\n\nnamespace submission\n\n@[ext] structure G where\n  a : Fin 5\n  b : Fin 5\n  c : Fin 5\n  d : Fin 5\n\nnamespace G\n\ndef q (x : Fin 5) : Fin 5 := 3 * x * (x + 1)\n\ndef mul (x y : G) : G :=\n  ⟨x.a + y.a,\n   x.b + y.b + x.a * y.d,\n   x.c + y.c + x.a * q y.d + x.b * y.d,\n   x.d + y.d⟩\n\ndef inv (x : G) : G :=\n  ⟨-x.a,\n   -x.b + x.a * x.d,\n   -x.c + x.a * q x.d + x.b * x.d - x.a * x.d * x.d,\n   -x.d⟩\n\ndef coreOp (x y : G) : G := mul (mul x (inv y)) x\n\ndef op (x y : G) : G := coreOp y x\n\ninstance instMagma : Magma G where\n  op := op\n\n'
_D15_EXP5_SOURCE_PROOFS = {'[0,["op",1,["op",0,["op",1,["op",["op",0,2],2]]]]]': 'lemma source_holds : EquationLHS G := by\n  intro x y z\n  change x = op y (op x (op y (op (op x z) z)))\n  rcases x with ⟨xa, xb, xc, xd⟩\n  rcases y with ⟨ya, yb, yc, yd⟩\n  rcases z with ⟨za, zb, zc, zd⟩\n  have h6 : (6 : Fin 5) = 1 := by decide\n  have h5 : (5 : Fin 5) = 0 := by decide\n  have h15 : (15 : Fin 5) = 0 := by decide\n  have h20 : (20 : Fin 5) = 0 := by decide\n  have h25 : (25 : Fin 5) = 0 := by decide\n  have h40 : (40 : Fin 5) = 0 := by decide\n  have h45 : (45 : Fin 5) = 0 := by decide\n  have h55 : (55 : Fin 5) = 0 := by decide\n  have h70 : (70 : Fin 5) = 0 := by decide\n  have h80 : (80 : Fin 5) = 0 := by decide\n  have h100 : (100 : Fin 5) = 0 := by decide\n  have h105 : (105 : Fin 5) = 0 := by decide\n  have h120 : (120 : Fin 5) = 0 := by decide\n  have h130 : (130 : Fin 5) = 0 := by decide\n  have h145 : (145 : Fin 5) = 0 := by decide\n  have h165 : (165 : Fin 5) = 0 := by decide\n  have h200 : (200 : Fin 5) = 0 := by decide\n  have h240 : (240 : Fin 5) = 0 := by decide\n  apply G.ext <;> simp [op, coreOp, mul, inv, q] <;> ring_nf\n  all_goals simp only [h6, h5, h15, h20, h25, h40, h45, h55, h70, h80, h100, h105, h120, h130, h145, h165, h200, h240, mul_zero, zero_mul, mul_one, one_mul, add_zero, zero_add, sub_zero]\n\n', '[0,["op",1,["op",["op",0,1],["op",["op",0,2],2]]]]': 'lemma source_holds : EquationLHS G := by\n  intro x y z\n  change x = op y (op (op x y) (op (op x z) z))\n  rcases x with ⟨xa, xb, xc, xd⟩\n  rcases y with ⟨ya, yb, yc, yd⟩\n  rcases z with ⟨za, zb, zc, zd⟩\n  have h6 : (6 : Fin 5) = 1 := by decide\n  have h5 : (5 : Fin 5) = 0 := by decide\n  have h15 : (15 : Fin 5) = 0 := by decide\n  have h20 : (20 : Fin 5) = 0 := by decide\n  have h25 : (25 : Fin 5) = 0 := by decide\n  have h40 : (40 : Fin 5) = 0 := by decide\n  have h45 : (45 : Fin 5) = 0 := by decide\n  have h55 : (55 : Fin 5) = 0 := by decide\n  have h70 : (70 : Fin 5) = 0 := by decide\n  have h80 : (80 : Fin 5) = 0 := by decide\n  have h100 : (100 : Fin 5) = 0 := by decide\n  have h105 : (105 : Fin 5) = 0 := by decide\n  have h120 : (120 : Fin 5) = 0 := by decide\n  have h130 : (130 : Fin 5) = 0 := by decide\n  have h145 : (145 : Fin 5) = 0 := by decide\n  have h165 : (165 : Fin 5) = 0 := by decide\n  have h200 : (200 : Fin 5) = 0 := by decide\n  have h240 : (240 : Fin 5) = 0 := by decide\n  apply G.ext <;> simp [op, coreOp, mul, inv, q] <;> ring_nf\n  all_goals simp only [h6, h5, h15, h20, h25, h40, h45, h55, h70, h80, h100, h105, h120, h130, h145, h165, h200, h240, mul_zero, zero_mul, mul_one, one_mul, add_zero, zero_add, sub_zero]\n\n'}
_D15_EXP5_WITNESS_POOL = (
    (0, 0, 0, 0),
    (1, 0, 0, 0),
    (0, 0, 0, 1),
)


def _d15_exp5_q(value):
    return (3 * value * (value + 1)) % 5


def _d15_exp5_mul(left, right):
    xa, xb, xc, xd = left
    ya, yb, yc, yd = right
    return (
        (xa + ya) % 5,
        (xb + yb + xa * yd) % 5,
        (xc + yc + xa * _d15_exp5_q(yd) + xb * yd) % 5,
        (xd + yd) % 5,
    )


def _d15_exp5_inv(value):
    xa, xb, xc, xd = value
    return (
        (-xa) % 5,
        (-xb + xa * xd) % 5,
        (-xc + xa * _d15_exp5_q(xd) + xb * xd - xa * xd * xd) % 5,
        (-xd) % 5,
    )


def _d15_exp5_op(left, right):
    # Opposite of coreOp: coreOp right left.
    return _d15_exp5_mul(
        _d15_exp5_mul(right, _d15_exp5_inv(left)), right
    )


def _d15_exp5_eval(term, values):
    if type(term) is int:
        return values[term]
    return _d15_exp5_op(
        _d15_exp5_eval(term[0], values),
        _d15_exp5_eval(term[1], values),
    )


def _d15_exp5_literal(value):
    return "(⟨" + ", ".join(str(item) for item in value) + "⟩ : G)"


def _d15_exp5_lean_term(term, values):
    if type(term) is int:
        return _d15_exp5_literal(values[term])
    return (
        "(G.op "
        + _d15_exp5_lean_term(term[0], values)
        + " "
        + _d15_exp5_lean_term(term[1], values)
        + ")"
    )


def _d15_exp5_candidate(parsed_source, parsed_target):
    source_pattern = _source_pattern(parsed_source)
    source_proof = _D15_EXP5_SOURCE_PROOFS.get(source_pattern)
    if source_proof is None:
        return None
    variables, left, right = parsed_target
    if not 1 <= len(variables) <= 4:
        return None
    for values in product(_D15_EXP5_WITNESS_POOL, repeat=len(variables)):
        left_value = _d15_exp5_eval(left, values)
        right_value = _d15_exp5_eval(right, values)
        if left_value == right_value:
            continue
        applications = " ".join(_d15_exp5_literal(value) for value in values)
        closed_left = _d15_exp5_lean_term(left, values)
        closed_right = _d15_exp5_lean_term(right, values)
        target_proof = (
            "lemma target_fails : ¬ EquationRHS G := by\n"
            "  intro target\n"
            f"  have bad := target {applications}\n"
            "  have hc := congrArg G.c bad\n"
            f"  change ({closed_left}).c = ({closed_right}).c at hc\n"
            f"  exact (show Not (({closed_left}).c = ({closed_right}).c) "
            "from by decide) hc\n\n"
        )
        suffix = (
            "end G\n\n"
            "def certificate : Goal :=\n"
            "  ⟨G, G.instMagma, G.source_holds, G.target_fails⟩\n\n"
            "end submission\n\n"
            "def submission : Goal := submission.certificate\n"
        )
        return (
            _D15_EXP5_FAMILY,
            _D15_EXP5_MODEL_CORE + source_proof + target_proof + suffix,
            "alpha_exact_source_law_and_bounded_target_ast_witness",
        )
    return None



_D15_ACCEPTED_CM_FAMILY = "d15_inductive_accepted_cm_transfer"
_D15_ACCEPTED_CM_MODEL_CORE = 'import JudgeProblem\nimport Mathlib\n\nset_option maxRecDepth 10000\n\nnamespace submission\n\nabbrev NE {α : Type} (a b : α) : Prop := Not (a = b)\ninfix:50 " ≢ " => NE\n\ndef condEq {α β : Type} [DecidableEq α] (a b : α) (yes no : β) : β :=\n  match decEq a b with\n  | isTrue _ => yes\n  | isFalse _ => no\n\nlemma condEq_pos {α β : Type} [DecidableEq α]\n    {a b : α} {yes no : β} (h : a = b) : condEq a b yes no = yes := by\n  subst b\n  unfold condEq\n  cases decEq a a with\n  | isTrue _ => rfl\n  | isFalse h => exact (h rfl).elim\n\nlemma condEq_neg {α β : Type} [DecidableEq α]\n    {a b : α} {yes no : β} (h : a ≢ b) : condEq a b yes no = no := by\n  unfold condEq\n  cases decEq a b with\n  | isTrue hab => exact (h hab).elim\n  | isFalse _ => rfl\n\ninductive CM where\n  | e : CM\n  | k : CM → CM\n  | p : CM → CM → CM\n\nnamespace CM\n\ndef cmDecEq : (a b : CM) → Decidable (a = b)\n  | .e, .e => isTrue rfl\n  | .e, .k _ => isFalse (fun h => CM.noConfusion h)\n  | .e, .p _ _ => isFalse (fun h => CM.noConfusion h)\n  | .k _, .e => isFalse (fun h => CM.noConfusion h)\n  | .p _ _, .e => isFalse (fun h => CM.noConfusion h)\n  | .k a, .k b =>\n      match cmDecEq a b with\n      | isTrue h => isTrue (congrArg CM.k h)\n      | isFalse h => isFalse (fun hab => h (CM.k.inj hab))\n  | .k _, .p _ _ => isFalse (fun h => CM.noConfusion h)\n  | .p _ _, .k _ => isFalse (fun h => CM.noConfusion h)\n  | .p a b, .p c d =>\n      match cmDecEq a c with\n      | isFalse h => isFalse (fun hab => h (CM.p.inj hab).1)\n      | isTrue hac =>\n          match cmDecEq b d with\n          | isFalse h => isFalse (fun hab => h (CM.p.inj hab).2)\n          | isTrue hbd => isTrue (by cases hac; cases hbd; rfl)\n\ninstance instDecidableEq : DecidableEq CM := cmDecEq\n\ndef sz : CM → Nat\n  | .e => 0\n  | .k x => sz x + 1\n  | .p x y => (sz x + 1) + (sz y + 1)\n\ndef dec : CM → CM\n  | .e => .e\n  | .k x => x\n  | .p a b =>\n      condEq b a (.k a)\n        (match b with\n        | .p c x => condEq c a x .e\n        | _ => .e)\n\nlemma dec_p_eq (a b : CM) :\n    dec (.p a b) = condEq b a (.k a)\n      (match b with\n      | .p c x => condEq c a x .e\n      | _ => .e) := rfl\n\nlemma dec_p_p_eq (a c x : CM) :\n    dec (CM.p a (CM.p c x)) =\n      condEq (CM.p c x) a (CM.k a) (condEq c a x CM.e) := rfl\n\ndef op (a b : CM) : CM :=\n  condEq b .e (dec a) (condEq a (.p b b) .e (.p a b))\n\ninstance instMagma : Magma CM where\n  op := op\n\nlemma sz_p_pos (a b : CM) : 0 < sz (.p a b) := by\n  change 0 < (sz a + 1) + (sz b + 1)\n  exact Nat.lt_of_lt_of_le (Nat.zero_lt_succ (sz a))\n    (Nat.le_add_right (sz a + 1) (sz b + 1))\n\nlemma sz_lt_p_left (a b : CM) : sz a < sz (.p a b) := by\n  change sz a < (sz a + 1) + (sz b + 1)\n  exact Nat.lt_of_lt_of_le (Nat.lt_succ_self (sz a))\n    (Nat.le_add_right (sz a + 1) (sz b + 1))\n\nlemma sz_dec_le (a : CM) : sz (dec a) ≤ sz a := by\n  cases a with\n  | e => exact Nat.le_refl 0\n  | k x =>\n      change sz x ≤ sz x + 1\n      exact Nat.le_add_right (sz x) 1\n  | p a b =>\n      by_cases hba : b = a\n      · subst b\n        rw [dec_p_eq]\n        rw [condEq_pos rfl]\n        change sz a + 1 ≤ (sz a + 1) + (sz a + 1)\n        exact Nat.le_add_right (sz a + 1) (sz a + 1)\n      · cases b with\n        | e =>\n            rw [dec_p_eq]\n            rw [condEq_neg hba]\n            exact Nat.zero_le _\n        | k b =>\n            rw [dec_p_eq]\n            rw [condEq_neg hba]\n            exact Nat.zero_le _\n        | p c x =>\n            by_cases hca : c = a\n            · subst c\n              rw [dec_p_p_eq]\n              rw [condEq_neg hba, condEq_pos rfl]\n              change sz x ≤ (sz a + 1) + (((sz a + 1) + (sz x + 1)) + 1)\n              exact Nat.le_trans (Nat.le_add_right (sz x) 1)\n                (Nat.le_trans (Nat.le_add_left (sz x + 1) (sz a + 1))\n                  (Nat.le_trans\n                    (Nat.le_add_right ((sz a + 1) + (sz x + 1)) 1)\n                    (Nat.le_add_left (((sz a + 1) + (sz x + 1)) + 1) (sz a + 1))))\n            · rw [dec_p_p_eq]\n              rw [condEq_neg hba, condEq_neg hca]\n              exact Nat.zero_le _\n\nlemma sz_dec_lt_of_ne_e (a : CM) (ha : a ≢ .e) : sz (dec a) < sz a := by\n  cases a with\n  | e => exact (ha rfl).elim\n  | k x =>\n      change sz x < sz x + 1\n      exact Nat.lt_succ_self (sz x)\n  | p a b =>\n      by_cases hba : b = a\n      · subst b\n        rw [dec_p_eq]\n        rw [condEq_pos rfl]\n        change sz a + 1 < (sz a + 1) + (sz a + 1)\n        exact Nat.lt_add_of_pos_right (Nat.zero_lt_succ (sz a))\n      · cases b with\n        | e =>\n            rw [dec_p_eq]\n            rw [condEq_neg hba]\n            exact sz_p_pos _ _\n        | k b =>\n            rw [dec_p_eq]\n            rw [condEq_neg hba]\n            exact sz_p_pos _ _\n        | p c x =>\n            by_cases hca : c = a\n            · subst c\n              rw [dec_p_p_eq]\n              rw [condEq_neg hba, condEq_pos rfl]\n              change sz x < (sz a + 1) + (((sz a + 1) + (sz x + 1)) + 1)\n              exact Nat.lt_of_lt_of_le (Nat.lt_succ_self (sz x))\n                (Nat.le_trans (Nat.le_add_left (sz x + 1) (sz a + 1))\n                  (Nat.le_trans\n                    (Nat.le_add_right ((sz a + 1) + (sz x + 1)) 1)\n                    (Nat.le_add_left (((sz a + 1) + (sz x + 1)) + 1) (sz a + 1))))\n            · rw [dec_p_p_eq]\n              rw [condEq_neg hba, condEq_neg hca]\n              exact sz_p_pos _ _\n\nlemma ne_self_p (a b : CM) : a ≢ .p a b := by\n  intro h\n  have hs := congrArg sz h\n  exact (Nat.ne_of_lt (sz_lt_p_left a b)) hs\n\nlemma dec_ne_p_self (a b : CM) : dec a ≢ .p a b := by\n  intro h\n  have hle := sz_dec_le a\n  have hs := congrArg sz h\n  rw [hs] at hle\n  exact (Nat.lt_irrefl (sz a))\n    (Nat.lt_of_lt_of_le (sz_lt_p_left a b) hle)\n\nlemma dec_ne_self_of_dec_ne_e (a : CM) (ha : dec a ≢ .e) : dec a ≢ a := by\n  have hae : a ≢ .e := by\n    intro h\n    subst a\n    exact ha rfl\n  intro h\n  have hlt := sz_dec_lt_of_ne_e a hae\n  have hs := congrArg sz h\n  rw [hs] at hlt\n  exact (Nat.lt_irrefl (sz a)) hlt\n\nlemma dec_p_default (a b : CM) (hba : b ≢ a)\n    (hshape : ∀ x, b ≢ .p a x) : dec (.p a b) = .e := by\n  cases b with\n  | e =>\n      rw [dec_p_eq]\n      rw [condEq_neg hba]\n  | k x =>\n      rw [dec_p_eq]\n      rw [condEq_neg hba]\n  | p c x =>\n      have hca : c ≢ a := by\n        intro h\n        subst c\n        exact hshape x rfl\n      rw [dec_p_p_eq]\n      rw [condEq_neg hba, condEq_neg hca]\n\nlemma dec_p_same (a : CM) : dec (.p a a) = .k a := by\n  rw [dec_p_eq]\n  rw [condEq_pos rfl]\n\nlemma dec_p_nested (a x : CM) : dec (.p a (.p a x)) = x := by\n  have hba : .p a x ≢ a := by\n    intro h\n    exact ne_self_p a x h.symm\n  rw [dec_p_p_eq]\n  rw [condEq_neg hba, condEq_pos rfl]\n\nlemma op_right_e (a : CM) : op a .e = dec a := by\n  unfold op\n  rw [condEq_pos rfl]\n\nlemma op_normal (a b : CM) (hb : b ≢ .e) (ha : a ≢ .p b b) :\n    op a b = .p a b := by\n  unfold op\n  rw [condEq_neg hb, condEq_neg ha]\n\nlemma op_special (a b : CM) (hb : b ≢ .e) (ha : a = .p b b) :\n    op a b = .e := by\n  unfold op\n  rw [condEq_neg hb, condEq_pos ha]\n\nlemma decode_twice (y x : CM) : dec (op y (op y x)) = x := by\n  by_cases hx : x = .e\n  · subst x\n    by_cases hd : dec y = .e\n    · calc\n        dec (op y (op y .e)) = dec (op y (dec y)) := by rw [op_right_e]\n        _ = dec (op y .e) := by rw [hd]\n        _ = dec (dec y) := by rw [op_right_e]\n        _ = dec .e := by rw [hd]\n        _ = .e := rfl\n    · by_cases hy : y = .p (dec y) (dec y)\n      · have oy : op y (dec y) = .e := op_special y (dec y) hd hy\n        calc\n          dec (op y (op y .e)) = dec (op y (dec y)) := by rw [op_right_e]\n          _ = dec .e := by rw [oy]\n          _ = .e := rfl\n      · have hdy : dec y ≢ y := dec_ne_self_of_dec_ne_e y hd\n        have hshape : ∀ q, dec y ≢ .p y q := fun q => dec_ne_p_self y q\n        have hdefault : dec (.p y (dec y)) = .e :=\n          dec_p_default y (dec y) hdy hshape\n        have oy : op y (dec y) = .p y (dec y) := op_normal y (dec y) hd hy\n        calc\n          dec (op y (op y .e)) = dec (op y (dec y)) := by rw [op_right_e]\n          _ = dec (.p y (dec y)) := by rw [oy]\n          _ = .e := hdefault\n  · by_cases hy : y = .p x x\n    · subst y\n      have hinner : op (.p x x) x = .e := op_special (.p x x) x hx rfl\n      calc\n        dec (op (.p x x) (op (.p x x) x)) = dec (op (.p x x) .e) := by rw [hinner]\n        _ = dec (dec (.p x x)) := by rw [op_right_e]\n        _ = dec (.k x) := by rw [dec_p_same]\n        _ = x := rfl\n    · have hbig : y ≢ .p (.p y x) (.p y x) := by\n        intro h\n        have hs := congrArg sz h\n        have hlt := Nat.lt_trans (sz_lt_p_left y x)\n          (sz_lt_p_left (.p y x) (.p y x))\n        exact (Nat.ne_of_lt hlt) hs\n      have hpxe : CM.p y x ≢ CM.e := by\n        intro h\n        exact CM.noConfusion h\n      have hinner : op y x = .p y x := op_normal y x hx hy\n      have houter : op y (.p y x) = .p y (.p y x) :=\n        op_normal y (.p y x) hpxe hbig\n      calc\n        dec (op y (op y x)) = dec (op y (.p y x)) := by rw [hinner]\n        _ = dec (.p y (.p y x)) := by rw [houter]\n        _ = x := dec_p_nested y x\n\nlemma triple (z : CM) : op (op z z) z = .e := by\n  by_cases hz : z = .e\n  · subst z\n    have hee : op CM.e CM.e = CM.e := by\n      calc\n        op CM.e CM.e = dec CM.e := op_right_e CM.e\n        _ = CM.e := rfl\n    exact (congrArg (fun q => op q CM.e) hee).trans hee\n  · have hself : z ≢ .p z z := ne_self_p z z\n    have hinner : op z z = .p z z := op_normal z z hz hself\n    calc\n      op (op z z) z = op (.p z z) z := by rw [hinner]\n      _ = .e := op_special (.p z z) z hz rfl\n\nend CM\n\nend submission\n\nopen submission\n\nopen submission\n\n'
_D15_ACCEPTED_CM_SOURCE_BRANCHES = {'[0,["op",["op",1,["op",1,1]],["op",["op",0,1],1]]]': '  · intro x y\n    change x = CM.op (CM.op y (CM.op y x)) (CM.op (CM.op y y) y)\n    rw [CM.triple]\n    change x = CM.dec (CM.op y (CM.op y x))\n    exact (CM.decode_twice y x).symm\n', '[0,["op",["op",1,["op",1,1]],["op",["op",0,2],2]]]': '  · intro x y z\n    change x = CM.op (CM.op z (CM.op z x)) (CM.op (CM.op y y) y)\n    rw [CM.triple]\n    change x = CM.dec (CM.op z (CM.op z x))\n    exact (CM.decode_twice z x).symm\n'}
_D15_ACCEPTED_CM_WITNESS_POOL = (
    ("e",),
    ("k", ("e",)),
)


def _d15_accepted_cm_dec(value):
    tag = value[0]
    if tag == "e":
        return value
    if tag == "k":
        return value[1]
    left, right = value[1], value[2]
    if right == left:
        return ("k", left)
    if right[0] == "p" and right[1] == left:
        return right[2]
    return ("e",)


def _d15_accepted_cm_core_op(left, right):
    if right == ("e",):
        return _d15_accepted_cm_dec(left)
    if left == ("p", right, right):
        return ("e",)
    return ("p", left, right)


def _d15_accepted_cm_opposite(left, right):
    return _d15_accepted_cm_core_op(right, left)


def _d15_accepted_cm_eval(term, values):
    if type(term) is int:
        return values[term]
    return _d15_accepted_cm_opposite(
        _d15_accepted_cm_eval(term[0], values),
        _d15_accepted_cm_eval(term[1], values),
    )


def _d15_accepted_cm_literal(value):
    tag = value[0]
    if tag == "e":
        return "CM.e"
    if tag == "k":
        return f"(CM.k {_d15_accepted_cm_literal(value[1])})"
    return (
        f"(CM.p {_d15_accepted_cm_literal(value[1])} "
        f"{_d15_accepted_cm_literal(value[2])})"
    )


def _d15_accepted_cm_lean_term(term, values):
    if type(term) is int:
        return _d15_accepted_cm_literal(values[term])
    left = _d15_accepted_cm_lean_term(term[0], values)
    right = _d15_accepted_cm_lean_term(term[1], values)
    return f"(CM.op {right} {left})"


def _d15_accepted_cm_candidate(parsed_source, parsed_target):
    source_pattern = _source_pattern(parsed_source)
    source_branch = _D15_ACCEPTED_CM_SOURCE_BRANCHES.get(source_pattern)
    if source_branch is None:
        return None
    variables, left, right = parsed_target
    if not 1 <= len(variables) <= 4:
        return None
    for values in product(_D15_ACCEPTED_CM_WITNESS_POOL, repeat=len(variables)):
        if _d15_accepted_cm_eval(left, values) == _d15_accepted_cm_eval(right, values):
            continue
        applications = " ".join(_d15_accepted_cm_literal(value) for value in values)
        closed_left = _d15_accepted_cm_lean_term(left, values)
        closed_right = _d15_accepted_cm_lean_term(right, values)
        target_branch = (
            "  · intro target\n"
            f"    have bad := target {applications}\n"
            f"    change {closed_left} = {closed_right} at bad\n"
            f"    exact (show Not ({closed_left} = {closed_right}) "
            "from by decide) bad\n"
        )
        submission = (
            "def submission.d15OppositeMagmaCM : Magma CM where\n"
            "  op a b := CM.op b a\n\n"
            "def submission : Goal := by\n"
            "  refine ⟨CM, d15OppositeMagmaCM, ?_, ?_⟩\n"
        )
        return (
            _D15_ACCEPTED_CM_FAMILY,
            _D15_ACCEPTED_CM_MODEL_CORE + submission + source_branch + target_branch,
            "alpha_exact_source_law_and_bounded_target_ast_witness",
        )
    return None



_D15_PATTERN_CM_FAMILY = "d15_inductive_pattern_cm_transfer"
_D15_PATTERN_CM_MODEL_CORE = "import JudgeProblem\nimport Mathlib\n\nset_option maxRecDepth 10000\n\nnamespace submission\n\ninductive CM where\n  | e : CM\n  | k : CM → CM\n  | p : CM → CM → CM\n\nnamespace CM\n\ndef cmDecEq : (a b : CM) → Decidable (a = b)\n  | CM.e, CM.e => isTrue rfl\n  | CM.e, CM.k _ => isFalse (fun h => CM.noConfusion h)\n  | CM.e, CM.p _ _ => isFalse (fun h => CM.noConfusion h)\n  | CM.k _, CM.e => isFalse (fun h => CM.noConfusion h)\n  | CM.p _ _, CM.e => isFalse (fun h => CM.noConfusion h)\n  | CM.k a, CM.k b =>\n      match cmDecEq a b with\n      | isTrue h => isTrue (congrArg CM.k h)\n      | isFalse h => isFalse (fun hab => h (CM.k.inj hab))\n  | CM.k _, CM.p _ _ => isFalse (fun h => CM.noConfusion h)\n  | CM.p _ _, CM.k _ => isFalse (fun h => CM.noConfusion h)\n  | CM.p a b, CM.p c d =>\n      match cmDecEq a c with\n      | isFalse h => isFalse (fun hab => h (CM.p.inj hab).1)\n      | isTrue hac =>\n          match cmDecEq b d with\n          | isFalse h => isFalse (fun hab => h (CM.p.inj hab).2)\n          | isTrue hbd => isTrue (by cases hac; cases hbd; rfl)\n\ninstance instDecidableEq : DecidableEq CM := cmDecEq\n\ndef sz : CM → Nat\n  | CM.e => 0\n  | CM.k x => sz x + 1\n  | CM.p x y => (sz x + 1) + (sz y + 1)\n\nlemma sz_lt_p_left (a b : CM) : sz a < sz (CM.p a b) := by\n  change sz a < (sz a + 1) + (sz b + 1)\n  exact Nat.lt_of_lt_of_le (Nat.lt_succ_self (sz a))\n    (Nat.le_add_right (sz a + 1) (sz b + 1))\n\nlemma sz_lt_p_right (a b : CM) : sz b < sz (CM.p a b) := by\n  change sz b < (sz a + 1) + (sz b + 1)\n  exact Nat.lt_of_lt_of_le (Nat.lt_succ_self (sz b))\n    (Nat.le_add_left (sz b + 1) (sz a + 1))\n\nstructure Pat1 where\n  y : CM\n  x : CM\n  z : CM\n\nstructure Pat2 where\n  a : CM\n  b : CM\n  c : CM\n\ndef left1 (m : Pat1) : CM := CM.p m.y (CM.p m.x m.x)\ndef right1 (m : Pat1) : CM := CM.p (CM.p m.y m.z) m.y\ndef left2 (m : Pat2) : CM := CM.p (CM.p m.a (CM.p m.b m.b)) (CM.p m.c m.c)\ndef right2 (m : Pat2) : CM := CM.p m.b (CM.p m.a (CM.p m.b m.b))\n\nabbrev No1 (a b : CM) := (m : Pat1) → a = left1 m → b = right1 m → False\nabbrev No2 (a b : CM) := (m : Pat2) → a = left2 m → b = right2 m → False\n\ndef get1Y : CM → CM\n  | CM.p y _ => y\n  | _ => CM.e\n\ndef get1X : CM → CM\n  | CM.p _ (CM.p x _) => x\n  | _ => CM.e\n\ndef get1Z : CM → CM\n  | CM.p (CM.p _ z) _ => z\n  | _ => CM.e\n\ndef get2A : CM → CM\n  | CM.p (CM.p a _) _ => a\n  | _ => CM.e\n\ndef get2B : CM → CM\n  | CM.p (CM.p _ (CM.p b _)) _ => b\n  | _ => CM.e\n\ndef get2C : CM → CM\n  | CM.p _ (CM.p c _) => c\n  | _ => CM.e\n\ninductive Detect1 (a b : CM) where\n  | yes (m : Pat1) (ha : a = left1 m) (hb : b = right1 m)\n  | no (h : No1 a b)\n\ninductive Detect2 (a b : CM) where\n  | yes (m : Pat2) (ha : a = left2 m) (hb : b = right2 m)\n  | no (h : No2 a b)\n\ndef detect1 (a b : CM) : Detect1 a b :=\n  let m : Pat1 := ⟨get1Y a, get1X a, get1Z b⟩\n  match cmDecEq a (left1 m) with\n  | isFalse ha => .no (fun q hqa _ => by cases hqa; exact ha rfl)\n  | isTrue ha =>\n      match cmDecEq b (right1 m) with\n      | isFalse hb => .no (fun q hqa hqb => by\n          cases hqa\n          cases hqb\n          exact hb rfl)\n      | isTrue hb => .yes m ha hb\n\ndef detect2 (a b : CM) : Detect2 a b :=\n  let m : Pat2 := ⟨get2A a, get2B a, get2C a⟩\n  match cmDecEq a (left2 m) with\n  | isFalse ha => .no (fun q hqa _ => by cases hqa; exact ha rfl)\n  | isTrue ha =>\n      match cmDecEq b (right2 m) with\n      | isFalse hb => .no (fun q hqa hqb => by\n          cases hqa\n          cases hqb\n          exact hb rfl)\n      | isTrue hb => .yes m ha hb\n\ninductive View (a b : CM) where\n  | r1 (m : Pat1) (ha : a = left1 m) (hb : b = right1 m)\n  | r2 (m : Pat2) (ha : a = left2 m) (hb : b = right2 m)\n  | raw (h1 : No1 a b) (h2 : No2 a b)\n\ndef view (a b : CM) : View a b :=\n  match detect1 a b with\n  | .yes m ha hb => .r1 m ha hb\n  | .no h1 =>\n      match detect2 a b with\n      | .yes m ha hb => .r2 m ha hb\n      | .no h2 => .raw h1 h2\n\ndef op (a b : CM) : CM :=\n  match view a b with\n  | .r1 m _ _ => m.x\n  | .r2 m _ _ => m.c\n  | .raw _ _ => CM.p a b\n\ninstance instMagma : Magma CM where\n  op := op\n\nlemma pat_disjoint (m : Pat1) (n : Pat2)\n    (hl : left1 m = left2 n) (hr : right1 m = right2 n) : False := by\n  have hy : m.y = CM.p n.a (CM.p n.b n.b) := (CM.p.inj hl).1\n  have hb : CM.p m.y m.z = n.b := (CM.p.inj hr).1\n  have hby : sz n.b < sz m.y := by\n    have h1 : sz n.b < sz (CM.p n.b n.b) := sz_lt_p_left n.b n.b\n    have h2 : sz (CM.p n.b n.b) < sz (CM.p n.a (CM.p n.b n.b)) :=\n      sz_lt_p_right n.a (CM.p n.b n.b)\n    exact Nat.lt_of_lt_of_eq (Nat.lt_trans h1 h2) (congrArg sz hy).symm\n  have hyb : sz m.y < sz n.b :=\n    Nat.lt_of_lt_of_eq (sz_lt_p_left m.y m.z) (congrArg sz hb)\n  exact (Nat.lt_irrefl (sz n.b)) (Nat.lt_trans hby hyb)\n\nlemma op_rule1 (m : Pat1) : op (left1 m) (right1 m) = m.x := by\n  unfold op view\n  cases hd : detect1 (left1 m) (right1 m) with\n  | yes q hq _ =>\n      change q.x = m.x\n      have hp : CM.p m.x m.x = CM.p q.x q.x := (CM.p.inj hq).2\n      exact (CM.p.inj hp).1.symm\n  | no hn => exact (hn m rfl rfl).elim\n\nlemma op_rule2 (m : Pat2) : op (left2 m) (right2 m) = m.c := by\n  unfold op view\n  cases hd1 : detect1 (left2 m) (right2 m) with\n  | yes q hq1 hq2 => exact (pat_disjoint q m hq1.symm hq2.symm).elim\n  | no _ =>\n      cases hd2 : detect2 (left2 m) (right2 m) with\n      | yes q hq _ =>\n          change q.c = m.c\n          have hp : CM.p m.c m.c = CM.p q.c q.c := (CM.p.inj hq).2\n          exact (CM.p.inj hp).1.symm\n      | no hn => exact (hn m rfl rfl).elim\n\nlemma op_raw {a b : CM} (h1 : No1 a b) (h2 : No2 a b) : op a b = CM.p a b := by\n  unfold op view\n  cases hd1 : detect1 a b with\n  | yes m ha hb => exact (h1 m ha hb).elim\n  | no _ =>\n      cases hd2 : detect2 a b with\n      | yes m ha hb => exact (h2 m ha hb).elim\n      | no _ => rfl\n\nlemma no1_same (t : CM) : No1 t t := by\n  intro m hl hr\n  have h : left1 m = right1 m := hl.symm.trans hr\n  have hy : m.y = CM.p m.y m.z := (CM.p.inj h).1\n  exact (Nat.ne_of_lt (sz_lt_p_left m.y m.z)) (congrArg sz hy)\n\nlemma no2_same (t : CM) : No2 t t := by\n  intro m hl hr\n  have h : left2 m = right2 m := hl.symm.trans hr\n  have hb : CM.p m.a (CM.p m.b m.b) = m.b := (CM.p.inj h).1\n  have hlt : sz m.b < sz (CM.p m.a (CM.p m.b m.b)) :=\n    Nat.lt_trans (sz_lt_p_left m.b m.b)\n      (sz_lt_p_right m.a (CM.p m.b m.b))\n  exact (Nat.ne_of_lt hlt) (congrArg sz hb).symm\n\nlemma no1_encode (y x : CM) : No1 y (CM.p x x) := by\n  intro m _ hr\n  have hx1 : x = CM.p m.y m.z := (CM.p.inj hr).1\n  have hx2 : x = m.y := (CM.p.inj hr).2\n  have hy : m.y = CM.p m.y m.z := hx2.symm.trans hx1\n  exact (Nat.ne_of_lt (sz_lt_p_left m.y m.z)) (congrArg sz hy)\n\nlemma no2_encode (y x : CM) : No2 y (CM.p x x) := by\n  intro m _ hr\n  have hx1 : x = m.b := (CM.p.inj hr).1\n  have hx2 : x = CM.p m.a (CM.p m.b m.b) := (CM.p.inj hr).2\n  have hb : m.b = CM.p m.a (CM.p m.b m.b) := hx1.symm.trans hx2\n  have hlt : sz m.b < sz (CM.p m.a (CM.p m.b m.b)) :=\n    Nat.lt_trans (sz_lt_p_left m.b m.b)\n      (sz_lt_p_right m.a (CM.p m.b m.b))\n  exact (Nat.ne_of_lt hlt) (congrArg sz hb)\n\nlemma no1_after1 (m : Pat1) : No1 m.x (left1 m) := by\n  intro q hl hr\n  have hright : CM.p m.x m.x = q.y := (CM.p.inj hr).2\n  have hqx : sz q.y < sz m.x :=\n    Nat.lt_of_lt_of_eq (sz_lt_p_left q.y (CM.p q.x q.x)) (congrArg sz hl).symm\n  have hxq : sz m.x < sz q.y :=\n    Nat.lt_of_lt_of_eq (sz_lt_p_left m.x m.x) (congrArg sz hright)\n  exact (Nat.lt_irrefl (sz q.y)) (Nat.lt_trans hqx hxq)\n\nlemma no2_after1 (m : Pat1) : No2 m.x (left1 m) := by\n  intro q hl hr\n  have hxq : m.x = q.a := (CM.p.inj (CM.p.inj hr).2).1\n  have hqa : sz q.a < sz m.x :=\n    Nat.lt_of_lt_of_eq\n      (Nat.lt_trans (sz_lt_p_left q.a (CM.p q.b q.b))\n        (sz_lt_p_left (CM.p q.a (CM.p q.b q.b)) (CM.p q.c q.c)))\n      (congrArg sz hl).symm\n  exact (Nat.ne_of_lt hqa) (congrArg sz hxq).symm\n\nlemma no1_after2 (m : Pat2) : No1 m.c (left2 m) := by\n  intro q hl hr\n  have hcy : CM.p m.c m.c = q.y := (CM.p.inj hr).2\n  have hyc : sz q.y < sz m.c :=\n    Nat.lt_of_lt_of_eq (sz_lt_p_left q.y (CM.p q.x q.x)) (congrArg sz hl).symm\n  have hcy' : sz m.c < sz q.y :=\n    Nat.lt_of_lt_of_eq (sz_lt_p_left m.c m.c) (congrArg sz hcy)\n  exact (Nat.lt_irrefl (sz q.y)) (Nat.lt_trans hyc hcy')\n\nlemma no2_after2 (m : Pat2) : No2 m.c (left2 m) := by\n  intro q hl hr\n  have hcq : m.c = q.a := (CM.p.inj (CM.p.inj hr).2).1\n  have hqa : sz q.a < sz m.c :=\n    Nat.lt_of_lt_of_eq\n      (Nat.lt_trans (sz_lt_p_left q.a (CM.p q.b q.b))\n        (sz_lt_p_left (CM.p q.a (CM.p q.b q.b)) (CM.p q.c q.c)))\n      (congrArg sz hl).symm\n  exact (Nat.ne_of_lt hqa) (congrArg sz hcq).symm\n\nlemma no1_after_raw (y z : CM) : No1 (CM.p y z) y := by\n  intro m hl hr\n  have hy : y = m.y := (CM.p.inj hl).1\n  have hself : m.y = right1 m := hy.symm.trans hr\n  have hlt : sz m.y < sz (right1 m) := by\n    unfold right1\n    exact sz_lt_p_right (CM.p m.y m.z) m.y\n  exact (Nat.ne_of_lt hlt) (congrArg sz hself)\n\nlemma no2_after_raw (y z : CM) : No2 (CM.p y z) y := by\n  intro m hl hr\n  have hy : y = CM.p m.a (CM.p m.b m.b) := (CM.p.inj hl).1\n  have hself : CM.p m.a (CM.p m.b m.b) =\n      CM.p m.b (CM.p m.a (CM.p m.b m.b)) := hy.symm.trans hr\n  have hlt : sz (CM.p m.a (CM.p m.b m.b)) <\n      sz (CM.p m.b (CM.p m.a (CM.p m.b m.b))) :=\n    sz_lt_p_right m.b (CM.p m.a (CM.p m.b m.b))\n  exact (Nat.ne_of_lt hlt) (congrArg sz hself)\n\nlemma square (x : CM) : op x x = CM.p x x := op_raw (no1_same x) (no2_same x)\n\nlemma encode (y x : CM) : op y (CM.p x x) = CM.p y (CM.p x x) :=\n  op_raw (no1_encode y x) (no2_encode y x)\n\nlemma return_right (y z : CM) : op (op y z) y = CM.p (op y z) y := by\n  cases hv : view y z with\n  | r1 m ha hb =>\n      have hop : op y z = m.x := by unfold op; rw [hv]\n      rw [hop, ha]\n      exact op_raw (no1_after1 m) (no2_after1 m)\n  | r2 m ha hb =>\n      have hop : op y z = m.c := by unfold op; rw [hv]\n      rw [hop, ha]\n      exact op_raw (no1_after2 m) (no2_after2 m)\n  | raw h1 h2 =>\n      have hop : op y z = CM.p y z := by unfold op; rw [hv]\n      rw [hop]\n      exact op_raw (no1_after_raw y z) (no2_after_raw y z)\n\n"
_D15_PATTERN_CM_SOURCE_ROUTES = {'[0,["op",["op",1,["op",2,1]],["op",["op",0,0],1]]]': ('lemma source_holds (x y z : CM) :\n    x = op (op y (op x x)) (op (op y z) y) := by\n  rw [square x, encode y x, return_right y z]\n  cases hv : view y z with\n  | r1 m ha hb =>\n      have hop : op y z = m.x := by unfold op; rw [hv]\n      rw [hop, ha]\n      exact (op_rule2 ⟨m.y, m.x, x⟩).symm\n  | r2 m ha hb =>\n      have hop : op y z = m.c := by unfold op; rw [hv]\n      rw [hop, ha]\n      exact (op_rule2 ⟨CM.p m.a (CM.p m.b m.b), m.c, x⟩).symm\n  | raw h1 h2 =>\n      have hop : op y z = CM.p y z := by unfold op; rw [hv]\n      rw [hop]\n      exact (op_rule1 ⟨y, x, z⟩).symm\n\n', '  · intro x y z\n    change x = CM.op (CM.op y (CM.op x x)) (CM.op (CM.op y z) y)\n    exact CM.source_holds x y z\n')}
_D15_PATTERN_CM_WITNESS_POOL = (("e",),)


def _d15_pattern_cm_p(left, right):
    return ("p", left, right)


def _d15_pattern_cm_left1(match):
    y, x, _z = match
    return _d15_pattern_cm_p(y, _d15_pattern_cm_p(x, x))


def _d15_pattern_cm_right1(match):
    y, _x, z = match
    return _d15_pattern_cm_p(_d15_pattern_cm_p(y, z), y)


def _d15_pattern_cm_left2(match):
    a, b, c = match
    return _d15_pattern_cm_p(
        _d15_pattern_cm_p(a, _d15_pattern_cm_p(b, b)),
        _d15_pattern_cm_p(c, c),
    )


def _d15_pattern_cm_right2(match):
    a, b, _c = match
    return _d15_pattern_cm_p(b, _d15_pattern_cm_p(a, _d15_pattern_cm_p(b, b)))


def _d15_pattern_cm_match1(left, right):
    y = left[1] if left[0] == "p" else ("e",)
    x = (
        left[2][1]
        if left[0] == "p" and left[2][0] == "p"
        else ("e",)
    )
    z = (
        right[1][2]
        if right[0] == "p" and right[1][0] == "p"
        else ("e",)
    )
    match = (y, x, z)
    return match if left == _d15_pattern_cm_left1(match) and right == _d15_pattern_cm_right1(match) else None


def _d15_pattern_cm_match2(left, right):
    a = (
        left[1][1]
        if left[0] == "p" and left[1][0] == "p"
        else ("e",)
    )
    b = (
        left[1][2][1]
        if (
            left[0] == "p"
            and left[1][0] == "p"
            and left[1][2][0] == "p"
        )
        else ("e",)
    )
    c = (
        left[2][1]
        if left[0] == "p" and left[2][0] == "p"
        else ("e",)
    )
    match = (a, b, c)
    return match if left == _d15_pattern_cm_left2(match) and right == _d15_pattern_cm_right2(match) else None


def _d15_pattern_cm_core_op(left, right):
    match1 = _d15_pattern_cm_match1(left, right)
    if match1 is not None:
        return match1[1]
    match2 = _d15_pattern_cm_match2(left, right)
    if match2 is not None:
        return match2[2]
    return _d15_pattern_cm_p(left, right)


def _d15_pattern_cm_opposite(left, right):
    return _d15_pattern_cm_core_op(right, left)


def _d15_pattern_cm_eval(term, values):
    if type(term) is int:
        return values[term]
    return _d15_pattern_cm_opposite(
        _d15_pattern_cm_eval(term[0], values),
        _d15_pattern_cm_eval(term[1], values),
    )


def _d15_pattern_cm_literal(value):
    tag = value[0]
    if tag == "e":
        return "CM.e"
    if tag == "k":
        return f"(CM.k {_d15_pattern_cm_literal(value[1])})"
    return (
        f"(CM.p {_d15_pattern_cm_literal(value[1])} "
        f"{_d15_pattern_cm_literal(value[2])})"
    )


def _d15_pattern_cm_lean_term(term, values):
    if type(term) is int:
        return _d15_pattern_cm_literal(values[term])
    left = _d15_pattern_cm_lean_term(term[0], values)
    right = _d15_pattern_cm_lean_term(term[1], values)
    return f"(CM.op {right} {left})"


def _d15_pattern_cm_candidate(parsed_source, parsed_target):
    source_pattern = _source_pattern(parsed_source)
    source_route = _D15_PATTERN_CM_SOURCE_ROUTES.get(source_pattern)
    if source_route is None:
        return None
    source_proof, source_branch = source_route
    variables, left, right = parsed_target
    if not 1 <= len(variables) <= 6:
        return None
    for values in product(_D15_PATTERN_CM_WITNESS_POOL, repeat=len(variables)):
        if _d15_pattern_cm_eval(left, values) == _d15_pattern_cm_eval(right, values):
            continue
        applications = " ".join(_d15_pattern_cm_literal(value) for value in values)
        closed_left = _d15_pattern_cm_lean_term(left, values)
        closed_right = _d15_pattern_cm_lean_term(right, values)
        target_branch = (
            "  · intro target\n"
            f"    have bad := target {applications}\n"
            f"    change {closed_left} = {closed_right} at bad\n"
            f"    exact (show Not ({closed_left} = {closed_right}) "
            "from by decide) bad\n"
        )
        submission = (
            "end CM\n\n"
            "end submission\n\n"
            "open submission\n\n"
            "def submission.d15OppositeMagmaPatternCM : Magma CM where\n"
            "  op a b := CM.op b a\n\n"
            "def submission : Goal := by\n"
            "  refine ⟨CM, d15OppositeMagmaPatternCM, ?_, ?_⟩\n"
        )
        return (
            _D15_PATTERN_CM_FAMILY,
            _D15_PATTERN_CM_MODEL_CORE
            + source_proof
            + submission
            + source_branch
            + target_branch,
            "alpha_exact_source_law_and_singleton_target_ast_witness",
        )
    return None



_D15_KBO_FAMILY = "d15_kbo_completion_transfer"
_D15_KBO_MODEL_CORE = 'import JudgeProblem\nimport Mathlib\n\nset_option maxRecDepth 10000\n\nnamespace submission\n\ninductive CM where\n  | e : CM\n  | p : CM → CM → CM\nderiving DecidableEq\n\nnamespace CM\n\ndef sz : CM → Nat\n  | e => 0\n  | p a b => sz a + sz b + 1\n\ndef sq (a : CM) : CM := p a a\n\ndef d (a b : CM) : CM :=\n  p (p (sq b) (sq a)) (sq b)\n\ndef lhs0 (a x : CM) : CM :=\n  p (p (p a (sq x)) a) a\n\ndef lhs1 (a b : CM) : CM :=\n  p (p a (d a b)) (d a b)\n\ndef get0a : CM → CM\n  | p _ a => a\n  | _ => e\n\ndef get0x : CM → CM\n  | p (p (p _ (p x _)) _) _ => x\n  | _ => e\n\ndef get1a : CM → CM\n  | p (p a _) _ => a\n  | _ => e\n\ndef get1b : CM → CM\n  | p _ (p (p (p b _) _) _) => b\n  | _ => e\n\ndef root (t : CM) : CM :=\n  let a0 := get0a t\n  let x0 := get0x t\n  if t = lhs0 a0 x0 then\n    x0\n  else\n    let a1 := get1a t\n    let b1 := get1b t\n    if t = lhs1 a1 b1 then b1 else t\n\ndef op (a b : CM) : CM := root (p a b)\n\ninstance instMagma : Magma CM where\n  op := op\n\ntheorem lhs1_not_lhs0 (a b c x : CM) :\n    lhs1 a b = lhs0 c x → False := by\n  intro h\n  have hr : d a b = c := (CM.p.inj h).2\n  have hl : a = p c (sq x) := (CM.p.inj (CM.p.inj h).1).1\n  have hself : a = p (d a b) (sq x) := by\n    exact hl.trans (congrArg (fun q => p q (sq x)) hr.symm)\n  have hs := congrArg sz hself\n  simp [d, sq, sz] at hs\n  omega\n\ntheorem root_lhs0 (a x : CM) : root (lhs0 a x) = x := by\n  change\n    (if lhs0 a x = lhs0 a x then x\n      else\n        if lhs0 a x =\n            lhs1 (get1a (lhs0 a x)) (get1b (lhs0 a x))\n          then get1b (lhs0 a x) else lhs0 a x) = x\n  rw [if_pos rfl]\n\ntheorem root_lhs1 (a b : CM) : root (lhs1 a b) = b := by\n  change\n    (if lhs1 a b = lhs0 (d a b) (get0x (lhs1 a b))\n      then get0x (lhs1 a b)\n      else if lhs1 a b = lhs1 a b then b else lhs1 a b) = b\n  rw [if_neg (lhs1_not_lhs0 a b _ _), if_pos rfl]\n\ntheorem root_eq_self {t : CM}\n    (h0 : t = lhs0 (get0a t) (get0x t) → False)\n    (h1 : t = lhs1 (get1a t) (get1b t) → False) :\n    root t = t := by\n  unfold root\n  rw [if_neg h0, if_neg h1]\n\ntheorem op_rule0 (a x : CM) :\n    op (p (p a (sq x)) a) a = x := by\n  exact root_lhs0 a x\n\ntheorem op_rule1 (a b : CM) :\n    op (p a (d a b)) (d a b) = b := by\n  exact root_lhs1 a b\n\ntheorem no_xx_lhs0 (q a x : CM) :\n    p q q = lhs0 a x → False := by\n  intro h\n  have hl : q = p (p a (sq x)) a := (CM.p.inj h).1\n  have hr : q = a := (CM.p.inj h).2\n  have hself : a = p (p a (sq x)) a := hr.symm.trans hl\n  have hs := congrArg sz hself\n  simp [sq, sz] at hs\n  omega\n\ntheorem no_xx_lhs1 (q a b : CM) :\n    p q q = lhs1 a b → False := by\n  intro h\n  have hl : q = p a (d a b) := (CM.p.inj h).1\n  have hr : q = d a b := (CM.p.inj h).2\n  have hself : d a b = p a (d a b) := hr.symm.trans hl\n  have hs := congrArg sz hself\n  simp [d, sq, sz] at hs\n  omega\n\ntheorem op_xx_raw (q : CM) : op q q = p q q := by\n  unfold op\n  apply root_eq_self\n  · exact no_xx_lhs0 q _ _\n  · exact no_xx_lhs1 q _ _\n\ntheorem mid_not_lhs1 (x y a b : CM) :\n    p y (sq x) = lhs1 a b → False := by\n  intro h\n  have hr : sq x = d a b := (CM.p.inj h).2\n  have hleft : x = p (sq b) (sq a) := (CM.p.inj hr).1\n  have hright : x = sq b := (CM.p.inj hr).2\n  have hself : sq b = p (sq b) (sq a) :=\n    hright.symm.trans hleft\n  have hs := congrArg sz hself\n  simp [sq, sz] at hs\n  omega\n\ntheorem prefix0_not_lhs0 (x y a b : CM) :\n    p (p y (sq x)) y = lhs0 a b → False := by\n  intro h\n  have hr : y = a := (CM.p.inj h).2\n  have hl : y = p a (sq b) := (CM.p.inj (CM.p.inj h).1).1\n  have hself : a = p a (sq b) := hr.symm.trans hl\n  have hs := congrArg sz hself\n  simp [sq, sz] at hs\n  omega\n\ntheorem prefix0_not_lhs1 (x y a b : CM) :\n    p (p y (sq x)) y = lhs1 a b → False := by\n  intro h\n  have hr : y = d a b := (CM.p.inj h).2\n  have hl : y = a := (CM.p.inj (CM.p.inj h).1).1\n  have hself : a = d a b := hl.symm.trans hr\n  have hs := congrArg sz hself\n  simp [d, sq, sz] at hs\n  omega\n\ntheorem op_prefix0_raw (x y : CM) :\n    op (p y (sq x)) y = p (p y (sq x)) y := by\n  unfold op\n  apply root_eq_self\n  · exact prefix0_not_lhs0 x y _ _\n  · exact prefix0_not_lhs1 x y _ _\n\ntheorem prefix1_not_lhs0 (a b c x : CM) :\n    p a (d a b) = lhs0 c x → False := by\n  intro h\n  have hr : d a b = c := (CM.p.inj h).2\n  have hl : a = p (p c (sq x)) c := (CM.p.inj h).1\n  have hself : a = p (p (d a b) (sq x)) (d a b) := by\n    exact hl.trans\n      (congrArg (fun q => p (p q (sq x)) q) hr.symm)\n  have hs := congrArg sz hself\n  simp [d, sq, sz] at hs\n  omega\n\ntheorem prefix1_not_lhs1 (a b c x : CM) :\n    p a (d a b) = lhs1 c x → False := by\n  intro h\n  have hr : d a b = d c x := (CM.p.inj h).2\n  have hl : a = p c (d c x) := (CM.p.inj h).1\n  have hs1 := congrArg sz hr\n  have hs2 := congrArg sz hl\n  simp [d, sq, sz] at hs1 hs2\n  omega\n\ntheorem op_prefix1_raw (a b : CM) :\n    op a (d a b) = p a (d a b) := by\n  unfold op\n  apply root_eq_self\n  · exact prefix1_not_lhs0 a b _ _\n  · exact prefix1_not_lhs1 a b _ _\n\n'
_D15_KBO_SOURCE_ROUTES = {'[0,["op",1,["op",1,["op",["op",0,0],1]]]]': ('theorem source_holds (x y : CM) :\n    x = op (op (op y (op x x)) y) y := by\n  rw [op_xx_raw]\n  change x = op (op (op y (sq x)) y) y\n  let b := get0x (p y (sq x))\n  by_cases h : p y (sq x) = lhs0 (sq x) b\n  · have hy : y = d b x := by\n      simpa [lhs0, d] using (CM.p.inj h).1\n    have hmid : op y (sq x) = b := by\n      unfold op\n      rw [h]\n      exact root_lhs0 (sq x) b\n    rw [hmid, hy, op_prefix1_raw]\n    exact (op_rule1 b x).symm\n  · have hmid : op y (sq x) = p y (sq x) := by\n      unfold op\n      apply root_eq_self\n      · exact h\n      · exact mid_not_lhs1 x y _ _\n    rw [hmid, op_prefix0_raw]\n    exact (op_rule0 y x).symm\n', '  · intro x y\n    change x = CM.op (CM.op (CM.op y (CM.op x x)) y) y\n    exact CM.source_holds x y\n')}
_D15_KBO_WITNESS_POOL = (("e",),)


def _d15_kbo_p(left, right):
    return ("p", left, right)


def _d15_kbo_sq(value):
    return _d15_kbo_p(value, value)


def _d15_kbo_d(left, right):
    return _d15_kbo_p(
        _d15_kbo_p(_d15_kbo_sq(right), _d15_kbo_sq(left)),
        _d15_kbo_sq(right),
    )


def _d15_kbo_lhs0(left, value):
    return _d15_kbo_p(
        _d15_kbo_p(_d15_kbo_p(left, _d15_kbo_sq(value)), left),
        left,
    )


def _d15_kbo_lhs1(left, right):
    delta = _d15_kbo_d(left, right)
    return _d15_kbo_p(_d15_kbo_p(left, delta), delta)


def _d15_kbo_get0a(term):
    return term[2] if term[0] == "p" else ("e",)


def _d15_kbo_get0x(term):
    if (
        term[0] == "p"
        and term[1][0] == "p"
        and term[1][1][0] == "p"
        and term[1][1][2][0] == "p"
    ):
        return term[1][1][2][1]
    return ("e",)


def _d15_kbo_get1a(term):
    if term[0] == "p" and term[1][0] == "p":
        return term[1][1]
    return ("e",)


def _d15_kbo_get1b(term):
    if (
        term[0] == "p"
        and term[2][0] == "p"
        and term[2][1][0] == "p"
        and term[2][1][1][0] == "p"
    ):
        return term[2][1][1][1]
    return ("e",)


def _d15_kbo_root(term):
    left0 = _d15_kbo_get0a(term)
    value0 = _d15_kbo_get0x(term)
    if term == _d15_kbo_lhs0(left0, value0):
        return value0
    left1 = _d15_kbo_get1a(term)
    right1 = _d15_kbo_get1b(term)
    if term == _d15_kbo_lhs1(left1, right1):
        return right1
    return term


def _d15_kbo_core_op(left, right):
    return _d15_kbo_root(_d15_kbo_p(left, right))


def _d15_kbo_opposite(left, right):
    return _d15_kbo_core_op(right, left)


def _d15_kbo_eval(term, values):
    if type(term) is int:
        return values[term]
    return _d15_kbo_opposite(
        _d15_kbo_eval(term[0], values),
        _d15_kbo_eval(term[1], values),
    )


def _d15_kbo_literal(value):
    if value[0] == "e":
        return "CM.e"
    return (
        f"(CM.p {_d15_kbo_literal(value[1])} "
        f"{_d15_kbo_literal(value[2])})"
    )


def _d15_kbo_lean_term(term, values):
    if type(term) is int:
        return _d15_kbo_literal(values[term])
    left = _d15_kbo_lean_term(term[0], values)
    right = _d15_kbo_lean_term(term[1], values)
    return f"(CM.op {right} {left})"


def _d15_kbo_candidate(parsed_source, parsed_target):
    source_pattern = _source_pattern(parsed_source)
    source_route = _D15_KBO_SOURCE_ROUTES.get(source_pattern)
    if source_route is None:
        return None
    source_proof, source_branch = source_route
    variables, left, right = parsed_target
    if not 1 <= len(variables) <= 6:
        return None
    for values in product(_D15_KBO_WITNESS_POOL, repeat=len(variables)):
        if _d15_kbo_eval(left, values) == _d15_kbo_eval(right, values):
            continue
        applications = " ".join(_d15_kbo_literal(value) for value in values)
        closed_left = _d15_kbo_lean_term(left, values)
        closed_right = _d15_kbo_lean_term(right, values)
        target_branch = (
            "  · intro target\n"
            f"    have bad := target {applications}\n"
            f"    change {closed_left} = {closed_right} at bad\n"
            f"    exact (show Not ({closed_left} = {closed_right}) "
            "from by decide) bad\n"
        )
        submission = (
            "end CM\n\n"
            "end submission\n\n"
            "open submission\n\n"
            "def submission.d15OppositeMagmaKBO : Magma CM where\n"
            "  op a b := CM.op b a\n\n"
            "def submission : Goal := by\n"
            "  refine ⟨CM, d15OppositeMagmaKBO, ?_, ?_⟩\n"
        )
        return (
            _D15_KBO_FAMILY,
            _D15_KBO_MODEL_CORE
            + source_proof
            + submission
            + source_branch
            + target_branch,
            "alpha_exact_source_law_and_singleton_target_ast_witness",
        )
    return None



_D15_NF_FAMILY = "d15_normal_form_normalization_transfer"
_D15_NF_MODEL_CORE = 'import JudgeProblem\n\nset_option maxRecDepth 100000\n\nnamespace submission\n\ninductive Raw where\n  | e : Raw\n  | p : Raw → Raw → Raw\nderiving DecidableEq\n\nnamespace Raw\n\ndef sq (a : Raw) : Raw := p a a\ndef q (a b : Raw) : Raw := p (sq a) b\n\ndef nodes : Raw → Nat\n  | e => 0\n  | p a b => nodes a + nodes b + 1\n\ntheorem nodes_lt_p_left (a b : Raw) : nodes a < nodes (p a b) := by\n  simp [nodes] <;> omega\n\ntheorem nodes_lt_p_right (a b : Raw) : nodes b < nodes (p a b) := by\n  simp [nodes] <;> omega\n\ndef try0 : Raw → Option Raw\n  | p (p (p y₁ y₂) x₁) (p x₂ _) =>\n      if y₁ = y₂ ∧ x₁ = x₂ then some x₁ else none\n  | _ => none\n\ndef try1 : Raw → Option Raw\n  | p (p (p y₁ y₂) (p (p a₁ a₂) x₁)) x₂ =>\n      if y₁ = y₂ ∧ a₁ = a₂ ∧ x₁ = x₂\n      then some (q a₁ x₁) else none\n  | _ => none\n\ndef try2 : Raw → Option Raw\n  | p (p y₁ y₂) (p (p (p v₁ v₂) x) _) =>\n      if y₁ = y₂ ∧ v₁ = v₂ ∧ y₁ = v₁\n      then some (q y₁ x) else none\n  | _ => none\n\ndef try3 : Raw → Option Raw\n  | p (p (p y₁ y₂) x₁)\n      (p (p (p (p v₁ v₂) x₂) a) _) =>\n      if y₁ = y₂ ∧ v₁ = v₂ ∧ y₁ = v₁ ∧ x₁ = x₂\n      then some (p (q y₁ x₁) a) else none\n  | _ => none\n\ndef lhs0 (y x a : Raw) : Raw := p (q y x) (p x a)\ndef lhs1 (y a x : Raw) : Raw := p (q y (q a x)) x\ndef lhs2 (y x b : Raw) : Raw := p (sq y) (p (q y x) b)\ndef lhs3 (y x a b : Raw) : Raw :=\n  p (q y x) (p (p (q y x) a) b)\n\ntheorem try0_sound {t u : Raw} (h : try0 t = some u) :\n    ∃ y x a, t = lhs0 y x a ∧ u = x := by\n  cases t with\n  | e => simp [try0] at h\n  | p l r =>\n    cases l with\n    | e => simp [try0] at h\n    | p ll x =>\n      cases ll with\n      | e => simp [try0] at h\n      | p y₁ y₂ =>\n        cases r with\n        | e => simp [try0] at h\n        | p x₂ a =>\n          by_cases hc : y₁ = y₂ ∧ x = x₂\n          · rw [try0, if_pos hc] at h\n            have hu : x = u := Option.some.inj h\n            exact ⟨y₁, x, a, by simp [lhs0, q, sq, hc], hu.symm⟩\n          · simp [try0, hc] at h\n\ntheorem try1_sound {t u : Raw} (h : try1 t = some u) :\n    ∃ y a x, t = lhs1 y a x ∧ u = q a x := by\n  cases t with\n  | e => simp [try1] at h\n  | p l x₂ =>\n    cases l with\n    | e => simp [try1] at h\n    | p ll ar =>\n      cases ll with\n      | e => simp [try1] at h\n      | p y₁ y₂ =>\n        cases ar with\n        | e => simp [try1] at h\n        | p aar x₁ =>\n          cases aar with\n          | e => simp [try1] at h\n          | p a₁ a₂ =>\n            by_cases hc : y₁ = y₂ ∧ a₁ = a₂ ∧ x₁ = x₂\n            · rw [try1, if_pos hc] at h\n              have hu : q a₁ x₁ = u := Option.some.inj h\n              exact ⟨y₁, a₁, x₁,\n                by simp [lhs1, q, sq, hc], hu.symm⟩\n            · simp [try1, hc] at h\n\ntheorem try2_sound {t u : Raw} (h : try2 t = some u) :\n    ∃ y x b, t = lhs2 y x b ∧ u = q y x := by\n  cases t with\n  | e => simp [try2] at h\n  | p l r =>\n    cases l with\n    | e => simp [try2] at h\n    | p y₁ y₂ =>\n      cases r with\n      | e => simp [try2] at h\n      | p rl b =>\n        cases rl with\n        | e => simp [try2] at h\n        | p rll x =>\n          cases rll with\n          | e => simp [try2] at h\n          | p v₁ v₂ =>\n            by_cases hc : y₁ = y₂ ∧ v₁ = v₂ ∧ y₁ = v₁\n            · rw [try2, if_pos hc] at h\n              have hu : q y₁ x = u := Option.some.inj h\n              have hv₂y₂ : v₂ = y₂ :=\n                hc.2.1.symm.trans (hc.2.2.symm.trans hc.1)\n              exact ⟨y₁, x, b,\n                by simp [lhs2, q, sq, hc, hv₂y₂], hu.symm⟩\n            · simp [try2, hc] at h\n\ntheorem try3_sound {t u : Raw} (h : try3 t = some u) :\n    ∃ y x a b, t = lhs3 y x a b ∧ u = p (q y x) a := by\n  cases t with\n  | e => simp [try3] at h\n  | p l r =>\n    cases l with\n    | e => simp [try3] at h\n    | p ll x₁ =>\n      cases ll with\n      | e => simp [try3] at h\n      | p y₁ y₂ =>\n        cases r with\n        | e => simp [try3] at h\n        | p rl b =>\n          cases rl with\n          | e => simp [try3] at h\n          | p rll a =>\n            cases rll with\n            | e => simp [try3] at h\n            | p rlll x₂ =>\n              cases rlll with\n              | e => simp [try3] at h\n              | p v₁ v₂ =>\n                by_cases hc :\n                    y₁ = y₂ ∧ v₁ = v₂ ∧ y₁ = v₁ ∧ x₁ = x₂\n                · rw [try3, if_pos hc] at h\n                  have hu : p (q y₁ x₁) a = u :=\n                    Option.some.inj h\n                  have hv₂y₂ : v₂ = y₂ :=\n                    hc.2.1.symm.trans (hc.2.2.1.symm.trans hc.1)\n                  exact ⟨y₁, x₁, a, b,\n                    by simp [lhs3, q, sq, hc, hv₂y₂], hu.symm⟩\n                · simp [try3, hc] at h\n\ndef root (t : Raw) : Option Raw :=\n  match try0 t with\n  | some u => some u\n  | none =>\n    match try1 t with\n    | some u => some u\n    | none =>\n      match try2 t with\n      | some u => some u\n      | none => try3 t\n\ndef rawOp (a b : Raw) : Raw :=\n  (root (p a b)).getD (p a b)\n\ninductive Step : Raw → Raw → Prop where\n  | rule0 (y x a) : Step (lhs0 y x a) x\n  | rule1 (y a x) (miss0 : try0 (lhs1 y a x) = none) :\n      Step (lhs1 y a x) (q a x)\n  | rule2 (y x b) (miss0 : try0 (lhs2 y x b) = none)\n      (miss1 : try1 (lhs2 y x b) = none) :\n      Step (lhs2 y x b) (q y x)\n  | rule3 (y x a b) (miss0 : try0 (lhs3 y x a b) = none)\n      (miss1 : try1 (lhs3 y x a b) = none)\n      (miss2 : try2 (lhs3 y x a b) = none) :\n      Step (lhs3 y x a b) (p (q y x) a)\n  | raw (t) (miss0 : try0 t = none) (miss1 : try1 t = none)\n      (miss2 : try2 t = none) (miss3 : try3 t = none) : Step t t\n\ndef StepCases (t u : Raw) : Prop :=\n  (∃ y x a, t = lhs0 y x a ∧ u = x) ∨\n  (∃ y a x, t = lhs1 y a x ∧ u = q a x ∧\n    try0 t = none) ∨\n  (∃ y x b, t = lhs2 y x b ∧ u = q y x ∧\n    try0 t = none ∧ try1 t = none) ∨\n  (∃ y x a b, t = lhs3 y x a b ∧ u = p (q y x) a ∧\n    try0 t = none ∧ try1 t = none ∧ try2 t = none) ∨\n  (t = u ∧ try0 t = none ∧ try1 t = none ∧\n    try2 t = none ∧ try3 t = none)\n\ntheorem step_cases {t u : Raw} (h : Step t u) : StepCases t u := by\n  cases h with\n  | rule0 y x a =>\n    exact Or.inl ⟨y, _, a, rfl, rfl⟩\n  | rule1 y a x m0 =>\n    exact Or.inr (Or.inl ⟨y, a, x, rfl, rfl, m0⟩)\n  | rule2 y x b m0 m1 =>\n    exact Or.inr (Or.inr (Or.inl\n      ⟨y, x, b, rfl, rfl, m0, m1⟩))\n  | rule3 y x a b m0 m1 m2 =>\n    exact Or.inr (Or.inr (Or.inr (Or.inl\n      ⟨y, x, a, b, rfl, rfl, m0, m1, m2⟩)))\n  | raw t m0 m1 m2 m3 =>\n    exact Or.inr (Or.inr (Or.inr (Or.inr\n      ⟨rfl, m0, m1, m2, m3⟩)))\n\ntheorem rawOp_step (a b : Raw) : Step (p a b) (rawOp a b) := by\n  unfold rawOp root\n  cases h0 : try0 (p a b) with\n  | some u =>\n    obtain ⟨y, x, c, ht, hu⟩ := try0_sound h0\n    have hs : Step (p a b) u := by\n      rw [ht, hu]\n      exact Step.rule0 y x c\n    simpa [h0] using hs\n  | none =>\n    cases h1 : try1 (p a b) with\n    | some u =>\n      obtain ⟨y, c, x, ht, hu⟩ := try1_sound h1\n      have m0 : try0 (lhs1 y c x) = none := by\n        rw [← ht]\n        exact h0\n      have hs : Step (p a b) u := by\n        rw [ht, hu]\n        exact Step.rule1 y c x m0\n      simpa [h0, h1] using hs\n    | none =>\n      cases h2 : try2 (p a b) with\n      | some u =>\n        obtain ⟨y, x, c, ht, hu⟩ := try2_sound h2\n        have m0 : try0 (lhs2 y x c) = none := by\n          rw [← ht]\n          exact h0\n        have m1 : try1 (lhs2 y x c) = none := by\n          rw [← ht]\n          exact h1\n        have hs : Step (p a b) u := by\n          rw [ht, hu]\n          exact Step.rule2 y x c m0 m1\n        simpa [h0, h1, h2] using hs\n      | none =>\n        cases h3 : try3 (p a b) with\n        | some u =>\n          obtain ⟨y, x, c, d, ht, hu⟩ := try3_sound h3\n          have m0 : try0 (lhs3 y x c d) = none := by\n            rw [← ht]\n            exact h0\n          have m1 : try1 (lhs3 y x c d) = none := by\n            rw [← ht]\n            exact h1\n          have m2 : try2 (lhs3 y x c d) = none := by\n            rw [← ht]\n            exact h2\n          have hs : Step (p a b) u := by\n            rw [ht, hu]\n            exact Step.rule3 y x c d m0 m1 m2\n          simpa [h0, h1, h2, h3] using hs\n        | none =>\n          simpa [h0, h1, h2, h3] using\n            Step.raw (p a b) h0 h1 h2 h3\n\ndef NF : Raw → Prop\n  | e => True\n  | p a b => NF a ∧ NF b ∧ root (p a b) = none\n\ntheorem try0_nf {a b u : Raw} (ha : NF a)\n    (h : try0 (p a b) = some u) : NF u := by\n  cases a with\n  | e => simp [try0] at h\n  | p al ar =>\n    cases al with\n    | e => simp [try0] at h\n    | p y₁ y₂ =>\n      cases b with\n      | e => simp [try0] at h\n      | p x₂ tail =>\n        by_cases hc : y₁ = y₂ ∧ ar = x₂\n        · simp [try0, hc] at h\n          subst u\n          simpa [hc.2] using ha.2.1\n        · simp [try0, hc] at h\n\ntheorem try1_nf {a b u : Raw} (ha : NF a)\n    (h : try1 (p a b) = some u) : NF u := by\n  cases a with\n  | e => simp [try1] at h\n  | p al ar =>\n    cases al with\n    | e => simp [try1] at h\n    | p y₁ y₂ =>\n      cases ar with\n      | e => simp [try1] at h\n      | p aar x₁ =>\n        cases aar with\n        | e => simp [try1] at h\n        | p a₁ a₂ =>\n          by_cases hc : y₁ = y₂ ∧ a₁ = a₂ ∧ x₁ = b\n          · simp [try1, hc] at h\n            subst u\n            rcases hc with ⟨rfl, rfl, rfl⟩\n            simpa [q, sq] using ha.2.1\n          · simp [try1, hc] at h\n\ntheorem try2_nf {a b u : Raw} (hb : NF b)\n    (h : try2 (p a b) = some u) : NF u := by\n  cases a with\n  | e => simp [try2] at h\n  | p y₁ y₂ =>\n    cases b with\n    | e => simp [try2] at h\n    | p bl tail =>\n      cases bl with\n      | e => simp [try2] at h\n      | p bll x =>\n        cases bll with\n        | e => simp [try2] at h\n        | p v₁ v₂ =>\n          by_cases hc : y₁ = y₂ ∧ v₁ = v₂ ∧ y₁ = v₁\n          · simp [try2, hc] at h\n            rcases h with ⟨hyv, rfl⟩\n            rcases hc with ⟨_, hv, _⟩\n            simpa [q, sq, hyv, hv] using hb.1\n          · simp [try2, hc] at h\n\ntheorem try3_nf {a b u : Raw} (hb : NF b)\n    (h : try3 (p a b) = some u) : NF u := by\n  cases a with\n  | e => simp [try3] at h\n  | p al x₁ =>\n    cases al with\n    | e => simp [try3] at h\n    | p y₁ y₂ =>\n      cases b with\n      | e => simp [try3] at h\n      | p bl tail =>\n        cases bl with\n        | e => simp [try3] at h\n        | p bll aa =>\n          cases bll with\n          | e => simp [try3] at h\n          | p blll x₂ =>\n            cases blll with\n            | e => simp [try3] at h\n            | p v₁ v₂ =>\n              by_cases hc :\n                  y₁ = y₂ ∧ v₁ = v₂ ∧ y₁ = v₁ ∧ x₁ = x₂\n              · simp [try3, hc] at h\n                rcases h with ⟨hyv, rfl⟩\n                rcases hc with ⟨_, hv, _, _⟩\n                simpa [q, sq, hyv, hv] using hb.1\n              · simp [try3, hc] at h\n\ntheorem root_nf {a b u : Raw} (ha : NF a) (hb : NF b)\n    (h : root (p a b) = some u) : NF u := by\n  unfold root at h\n  split at h\n  · simp_all only [Option.some.injEq]\n    exact try0_nf ha ‹try0 (p a b) = some u›\n  · split at h\n    · simp_all only [Option.some.injEq]\n      exact try1_nf ha ‹try1 (p a b) = some u›\n    · split at h\n      · simp_all only [Option.some.injEq]\n        exact try2_nf hb ‹try2 (p a b) = some u›\n      · exact try3_nf hb h\n\ntheorem rawOp_nf {a b : Raw} (ha : NF a) (hb : NF b) :\n    NF (rawOp a b) := by\n  unfold rawOp\n  cases h : root (p a b) with\n  | none => simp [NF, ha, hb, h]\n  | some u => simpa [h] using root_nf ha hb h\n\ndef Carrier := {t : Raw // NF t}\n\ndef op (a b : Carrier) : Carrier :=\n  ⟨rawOp a.1 b.1, rawOp_nf a.2 b.2⟩\n\ninstance instMagma : Magma Carrier where\n  op := op\n\ntheorem lhs2_not_nf (y x b : Raw) : ¬ NF (lhs2 y x b) := by\n  intro hnf\n  have hr : root (lhs2 y x b) = none := hnf.2.2\n  unfold root at hr\n  cases h0 : try0 (lhs2 y x b) with\n  | some u => simp [h0] at hr\n  | none =>\n    cases h1 : try1 (lhs2 y x b) with\n    | some u => simp [h0, h1] at hr\n    | none =>\n      have h2 : try2 (lhs2 y x b) = some (q y x) := by\n        simp [try2, lhs2, q, sq]\n      simp [h0, h1, h2] at hr\n\ntheorem step_self_square {y yy : Raw} (h : Step (p y y) yy) :\n    ∃ k, yy = sq k := by\n  have c := step_cases h\n  clear h\n  rcases c with c0 | c1 | c2 | c3 | c4\n  · rcases c0 with ⟨a, x, b, ht, hu⟩\n    refine ⟨a, ?_⟩\n    grind [lhs0, q, sq]\n  · rcases c1 with ⟨a, b, x, ht, hu, hm0⟩\n    exfalso\n    grind [lhs1, q, sq, nodes_lt_p_left, nodes_lt_p_right]\n  · rcases c2 with ⟨a, x, b, ht, hu, hm0, hm1⟩\n    exfalso\n    grind [lhs2, q, sq, nodes_lt_p_left, nodes_lt_p_right]\n  · rcases c3 with ⟨a, x, b, d, ht, hu, hm0, hm1, hm2⟩\n    exfalso\n    grind [lhs3, q, sq, nodes_lt_p_left, nodes_lt_p_right]\n  · rcases c4 with ⟨ht, hm0, hm1, hm2, hm3⟩\n    exact ⟨y, by simpa [sq] using ht.symm⟩\n\n'
_D15_NF_SOURCE_ROUTES = {'[0,["op",["op",["op",1,1],0],["op",0,2]]]': ('theorem step_source_kernel\n    {k x zw yx xzw out : Raw}\n    (hx : NF x) (hkk_nf : NF (sq k))\n    (hyx_nf : NF yx) (hzw_nf : NF zw) (hxzw_nf : NF xzw)\n    (hyx : Step (p (sq k) x) yx)\n    (hxzw : Step (p x zw) xzw)\n    (hout : Step (p yx xzw) out) :\n    out = x := by\n  have cyx := step_cases hyx\n  have cxzw := step_cases hxzw\n  have cout := step_cases hout\n  clear hyx hxzw hout\n  rcases cout with c0 | c1 | c2 | c3 | c4\n  · rcases c0 with ⟨yo, xo, ao, hto, huo⟩\n    grind (config := { splits := 12, gen := 10 })\n      [StepCases, NF, root, try0, try1, try2, try3, lhs0, lhs1,\n        lhs2, lhs3, q, sq, lhs2_not_nf,\n        nodes_lt_p_left, nodes_lt_p_right]\n  · rcases c1 with ⟨yo, ao, xo, hto, huo, hm0o⟩\n    grind (config := { splits := 12, gen := 10 })\n      [StepCases, NF, root, try0, try1, try2, try3, lhs0, lhs1,\n        lhs2, lhs3, q, sq, lhs2_not_nf,\n        nodes_lt_p_left, nodes_lt_p_right]\n  · rcases c2 with ⟨yo, xo, bo, hto, huo, hm0o, hm1o⟩\n    grind (config := { splits := 12, gen := 10 })\n      [StepCases, NF, root, try0, try1, try2, try3, lhs0, lhs1,\n        lhs2, lhs3, q, sq, lhs2_not_nf,\n        nodes_lt_p_left, nodes_lt_p_right]\n  · rcases c3 with ⟨yo, xo, ao, bo, hto, huo, hm0o, hm1o, hm2o⟩\n    grind (config := { splits := 12, gen := 10 })\n      [StepCases, NF, root, try0, try1, try2, try3, lhs0, lhs1,\n        lhs2, lhs3, q, sq, lhs2_not_nf,\n        nodes_lt_p_left, nodes_lt_p_right]\n  · rcases c4 with ⟨hto, hm0o, hm1o, hm2o, hm3o⟩\n    grind (config := { splits := 12, gen := 10 })\n      [StepCases, NF, root, try0, try1, try2, try3, lhs0, lhs1,\n        lhs2, lhs3, q, sq, lhs2_not_nf,\n        nodes_lt_p_left, nodes_lt_p_right]\n\ntheorem step_source_nf\n    {x y z w yy yx zw xzw out : Raw}\n    (hx : NF x) (hy : NF y) (hz : NF z) (hw : NF w)\n    (hyy_nf : NF yy) (hyx_nf : NF yx)\n    (hzw_nf : NF zw) (hxzw_nf : NF xzw)\n    (hyy : Step (p y y) yy)\n    (hyx : Step (p yy x) yx)\n    (hzw : Step (p z w) zw)\n    (hxzw : Step (p x zw) xzw)\n    (hout : Step (p yx xzw) out) :\n    out = x := by\n  obtain ⟨k, hsq⟩ := step_self_square hyy\n  subst yy\n  exact step_source_kernel hx hyy_nf hyx_nf hzw_nf hxzw_nf\n    hyx hxzw hout\n\ntheorem source_raw (x y z w : Raw)\n    (hx : NF x) (hy : NF y) (hz : NF z) (hw : NF w) :\n    rawOp (rawOp (rawOp y y) x) (rawOp x (rawOp z w)) = x := by\n  apply step_source_nf hx hy hz hw\n  · exact rawOp_nf hy hy\n  · exact rawOp_nf (rawOp_nf hy hy) hx\n  · exact rawOp_nf hz hw\n  · exact rawOp_nf hx (rawOp_nf hz hw)\n  · exact rawOp_step y y\n  · exact rawOp_step (rawOp y y) x\n  · exact rawOp_step z w\n  · exact rawOp_step x (rawOp z w)\n  · exact rawOp_step (rawOp (rawOp y y) x) (rawOp x (rawOp z w))\n\ntheorem source_holds (x y z w : Carrier) :\n    x = op (op (op y y) x) (op x (op z w)) := by\n  apply Subtype.ext\n  exact (source_raw x.1 y.1 z.1 w.1 x.2 y.2 z.2 w.2).symm\n\n\ntheorem source_raw_general (x y z : Raw)\n    (hx : NF x) (hy : NF y) (hz : NF z) :\n    rawOp (rawOp (rawOp y y) x) (rawOp x z) = x := by\n  have hyy := rawOp_step y y\n  obtain ⟨k, hk⟩ := step_self_square hyy\n  apply step_source_kernel (k := k) hx\n  · rw [← hk]\n    exact rawOp_nf hy hy\n  · exact rawOp_nf (rawOp_nf hy hy) hx\n  · exact hz\n  · exact rawOp_nf hx hz\n  · rw [← hk]\n    exact rawOp_step (rawOp y y) x\n  · exact rawOp_step x z\n  · exact rawOp_step (rawOp (rawOp y y) x) (rawOp x z)\n\ntheorem source_holds_general (x y z : Carrier) :\n    x = op (op (op y y) x) (op x z) := by\n  apply Subtype.ext\n  exact (source_raw_general x.1 y.1 z.1 x.2 y.2 z.2).symm\n', '  · intro x y z\n    exact Raw.source_holds_general x y z\n')}
_D15_NF_WITNESS_POOL = (("e",),)


def _d15_nf_p(left, right):
    return ("p", left, right)


def _d15_nf_sq(value):
    return _d15_nf_p(value, value)


def _d15_nf_q(left, right):
    return _d15_nf_p(_d15_nf_sq(left), right)


def _d15_nf_try0(term):
    if (
        term[0] == "p"
        and term[1][0] == "p"
        and term[1][1][0] == "p"
        and term[2][0] == "p"
    ):
        y1, y2 = term[1][1][1], term[1][1][2]
        x1, x2 = term[1][2], term[2][1]
        if y1 == y2 and x1 == x2:
            return x1
    return None


def _d15_nf_try1(term):
    if (
        term[0] == "p"
        and term[1][0] == "p"
        and term[1][1][0] == "p"
        and term[1][2][0] == "p"
        and term[1][2][1][0] == "p"
    ):
        y1, y2 = term[1][1][1], term[1][1][2]
        a1, a2 = term[1][2][1][1], term[1][2][1][2]
        x1, x2 = term[1][2][2], term[2]
        if y1 == y2 and a1 == a2 and x1 == x2:
            return _d15_nf_q(a1, x1)
    return None


def _d15_nf_try2(term):
    if (
        term[0] == "p"
        and term[1][0] == "p"
        and term[2][0] == "p"
        and term[2][1][0] == "p"
        and term[2][1][1][0] == "p"
    ):
        y1, y2 = term[1][1], term[1][2]
        v1, v2 = term[2][1][1][1], term[2][1][1][2]
        x = term[2][1][2]
        if y1 == y2 and v1 == v2 and y1 == v1:
            return _d15_nf_q(y1, x)
    return None


def _d15_nf_try3(term):
    if (
        term[0] == "p"
        and term[1][0] == "p"
        and term[1][1][0] == "p"
        and term[2][0] == "p"
        and term[2][1][0] == "p"
        and term[2][1][1][0] == "p"
        and term[2][1][1][1][0] == "p"
    ):
        y1, y2 = term[1][1][1], term[1][1][2]
        x1 = term[1][2]
        v1, v2 = term[2][1][1][1][1], term[2][1][1][1][2]
        x2, middle = term[2][1][1][2], term[2][1][2]
        if y1 == y2 and v1 == v2 and y1 == v1 and x1 == x2:
            return _d15_nf_p(_d15_nf_q(y1, x1), middle)
    return None


def _d15_nf_op(left, right):
    raw = _d15_nf_p(left, right)
    for attempt in (_d15_nf_try0, _d15_nf_try1, _d15_nf_try2, _d15_nf_try3):
        reduced = attempt(raw)
        if reduced is not None:
            return reduced
    return raw


def _d15_nf_eval(term, values):
    if type(term) is int:
        return values[term]
    return _d15_nf_op(
        _d15_nf_eval(term[0], values),
        _d15_nf_eval(term[1], values),
    )


def _d15_nf_raw_literal(value):
    if value[0] == "e":
        return "Raw.e"
    return (
        f"(Raw.p {_d15_nf_raw_literal(value[1])} "
        f"{_d15_nf_raw_literal(value[2])})"
    )


def _d15_nf_candidate(parsed_source, parsed_target):
    source_pattern = _source_pattern(parsed_source)
    source_route = _D15_NF_SOURCE_ROUTES.get(source_pattern)
    if source_route is None:
        return None
    source_proof, source_branch = source_route
    variables, left, right = parsed_target
    if not 1 <= len(variables) <= 6:
        return None
    for values in product(_D15_NF_WITNESS_POOL, repeat=len(variables)):
        left_value = _d15_nf_eval(left, values)
        right_value = _d15_nf_eval(right, values)
        if left_value == right_value:
            continue
        applications = " ".join("E" for _ in values)
        closed_left = _d15_nf_raw_literal(left_value)
        closed_right = _d15_nf_raw_literal(right_value)
        target_branch = (
            "  · intro target\n"
            "    let E : Raw.Carrier := ⟨Raw.e, True.intro⟩\n"
            f"    have bad := target {applications}\n"
            "    have badv := congrArg Subtype.val bad\n"
            f"    change {closed_left} = {closed_right} at badv\n"
            f"    exact (show Not ({closed_left} = {closed_right}) "
            "from by decide) badv\n"
        )
        submission = (
            "end Raw\n\n"
            "end submission\n\n"
            "open submission\n\n"
            "def submission : Goal := by\n"
            "  refine ⟨Raw.Carrier, Raw.instMagma, ?_, ?_⟩\n"
        )
        return (
            _D15_NF_FAMILY,
            _D15_NF_MODEL_CORE
            + source_proof
            + submission
            + source_branch
            + target_branch,
            "alpha_exact_source_law_and_singleton_target_ast_witness",
        )
    return None


def _infinite_candidate(parsed_source, parsed_target):
    d15_candidate = _d15_exp5_candidate(parsed_source, parsed_target)
    if d15_candidate is not None:
        return d15_candidate
    d15_candidate = _d15_accepted_cm_candidate(parsed_source, parsed_target)
    if d15_candidate is not None:
        return d15_candidate
    d15_candidate = _d15_pattern_cm_candidate(parsed_source, parsed_target)
    if d15_candidate is not None:
        return d15_candidate
    d15_candidate = _d15_kbo_candidate(parsed_source, parsed_target)
    if d15_candidate is not None:
        return d15_candidate
    d15_candidate = _d15_nf_candidate(parsed_source, parsed_target)
    if d15_candidate is not None:
        return d15_candidate
    incoming_pattern = _source_pattern(parsed_source)
    marker = "  -- __D10_TARGET_AST_SYMBOLIC_BRANCH__"
    matches = []
    for row in _infinite_rules():
        source_pattern = row[1]
        substitution = _source_schema_match(source_pattern, parsed_source)
        if substitution is None:
            continue
        exact_source = source_pattern == incoming_pattern
        matches.append((not exact_source, len(row[-1]), row, substitution))
    for _nonexact, _template_bytes, row, substitution in sorted(
        matches, key=lambda item: (item[0], item[1], item[2][0], item[2][1])
    ):
        family, source_pattern, witness_vectors, carrier_type, magma_instance, project_subtype_value, _constructive_model, target_simp_lemmas, target_eval_function, target_eval_opposite, target_stepwise_raw, code_template = row
        exact_source = source_pattern == incoming_pattern
        exact_arity_vectors = tuple(
            tuple(vector) for vector in witness_vectors
            if len(vector) == len(parsed_target[0])
        )
        if exact_source and exact_arity_vectors:
            witness_vectors = exact_arity_vectors
        else:
            witness_vectors = _expanded_witness_vectors(
                witness_vectors, len(parsed_target[0])
            )
        branch = _symbolic_target_branch(
            parsed_target,
            witness_vectors,
            carrier_type,
            magma_instance,
            project_subtype_value,
            target_simp_lemmas,
            target_eval_function,
            target_eval_opposite,
            target_stepwise_raw,
        )
        if branch is None or code_template.count(marker) != 1:
            continue
        template = code_template
        if not exact_source:
            template = _rewrite_source_branch(
                template, parsed_source, substitution, marker
            )
            if template is None:
                continue
        if ("theorem family_submission" in template or
                "-- d14-direct-template" in template):
            code = template.replace(marker, branch)
        else:
            helper_scope = carrier_type
            local_witness_lets = tuple(dict.fromkeys(
                match.group(0).strip()
                for vector in witness_vectors
                for value in vector
                if re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", value)
                for match in [re.search(
                    rf"^[ \t]*let[ \t]+{re.escape(value)}[ \t]*:[^\n]+$",
                    template,
                    re.MULTILINE,
                )]
                if match is not None
            ))
            branch_lines = branch.splitlines()
            if not branch_lines or branch_lines[0] != "  · intro target":
                continue
            helper_body = "\n".join(
                line[2:] if line.startswith("  ") else line
                for line in branch_lines[1:]
            )
            if local_witness_lets:
                helper_body = (
                    "\n".join(f"  {line}" for line in local_witness_lets)
                    + "\n"
                    + helper_body
                )
            helper = (
                f"namespace submission.{helper_scope}\n\n"
                f"theorem d10TargetRefutation\n"
                f"    (target : @EquationRHS {carrier_type} {magma_instance}) : False := by\n"
                f"{helper_body}\n\n"
                f"end submission.{helper_scope}\n\n"
            )
            final_submission = "def submission : Goal := by"
            if template.rfind(final_submission) < 0:
                continue
            simple_branch = (
                "  · intro target\n"
                f"    exact {helper_scope}.d10TargetRefutation target"
            )
            code = template.replace(marker, simple_branch)
            position = code.rfind(final_submission)
            code = code[:position] + helper + code[position:]
        return (
            family,
            code,
            "alpha_exact_source_law"
            if exact_source
            else "uniform_term_substitution_source_schema",
        )
    return None


def _staged_certificate(stage, code):
    """Return the exact Judge payload and its UTF-8 size, or fail closed."""

    staged = f"-- stage:{stage}\n" + code
    size = len(staged.encode("utf-8"))
    if size > MAX_FALSE_CERTIFICATE_BYTES:
        return None, size
    return staged, size


def _eval_term(term, values, table):
    if type(term) is int:
        return values[term]
    return table[_eval_term(term[0], values, table)][
        _eval_term(term[1], values, table)
    ]


def _equation_holds(parsed, table):
    variables, lhs, rhs = parsed
    checked = 0
    for values in product(range(len(table)), repeat=len(variables)):
        checked += 1
        left = _eval_term(lhs, values, table)
        right = _eval_term(rhs, values, table)
        if left != right:
            return False, checked, {
                "assignment": dict(zip(variables, values)),
                "lhs": left,
                "rhs": right,
            }
    return True, checked, None



ENGINE = "standalone-py-cdcl-cadical-scc-best-prefix"
SANDBOX_MIN_SIZE = 2
SANDBOX_MAX_SIZE = 9
MEMORY_LIMIT_MIB = 590
DECISION_REASON = -2147483648
NO_CONFLICT = -1
BINARY_CONFLICT = -2


class ParseError(ValueError):
    pass


class SearchTimeout(RuntimeError):
    pass


class Term:
    __slots__ = ("id", "key", "name", "left", "right", "variables")

    def __init__(self, ident, key, name=None, left=None, right=None, variables=()):
        self.id, self.key, self.name = ident, key, name
        self.left, self.right, self.variables = left, right, variables


class TermFactory:
    __slots__ = ("by_key", "next_id")

    def __init__(self):
        self.by_key, self.next_id = {}, 1

    def leaf(self, name):
        node = self.by_key.get(name)
        if node is None:
            node = Term(self.next_id, name, name=name, variables=(name,))
            self.next_id += 1
            self.by_key[name] = node
        return node

    def product(self, left, right):
        key = "(" + left.key + "*" + right.key + ")"
        node = self.by_key.get(key)
        if node is None:
            variables = tuple(sorted(set(left.variables + right.variables)))
            node = Term(self.next_id, key, left=left, right=right, variables=variables)
            self.next_id += 1
            self.by_key[key] = node
        return node


class TermParser:
    __slots__ = ("text", "factory", "pos")

    def __init__(self, text, factory):
        self.text, self.factory, self.pos = text, factory, 0

    def space(self):
        while self.pos < len(self.text) and self.text[self.pos].isspace():
            self.pos += 1

    def parse(self):
        term = self.expression()
        self.space()
        if self.pos != len(self.text):
            raise ParseError(f"unexpected input at {self.pos}")
        return term

    def expression(self):
        node = self.atom()
        while True:
            self.space()
            if self.pos >= len(self.text) or self.text[self.pos] not in ("*", "◇"):
                return node
            self.pos += 1
            node = self.factory.product(node, self.atom())

    def atom(self):
        self.space()
        if self.pos >= len(self.text):
            raise ParseError("unexpected end of term")
        if self.text[self.pos] == "(":
            self.pos += 1
            node = self.expression()
            self.space()
            if self.pos >= len(self.text) or self.text[self.pos] != ")":
                raise ParseError(f"missing ')' at {self.pos}")
            self.pos += 1
            return node
        start = self.pos
        if not (self.text[self.pos].isalpha() or self.text[self.pos] == "_"):
            raise ParseError(f"expected variable at {self.pos}")
        self.pos += 1
        while self.pos < len(self.text) and (self.text[self.pos].isalnum() or self.text[self.pos] == "_"):
            self.pos += 1
        return self.factory.leaf(self.text[start:self.pos])


def parse_equation(text, factory=None):
    factory = factory or TermFactory()
    parts = text.split("=")
    if len(parts) != 2:
        raise ParseError(f"expected one equality: {text}")
    return TermParser(parts[0], factory).parse(), TermParser(parts[1], factory).parse()


def lit_index(literal):
    return literal << 1 if literal > 0 else ((-literal) << 1) | 1


def index_literal(index):
    return -(index >> 1) if index & 1 else index >> 1


def binary_reason(false_literal):
    return -lit_index(false_literal) - 3


def reason_literal(reason):
    return index_literal(-reason - 3)


def luby(base, index):
    size, sequence = 1, 0
    while size < index + 1:
        size, sequence = 2 * size + 1, sequence + 1
    while size - 1 != index:
        size = (size - 1) >> 1
        sequence -= 1
        index %= size
    return base ** sequence


class CNF:
    __slots__ = (
        "next_var", "binary", "long_data", "long_meta", "units", "inconsistent",
        "binary_count", "long_count", "unit_count", "empty_count", "watches", "order", "lengths", "representative",
    )

    def __init__(self):
        self.next_var = 1
        self.binary, self.long_data, self.long_meta = array("i"), array("i"), array("I")
        self.watches = [None] * 8
        self.order = array("I")
        self.lengths = None
        self.representative = None
        self.units = array("i")
        self.inconsistent = False
        self.binary_count = self.long_count = self.unit_count = self.empty_count = 0

    @property
    def variable_count(self):
        return self.next_var - 1

    @property
    def clause_count(self):
        return self.binary_count + self.long_count + self.unit_count + self.empty_count

    def fresh_vector(self, size):
        start = self.next_var
        self.next_var += size
        needed = self.next_var * 2 + 4
        if len(self.watches) < needed:
            self.watches.extend([None] * (needed - len(self.watches)))
        return start

    def watch(self, literal):
        index = lit_index(literal)
        watched = self.watches[index]
        if watched is None:
            watched = array("I")
            self.watches[index] = watched
        return watched

    def remember(self, code):
        if self.order is not None:
            self.order.append(code)
            if not (len(self.order) & 16383) and 36 * len(self.long_data) + 80 * self.long_count + 72 * self.binary_count > 260 * (1 << 20):
                self.order = None
                self.binary = array("i")

    def add1(self, literal):
        self.remember(0x40000000 | self.unit_count)
        self.units.append(literal)
        self.unit_count += 1

    def add2(self, left, right):
        code = 0x80000000 | self.binary_count
        if self.order is not None:
            self.binary.extend((left, right))
        self.remember(code)
        self.watch(left).append(0x80000000 | lit_index(right))
        self.watch(right).append(0x80000000 | lit_index(left))
        self.binary_count += 1

    def add3(self, a, b, c):
        offset = len(self.long_data)
        self.remember(self.long_count)
        self.watch(a).append(self.long_count)
        self.watch(b).append(self.long_count)
        self.long_meta.append((offset << 4) | 3)
        self.long_data.extend((a, b, c))
        self.long_count += 1

    def add4(self, a, b, c, d):
        offset = len(self.long_data)
        self.remember(self.long_count)
        self.watch(a).append(self.long_count)
        self.watch(b).append(self.long_count)
        self.long_meta.append((offset << 4) | 4)
        self.long_data.extend((a, b, c, d))
        self.long_count += 1

    def add(self, literals):
        lits = tuple(literals)
        length = len(lits)
        if not length:
            self.remember(0xc0000000 | self.empty_count)
            self.inconsistent = True
            self.empty_count += 1
        elif length == 1:
            self.add1(lits[0])
        elif length == 2:
            self.add2(lits[0], lits[1])
        else:
            offset = len(self.long_data)
            if length > 15 or offset >= (1 << 28):
                raise MemoryError("original clause arena exceeds compact reference range")
            self.remember(self.long_count)
            self.watch(lits[0]).append(self.long_count)
            self.watch(lits[1]).append(self.long_count)
            self.long_meta.append((offset << 4) | length)
            self.long_data.extend(lits)
            self.long_count += 1

    def exactly_one(self, start, size):
        offset = len(self.long_data)
        self.remember(self.long_count)
        self.watch(start).append(self.long_count)
        self.watch(start + 1).append(self.long_count)
        self.long_meta.append((offset << 4) | size)
        self.long_data.extend(range(start, start + size))
        self.long_count += 1
        for i in range(size):
            for j in range(i + 1, size):
                self.add2(-(start + i), -(start + j))

    def make_legacy(self):
        old_binary, old_data, old_meta = self.binary, self.long_data, self.long_meta
        data, meta, lengths = [], [], []
        watches = [None] * len(self.watches)
        for cid, code in enumerate(self.order):
            kind = code >> 30
            if kind == 2:
                index = (code & 0x3fffffff) * 2
                literals = (old_binary[index], old_binary[index + 1])
            elif kind == 1:
                literals = (self.units[code & 0x3fffffff],)
            elif kind == 3:
                literals = ()
            else:
                packed = old_meta[code]
                offset, length = packed >> 4, packed & 15
                literals = old_data[offset:offset + length]
            offset = len(data)
            meta.append(offset)
            lengths.append(len(literals))
            data.extend(literals)
            if len(literals) >= 2:
                for literal in literals[:2]:
                    index = lit_index(literal)
                    if watches[index] is None:
                        watches[index] = []
                    watches[index].append(cid)
        self.binary, self.long_data, self.long_meta, self.watches, self.lengths = [], data, meta, watches, lengths
        self.long_count = len(meta)
        self.binary_count = self.unit_count = self.empty_count = 0
        self.order = None


def decompose_binary_scc(cnf, deadline):
    """CaDiCaL-style SCC equivalence decomposition of the binary implication graph."""
    if cnf.inconsistent:
        return cnf
    total = (cnf.variable_count + 1) * 2
    visited, order = bytearray(total), array("I")
    watches = cnf.watches
    for root in range(2, total):
        if visited[root]:
            continue
        stack = [root]
        while stack:
            node = stack.pop()
            if node < 0:
                order.append(~node)
                continue
            if visited[node]:
                continue
            visited[node] = 1
            stack.append(~node)
            literal = index_literal(node)
            outgoing = watches[lit_index(-literal)]
            if outgoing:
                for code in outgoing:
                    if code & 0x80000000:
                        other = code & 0x7fffffff
                        if not visited[other]:
                            stack.append(other)
        if not (root & 8191) and time.perf_counter() > deadline:
            raise SearchTimeout("binary decomposition timeout")
    component = array("i", [-1]) * total
    canonical = []
    for root in reversed(order):
        if component[root] >= 0:
            continue
        cid, best = len(canonical), 0
        component[root] = cid
        stack = [root]
        while stack:
            node = stack.pop()
            literal = index_literal(node)
            if not best or abs(literal) < abs(best):
                best = literal
            incoming = watches[node]
            if incoming:
                for code in incoming:
                    if code & 0x80000000:
                        predecessor = (code & 0x7fffffff) ^ 1
                        if component[predecessor] < 0:
                            component[predecessor] = cid
                            stack.append(predecessor)
        canonical.append(best)
    representative = array("i", [0]) * (cnf.variable_count + 1)
    for variable in range(1, cnf.variable_count + 1):
        positive, negative = lit_index(variable), lit_index(-variable)
        if component[positive] == component[negative]:
            result = CNF()
            result.next_var, result.watches, result.inconsistent = cnf.next_var, [None] * len(watches), True
            result.representative = representative
            return result
        representative[variable] = canonical[component[positive]]
    result = CNF()
    result.next_var, result.watches = cnf.next_var, [None] * len(watches)

    def mapped_clause(literals):
        mapped = []
        for literal in literals:
            rep = representative[abs(literal)]
            rep = rep if literal > 0 else -rep
            if -rep in mapped:
                return None
            if rep not in mapped:
                mapped.append(rep)
        return mapped

    for literal in cnf.units:
        clause = mapped_clause((literal,))
        if clause is not None:
            result.add(clause)
    for left_index in range(2, total):
        watched = watches[left_index]
        if not watched:
            continue
        for code in watched:
            if not code & 0x80000000:
                continue
            right_index = code & 0x7fffffff
            if left_index > right_index:
                continue
            clause = mapped_clause((index_literal(left_index), index_literal(right_index)))
            if clause is not None:
                result.add(clause)
    data, meta = cnf.long_data, cnf.long_meta
    for cid in range(cnf.long_count):
        packed = meta[cid]
        offset, length = packed >> 4, packed & 15
        clause = mapped_clause(data[offset:offset + length])
        if clause is not None:
            result.add(clause)
        if not (cid & 16383) and time.perf_counter() > deadline:
            raise SearchTimeout("binary decomposition rewrite timeout")
    result.representative = representative
    return result


class MagmaEncoder:
    __slots__ = (
        "size", "deadline", "fix_first_witness", "witness_pattern", "cnf",
        "decision_groups", "table", "structure", "ground_cache", "symbolic_cache",
        "witness", "grounding_count",
    )

    def __init__(self, size, deadline=math.inf, fix_first_witness=True,
                 structure="none", witness_pattern=None):
        self.size, self.deadline = size, deadline
        self.fix_first_witness, self.witness_pattern = fix_first_witness, witness_pattern
        self.cnf, self.decision_groups = CNF(), []
        self.table = [[0] * size for _ in range(size)]
        clone_first = size - 2 if structure == "idempotent-clone" else -1
        clone_second = size - 1 if structure == "idempotent-clone" else -1
        if structure == "idempotent-clone" and size < 4:
            raise ValueError("idempotent-clone needs size >= 4")
        for left in range(size):
            for right in range(size):
                shared = 0
                if structure == "idempotent-clone":
                    if left == clone_second and right != clone_second:
                        shared = self.table[clone_first][right]
                    elif right == clone_second and left != clone_second:
                        shared = self.table[left][clone_first]
                if shared:
                    self.table[left][right] = shared
                else:
                    start = self.cnf.fresh_vector(size)
                    self.table[left][right] = start
                    self.decision_groups.append(start)
                    self.cnf.exactly_one(start, size)
        if structure in ("idempotent", "idempotent-clone"):
            for value in range(size):
                self.cnf.add1(self.table[value][value] + value)
        self.structure = structure
        self.ground_cache, self.symbolic_cache, self.witness = {}, {}, {}
        self.grounding_count = 0

    def check_time(self):
        if time.perf_counter() > self.deadline:
            raise SearchTimeout("encoding timeout")

    def new_value(self):
        start = self.cnf.fresh_vector(self.size)
        self.cnf.exactly_one(start, self.size)
        return start

    def product(self, left, right):
        output = self.new_value()
        left_const, right_const = left < 0, right < 0
        same = not left_const and not right_const and left == right
        left_values = range(-left - 1, -left) if left_const else range(self.size)
        right_values = range(-right - 1, -right) if right_const else range(self.size)
        for a in left_values:
            for b in right_values:
                if same and a != b:
                    continue
                prefix = []
                if not left_const:
                    prefix.append(-(left + a))
                if not right_const and not (same and a == b):
                    prefix.append(-(right + b))
                cell = self.table[a][b]
                for c in range(self.size):
                    if len(prefix) == 2:
                        self.cnf.add4(prefix[0], prefix[1], -(cell + c), output + c)
                    elif prefix:
                        self.cnf.add3(prefix[0], -(cell + c), output + c)
                    else:
                        self.cnf.add2(-(cell + c), output + c)
        return output

    def ground(self, node, assignment):
        if node.name is not None:
            return -assignment[node.name] - 1
        key = (node.id,) + tuple(assignment[name] for name in node.variables)
        result = self.ground_cache.get(key)
        if result is None:
            left, right = self.ground(node.left, assignment), self.ground(node.right, assignment)
            if left < 0 and right < 0:
                result = self.table[-left - 1][-right - 1]
            else:
                result = self.product(left, right)
            self.ground_cache[key] = result
        return result

    def symbolic(self, node):
        if node.name is not None:
            return self.witness[node.name]
        result = self.symbolic_cache.get(node.id)
        if result is None:
            result = self.product(self.symbolic(node.left), self.symbolic(node.right))
            self.symbolic_cache[node.id] = result
        return result

    def equal(self, left, right):
        if left < 0 and right < 0:
            if left != right:
                self.cnf.add(())
        elif left < 0:
            self.cnf.add1(right - left - 1)
        elif right < 0:
            self.cnf.add1(left - right - 1)
        elif left != right:
            for value in range(self.size):
                self.cnf.add2(-(left + value), right + value)
                self.cnf.add2(-(right + value), left + value)

    def encode(self, premise, target):
        names = tuple(sorted(set(premise[0].variables + premise[1].variables)))
        assignment = {}

        def visit(index):
            if index < len(names):
                name = names[index]
                for value in range(self.size):
                    assignment[name] = value
                    visit(index + 1)
                return
            self.grounding_count += 1
            if not (self.grounding_count & 255):
                self.check_time()
            self.equal(self.ground(premise[0], assignment), self.ground(premise[1], assignment))

        visit(0)
        target_names = tuple(sorted(set(target[0].variables + target[1].variables)))
        for name in target_names:
            start = self.cnf.fresh_vector(self.size)
            self.cnf.exactly_one(start, self.size)
            self.decision_groups.append(start)
            self.witness[name] = start
        if self.witness_pattern is not None:
            if len(self.witness_pattern) != len(target_names):
                raise ValueError("wrong witness pattern length")
            for index, name in enumerate(target_names):
                value = self.witness_pattern[index]
                if value < 0 or value >= self.size:
                    raise ValueError("witness pattern outside domain")
                self.cnf.add1(self.witness[name] + value)
        if self.fix_first_witness:
            for index, name in enumerate(target_names):
                for value in range(index + 1, self.size):
                    self.cnf.add1(-(self.witness[name] + value))
        left, right = self.symbolic(target[0]), self.symbolic(target[1])
        for value in range(self.size):
            self.cnf.add2(-(left + value), -(right + value))
        self.check_time()

    def release_caches(self):
        self.ground_cache.clear()
        self.symbolic_cache.clear()


class VarHeap:
    __slots__ = ("activity", "allowed", "heap", "pos")

    def __init__(self, activity, allowed):
        self.activity, self.allowed = activity, allowed
        self.heap = [0] if isinstance(activity, list) else array("I", [0])
        self.pos = [0] * len(activity) if isinstance(activity, list) else array("I", [0]) * len(activity)
        for variable in range(1, len(activity)):
            if allowed[variable]:
                self.insert(variable)

    def better(self, left, right):
        delta = self.activity[left] - self.activity[right]
        return delta > 0 or (delta == 0 and left < right)

    def up(self, index):
        value = self.heap[index]
        while index > 1:
            parent = index >> 1
            if not self.better(value, self.heap[parent]):
                break
            self.heap[index] = self.heap[parent]
            self.pos[self.heap[index]] = index
            index = parent
        self.heap[index], self.pos[value] = value, index

    def down(self, index):
        value, length = self.heap[index], len(self.heap)
        while True:
            child = index << 1
            if child >= length:
                break
            if child + 1 < length and self.better(self.heap[child + 1], self.heap[child]):
                child += 1
            if not self.better(self.heap[child], value):
                break
            self.heap[index] = self.heap[child]
            self.pos[self.heap[index]] = index
            index = child
        self.heap[index], self.pos[value] = value, index

    def insert(self, variable):
        if not self.allowed[variable] or self.pos[variable]:
            return
        self.heap.append(variable)
        self.pos[variable] = len(self.heap) - 1
        self.up(len(self.heap) - 1)

    def remove(self, variable):
        index = self.pos[variable]
        if not index:
            return
        last = self.heap.pop()
        self.pos[variable] = 0
        if index < len(self.heap):
            self.heap[index], self.pos[last] = last, index
            if index > 1 and self.better(last, self.heap[index >> 1]):
                self.up(index)
            else:
                self.down(index)

    def update(self, variable):
        if self.pos[variable]:
            self.up(self.pos[variable])

    def pop(self):
        if len(self.heap) == 1:
            return 0
        result = self.heap[1]
        self.remove(result)
        return result


class CDCLSolver:
    __slots__ = (
        "cnf", "deadline", "nvars", "original_clauses", "original_long", "assigns",
        "level", "reason", "phase", "phase_mode", "seed", "decision_mask", "branch_mode",
        "restart_base", "restart_mode", "decision_groups", "group_of", "activity", "seen", "trail", "qhead",
        "trail_lim", "long_watches", "learnt_data",
        "learnt_meta", "learnt_deleted", "learnt_activity", "learnt_lbd", "learnt_watches",
        "var_inc", "clause_inc", "conflicts", "decisions", "propagations", "restarts",
        "aborted", "inconsistent", "heap", "initial_phase", "best_phase", "best_assigned", "best_prefix",
        "rephase_count", "next_rephase", "lbd_fast", "lbd_slow", "lbd_initialized",
        "next_restart", "binary_conflict_a", "binary_conflict_b", "active_learnts", "group_size", "compact",
    )

    def __init__(self, cnf, deadline=math.inf, options=None):
        options = options or {}
        self.cnf, self.deadline = cnf, deadline
        self.nvars = cnf.variable_count
        legacy_bytes = 36 * len(cnf.long_data) + 80 * cnf.long_count + 72 * cnf.binary_count
        self.compact = cnf.order is None or legacy_bytes > 260 * (1 << 20)
        if not self.compact:
            cnf.make_legacy()
        else:
            cnf.order = None
            cnf.binary = array("i")
        self.original_clauses, self.original_long = cnf.clause_count, cnf.long_count
        self.assigns = array("b", [0]) * (self.nvars + 1) if self.compact else [0] * (self.nvars + 1)
        self.level = array("I", [0]) * (self.nvars + 1) if self.compact else [0] * (self.nvars + 1)
        self.reason = array("i", [DECISION_REASON]) * (self.nvars + 1) if self.compact else [DECISION_REASON] * (self.nvars + 1)
        self.phase_mode, self.seed = options.get("phase", "negative"), int(options.get("seed", 1)) & 0xffffffff
        self.phase = array("b", [0]) * (self.nvars + 1) if self.compact else [0] * (self.nvars + 1)
        for variable in range(1, self.nvars + 1):
            if self.phase_mode == "positive":
                self.phase[variable] = 1
            elif self.phase_mode == "mixed":
                value = ((variable ^ self.seed ^ 0x9e3779b9) * 0x85ebca6b) & 0xffffffff
                self.phase[variable] = 1 if (value ^ (value >> 13)) & 1 else -1
            else:
                self.phase[variable] = -1
        self.decision_mask = bytearray(self.nvars + 1)
        self.decision_groups = options.get("decision_groups", [])
        group_size = self.group_size = int(options.get("group_size", 0))
        for start in self.decision_groups:
            self.decision_mask[start:start + group_size] = b"\1" * group_size
        if cnf.representative is not None:
            original_mask, self.decision_mask = self.decision_mask, bytearray(self.nvars + 1)
            for variable in range(1, self.nvars + 1):
                if original_mask[variable]:
                    self.decision_mask[abs(cnf.representative[variable])] = 1
        self.branch_mode = options.get("branch", "boolean")
        self.restart_base = int(options.get("restart_base", 2))
        self.restart_mode = options.get("restart_mode", "dynamic")
        self.group_of = None
        if self.branch_mode == "group":
            self.group_of = array("i", [-1]) * (self.nvars + 1) if self.compact else [-1] * (self.nvars + 1)
            for index, start in enumerate(self.decision_groups):
                for variable in range(start, start + group_size):
                    self.group_of[variable] = index
        self.activity = array("d", [0.0]) * (self.nvars + 1) if self.compact else [0.0] * (self.nvars + 1)
        self.seen = bytearray(self.nvars + 1)
        self.trail, self.trail_lim = (array("i"), array("I")) if self.compact else ([], [])
        self.qhead = 0
        self.long_watches = cnf.watches
        self.learnt_data, self.learnt_meta = (array("i"), array("Q")) if self.compact else ([], [])
        self.learnt_deleted = bytearray()
        self.learnt_activity = array("d") if self.compact else []
        self.learnt_lbd, self.learnt_watches = (array("I") if self.compact else []), {}
        self.var_inc, self.clause_inc = 1.0, 1.0
        self.conflicts = self.decisions = self.propagations = self.restarts = 0
        self.aborted, self.inconsistent = False, cnf.inconsistent
        self.binary_conflict_a = self.binary_conflict_b = 0
        self.active_learnts = 0
        self.initial_phase = self.phase[:]
        self.best_phase = array("b", [0]) * (self.nvars + 1) if self.compact else [0] * (self.nvars + 1)
        self.best_assigned, self.best_prefix, self.rephase_count, self.next_rephase = 0, 0, 0, 1000
        self.lbd_fast = self.lbd_slow = 0.0
        self.lbd_initialized, self.next_restart = False, self.restart_base
        self.initialize()

    @property
    def decision_level(self):
        return len(self.trail_lim)

    @property
    def clause_count(self):
        return self.original_clauses + self.active_learnts

    def value(self, literal):
        value = self.assigns[abs(literal)]
        return value if literal > 0 else -value

    def long_watch(self, literal):
        index = lit_index(literal)
        watched = self.long_watches[index]
        if watched is None:
            watched = array("I") if self.compact else []
            self.long_watches[index] = watched
        return watched

    def learnt_watch(self, literal):
        if not self.compact:
            return self.long_watch(literal)
        index = lit_index(literal)
        watched = self.learnt_watches.get(index)
        if watched is None:
            watched = array("I") if self.compact else []
            self.learnt_watches[index] = watched
        return watched

    def initialize(self):
        occurrence = array("I", [0]) * (self.nvars + 1) if self.compact else [0] * (self.nvars + 1)
        if self.compact:
            for index, watched in enumerate(self.cnf.watches):
                if watched:
                    occurrence[abs(index_literal(index))] += sum(1 for code in watched if code & 0x80000000)
        if self.compact:
            for literal in self.cnf.units:
                occurrence[abs(literal)] += 1
        data, meta = self.cnf.long_data, self.cnf.long_meta
        for cid in range(self.original_long):
            if self.compact:
                packed = meta[cid]
                offset, length = packed >> 4, packed & 15
            else:
                offset, length = meta[cid], self.cnf.lengths[cid]
            for pos in range(offset, offset + length):
                occurrence[abs(data[pos])] += 1
        maximum = max(1, max(occurrence, default=1))
        for variable in range(1, self.nvars + 1):
            noise = ((variable ^ self.seed) * 0x27d4eb2d) & 0xffffffff
            self.activity[variable] = occurrence[variable] / maximum + (noise ^ (noise >> 15)) / 0xffffffff * 1e-5
        del occurrence
        self.heap = VarHeap(self.activity, self.decision_mask)
        for literal in self.cnf.units:
            if not self.enqueue(literal, DECISION_REASON):
                self.inconsistent = True

    def enqueue(self, literal, reason):
        variable = abs(literal)
        current = self.assigns[variable]
        value = current if literal > 0 else -current
        if value:
            return value > 0
        assigned = 1 if literal > 0 else -1
        self.assigns[variable], self.phase[variable] = assigned, assigned
        self.level[variable], self.reason[variable] = self.decision_level, reason
        self.trail.append(literal)
        self.heap.remove(variable)
        return True

    def is_deleted(self, cid):
        return cid >= self.original_long and self.learnt_deleted[cid - self.original_long]

    def clause_view(self, cid):
        if not self.compact:
            return self.cnf.long_data, self.cnf.long_meta[cid], self.cnf.lengths[cid]
        if cid < self.original_long:
            packed = self.cnf.long_meta[cid]
            return self.cnf.long_data, packed >> 4, packed & 15
        packed = self.learnt_meta[cid - self.original_long]
        return self.learnt_data, packed >> 32, packed & 0xffffffff

    def propagate_long_list(self, watched, false_literal, learnt):
        read = write = 0
        length_watched = len(watched)
        assigns = self.assigns
        compact, original_long, cnf = self.compact, self.original_long, self.cnf
        original_data, original_meta = cnf.long_data, cnf.long_meta
        original_lengths = cnf.lengths
        learnt_data, learnt_meta, learnt_deleted = self.learnt_data, self.learnt_meta, self.learnt_deleted
        while read < length_watched:
            cid = watched[read]
            read += 1
            if not learnt and cid & 0x80000000:
                other = index_literal(cid & 0x7fffffff)
                watched[write] = cid
                write += 1
                raw_value = assigns[abs(other)]
                other_value = raw_value if other > 0 else -raw_value
                if other_value < 0 or (not other_value and not self.enqueue(other, binary_reason(false_literal))):
                    self.binary_conflict_a, self.binary_conflict_b = false_literal, other
                    while read < length_watched:
                        watched[write] = watched[read]
                        read += 1
                        write += 1
                    del watched[write:]
                    return BINARY_CONFLICT
                continue
            is_learnt = learnt or (not compact and cid >= original_long)
            if is_learnt and learnt_deleted[cid - original_long]:
                continue
            if not compact:
                data, offset, length = original_data, original_meta[cid], original_lengths[cid]
            elif cid < original_long:
                packed = original_meta[cid]
                data, offset, length = original_data, packed >> 4, packed & 15
            else:
                packed = learnt_meta[cid - original_long]
                data, offset, length = learnt_data, packed >> 32, packed & 0xffffffff
            if data[offset] == false_literal:
                data[offset], data[offset + 1] = data[offset + 1], data[offset]
            if data[offset + 1] != false_literal:
                watched[write] = cid
                write += 1
                continue
            other = data[offset]
            raw_value = assigns[abs(other)]
            other_value = raw_value if other > 0 else -raw_value
            if other_value > 0:
                watched[write] = cid
                write += 1
                continue
            replacement = 2
            while replacement < length:
                candidate = data[offset + replacement]
                raw_value = assigns[abs(candidate)]
                if (raw_value if candidate > 0 else -raw_value) >= 0:
                    break
                replacement += 1
            if replacement < length:
                next_literal = data[offset + replacement]
                data[offset + 1], data[offset + replacement] = next_literal, false_literal
                (self.learnt_watch(next_literal) if is_learnt else self.long_watch(next_literal)).append(cid)
                continue
            watched[write] = cid
            write += 1
            if other_value < 0 or not self.enqueue(other, cid):
                while read < length_watched:
                    watched[write] = watched[read]
                    read += 1
                    write += 1
                del watched[write:]
                return cid
        del watched[write:]
        return NO_CONFLICT

    def propagate(self):
        while self.qhead < len(self.trail):
            false_literal = -self.trail[self.qhead]
            self.qhead += 1
            self.propagations += 1
            index = lit_index(false_literal)
            watched = self.long_watches[index]
            if watched is not None:
                conflict = self.propagate_long_list(watched, false_literal, False)
                if conflict != NO_CONFLICT:
                    return conflict
            if self.compact:
                learnt = self.learnt_watches.get(index)
                if learnt is not None:
                    conflict = self.propagate_long_list(learnt, false_literal, True)
                    if conflict != NO_CONFLICT:
                        return conflict
            if not (self.propagations & 8191) and time.perf_counter() > self.deadline:
                self.aborted = True
                return NO_CONFLICT
        return NO_CONFLICT

    def bump_variable(self, variable):
        self.activity[variable] += self.var_inc
        if self.activity[variable] > 1e100:
            for index in range(1, self.nvars + 1):
                self.activity[index] *= 1e-100
            self.var_inc *= 1e-100
        self.heap.update(variable)

    def bump_clause(self, cid):
        if cid < self.original_long:
            return
        index = cid - self.original_long
        self.learnt_activity[index] += self.clause_inc
        data, offset, length = self.clause_view(cid)
        levels = set()
        for pos in range(offset, offset + length):
            level = self.level[abs(data[pos])]
            if level:
                levels.add(level)
        if levels and len(levels) < self.learnt_lbd[index]:
            self.learnt_lbd[index] = len(levels)
        if self.learnt_activity[index] > 1e20:
            for pos in range(len(self.learnt_activity)):
                self.learnt_activity[pos] *= 1e-20
            self.clause_inc *= 1e-20

    def visit_reason(self, reason, pivot, callback):
        if reason < 0:
            if reason != DECISION_REASON:
                callback(reason_literal(reason))
            return
        data, offset, length = self.clause_view(reason)
        for pos in range(offset, offset + length):
            literal = data[pos]
            if literal != pivot:
                callback(literal)

    def analyze(self, conflict):
        learnt, touched = [0], []
        path_count = pivot = 0

        def inspect(literal):
            nonlocal path_count
            variable = abs(literal)
            if not self.seen[variable] and self.level[variable] > 0:
                self.seen[variable] = 1
                touched.append(variable)
                self.bump_variable(variable)
                if self.level[variable] == self.decision_level:
                    path_count += 1
                else:
                    learnt.append(literal)

        if conflict == BINARY_CONFLICT:
            inspect(self.binary_conflict_b)
            inspect(self.binary_conflict_a)
        else:
            self.bump_clause(conflict)
            self.visit_reason(conflict, 0, inspect)
        trail_index = len(self.trail) - 1
        while True:
            while True:
                pivot = self.trail[trail_index]
                trail_index -= 1
                if self.seen[abs(pivot)]:
                    break
            self.seen[abs(pivot)] = 0
            path_count -= 1
            if path_count <= 0:
                break
            reason = self.reason[abs(pivot)]
            if reason >= 0:
                self.bump_clause(reason)
            self.visit_reason(reason, pivot, inspect)
        learnt[0] = -pivot
        for literal in learnt:
            self.seen[abs(literal)] = 1
        minimized = [learnt[0]]
        for literal in learnt[1:]:
            variable = abs(literal)
            redundant = self.reason[variable] != DECISION_REASON
            stack = [variable] if redundant else []
            added = []
            while redundant and stack:
                current = stack.pop()
                current_reason = self.reason[current]
                if current_reason == DECISION_REASON:
                    redundant = False
                    break
                dependencies = []
                assigned_literal = current if self.assigns[current] > 0 else -current
                self.visit_reason(current_reason, assigned_literal, dependencies.append)
                for dependency_literal in dependencies:
                    dependency = abs(dependency_literal)
                    if dependency == current or not self.level[dependency] or self.seen[dependency]:
                        continue
                    if self.reason[dependency] == DECISION_REASON:
                        redundant = False
                        break
                    self.seen[dependency] = 1
                    added.append(dependency)
                    stack.append(dependency)
            for dependency in added:
                self.seen[dependency] = 0
            if not redundant:
                minimized.append(literal)
        learnt = minimized
        for variable in touched:
            self.seen[variable] = 0
        for literal in learnt:
            self.seen[abs(literal)] = 0
        backtrack = 0
        if len(learnt) > 1:
            best = 1
            for index in range(2, len(learnt)):
                if self.level[abs(learnt[index])] > self.level[abs(learnt[best])]:
                    best = index
            learnt[1], learnt[best] = learnt[best], learnt[1]
            backtrack = self.level[abs(learnt[1])]
        lbd = len({self.level[abs(literal)] for literal in learnt})
        return learnt, backtrack, lbd

    def add_learnt(self, literals, lbd):
        if self.compact:
            offset = len(self.learnt_data)
            self.learnt_data.extend(literals)
            packed = (offset << 32) | len(literals)
        else:
            offset = len(self.cnf.long_data)
            self.cnf.long_data.extend(literals)
            self.cnf.long_meta.append(offset)
            self.cnf.lengths.append(len(literals))
            packed = len(literals)
        self.learnt_meta.append(packed)
        self.learnt_deleted.append(0)
        self.learnt_activity.append(self.clause_inc)
        self.learnt_lbd.append(lbd)
        cid = self.original_long + len(self.learnt_meta) - 1
        self.active_learnts += 1
        if len(literals) >= 2:
            self.learnt_watch(literals[0]).append(cid)
            self.learnt_watch(literals[1]).append(cid)
        return cid

    def backtrack(self, target_level):
        if self.decision_level <= target_level:
            return
        target = self.trail_lim[0] if target_level == 0 else self.trail_lim[target_level]
        self.best_prefix = min(self.best_prefix, target)
        for literal in reversed(self.trail[target:]):
            variable = abs(literal)
            self.assigns[variable], self.level[variable], self.reason[variable] = 0, 0, DECISION_REASON
            self.heap.insert(variable)
        del self.trail[target:]
        self.qhead = min(self.qhead, target)
        del self.trail_lim[target_level:]

    def restart(self):
        target = 0
        if len(self.heap.heap) > 1:
            next_var = self.heap.heap[1]
            while target < self.decision_level:
                decision = abs(self.trail[self.trail_lim[target]])
                if self.activity[decision] < self.activity[next_var]:
                    break
                target += 1
        self.backtrack(target)
        self.restarts += 1

    def update_best_phases(self):
        if len(self.trail) <= self.best_assigned:
            return
        self.best_assigned = len(self.trail)
        for literal in self.trail[self.best_prefix:]:
            self.best_phase[abs(literal)] = 1 if literal > 0 else -1
        self.best_prefix = len(self.trail)

    def rephase(self):
        self.backtrack(0)
        kind = self.rephase_count & 7
        for variable in range(1, self.nvars + 1):
            if kind == 0:
                self.phase[variable] = -self.initial_phase[variable]
            elif kind in (1, 3, 5, 7) and self.best_phase[variable]:
                self.phase[variable] = self.best_phase[variable]
            elif kind == 2:
                self.phase[variable] = -self.phase[variable]
            elif kind == 4:
                value = ((variable ^ self.seed ^ ((self.rephase_count + 1) * 0x9e3779b9)) * 0x85ebca6b) & 0xffffffff
                self.phase[variable] = 1 if (value ^ (value >> 13)) & 1 else -1
            elif kind == 6:
                self.phase[variable] = self.initial_phase[variable]
        self.rephase_count += 1
        self.next_rephase = self.conflicts + 1000 * (self.rephase_count + 1)

    def update_lbd(self, lbd):
        if not self.lbd_initialized:
            self.lbd_fast = self.lbd_slow = float(lbd)
            self.lbd_initialized = True
        else:
            self.lbd_fast += (lbd - self.lbd_fast) / 33.0
            self.lbd_slow += (lbd - self.lbd_slow) / 100000.0

    def reduce_learnts(self, aggressive=False):
        locked = set()
        for literal in self.trail:
            reason = self.reason[abs(literal)]
            if reason >= self.original_long:
                locked.add(reason)
        candidates = []
        for index in range(len(self.learnt_meta)):
            cid = self.original_long + index
            if self.learnt_deleted[index] or cid in locked:
                continue
            length = self.learnt_meta[index] & 0xffffffff if self.compact else self.learnt_meta[index]
            if aggressive or (length > 2 and (self.restart_mode == "luby" or self.learnt_lbd[index] > 2)):
                candidates.append(cid)
        candidates.sort(key=lambda cid: (
            -self.learnt_lbd[cid - self.original_long],
            self.learnt_activity[cid - self.original_long],
        ))
        fraction = 3 if aggressive else 2
        for cid in candidates[:len(candidates) * fraction // 4]:
            self.learnt_deleted[cid - self.original_long] = 1
            self.active_learnts -= 1
        if self.compact and len(self.learnt_data) > 2_000_000 and self.active_learnts * 2 < len(self.learnt_meta):
            self.compact_learnts()

    def compact_learnts(self):
        count = len(self.learnt_meta)
        mapping = array("i", [-1]) * count
        write_data = write_clause = 0
        for old in range(count):
            if self.learnt_deleted[old]:
                continue
            packed = self.learnt_meta[old]
            offset, length = packed >> 32, packed & 0xffffffff
            if write_data != offset:
                for index in range(length):
                    self.learnt_data[write_data + index] = self.learnt_data[offset + index]
            mapping[old] = write_clause
            self.learnt_meta[write_clause] = (write_data << 32) | length
            self.learnt_activity[write_clause] = self.learnt_activity[old]
            self.learnt_lbd[write_clause] = self.learnt_lbd[old]
            write_data += length
            write_clause += 1
        del self.learnt_data[write_data:]
        del self.learnt_meta[write_clause:]
        del self.learnt_activity[write_clause:]
        del self.learnt_lbd[write_clause:]
        self.learnt_deleted = bytearray(write_clause)
        for variable in range(1, self.nvars + 1):
            reason = self.reason[variable]
            if reason >= self.original_long:
                self.reason[variable] = self.original_long + mapping[reason - self.original_long]
        self.learnt_watches.clear()
        for index in range(write_clause):
            packed = self.learnt_meta[index]
            offset, length = packed >> 32, packed & 0xffffffff
            if length >= 2:
                cid = self.original_long + index
                self.learnt_watch(self.learnt_data[offset]).append(cid)
                self.learnt_watch(self.learnt_data[offset + 1]).append(cid)

    def solve(self):
        if self.inconsistent:
            return "UNSAT"
        conflict = self.propagate()
        if self.aborted:
            return "TIMEOUT"
        if conflict != NO_CONFLICT:
            return "UNSAT"
        next_reduction = 5000
        restart_index, since_restart = 1, 0
        stable, switch_limit, switch_span = False, 10000, 10000
        restart_limit = self.restart_base * luby(2, restart_index)
        while True:
            conflict = self.propagate()
            if self.aborted:
                return "TIMEOUT"
            if conflict != NO_CONFLICT:
                self.update_best_phases()
                self.conflicts += 1
                since_restart += 1
                if self.decision_level == 0:
                    return "UNSAT"
                learnt, backtrack, lbd = self.analyze(conflict)
                self.update_lbd(lbd)
                self.backtrack(backtrack)
                reason = self.add_learnt(learnt, lbd)
                if not self.enqueue(learnt[0], reason):
                    return "UNSAT"
                self.var_inc *= 1 / 0.95
                self.clause_inc *= 1 / 0.999
                if self.conflicts >= next_reduction:
                    self.reduce_learnts(len(self.learnt_data) > 12_000_000)
                    next_reduction = self.conflicts + 5000 + self.conflicts // 20
                if self.restart_mode == "cadical" and self.conflicts >= switch_limit:
                    stable = not stable
                    switch_span *= 2
                    switch_limit = self.conflicts + switch_span
                    restart_index, since_restart = 1, 0
                    restart_limit = (1024 if stable else self.restart_base) * luby(2, restart_index)
                if (self.restart_mode in ("luby", "hybrid") or self.restart_mode == "cadical" and stable) and since_restart >= restart_limit:
                    self.restart()
                    restart_index += 1
                    restart_limit = (1024 if self.restart_mode == "cadical" and stable else self.restart_base) * luby(2, restart_index)
                    since_restart = 0
                elif self.restart_mode != "luby" and self.conflicts >= self.next_rephase:
                    self.rephase()
                elif self.restart_mode != "luby" and not stable and self.decision_level >= 2 and self.conflicts >= self.next_restart and self.lbd_initialized and self.lbd_fast >= 1.10 * self.lbd_slow:
                    self.restart()
                    self.next_restart = self.conflicts + self.restart_base
                if not (self.conflicts & 255) and time.perf_counter() > self.deadline:
                    return "TIMEOUT"
                continue
            self.update_best_phases()
            variable = self.heap.pop()
            while variable and self.assigns[variable]:
                variable = self.heap.pop()
            if not variable:
                return "SAT"
            if self.branch_mode == "group" and self.group_of[variable] >= 0:
                start = self.decision_groups[self.group_of[variable]]
                best = variable
                for candidate in range(start, start + self.group_size):
                    if not self.assigns[candidate] and self.activity[candidate] > self.activity[best]:
                        best = candidate
                if best != variable:
                    self.heap.insert(variable)
                    self.heap.remove(best)
                    variable = best
            self.decisions += 1
            self.trail_lim.append(len(self.trail))
            literal = variable if self.phase[variable] > 0 else -variable
            self.enqueue(literal, DECISION_REASON)
            if not (self.decisions & 4095) and time.perf_counter() > self.deadline:
                return "TIMEOUT"


def evaluate(node, assignment, table):
    if node.name is not None:
        return assignment[node.name]
    return table[evaluate(node.left, assignment, table)][evaluate(node.right, assignment, table)]


def enumerate_assignments(names, size, callback):
    assignment, count = {}, 0

    def visit(index):
        nonlocal count
        if index == len(names):
            count += 1
            callback(assignment)
            return
        name = names[index]
        for value in range(size):
            assignment[name] = value
            visit(index + 1)

    visit(0)
    return count


def validate_countermodel(premise_text, target_text, size, table):
    factory = TermFactory()
    premise, target = parse_equation(premise_text, factory), parse_equation(target_text, factory)
    premise_names = tuple(sorted(set(premise[0].variables + premise[1].variables)))
    premise_checks, premise_error = 0, None

    def check_premise(assignment):
        nonlocal premise_checks, premise_error
        premise_checks += 1
        if premise_error is None and evaluate(premise[0], assignment, table) != evaluate(premise[1], assignment, table):
            premise_error = dict(assignment)

    enumerate_assignments(premise_names, size, check_premise)
    if premise_error is not None:
        return {"valid": False, "error": "premise failure", "premise_failure": premise_error,
                "premise_assignments": premise_checks, "target_assignments": 0, "target_failures": 0}
    target_names = tuple(sorted(set(target[0].variables + target[1].variables)))
    target_checks, failures, witness, witness_values = 0, 0, None, None

    def check_target(assignment):
        nonlocal target_checks, failures, witness, witness_values
        target_checks += 1
        left, right = evaluate(target[0], assignment, table), evaluate(target[1], assignment, table)
        if left != right:
            failures += 1
            if witness is None:
                witness, witness_values = dict(assignment), [left, right]

    enumerate_assignments(target_names, size, check_target)
    return {"valid": witness is not None, "witness": witness, "witness_values": witness_values,
            "premise_assignments": premise_checks, "target_assignments": target_checks,
            "target_failures": failures, "error": None if witness is not None else "target never fails"}


def decode_vector(start, size, assignments):
    selected = -1
    for value in range(size):
        if assignments[start + value] > 0:
            if selected >= 0:
                raise RuntimeError("non one-hot model")
            selected = value
    if selected < 0:
        raise RuntimeError("missing one-hot model value")
    return selected


def trim_heap():
    gc.collect()
    if os.name != "nt":
        try:
            ctypes.CDLL(None).malloc_trim(0)
        except Exception:
            pass


def peak_memory_mib():
    try:
        with open("/proc/self/status", encoding="ascii") as handle:
            for line in handle:
                if line.startswith("VmHWM:"):
                    return int(line.split()[1]) / 1024.0
    except OSError:
        pass
    return None


def solve_fixed(premise_text, target_text, size, timeout=300.0, *, structure="none",
                witness_pattern=None, phase="negative", branch="boolean",
                restart_base=2, restart_mode="dynamic", seed=1, fix_first_witness=True):
    started = time.perf_counter()
    deadline = started + max(0.001, float(timeout))
    try:
        factory = TermFactory()
        premise, target = parse_equation(premise_text, factory), parse_equation(target_text, factory)
        encoder = MagmaEncoder(size, deadline, fix_first_witness, structure, witness_pattern)
        encoder.encode(premise, target)
        encoder.cnf = decompose_binary_scc(encoder.cnf, deadline)
        encoded_at = time.perf_counter()
        encoder.release_caches()
        trim_heap()
        solver = CDCLSolver(encoder.cnf, deadline, {
            "phase": phase, "decision_groups": encoder.decision_groups, "group_size": size,
            "branch": branch, "restart_base": restart_base, "restart_mode": restart_mode, "seed": seed,
        })
        status = solver.solve()
        common = {
            "size": size, "status": status, "variables": encoder.cnf.variable_count,
            "clauses": solver.clause_count, "original_clauses": solver.original_clauses,
            "encoding_seconds": encoded_at - started, "seconds": time.perf_counter() - started,
            "conflicts": solver.conflicts, "decisions": solver.decisions,
            "propagations": solver.propagations, "restarts": solver.restarts, "engine": ENGINE,
            "phase": solver.phase_mode, "branch": solver.branch_mode, "structure": encoder.structure,
            "restart_base": solver.restart_base, "seed": solver.seed, "peak_memory_mib": peak_memory_mib(),
        }
        if status != "SAT":
            return common
        if encoder.cnf.representative is not None:
            original_values = solver.assigns[:]
            for variable in range(1, solver.nvars + 1):
                rep = encoder.cnf.representative[variable]
                value = original_values[abs(rep)]
                solver.assigns[variable] = value if rep > 0 else -value
        table = [[decode_vector(encoder.table[left][right], size, solver.assigns)
                  for right in range(size)] for left in range(size)]
        common["sat_witness"] = {name: decode_vector(start, size, solver.assigns)
                                 for name, start in encoder.witness.items()}
        common["validation"] = validate_countermodel(premise_text, target_text, size, table)
        common["status"] = "SAT" if common["validation"]["valid"] else "INVALID_MODEL"
        common["table"], common["seconds"] = table, time.perf_counter() - started
        return common
    except SearchTimeout:
        return {"size": size, "status": "TIMEOUT", "seconds": time.perf_counter() - started,
                "engine": ENGINE, "peak_memory_mib": peak_memory_mib()}
    except MemoryError:
        return {"size": size, "status": "MEMORY_LIMIT", "seconds": time.perf_counter() - started,
                "engine": ENGINE, "peak_memory_mib": peak_memory_mib()}
    except Exception as error:
        return {"size": size, "status": "ERROR", "seconds": time.perf_counter() - started,
                "engine": ENGINE, "error": "".join(traceback.format_exception(error)),
                "peak_memory_mib": peak_memory_mib()}


def solve_portfolio(premise_text, target_text, size, timeout=300.0, *,
                    general_slice=30.0, seed=1, fix_first_witness=True):
    structure, pattern, branch, base, mode = "none", None, "boolean", 2, "cadical"
    result = solve_fixed(premise_text, target_text, size, timeout, structure=structure,
                         witness_pattern=pattern, branch=branch, restart_base=base,
                         restart_mode=mode, seed=seed, fix_first_witness=fix_first_witness)
    result["portfolio"] = [{"status": result["status"], "seconds": result.get("seconds", 0),
                            "structure": structure, "conflicts": result.get("conflicts", 0),
                            "decisions": result.get("decisions", 0)}]
    return result


def default_domain_budget(size, max_size, remaining, total_budget=300.0):
    if size >= max_size:
        return remaining
    scale = max(1.0, total_budget / 300.0)
    if size >= 9:
        return remaining / 2.0
    if scale > 4.0:
        scale = 2.0 * math.sqrt(scale)
    caps = {2: 2, 3: 4, 4: 8, 5: 20, 6: 40, 7: 70, 8: 120}
    return min(remaining, caps.get(size, 2) * scale)


def solve_problem(premise_text, target_text, timeout=300.0, min_size=2, max_size=9,
                  general_slice=30.0, seed=1, fix_first_witness=True):
    factory = TermFactory()
    parse_equation(premise_text, factory), parse_equation(target_text, factory)
    if min_size < 1 or max_size < min_size:
        raise ValueError("invalid domain range")
    started, attempts, last = time.perf_counter(), [], None
    for size in range(min_size, max_size + 1):
        remaining = timeout - (time.perf_counter() - started)
        if remaining <= 0:
            break
        budget = default_domain_budget(size, max_size, remaining, timeout)
        result = solve_portfolio(premise_text, target_text, size, budget,
                                 general_slice=min(general_slice, budget), seed=seed,
                                 fix_first_witness=fix_first_witness)
        attempts.append({"size": size, "status": result["status"], "seconds": result.get("seconds", 0),
                         "variables": result.get("variables"), "clauses": result.get("clauses"),
                         "conflicts": result.get("conflicts", 0), "structure": result.get("structure", "none"),
                         "peak_memory_mib": result.get("peak_memory_mib"), "error": result.get("error")})
        last = result
        if result["status"] == "SAT":
            result["seconds"], result["domain_attempts"], result["searched_automatically"] = time.perf_counter() - started, attempts, True
            return result
        if result["status"] in ("ERROR", "MEMORY_LIMIT"):
            break
        trim_heap()
    if last is None:
        last = {"status": "TIMEOUT", "engine": ENGINE}
    elif last["status"] == "UNSAT" and attempts[-1]["size"] < max_size:
        last = {"status": "TIMEOUT", "engine": ENGINE}
    last["seconds"], last["domain_attempts"], last["searched_automatically"] = time.perf_counter() - started, attempts, True
    if attempts and attempts[-1]["size"] == max_size and all(row["status"] == "UNSAT" for row in attempts):
        last["status"] = "UNSAT_UP_TO_MAX_SIZE"
    elif last.get("status") == "UNSAT":
        last["status"] = "TIMEOUT"
    return last


def _d12_cadical_formula(text):
    """Translate the Stage 2 magma glyph to cadical_baseline syntax."""

    return text.replace("◇", "*")


def _d12_record_search_metrics(metrics, result, effective_seconds):
    attempts = result.get("domain_attempts", [])
    metrics["formula_cdcl_effective_seconds"] = round(effective_seconds, 6)
    metrics["formula_cdcl_elapsed_seconds"] = round(
        float(result.get("seconds", 0.0)), 6
    )
    metrics["formula_cdcl_status"] = result.get("status", "ERROR")
    metrics["formula_cdcl_engine"] = result.get("engine", ENGINE)
    metrics["formula_cdcl_found_order"] = result.get("size")
    metrics["formula_cdcl_domain_attempts"] = len(attempts)
    metrics["formula_cdcl_domain_statuses"] = [
        f"{item.get('size')}:{item.get('status')}" for item in attempts
    ]
    metrics["formula_cdcl_conflicts"] = sum(
        int(item.get("conflicts") or 0) for item in attempts
    )


def _table_bytes():
    global _TABLE_BYTES
    if _TABLE_BYTES is None:
        raw = lzma.decompress(base64.b85decode(_TABLES_XZ_B85))
        if len(raw) != _TABLE_RAW_BYTES:
            raise ValueError("finite-model payload length drift")
        _TABLE_BYTES = raw
    return _TABLE_BYTES


def _tables():
    raw = _table_bytes()
    position = 0
    for model_index in range(_MODEL_COUNT):
        if position >= len(raw):
            raise ValueError("finite-model payload ended early")
        order = raw[position]
        end = position + 1 + order * order
        if order == 0 or end > len(raw):
            raise ValueError("invalid finite-model payload")
        flat = raw[position + 1 : end]
        if any(value >= order for value in flat):
            raise ValueError("finite-model entry outside carrier")
        yield model_index, [
            list(flat[row * order : (row + 1) * order])
            for row in range(order)
        ]
        position = end
    if position != len(raw):
        raise ValueError("finite-model payload has trailing bytes")


def _table_sha256(table):
    canonical = json.dumps(
        table, ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _countermodel(parsed_source, parsed_target, table, metrics):
    source_holds, checked, _failure = _equation_holds(parsed_source, table)
    metrics["assignments_checked"] += checked
    if not source_holds:
        return None
    target_holds, checked, failure = _equation_holds(parsed_target, table)
    metrics["assignments_checked"] += checked
    if target_holds:
        return None
    return {
        "order": len(table),
        "carrier": list(range(len(table))),
        "table": table,
        "source_verified": True,
        "target_counterexample": failure,
        "validation_mode": "exhaustive_finite_table_full_scan",
    }


def _affine_parameters(table):
    order = len(table)
    constant = table[0][0]
    left = (table[1][0] - constant) % order if order > 1 else 0
    right = (table[0][1] - constant) % order if order > 1 else 0
    if all(
        table[row][column]
        == (left * row + right * column + constant) % order
        for row in range(order)
        for column in range(order)
    ):
        return left, right, constant
    return None


def _small_table_false_code(table):
    order = len(table)
    encoded = "[" + ",".join(
        "[" + ",".join(str(value) for value in row) + "]" for row in table
    ) + "]"
    return (
        "import JudgeProblem\n"
        "import JudgeDecide.DecideBang\n"
        "import JudgeFinOp.MemoFinOp\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n"
        "open MemoFinOp\n\n"
        "def submission : Goal := by\n"
        f"  let m : Magma (Fin {order}) := {{\n"
        f'    op := finOpTable "{encoded}"\n'
        "  }\n"
        f"  refine ⟨Fin {order}, m, ?_⟩\n"
        "  decideFin!\n"
    )


def _lean_term(term, variables, operation="d6Affine"):
    if type(term) is int:
        return variables[term]
    left = _lean_term(term[0], variables, operation)
    right = _lean_term(term[1], variables, operation)
    return f"{operation} ({left}) ({right})"


def _scalar_affine_false_code(
    order, parameters, parsed_source, parsed_target, failure
):
    left, right, constant = parameters
    source_variables, source_lhs, source_rhs = parsed_source
    target_variables, target_lhs, target_rhs = parsed_target
    source_left = _lean_term(source_lhs, source_variables)
    source_right = _lean_term(source_rhs, source_variables)
    witness = failure["assignment"]
    target_arguments = " ".join(
        f"({witness[variable]} : Fin {order})" for variable in target_variables
    )
    witness_variables = {
        index: f"({witness[variable]} : Fin {order})"
        for index, variable in enumerate(target_variables)
    }
    target_left = _lean_term(target_lhs, witness_variables)
    target_right = _lean_term(target_rhs, witness_variables)
    failure_left = failure["lhs"]
    failure_right = failure["rhs"]
    return (
        "import JudgeProblem\n"
        "import Mathlib.Tactic\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n\n"
        f"abbrev d6Carrier := Fin {order}\n\n"
        f"def d6Affine (i j : Fin {order}) : Fin {order} :=\n"
        f"  ({left} : Fin {order}) * i + ({right} : Fin {order}) * j + "
        f"({constant} : Fin {order})\n\n"
        f"@[reducible] def d6Magma : Magma (Fin {order}) := "
        "{ op := d6Affine }\n\n"
        f"local instance : Magma (Fin {order}) := d6Magma\n\n"
        f"def d6Source : EquationLHS (Fin {order}) := by\n"
        f"  intro {' '.join(source_variables)}\n"
        f"  change {source_left} = {source_right}\n"
        "  apply Fin.ext\n"
        "  simp [d6Affine] <;> omega\n\n"
        f"def d6Target : ¬ EquationRHS (Fin {order}) := by\n"
        "  intro h\n"
        f"  have bad := h {target_arguments}\n"
        f"  change {target_left} = {target_right} at bad\n"
        f"  change ({failure_left} : Fin {order}) = "
        f"({failure_right} : Fin {order}) at bad\n"
        f"  exact (show ({failure_left} : Fin {order}) ≠ "
        f"({failure_right} : Fin {order}) by decide) bad\n\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        "  exact ⟨MemoFinOp.d6Carrier, MemoFinOp.d6Magma, "
        "MemoFinOp.d6Source, MemoFinOp.d6Target⟩\n"
    )


def _affine_false_code(table, parameters, parsed_source, parsed_target, failure):
    return _scalar_affine_false_code(
        len(table), parameters, parsed_source, parsed_target, failure
    )


def _prime_power(order):
    for prime in (2, 3, 5, 7, 11, 13):
        value = order
        exponent = 0
        while value > 1 and value % prime == 0:
            value //= prime
            exponent += 1
        if value == 1 and exponent >= 2:
            return prime, exponent
    return None


def _vector_digits(value, prime, dimension):
    digits = []
    for _ in range(dimension):
        digits.append(value % prime)
        value //= prime
    return digits


def _vector_value(digits, prime):
    value = 0
    place = 1
    for digit in digits:
        value += digit * place
        place *= prime
    return value


def _vector_add(left, right, prime, dimension):
    return _vector_value(
        [
            (x + y) % prime
            for x, y in zip(
                _vector_digits(left, prime, dimension),
                _vector_digits(right, prime, dimension),
            )
        ],
        prime,
    )


def _vector_sub(left, right, prime, dimension):
    return _vector_value(
        [
            (x - y) % prime
            for x, y in zip(
                _vector_digits(left, prime, dimension),
                _vector_digits(right, prime, dimension),
            )
        ],
        prime,
    )


def _vector_affine_parameters(table):
    decomposition = _prime_power(len(table))
    if decomposition is None:
        return None
    prime, dimension = decomposition
    order = len(table)
    constant = table[0][0]
    left_map = [
        _vector_sub(table[value][0], constant, prime, dimension)
        for value in range(order)
    ]
    right_map = [
        _vector_sub(table[0][value], constant, prime, dimension)
        for value in range(order)
    ]
    if not all(
        table[i][j]
        == _vector_add(
            _vector_add(left_map[i], right_map[j], prime, dimension),
            constant,
            prime,
            dimension,
        )
        for i in range(order)
        for j in range(order)
    ):
        return None
    if not all(
        left_map[_vector_add(i, j, prime, dimension)]
        == _vector_add(left_map[i], left_map[j], prime, dimension)
        and right_map[_vector_add(i, j, prime, dimension)]
        == _vector_add(right_map[i], right_map[j], prime, dimension)
        for i in range(order)
        for j in range(order)
    ):
        return None
    left_columns = [
        _vector_digits(left_map[prime**index], prime, dimension)
        for index in range(dimension)
    ]
    right_columns = [
        _vector_digits(right_map[prime**index], prime, dimension)
        for index in range(dimension)
    ]
    return {
        "prime": prime,
        "dimension": dimension,
        "left_columns": left_columns,
        "right_columns": right_columns,
        "constant": _vector_digits(constant, prime, dimension),
    }


def _product_type(prime, dimension):
    result = f"Fin {prime}"
    for _ in range(dimension - 1):
        result = f"Fin {prime} × ({result})"
    return result


def _coordinate(variable, index, dimension):
    if index == dimension - 1:
        return variable + ".2" * index
    return variable + ".2" * index + ".1"


def _tuple_expression(expressions):
    result = expressions[-1]
    for expression in reversed(expressions[:-1]):
        result = f"⟨{expression}, {result}⟩"
    return result


def _linear_coordinate(variable, row, columns, prime, dimension):
    terms = []
    for column in range(dimension):
        coefficient = columns[column][row]
        if coefficient == 0:
            continue
        coordinate = _coordinate(variable, column, dimension)
        if coefficient == 1:
            terms.append(coordinate)
        else:
            terms.append(f"({coefficient} : ℕ) • {coordinate}")
    return " + ".join(terms) if terms else f"(0 : Fin {prime})"


def _vector_literal(value, prime, dimension):
    return _tuple_expression(
        [f"({digit} : Fin {prime})" for digit in _vector_digits(value, prime, dimension)]
    )


def _integer_linear_term(term, variable_count, parameters):
    dimension = parameters["dimension"]
    if type(term) is int:
        return [
            {(term, coordinate): 1} for coordinate in range(dimension)
        ]
    left = _integer_linear_term(term[0], variable_count, parameters)
    right = _integer_linear_term(term[1], variable_count, parameters)
    result = []
    for row in range(dimension):
        combined = {}
        for columns, values in (
            (parameters["left_columns"], left),
            (parameters["right_columns"], right),
        ):
            for column in range(dimension):
                multiplier = columns[column][row]
                for key, coefficient in values[column].items():
                    combined[key] = combined.get(key, 0) + multiplier * coefficient
        result.append({key: value for key, value in combined.items() if value})
    return result


def _source_zsmul_coefficients(parsed_source, parameters):
    source_variables, source_lhs, source_rhs = parsed_source
    coefficients = set()
    for term in (source_lhs, source_rhs):
        for coordinate in _integer_linear_term(
            term, len(source_variables), parameters
        ):
            coefficients.update(value for value in coordinate.values() if value > 1)
    return sorted(coefficients)


def _vector_affine_false_code(
    table, parameters, parsed_source, parsed_target, failure
):
    prime = parameters["prime"]
    dimension = parameters["dimension"]
    carrier = _product_type(prime, dimension)
    coordinates = []
    for row in range(dimension):
        left = _linear_coordinate(
            "i", row, parameters["left_columns"], prime, dimension
        )
        right = _linear_coordinate(
            "j", row, parameters["right_columns"], prime, dimension
        )
        constant = parameters["constant"][row]
        coordinates.append(f"({left}) + ({right}) + ({constant} : Fin {prime})")
    affine_body = _tuple_expression(coordinates)
    source_variables, source_lhs, source_rhs = parsed_source
    target_variables, target_lhs, target_rhs = parsed_target
    source_left = _lean_term(source_lhs, source_variables)
    source_right = _lean_term(source_rhs, source_variables)
    witness = failure["assignment"]
    target_arguments = " ".join(
        _vector_literal(witness[variable], prime, dimension)
        for variable in target_variables
    )
    witness_variables = {
        index: _vector_literal(witness[variable], prime, dimension)
        for index, variable in enumerate(target_variables)
    }
    target_left = _lean_term(target_lhs, witness_variables)
    target_right = _lean_term(target_rhs, witness_variables)
    left_digits = _vector_digits(failure["lhs"], prime, dimension)
    right_digits = _vector_digits(failure["rhs"], prime, dimension)
    different_index = next(
        index
        for index, (left, right) in enumerate(zip(left_digits, right_digits))
        if left != right
    )
    projection = _coordinate("q", different_index, dimension)
    failure_left = left_digits[different_index]
    failure_right = right_digits[different_index]
    zsmul_coefficients = _source_zsmul_coefficients(parsed_source, parameters)
    if any(coefficient % prime not in (0, 1) for coefficient in zsmul_coefficients):
        raise ValueError("vector source coefficients do not reduce to identity")
    zsmul_lemmas = "".join(
        f"theorem d6Zsmul{coefficient} (x : Fin {prime}) : "
        f"({coefficient} : ℤ) • x = "
        f"{'0' if coefficient % prime == 0 else 'x'} := by\n"
        "  fin_cases x <;> decide\n\n"
        for coefficient in zsmul_coefficients
    )
    zsmul_names = ", ".join(
        f"d6Zsmul{coefficient}" for coefficient in zsmul_coefficients
    )
    if zsmul_names:
        source_proof = (
            "  ext <;> simp [d6Affine] <;> abel_nf <;>\n"
            f"    simp only [{zsmul_names}, zero_add, add_zero]\n\n"
        )
    else:
        source_proof = "  ext <;> simp [d6Affine] <;> abel_nf\n\n"
    return (
        "import JudgeProblem\n"
        "import Mathlib.Tactic\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n\n"
        f"abbrev d6Carrier := {carrier}\n\n"
        "def d6Affine (i j : d6Carrier) : d6Carrier :=\n"
        f"  {affine_body}\n\n"
        f"{zsmul_lemmas}"
        "@[reducible] def d6Magma : Magma d6Carrier := { op := d6Affine }\n\n"
        "local instance : Magma d6Carrier := d6Magma\n\n"
        "def d6Source : EquationLHS d6Carrier := by\n"
        f"  intro {' '.join(source_variables)}\n"
        f"  change {source_left} = {source_right}\n"
        f"{source_proof}"
        "def d6Target : ¬ EquationRHS d6Carrier := by\n"
        "  intro h\n"
        f"  have bad := h {target_arguments}\n"
        f"  change {target_left} = {target_right} at bad\n"
        f"  have badCoordinate := congrArg (fun q : d6Carrier => {projection}) bad\n"
        f"  change ({failure_left} : Fin {prime}) = "
        f"({failure_right} : Fin {prime}) at badCoordinate\n"
        f"  exact (show ({failure_left} : Fin {prime}) ≠ "
        f"({failure_right} : Fin {prime}) by decide) badCoordinate\n\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        "  exact ⟨MemoFinOp.d6Carrier, MemoFinOp.d6Magma, "
        "MemoFinOp.d6Source, MemoFinOp.d6Target⟩\n"
    )


def _compact_table_false_code(table):
    order = len(table)
    alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if order > len(alphabet):
        raise ValueError("compact Base36 table only supports orders up to 36")
    encoded = "".join(alphabet[value] for row in table for value in row)
    if len(encoded) != order * order:
        raise ValueError("compact finite-table encoding length drift")
    return (
        "import JudgeProblem\n"
        "import JudgeDecide.DecideBang\n"
        "import JudgeFinOp.MemoFinOp\n\n"
        "set_option maxRecDepth 1000000\n"
        "set_option maxHeartbeats 0\n\n"
        "namespace MemoFinOp\n\n"
        "private def decodeBase36V2 (c : Char) : Nat :=\n"
        "  if c.isDigit then c.toNat - '0'.toNat\n"
        "  else c.toNat - 'A'.toNat + 10\n\n"
        "def base36TableV2 (s : String) (i j : Fin n) : Fin n :=\n"
        "  let vals := s.toList.map decodeBase36V2\n"
        "  let idx := i.val * n + j.val\n"
        "  ⟨(vals.getD idx 0) % n,\n"
        "    Nat.mod_lt _ (Nat.lt_of_le_of_lt (Nat.zero_le i.val) i.isLt)⟩\n\n"
        "end MemoFinOp\n\n"
        "def submission : Goal := by\n"
        f"  let m : Magma (Fin {order}) := {{\n"
        f'    op := MemoFinOp.base36TableV2 "{encoded}"\n'
        "  }\n"
        f"  refine ⟨Fin {order}, m, ?_⟩\n"
        "  decideFin!\n"
    )


def _false_code(table, parsed_source, parsed_target, failure):
    order = len(table)
    if order <= 10:
        return _small_table_false_code(table), "finOpTable_single_digit_decideFin"
    parameters = _affine_parameters(table)
    if parameters is not None:
        return (
            _affine_false_code(
                table, parameters, parsed_source, parsed_target, failure
            ),
            "fin_scalar_affine_symbolic",
        )
    vector_parameters = _vector_affine_parameters(table)
    if (
        vector_parameters is not None
        and not any(vector_parameters["constant"])
        and all(
            coefficient % vector_parameters["prime"] in (0, 1)
            for coefficient in _source_zsmul_coefficients(
                parsed_source, vector_parameters
            )
        )
    ):
        return (
            _vector_affine_false_code(
                table,
                vector_parameters,
                parsed_source,
                parsed_target,
                failure,
            ),
            "fin_vector_affine_symbolic",
        )
    return _compact_table_false_code(table), "base36_compact_table_decideFin"


def _base_result(ordinal, case_id, status, stop_reason, save_mode, metrics):
    return {
        "schema_version": PROVER_SCHEMA,
        "prover_name": PROVER_NAME,
        "ordinal": ordinal,
        "id": case_id,
        "status": status,
        "stop_reason": stop_reason,
        "result_save_mode": save_mode,
        "certificate_valid": None,
        "verdict": None,
        "judge_verdict": None,
        "metrics": {key: value for key, value in metrics.items() if not key.startswith("_")},
    }


def prove(case, config):
    """Try generalized infinite source rules, then the d6 finite-model bank."""

    started = time.monotonic()
    ordinal = case.get("ordinal") if isinstance(case, dict) else None
    case_id = case.get("id") if isinstance(case, dict) else None
    save_mode = "minimal"
    previous_alarm = None
    trace = []
    metrics = {
        "architecture": "false-solver-d17-exp5-group-core-plus-affine-stream-v2",
        "infinite_family_checks": 0,
        "model_checks": 0,
        "assignments_checked": 0,
        "oversize_certificates_skipped": 0,
        "maximum_candidate_certificate_bytes": 0,
        "stage_events": 0,
        "scalar_affine_enabled": False,
        "scalar_affine_parameter_checks": 0,
        "scalar_affine_found_order": None,
        "scalar_affine_integer_pairs_evaluated": 0,
        "scalar_affine_logical_ab_pairs": 0,
        "scalar_affine_moduli_checked": 0,
        "scalar_affine_candidate_moduli": 0,
        "scalar_affine_search_seconds": 0.0,
        "scalar_affine_max_n": _D16_AFFINE_MAX_N,
        "finite_model_bank_scalar_affine_removed": 241,
        "formula_cdcl_enabled": False,
        "formula_cdcl_configured_seconds": 0.0,
        "formula_cdcl_effective_seconds": 0.0,
        "formula_cdcl_elapsed_seconds": 0.0,
        "formula_cdcl_status": "NOT_RUN",
        "elapsed_seconds": 0.0,
    }
    try:
        (save_mode, safety_seconds, enabled, infinite_enabled, scalar_affine_enabled,
         formula_cdcl_enabled, formula_cdcl_seconds, formula_cdcl_min_size,
         formula_cdcl_max_size) = _runtime_config(config)
        ordinal, case_id, source, target = _case_formulas(case)
        parsed_source = _parse_equation(source)
        parsed_target = _parse_equation(target)
        previous_alarm = _arm_safety_wall(safety_seconds)
        if infinite_enabled:
            metrics["infinite_family_checks"] = (_INFINITE_RULE_COUNT + 7)
            candidate = _infinite_candidate(parsed_source, parsed_target)
            if candidate is not None:
                family, code, source_recognition = candidate
                if family == _D15_EXP5_FAMILY:
                    stage = "stage0_d15_exp5_group_core"
                elif family == _D15_ACCEPTED_CM_FAMILY:
                    stage = "stage0_d15_inductive_cm_transfer"
                elif family == _D15_PATTERN_CM_FAMILY:
                    stage = "stage0_d15_pattern_cm_transfer"
                elif family == _D15_KBO_FAMILY:
                    stage = "stage0_d15_kbo_completion"
                elif family == _D15_NF_FAMILY:
                    stage = "stage0_d15_normal_form_normalization"
                else:
                    stage = "stage0_generalized_infinite_source_family"
                judge_lean, certificate_bytes = _staged_certificate(stage, code)
                metrics["maximum_candidate_certificate_bytes"] = max(
                    metrics["maximum_candidate_certificate_bytes"], certificate_bytes
                )
                if judge_lean is None:
                    metrics["oversize_certificates_skipped"] += 1
                    if save_mode == "full":
                        trace.append(
                            {
                                "seq": len(trace) + 1,
                                "stage": stage,
                                "event": "certificate_too_large",
                                "certificate_bytes": certificate_bytes,
                                "limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                            }
                        )
                else:
                    metrics["stage_events"] = 1
                    metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                    result = _base_result(
                        ordinal,
                        case_id,
                        "REFUTED",
                        "INFINITE_COUNTERMODEL_CANDIDATE",
                        save_mode,
                        metrics,
                    )
                    result.update(
                        {
                            "certificate_valid": None,
                            "certificate_kind": (
                                "d15_exp5_group_source_model"
                                if family == _D15_EXP5_FAMILY
                                else "d15_inductive_cm_source_model"
                                if family == _D15_ACCEPTED_CM_FAMILY
                                else "d15_pattern_cm_source_model"
                                if family == _D15_PATTERN_CM_FAMILY
                                else "d15_kbo_source_model"
                                if family == _D15_KBO_FAMILY
                                else "d15_normal_form_source_model"
                                if family == _D15_NF_FAMILY
                                else "generalized_infinite_source_model"
                            ),
                            "certificate_bytes": certificate_bytes,
                            "certificate_limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                            "verdict": False,
                            "judge_verdict": "false",
                            "stage": stage,
                            "countermodel": {
                                "carrier_class": "infinite",
                                "construction_family": family,
                                "recognition": source_recognition,
                                "target_index_used": False,
                                "target_validation": "target_ast_symbolic_reduction_then_constructor_nomatch_then_current_judge",
                            },
                            "judge_lean": judge_lean,
                        }
                    )
                    if save_mode == "full":
                        result["trace"] = trace + [
                            {
                                "seq": len(trace) + 1,
                                "stage": stage,
                                "event": "candidate",
                                "construction_family": family,
                                "certificate_bytes": certificate_bytes,
                            }
                        ]
                    return result
        if enabled:
            for model_index, table in _tables():
                metrics["model_checks"] += 1
                details = _countermodel(
                    parsed_source, parsed_target, table, metrics
                )
                if details is None:
                    continue
                model_sha256 = _table_sha256(table)
                metrics["stage_events"] = 1
                metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
                details.update(
                    {
                        "frozen_model_sha256": model_sha256,
                        "frozen_model_index": model_index,
                        "frozen_library": "unified_static_finite_bank",
                    }
                )
                stage = "stage0_unified_finite_model_full_scan"
                trace.append(
                    {
                        "seq": 1,
                        "stage": stage,
                        "event": "hit",
                        "models_scanned": metrics["model_checks"],
                        "model_index": model_index,
                        "model_sha256": model_sha256,
                    }
                )
                judge_lean, certificate_encoding = _false_code(
                    table,
                    parsed_source,
                    parsed_target,
                    details["target_counterexample"],
                )
                staged_judge_lean, certificate_bytes = _staged_certificate(
                    stage, judge_lean
                )
                metrics["maximum_candidate_certificate_bytes"] = max(
                    metrics["maximum_candidate_certificate_bytes"], certificate_bytes
                )
                if staged_judge_lean is None:
                    metrics["oversize_certificates_skipped"] += 1
                    if save_mode == "full":
                        trace.append(
                            {
                                "seq": len(trace) + 1,
                                "stage": stage,
                                "event": "certificate_too_large",
                                "model_index": model_index,
                                "certificate_bytes": certificate_bytes,
                                "limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                            }
                        )
                    continue
                details["certificate_encoding"] = certificate_encoding
                result = _base_result(
                    ordinal,
                    case_id,
                    "REFUTED",
                    "COUNTERMODEL_FOUND",
                    save_mode,
                    metrics,
                )
                result.update(
                    {
                        "certificate_valid": True,
                        "certificate_kind": "finite_magma_countermodel",
                        "certificate_bytes": certificate_bytes,
                        "certificate_limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                        "verdict": False,
                        "judge_verdict": "false",
                        "stage": stage,
                        "countermodel": details,
                        "judge_lean": staged_judge_lean,
                    }
                )
                if save_mode == "full":
                    result["trace"] = trace
                return result
        if scalar_affine_enabled:
            metrics["scalar_affine_enabled"] = True
            affine_candidate = _d16_scalar_affine_countermodel(
                parsed_source, parsed_target, metrics
            )
            if affine_candidate is not None:
                order = affine_candidate["order"]
                affine_parameters = {
                    key: affine_candidate[key]
                    for key in (
                        "prime",
                        "exponent",
                        "left_coefficient",
                        "right_coefficient",
                        "constant",
                    )
                }
                details = {
                    "order": order,
                    "carrier": list(range(order)),
                    "source_verified": True,
                    "target_counterexample": affine_candidate[
                        "target_counterexample"
                    ],
                    "validation_mode": (
                        "exact_integer_coefficient_congruences_and_direct_witness"
                    ),
                    "representation": "scalar_affine_parameters_without_table",
                    "construction_family": "scalar_affine_prime_power",
                    "discovery_route": "scalar_affine_integer_pair_stream_v2",
                    "formula_only": True,
                    "searched_automatically": True,
                    "parameters": affine_parameters,
                    "source_variable_coefficients": affine_candidate[
                        "source_variable_coefficients"
                    ],
                    "source_c_coefficient": affine_candidate[
                        "source_c_coefficient"
                    ],
                    "target_variable_coefficients": affine_candidate[
                        "target_variable_coefficients"
                    ],
                    "target_c_coefficient": affine_candidate[
                        "target_c_coefficient"
                    ],
                }
                stage = "stage0_scalar_affine_prime_power_stream_v2"
                judge_lean = _scalar_affine_false_code(
                    order,
                    (
                        affine_candidate["left_coefficient"],
                        affine_candidate["right_coefficient"],
                        affine_candidate["constant"],
                    ),
                    parsed_source,
                    parsed_target,
                    details["target_counterexample"],
                )
                certificate_encoding = "fin_scalar_affine_symbolic"
                staged_judge_lean, certificate_bytes = _staged_certificate(
                    stage, judge_lean
                )
                metrics["maximum_candidate_certificate_bytes"] = max(
                    metrics["maximum_candidate_certificate_bytes"],
                    certificate_bytes,
                )
                if staged_judge_lean is not None:
                    metrics["stage_events"] = 1
                    metrics["elapsed_seconds"] = round(
                        time.monotonic() - started, 6
                    )
                    details["certificate_encoding"] = certificate_encoding
                    result = _base_result(
                        ordinal,
                        case_id,
                        "REFUTED",
                        "SCALAR_AFFINE_COUNTERMODEL_FOUND",
                        save_mode,
                        metrics,
                    )
                    result.update(
                        {
                            "certificate_valid": True,
                            "certificate_kind": "finite_magma_countermodel",
                            "certificate_bytes": certificate_bytes,
                            "certificate_limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                            "verdict": False,
                            "judge_verdict": "false",
                            "stage": stage,
                            "countermodel": details,
                            "judge_lean": staged_judge_lean,
                        }
                    )
                    if save_mode == "full":
                        result["trace"] = trace + [
                            {
                                "seq": len(trace) + 1,
                                "stage": stage,
                                "event": "hit",
                                "order": order,
                            }
                        ]
                    return result
                metrics["oversize_certificates_skipped"] += 1
        if formula_cdcl_enabled and formula_cdcl_seconds > 0.0:
            metrics["formula_cdcl_enabled"] = True
            metrics["formula_cdcl_configured_seconds"] = formula_cdcl_seconds
            elapsed_before_cdcl = time.monotonic() - started
            effective_seconds = min(
                formula_cdcl_seconds,
                max(0.0, safety_seconds - elapsed_before_cdcl - 1.0),
            )
            if effective_seconds > 0.0:
                formula_result = solve_problem(
                    _d12_cadical_formula(source),
                    _d12_cadical_formula(target),
                    timeout=effective_seconds,
                    min_size=formula_cdcl_min_size,
                    max_size=formula_cdcl_max_size,
                    general_slice=min(30.0, effective_seconds),
                    seed=1,
                    fix_first_witness=True,
                )
                _d12_record_search_metrics(
                    metrics, formula_result, effective_seconds
                )
                if formula_result.get("status") == "SAT":
                    formula_table = formula_result.get("table")
                    details = _countermodel(
                        parsed_source, parsed_target, formula_table, metrics
                    )
                    if details is None:
                        raise RuntimeError(
                            "formula CDCL table failed exhaustive d12 revalidation"
                        )
                    stage = "stage2_formula_cdcl_fin2to9_model_synthesis"
                    details.update(
                        {
                            "construction_family": "formula_driven_cnf_cdcl_portfolio",
                            "dynamic_model_search": True,
                            "formula_only": True,
                            "searched_automatically": True,
                            "search_engine": formula_result.get("engine", ENGINE),
                            "search_seconds": round(
                                float(formula_result.get("seconds", 0.0)), 6
                            ),
                        }
                    )
                    judge_lean, certificate_encoding = _false_code(
                        formula_table,
                        parsed_source,
                        parsed_target,
                        details["target_counterexample"],
                    )
                    staged_judge_lean, certificate_bytes = _staged_certificate(
                        stage, judge_lean
                    )
                    metrics["maximum_candidate_certificate_bytes"] = max(
                        metrics["maximum_candidate_certificate_bytes"],
                        certificate_bytes,
                    )
                    if staged_judge_lean is not None:
                        metrics["stage_events"] = 1
                        metrics["elapsed_seconds"] = round(
                            time.monotonic() - started, 6
                        )
                        details["certificate_encoding"] = certificate_encoding
                        result = _base_result(
                            ordinal,
                            case_id,
                            "REFUTED",
                            "FORMULA_CDCL_COUNTERMODEL_FOUND",
                            save_mode,
                            metrics,
                        )
                        result.update(
                            {
                                "certificate_valid": True,
                                "certificate_kind": "finite_magma_countermodel",
                                "certificate_bytes": certificate_bytes,
                                "certificate_limit_bytes": MAX_FALSE_CERTIFICATE_BYTES,
                                "verdict": False,
                                "judge_verdict": "false",
                                "stage": stage,
                                "countermodel": details,
                                "judge_lean": staged_judge_lean,
                            }
                        )
                        if save_mode == "full":
                            result["trace"] = trace + [
                                {
                                    "seq": len(trace) + 1,
                                    "stage": stage,
                                    "event": "hit",
                                    "order": len(formula_table),
                                    "engine": formula_result.get("engine", ENGINE),
                                }
                            ]
                        return result
                    metrics["oversize_certificates_skipped"] += 1
            else:
                metrics["formula_cdcl_status"] = "SKIPPED_NO_SAFETY_BUDGET"
        metrics["stage_events"] = 1
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        if save_mode == "full":
            trace.append(
                {
                    "seq": 1,
                    "stage": "stage0_unified_finite_model_full_scan",
                    "event": "miss",
                    "models_scanned": metrics["model_checks"],
                }
            )
        result = _base_result(
            ordinal, case_id, "UNKNOWN", "COUNTERMODEL_NOT_FOUND", save_mode, metrics
        )
        if save_mode == "full":
            result["trace"] = trace
        return result
    except _SafetyWallExpired:
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        result = _base_result(
            ordinal, case_id, "UNKNOWN", "SAFETY_WALL", save_mode, metrics
        )
        if save_mode == "full":
            result["trace"] = trace
        return result
    except Exception as error:
        metrics["elapsed_seconds"] = round(time.monotonic() - started, 6)
        result = _base_result(
            ordinal, case_id, "ERROR", "PROVER_ERROR", save_mode, metrics
        )
        result.update(
            {"error_type": type(error).__name__, "diagnostic": str(error)}
        )
        return result
    finally:
        _disarm_safety_wall(previous_alarm)


def _read_message():
    line = sys.stdin.readline()
    if not line:
        raise SystemExit(0)
    return json.loads(line)


def _send_message(message):
    print(json.dumps(message, ensure_ascii=False, separators=(",", ":")), flush=True)


def _call_judge(verdict, code):
    if len(code.encode("utf-8")) > MAX_FALSE_CERTIFICATE_BYTES:
        return {"status": "rejected", "reason": "local_false_certificate_20kb_guard"}
    _send_message({"call": "judge", "verdict": verdict, "code": code})
    return _read_message()


def _d12_solo_config(infinite_enabled):
    return {
            "result_save_mode": "minimal",
            "safety_wall_seconds": 305.0,
            "use_finite_model_bank": True,
            "use_infinite_family_bank": infinite_enabled,
            "use_scalar_affine_search": True,
            "use_formula_cdcl_search": True,
            "formula_cdcl_search_seconds": 300.0,
            "formula_cdcl_min_size": 2,
            "formula_cdcl_max_size": 9,
        }


def _solver_main():
    startup = _read_message()
    problem = startup["problem"]
    case = {
        "id": problem.get("id"),
        "source_formula": problem["equation1"],
        "target_formula": problem["equation2"],
    }
    result = prove(case, _d12_solo_config(True))
    if result.get("status") == "REFUTED":
        judge_result = _call_judge("false", result["judge_lean"])
        if (
            judge_result.get("status") != "accepted"
            and result.get("stage") == "stage0_generalized_infinite_source_family"
        ):
            fallback = prove(case, _d12_solo_config(False))
            if fallback.get("status") == "REFUTED":
                _call_judge("false", fallback["judge_lean"])


__all__ = ["PROVER_NAME", "PROVER_SCHEMA", "prove"]


if __name__ == "__main__":
    _solver_main()
