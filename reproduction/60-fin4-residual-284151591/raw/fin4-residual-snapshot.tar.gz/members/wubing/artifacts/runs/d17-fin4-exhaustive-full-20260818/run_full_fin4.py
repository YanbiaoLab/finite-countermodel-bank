#!/usr/bin/env python3
"""Run all 2^32 labeled Fin4 tables in durable, idempotent 2^24 shards."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
from datetime import datetime, timezone


RUN_DIR = Path(__file__).resolve().parent
REPO = RUN_DIR.parents[4]
ENGINE = RUN_DIR / "fin4_exhaustive_engine"
EQUATIONS = REPO / "members/wubing/data/processed/jiaming/false_tail/inputs/equations.bin"
SOURCE_BITSET = REPO / "members/wubing/data/324M_remaining_pairs/324M_remaining_pairs.bitset"
WORK_BITSET = RUN_DIR / "324M_after_all_fin4.bitset"
PROGRESS = RUN_DIR / "progress.json"
SHARDS_DIR = RUN_DIR / "shards"

SOURCE_SHA256 = "f3cce217528adee2305e618a81a1fdb7399c6732523bb60f055b1d5acf61f383"
EQUATIONS_SHA256 = "263b6d3fb1c6a84a4503742f11a4f2e6ac3a00a64e1f0a57fc002699ef7be7f9"
ORIGINAL_REMAINING = 324_157_667
SHARD_SIZE = 1 << 24
SHARD_COUNT = 1 << 8
FULL_RAW_TABLES = 1 << 32


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(8 << 20):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_json(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def initialize() -> dict:
    if not ENGINE.is_file():
        raise SystemExit(f"missing engine: {ENGINE}")
    if sha256(SOURCE_BITSET) != SOURCE_SHA256:
        raise SystemExit("source 324M bitset SHA-256 mismatch")
    if sha256(EQUATIONS) != EQUATIONS_SHA256:
        raise SystemExit("equation binary SHA-256 mismatch")
    SHARDS_DIR.mkdir(parents=True, exist_ok=True)
    if PROGRESS.exists():
        return json.loads(PROGRESS.read_text(encoding="utf-8"))
    if WORK_BITSET.exists():
        raise SystemExit("work bitset exists without progress.json; refusing ambiguous resume")
    print(f"{utc_now()} initializing 489,598,720-byte work bitset", flush=True)
    shutil.copyfile(SOURCE_BITSET, WORK_BITSET)
    with WORK_BITSET.open("rb") as handle:
        os.fsync(handle.fileno())
    copied_sha = sha256(WORK_BITSET)
    if copied_sha != SOURCE_SHA256:
        raise SystemExit("initialized work bitset does not match source SHA-256")
    progress = {
        "schema": "d17-fin4-exhaustive-progress-v1",
        "status": "running",
        "created_at": utc_now(),
        "updated_at": utc_now(),
        "source_sha256": SOURCE_SHA256,
        "work_bitset": WORK_BITSET.name,
        "original_remaining_pairs": ORIGINAL_REMAINING,
        "shard_size": SHARD_SIZE,
        "shard_count": SHARD_COUNT,
        "next_shard": 0,
        "completed_shards": [],
    }
    atomic_json(PROGRESS, progress)
    return progress


def run_shard(index: int, threads: int) -> dict:
    start = index * SHARD_SIZE
    summary = SHARDS_DIR / f"shard_{index:03d}.json"
    log = SHARDS_DIR / f"shard_{index:03d}.stderr.log"
    command = [
        str(ENGINE),
        "enumerate-inplace",
        str(EQUATIONS),
        str(WORK_BITSET),
        str(start),
        str(SHARD_SIZE),
        str(threads),
        str(summary),
    ]
    print(
        f"{utc_now()} shard={index:03d}/{SHARD_COUNT - 1:03d} "
        f"range=[{start},{start + SHARD_SIZE}) starting",
        flush=True,
    )
    with log.open("a", encoding="utf-8") as stderr:
        stderr.write(f"runner_start={utc_now()} command={json.dumps(command)}\n")
        stderr.flush()
        process = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=stderr)
        last_report = 0.0
        while True:
            return_code = process.poll()
            if return_code is not None:
                break
            now = time.monotonic()
            if now - last_report >= 60:
                try:
                    rss_kib = subprocess.check_output(
                        ["ps", "-o", "rss=", "-p", str(process.pid)], text=True
                    ).strip()
                except subprocess.SubprocessError:
                    rss_kib = "unknown"
                print(
                    f"{utc_now()} shard={index:03d} child_pid={process.pid} "
                    f"rss_kib={rss_kib or 'exited'} running",
                    flush=True,
                )
                last_report = now
            time.sleep(5)
        stderr.write(f"runner_end={utc_now()} return_code={return_code}\n")
    if return_code != 0:
        raise SystemExit(f"shard {index} failed with exit code {return_code}; see {log}")
    result = json.loads(summary.read_text(encoding="utf-8"))
    if (
        result.get("status") != "complete"
        or result.get("range_start") != start
        or result.get("range_count") != SHARD_SIZE
        or result.get("raw_tables_scanned") != SHARD_SIZE
    ):
        raise SystemExit(f"shard {index} has an invalid summary")
    print(
        f"{utc_now()} shard={index:03d} complete "
        f"canonical={result['canonical_models_evaluated']} "
        f"newly_covered={result['covered_pairs']} "
        f"remaining={result['remaining_pairs_after']} "
        f"elapsed_s={result['elapsed_seconds']:.3f}",
        flush=True,
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--threads", type=int, default=10)
    parser.add_argument("--max-shards", type=int, default=None)
    args = parser.parse_args()
    if not 1 <= args.threads <= 64:
        raise SystemExit("--threads must be in [1,64]")
    progress = initialize()
    if progress.get("schema") != "d17-fin4-exhaustive-progress-v1":
        raise SystemExit("unsupported progress schema")
    next_shard = int(progress["next_shard"])
    stop = SHARD_COUNT
    if args.max_shards is not None:
        if args.max_shards < 0:
            raise SystemExit("--max-shards must be nonnegative")
        stop = min(stop, next_shard + args.max_shards)
    for index in range(next_shard, stop):
        result = run_shard(index, args.threads)
        progress["completed_shards"].append(
            {
                "index": index,
                "range_start": index * SHARD_SIZE,
                "range_count": SHARD_SIZE,
                "summary": f"shards/shard_{index:03d}.json",
                "remaining_pairs_after": result["remaining_pairs_after"],
            }
        )
        progress["next_shard"] = index + 1
        progress["updated_at"] = utc_now()
        progress["status"] = "complete" if index + 1 == SHARD_COUNT else "running"
        atomic_json(PROGRESS, progress)
    if progress["next_shard"] == SHARD_COUNT:
        canonical = sum(
            json.loads((SHARDS_DIR / f"shard_{i:03d}.json").read_text())["canonical_models_evaluated"]
            for i in range(SHARD_COUNT)
        )
        print(
            f"{utc_now()} all shards complete raw_tables={FULL_RAW_TABLES} "
            f"canonical_models={canonical}",
            flush=True,
        )


if __name__ == "__main__":
    main()
