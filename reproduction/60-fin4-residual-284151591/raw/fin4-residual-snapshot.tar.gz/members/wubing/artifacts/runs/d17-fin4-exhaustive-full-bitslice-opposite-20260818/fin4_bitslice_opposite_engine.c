#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#if defined(__aarch64__)
#include <arm_neon.h>
#endif

#define EQUATION_MAGIC "FTEQN001"
#define MODEL_MAGIC "FTMODL01"
#define PAIR_MAGIC "O5RPAIR1"
#define MIRROR_MAGIC "FTMIRR01"
#define EXPECTED_EQUATIONS 62576u
#define EXPECTED_WORDS 978u
#define EXPECTED_REMAINING UINT64_C(324157667)
#define EXPECTED_ISOMORPHISM_CLASSES UINT64_C(178981952)
#define MAX_VARS 7u
#define MAX_TOKENS 15u
#define ORDER 4u
#define TABLE_CELLS 16u
#define SIGNATURE_BYTES 7822u
#define WORK_BLOCK 256u
#define PROBE_COUNT 8u
#define BATCH_SIZE 64u
#define BATCH_WORK_BLOCK 4096u

typedef struct {
    uint8_t var_count;
    uint8_t left_len;
    uint8_t right_len;
    uint8_t left[MAX_TOKENS];
    uint8_t right[MAX_TOKENS];
} Equation;

typedef struct {
    uint32_t count;
    uint8_t var_count;
    uint8_t *values;
} Assignments;

typedef struct {
    uint64_t low;
    uint64_t high;
} BatchValue;

typedef struct {
    uint64_t output_low[TABLE_CELLS];
    uint64_t output_high[TABLE_CELLS];
#if defined(__aarch64__)
    uint64x2_t output_planes[TABLE_CELLS];
#endif
    uint64_t lane_mask;
} BatchTable;

typedef struct {
    int fd;
    void *mapping;
    size_t mapping_size;
    uint32_t equation_count;
    uint32_t word_count;
    uint32_t header_bytes;
    uint32_t row_stride_bytes;
    uint64_t declared_remaining;
    int writable_shared;
    _Atomic uint64_t *rows;
    uint8_t *active;
    uint32_t active_count;
} PairBitset;

typedef enum {
    MODE_ENUMERATE = 1,
    MODE_MODELS = 2,
} WorkMode;

typedef struct Shared Shared;
typedef struct BatchShared BatchShared;

typedef struct {
    Shared *shared;
    uint32_t thread_id;
} WorkerArgs;

typedef struct {
    BatchShared *shared;
    uint32_t thread_id;
} BatchWorkerArgs;

struct Shared {
    WorkMode mode;
    const Equation *equations;
    uint32_t equation_count;
    const Assignments *assignments;
    PairBitset *pairs;
    const uint8_t *model_tables;
    uint64_t model_count;
    uint64_t range_start;
    uint64_t range_count;
    _Atomic uint64_t next_offset;
    _Atomic uint64_t scanned;
    _Atomic uint64_t canonical_models;
    _Atomic uint64_t relevant_models;
    _Atomic uint64_t source_satisfactions;
    _Atomic uint64_t next_report;
    uint64_t report_interval;
};

struct BatchShared {
    const Equation *equations;
    uint32_t equation_count;
    const Assignments *assignments;
    PairBitset *pairs;
    const uint32_t *mirror_map;
    const uint8_t *source_needed;
    uint64_t range_start;
    uint64_t range_count;
    uint64_t pair_start;
    uint64_t pair_end;
    _Atomic uint64_t next_offset;
    _Atomic uint64_t scanned;
    _Atomic uint64_t canonical_in_range;
    _Atomic uint64_t signatures_evaluated;
    _Atomic uint64_t opposite_signatures_derived;
    _Atomic uint64_t skipped_as_derived;
    _Atomic uint64_t expanded_relevant_models;
    _Atomic uint64_t expanded_source_satisfactions;
    _Atomic uint64_t next_report;
    uint64_t report_interval;
};

static uint8_t permutations[24][ORDER];
static uint32_t transform_lut[24][4][256];
static uint32_t permutation_count = 0;

static void fail(const char *message) {
    fprintf(stderr, "fin4_exhaustive_engine: %s\n", message);
    exit(2);
}

static void fail_errno(const char *message) {
    fprintf(stderr, "fin4_exhaustive_engine: %s: %s\n", message, strerror(errno));
    exit(2);
}

static void *checked_calloc(size_t count, size_t size) {
    void *value = calloc(count, size);
    if (value == NULL) fail_errno("allocation failed");
    return value;
}

static uint32_t read_u32_le(FILE *handle, const char *what) {
    uint8_t raw[4];
    if (fread(raw, 1, sizeof(raw), handle) != sizeof(raw)) {
        fprintf(stderr, "fin4_exhaustive_engine: short read for %s\n", what);
        exit(2);
    }
    return (uint32_t)raw[0] | ((uint32_t)raw[1] << 8) |
           ((uint32_t)raw[2] << 16) | ((uint32_t)raw[3] << 24);
}

static uint32_t load_u32_le(const uint8_t *raw) {
    return (uint32_t)raw[0] | ((uint32_t)raw[1] << 8) |
           ((uint32_t)raw[2] << 16) | ((uint32_t)raw[3] << 24);
}

static uint64_t load_u64_le(const uint8_t *raw) {
    uint64_t value = 0;
    for (unsigned i = 0; i < 8; ++i) value |= (uint64_t)raw[i] << (8u * i);
    return value;
}

static void store_u64_le(uint8_t *raw, uint64_t value) {
    for (unsigned i = 0; i < 8; ++i) raw[i] = (uint8_t)(value >> (8u * i));
}

static double elapsed_seconds(const struct timespec *start, const struct timespec *end) {
    return (double)(end->tv_sec - start->tv_sec) +
           (double)(end->tv_nsec - start->tv_nsec) / 1000000000.0;
}

static uint64_t splitmix64(uint64_t value) {
    value += UINT64_C(0x9e3779b97f4a7c15);
    value = (value ^ (value >> 30)) * UINT64_C(0xbf58476d1ce4e5b9);
    value = (value ^ (value >> 27)) * UINT64_C(0x94d049bb133111eb);
    return value ^ (value >> 31);
}

static Equation *load_equations(const char *path, uint32_t *count_out) {
    FILE *handle = fopen(path, "rb");
    if (handle == NULL) fail_errno("cannot open equation binary");
    char magic[8];
    if (fread(magic, 1, sizeof(magic), handle) != sizeof(magic) ||
        memcmp(magic, EQUATION_MAGIC, sizeof(magic)) != 0) {
        fail("bad equation binary magic");
    }
    uint32_t count = read_u32_le(handle, "equation count");
    if (count != EXPECTED_EQUATIONS) fail("unexpected equation count");
    Equation *equations = checked_calloc(count, sizeof(Equation));
    for (uint32_t i = 0; i < count; ++i) {
        Equation *equation = &equations[i];
        int var_count = fgetc(handle);
        int left_len = fgetc(handle);
        int right_len = fgetc(handle);
        if (var_count == EOF || left_len == EOF || right_len == EOF) {
            fail("short equation record header");
        }
        equation->var_count = (uint8_t)var_count;
        equation->left_len = (uint8_t)left_len;
        equation->right_len = (uint8_t)right_len;
        if (equation->var_count == 0 || equation->var_count > MAX_VARS ||
            equation->left_len == 0 || equation->left_len > MAX_TOKENS ||
            equation->right_len == 0 || equation->right_len > MAX_TOKENS) {
            fail("invalid equation dimensions");
        }
        if (fread(equation->left, 1, equation->left_len, handle) != equation->left_len ||
            fread(equation->right, 1, equation->right_len, handle) != equation->right_len) {
            fail("short equation token record");
        }
    }
    if (fgetc(handle) != EOF) fail("equation binary has trailing bytes");
    fclose(handle);
    *count_out = count;
    return equations;
}

static uint32_t power_u32(uint32_t base, uint32_t exponent) {
    uint32_t result = 1;
    for (uint32_t i = 0; i < exponent; ++i) result *= base;
    return result;
}

static void make_assignments(Assignments assignments[MAX_VARS + 1]) {
    memset(assignments, 0, sizeof(Assignments) * (MAX_VARS + 1));
    for (uint8_t var_count = 1; var_count <= MAX_VARS; ++var_count) {
        Assignments *item = &assignments[var_count];
        item->count = power_u32(ORDER, var_count);
        item->var_count = var_count;
        item->values = checked_calloc((size_t)item->count * var_count, 1);
        for (uint32_t index = 0; index < item->count; ++index) {
            uint32_t value = index;
            for (uint8_t variable = 0; variable < var_count; ++variable) {
                item->values[(size_t)index * var_count + variable] =
                    (uint8_t)(value & 3u);
                value >>= 2;
            }
        }
    }
}

static void free_assignments(Assignments assignments[MAX_VARS + 1]) {
    for (uint8_t var_count = 1; var_count <= MAX_VARS; ++var_count) {
        free(assignments[var_count].values);
    }
}

static inline uint8_t eval_tokens(
    const uint8_t *tokens,
    uint8_t length,
    const uint8_t *assignment,
    const uint8_t table[TABLE_CELLS]
) {
    uint8_t stack[MAX_TOKENS];
    uint8_t size = 0;
    for (uint8_t i = 0; i < length; ++i) {
        uint8_t token = tokens[i];
        if (token != UINT8_MAX) {
            stack[size++] = assignment[token];
        } else {
            uint8_t right = stack[--size];
            uint8_t left = stack[--size];
            stack[size++] = table[(unsigned)left * ORDER + right];
        }
    }
    return stack[0];
}

static inline int assignment_holds(
    const Equation *equation,
    const uint8_t *assignment,
    const uint8_t table[TABLE_CELLS]
) {
    return eval_tokens(equation->left, equation->left_len, assignment, table) ==
           eval_tokens(equation->right, equation->right_len, assignment, table);
}

static int equation_holds(
    const Equation *equation,
    const Assignments *assignments,
    const uint8_t table[TABLE_CELLS],
    uint64_t model_key,
    uint32_t equation_index
) {
    uint64_t seed = model_key ^ ((uint64_t)equation_index << 32);
    for (uint32_t probe = 0; probe < PROBE_COUNT; ++probe) {
        uint32_t index = (uint32_t)(splitmix64(seed + probe) % assignments->count);
        const uint8_t *assignment =
            assignments->values + (size_t)index * assignments->var_count;
        if (!assignment_holds(equation, assignment, table)) return 0;
    }
    for (uint32_t index = 0; index < assignments->count; ++index) {
        const uint8_t *assignment =
            assignments->values + (size_t)index * assignments->var_count;
        if (!assignment_holds(equation, assignment, table)) return 0;
    }
    return 1;
}

#if !defined(__aarch64__)
static inline uint64_t batch_mux(uint64_t selector, uint64_t zero, uint64_t one) {
    return zero ^ (selector & (zero ^ one));
}

static inline uint64_t batch_select16(
    const uint64_t values[TABLE_CELLS],
    BatchValue left,
    BatchValue right
) {
    uint64_t right_low[8];
    uint64_t right_high[4];
    uint64_t left_low[2];
    for (uint32_t i = 0; i < 8; ++i) {
        right_low[i] = batch_mux(right.low, values[2u * i], values[2u * i + 1u]);
    }
    for (uint32_t i = 0; i < 4; ++i) {
        right_high[i] = batch_mux(right.high, right_low[2u * i], right_low[2u * i + 1u]);
    }
    left_low[0] = batch_mux(left.low, right_high[0], right_high[1]);
    left_low[1] = batch_mux(left.low, right_high[2], right_high[3]);
    return batch_mux(left.high, left_low[0], left_low[1]);
}
#endif

static inline BatchValue batch_apply(
    const BatchTable *table,
    BatchValue left,
    BatchValue right
) {
    BatchValue result;
#if defined(__aarch64__)
    uint64x2_t right_low[8];
    uint64x2_t right_high[4];
    uint64x2_t left_low[2];
    uint64x2_t right_low_selector = vdupq_n_u64(right.low);
    uint64x2_t right_high_selector = vdupq_n_u64(right.high);
    uint64x2_t left_low_selector = vdupq_n_u64(left.low);
    uint64x2_t left_high_selector = vdupq_n_u64(left.high);
    for (uint32_t i = 0; i < 8; ++i) {
        uint64x2_t zero = table->output_planes[2u * i];
        uint64x2_t one = table->output_planes[2u * i + 1u];
        right_low[i] = veorq_u64(zero, vandq_u64(right_low_selector, veorq_u64(zero, one)));
    }
    for (uint32_t i = 0; i < 4; ++i) {
        uint64x2_t zero = right_low[2u * i];
        uint64x2_t one = right_low[2u * i + 1u];
        right_high[i] = veorq_u64(zero, vandq_u64(right_high_selector, veorq_u64(zero, one)));
    }
    left_low[0] = veorq_u64(
        right_high[0],
        vandq_u64(left_low_selector, veorq_u64(right_high[0], right_high[1]))
    );
    left_low[1] = veorq_u64(
        right_high[2],
        vandq_u64(left_low_selector, veorq_u64(right_high[2], right_high[3]))
    );
    uint64x2_t output = veorq_u64(
        left_low[0],
        vandq_u64(left_high_selector, veorq_u64(left_low[0], left_low[1]))
    );
    result.low = vgetq_lane_u64(output, 0);
    result.high = vgetq_lane_u64(output, 1);
#else
    result.low = batch_select16(table->output_low, left, right);
    result.high = batch_select16(table->output_high, left, right);
#endif
    return result;
}

static inline BatchValue eval_tokens_batch(
    const uint8_t *tokens,
    uint8_t length,
    const uint8_t *assignment,
    const BatchTable *table
) {
    BatchValue stack[MAX_TOKENS];
    uint8_t size = 0;
    for (uint8_t i = 0; i < length; ++i) {
        uint8_t token = tokens[i];
        if (token != UINT8_MAX) {
            uint8_t value = assignment[token];
            stack[size].low = (value & 1u) ? table->lane_mask : 0;
            stack[size].high = (value & 2u) ? table->lane_mask : 0;
            ++size;
        } else {
            BatchValue right = stack[--size];
            BatchValue left = stack[--size];
            stack[size++] = batch_apply(table, left, right);
        }
    }
    return stack[0];
}

static inline uint64_t assignment_holds_batch(
    const Equation *equation,
    const uint8_t *assignment,
    const BatchTable *table,
    uint64_t active_mask
) {
    BatchValue left = eval_tokens_batch(
        equation->left,
        equation->left_len,
        assignment,
        table
    );
    BatchValue right = eval_tokens_batch(
        equation->right,
        equation->right_len,
        assignment,
        table
    );
    return active_mask & ~((left.low ^ right.low) | (left.high ^ right.high));
}

static uint64_t equation_holds_batch(
    const Equation *equation,
    const Assignments *assignments,
    const BatchTable *table,
    uint64_t active_mask,
    uint32_t equation_index
) {
    uint64_t holds = active_mask;
    uint64_t seed = ((uint64_t)equation_index << 32) ^ UINT64_C(0xd17f1a4b9c6732e5);
    for (uint32_t probe = 0; probe < PROBE_COUNT && holds != 0; ++probe) {
        uint32_t index = (uint32_t)(splitmix64(seed + probe) % assignments->count);
        const uint8_t *assignment =
            assignments->values + (size_t)index * assignments->var_count;
        holds = assignment_holds_batch(equation, assignment, table, holds);
    }
    for (uint32_t index = 0; index < assignments->count && holds != 0; ++index) {
        const uint8_t *assignment =
            assignments->values + (size_t)index * assignments->var_count;
        holds = assignment_holds_batch(equation, assignment, table, holds);
    }
    return holds;
}

static void build_batch_table_from_ids(
    const uint32_t table_ids[BATCH_SIZE],
    uint32_t count,
    BatchTable *batch
) {
    memset(batch, 0, sizeof(*batch));
    batch->lane_mask = count == BATCH_SIZE
        ? UINT64_MAX
        : (UINT64_C(1) << count) - 1u;
    for (uint32_t lane = 0; lane < count; ++lane) {
        uint64_t lane_bit = UINT64_C(1) << lane;
        uint32_t table_id = table_ids[lane];
        for (uint32_t cell = 0; cell < TABLE_CELLS; ++cell) {
            uint32_t value = (table_id >> (2u * cell)) & 3u;
            if (value & 1u) batch->output_low[cell] |= lane_bit;
            if (value & 2u) batch->output_high[cell] |= lane_bit;
        }
    }
#if defined(__aarch64__)
    for (uint32_t cell = 0; cell < TABLE_CELLS; ++cell) {
        batch->output_planes[cell] = (uint64x2_t){
            batch->output_low[cell],
            batch->output_high[cell]
        };
    }
#endif
}

static void build_batch_table_from_cells(
    const uint8_t *tables,
    uint32_t count,
    BatchTable *batch
) {
    memset(batch, 0, sizeof(*batch));
    batch->lane_mask = count == BATCH_SIZE
        ? UINT64_MAX
        : (UINT64_C(1) << count) - 1u;
    for (uint32_t lane = 0; lane < count; ++lane) {
        uint64_t lane_bit = UINT64_C(1) << lane;
        const uint8_t *table = tables + (size_t)lane * TABLE_CELLS;
        for (uint32_t cell = 0; cell < TABLE_CELLS; ++cell) {
            uint8_t value = table[cell];
            if (value & 1u) batch->output_low[cell] |= lane_bit;
            if (value & 2u) batch->output_high[cell] |= lane_bit;
        }
    }
#if defined(__aarch64__)
    for (uint32_t cell = 0; cell < TABLE_CELLS; ++cell) {
        batch->output_planes[cell] = (uint64x2_t){
            batch->output_low[cell],
            batch->output_high[cell]
        };
    }
#endif
}

static void generate_permutations_recursive(
    uint8_t current[ORDER],
    uint8_t used_mask,
    uint32_t depth
) {
    if (depth == ORDER) {
        memcpy(permutations[permutation_count++], current, ORDER);
        return;
    }
    for (uint8_t value = 0; value < ORDER; ++value) {
        if ((used_mask & (1u << value)) != 0) continue;
        current[depth] = value;
        generate_permutations_recursive(current, (uint8_t)(used_mask | (1u << value)), depth + 1);
    }
}

static void prepare_transform_lut(void) {
    uint8_t current[ORDER] = {0};
    permutation_count = 0;
    generate_permutations_recursive(current, 0, 0);
    if (permutation_count != 24) fail("internal permutation generation failure");
    memset(transform_lut, 0, sizeof(transform_lut));
    for (uint32_t p = 0; p < permutation_count; ++p) {
        for (uint32_t byte_position = 0; byte_position < 4; ++byte_position) {
            for (uint32_t byte_value = 0; byte_value < 256; ++byte_value) {
                uint32_t contribution = 0;
                for (uint32_t local = 0; local < 4; ++local) {
                    uint32_t old_index = byte_position * 4 + local;
                    uint8_t left = (uint8_t)(old_index / ORDER);
                    uint8_t right = (uint8_t)(old_index % ORDER);
                    uint8_t output = (uint8_t)((byte_value >> (2u * local)) & 3u);
                    uint32_t new_index =
                        (uint32_t)permutations[p][left] * ORDER + permutations[p][right];
                    uint32_t new_output = permutations[p][output];
                    contribution |= new_output << (2u * new_index);
                }
                transform_lut[p][byte_position][byte_value] = contribution;
            }
        }
    }
}

static inline uint32_t transform_table_id(uint32_t table_id, uint32_t permutation) {
    return transform_lut[permutation][0][table_id & 255u] |
           transform_lut[permutation][1][(table_id >> 8) & 255u] |
           transform_lut[permutation][2][(table_id >> 16) & 255u] |
           transform_lut[permutation][3][(table_id >> 24) & 255u];
}

static inline int is_canonical_table(uint32_t table_id) {
    for (uint32_t p = 0; p < permutation_count; ++p) {
        if (transform_table_id(table_id, p) < table_id) return 0;
    }
    return 1;
}

static inline uint32_t canonical_table_id(uint32_t table_id) {
    uint32_t minimum = table_id;
    for (uint32_t p = 0; p < permutation_count; ++p) {
        uint32_t transformed = transform_table_id(table_id, p);
        if (transformed < minimum) minimum = transformed;
    }
    return minimum;
}

static inline uint32_t opposite_table_id(uint32_t table_id) {
    uint32_t opposite = 0;
    for (uint32_t left = 0; left < ORDER; ++left) {
        for (uint32_t right = 0; right < ORDER; ++right) {
            uint32_t old_index = right * ORDER + left;
            uint32_t new_index = left * ORDER + right;
            uint32_t value = (table_id >> (2u * old_index)) & 3u;
            opposite |= value << (2u * new_index);
        }
    }
    return opposite;
}

static inline void decode_table(uint32_t table_id, uint8_t table[TABLE_CELLS]) {
    for (uint32_t i = 0; i < TABLE_CELLS; ++i) {
        table[i] = (uint8_t)((table_id >> (2u * i)) & 3u);
    }
}

static uint32_t *load_mirror_map(const char *path, uint32_t equation_count) {
    FILE *handle = fopen(path, "rb");
    if (handle == NULL) fail_errno("cannot open equation mirror map");
    char magic[8];
    if (fread(magic, 1, sizeof(magic), handle) != sizeof(magic) ||
        memcmp(magic, MIRROR_MAGIC, sizeof(magic)) != 0) {
        fail("bad equation mirror map magic");
    }
    uint32_t count = read_u32_le(handle, "mirror map count");
    if (count != equation_count) fail("mirror map equation count mismatch");
    uint32_t *mapping = checked_calloc(count, sizeof(uint32_t));
    uint8_t *seen = checked_calloc(count, 1);
    for (uint32_t i = 0; i < count; ++i) {
        mapping[i] = read_u32_le(handle, "mirror map entry");
        if (mapping[i] >= count || seen[mapping[i]]) fail("mirror map is not a permutation");
        seen[mapping[i]] = 1;
    }
    if (fgetc(handle) != EOF) fail("equation mirror map has trailing bytes");
    fclose(handle);
    free(seen);
    for (uint32_t i = 0; i < count; ++i) {
        if (mapping[mapping[i]] != i) fail("equation mirror map is not an involution");
    }
    return mapping;
}

static PairBitset load_pair_bitset(const char *path, int writable_shared) {
    PairBitset result;
    memset(&result, 0, sizeof(result));
    result.writable_shared = writable_shared;
    result.fd = open(path, writable_shared ? O_RDWR : O_RDONLY);
    if (result.fd < 0) fail_errno("cannot open 324M bitset");
    struct stat file_stat;
    if (fstat(result.fd, &file_stat) != 0) fail_errno("cannot stat 324M bitset");
    result.mapping_size = (size_t)file_stat.st_size;
    result.mapping = mmap(
        NULL,
        result.mapping_size,
        PROT_READ | PROT_WRITE,
        writable_shared ? MAP_SHARED : MAP_PRIVATE,
        result.fd,
        0
    );
    if (result.mapping == MAP_FAILED) fail_errno("cannot privately mmap 324M bitset");
    const uint8_t *header = (const uint8_t *)result.mapping;
    if (result.mapping_size < 4096 || memcmp(header, PAIR_MAGIC, 8) != 0) {
        fail("bad 324M bitset magic or length");
    }
    uint32_t version = load_u32_le(header + 16);
    result.header_bytes = load_u32_le(header + 20);
    result.equation_count = load_u32_le(header + 24);
    result.word_count = load_u32_le(header + 28);
    result.row_stride_bytes = load_u32_le(header + 32);
    uint32_t bit_order = load_u32_le(header + 36);
    result.declared_remaining = load_u64_le(header + 48);
    uint64_t payload_bytes = load_u64_le(header + 56);
    if (version != 1 || bit_order != 1 ||
        result.equation_count != EXPECTED_EQUATIONS ||
        result.word_count != EXPECTED_WORDS ||
        result.row_stride_bytes != result.word_count * 8u ||
        result.declared_remaining > EXPECTED_REMAINING ||
        payload_bytes != (uint64_t)result.equation_count * result.row_stride_bytes ||
        result.mapping_size != (size_t)result.header_bytes + payload_bytes) {
        fail("unsupported or inconsistent 324M bitset header");
    }
    result.rows = (_Atomic uint64_t *)((uint8_t *)result.mapping + result.header_bytes);
    result.active = checked_calloc(result.equation_count, 1);
    for (uint32_t source = 0; source < result.equation_count; ++source) {
        const _Atomic uint64_t *row = result.rows + (size_t)source * result.word_count;
        int nonzero = 0;
        for (uint32_t word = 0; word < result.word_count; ++word) {
            if (atomic_load_explicit(&row[word], memory_order_relaxed) != 0) {
                nonzero = 1;
                break;
            }
        }
        result.active[source] = (uint8_t)nonzero;
        result.active_count += (uint32_t)nonzero;
    }
    if (result.active_count > 41696u) fail("unexpected active source count");
    return result;
}

static uint64_t popcount_pairs(const PairBitset *pairs) {
    uint64_t total = 0;
    size_t words = (size_t)pairs->equation_count * pairs->word_count;
    for (size_t i = 0; i < words; ++i) {
        total += (uint64_t)__builtin_popcountll(
            atomic_load_explicit(&pairs->rows[i], memory_order_relaxed)
        );
    }
    return total;
}

static void checkpoint_pair_bitset(PairBitset *pairs, uint64_t remaining) {
    if (!pairs->writable_shared) return;
    if (msync(pairs->mapping, pairs->mapping_size, MS_SYNC) != 0) {
        fail_errno("cannot sync bitset payload");
    }
    store_u64_le((uint8_t *)pairs->mapping + 48, remaining);
    if (msync(pairs->mapping, pairs->header_bytes, MS_SYNC) != 0) {
        fail_errno("cannot sync bitset header");
    }
    if (fsync(pairs->fd) != 0) fail_errno("cannot fsync bitset");
    pairs->declared_remaining = remaining;
}

static void unload_pair_bitset(PairBitset *pairs) {
    free(pairs->active);
    if (munmap(pairs->mapping, pairs->mapping_size) != 0) fail_errno("cannot unmap bitset");
    close(pairs->fd);
    memset(pairs, 0, sizeof(*pairs));
}

static uint8_t *load_model_tables(const char *path, uint64_t *count_out) {
    FILE *handle = fopen(path, "rb");
    if (handle == NULL) fail_errno("cannot open model binary");
    char magic[8];
    if (fread(magic, 1, sizeof(magic), handle) != sizeof(magic) ||
        memcmp(magic, MODEL_MAGIC, sizeof(magic)) != 0) {
        fail("bad model binary magic");
    }
    uint32_t count = read_u32_le(handle, "model count");
    uint8_t *tables = checked_calloc((size_t)count, TABLE_CELLS);
    for (uint32_t model = 0; model < count; ++model) {
        int order = fgetc(handle);
        if (order != (int)ORDER) fail("model file contains non-Fin4 table");
        if (fread(tables + (size_t)model * TABLE_CELLS, 1, TABLE_CELLS, handle) != TABLE_CELLS) {
            fail("short model table");
        }
        for (uint32_t cell = 0; cell < TABLE_CELLS; ++cell) {
            if (tables[(size_t)model * TABLE_CELLS + cell] >= ORDER) {
                fail("model table value outside Fin4 carrier");
            }
        }
    }
    if (fgetc(handle) != EOF) fail("model binary has trailing bytes");
    fclose(handle);
    *count_out = count;
    return tables;
}

static uint64_t table_key_from_cells(const uint8_t table[TABLE_CELLS]) {
    uint64_t key = 0;
    for (uint32_t i = 0; i < TABLE_CELLS; ++i) key |= (uint64_t)table[i] << (2u * i);
    return key;
}

static uint32_t build_relevant_signature(
    const Shared *shared,
    const uint8_t table[TABLE_CELLS],
    uint64_t model_key,
    uint64_t signature[EXPECTED_WORDS],
    uint32_t satisfied_sources[EXPECTED_EQUATIONS]
) {
    memset(signature, 0, sizeof(uint64_t) * EXPECTED_WORDS);
    uint32_t satisfied_source_count = 0;
    for (uint32_t equation_index = 0; equation_index < shared->equation_count; ++equation_index) {
        if (!shared->pairs->active[equation_index]) continue;
        const Equation *equation = &shared->equations[equation_index];
        if (equation_holds(
                equation,
                &shared->assignments[equation->var_count],
                table,
                model_key,
                equation_index
            )) {
            signature[equation_index >> 6] |= UINT64_C(1) << (equation_index & 63u);
            satisfied_sources[satisfied_source_count++] = equation_index;
        }
    }
    if (satisfied_source_count == 0) return 0;
    for (uint32_t equation_index = 0; equation_index < shared->equation_count; ++equation_index) {
        if (shared->pairs->active[equation_index]) continue;
        const Equation *equation = &shared->equations[equation_index];
        if (equation_holds(
                equation,
                &shared->assignments[equation->var_count],
                table,
                model_key,
                equation_index
            )) {
            signature[equation_index >> 6] |= UINT64_C(1) << (equation_index & 63u);
        }
    }
    return satisfied_source_count;
}

static void apply_signature(
    PairBitset *pairs,
    const uint64_t signature[EXPECTED_WORDS],
    const uint32_t *satisfied_sources,
    uint32_t satisfied_source_count
) {
    for (uint32_t i = 0; i < satisfied_source_count; ++i) {
        uint32_t source = satisfied_sources[i];
        _Atomic uint64_t *row = pairs->rows + (size_t)source * pairs->word_count;
        for (uint32_t word = 0; word < pairs->word_count; ++word) {
            uint64_t current = atomic_load_explicit(&row[word], memory_order_relaxed);
            if ((current & ~signature[word]) != 0) {
                atomic_fetch_and_explicit(&row[word], signature[word], memory_order_relaxed);
            }
        }
    }
}

static uint32_t collect_satisfied_sources(
    const PairBitset *pairs,
    const uint64_t signature[EXPECTED_WORDS],
    uint32_t satisfied_sources[EXPECTED_EQUATIONS]
) {
    uint32_t count = 0;
    for (uint32_t source = 0; source < pairs->equation_count; ++source) {
        if (pairs->active[source] &&
            (signature[source >> 6] & (UINT64_C(1) << (source & 63u)))) {
            satisfied_sources[count++] = source;
        }
    }
    return count;
}

static void mirror_signature(
    const uint64_t signature[EXPECTED_WORDS],
    const uint32_t mirror_map[EXPECTED_EQUATIONS],
    uint64_t mirrored[EXPECTED_WORDS]
) {
    memset(mirrored, 0, sizeof(uint64_t) * EXPECTED_WORDS);
    for (uint32_t word = 0; word < EXPECTED_WORDS; ++word) {
        uint64_t bits = signature[word];
        while (bits != 0) {
            uint32_t bit = (uint32_t)__builtin_ctzll(bits);
            uint32_t equation = word * 64u + bit;
            if (equation < EXPECTED_EQUATIONS) {
                uint32_t target = mirror_map[equation];
                mirrored[target >> 6] |= UINT64_C(1) << (target & 63u);
            }
            bits &= bits - 1u;
        }
    }
}

static void process_bitslice_batch(
    BatchShared *shared,
    const uint32_t table_ids[BATCH_SIZE],
    uint32_t count,
    uint64_t derive_mask,
    uint64_t eq_masks[EXPECTED_EQUATIONS],
    uint64_t *signatures
) {
    BatchTable table;
    build_batch_table_from_ids(table_ids, count, &table);
    memset(eq_masks, 0, sizeof(uint64_t) * EXPECTED_EQUATIONS);
    derive_mask &= table.lane_mask;
    uint64_t original_relevant = 0;
    uint64_t opposite_relevant = 0;
    for (uint32_t equation_index = 0; equation_index < shared->equation_count; ++equation_index) {
        uint8_t need = shared->source_needed[equation_index];
        if (!need) continue;
        uint64_t required_mask = 0;
        if (need & 1u) required_mask |= table.lane_mask;
        if (need & 2u) required_mask |= derive_mask;
        if (required_mask == 0) {
            eq_masks[equation_index] = 0;
            continue;
        }
        const Equation *equation = &shared->equations[equation_index];
        eq_masks[equation_index] = equation_holds_batch(
            equation,
            &shared->assignments[equation->var_count],
            &table,
            required_mask,
            equation_index
        );
    }
    for (uint32_t source = 0; source < shared->equation_count; ++source) {
        if (!shared->pairs->active[source]) continue;
        original_relevant |= eq_masks[source];
        opposite_relevant |= eq_masks[shared->mirror_map[source]];
    }
    opposite_relevant &= derive_mask;
    uint64_t full_mask = original_relevant | opposite_relevant;
    atomic_fetch_add_explicit(
        &shared->signatures_evaluated,
        count,
        memory_order_relaxed
    );
    atomic_fetch_add_explicit(
        &shared->opposite_signatures_derived,
        (uint64_t)__builtin_popcountll(derive_mask),
        memory_order_relaxed
    );
    if (full_mask == 0) return;
    for (uint32_t equation_index = 0; equation_index < shared->equation_count; ++equation_index) {
        uint8_t need = shared->source_needed[equation_index];
        uint64_t computed_mask = 0;
        if (need & 1u) computed_mask |= table.lane_mask;
        if (need & 2u) computed_mask |= derive_mask;
        uint64_t missing_mask = full_mask & ~computed_mask;
        if (missing_mask == 0) continue;
        const Equation *equation = &shared->equations[equation_index];
        uint64_t additional = equation_holds_batch(
            equation,
            &shared->assignments[equation->var_count],
            &table,
            missing_mask,
            equation_index
        );
        eq_masks[equation_index] |= additional;
    }

    memset(signatures, 0, sizeof(uint64_t) * BATCH_SIZE * EXPECTED_WORDS);
    for (uint32_t equation = 0; equation < shared->equation_count; ++equation) {
        uint64_t lanes = eq_masks[equation] & full_mask;
        while (lanes != 0) {
            uint32_t lane = (uint32_t)__builtin_ctzll(lanes);
            signatures[(size_t)lane * EXPECTED_WORDS + (equation >> 6)] |=
                UINT64_C(1) << (equation & 63u);
            lanes &= lanes - 1u;
        }
    }

    uint32_t satisfied_sources[EXPECTED_EQUATIONS];
    uint64_t mirrored[EXPECTED_WORDS];
    uint64_t expanded_relevant = 0;
    uint64_t source_satisfactions = 0;
    for (uint32_t lane = 0; lane < count; ++lane) {
        uint64_t lane_bit = UINT64_C(1) << lane;
        uint64_t *signature = signatures + (size_t)lane * EXPECTED_WORDS;
        if (original_relevant & lane_bit) {
            uint32_t satisfied_count = collect_satisfied_sources(
                shared->pairs,
                signature,
                satisfied_sources
            );
            if (satisfied_count == 0) fail("bitslice original relevance inconsistency");
            apply_signature(shared->pairs, signature, satisfied_sources, satisfied_count);
            ++expanded_relevant;
            source_satisfactions += satisfied_count;
        }
        if (opposite_relevant & lane_bit) {
            mirror_signature(signature, shared->mirror_map, mirrored);
            uint32_t satisfied_count = collect_satisfied_sources(
                shared->pairs,
                mirrored,
                satisfied_sources
            );
            if (satisfied_count == 0) fail("bitslice opposite relevance inconsistency");
            apply_signature(shared->pairs, mirrored, satisfied_sources, satisfied_count);
            ++expanded_relevant;
            source_satisfactions += satisfied_count;
        }
    }
    atomic_fetch_add_explicit(
        &shared->expanded_relevant_models,
        expanded_relevant,
        memory_order_relaxed
    );
    atomic_fetch_add_explicit(
        &shared->expanded_source_satisfactions,
        source_satisfactions,
        memory_order_relaxed
    );
}

static void maybe_report_bitslice(BatchShared *shared, uint64_t done) {
    uint64_t threshold = atomic_load_explicit(&shared->next_report, memory_order_relaxed);
    while (done >= threshold) {
        if (atomic_compare_exchange_weak_explicit(
                &shared->next_report,
                &threshold,
                threshold + shared->report_interval,
                memory_order_relaxed,
                memory_order_relaxed
            )) {
            fprintf(
                stderr,
                "progress scanned=%" PRIu64 "/%" PRIu64
                " canonical=%" PRIu64 " evaluated=%" PRIu64
                " derived=%" PRIu64 " skipped=%" PRIu64 "\n",
                done,
                shared->range_count,
                atomic_load_explicit(&shared->canonical_in_range, memory_order_relaxed),
                atomic_load_explicit(&shared->signatures_evaluated, memory_order_relaxed),
                atomic_load_explicit(&shared->opposite_signatures_derived, memory_order_relaxed),
                atomic_load_explicit(&shared->skipped_as_derived, memory_order_relaxed)
            );
            fflush(stderr);
            return;
        }
    }
}

static void *bitslice_worker_main(void *raw_args) {
    BatchWorkerArgs *args = raw_args;
    BatchShared *shared = args->shared;
    (void)args->thread_id;
    uint32_t table_ids[BATCH_SIZE];
    uint32_t batch_count = 0;
    uint64_t derive_mask = 0;
    uint64_t *eq_masks = checked_calloc(EXPECTED_EQUATIONS, sizeof(uint64_t));
    uint64_t *signatures = checked_calloc(
        (size_t)BATCH_SIZE * EXPECTED_WORDS,
        sizeof(uint64_t)
    );
    for (;;) {
        uint64_t offset = atomic_fetch_add_explicit(
            &shared->next_offset,
            BATCH_WORK_BLOCK,
            memory_order_relaxed
        );
        if (offset >= shared->range_count) break;
        uint64_t block_count = BATCH_WORK_BLOCK;
        if (block_count > shared->range_count - offset) {
            block_count = shared->range_count - offset;
        }
        uint64_t local_canonical = 0;
        uint64_t local_skipped = 0;
        for (uint64_t local = 0; local < block_count; ++local) {
            uint32_t table_id = (uint32_t)(shared->range_start + offset + local);
            if (!is_canonical_table(table_id)) continue;
            ++local_canonical;
            uint32_t opposite_canonical = canonical_table_id(opposite_table_id(table_id));
            int derive = 0;
            if ((uint64_t)opposite_canonical >= shared->pair_start &&
                (uint64_t)opposite_canonical < shared->pair_end) {
                if (opposite_canonical < table_id) {
                    ++local_skipped;
                    continue;
                }
                derive = opposite_canonical > table_id;
            }
            table_ids[batch_count] = table_id;
            if (derive) derive_mask |= UINT64_C(1) << batch_count;
            ++batch_count;
            if (batch_count == BATCH_SIZE) {
                process_bitslice_batch(
                    shared,
                    table_ids,
                    batch_count,
                    derive_mask,
                    eq_masks,
                    signatures
                );
                batch_count = 0;
                derive_mask = 0;
            }
        }
        atomic_fetch_add_explicit(
            &shared->canonical_in_range,
            local_canonical,
            memory_order_relaxed
        );
        atomic_fetch_add_explicit(
            &shared->skipped_as_derived,
            local_skipped,
            memory_order_relaxed
        );
        uint64_t done = atomic_fetch_add_explicit(
            &shared->scanned,
            block_count,
            memory_order_relaxed
        ) + block_count;
        maybe_report_bitslice(shared, done);
    }
    if (batch_count != 0) {
        process_bitslice_batch(
            shared,
            table_ids,
            batch_count,
            derive_mask,
            eq_masks,
            signatures
        );
    }
    free(signatures);
    free(eq_masks);
    return NULL;
}

static void process_table(Shared *shared, const uint8_t table[TABLE_CELLS], uint64_t model_key) {
    uint64_t signature[EXPECTED_WORDS];
    uint32_t satisfied_sources[EXPECTED_EQUATIONS];
    uint32_t count = build_relevant_signature(
        shared,
        table,
        model_key,
        signature,
        satisfied_sources
    );
    if (count == 0) return;
    atomic_fetch_add_explicit(&shared->relevant_models, 1, memory_order_relaxed);
    atomic_fetch_add_explicit(&shared->source_satisfactions, count, memory_order_relaxed);
    apply_signature(shared->pairs, signature, satisfied_sources, count);
}

static void maybe_report(Shared *shared, uint64_t done) {
    uint64_t threshold = atomic_load_explicit(&shared->next_report, memory_order_relaxed);
    while (done >= threshold) {
        if (atomic_compare_exchange_weak_explicit(
                &shared->next_report,
                &threshold,
                threshold + shared->report_interval,
                memory_order_relaxed,
                memory_order_relaxed
            )) {
            fprintf(
                stderr,
                "progress scanned=%" PRIu64 "/%" PRIu64
                " canonical=%" PRIu64 " relevant=%" PRIu64 "\n",
                done,
                shared->range_count,
                atomic_load_explicit(&shared->canonical_models, memory_order_relaxed),
                atomic_load_explicit(&shared->relevant_models, memory_order_relaxed)
            );
            fflush(stderr);
            return;
        }
    }
}

static void *worker_main(void *raw_args) {
    WorkerArgs *args = raw_args;
    Shared *shared = args->shared;
    (void)args->thread_id;
    uint8_t table[TABLE_CELLS];
    for (;;) {
        uint64_t offset = atomic_fetch_add_explicit(
            &shared->next_offset,
            WORK_BLOCK,
            memory_order_relaxed
        );
        if (offset >= shared->range_count) break;
        uint64_t block_count = WORK_BLOCK;
        if (block_count > shared->range_count - offset) block_count = shared->range_count - offset;
        uint64_t local_canonical = 0;
        for (uint64_t local = 0; local < block_count; ++local) {
            uint64_t item = offset + local;
            if (shared->mode == MODE_ENUMERATE) {
                uint64_t raw_id = shared->range_start + item;
                uint32_t table_id = (uint32_t)raw_id;
                if (!is_canonical_table(table_id)) continue;
                ++local_canonical;
                decode_table(table_id, table);
                process_table(shared, table, raw_id);
            } else {
                const uint8_t *source = shared->model_tables + item * TABLE_CELLS;
                memcpy(table, source, TABLE_CELLS);
                ++local_canonical;
                process_table(shared, table, table_key_from_cells(table));
            }
        }
        atomic_fetch_add_explicit(
            &shared->canonical_models,
            local_canonical,
            memory_order_relaxed
        );
        uint64_t done = atomic_fetch_add_explicit(
            &shared->scanned,
            block_count,
            memory_order_relaxed
        ) + block_count;
        maybe_report(shared, done);
    }
    return NULL;
}

static uint32_t parse_u32(const char *raw, const char *name) {
    char *end = NULL;
    unsigned long value = strtoul(raw, &end, 10);
    if (*raw == '\0' || *end != '\0' || value == 0 || value > UINT32_MAX) {
        fprintf(stderr, "invalid %s: %s\n", name, raw);
        exit(2);
    }
    return (uint32_t)value;
}

static uint64_t parse_u64_allow_zero(const char *raw, const char *name) {
    char *end = NULL;
    errno = 0;
    unsigned long long value = strtoull(raw, &end, 10);
    if (errno != 0 || *raw == '\0' || *end != '\0') {
        fprintf(stderr, "invalid %s: %s\n", name, raw);
        exit(2);
    }
    return (uint64_t)value;
}

static void write_summary(
    const char *path,
    const char *mode,
    const Shared *shared,
    uint32_t threads,
    uint64_t initial_remaining,
    uint64_t final_remaining,
    double elapsed,
    const struct rusage *usage
) {
    FILE *handle = fopen(path, "w");
    if (handle == NULL) fail_errno("cannot open summary output");
    fprintf(
        handle,
        "{\n"
        "  \"schema_version\": 1,\n"
        "  \"status\": \"complete\",\n"
        "  \"mode\": \"%s\",\n"
        "  \"range_start\": %" PRIu64 ",\n"
        "  \"range_count\": %" PRIu64 ",\n"
        "  \"threads\": %" PRIu32 ",\n"
        "  \"equation_count\": %" PRIu32 ",\n"
        "  \"active_source_count\": %" PRIu32 ",\n"
        "  \"raw_tables_scanned\": %" PRIu64 ",\n"
        "  \"canonical_models_evaluated\": %" PRIu64 ",\n"
        "  \"relevant_models\": %" PRIu64 ",\n"
        "  \"active_source_satisfactions\": %" PRIu64 ",\n"
        "  \"initial_remaining_pairs\": %" PRIu64 ",\n"
        "  \"covered_pairs\": %" PRIu64 ",\n"
        "  \"remaining_pairs_after\": %" PRIu64 ",\n"
        "  \"elapsed_seconds\": %.9f,\n"
        "  \"user_cpu_seconds\": %.9f,\n"
        "  \"system_cpu_seconds\": %.9f,\n"
        "  \"ru_maxrss_raw\": %ld,\n"
        "  \"full_fin4_isomorphism_class_target\": %" PRIu64 "\n"
        "}\n",
        mode,
        shared->range_start,
        shared->range_count,
        threads,
        shared->equation_count,
        shared->pairs->active_count,
        atomic_load_explicit(&shared->scanned, memory_order_relaxed),
        atomic_load_explicit(&shared->canonical_models, memory_order_relaxed),
        atomic_load_explicit(&shared->relevant_models, memory_order_relaxed),
        atomic_load_explicit(&shared->source_satisfactions, memory_order_relaxed),
        initial_remaining,
        initial_remaining - final_remaining,
        final_remaining,
        elapsed,
        (double)usage->ru_utime.tv_sec + (double)usage->ru_utime.tv_usec / 1000000.0,
        (double)usage->ru_stime.tv_sec + (double)usage->ru_stime.tv_usec / 1000000.0,
        usage->ru_maxrss,
        EXPECTED_ISOMORPHISM_CLASSES
    );
    if (fflush(handle) != 0) fail_errno("cannot flush summary output");
    fclose(handle);
}

static void write_bitslice_summary(
    const char *path,
    const char *mode,
    const BatchShared *shared,
    uint32_t threads,
    uint64_t initial_remaining,
    uint64_t final_remaining,
    double elapsed,
    const struct rusage *usage
) {
    FILE *handle = fopen(path, "w");
    if (handle == NULL) fail_errno("cannot open bitslice summary output");
    uint64_t evaluated = atomic_load_explicit(
        &shared->signatures_evaluated,
        memory_order_relaxed
    );
    uint64_t derived = atomic_load_explicit(
        &shared->opposite_signatures_derived,
        memory_order_relaxed
    );
    fprintf(
        handle,
        "{\n"
        "  \"schema_version\": 1,\n"
        "  \"status\": \"complete\",\n"
        "  \"mode\": \"%s\",\n"
        "  \"batch_size\": %u,\n"
        "  \"range_start\": %" PRIu64 ",\n"
        "  \"range_count\": %" PRIu64 ",\n"
        "  \"pair_start\": %" PRIu64 ",\n"
        "  \"pair_end\": %" PRIu64 ",\n"
        "  \"threads\": %u,\n"
        "  \"equation_count\": %u,\n"
        "  \"active_source_count\": %u,\n"
        "  \"raw_tables_scanned\": %" PRIu64 ",\n"
        "  \"canonical_models_in_range\": %" PRIu64 ",\n"
        "  \"model_signatures_evaluated\": %" PRIu64 ",\n"
        "  \"opposite_signatures_derived\": %" PRIu64 ",\n"
        "  \"canonical_models_skipped_as_derived\": %" PRIu64 ",\n"
        "  \"expanded_models_accounted_now\": %" PRIu64 ",\n"
        "  \"expanded_relevant_models\": %" PRIu64 ",\n"
        "  \"expanded_source_satisfactions\": %" PRIu64 ",\n"
        "  \"initial_remaining_pairs\": %" PRIu64 ",\n"
        "  \"covered_pairs\": %" PRIu64 ",\n"
        "  \"remaining_pairs_after\": %" PRIu64 ",\n"
        "  \"elapsed_seconds\": %.9f,\n"
        "  \"user_cpu_seconds\": %.9f,\n"
        "  \"system_cpu_seconds\": %.9f,\n"
        "  \"ru_maxrss_raw\": %ld,\n"
        "  \"full_fin4_isomorphism_class_target\": %" PRIu64 ",\n"
        "  \"full_fin4_isomorphism_or_anti_isomorphism_target\": 89521056\n"
        "}\n",
        mode,
        BATCH_SIZE,
        shared->range_start,
        shared->range_count,
        shared->pair_start,
        shared->pair_end,
        threads,
        shared->equation_count,
        shared->pairs->active_count,
        atomic_load_explicit(&shared->scanned, memory_order_relaxed),
        atomic_load_explicit(&shared->canonical_in_range, memory_order_relaxed),
        evaluated,
        derived,
        atomic_load_explicit(&shared->skipped_as_derived, memory_order_relaxed),
        evaluated + derived,
        atomic_load_explicit(&shared->expanded_relevant_models, memory_order_relaxed),
        atomic_load_explicit(&shared->expanded_source_satisfactions, memory_order_relaxed),
        initial_remaining,
        initial_remaining - final_remaining,
        final_remaining,
        elapsed,
        (double)usage->ru_utime.tv_sec + (double)usage->ru_utime.tv_usec / 1000000.0,
        (double)usage->ru_stime.tv_sec + (double)usage->ru_stime.tv_usec / 1000000.0,
        usage->ru_maxrss,
        EXPECTED_ISOMORPHISM_CLASSES
    );
    if (fflush(handle) != 0) fail_errno("cannot flush bitslice summary output");
    fclose(handle);
}

static int command_self_test(void) {
    prepare_transform_lut();
    uint64_t state = UINT64_C(0x123456789abcdef0);
    for (uint32_t test = 0; test < 100000; ++test) {
        state = splitmix64(state);
        uint32_t table_id = (uint32_t)state;
        uint32_t minimum = UINT32_MAX;
        for (uint32_t p = 0; p < permutation_count; ++p) {
            uint32_t transformed = transform_table_id(table_id, p);
            if (transformed < minimum) minimum = transformed;
        }
        if (!is_canonical_table(minimum)) fail("canonicalization self-test failed");
        for (uint32_t p = 0; p < permutation_count; ++p) {
            uint32_t transformed = transform_table_id(table_id, p);
            if (is_canonical_table(transformed) != (transformed == minimum)) {
                fail("orbit minimum uniqueness self-test failed");
            }
        }
    }
    printf(
        "{\"status\":\"ok\",\"permutations\":%u,\"random_orbits\":100000,"
        "\"full_isomorphism_class_target\":%" PRIu64 "}\n",
        permutation_count,
        EXPECTED_ISOMORPHISM_CLASSES
    );
    return 0;
}

static int command_verify(int argc, char **argv) {
    if (argc != 6) {
        fail("usage: fin4_exhaustive_engine verify EQUATIONS.bin MODELS.bin SIGNATURES.bin COUNT");
    }
    uint32_t equation_count = 0;
    Equation *equations = load_equations(argv[2], &equation_count);
    Assignments assignments[MAX_VARS + 1];
    make_assignments(assignments);
    uint64_t model_count = 0;
    uint8_t *tables = load_model_tables(argv[3], &model_count);
    uint32_t verify_count = parse_u32(argv[5], "COUNT");
    if (verify_count > model_count) fail("verify COUNT exceeds model count");
    FILE *signatures = fopen(argv[4], "rb");
    if (signatures == NULL) fail_errno("cannot open signature reference");
    struct stat sig_stat;
    if (fstat(fileno(signatures), &sig_stat) != 0) fail_errno("cannot stat signature reference");
    if ((uint64_t)sig_stat.st_size != model_count * SIGNATURE_BYTES) {
        fail("signature reference size does not match model count");
    }
    uint8_t *expected = checked_calloc(SIGNATURE_BYTES, 1);
    uint8_t *actual = checked_calloc(SIGNATURE_BYTES, 1);
    for (uint32_t model = 0; model < verify_count; ++model) {
        if (fread(expected, 1, SIGNATURE_BYTES, signatures) != SIGNATURE_BYTES) {
            fail("short signature reference");
        }
        memset(actual, 0, SIGNATURE_BYTES);
        const uint8_t *table = tables + (size_t)model * TABLE_CELLS;
        uint64_t model_key = table_key_from_cells(table);
        for (uint32_t equation_index = 0; equation_index < equation_count; ++equation_index) {
            const Equation *equation = &equations[equation_index];
            if (equation_holds(
                    equation,
                    &assignments[equation->var_count],
                    table,
                    model_key,
                    equation_index
                )) {
                actual[equation_index >> 3] |= (uint8_t)(1u << (equation_index & 7u));
            }
        }
        if (memcmp(actual, expected, SIGNATURE_BYTES) != 0) {
            fprintf(stderr, "signature mismatch at model %u\n", model);
            exit(3);
        }
    }
    fclose(signatures);
    free(expected);
    free(actual);
    free(tables);
    free_assignments(assignments);
    free(equations);
    printf("{\"status\":\"ok\",\"verified_models\":%u}\n", verify_count);
    return 0;
}

static int command_verify_bitslice(int argc, char **argv) {
    if (argc != 6) {
        fail("usage: fin4_bitslice_opposite_engine verify-bitslice EQUATIONS.bin MODELS.bin SIGNATURES.bin COUNT");
    }
    uint32_t equation_count = 0;
    Equation *equations = load_equations(argv[2], &equation_count);
    Assignments assignments[MAX_VARS + 1];
    make_assignments(assignments);
    uint64_t model_count = 0;
    uint8_t *tables = load_model_tables(argv[3], &model_count);
    uint32_t verify_count = parse_u32(argv[5], "COUNT");
    if (verify_count > model_count) fail("verify-bitslice COUNT exceeds model count");
    FILE *signatures = fopen(argv[4], "rb");
    if (signatures == NULL) fail_errno("cannot open signature reference");
    struct stat sig_stat;
    if (fstat(fileno(signatures), &sig_stat) != 0) fail_errno("cannot stat signature reference");
    if ((uint64_t)sig_stat.st_size != model_count * SIGNATURE_BYTES) {
        fail("signature reference size does not match model count");
    }
    uint64_t *eq_masks = checked_calloc(equation_count, sizeof(uint64_t));
    uint8_t *expected = checked_calloc(SIGNATURE_BYTES, 1);
    uint8_t *actual = checked_calloc(SIGNATURE_BYTES, 1);
    uint32_t verified = 0;
    while (verified < verify_count) {
        uint32_t count = verify_count - verified;
        if (count > BATCH_SIZE) count = BATCH_SIZE;
        BatchTable batch;
        build_batch_table_from_cells(
            tables + (size_t)verified * TABLE_CELLS,
            count,
            &batch
        );
        for (uint32_t equation_index = 0; equation_index < equation_count; ++equation_index) {
            const Equation *equation = &equations[equation_index];
            eq_masks[equation_index] = equation_holds_batch(
                equation,
                &assignments[equation->var_count],
                &batch,
                batch.lane_mask,
                equation_index
            );
        }
        for (uint32_t lane = 0; lane < count; ++lane) {
            if (fread(expected, 1, SIGNATURE_BYTES, signatures) != SIGNATURE_BYTES) {
                fail("short signature reference");
            }
            memset(actual, 0, SIGNATURE_BYTES);
            uint64_t lane_bit = UINT64_C(1) << lane;
            for (uint32_t equation = 0; equation < equation_count; ++equation) {
                if (eq_masks[equation] & lane_bit) {
                    actual[equation >> 3] |= (uint8_t)(1u << (equation & 7u));
                }
            }
            if (memcmp(actual, expected, SIGNATURE_BYTES) != 0) {
                fprintf(stderr, "bitslice signature mismatch at model %u\n", verified + lane);
                exit(3);
            }
        }
        verified += count;
    }
    fclose(signatures);
    free(actual);
    free(expected);
    free(eq_masks);
    free(tables);
    free_assignments(assignments);
    free(equations);
    printf("{\"status\":\"ok\",\"verified_bitslice_models\":%u,\"batch_size\":%u}\n",
           verify_count, BATCH_SIZE);
    return 0;
}

static int command_enumerate_bitslice(int argc, char **argv, int writable_shared) {
    if (argc != 11) {
        fail("usage: fin4_bitslice_opposite_engine enumerate-bitslice[-inplace] EQUATIONS.bin PAIRS.bitset MIRROR.bin START COUNT PAIR_START PAIR_END THREADS SUMMARY.json");
    }
    uint32_t equation_count = 0;
    Equation *equations = load_equations(argv[2], &equation_count);
    Assignments assignments[MAX_VARS + 1];
    make_assignments(assignments);
    PairBitset pairs = load_pair_bitset(argv[3], writable_shared);
    uint64_t initial_remaining = popcount_pairs(&pairs);
    if (!writable_shared && initial_remaining != pairs.declared_remaining) {
        fail("324M payload popcount mismatch");
    }
    uint32_t *mirror_map = load_mirror_map(argv[4], equation_count);
    uint8_t *source_needed = checked_calloc(equation_count, 1);
    for (uint32_t source = 0; source < equation_count; ++source) {
        if (!pairs.active[source]) continue;
        source_needed[source] |= 1u;
        source_needed[mirror_map[source]] |= 2u;
    }

    BatchShared shared;
    memset(&shared, 0, sizeof(shared));
    shared.equations = equations;
    shared.equation_count = equation_count;
    shared.assignments = assignments;
    shared.pairs = &pairs;
    shared.mirror_map = mirror_map;
    shared.source_needed = source_needed;
    shared.range_start = parse_u64_allow_zero(argv[5], "START");
    shared.range_count = parse_u64_allow_zero(argv[6], "COUNT");
    shared.pair_start = parse_u64_allow_zero(argv[7], "PAIR_START");
    shared.pair_end = parse_u64_allow_zero(argv[8], "PAIR_END");
    const uint64_t table_universe = UINT64_C(1) << 32;
    if (shared.range_count == 0 || shared.range_start > table_universe ||
        shared.range_count > table_universe - shared.range_start) {
        fail("bitslice enumeration range is outside 2^32 Fin4 tables");
    }
    if (shared.pair_start > shared.range_start ||
        shared.pair_end < shared.range_start + shared.range_count ||
        shared.pair_end > table_universe || shared.pair_start >= shared.pair_end) {
        fail("anti-isomorphism pair interval must contain the enumeration range");
    }
    uint32_t threads = parse_u32(argv[9], "THREADS");
    if (threads > 64) fail("THREADS exceeds safety limit 64");
    const char *summary_path = argv[10];
    prepare_transform_lut();
    shared.report_interval = shared.range_count < (UINT64_C(1) << 20)
        ? shared.range_count
        : (UINT64_C(1) << 20);
    atomic_init(&shared.next_report, shared.report_interval);

    const char *mode_name = writable_shared
        ? "enumerate-bitslice-inplace"
        : "enumerate-bitslice";
    fprintf(
        stderr,
        "start mode=%s range_start=%" PRIu64 " range_count=%" PRIu64
        " pair_start=%" PRIu64 " pair_end=%" PRIu64
        " threads=%u active_sources=%u initial_remaining=%" PRIu64 "\n",
        mode_name,
        shared.range_start,
        shared.range_count,
        shared.pair_start,
        shared.pair_end,
        threads,
        pairs.active_count,
        initial_remaining
    );
    fflush(stderr);
    struct timespec started;
    struct timespec ended;
    clock_gettime(CLOCK_MONOTONIC, &started);
    pthread_t *workers = checked_calloc(threads, sizeof(pthread_t));
    BatchWorkerArgs *worker_args = checked_calloc(threads, sizeof(BatchWorkerArgs));
    for (uint32_t thread = 0; thread < threads; ++thread) {
        worker_args[thread].shared = &shared;
        worker_args[thread].thread_id = thread;
        int status = pthread_create(
            &workers[thread],
            NULL,
            bitslice_worker_main,
            &worker_args[thread]
        );
        if (status != 0) {
            errno = status;
            fail_errno("cannot create bitslice worker thread");
        }
    }
    for (uint32_t thread = 0; thread < threads; ++thread) {
        int status = pthread_join(workers[thread], NULL);
        if (status != 0) {
            errno = status;
            fail_errno("cannot join bitslice worker thread");
        }
    }
    clock_gettime(CLOCK_MONOTONIC, &ended);
    uint64_t final_remaining = popcount_pairs(&pairs);
    checkpoint_pair_bitset(&pairs, final_remaining);
    struct rusage usage;
    if (getrusage(RUSAGE_SELF, &usage) != 0) fail_errno("cannot read resource usage");
    double elapsed = elapsed_seconds(&started, &ended);
    write_bitslice_summary(
        summary_path,
        mode_name,
        &shared,
        threads,
        initial_remaining,
        final_remaining,
        elapsed,
        &usage
    );
    fprintf(
        stderr,
        "complete mode=%s scanned=%" PRIu64 " canonical=%" PRIu64
        " evaluated=%" PRIu64 " derived=%" PRIu64 " skipped=%" PRIu64
        " covered=%" PRIu64 " remaining=%" PRIu64 " elapsed=%.3f\n",
        mode_name,
        atomic_load_explicit(&shared.scanned, memory_order_relaxed),
        atomic_load_explicit(&shared.canonical_in_range, memory_order_relaxed),
        atomic_load_explicit(&shared.signatures_evaluated, memory_order_relaxed),
        atomic_load_explicit(&shared.opposite_signatures_derived, memory_order_relaxed),
        atomic_load_explicit(&shared.skipped_as_derived, memory_order_relaxed),
        initial_remaining - final_remaining,
        final_remaining,
        elapsed
    );
    free(worker_args);
    free(workers);
    free(source_needed);
    free(mirror_map);
    unload_pair_bitset(&pairs);
    free_assignments(assignments);
    free(equations);
    return 0;
}

static int command_work(int argc, char **argv, WorkMode mode, int writable_shared) {
    const char *mode_name = mode == MODE_ENUMERATE
        ? (writable_shared ? "enumerate-inplace" : "enumerate")
        : (writable_shared ? "models-inplace" : "models");
    int expected_argc = mode == MODE_ENUMERATE ? 8 : 7;
    if (argc != expected_argc) {
        if (mode == MODE_ENUMERATE) {
            fail("usage: fin4_exhaustive_engine enumerate[-inplace] EQUATIONS.bin PAIRS.bitset START COUNT THREADS SUMMARY.json");
        }
        fail("usage: fin4_exhaustive_engine models EQUATIONS.bin PAIRS.bitset MODELS.bin THREADS SUMMARY.json");
    }
    uint32_t equation_count = 0;
    Equation *equations = load_equations(argv[2], &equation_count);
    Assignments assignments[MAX_VARS + 1];
    make_assignments(assignments);
    PairBitset pairs = load_pair_bitset(argv[3], writable_shared);
    uint64_t initial_remaining = popcount_pairs(&pairs);
    if (!writable_shared && initial_remaining != pairs.declared_remaining) {
        fail("324M payload popcount mismatch");
    }

    Shared shared;
    memset(&shared, 0, sizeof(shared));
    shared.mode = mode;
    shared.equations = equations;
    shared.equation_count = equation_count;
    shared.assignments = assignments;
    shared.pairs = &pairs;
    uint32_t threads;
    const char *summary_path;
    if (mode == MODE_ENUMERATE) {
        shared.range_start = parse_u64_allow_zero(argv[4], "START");
        shared.range_count = parse_u64_allow_zero(argv[5], "COUNT");
        if (shared.range_count == 0 || shared.range_start > UINT64_C(1) << 32 ||
            shared.range_count > (UINT64_C(1) << 32) - shared.range_start) {
            fail("enumeration range is outside 2^32 Fin4 tables");
        }
        threads = parse_u32(argv[6], "THREADS");
        summary_path = argv[7];
        prepare_transform_lut();
    } else {
        shared.model_tables = load_model_tables(argv[4], &shared.model_count);
        shared.range_start = 0;
        shared.range_count = shared.model_count;
        threads = parse_u32(argv[5], "THREADS");
        summary_path = argv[6];
    }
    if (threads > 64) fail("THREADS exceeds safety limit 64");
    shared.report_interval = shared.range_count < (UINT64_C(1) << 20)
        ? shared.range_count
        : (UINT64_C(1) << 20);
    atomic_init(&shared.next_report, shared.report_interval);

    fprintf(
        stderr,
        "start mode=%s range_start=%" PRIu64 " range_count=%" PRIu64
        " threads=%u active_sources=%u initial_remaining=%" PRIu64 "\n",
        mode_name,
        shared.range_start,
        shared.range_count,
        threads,
        pairs.active_count,
        initial_remaining
    );
    fflush(stderr);
    struct timespec started;
    struct timespec ended;
    clock_gettime(CLOCK_MONOTONIC, &started);
    pthread_t *workers = checked_calloc(threads, sizeof(pthread_t));
    WorkerArgs *worker_args = checked_calloc(threads, sizeof(WorkerArgs));
    for (uint32_t thread = 0; thread < threads; ++thread) {
        worker_args[thread].shared = &shared;
        worker_args[thread].thread_id = thread;
        int status = pthread_create(&workers[thread], NULL, worker_main, &worker_args[thread]);
        if (status != 0) {
            errno = status;
            fail_errno("cannot create worker thread");
        }
    }
    for (uint32_t thread = 0; thread < threads; ++thread) {
        int status = pthread_join(workers[thread], NULL);
        if (status != 0) {
            errno = status;
            fail_errno("cannot join worker thread");
        }
    }
    clock_gettime(CLOCK_MONOTONIC, &ended);
    uint64_t final_remaining = popcount_pairs(&pairs);
    checkpoint_pair_bitset(&pairs, final_remaining);
    struct rusage usage;
    if (getrusage(RUSAGE_SELF, &usage) != 0) fail_errno("cannot read resource usage");
    double elapsed = elapsed_seconds(&started, &ended);
    write_summary(
        summary_path,
        mode_name,
        &shared,
        threads,
        initial_remaining,
        final_remaining,
        elapsed,
        &usage
    );
    fprintf(
        stderr,
        "complete mode=%s scanned=%" PRIu64 " canonical=%" PRIu64
        " relevant=%" PRIu64 " covered=%" PRIu64 " remaining=%" PRIu64
        " elapsed=%.3f\n",
        mode_name,
        atomic_load_explicit(&shared.scanned, memory_order_relaxed),
        atomic_load_explicit(&shared.canonical_models, memory_order_relaxed),
        atomic_load_explicit(&shared.relevant_models, memory_order_relaxed),
        initial_remaining - final_remaining,
        final_remaining,
        elapsed
    );
    free(workers);
    free(worker_args);
    free((void *)shared.model_tables);
    unload_pair_bitset(&pairs);
    free_assignments(assignments);
    free(equations);
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        fail("expected self-test, verify, verify-bitslice, models, enumerate, enumerate-inplace, enumerate-bitslice, or enumerate-bitslice-inplace subcommand");
    }
    if (strcmp(argv[1], "self-test") == 0) {
        if (argc != 2) fail("self-test takes no arguments");
        return command_self_test();
    }
    if (strcmp(argv[1], "verify") == 0) return command_verify(argc, argv);
    if (strcmp(argv[1], "verify-bitslice") == 0) {
        return command_verify_bitslice(argc, argv);
    }
    if (strcmp(argv[1], "models") == 0) return command_work(argc, argv, MODE_MODELS, 0);
    if (strcmp(argv[1], "models-inplace") == 0) {
        return command_work(argc, argv, MODE_MODELS, 1);
    }
    if (strcmp(argv[1], "enumerate") == 0) return command_work(argc, argv, MODE_ENUMERATE, 0);
    if (strcmp(argv[1], "enumerate-inplace") == 0) {
        return command_work(argc, argv, MODE_ENUMERATE, 1);
    }
    if (strcmp(argv[1], "enumerate-bitslice") == 0) {
        return command_enumerate_bitslice(argc, argv, 0);
    }
    if (strcmp(argv[1], "enumerate-bitslice-inplace") == 0) {
        return command_enumerate_bitslice(argc, argv, 1);
    }
    fail("unknown subcommand");
    return 2;
}
