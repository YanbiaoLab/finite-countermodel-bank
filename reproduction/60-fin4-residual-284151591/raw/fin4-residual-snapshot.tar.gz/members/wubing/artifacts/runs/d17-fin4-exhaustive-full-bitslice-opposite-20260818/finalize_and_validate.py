#!/usr/bin/env python
"""Validate and summarize the exact all-Fin4 coverage of the 324M bitset."""

from __future__ import annotations

import csv
from datetime import datetime, timezone
import hashlib
import json
import mmap
import os
from pathlib import Path
import struct


RUN_DIR = Path(__file__).resolve().parent
REPO = RUN_DIR.parents[4]
DATA_DIR = REPO / "members/wubing/data/324M_remaining_pairs"
SCALAR_DIR = RUN_DIR.parent / "d17-fin4-exhaustive-full-20260818"

ORIGINAL_BITSET = DATA_DIR / "324M_remaining_pairs.bitset"
FINAL_BITSET = RUN_DIR / "324M_after_all_fin4.bitset"
ORIGINAL_ROWS = DATA_DIR / "324M_remaining_pairs_by_source.csv"
EQUATIONS = DATA_DIR / "order5_equations.csv"
PROGRESS = RUN_DIR / "progress.json"
OUTPUT_ROWS = RUN_DIR / "fin4_coverage_by_source.csv"
OUTPUT_SUMMARY = RUN_DIR / "full_summary.json"
OUTPUT_MANIFEST = RUN_DIR / "manifest.json"

EXPECTED_ORIGINAL_SHA256 = (
    "f3cce217528adee2305e618a81a1fdb7399c6732523bb60f055b1d5acf61f383"
)
EXPECTED_ORIGINAL_REMAINING = 324_157_667
EXPECTED_EQUATIONS = 62_576
EXPECTED_PAIR_UNIVERSE = 3_915_693_200
EXPECTED_ISOMORPHISM_CLASSES = 178_981_952
EXPECTED_NEW_INTERVAL_CLASSES = 120_727_754
EXPECTED_SCALAR_CLASSES = 58_254_198
HEADER_STRUCT = struct.Struct("<16s6I3Q32s")
MAGIC = b"O5RPAIR1" + b"\0" * 8


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(8 << 20):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


class Bitset:
    def __init__(self, path: Path):
        self.path = path
        self.handle = path.open("rb")
        self.mapping = mmap.mmap(self.handle.fileno(), 0, access=mmap.ACCESS_READ)
        values = HEADER_STRUCT.unpack_from(self.mapping)
        (
            magic,
            self.version,
            self.header_bytes,
            self.equation_count,
            self.word_count,
            self.row_stride_bytes,
            self.bit_order_code,
            self.pair_universe,
            self.remaining_count,
            self.payload_bytes,
            equations_sha,
        ) = values
        if magic != MAGIC:
            raise ValueError(f"invalid magic: {path}")
        if self.version != 1 or self.bit_order_code != 1:
            raise ValueError(f"unsupported version or bit order: {path}")
        if self.row_stride_bytes != self.word_count * 8:
            raise ValueError(f"invalid row stride: {path}")
        if len(self.mapping) != self.header_bytes + self.payload_bytes:
            raise ValueError(f"invalid file length: {path}")
        self.equations_sha256 = equations_sha.hex()

    def row_offset(self, row_index: int) -> int:
        return self.header_bytes + row_index * self.row_stride_bytes

    def close(self) -> None:
        self.mapping.close()
        self.handle.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()


def load_original_rows() -> list[dict]:
    with ORIGINAL_ROWS.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != EXPECTED_EQUATIONS:
        raise ValueError("original by-source CSV row count mismatch")
    return rows


def load_equations() -> list[dict]:
    with EQUATIONS.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != EXPECTED_EQUATIONS:
        raise ValueError("equation CSV row count mismatch")
    return rows


def validate_bitsets_and_write_rows() -> dict:
    original_rows = load_original_rows()
    equation_rows = load_equations()
    output_fields = [
        "source_equation_id",
        "equation_text",
        "original_324M_target_count",
        "fin4_covered_target_count",
        "remaining_after_all_fin4_target_count",
        "fin4_coverage_percent_of_324M_source",
        "is_active_after_all_fin4",
    ]
    total_original = 0
    total_final = 0
    active_original = 0
    active_final = 0
    sources_with_fin4_coverage = 0
    top_sources: list[dict] = []
    temporary = OUTPUT_ROWS.with_suffix(".csv.tmp")
    with Bitset(ORIGINAL_BITSET) as original, Bitset(FINAL_BITSET) as final:
        metadata = (
            "version",
            "header_bytes",
            "equation_count",
            "word_count",
            "row_stride_bytes",
            "bit_order_code",
            "pair_universe",
            "payload_bytes",
            "equations_sha256",
        )
        for field in metadata:
            if getattr(original, field) != getattr(final, field):
                raise ValueError(f"bitset metadata mismatch: {field}")
        if original.equation_count != EXPECTED_EQUATIONS:
            raise ValueError("unexpected equation count")
        if original.pair_universe != EXPECTED_PAIR_UNIVERSE:
            raise ValueError("unexpected pair universe")
        valid_last_bits = original.equation_count % 64
        invalid_last_mask = (
            (~((1 << valid_last_bits) - 1)) & ((1 << 64) - 1)
            if valid_last_bits
            else 0
        )
        with temporary.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=output_fields)
            writer.writeheader()
            for row_index in range(original.equation_count):
                original_count = 0
                final_count = 0
                original_offset = original.row_offset(row_index)
                final_offset = final.row_offset(row_index)
                diagonal_word = row_index // 64
                diagonal_mask = 1 << (row_index % 64)
                for word_index in range(original.word_count):
                    offset = word_index * 8
                    original_word = struct.unpack_from(
                        "<Q", original.mapping, original_offset + offset
                    )[0]
                    final_word = struct.unpack_from(
                        "<Q", final.mapping, final_offset + offset
                    )[0]
                    if final_word & ~original_word:
                        raise ValueError(
                            f"final set is not a subset at Equation{row_index + 1}"
                        )
                    if word_index == diagonal_word and final_word & diagonal_mask:
                        raise ValueError(
                            f"diagonal bit set at Equation{row_index + 1}"
                        )
                    if (
                        word_index + 1 == original.word_count
                        and invalid_last_mask
                        and (original_word | final_word) & invalid_last_mask
                    ):
                        raise ValueError(
                            f"out-of-range target bit set at Equation{row_index + 1}"
                        )
                    original_count += original_word.bit_count()
                    final_count += final_word.bit_count()
                stated_original = int(
                    original_rows[row_index]["remaining_target_count"]
                )
                if original_count != stated_original:
                    raise ValueError(
                        f"original row count drift at Equation{row_index + 1}"
                    )
                equation_id = int(equation_rows[row_index]["equation_id"])
                if equation_id != row_index + 1:
                    raise ValueError("equation ID sequence drift")
                covered = original_count - final_count
                total_original += original_count
                total_final += final_count
                active_original += original_count > 0
                active_final += final_count > 0
                sources_with_fin4_coverage += covered > 0
                candidate = {
                    "source_equation_id": equation_id,
                    "equation_text": equation_rows[row_index]["equation_text"],
                    "original_324M_target_count": original_count,
                    "fin4_covered_target_count": covered,
                    "remaining_after_all_fin4_target_count": final_count,
                }
                if covered:
                    top_sources.append(candidate)
                writer.writerow(
                    {
                        **candidate,
                        "fin4_coverage_percent_of_324M_source": (
                            f"{covered * 100 / original_count:.12f}"
                            if original_count
                            else "0.000000000000"
                        ),
                        "is_active_after_all_fin4": int(final_count > 0),
                    }
                )
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, OUTPUT_ROWS)
        if total_original != original.remaining_count:
            raise ValueError("original header/popcount mismatch")
        if total_final != final.remaining_count:
            raise ValueError("final header/popcount mismatch")
        if total_original != EXPECTED_ORIGINAL_REMAINING:
            raise ValueError("unexpected original remaining count")
    top_sources.sort(
        key=lambda row: (-row["fin4_covered_target_count"], row["source_equation_id"])
    )
    return {
        "original_324M_pairs": total_original,
        "covered_by_all_fin4": total_original - total_final,
        "remaining_after_all_fin4": total_final,
        "coverage_percent_of_324M": (total_original - total_final)
        * 100
        / total_original,
        "active_sources_before_fin4": active_original,
        "active_sources_after_all_fin4": active_final,
        "sources_with_nonzero_fin4_coverage": sources_with_fin4_coverage,
        "top_20_sources_by_fin4_coverage": top_sources[:20],
        "diagonal_bits_checked": EXPECTED_EQUATIONS,
        "final_is_subset_of_original": True,
        "out_of_range_bits_clear": True,
    }


def validate_shards() -> dict:
    scalar = [
        json.loads((SCALAR_DIR / f"shards/shard_{index:03d}.json").read_text())
        for index in range(6)
    ]
    new = [
        json.loads((RUN_DIR / f"shards/shard_{index:03d}.json").read_text())
        for index in range(6, 256)
    ]
    all_shards = scalar + new
    expected_start = 0
    for index, item in enumerate(all_shards):
        if item["range_start"] != expected_start:
            raise ValueError(f"range gap or overlap at shard {index}")
        if item["range_count"] != 1 << 24:
            raise ValueError(f"unexpected shard size at shard {index}")
        if item["raw_tables_scanned"] != 1 << 24:
            raise ValueError(f"raw table scan mismatch at shard {index}")
        expected_start += item["range_count"]
    if expected_start != 1 << 32:
        raise ValueError("full raw table range not covered")
    scalar_classes = sum(item["canonical_models_evaluated"] for item in scalar)
    new_classes = sum(item["canonical_models_in_range"] for item in new)
    evaluated = sum(item["model_signatures_evaluated"] for item in new)
    derived = sum(item["opposite_signatures_derived"] for item in new)
    skipped = sum(item["canonical_models_skipped_as_derived"] for item in new)
    if scalar_classes != EXPECTED_SCALAR_CLASSES:
        raise ValueError("scalar class count mismatch")
    if new_classes != EXPECTED_NEW_INTERVAL_CLASSES:
        raise ValueError("new interval class count mismatch")
    if scalar_classes + new_classes != EXPECTED_ISOMORPHISM_CLASSES:
        raise ValueError("full Fin4 class count mismatch")
    if evaluated + skipped != new_classes:
        raise ValueError("evaluated/skipped class accounting mismatch")
    if evaluated + derived != EXPECTED_NEW_INTERVAL_CLASSES:
        raise ValueError("evaluated/derived signature accounting mismatch")
    progress = json.loads(PROGRESS.read_text(encoding="utf-8"))
    if (
        progress.get("status") != "complete"
        or progress.get("next_shard") != 256
        or len(progress.get("completed_shards", [])) != 250
    ):
        raise ValueError("progress checkpoint is not complete")
    return {
        "raw_labeled_tables_scanned": 1 << 32,
        "raw_range_start": 0,
        "raw_range_end_exclusive": 1 << 32,
        "shards": 256,
        "scalar_isomorphism_classes_shards_000_005": scalar_classes,
        "bitslice_interval_isomorphism_classes_shards_006_255": new_classes,
        "all_fin4_isomorphism_classes": scalar_classes + new_classes,
        "bitslice_model_signatures_evaluated": evaluated,
        "bitslice_opposite_signatures_derived": derived,
        "bitslice_classes_skipped_as_already_derived": skipped,
        "bitslice_elapsed_seconds_sum": sum(item["elapsed_seconds"] for item in new),
        "scalar_elapsed_seconds_sum": sum(item["elapsed_seconds"] for item in scalar),
        "maximum_engine_rss_bytes": max(
            item["ru_maxrss_raw"] for item in all_shards
        ),
        "ranges_contiguous_and_gapless": True,
    }


def artifact_metadata(path: Path) -> dict:
    return {"bytes": path.stat().st_size, "sha256": sha256(path)}


def main() -> None:
    original_sha = sha256(ORIGINAL_BITSET)
    if original_sha != EXPECTED_ORIGINAL_SHA256:
        raise ValueError("original 324M bitset SHA-256 mismatch")
    pair_summary = validate_bitsets_and_write_rows()
    enumeration_summary = validate_shards()
    seed_original = json.loads((RUN_DIR / "seed_known6173.json").read_text())
    seed_opposite = json.loads(
        (RUN_DIR / "seed_known6173_opposites.json").read_text()
    )
    scalar_after_committed = 308_832_762
    scalar_partial_payload = seed_original["initial_remaining_pairs"]
    stage_attribution = {
        "note": "Exact but order-dependent attribution; only the union total is intrinsic.",
        "scalar_committed_shards_000_005": EXPECTED_ORIGINAL_REMAINING
        - scalar_after_committed,
        "uncommitted_partial_shard_006_payload_reused": scalar_after_committed
        - scalar_partial_payload,
        "known_6173_models_seed": seed_original["covered_pairs"],
        "known_6173_opposite_models_seed": seed_opposite["covered_pairs"],
        "bitslice_shards_006_255_after_seeds": seed_opposite[
            "remaining_pairs_after"
        ]
        - pair_summary["remaining_after_all_fin4"],
    }
    if sum(
        value for value in stage_attribution.values() if isinstance(value, int)
    ) != pair_summary["covered_by_all_fin4"]:
        raise ValueError("stage attribution does not sum to final coverage")
    summary = {
        "schema": "d17-fin4-exhaustive-full-summary-v1",
        "status": "validated-exact",
        "generated_at": utc_now(),
        "scope": "All order-4 binary operation tables, measured on 324M directed equation pairs.",
        "pair_counts": pair_summary,
        "enumeration": enumeration_summary,
        "stage_attribution": stage_attribution,
        "validation": {
            "original_324M_sha256_verified": original_sha,
            "header_popcounts_verified": True,
            "payload_popcounts_verified_by_streaming": True,
            "diagonal_bits_all_zero": True,
            "final_bitset_is_subset_of_original_324M": True,
            "out_of_range_bits_all_zero": True,
            "all_256_raw_ranges_contiguous_and_gapless": True,
            "full_fin4_isomorphism_class_accounting_exact": True,
            "opposite_signature_accounting_exact": True,
        },
    }
    atomic_json(OUTPUT_SUMMARY, summary)
    artifacts = [
        FINAL_BITSET,
        OUTPUT_ROWS,
        OUTPUT_SUMMARY,
        PROGRESS,
        RUN_DIR / "fin4_bitslice_opposite_engine",
        RUN_DIR / "fin4_bitslice_opposite_engine.c",
        RUN_DIR / "equation_mirror_map.bin",
        RUN_DIR / "run_remaining_bitslice_opposite.py",
        RUN_DIR / "finalize_and_validate.py",
    ]
    compressed = RUN_DIR / "324M_after_all_fin4.bitset.zst"
    if compressed.exists():
        artifacts.append(compressed)
    readme = RUN_DIR / "README.md"
    if readme.exists():
        artifacts.append(readme)
    manifest = {
        "schema": "d17-fin4-exhaustive-full-manifest-v1",
        "generated_at": utc_now(),
        "status": "validated-exact",
        "inputs": {
            str(ORIGINAL_BITSET.relative_to(REPO)): {
                "bytes": ORIGINAL_BITSET.stat().st_size,
                "sha256": original_sha,
            },
            str(EQUATIONS.relative_to(REPO)): artifact_metadata(EQUATIONS),
        },
        "outputs": {
            path.name: artifact_metadata(path)
            for path in artifacts
        },
        "exact_result": {
            "original_324M_pairs": pair_summary["original_324M_pairs"],
            "covered_by_all_fin4": pair_summary["covered_by_all_fin4"],
            "remaining_after_all_fin4": pair_summary[
                "remaining_after_all_fin4"
            ],
        },
    }
    atomic_json(OUTPUT_MANIFEST, manifest)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
