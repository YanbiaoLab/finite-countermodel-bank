#!/usr/bin/env python3
"""Resume the exact Fin4 run at shard 006 with bit slicing and opposite pairing."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


RUN_DIR = Path(__file__).resolve().parent
REPO = RUN_DIR.parents[4]
ENGINE = RUN_DIR / "fin4_bitslice_opposite_engine"
EQUATIONS = REPO / "members/wubing/data/processed/jiaming/false_tail/inputs/equations.bin"
MIRROR_MAP = RUN_DIR / "equation_mirror_map.bin"
WORK_BITSET = RUN_DIR / "324M_after_all_fin4.bitset"
PROGRESS = RUN_DIR / "progress.json"
SHARDS_DIR = RUN_DIR / "shards"

EQUATIONS_SHA256 = "263b6d3fb1c6a84a4503742f11a4f2e6ac3a00a64e1f0a57fc002699ef7be7f9"
MIRROR_SHA256 = "b3f3f577c986890fc4ab7eb594396cf246c6f855107c4ff02cdbd8795865a96a"
ORIGINAL_REMAINING = 324_157_667
SCALAR_COMPLETED_SHARDS = 6
SCALAR_CANONICAL_MODELS = 58_254_198
SHARD_SIZE = 1 << 24
SHARD_COUNT = 1 << 8
PAIR_START = SCALAR_COMPLETED_SHARDS * SHARD_SIZE
PAIR_END = 1 << 32
FULL_ISOMORPHISM_CLASSES = 178_981_952


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(8 << 20):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_json(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def initialize() -> dict:
    if sha256(EQUATIONS) != EQUATIONS_SHA256:
        raise SystemExit("equation binary SHA-256 mismatch")
    if sha256(MIRROR_MAP) != MIRROR_SHA256:
        raise SystemExit("mirror map SHA-256 mismatch")
    if not ENGINE.is_file() or not WORK_BITSET.is_file():
        raise SystemExit("missing engine or work bitset")
    SHARDS_DIR.mkdir(parents=True, exist_ok=True)
    if PROGRESS.exists():
        return json.loads(PROGRESS.read_text(encoding="utf-8"))
    seed = json.loads((RUN_DIR / "seed_known6173_opposites.json").read_text())
    progress = {
        "schema": "d17-fin4-bitslice-opposite-progress-v1",
        "status": "running",
        "created_at": utc_now(),
        "updated_at": utc_now(),
        "work_bitset": WORK_BITSET.name,
        "original_remaining_pairs": ORIGINAL_REMAINING,
        "remaining_after_seeds": seed["remaining_pairs_after"],
        "scalar_completed_shards": SCALAR_COMPLETED_SHARDS,
        "scalar_canonical_models": SCALAR_CANONICAL_MODELS,
        "pair_start": PAIR_START,
        "pair_end": PAIR_END,
        "shard_size": SHARD_SIZE,
        "shard_count": SHARD_COUNT,
        "next_shard": SCALAR_COMPLETED_SHARDS,
        "completed_shards": [],
    }
    atomic_json(PROGRESS, progress)
    return progress


def run_shard(index: int, threads: int) -> dict:
    start = index * SHARD_SIZE
    summary = SHARDS_DIR / f"shard_{index:03d}.json"
    log = SHARDS_DIR / f"shard_{index:03d}.stderr.log"
    command = [
        str(ENGINE),
        "enumerate-bitslice-inplace",
        str(EQUATIONS),
        str(WORK_BITSET),
        str(MIRROR_MAP),
        str(start),
        str(SHARD_SIZE),
        str(PAIR_START),
        str(PAIR_END),
        str(threads),
        str(summary),
    ]
    print(
        f"{utc_now()} shard={index:03d}/{SHARD_COUNT - 1:03d} "
        f"range=[{start},{start + SHARD_SIZE}) starting",
        flush=True,
    )
    with log.open("a", encoding="utf-8") as stderr:
        stderr.write(f"runner_start={utc_now()} command={json.dumps(command)}\n")
        stderr.flush()
        process = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=stderr)
        last_report = 0.0
        while True:
            return_code = process.poll()
            if return_code is not None:
                break
            now = time.monotonic()
            if now - last_report >= 60:
                try:
                    rss_kib = subprocess.check_output(
                        ["ps", "-o", "rss=", "-p", str(process.pid)], text=True
                    ).strip()
                except subprocess.SubprocessError:
                    rss_kib = "unknown"
                print(
                    f"{utc_now()} shard={index:03d} child_pid={process.pid} "
                    f"rss_kib={rss_kib or 'exited'} running",
                    flush=True,
                )
                last_report = now
            time.sleep(5)
        stderr.write(f"runner_end={utc_now()} return_code={return_code}\n")
    if return_code != 0:
        raise SystemExit(f"shard {index} failed with exit code {return_code}; see {log}")
    result = json.loads(summary.read_text(encoding="utf-8"))
    if (
        result.get("status") != "complete"
        or result.get("range_start") != start
        or result.get("range_count") != SHARD_SIZE
        or result.get("raw_tables_scanned") != SHARD_SIZE
    ):
        raise SystemExit(f"shard {index} has an invalid summary")
    if (
        result["model_signatures_evaluated"]
        + result["canonical_models_skipped_as_derived"]
        != result["canonical_models_in_range"]
    ):
        raise SystemExit(f"shard {index} canonical accounting mismatch")
    print(
        f"{utc_now()} shard={index:03d} complete "
        f"canonical={result['canonical_models_in_range']} "
        f"evaluated={result['model_signatures_evaluated']} "
        f"derived={result['opposite_signatures_derived']} "
        f"skipped={result['canonical_models_skipped_as_derived']} "
        f"newly_covered={result['covered_pairs']} "
        f"remaining={result['remaining_pairs_after']} "
        f"elapsed_s={result['elapsed_seconds']:.3f}",
        flush=True,
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--threads", type=int, default=10)
    parser.add_argument("--max-shards", type=int, default=None)
    args = parser.parse_args()
    if not 1 <= args.threads <= 64:
        raise SystemExit("--threads must be in [1,64]")
    progress = initialize()
    if progress.get("schema") != "d17-fin4-bitslice-opposite-progress-v1":
        raise SystemExit("unsupported progress schema")
    next_shard = int(progress["next_shard"])
    stop = SHARD_COUNT
    if args.max_shards is not None:
        if args.max_shards < 0:
            raise SystemExit("--max-shards must be nonnegative")
        stop = min(stop, next_shard + args.max_shards)
    for index in range(next_shard, stop):
        result = run_shard(index, args.threads)
        progress["completed_shards"].append(
            {
                "index": index,
                "range_start": index * SHARD_SIZE,
                "range_count": SHARD_SIZE,
                "summary": f"shards/shard_{index:03d}.json",
                "canonical_models_in_range": result["canonical_models_in_range"],
                "model_signatures_evaluated": result["model_signatures_evaluated"],
                "opposite_signatures_derived": result["opposite_signatures_derived"],
                "canonical_models_skipped_as_derived": result[
                    "canonical_models_skipped_as_derived"
                ],
                "remaining_pairs_after": result["remaining_pairs_after"],
            }
        )
        progress["next_shard"] = index + 1
        progress["updated_at"] = utc_now()
        progress["status"] = "complete" if index + 1 == SHARD_COUNT else "running"
        atomic_json(PROGRESS, progress)
    if progress["next_shard"] == SHARD_COUNT:
        results = [
            json.loads((SHARDS_DIR / f"shard_{i:03d}.json").read_text())
            for i in range(SCALAR_COMPLETED_SHARDS, SHARD_COUNT)
        ]
        canonical = SCALAR_CANONICAL_MODELS + sum(
            item["canonical_models_in_range"] for item in results
        )
        accounted = sum(
            item["model_signatures_evaluated"]
            + item["opposite_signatures_derived"]
            for item in results
        )
        expected_remaining = FULL_ISOMORPHISM_CLASSES - SCALAR_CANONICAL_MODELS
        if canonical != FULL_ISOMORPHISM_CLASSES or accounted != expected_remaining:
            raise SystemExit(
                f"final class accounting mismatch: canonical={canonical} accounted={accounted}"
            )
        print(
            f"{utc_now()} all shards complete canonical_models={canonical} "
            f"remaining_interval_accounted={accounted}",
            flush=True,
        )


if __name__ == "__main__":
    main()
