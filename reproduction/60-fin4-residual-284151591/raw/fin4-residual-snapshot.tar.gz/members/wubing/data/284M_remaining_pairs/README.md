# 284M_remaining_pairs

## 1. 这份数据是什么

本目录保存 62,576 条 order5 等式之间，在依次应用以下精确分类方法后仍然保留的有向非自反等式对：

1. 全部 Fin2 二元运算表有限反模型；
2. 全部 Fin3 二元运算表有限反模型；
3. 三类已证明的单元素坍缩（singleton collapse）源等式；
4. 全部 Fin4 二元运算表有限反模型。

一对有向等式对写作：

    (源等式 A, 目标等式 B)

方向不能交换；`(A, B)` 与 `(B, A)` 是两个不同问题。对角线 `(A, A)` 不属于候选集合。

最终精确剩余数是：

    284,151,591

本目录固定命名为 `284M_remaining_pairs`，后续可以直接用“284M”指代这份 Fin4 之后的权威剩余集合。

“剩余”只表示目前没有被上述有限反模型或单元素坍缩证明分类，不表示源等式必然推出目标等式，也不排除存在 Fin5 或更高阶有限反模型。

## 2. 284M 如何从 39 亿得到

### 2.1 初始有向非自反全集

order5 有：

    N = 62,576

排除对角线后，有向等式对全集为：

    N × (N - 1)
    = 62,576 × 62,575
    = 3,915,693,200

### 2.2 Fin2 或 Fin3 的精确反模型覆盖

全部 Fin2 与 Fin3 运算表的去重有限反模型覆盖为：

    2,285,032,108

该结果来自完整标号表枚举、代数同构约简和精确满足签名，不是抽样估计。

### 2.3 三类单元素坍缩真蕴含

三类单元素坍缩源等式去重后共有 20,879 条。每条源等式一旦成立，就证明载体只能有一个元素，因此推出任意目标等式。对应真蕴含对数为：

    20,879 × 62,575
    = 1,306,503,425

这些真蕴含对不可能同时拥有至少二元素有限反模型，因此与 Fin2/Fin3 反模型覆盖严格不相交。

### 2.4 Fin4 对 324M 的新增精确覆盖

排除 Fin2/Fin3 和单元素坍缩后，原先得到：

    324,157,667

个 `324M_remaining_pairs`。随后完整扫描全部：

    4^(4×4) = 4^16 = 4,294,967,296

张 Fin4 带标号二元运算表，按同构精确归并为：

    178,981,952

个同构类。全部 Fin4 在 324M 上新增、去重覆盖：

    40,006,076

所以最终剩余：

    324,157,667 - 40,006,076
    = 284,151,591

Fin4 的 40,006,076 是只在 324M 中计算的增量，因而按构造与前面的 Fin2/Fin3 覆盖、单元素坍缩真蕴含不重叠。Fin4 在完整 39 亿中的单独覆盖会与 Fin2/Fin3 大量重叠，不应直接加入总账。

### 2.5 最终精确分割

| 分类 | 精确等式对数 | 占初始全集 |
|---|---:|---:|
| Fin2 或 Fin3 有限反模型覆盖 | 2,285,032,108 | 58.3557493217% |
| 三类单元素坍缩真蕴含 | 1,306,503,425 | 33.3658271542% |
| Fin4 在 324M 上新增覆盖 | 40,006,076 | 1.0216856622% |
| 284M 最终剩余 | 284,151,591 | 7.2567378619% |
| 合计 | 3,915,693,200 | 100% |

全局恒等式是：

    2,285,032,108
    + 1,306,503,425
    + 40,006,076
    + 284,151,591
    = 3,915,693,200

## 3. Fin4 结果为何是精确的

Fin4 全量结果来自：

`members/wubing/artifacts/runs/d17-fin4-exhaustive-full-bitslice-opposite-20260818/`

正式计算采用以下不改变语义的精确约简和加速：

- 扫描完整 `[0, 2^32)` 原始表编码范围；
- 载体重标号下只求值同构类代表；
- 用 64 模型位切片（bit slicing）同时求值 64 个模型；
- 对互为对偶的代数，用 order5 等式镜像置换精确导出完整满足签名；
- 对每个等式仍穷举全部变量赋值，没有概率哈希或抽样；
- 通过 256 个大小为 `2^24` 的连续分片建立检查点；
- 最终独立流式复算位图 popcount、子集关系、对角线、尾部位和同构类账户。

切换新引擎前还完成了冻结 6173 模型签名、256 个对偶模型、`2^16`、`2^20` 和完整 `2^24` 分片的标量/位切片逐字节对照。完整方法和性能分析见该运行目录的 `README.md`。

## 4. 文件说明

### 4.1 `284M_remaining_pairs.bitset`

这是后续计算使用的权威主数据。

文件由 4,096 字节固定头部和行优先位图负载组成。共有 62,576 行，每行对应一个源 Equation<ID>；每行包含 978 个小端 `uint64`，共 7,824 字节。

目标 EquationB 的定位规则：

    target_index = B - 1
    word_index = target_index // 64
    bit_index = target_index % 64

源 EquationA 的行偏移：

    row_offset = 4096 + (A - 1) × 7824

查询 `(EquationA, EquationB)`：

    word = little_endian_uint64_at(
        row_offset + word_index × 8
    )
    is_remaining = bool(word & (1 << bit_index))

bit = 1 表示该等式对在排除 Fin2、Fin3、三类单元素坍缩和全部 Fin4 后仍然保留；bit = 0 表示已经分类或属于对角线。

位图负载固定为：

    62,576 × 7,824 = 489,594,624 bytes

加上头部后，文件大小是 489,598,720 bytes，约 466.92 MiB。最终位图 SHA-256 为：

    03f4a7eccc7df811756fc5da361a647b49b9064f35b2b14730362fc3fb810756

### 4.2 `284M_remaining_pairs.bitset.zst`

权威位图的 zstd 压缩归档，适合分享和冷存储。随机查询前应先解压，不能把压缩流直接当成位图使用。

该文件大小为 1,187,187 bytes，SHA-256 为：

    857796b5cf61216cbde8e3d67b65dab5abaa9383851f283cfa80b6f76d6b9b5d

### 4.3 `284M_remaining_pairs_by_source.csv`

这是 62,576 行的逐源统计和位图索引，不是 2.84 亿行明细。

| 字段 | 含义 |
|---|---|
| source_equation_id | 从 1 开始的源 Equation<ID> |
| bitmap_row_index | 从 0 开始的位图行号 |
| bitmap_offset_bytes | 该源行在主位图中的绝对字节偏移 |
| fin23_covered_target_count | 该源被 Fin2/Fin3 覆盖的目标数 |
| singleton_true_target_count | 该源由单元素坍缩证明覆盖的目标数 |
| original_324M_target_count | Fin4 前该源在 324M 中的目标数 |
| fin4_covered_target_count | 全部 Fin4 对该源新增覆盖的目标数 |
| remaining_target_count | 全部 Fin4 后该源在 284M 中的目标数 |
| is_active_source | `remaining_target_count` 是否大于 0 |
| singleton_family_mask | 三类 singleton 家族的位掩码 |
| singleton_primary_class | 预先登记的主家族分类 |

每行必须同时满足：

    original_324M_target_count
    = fin4_covered_target_count
    + remaining_target_count

以及：

    fin23_covered_target_count
    + singleton_true_target_count
    + fin4_covered_target_count
    + remaining_target_count
    = 62,575

### 4.4 `order5_equations.csv`

保存 Equation<ID> 与原始等式文本的映射，以及变量数和左右项运算符数。共 62,576 行，与 324M 数据包中的文件逐字节相同。

### 4.5 `manifest.json`

记录精确分割、Fin4 枚举口径、输入来源、位图布局、输出文件大小和 SHA-256，以及构建与验证工具摘要。复制、解压或后续加工后，应先用该清单核对完整性。

### 4.6 工具脚本

| 文件 | 用途 |
|---|---|
| `build_284M_remaining_pairs.py` | 从已验证的 Fin4 运行产物重建稳定数据包和逐源 CSV |
| `query_284M_remaining_pairs.py` | 使用 mmap 查询、计数、抽样或导出剩余等式对 |
| `validate_284M_remaining_pairs.py` | 流式复算位图、逐源分割、324M 子集关系和清单哈希 |

## 5. 逐源概况

Fin4 前后活跃源数都是：

    41,696

即全部 Fin4 没有把任何一个原活跃源的剩余目标完全清空。共有 21,011 条源至少被 Fin4 新增覆盖一个目标。

覆盖最多的五条源为 Equation11952、Equation17177、Equation22439、Equation28578 和 Equation33850。它们在原 324M 中各有 62,575 个目标，Fin4 各覆盖 62,573 个，最终各剩余 2 个目标。

完整逐源数据以 `284M_remaining_pairs_by_source.csv` 为准。

## 6. 查询方法

查看位图元数据：

```bash
uv run --no-sync python query_284M_remaining_pairs.py info
```

判断一个等式对是否仍在 284M：

```bash
uv run --no-sync python query_284M_remaining_pairs.py \
  contains Equation104 Equation178
```

统计某个源的剩余目标数：

```bash
uv run --no-sync python query_284M_remaining_pairs.py \
  count Equation104
```

列出某个源的前 20 个剩余目标并显示等式文本：

```bash
uv run --no-sync python query_284M_remaining_pairs.py \
  targets Equation104 --limit 20 --with-text
```

导出一组源：

```bash
uv run --no-sync python query_284M_remaining_pairs.py \
  export --sources Equation104,Equation178-Equation185 \
  --output selected_pairs.csv --with-text
```

## 7. 构建和完整验证

从已验证 Fin4 运行产物重新构建：

```bash
uv run --no-sync python build_284M_remaining_pairs.py
```

执行全量流式验证：

```bash
uv run --no-sync python validate_284M_remaining_pairs.py
```

验证器会检查：

- 位图头部和逐行 popcount 合计均为 284,151,591；
- 284M 是原 324M 的逐位子集；
- Fin4 行级覆盖合计为 40,006,076；
- 62,576 个对角线全部为 0；
- 每行超出 Equation62576 的尾部无效位全部为 0；
- 每行四类分割精确合计 62,575；
- 逐源 CSV 的行号、偏移、活跃标记和全局总计一致；
- 压缩文件可完整解压；
- `manifest.json` 登记的所有数据与工具文件大小、SHA-256 一致。

构建和验证均采用流式或 mmap 读取，不会把约 467 MiB 位图整体复制进 Python 对象。

## 8. 后续使用原则

后续 Fin5、更高阶有限模型、证明器评估、抽样和剩余集合诊断，应默认以 `284M_remaining_pairs.bitset` 为权威基线。

对任意新方法，建议继续使用原位清除口径：只清除当前仍置位的等式对。这样新增贡献可以直接计算为：

    284,151,591 - 应用新方法后的剩余位图 popcount

并天然与 Fin2、Fin3、Fin4 和单元素坍缩结果去重。
