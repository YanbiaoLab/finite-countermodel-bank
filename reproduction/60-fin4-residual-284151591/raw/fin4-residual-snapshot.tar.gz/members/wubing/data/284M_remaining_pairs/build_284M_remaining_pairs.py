#!/usr/bin/env python
"""Build the stable 284M remaining-pairs package from validated Fin4 outputs."""

from __future__ import annotations

import csv
from datetime import datetime, timezone
import hashlib
import itertools
import json
import os
from pathlib import Path
import shutil
import time


RUN_DIR = Path(__file__).resolve().parent
REPO_ROOT = RUN_DIR.parents[3]
SOURCE_324_DIR = REPO_ROOT / "members/wubing/data/324M_remaining_pairs"
SOURCE_FIN4_DIR = (
    REPO_ROOT
    / "members/wubing/artifacts/runs"
    / "d17-fin4-exhaustive-full-bitslice-opposite-20260818"
)

SOURCE_BITSET = SOURCE_FIN4_DIR / "324M_after_all_fin4.bitset"
SOURCE_COMPRESSED = SOURCE_FIN4_DIR / "324M_after_all_fin4.bitset.zst"
SOURCE_FIN4_ROWS = SOURCE_FIN4_DIR / "fin4_coverage_by_source.csv"
SOURCE_324_ROWS = SOURCE_324_DIR / "324M_remaining_pairs_by_source.csv"
SOURCE_EQUATIONS = SOURCE_324_DIR / "order5_equations.csv"

BITSET_PATH = RUN_DIR / "284M_remaining_pairs.bitset"
COMPRESSED_PATH = RUN_DIR / "284M_remaining_pairs.bitset.zst"
ROWS_PATH = RUN_DIR / "284M_remaining_pairs_by_source.csv"
EQUATIONS_PATH = RUN_DIR / "order5_equations.csv"
MANIFEST_PATH = RUN_DIR / "manifest.json"

EXPECTED = {
    "equations": 62_576,
    "pair_universe": 3_915_693_200,
    "fin2_or_fin3_covered_pairs": 2_285_032_108,
    "singleton_true_pairs": 1_306_503_425,
    "original_324m_pairs": 324_157_667,
    "fin4_incremental_covered_pairs": 40_006_076,
    "remaining_pairs": 284_151_591,
    "active_source_count": 41_696,
}

EXPECTED_HASHES = {
    SOURCE_BITSET: "03f4a7eccc7df811756fc5da361a647b49b9064f35b2b14730362fc3fb810756",
    SOURCE_COMPRESSED: "857796b5cf61216cbde8e3d67b65dab5abaa9383851f283cfa80b6f76d6b9b5d",
    SOURCE_FIN4_ROWS: "b3cab90ba8f3a73278829eb2ac6898f50b9f8003ab3eecd1ff6a1e57bca6bcd7",
    SOURCE_324_ROWS: "0e00485f6a0c6c2aa53a915c99f886f5d868d566d7f9f333106c9ebec996a882",
    SOURCE_EQUATIONS: "62b9fa9d5b5fa0ef499e7a9b30ae3e244485e4cc62e996de99c39897a74bdc7c",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(8 << 20):
            digest.update(block)
    return digest.hexdigest()


def atomic_copy(source: Path, target: Path) -> None:
    partial = target.with_name(target.name + ".partial")
    if partial.exists():
        partial.unlink()
    with source.open("rb") as source_handle, partial.open("wb") as target_handle:
        shutil.copyfileobj(source_handle, target_handle, length=8 << 20)
        target_handle.flush()
        os.fsync(target_handle.fileno())
    os.replace(partial, target)


def atomic_json(path: Path, value: dict) -> None:
    partial = path.with_name(path.name + ".partial")
    with partial.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(partial, path)


def verify_sources() -> None:
    for path, expected_hash in EXPECTED_HASHES.items():
        if not path.is_file():
            raise FileNotFoundError(path)
        observed = sha256(path)
        if observed != expected_hash:
            raise ValueError(f"source SHA-256 mismatch: {path}: {observed}")
    summary = json.loads((SOURCE_FIN4_DIR / "full_summary.json").read_text())
    if summary.get("status") != "validated-exact":
        raise ValueError("Fin4 source run is not validated-exact")
    counts = summary["pair_counts"]
    if (
        counts["original_324M_pairs"] != EXPECTED["original_324m_pairs"]
        or counts["covered_by_all_fin4"]
        != EXPECTED["fin4_incremental_covered_pairs"]
        or counts["remaining_after_all_fin4"] != EXPECTED["remaining_pairs"]
    ):
        raise ValueError("Fin4 source summary count mismatch")


def write_rows_csv() -> dict:
    output_fields = [
        "source_equation_id",
        "bitmap_row_index",
        "bitmap_offset_bytes",
        "fin23_covered_target_count",
        "singleton_true_target_count",
        "original_324M_target_count",
        "fin4_covered_target_count",
        "remaining_target_count",
        "is_active_source",
        "singleton_family_mask",
        "singleton_primary_class",
    ]
    partial = ROWS_PATH.with_name(ROWS_PATH.name + ".partial")
    total_fin23 = 0
    total_singleton = 0
    total_original = 0
    total_fin4 = 0
    total_remaining = 0
    active_sources = 0
    row_count = 0
    with (
        SOURCE_324_ROWS.open(newline="", encoding="utf-8") as base_handle,
        SOURCE_FIN4_ROWS.open(newline="", encoding="utf-8") as fin4_handle,
        partial.open("w", newline="", encoding="utf-8") as output_handle,
    ):
        base_rows = csv.DictReader(base_handle)
        fin4_rows = csv.DictReader(fin4_handle)
        writer = csv.DictWriter(output_handle, fieldnames=output_fields)
        writer.writeheader()
        for expected_id, pair in enumerate(
            itertools.zip_longest(base_rows, fin4_rows), start=1
        ):
            base, fin4 = pair
            if base is None or fin4 is None:
                raise ValueError("source CSV row count mismatch")
            source_id = int(base["source_equation_id"])
            if source_id != expected_id or int(fin4["source_equation_id"]) != source_id:
                raise ValueError(f"source ID sequence mismatch at row {expected_id}")
            fin23_count = int(base["fin23_covered_target_count"])
            singleton_count = int(base["singleton_true_target_count"])
            original_count = int(base["remaining_target_count"])
            fin4_original = int(fin4["original_324M_target_count"])
            fin4_count = int(fin4["fin4_covered_target_count"])
            remaining_count = int(
                fin4["remaining_after_all_fin4_target_count"]
            )
            if original_count != fin4_original:
                raise ValueError(f"324M row count mismatch at Equation{source_id}")
            if original_count != fin4_count + remaining_count:
                raise ValueError(f"Fin4 row partition mismatch at Equation{source_id}")
            if (
                fin23_count
                + singleton_count
                + fin4_count
                + remaining_count
                != EXPECTED["equations"] - 1
            ):
                raise ValueError(f"full row partition mismatch at Equation{source_id}")
            is_active = int(remaining_count > 0)
            if is_active != int(fin4["is_active_after_all_fin4"]):
                raise ValueError(f"active flag mismatch at Equation{source_id}")
            writer.writerow(
                {
                    "source_equation_id": source_id,
                    "bitmap_row_index": base["bitmap_row_index"],
                    "bitmap_offset_bytes": base["bitmap_offset_bytes"],
                    "fin23_covered_target_count": fin23_count,
                    "singleton_true_target_count": singleton_count,
                    "original_324M_target_count": original_count,
                    "fin4_covered_target_count": fin4_count,
                    "remaining_target_count": remaining_count,
                    "is_active_source": is_active,
                    "singleton_family_mask": base["singleton_family_mask"],
                    "singleton_primary_class": base["singleton_primary_class"],
                }
            )
            row_count += 1
            total_fin23 += fin23_count
            total_singleton += singleton_count
            total_original += original_count
            total_fin4 += fin4_count
            total_remaining += remaining_count
            active_sources += is_active
        output_handle.flush()
        os.fsync(output_handle.fileno())
    if row_count != EXPECTED["equations"]:
        raise ValueError(f"unexpected row count: {row_count}")
    observed = {
        "fin2_or_fin3_covered_pairs": total_fin23,
        "singleton_true_pairs": total_singleton,
        "original_324m_pairs": total_original,
        "fin4_incremental_covered_pairs": total_fin4,
        "remaining_pairs": total_remaining,
        "active_source_count": active_sources,
    }
    for field, value in observed.items():
        if value != EXPECTED[field]:
            raise ValueError(f"{field} mismatch: {value} != {EXPECTED[field]}")
    os.replace(partial, ROWS_PATH)
    return {"rows": row_count, **observed}


def metadata(path: Path) -> dict:
    return {"bytes": path.stat().st_size, "sha256": sha256(path)}


def relative(path: Path) -> str:
    return str(path.relative_to(REPO_ROOT))


def main() -> None:
    started = time.monotonic()
    verify_sources()
    atomic_copy(SOURCE_BITSET, BITSET_PATH)
    atomic_copy(SOURCE_COMPRESSED, COMPRESSED_PATH)
    atomic_copy(SOURCE_EQUATIONS, EQUATIONS_PATH)
    row_summary = write_rows_csv()
    if sha256(BITSET_PATH) != EXPECTED_HASHES[SOURCE_BITSET]:
        raise ValueError("copied bitset hash mismatch")
    if sha256(COMPRESSED_PATH) != EXPECTED_HASHES[SOURCE_COMPRESSED]:
        raise ValueError("copied compressed bitset hash mismatch")
    if sha256(EQUATIONS_PATH) != EXPECTED_HASHES[SOURCE_EQUATIONS]:
        raise ValueError("copied equation CSV hash mismatch")

    data_outputs = [BITSET_PATH, COMPRESSED_PATH, ROWS_PATH, EQUATIONS_PATH]
    utility_names = [
        "README.md",
        "build_284M_remaining_pairs.py",
        "query_284M_remaining_pairs.py",
        "validate_284M_remaining_pairs.py",
    ]
    utilities = {
        name: metadata(RUN_DIR / name)
        for name in utility_names
        if (RUN_DIR / name).is_file()
    }
    manifest = {
        "schema": "order5-284m-remaining-directed-pairs-v1",
        "created_at": utc_now(),
        "elapsed_seconds": time.monotonic() - started,
        "definition": (
            "directed nonreflexive order5 equation pairs not covered by any "
            "Fin2, Fin3, or Fin4 binary operation table and not proved true "
            "by the union of three singleton-collapse source families"
        ),
        "equations": {
            "count": EXPECTED["equations"],
            "path": "third_party/equational_theories/data/eq_size5.txt",
            "sha256": "7fb9c0e85bee412baa7030bafec311c65a75502a2c25bdd0b94171b324585b1d",
        },
        "partition": {
            "directed_nonreflexive_pair_universe": EXPECTED["pair_universe"],
            "fin2_or_fin3_covered_pairs": EXPECTED[
                "fin2_or_fin3_covered_pairs"
            ],
            "singleton_true_pairs": EXPECTED["singleton_true_pairs"],
            "fin4_incremental_covered_pairs": EXPECTED[
                "fin4_incremental_covered_pairs"
            ],
            "remaining_pairs": EXPECTED["remaining_pairs"],
            "active_source_count": EXPECTED["active_source_count"],
            "identity": (
                "fin2_or_fin3_covered_pairs + singleton_true_pairs + "
                "fin4_incremental_covered_pairs + remaining_pairs = "
                "directed_nonreflexive_pair_universe"
            ),
        },
        "fin4": {
            "labeled_tables_scanned": 4_294_967_296,
            "isomorphism_classes_accounted": 178_981_952,
            "incremental_coverage_on_324m": EXPECTED[
                "fin4_incremental_covered_pairs"
            ],
            "exactness": (
                "complete [0,2^32) table scan; isomorphism canonicalization; "
                "64-model bit slicing; exact opposite-algebra signature "
                "derivation; final bitset independently streamed and validated"
            ),
        },
        "bitset_layout": {
            "magic": "O5RPAIR1",
            "version": 1,
            "header_bytes": 4096,
            "equation_ids": "1-based; bit indexes are equation_id - 1",
            "row_order": "source equation id ascending",
            "word_count_per_row": 978,
            "row_stride_bytes": 7824,
            "word_encoding": "little-endian uint64",
            "bit_order": (
                "target equation id j uses bit ((j - 1) mod 64) in word "
                "floor((j - 1) / 64)"
            ),
            "diagonal_policy": "all (EquationA, EquationA) bits are zero",
            "set_bit_meaning": (
                "pair remains after Fin2/Fin3 countermodels, singleton-collapse "
                "proofs, and all Fin4 countermodels"
            ),
        },
        "row_summary": row_summary,
        "provenance": {
            "source_324m_manifest": relative(SOURCE_324_DIR / "manifest.json"),
            "source_fin4_manifest": relative(SOURCE_FIN4_DIR / "manifest.json"),
            "source_fin4_summary": relative(SOURCE_FIN4_DIR / "full_summary.json"),
            "source_fin4_bitset_sha256": EXPECTED_HASHES[SOURCE_BITSET],
        },
        "outputs": {path.name: metadata(path) for path in data_outputs},
        "utilities": utilities,
    }
    atomic_json(MANIFEST_PATH, manifest)
    print(
        json.dumps(
            {
                "status": "ok",
                "remaining_pairs": EXPECTED["remaining_pairs"],
                "active_sources": EXPECTED["active_source_count"],
                "outputs": {path.name: metadata(path) for path in data_outputs},
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
