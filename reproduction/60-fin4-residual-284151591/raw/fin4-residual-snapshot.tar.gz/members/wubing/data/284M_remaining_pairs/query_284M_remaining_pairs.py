#!/usr/bin/env python
"""Query and stream the 284M remaining order5 directed-pair bitset."""

from __future__ import annotations

import argparse
import csv
import json
import mmap
import random
import struct
from pathlib import Path


RUN_DIR = Path(__file__).resolve().parent
DEFAULT_BITSET = RUN_DIR / "284M_remaining_pairs.bitset"
DEFAULT_EQUATIONS = RUN_DIR / "order5_equations.csv"
HEADER_STRUCT = struct.Struct("<16s6I3Q32s")
MAGIC = b"O5RPAIR1" + b"\0" * 8


class RemainingPairs:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.handle = self.path.open("rb")
        self.mapping = mmap.mmap(
            self.handle.fileno(), length=0, access=mmap.ACCESS_READ
        )
        values = HEADER_STRUCT.unpack_from(self.mapping, 0)
        (
            magic,
            self.version,
            self.header_bytes,
            self.equation_count,
            self.word_count,
            self.row_stride_bytes,
            self.bit_order_code,
            self.pair_universe,
            self.remaining_count,
            self.payload_bytes,
            equations_sha,
        ) = values
        if magic != MAGIC:
            raise ValueError("invalid 284M remaining-pairs magic")
        if self.version != 1 or self.bit_order_code != 1:
            raise ValueError("unsupported bitset version or bit order")
        if self.row_stride_bytes != self.word_count * 8:
            raise ValueError("row stride is inconsistent with word count")
        if len(self.mapping) != self.header_bytes + self.payload_bytes:
            raise ValueError("bitset length does not match header")
        self.equations_sha256 = equations_sha.hex()

    def close(self) -> None:
        self.mapping.close()
        self.handle.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()

    def _validate_id(self, equation_id: int) -> None:
        if not 1 <= equation_id <= self.equation_count:
            raise ValueError(
                f"equation id must be in 1..{self.equation_count}"
            )

    def row_offset(self, source_id: int) -> int:
        self._validate_id(source_id)
        return self.header_bytes + (source_id - 1) * self.row_stride_bytes

    def contains(self, source_id: int, target_id: int) -> bool:
        self._validate_id(source_id)
        self._validate_id(target_id)
        target_index = target_id - 1
        word_offset = (target_index // 64) * 8
        word = struct.unpack_from(
            "<Q", self.mapping, self.row_offset(source_id) + word_offset
        )[0]
        return bool(word & (1 << (target_index % 64)))

    def target_count(self, source_id: int) -> int:
        offset = self.row_offset(source_id)
        total = 0
        for word_index in range(self.word_count):
            word = struct.unpack_from(
                "<Q", self.mapping, offset + word_index * 8
            )[0]
            total += word.bit_count()
        return total

    def targets(self, source_id: int):
        offset = self.row_offset(source_id)
        for word_index in range(self.word_count):
            word = struct.unpack_from(
                "<Q", self.mapping, offset + word_index * 8
            )[0]
            while word:
                lowest = word & -word
                bit = lowest.bit_length() - 1
                target_id = word_index * 64 + bit + 1
                if target_id <= self.equation_count:
                    yield target_id
                word ^= lowest


def parse_equation_id(value: str) -> int:
    normalized = value.strip()
    if normalized.lower().startswith("equation"):
        normalized = normalized[8:]
    return int(normalized)


def parse_sources(specification: str):
    seen = set()
    for piece in specification.split(","):
        piece = piece.strip()
        if not piece:
            continue
        if "-" in piece:
            left, right = piece.split("-", 1)
            start = parse_equation_id(left)
            end = parse_equation_id(right)
            if end < start:
                raise ValueError(f"invalid descending range: {piece}")
            values = range(start, end + 1)
        else:
            values = [parse_equation_id(piece)]
        for value in values:
            if value not in seen:
                seen.add(value)
                yield value


def load_equation_texts(path: Path) -> dict[int, str]:
    with Path(path).open(newline="", encoding="utf-8") as handle:
        return {
            int(row["equation_id"]): row["equation_text"]
            for row in csv.DictReader(handle)
        }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bitset", type=Path, default=DEFAULT_BITSET)
    parser.add_argument(
        "--equations", type=Path, default=DEFAULT_EQUATIONS
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("info")

    contains = subparsers.add_parser("contains")
    contains.add_argument("source")
    contains.add_argument("target")

    count = subparsers.add_parser("count")
    count.add_argument("source")

    targets = subparsers.add_parser("targets")
    targets.add_argument("source")
    targets.add_argument("--limit", type=int)
    targets.add_argument("--with-text", action="store_true")

    export = subparsers.add_parser("export")
    export.add_argument("--sources", required=True)
    export.add_argument("--output", type=Path, required=True)
    export.add_argument("--with-text", action="store_true")

    sample = subparsers.add_parser("sample")
    sample.add_argument("--size", type=int, required=True)
    sample.add_argument("--seed", type=int, required=True)
    sample.add_argument("--output", type=Path, required=True)
    sample.add_argument("--with-text", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    with RemainingPairs(args.bitset) as pairs:
        if args.command == "info":
            print(
                json.dumps(
                    {
                        "path": str(args.bitset),
                        "version": pairs.version,
                        "equation_count": pairs.equation_count,
                        "directed_nonreflexive_pair_universe": (
                            pairs.pair_universe
                        ),
                        "remaining_pair_count": pairs.remaining_count,
                        "header_bytes": pairs.header_bytes,
                        "row_stride_bytes": pairs.row_stride_bytes,
                        "payload_bytes": pairs.payload_bytes,
                        "equations_sha256": pairs.equations_sha256,
                    },
                    indent=2,
                )
            )
            return

        if args.command == "contains":
            source = parse_equation_id(args.source)
            target = parse_equation_id(args.target)
            print("true" if pairs.contains(source, target) else "false")
            return

        if args.command == "count":
            source = parse_equation_id(args.source)
            print(pairs.target_count(source))
            return

        if args.command == "targets":
            source = parse_equation_id(args.source)
            texts = (
                load_equation_texts(args.equations)
                if args.with_text
                else None
            )
            for index, target in enumerate(pairs.targets(source)):
                if args.limit is not None and index >= args.limit:
                    break
                if texts is None:
                    print(f"Equation{target}")
                else:
                    print(f"Equation{target}\t{texts[target]}")
            return

        texts = (
            load_equation_texts(args.equations)
            if args.with_text
            else None
        )
        fieldnames = ["source_equation_id", "target_equation_id"]
        if texts is not None:
            fieldnames += ["source_equation_text", "target_equation_text"]

        if args.command == "export":
            args.output.parent.mkdir(parents=True, exist_ok=True)
            with args.output.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=fieldnames)
                writer.writeheader()
                for source in parse_sources(args.sources):
                    for target in pairs.targets(source):
                        row = {
                            "source_equation_id": source,
                            "target_equation_id": target,
                        }
                        if texts is not None:
                            row["source_equation_text"] = texts[source]
                            row["target_equation_text"] = texts[target]
                        writer.writerow(row)
            return

        if args.size < 0:
            raise ValueError("--size must be nonnegative")
        if args.size > pairs.remaining_count:
            raise ValueError(
                f"--size cannot exceed {pairs.remaining_count}"
            )
        rng = random.Random(args.seed)
        selected = set()
        while len(selected) < args.size:
            source = rng.randint(1, pairs.equation_count)
            target = rng.randint(1, pairs.equation_count)
            if pairs.contains(source, target):
                selected.add((source, target))
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            for source, target in sorted(selected):
                row = {
                    "source_equation_id": source,
                    "target_equation_id": target,
                }
                if texts is not None:
                    row["source_equation_text"] = texts[source]
                    row["target_equation_text"] = texts[target]
                writer.writerow(row)


if __name__ == "__main__":
    main()
