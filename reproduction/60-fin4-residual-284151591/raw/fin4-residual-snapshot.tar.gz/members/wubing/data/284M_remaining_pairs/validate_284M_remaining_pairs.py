#!/usr/bin/env python
"""Full streaming validation for the stable 284M remaining-pairs package."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
import struct
import subprocess

from query_284M_remaining_pairs import RemainingPairs


RUN_DIR = Path(__file__).resolve().parent
REPO_ROOT = RUN_DIR.parents[3]
BITSET_PATH = RUN_DIR / "284M_remaining_pairs.bitset"
COMPRESSED_PATH = RUN_DIR / "284M_remaining_pairs.bitset.zst"
ROWS_PATH = RUN_DIR / "284M_remaining_pairs_by_source.csv"
EQUATIONS_PATH = RUN_DIR / "order5_equations.csv"
MANIFEST_PATH = RUN_DIR / "manifest.json"
ORIGINAL_324_BITSET = (
    REPO_ROOT
    / "members/wubing/data/324M_remaining_pairs/324M_remaining_pairs.bitset"
)

EXPECTED_EQUATIONS = 62_576
EXPECTED_REMAINING = 284_151_591
EXPECTED_FIN4_COVERAGE = 40_006_076
EXPECTED_ACTIVE_SOURCES = 41_696


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(8 << 20):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    if manifest.get("schema") != "order5-284m-remaining-directed-pairs-v1":
        raise ValueError("manifest schema mismatch")
    total = 0
    total_fin4 = 0
    active = 0
    rows_seen = 0
    with (
        RemainingPairs(BITSET_PATH) as pairs,
        RemainingPairs(ORIGINAL_324_BITSET) as original,
        ROWS_PATH.open(newline="", encoding="utf-8") as rows_handle,
    ):
        if pairs.equation_count != EXPECTED_EQUATIONS:
            raise ValueError("equation count mismatch")
        if pairs.remaining_count != EXPECTED_REMAINING:
            raise ValueError("bitset header remaining count mismatch")
        if (
            pairs.header_bytes != original.header_bytes
            or pairs.word_count != original.word_count
            or pairs.row_stride_bytes != original.row_stride_bytes
            or pairs.payload_bytes != original.payload_bytes
            or pairs.equations_sha256 != original.equations_sha256
        ):
            raise ValueError("284M/324M bitset metadata mismatch")
        invalid_bits = pairs.word_count * 64 - pairs.equation_count
        invalid_mask = (
            ((1 << invalid_bits) - 1) << (64 - invalid_bits)
            if invalid_bits
            else 0
        )
        for expected_source, row in enumerate(
            csv.DictReader(rows_handle), start=1
        ):
            rows_seen = expected_source
            if int(row["source_equation_id"]) != expected_source:
                raise ValueError("source equation sequence drift")
            expected_offset = pairs.row_offset(expected_source)
            if int(row["bitmap_row_index"]) != expected_source - 1:
                raise ValueError("bitmap row index drift")
            if int(row["bitmap_offset_bytes"]) != expected_offset:
                raise ValueError("bitmap offset drift")
            observed_count = pairs.target_count(expected_source)
            original_count = original.target_count(expected_source)
            stated_original = int(row["original_324M_target_count"])
            fin4_count = int(row["fin4_covered_target_count"])
            stated_remaining = int(row["remaining_target_count"])
            if original_count != stated_original:
                raise ValueError(
                    f"original 324M row count drift at Equation{expected_source}"
                )
            if observed_count != stated_remaining:
                raise ValueError(
                    f"284M row popcount drift at Equation{expected_source}"
                )
            if original_count != fin4_count + observed_count:
                raise ValueError(
                    f"Fin4 row partition drift at Equation{expected_source}"
                )
            partition = (
                int(row["fin23_covered_target_count"])
                + int(row["singleton_true_target_count"])
                + fin4_count
                + observed_count
            )
            if partition != pairs.equation_count - 1:
                raise ValueError(
                    f"full row partition drift at Equation{expected_source}"
                )
            if int(row["is_active_source"]) != int(observed_count > 0):
                raise ValueError("active-source flag drift")
            if pairs.contains(expected_source, expected_source):
                raise ValueError(
                    f"diagonal bit set at Equation{expected_source}"
                )
            row_offset = pairs.row_offset(expected_source)
            original_offset = original.row_offset(expected_source)
            for word_index in range(pairs.word_count):
                offset = word_index * 8
                final_word = struct.unpack_from(
                    "<Q", pairs.mapping, row_offset + offset
                )[0]
                original_word = struct.unpack_from(
                    "<Q", original.mapping, original_offset + offset
                )[0]
                if final_word & ~original_word:
                    raise ValueError(
                        f"284M is not a subset at Equation{expected_source}"
                    )
                if (
                    word_index + 1 == pairs.word_count
                    and invalid_mask
                    and final_word & invalid_mask
                ):
                    raise ValueError(
                        f"out-of-range bit set at Equation{expected_source}"
                    )
            total += observed_count
            total_fin4 += fin4_count
            active += observed_count > 0
    if rows_seen != EXPECTED_EQUATIONS:
        raise ValueError(f"row CSV length drift: {rows_seen}")
    if total != EXPECTED_REMAINING:
        raise ValueError(f"global remaining count drift: {total}")
    if total_fin4 != EXPECTED_FIN4_COVERAGE:
        raise ValueError(f"global Fin4 coverage drift: {total_fin4}")
    if active != EXPECTED_ACTIVE_SOURCES:
        raise ValueError(f"active source count drift: {active}")

    with EQUATIONS_PATH.open(newline="", encoding="utf-8") as handle:
        equations = list(csv.DictReader(handle))
    if len(equations) != EXPECTED_EQUATIONS:
        raise ValueError("equation CSV length drift")
    if [int(row["equation_id"]) for row in equations] != list(
        range(1, EXPECTED_EQUATIONS + 1)
    ):
        raise ValueError("equation ID sequence drift")

    for section in ("outputs", "utilities"):
        for filename, metadata in manifest.get(section, {}).items():
            path = RUN_DIR / filename
            if path.stat().st_size != metadata["bytes"]:
                raise ValueError(f"size drift for {filename}")
            if sha256(path) != metadata["sha256"]:
                raise ValueError(f"SHA-256 drift for {filename}")
    subprocess.run(
        ["zstd", "-t", "--no-progress", str(COMPRESSED_PATH)],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    print(
        json.dumps(
            {
                "status": "ok",
                "remaining_pairs": total,
                "fin4_incremental_coverage": total_fin4,
                "active_sources": active,
                "equations": len(equations),
                "final_is_subset_of_324m": True,
                "manifest_files_verified": sum(
                    len(manifest.get(section, {}))
                    for section in ("outputs", "utilities")
                ),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
