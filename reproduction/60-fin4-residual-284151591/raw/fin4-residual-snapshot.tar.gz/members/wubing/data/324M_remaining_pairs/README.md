# 324M_remaining_pairs

## 1. 这份数据是什么

本目录保存 62,576 条 order5 等式之间的“剩余未分类有向等式对”
（remaining unclassified directed equation pairs）。

一对有向等式对写作：

    (源等式 A, 目标等式 B)

方向不能交换；(A, B) 与 (B, A) 是两个不同问题。对角线 (A, A)
不纳入候选集合。

本数据中的一个置位表示该等式对同时满足：

1. 尚未被任意 Fin 2 或 Fin 3 二元运算表反驳；
2. 源等式不属于三类已经证明会强制单元素坍缩
   （singleton collapse）的源等式并集；
3. 源等式与目标等式不同。

“剩余”不代表蕴含成立，也不代表一定存在 Fin 4 反模型。它只表示该对尚未被
上述两类精确方法分类，适合作为后续 Fin 4 搜索、定理证明、抽样评估和模型覆盖
分析的统一候选全集。

## 2. 为什么叫 324M

最终剩余数是精确整数：

    324,157,667

通常简称约 324M。目录固定命名为 324M_remaining_pairs，便于后续直接通过
“324M”定位本数据。

## 3. 从 39 亿有向等式对到 324M

### 3.1 初始全集

order5 输入共有：

    N = 62,576

排除 62,576 个对角线对后，有向非自反等式对全集是：

    N × (N - 1)
    = 62,576 × 62,575
    = 3,915,693,200

### 3.2 Fin 2 与 Fin 3 精确有限反模型覆盖

Fin 2 包含全部：

    2^(2×2) = 16

张标号二元运算表；Fin 3 包含全部：

    3^(3×3) = 19,683

张标号二元运算表。

等式满足轮廓在载体重标号下不变，因此可以按代数同构精确约简：

- Fin 2：16 张标号表约简为 10 个同构类代表；
- Fin 3：19,683 张标号表约简为 3,330 个同构类代表。

对每个代表、每条等式，程序先使用确定性赋值探针寻找反例；只有探针未发现
反例时才穷举全部变量赋值。探针只改变搜索顺序，不改变真假结论。此前还使用
关闭探针的纯穷举版本独立复算，核心整数完全一致。

一个模型覆盖 (A, B)，当且仅当它满足 A、反驳 B。全部 Fin 2 与 Fin 3
运算表的去重并集为：

| 模型范围 | 精确覆盖数 |
|---|---:|
| Fin 2 | 2,019,519,085 |
| Fin 3 | 2,280,364,342 |
| Fin 2 与 Fin 3 的交集 | 2,014,851,319 |
| Fin 2 或 Fin 3 的并集 | 2,285,032,108 |

所以排除 Fin 2/3 已有反模型的等式对后剩余：

    3,915,693,200 - 2,285,032,108
    = 1,630,661,092

### 3.3 三类单元素坍缩真蕴含

本项目保存三类已经证明可推出单元素载体的源等式：

| 家族 | 源等式数 |
|---|---:|
| singleton_collapse | 9,342 |
| singleton_seedbank | 14,789 |
| singleton_seedbank_specialization | 20,310 |

三类存在重叠，不能直接相加。按 source bitset 精确求并集后共有：

    20,879

条不同的源等式。family_mask 的精确分布是：

| family_mask | 含义 | 源等式数 |
|---:|---|---:|
| 1 | singleton_collapse only | 569 |
| 4 | specialization only | 2,663 |
| 5 | collapse + specialization | 2,858 |
| 6 | seedbank + specialization | 8,874 |
| 7 | 三类同时命中 | 5,915 |
| 非零合计 | 三类源并集 | 20,879 |

这些源等式中的任意一条一旦成立，就能证明载体中任意两个元素相等，因此会推出
任意目标等式。每条源覆盖除自身之外的全部 62,575 个目标，去重真蕴含对数为：

    20,879 × 62,575
    = 1,306,503,425

### 3.4 为什么可以与 Fin 2/3 直接相加

Fin 2/3 集合中的每个对都有一个至少含两个元素的有限反模型：模型满足源等式，
但反驳目标等式。

三类单元素坍缩集合中的每个对都有一个普遍有效的证明：源等式强制载体成为
单元素，因此目标等式必然成立。

一个等式对不可能同时拥有反模型和有效证明，所以这两个集合严格不相交。
生成器还逐源检查单元素坍缩行的 Fin 2/3 覆盖数必须为零。

### 3.5 最终精确分割

| 分类 | 精确等式对数 | 占初始全集 |
|---|---:|---:|
| Fin 2 或 Fin 3 有限反模型覆盖 | 2,285,032,108 | 58.3557493217% |
| 三类单元素坍缩真蕴含 | 1,306,503,425 | 33.3658271542% |
| 324M 剩余未分类 | 324,157,667 | 8.2784235241% |
| 合计 | 3,915,693,200 | 100% |

全局恒等式是：

    2,285,032,108
    + 1,306,503,425
    + 324,157,667
    = 3,915,693,200

最终有 41,696 条源等式至少还保留一个目标。20,879 条 singleton 源行全部
为空；除此之外，Equation1 的整行已经被 Fin 2/3 覆盖，因此也没有剩余目标。

## 4. 文件说明

### 4.1 324M_remaining_pairs.bitset

这是后续计算使用的权威主数据。

文件由 4,096 字节固定头部和一个行优先位图负载组成。共有 62,576 行，
每行对应一个源等式；每行包含 978 个小端 uint64，共 7,824 字节。

目标 EquationB 的定位规则：

    target_index = B - 1
    word_index = target_index // 64
    bit_index = target_index % 64

源 EquationA 的行偏移：

    row_offset = 4096 + (A - 1) × 7824

查询 (EquationA, EquationB)：

    word = little_endian_uint64_at(
        row_offset + word_index × 8
    )
    is_remaining = bool(word & (1 << bit_index))

bit = 1 表示仍在 324M 集合；bit = 0 表示已被排除或属于对角线。

位图负载固定为：

    62,576 × 7,824 = 489,594,624 bytes

加上 4,096 字节头部后，未压缩文件约 466.92 MiB。虽然置位数只有
324,157,667，但随机查询需要保留它们在原始二维坐标中的位置，因此不能只用
324,157,667 bits 而不保存坐标映射。

### 4.2 324M_remaining_pairs.bitset.zst

主位图的 zstd 压缩归档。适合分享和冷存储。计算前应解压为原始 bitset；
不要直接把压缩流当作随机访问文件。

本次实际输出为 1,467,247 字节，约 1.40 MiB。压缩率很高是因为大量源行为空，
且许多 order5 等式在 Fin 2/3 上具有相同或高度相似的覆盖轮廓。权威完整性摘要
以 manifest.json 为准。

### 4.3 324M_remaining_pairs_by_source.csv

这是 62,576 行的源等式统计与位图索引，不是 3.24 亿行明细。

| 字段 | 含义 |
|---|---|
| source_equation_id | 从 1 开始的源等式编号 |
| bitmap_row_index | 从 0 开始的位图行号 |
| bitmap_offset_bytes | 该行在主位图中的绝对字节偏移 |
| fin23_covered_target_count | 该源被 Fin 2/3 覆盖的目标数 |
| singleton_true_target_count | 单元素坍缩证明覆盖的目标数，非坍缩源为 0 |
| remaining_target_count | 该源仍未分类的目标数 |
| is_active_source | remaining_target_count 是否大于 0 |
| singleton_family_mask | 三类 singleton 家族的位掩码 |
| singleton_primary_class | 预先登记的主家族分类 |

每行都必须满足：

    fin23_covered_target_count
    + singleton_true_target_count
    + remaining_target_count
    = 62,575

### 4.4 order5_equations.csv

Equation<ID> 与原始等式文本的映射，共 62,576 行。

| 字段 | 含义 |
|---|---|
| equation_id | Equation<ID> 中的 ID |
| equation_text | eq_size5.txt 中的原始文本 |
| variable_count | 不同变量数 |
| lhs_operation_count | 左项运算符数 |
| rhs_operation_count | 右项运算符数 |
| total_operation_count | 左右项运算符总数 |

### 4.5 manifest.json

记录输入文件摘要、精确分割计数、位图格式、输出文件大小和 SHA-256、
生成器版本与可复现性信息。任何复制、解压或后续加工都应先核对 manifest。

### 4.6 query_324M_remaining_pairs.py

使用 mmap 查询主位图，不会把约 467 MiB 文件整体加载进 Python 对象。

查看元数据：

    uv run --no-sync python query_324M_remaining_pairs.py info

判断一个等式对是否仍在 324M：

    uv run --no-sync python query_324M_remaining_pairs.py \
      contains Equation104 Equation178

统计某个源的剩余目标数：

    uv run --no-sync python query_324M_remaining_pairs.py \
      count Equation104

列出某个源的前 20 个剩余目标：

    uv run --no-sync python query_324M_remaining_pairs.py \
      targets Equation104 --limit 20

同时显示等式文本：

    uv run --no-sync python query_324M_remaining_pairs.py \
      targets Equation104 --limit 20 --with-text

导出指定源或源区间：

    uv run --no-sync python query_324M_remaining_pairs.py export \
      --sources 104,178,200-220 \
      --output selected_pairs.csv

固定随机种子抽样：

    uv run --no-sync python query_324M_remaining_pairs.py sample \
      --size 100000 \
      --seed 20260817 \
      --output sample_100k.csv

### 4.7 validate_324M_remaining_pairs.py

执行完整流式校验：

- 逐行重新 popcount；
- 验证全部对角线为零；
- 验证每行三分割恒等式；
- 验证全局置位数为 324,157,667；
- 验证 active source 数；
- 验证两份 CSV 的行数和编号；
- 验证 manifest 中全部输出文件的大小和 SHA-256。

运行：

    uv run --no-sync python validate_324M_remaining_pairs.py

## 5. 为什么不用 3.24 亿行 CSV

把每个等式对展开成 source_id,target_id 两列会产生 324,157,667 行：

- 未压缩体积预计数 GB；
- 文本解析与重复扫描很慢；
- 随机查询需要额外数据库索引；
- 集合交、差和 popcount 无法直接使用 CPU 位运算；
- 分布式任务会重复承担高额解析成本。

本目录采用“位图主数据 + 小型 CSV 索引 + 按需 CSV 导出”：

- 位图用于权威存储与高速集合运算；
- by_source CSV 用于浏览、排序和选择源等式；
- equations CSV 用于 Equation<ID> 到文本的映射；
- 完整明细只在具体实验需要时按源范围或随机种子导出。

## 6. 用于 Fin 4 的推荐方式

Fin 4 模型对剩余集合的新增覆盖应计算为：

    ((模型满足集合 × 模型反驳集合) ∩ 324M位图)

实现时按源行处理：

1. 判断模型是否满足当前源等式；
2. 若不满足，直接跳过该行；
3. 若满足，将模型反驳目标位图与该源的 324M 行做 AND；
4. popcount 得到新增候选覆盖；
5. 必要时用 AND-NOT 从工作副本中删除已经覆盖的位。

源行只有 7,824 字节，适合 CPU SIMD、GPU 批处理、mmap、分片和断点续算。
不要为了 Fin 4 再构造 3.24 亿行文本对。

## 7. 数据质量与解释边界

### 7.1 精确性

本数据不是抽样或估算：

- Fin 2/3 覆盖来自全部有限表，按同构只删除重复语义；
- 等式真假对探针幸存者执行全部变量赋值穷举；
- 位图集合操作使用精确 OR、NOT、AND 和 popcount；
- 三类 singleton 来源通过 bitset 精确并集；
- 生成时逐行和全局检查真假/剩余三分割。

### 7.2 仍未分类不等于真假

一个置位只能说明：

- 没有被 Fin 2/3 找到反模型；
- 不属于当前三类单元素坍缩任意目标证明。

它可能：

- 被 Fin 4 或更大有限模型反驳；
- 被无限模型反驳；
- 是真正成立的蕴含；
- 可被其他证明模板、闭包或自动定理证明器解决。

### 7.3 版本绑定

所有 Equation<ID> 都绑定 manifest 中记录的 eq_size5.txt SHA-256。若等式文件
顺序或内容变化，即使仍有 62,576 行，也不能继续沿用本位图。

## 8. 重新生成

在本目录运行：

    uv run --no-sync python build_324M_remaining_pairs.py

生成器使用分块设计：

- 约 26 MiB 的 Fin 2/3 同构代表满足轮廓；
- 每次只维护 128 个源行的覆盖状态，约 1 MiB；
- 输出位图逐行写盘；
- 不构造 3.24 亿行对象，也不在内存中保存完整 39 亿位矩阵。

最终文件摘要和精确统计写入 manifest.json。
