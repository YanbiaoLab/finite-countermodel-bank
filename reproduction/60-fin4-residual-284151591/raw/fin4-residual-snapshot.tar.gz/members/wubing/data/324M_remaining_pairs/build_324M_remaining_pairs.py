#!/usr/bin/env python
"""Build the exact 324M remaining order5 directed-pair dataset."""

from __future__ import annotations

import csv
import hashlib
import importlib.util
import itertools
import json
import os
import struct
import subprocess
import tempfile
import time
from pathlib import Path


RUN_DIR = Path(__file__).resolve().parent
REPO_ROOT = RUN_DIR.parents[3]
BASE_RUN_DIR = (
    REPO_ROOT
    / "members/wubing/artifacts/runs"
    / "d17-finite-model-order5-law-counts-20260817"
)
COUNTS_MODULE_PATH = BASE_RUN_DIR / "compute_counts.py"
C_SOURCE_PATH = RUN_DIR / "generate_324M_remaining_pairs.c"
SIGNATURE_DIR = (
    REPO_ROOT
    / "members/wubing/data/processed/jiaming/false_tail/signatures"
)
FAMILY_MASK_PATH = SIGNATURE_DIR / "singleton_family_mask.u8"
PRIMARY_CLASS_PATH = SIGNATURE_DIR / "singleton_primary.u8"
BITSET_PATH = RUN_DIR / "324M_remaining_pairs.bitset"
ROWS_CSV_PATH = RUN_DIR / "324M_remaining_pairs_by_source.csv"
EQUATIONS_CSV_PATH = RUN_DIR / "order5_equations.csv"
COMPRESSED_PATH = RUN_DIR / "324M_remaining_pairs.bitset.zst"
MANIFEST_PATH = RUN_DIR / "manifest.json"
HEADER_BYTES = 4096
HEADER_STRUCT = struct.Struct("<16s6I3Q32s")
MAGIC = b"O5RPAIR1" + b"\0" * 8
PAIR_UNIVERSE = 62_576 * 62_575
EXPECTED_REMAINING = 324_157_667


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def relabel(table: tuple[int, ...], order: int, permutation: tuple[int, ...]):
    result = [0] * (order * order)
    for left in range(order):
        for right in range(order):
            result[
                permutation[left] * order + permutation[right]
            ] = permutation[table[left * order + right]]
    return tuple(result)


def canonical(table: tuple[int, ...], order: int) -> tuple[int, ...]:
    return min(
        relabel(table, order, permutation)
        for permutation in itertools.permutations(range(order))
    )


def representatives(order: int) -> list[tuple[int, ...]]:
    return sorted(
        {
            canonical(table, order)
            for table in itertools.product(
                range(order), repeat=order * order
            )
        }
    )


def nested_table(flat: tuple[int, ...], order: int) -> list[list[int]]:
    return [
        list(flat[row * order : (row + 1) * order])
        for row in range(order)
    ]


def operation_count(term) -> int:
    if type(term) is int:
        return 0
    return 1 + operation_count(term[0]) + operation_count(term[1])


def write_equations_csv(path: Path, equation_texts, equations) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "equation_id",
                "equation_text",
                "variable_count",
                "lhs_operation_count",
                "rhs_operation_count",
                "total_operation_count",
            ],
        )
        writer.writeheader()
        for equation_id, (text, equation) in enumerate(
            zip(equation_texts, equations, strict=True),
            start=1,
        ):
            variables, lhs, rhs = equation
            lhs_count = operation_count(lhs)
            rhs_count = operation_count(rhs)
            writer.writerow(
                {
                    "equation_id": equation_id,
                    "equation_text": text,
                    "variable_count": len(variables),
                    "lhs_operation_count": lhs_count,
                    "rhs_operation_count": rhs_count,
                    "total_operation_count": lhs_count + rhs_count,
                }
            )


def write_header(path: Path, *, result: dict, equations_sha256: str) -> None:
    packed = HEADER_STRUCT.pack(
        MAGIC,
        1,
        HEADER_BYTES,
        result["equations"],
        result["word_count_per_row"],
        result["row_stride_bytes"],
        1,
        result["directed_nonreflexive_pair_universe"],
        result["remaining_pairs"],
        result["payload_bytes"],
        bytes.fromhex(equations_sha256),
    )
    if len(packed) > HEADER_BYTES:
        raise ValueError("bitset header exceeds reserved space")
    with path.open("r+b") as handle:
        handle.seek(0)
        handle.write(packed)
        handle.write(b"\0" * (HEADER_BYTES - len(packed)))


def replace_file(partial: Path, final: Path) -> None:
    os.replace(partial, final)


def main() -> None:
    started = time.time()
    counts = load_module("d17_compute_counts_for_324m", COUNTS_MODULE_PATH)
    solver = counts.load_solver()
    equation_texts = [
        line.strip()
        for line in counts.EQUATIONS_PATH.read_text(
            encoding="utf-8"
        ).splitlines()
        if line.strip()
    ]
    equations = [
        solver._parse_equation(text.replace("◇", "*"))
        for text in equation_texts
    ]
    if len(equations) != 62_576:
        raise ValueError("order5 equation count drift")

    reps2 = representatives(2)
    reps3 = representatives(3)
    if len(reps2) != 10 or len(reps3) != 3_330:
        raise ValueError("isomorphism representative count drift")
    tables = []
    for flat in reps2:
        tables.append((len(tables), nested_table(flat, 2)))
    for flat in reps3:
        tables.append((len(tables), nested_table(flat, 3)))

    bitset_partial = BITSET_PATH.with_suffix(".bitset.partial")
    rows_partial = ROWS_CSV_PATH.with_suffix(".csv.partial")
    equations_partial = EQUATIONS_CSV_PATH.with_suffix(".csv.partial")
    for partial in (bitset_partial, rows_partial, equations_partial):
        if partial.exists():
            partial.unlink()

    with tempfile.TemporaryDirectory(prefix="324m-remaining-pairs-") as temp:
        temp_dir = Path(temp)
        input_path = temp_dir / "input.bin"
        executable_path = temp_dir / "generate_324m"
        counts.write_input(input_path, equations, tables)
        subprocess.run(
            [
                "clang",
                "-O3",
                "-std=c11",
                "-Wall",
                "-Wextra",
                "-pedantic",
                str(C_SOURCE_PATH),
                "-o",
                str(executable_path),
            ],
            check=True,
        )
        completed = subprocess.run(
            [
                str(executable_path),
                str(input_path),
                str(FAMILY_MASK_PATH),
                str(PRIMARY_CLASS_PATH),
                str(bitset_partial),
                str(rows_partial),
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        print(completed.stderr, end="")
        result = json.loads(completed.stdout)

    expected = {
        "equations": 62_576,
        "models_profiled": 3_340,
        "directed_nonreflexive_pair_universe": PAIR_UNIVERSE,
        "fin2_or_fin3_covered_pairs": 2_285_032_108,
        "singleton_source_union_count": 20_879,
        "singleton_true_pairs": 1_306_503_425,
        "remaining_pairs": EXPECTED_REMAINING,
    }
    for field, value in expected.items():
        if result[field] != value:
            raise ValueError(f"{field} mismatch: {result[field]} != {value}")
    expected_size = HEADER_BYTES + result["payload_bytes"]
    if bitset_partial.stat().st_size != expected_size:
        raise ValueError("bitset file size drift")

    equations_sha = sha256(counts.EQUATIONS_PATH)
    write_header(
        bitset_partial,
        result=result,
        equations_sha256=equations_sha,
    )
    write_equations_csv(equations_partial, equation_texts, equations)
    replace_file(bitset_partial, BITSET_PATH)
    replace_file(rows_partial, ROWS_CSV_PATH)
    replace_file(equations_partial, EQUATIONS_CSV_PATH)

    subprocess.run(
        [
            "zstd",
            "-3",
            "--no-progress",
            "-f",
            str(BITSET_PATH),
            "-o",
            str(COMPRESSED_PATH),
        ],
        check=True,
    )

    finished = time.time()
    output_files = {}
    for path in (
        BITSET_PATH,
        COMPRESSED_PATH,
        ROWS_CSV_PATH,
        EQUATIONS_CSV_PATH,
    ):
        output_files[path.name] = {
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
        }
    manifest = {
        "schema": "order5-324m-remaining-directed-pairs-v1",
        "created_unix": finished,
        "elapsed_seconds": finished - started,
        "definition": (
            "directed nonreflexive order5 equation pairs not covered by any "
            "Fin 2 or Fin 3 binary operation table and not proved true by "
            "the union of three singleton-collapse source families"
        ),
        "equations": {
            "count": 62_576,
            "path": str(counts.EQUATIONS_PATH.relative_to(REPO_ROOT)),
            "sha256": equations_sha,
        },
        "fin2_fin3": {
            "labeled_tables": 16 + 19_683,
            "isomorphism_representatives_evaluated": len(tables),
            "covered_pairs": result["fin2_or_fin3_covered_pairs"],
            "exactness": (
                "deterministic probes followed by exhaustive assignment "
                "verification; exact bitset union"
            ),
        },
        "singleton_families": {
            "source_counts": {
                "singleton_collapse": 9_342,
                "singleton_seedbank": 14_789,
                "singleton_seedbank_specialization": 20_310,
            },
            "deduplicated_source_union_count": 20_879,
            "true_pairs": result["singleton_true_pairs"],
            "family_mask_path": str(FAMILY_MASK_PATH.relative_to(REPO_ROOT)),
            "family_mask_sha256": sha256(FAMILY_MASK_PATH),
            "primary_class_path": str(PRIMARY_CLASS_PATH.relative_to(REPO_ROOT)),
            "primary_class_sha256": sha256(PRIMARY_CLASS_PATH),
        },
        "partition": {
            "directed_nonreflexive_pair_universe": PAIR_UNIVERSE,
            "fin2_or_fin3_covered_pairs": result[
                "fin2_or_fin3_covered_pairs"
            ],
            "singleton_true_pairs": result["singleton_true_pairs"],
            "remaining_pairs": result["remaining_pairs"],
            "active_source_count": result["active_source_count"],
            "identity": (
                "fin2_or_fin3_covered_pairs + singleton_true_pairs + "
                "remaining_pairs = directed_nonreflexive_pair_universe"
            ),
        },
        "bitset_layout": {
            "magic": "O5RPAIR1",
            "version": 1,
            "header_bytes": HEADER_BYTES,
            "equation_ids": "1-based; bit indexes are equation_id - 1",
            "row_order": "source equation id ascending",
            "word_count_per_row": result["word_count_per_row"],
            "row_stride_bytes": result["row_stride_bytes"],
            "word_encoding": "little-endian uint64",
            "bit_order": (
                "target equation id j uses bit ((j - 1) mod 64) in "
                "word floor((j - 1) / 64)"
            ),
            "diagonal_policy": "all (EquationA, EquationA) bits are zero",
            "set_bit_meaning": "pair remains unclassified by the stated filters",
        },
        "outputs": output_files,
        "generator": {
            "python_path": str(
                Path(__file__).resolve().relative_to(REPO_ROOT)
            ),
            "python_sha256": sha256(Path(__file__)),
            "c_path": str(C_SOURCE_PATH.relative_to(REPO_ROOT)),
            "c_sha256": sha256(C_SOURCE_PATH),
        },
    }
    MANIFEST_PATH.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
