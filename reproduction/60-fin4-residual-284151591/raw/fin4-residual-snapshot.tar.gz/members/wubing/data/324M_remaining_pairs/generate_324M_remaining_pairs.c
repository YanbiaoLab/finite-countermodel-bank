#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CODE 16
#define MAX_ARITY 7
#define OP_TOKEN 255
#define PREFILTER_SAMPLES 16
#define SOURCE_CHUNK 128
#define HEADER_BYTES 4096

typedef struct {
  uint8_t arity;
  uint8_t lhs_len;
  uint8_t rhs_len;
  uint8_t lhs[MAX_CODE];
  uint8_t rhs[MAX_CODE];
} Equation;

static void die(const char *message) {
  fprintf(stderr, "%s\n", message);
  exit(2);
}

static void *checked_calloc(size_t count, size_t size) {
  void *value = calloc(count, size);
  if (!value) die("allocation failed");
  return value;
}

static uint32_t read_u32(FILE *input) {
  uint8_t bytes[4];
  if (fread(bytes, 1, 4, input) != 4) die("unexpected end of input");
  return (uint32_t)bytes[0] | ((uint32_t)bytes[1] << 8) |
         ((uint32_t)bytes[2] << 16) | ((uint32_t)bytes[3] << 24);
}

static uint8_t read_u8(FILE *input) {
  int value = fgetc(input);
  if (value == EOF) die("unexpected end of input");
  return (uint8_t)value;
}

static uint64_t splitmix64(uint64_t value) {
  value += UINT64_C(0x9e3779b97f4a7c15);
  value = (value ^ (value >> 30)) * UINT64_C(0xbf58476d1ce4e5b9);
  value = (value ^ (value >> 27)) * UINT64_C(0x94d049bb133111eb);
  return value ^ (value >> 31);
}

static uint8_t eval_term(const uint8_t *code, uint8_t code_len,
                         const uint8_t *values, const uint8_t *table,
                         uint8_t order) {
  uint8_t stack[MAX_CODE];
  uint8_t top = 0;
  for (uint8_t index = 0; index < code_len; ++index) {
    uint8_t token = code[index];
    if (token != OP_TOKEN) {
      stack[top++] = values[token];
    } else {
      uint8_t right = stack[--top];
      uint8_t left = stack[--top];
      stack[top++] = table[(size_t)left * order + right];
    }
  }
  return stack[0];
}

static void decode_assignment(uint64_t index, uint8_t order, uint8_t arity,
                              uint8_t *values) {
  for (uint8_t variable = 0; variable < arity; ++variable) {
    values[variable] = (uint8_t)(index % order);
    index /= order;
  }
}

static int assignment_holds(const Equation *equation, const uint8_t *values,
                            const uint8_t *table, uint8_t order) {
  return eval_term(equation->lhs, equation->lhs_len, values, table, order) ==
         eval_term(equation->rhs, equation->rhs_len, values, table, order);
}

static int equation_holds(const Equation *equation, const uint8_t *table,
                          uint8_t order, uint32_t model_index,
                          uint32_t equation_index) {
  uint64_t total = 1;
  uint8_t values[MAX_ARITY];
  for (uint8_t variable = 0; variable < equation->arity; ++variable) {
    total *= order;
  }
  uint64_t seed = ((uint64_t)model_index << 32) ^ equation_index;
  for (uint32_t sample = 0; sample < PREFILTER_SAMPLES; ++sample) {
    uint64_t assignment = splitmix64(seed + sample) % total;
    decode_assignment(assignment, order, equation->arity, values);
    if (!assignment_holds(equation, values, table, order)) return 0;
  }
  for (uint64_t assignment = 0; assignment < total; ++assignment) {
    decode_assignment(assignment, order, equation->arity, values);
    if (!assignment_holds(equation, values, table, order)) return 0;
  }
  return 1;
}

static uint64_t last_word_mask(uint32_t bit_count) {
  uint32_t used = bit_count % 64;
  return used == 0 ? UINT64_MAX : (UINT64_C(1) << used) - 1;
}

static uint8_t *read_exact_bytes(const char *path, size_t expected_size) {
  FILE *input = fopen(path, "rb");
  if (!input) die("cannot open signature input");
  uint8_t *bytes = checked_calloc(expected_size, 1);
  if (fread(bytes, 1, expected_size, input) != expected_size) {
    die("signature input has wrong length");
  }
  if (fgetc(input) != EOF) die("signature input has trailing bytes");
  fclose(input);
  return bytes;
}

int main(int argc, char **argv) {
  if (argc != 6) {
    die("usage: generate INPUT.bin FAMILY_MASK.u8 PRIMARY.u8 OUTPUT.bitset ROWS.csv");
  }
  FILE *input = fopen(argv[1], "rb");
  if (!input) die("cannot open input");
  char magic[8];
  if (fread(magic, 1, 8, input) != 8 ||
      memcmp(magic, "O5FMC01\0", 8) != 0) {
    die("invalid input magic");
  }
  uint32_t equation_count = read_u32(input);
  uint32_t model_count = read_u32(input);
  size_t word_count = (equation_count + 63U) / 64U;
  size_t row_stride_bytes = word_count * sizeof(uint64_t);
  uint64_t tail_mask = last_word_mask(equation_count);
  uint8_t *family_mask = read_exact_bytes(argv[2], equation_count);
  uint8_t *primary_class = read_exact_bytes(argv[3], equation_count);

  Equation *equations = checked_calloc(equation_count, sizeof(Equation));
  for (uint32_t index = 0; index < equation_count; ++index) {
    Equation *equation = &equations[index];
    equation->arity = read_u8(input);
    equation->lhs_len = read_u8(input);
    equation->rhs_len = read_u8(input);
    if (equation->arity > MAX_ARITY || equation->lhs_len > MAX_CODE ||
        equation->rhs_len > MAX_CODE) {
      die("equation exceeds compiled limits");
    }
    if (fread(equation->lhs, 1, equation->lhs_len, input) !=
            equation->lhs_len ||
        fread(equation->rhs, 1, equation->rhs_len, input) !=
            equation->rhs_len) {
      die("truncated equation payload");
    }
  }

  uint64_t *profiles =
      checked_calloc((size_t)model_count * word_count, sizeof(uint64_t));
  for (uint32_t model_index = 0; model_index < model_count; ++model_index) {
    uint8_t order = read_u8(input);
    if (order != 2 && order != 3) die("unexpected model order");
    size_t table_size = (size_t)order * order;
    uint8_t *table = checked_calloc(table_size, 1);
    if (fread(table, 1, table_size, input) != table_size) {
      die("truncated model payload");
    }
    uint64_t *profile = profiles + (size_t)model_index * word_count;
    for (uint32_t equation_index = 0; equation_index < equation_count;
         ++equation_index) {
      if (equation_holds(&equations[equation_index], table, order, model_index,
                         equation_index)) {
        profile[equation_index / 64U] |=
            UINT64_C(1) << (equation_index % 64U);
      }
    }
    free(table);
    if ((model_index + 1) % 250 == 0 || model_index + 1 == model_count) {
      fprintf(stderr, "profiled %u/%u representatives\n", model_index + 1,
              model_count);
      fflush(stderr);
    }
  }
  if (fgetc(input) != EOF) die("trailing input bytes");
  fclose(input);
  free(equations);

  FILE *bitset_output = fopen(argv[4], "wb");
  FILE *rows_output = fopen(argv[5], "w");
  if (!bitset_output || !rows_output) die("cannot open output");
  uint8_t zero_header[HEADER_BYTES] = {0};
  if (fwrite(zero_header, 1, HEADER_BYTES, bitset_output) != HEADER_BYTES) {
    die("cannot write reserved header");
  }
  fputs("source_equation_id,bitmap_row_index,bitmap_offset_bytes,"
        "fin23_covered_target_count,singleton_true_target_count,"
        "remaining_target_count,is_active_source,singleton_family_mask,"
        "singleton_primary_class\n",
        rows_output);

  uint64_t fin23_pairs = 0;
  uint64_t singleton_true_pairs = 0;
  uint64_t remaining_pairs = 0;
  uint32_t singleton_source_count = 0;
  uint32_t active_source_count = 0;
  uint64_t *zero_row = checked_calloc(word_count, sizeof(uint64_t));

  for (uint32_t chunk_start = 0; chunk_start < equation_count;
       chunk_start += SOURCE_CHUNK) {
    uint32_t chunk_size = equation_count - chunk_start;
    if (chunk_size > SOURCE_CHUNK) chunk_size = SOURCE_CHUNK;
    uint64_t *covered =
        checked_calloc((size_t)chunk_size * word_count, sizeof(uint64_t));
    for (uint32_t model_index = 0; model_index < model_count; ++model_index) {
      uint64_t *profile = profiles + (size_t)model_index * word_count;
      for (uint32_t local_source = 0; local_source < chunk_size;
           ++local_source) {
        uint32_t source = chunk_start + local_source;
        if ((profile[source / 64U] &
             (UINT64_C(1) << (source % 64U))) == 0) {
          continue;
        }
        uint64_t *source_covered =
            covered + (size_t)local_source * word_count;
        for (size_t word = 0; word < word_count; ++word) {
          uint64_t valid_mask =
              word + 1 == word_count ? tail_mask : UINT64_MAX;
          source_covered[word] |= (~profile[word]) & valid_mask;
        }
      }
    }

    for (uint32_t local_source = 0; local_source < chunk_size;
         ++local_source) {
      uint32_t source = chunk_start + local_source;
      uint64_t *source_covered =
          covered + (size_t)local_source * word_count;
      uint64_t fin23_row_count = 0;
      for (size_t word = 0; word < word_count; ++word) {
        fin23_row_count +=
            (uint64_t)__builtin_popcountll(source_covered[word]);
      }
      fin23_pairs += fin23_row_count;

      uint64_t singleton_row_count = 0;
      uint64_t remaining_row_count = 0;
      uint64_t *remaining_row = zero_row;
      if (family_mask[source] != 0) {
        ++singleton_source_count;
        singleton_row_count = equation_count - 1U;
        singleton_true_pairs += singleton_row_count;
        if (fin23_row_count != 0) {
          die("sound singleton row overlaps finite countermodel coverage");
        }
      } else {
        remaining_row = checked_calloc(word_count, sizeof(uint64_t));
        for (size_t word = 0; word < word_count; ++word) {
          uint64_t valid_mask =
              word + 1 == word_count ? tail_mask : UINT64_MAX;
          remaining_row[word] = (~source_covered[word]) & valid_mask;
        }
        remaining_row[source / 64U] &=
            ~(UINT64_C(1) << (source % 64U));
        for (size_t word = 0; word < word_count; ++word) {
          remaining_row_count +=
              (uint64_t)__builtin_popcountll(remaining_row[word]);
        }
        if (remaining_row_count > 0) ++active_source_count;
        remaining_pairs += remaining_row_count;
      }

      if (fwrite(remaining_row, sizeof(uint64_t), word_count, bitset_output) !=
          word_count) {
        die("cannot write bitset row");
      }
      uint64_t row_offset =
          HEADER_BYTES + (uint64_t)source * row_stride_bytes;
      fprintf(rows_output,
              "%u,%u,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64
              ",%u,%u,%u\n",
              source + 1U, source, row_offset, fin23_row_count,
              singleton_row_count, remaining_row_count,
              remaining_row_count > 0 ? 1U : 0U, family_mask[source],
              primary_class[source]);
      if (remaining_row != zero_row) free(remaining_row);
    }
    free(covered);
    if (chunk_start % (SOURCE_CHUNK * 50U) == 0 ||
        chunk_start + chunk_size == equation_count) {
      fprintf(stderr, "wrote source equations %u/%u\n",
              chunk_start + chunk_size, equation_count);
      fflush(stderr);
    }
  }

  if (fclose(bitset_output) != 0 || fclose(rows_output) != 0) {
    die("cannot close output");
  }
  free(zero_row);
  free(profiles);
  free(family_mask);
  free(primary_class);

  uint64_t universe =
      (uint64_t)equation_count * (uint64_t)(equation_count - 1U);
  if (fin23_pairs + singleton_true_pairs + remaining_pairs != universe) {
    die("global partition identity failed");
  }
  printf("{\n");
  printf("  \"equations\": %u,\n", equation_count);
  printf("  \"models_profiled\": %u,\n", model_count);
  printf("  \"word_count_per_row\": %zu,\n", word_count);
  printf("  \"row_stride_bytes\": %zu,\n", row_stride_bytes);
  printf("  \"payload_bytes\": %" PRIu64 ",\n",
         (uint64_t)equation_count * row_stride_bytes);
  printf("  \"directed_nonreflexive_pair_universe\": %" PRIu64 ",\n",
         universe);
  printf("  \"fin2_or_fin3_covered_pairs\": %" PRIu64 ",\n", fin23_pairs);
  printf("  \"singleton_source_union_count\": %u,\n",
         singleton_source_count);
  printf("  \"singleton_true_pairs\": %" PRIu64 ",\n",
         singleton_true_pairs);
  printf("  \"remaining_pairs\": %" PRIu64 ",\n", remaining_pairs);
  printf("  \"active_source_count\": %u\n", active_source_count);
  printf("}\n");
  return 0;
}
