#!/usr/bin/env python
"""Full streaming validation for the 324M remaining-pairs artifact."""

from __future__ import annotations

import csv
import hashlib
import json
import struct
from pathlib import Path

from query_324M_remaining_pairs import RemainingPairs


RUN_DIR = Path(__file__).resolve().parent
BITSET_PATH = RUN_DIR / "324M_remaining_pairs.bitset"
ROWS_PATH = RUN_DIR / "324M_remaining_pairs_by_source.csv"
EQUATIONS_PATH = RUN_DIR / "order5_equations.csv"
MANIFEST_PATH = RUN_DIR / "manifest.json"
EXPECTED_REMAINING = 324_157_667


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    with RemainingPairs(BITSET_PATH) as pairs:
        total = 0
        active = 0
        with ROWS_PATH.open(newline="", encoding="utf-8") as rows_handle:
            rows = csv.DictReader(rows_handle)
            for expected_source, row in enumerate(rows, start=1):
                if int(row["source_equation_id"]) != expected_source:
                    raise ValueError("source equation sequence drift")
                expected_offset = pairs.row_offset(expected_source)
                if int(row["bitmap_offset_bytes"]) != expected_offset:
                    raise ValueError("row offset drift")
                observed_count = pairs.target_count(expected_source)
                stated_count = int(row["remaining_target_count"])
                if observed_count != stated_count:
                    raise ValueError(
                        f"row popcount drift for Equation{expected_source}"
                    )
                if pairs.contains(expected_source, expected_source):
                    raise ValueError(
                        f"diagonal bit set for Equation{expected_source}"
                    )
                partition = (
                    int(row["fin23_covered_target_count"])
                    + int(row["singleton_true_target_count"])
                    + stated_count
                )
                if partition != pairs.equation_count - 1:
                    raise ValueError(
                        f"row partition drift for Equation{expected_source}"
                    )
                if int(row["is_active_source"]) != (stated_count > 0):
                    raise ValueError("active-source flag drift")
                total += observed_count
                active += observed_count > 0
            if expected_source != pairs.equation_count:
                raise ValueError("row CSV length drift")
        if total != EXPECTED_REMAINING:
            raise ValueError(f"global popcount drift: {total}")
        if total != pairs.remaining_count:
            raise ValueError("header remaining count drift")
        if active != manifest["partition"]["active_source_count"]:
            raise ValueError("active source count drift")

    with EQUATIONS_PATH.open(newline="", encoding="utf-8") as handle:
        equation_rows = list(csv.DictReader(handle))
    if len(equation_rows) != 62_576:
        raise ValueError("equation CSV length drift")
    if [int(row["equation_id"]) for row in equation_rows] != list(
        range(1, 62_577)
    ):
        raise ValueError("equation id sequence drift")

    for filename, metadata in manifest["outputs"].items():
        path = RUN_DIR / filename
        if path.stat().st_size != metadata["bytes"]:
            raise ValueError(f"size drift for {filename}")
        if sha256(path) != metadata["sha256"]:
            raise ValueError(f"sha256 drift for {filename}")

    print(
        json.dumps(
            {
                "status": "ok",
                "remaining_pairs": total,
                "active_sources": active,
                "equations": len(equation_rows),
                "outputs_verified": len(manifest["outputs"]),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
