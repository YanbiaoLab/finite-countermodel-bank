#!/usr/bin/env python
"""Deduplicate D17 coverage of the 284M set in fixed coverage-rank order."""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path


RUN_DIR = Path(__file__).resolve().parent
REPO_ROOT = RUN_DIR.parents[4]
REFERENCE_DIR = (
    REPO_ROOT
    / "members/wubing/artifacts/runs/"
    "d17-finite-model-324m-pair-coverage-20260818"
)
REFERENCE_SCRIPT = (
    REFERENCE_DIR / "compute_324m_deduplicated_pair_coverage.py"
)


def _load_reference():
    spec = importlib.util.spec_from_file_location(
        "d17_284m_deduplicated_reference", REFERENCE_SCRIPT
    )
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {REFERENCE_SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_base = _load_reference()


def _configure() -> None:
    values = {
        "RUN_DIR": RUN_DIR,
        "INDIVIDUAL_SCRIPT": RUN_DIR / "compute_284m_model_pair_coverage.py",
        "INDIVIDUAL_CSV": RUN_DIR / "model_284m_pair_coverage.csv",
        "INDIVIDUAL_MANIFEST": RUN_DIR / "manifest.json",
        "OUTPUT_NAME": "model_284m_pair_coverage_deduplicated.csv",
        "MANIFEST_NAME": "deduplicated_manifest.json",
    }
    for name, value in values.items():
        setattr(_base, name, value)
        globals()[name] = value
    _base.__file__ = __file__


_configure()
for _name in dir(_base):
    if not _name.startswith("__") and _name not in globals():
        globals()[_name] = getattr(_base, _name)


def _rename_coverage_fraction_keys(value):
    if isinstance(value, dict):
        return {
            key.replace("324m", "284m"): _rename_coverage_fraction_keys(item)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_rename_coverage_fraction_keys(item) for item in value]
    return value


def _output_dir_from_argv() -> Path:
    for index, argument in enumerate(sys.argv):
        if argument == "--output-dir" and index + 1 < len(sys.argv):
            return Path(sys.argv[index + 1])
        if argument.startswith("--output-dir="):
            return Path(argument.split("=", 1)[1])
    return RUN_DIR


def _finalize(output_dir: Path) -> dict:
    output_path = output_dir / OUTPUT_NAME
    text = output_path.read_text(encoding="utf-8")
    output_path.write_text(
        text.replace("fraction_of_324m", "fraction_of_284m"),
        encoding="utf-8",
    )

    manifest_path = output_dir / MANIFEST_NAME
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["schema"] = (
        "d17-finite-model-284m-deduplicated-pair-coverage-v1"
    )
    manifest["coverage_definition"] = (
        "the per-model intersection with the 284M remaining-pair universe"
    )
    manifest["deduplication_order"] = (
        "coverage_rank from model_284m_pair_coverage.csv; "
        "remaining_pair_coverage_count descending, model_index ascending"
    )
    manifest["implementation"]["working_memory_design"] = (
        "packed satisfaction profiles, source-to-rank inverted index, and "
        "one 7824-byte source row with one 7824-byte covered row; no pair "
        "expansion and no full 284M bitset in memory"
    )
    manifest["summary"] = _rename_coverage_fraction_keys(
        manifest["summary"]
    )
    manifest["output"]["sha256"] = _base.load_module(
        "d17_284m_hash", INDIVIDUAL_SCRIPT
    ).sha256(output_path)
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return manifest


def main() -> None:
    _configure()
    output_dir = _output_dir_from_argv()
    _base.main()
    print(json.dumps(_finalize(output_dir), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
