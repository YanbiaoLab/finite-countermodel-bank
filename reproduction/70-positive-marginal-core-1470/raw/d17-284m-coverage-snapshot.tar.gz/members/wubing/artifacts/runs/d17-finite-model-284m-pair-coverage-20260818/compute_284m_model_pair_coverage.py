#!/usr/bin/env python
"""Compute each frozen D17 finite model's exact coverage of the 284M set."""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path


RUN_DIR = Path(__file__).resolve().parent
REPO_ROOT = RUN_DIR.parents[4]
REFERENCE_DIR = (
    REPO_ROOT
    / "members/wubing/artifacts/runs/"
    "d17-finite-model-324m-pair-coverage-20260818"
)
REFERENCE_SCRIPT = REFERENCE_DIR / "compute_324m_model_pair_coverage.py"


def _load_reference():
    spec = importlib.util.spec_from_file_location(
        "d17_284m_individual_reference", REFERENCE_SCRIPT
    )
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {REFERENCE_SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_base = _load_reference()


def _configure() -> None:
    values = {
        "RUN_DIR": RUN_DIR,
        "BITSET_DIR": REPO_ROOT / "members/wubing/data/284M_remaining_pairs",
        "BITSET_PATH": (
            REPO_ROOT
            / "members/wubing/data/284M_remaining_pairs/"
            "284M_remaining_pairs.bitset"
        ),
        "BITSET_MANIFEST_PATH": (
            REPO_ROOT
            / "members/wubing/data/284M_remaining_pairs/manifest.json"
        ),
        "OUTPUT_NAME": "model_284m_pair_coverage.csv",
        "MANIFEST_NAME": "manifest.json",
        "REMAINING_PAIR_COUNT": 284_151_591,
    }
    for name, value in values.items():
        setattr(_base, name, value)
        globals()[name] = value
    _base.__file__ = __file__


_configure()
for _name in dir(_base):
    if not _name.startswith("__") and _name not in globals():
        globals()[_name] = getattr(_base, _name)


def _output_dir_from_argv() -> Path:
    for index, argument in enumerate(sys.argv):
        if argument == "--output-dir" and index + 1 < len(sys.argv):
            return Path(sys.argv[index + 1])
        if argument.startswith("--output-dir="):
            return Path(argument.split("=", 1)[1])
    return RUN_DIR


def _finalize(output_dir: Path) -> dict:
    output_path = output_dir / OUTPUT_NAME
    text = output_path.read_text(encoding="utf-8")
    output_path.write_text(
        text.replace("_324m", "_284m"),
        encoding="utf-8",
    )

    manifest_path = output_dir / MANIFEST_NAME
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["schema"] = "d17-finite-model-284m-individual-pair-coverage-v1"
    manifest["deduplication_scope"] = (
        "none across models; each row is one model's individual intersection "
        "with the 284M remaining-pair universe"
    )
    manifest["implementation"]["working_memory_design"] = (
        "one sequential 7824-byte remaining-pair row buffer, packed model "
        "satisfaction profiles, and a source-to-model inverted index; no "
        "284M-row pair expansion and no 467 MiB in-memory bitset"
    )
    top = manifest["summary"]["top_model"]
    top["fraction_of_284m_remaining_pairs"] = top.pop(
        "fraction_of_324m_remaining_pairs"
    )
    manifest["output"]["sha256"] = _base.sha256(output_path)
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return manifest


def main() -> None:
    _configure()
    output_dir = _output_dir_from_argv()
    _base.main()
    print(json.dumps(_finalize(output_dir), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
