# D17 finite-model × order5-law counts

This run evaluates every frozen finite table model in
`solvers/false/20260812_d17_fix/solver.py` against every one of the 62,576
laws in `third_party/equational_theories/data/eq_size5.txt`.

For a law to be counted as satisfied, both sides must evaluate equally under
every assignment of the law's variables. A single unequal assignment refutes
the law in that model. The deterministic probes in `evaluator.c` only find
early counterexamples; every surviving law is still checked exhaustively, so
the counts are exact rather than sampled estimates.

## Outputs

- `model_order5_law_counts.csv`: one row per `model_index`, including the
  carrier order, canonical table SHA-256, satisfied/refuted counts, and the
  number of assignments examined.
- `manifest.json`: frozen input/output hashes, run time, and aggregate checks.
- `compute_counts.py` and `evaluator.c`: reproducible single-process scanner.

All 3,535 rows satisfy
`satisfied_count + refuted_count = 62,576`. The minimum satisfied count is 3,
the maximum is 9,986, and the sum across all models is 2,295,615.

## Deduplicated directed-pair coverage

`model_order5_pair_coverage_deduplicated.csv` ranks models by
`satisfied_count` descending and then `model_index` ascending. A model covers
the directed pairs `S × R`, where `S` is its set of satisfied laws and `R` is
its set of refuted laws.

- `raw_pair_count` is `satisfied_count * refuted_count`.
- `new_unique_pair_count` removes every pair covered by an earlier-ranked
  model.
- `overlap_pair_count` is the current model's already-covered pair count.
- `cumulative_unique_pair_count` is the exact union size through that rank.
- `new_satisfied_equation_count` and `new_refuted_equation_count` separately
  show laws first encountered on each side. They are diagnostic fields and
  must not be multiplied to obtain unique pair coverage.

The first model (`model_index=1424`) covers 525,163,740 pairs. Across all
models, the union contains 1,492,914,319 of the 3,915,693,200 possible
distinct directed pairs (38.1264%). Of the 3,535 models, 2,939 add at least
one new pair and 596 are pair-coverage redundant under this ordering.
