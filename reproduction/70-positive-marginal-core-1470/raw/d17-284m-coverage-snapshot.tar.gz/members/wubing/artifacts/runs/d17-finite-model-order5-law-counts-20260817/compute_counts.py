#!/usr/bin/env python
"""Compute exact order5-law counts for the frozen D17 finite-model bank."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import struct
import subprocess
import tempfile
import time
from pathlib import Path


RUN_DIR = Path(__file__).resolve().parent
REPO_ROOT = RUN_DIR.parents[4]
SOLVER_PATH = REPO_ROOT / "solvers/false/20260812_d17_fix/solver.py"
EQUATIONS_PATH = (
    REPO_ROOT / "third_party/equational_theories/data/eq_size5.txt"
)
EVALUATOR_SOURCE = RUN_DIR / "evaluator.c"
OUTPUT_CSV = RUN_DIR / "model_order5_law_counts.csv"
MANIFEST_PATH = RUN_DIR / "manifest.json"
OP_TOKEN = 255


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def display_path(path: Path) -> str:
    try:
        return str(path.resolve().relative_to(REPO_ROOT))
    except ValueError:
        return str(path.resolve())


def load_solver():
    spec = importlib.util.spec_from_file_location("d17_fix_solver", SOLVER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {SOLVER_PATH}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def postfix(term) -> bytes:
    if type(term) is int:
        return bytes([term])
    return postfix(term[0]) + postfix(term[1]) + bytes([OP_TOKEN])


def model_sha256(table) -> str:
    canonical = json.dumps(
        table, ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def write_input(path: Path, equations, tables) -> None:
    with path.open("wb") as handle:
        handle.write(b"O5FMC01\0")
        handle.write(struct.pack("<II", len(equations), len(tables)))
        for variables, lhs, rhs in equations:
            left = postfix(lhs)
            right = postfix(rhs)
            handle.write(bytes([len(variables), len(left), len(right)]))
            handle.write(left)
            handle.write(right)
        for model_index, table in tables:
            if model_index >= 2**32:
                raise ValueError("model index does not fit input format")
            order = len(table)
            handle.write(bytes([order]))
            handle.write(bytes(value for row in table for value in row))


def enrich_csv(raw_path: Path, output_path: Path, tables) -> None:
    with raw_path.open(newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        with output_path.open("w", newline="", encoding="utf-8") as destination:
            fieldnames = [
                "model_index",
                "order",
                "model_sha256",
                "satisfied_count",
                "refuted_count",
                "assignments_checked",
            ]
            writer = csv.DictWriter(destination, fieldnames=fieldnames)
            writer.writeheader()
            for row, (model_index, table) in zip(reader, tables, strict=True):
                if int(row["model_index"]) != model_index:
                    raise ValueError("raw evaluator model-index drift")
                row["model_sha256"] = model_sha256(table)
                writer.writerow({field: row[field] for field in fieldnames})


def validate_csv(path: Path, tables, equation_count: int) -> dict:
    rows = []
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            rows.append(
                {
                    key: value if key == "model_sha256" else int(value)
                    for key, value in row.items()
                }
            )
    if len(rows) != len(tables):
        raise ValueError(f"expected {len(tables)} rows, found {len(rows)}")
    for expected, (model_index, table) in zip(rows, tables):
        if expected["model_index"] != model_index or expected["order"] != len(table):
            raise ValueError("model identity/order drift")
        if expected["model_sha256"] != model_sha256(table):
            raise ValueError("model hash drift")
        if expected["satisfied_count"] + expected["refuted_count"] != equation_count:
            raise ValueError("law-count partition drift")
    return {
        "models": len(rows),
        "equations": equation_count,
        "satisfied_min": min(row["satisfied_count"] for row in rows),
        "satisfied_max": max(row["satisfied_count"] for row in rows),
        "satisfied_sum": sum(row["satisfied_count"] for row in rows),
        "assignments_checked_sum": sum(row["assignments_checked"] for row in rows),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit-models", type=int)
    parser.add_argument("--output", type=Path, default=OUTPUT_CSV)
    args = parser.parse_args()

    solver = load_solver()
    equation_texts = [
        line.strip()
        for line in EQUATIONS_PATH.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    equations = [
        solver._parse_equation(text.replace("◇", "*")) for text in equation_texts
    ]
    tables = list(solver._tables())
    if args.limit_models is not None:
        tables = tables[: args.limit_models]

    args.output.parent.mkdir(parents=True, exist_ok=True)
    started = time.time()
    with tempfile.TemporaryDirectory(prefix="d17-o5-counts-") as temporary:
        temporary_dir = Path(temporary)
        input_path = temporary_dir / "input.bin"
        executable_path = temporary_dir / "evaluator"
        raw_output_path = temporary_dir / "raw-counts.csv"
        write_input(input_path, equations, tables)
        subprocess.run(
            [
                "clang",
                "-O3",
                "-std=c11",
                str(EVALUATOR_SOURCE),
                "-o",
                str(executable_path),
            ],
            check=True,
        )
        with raw_output_path.open("w", encoding="utf-8", newline="") as output:
            subprocess.run(
                [str(executable_path), str(input_path)], stdout=output, check=True
            )
        enrich_csv(raw_output_path, args.output, tables)

    summary = validate_csv(args.output, tables, len(equations))
    finished = time.time()
    manifest = {
        "schema": "d17-finite-model-order5-law-counts-v1",
        "solver_path": str(SOLVER_PATH.relative_to(REPO_ROOT)),
        "solver_sha256": sha256(SOLVER_PATH),
        "equations_path": str(EQUATIONS_PATH.relative_to(REPO_ROOT)),
        "equations_sha256": sha256(EQUATIONS_PATH),
        "output_path": display_path(args.output),
        "output_sha256": sha256(args.output),
        "started_unix": started,
        "finished_unix": finished,
        "elapsed_seconds": finished - started,
        "summary": summary,
        "exactness": (
            "32 deterministic probes followed by exhaustive verification of survivors"
        ),
    }
    MANIFEST_PATH.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
