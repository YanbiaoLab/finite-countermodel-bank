#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CODE 16
#define MAX_ARITY 7
#define OP_TOKEN 255
#define PREFILTER_SAMPLES 32

typedef struct {
  uint8_t arity;
  uint8_t lhs_len;
  uint8_t rhs_len;
  uint8_t lhs[MAX_CODE];
  uint8_t rhs[MAX_CODE];
} Equation;

static void die(const char *message) {
  fprintf(stderr, "%s\n", message);
  exit(2);
}

static uint32_t read_u32(FILE *input) {
  uint8_t bytes[4];
  if (fread(bytes, 1, 4, input) != 4) die("unexpected end of input");
  return (uint32_t)bytes[0] | ((uint32_t)bytes[1] << 8) |
         ((uint32_t)bytes[2] << 16) | ((uint32_t)bytes[3] << 24);
}

static uint8_t read_u8(FILE *input) {
  int value = fgetc(input);
  if (value == EOF) die("unexpected end of input");
  return (uint8_t)value;
}

static uint64_t splitmix64(uint64_t value) {
  value += UINT64_C(0x9e3779b97f4a7c15);
  value = (value ^ (value >> 30)) * UINT64_C(0xbf58476d1ce4e5b9);
  value = (value ^ (value >> 27)) * UINT64_C(0x94d049bb133111eb);
  return value ^ (value >> 31);
}

static uint8_t eval_term(const uint8_t *code, uint8_t code_len,
                         const uint8_t *values, const uint8_t *table,
                         uint8_t order) {
  uint8_t stack[MAX_CODE];
  uint8_t top = 0;
  for (uint8_t index = 0; index < code_len; ++index) {
    uint8_t token = code[index];
    if (token != OP_TOKEN) {
      stack[top++] = values[token];
    } else {
      uint8_t right = stack[--top];
      uint8_t left = stack[--top];
      stack[top++] = table[(size_t)left * order + right];
    }
  }
  return stack[0];
}

static void decode_assignment(uint64_t index, uint8_t order, uint8_t arity,
                              uint8_t *values) {
  for (uint8_t variable = 0; variable < arity; ++variable) {
    values[variable] = (uint8_t)(index % order);
    index /= order;
  }
}

static int assignment_holds(const Equation *equation, const uint8_t *values,
                            const uint8_t *table, uint8_t order) {
  return eval_term(equation->lhs, equation->lhs_len, values, table, order) ==
         eval_term(equation->rhs, equation->rhs_len, values, table, order);
}

static int equation_holds(const Equation *equation, const uint8_t *table,
                          uint8_t order, uint32_t model_index,
                          uint32_t equation_index, uint64_t *checked) {
  uint64_t total = 1;
  uint8_t values[MAX_ARITY];
  for (uint8_t variable = 0; variable < equation->arity; ++variable) {
    total *= order;
  }

  /* Deterministic dispersed probes only change the search order. Any law that
     survives them is still checked exhaustively below. */
  uint64_t seed = ((uint64_t)model_index << 32) ^ equation_index;
  for (uint32_t sample = 0; sample < PREFILTER_SAMPLES; ++sample) {
    uint64_t assignment = splitmix64(seed + sample) % total;
    decode_assignment(assignment, order, equation->arity, values);
    ++*checked;
    if (!assignment_holds(equation, values, table, order)) return 0;
  }

  for (uint64_t assignment = 0; assignment < total; ++assignment) {
    decode_assignment(assignment, order, equation->arity, values);
    ++*checked;
    if (!assignment_holds(equation, values, table, order)) return 0;
  }
  return 1;
}

int main(int argc, char **argv) {
  if (argc != 2) die("usage: evaluator INPUT.bin");
  FILE *input = fopen(argv[1], "rb");
  if (!input) die("cannot open input");
  char magic[8];
  if (fread(magic, 1, 8, input) != 8 || memcmp(magic, "O5FMC01\0", 8) != 0) {
    die("invalid input magic");
  }
  uint32_t equation_count = read_u32(input);
  uint32_t model_count = read_u32(input);
  Equation *equations = calloc(equation_count, sizeof(Equation));
  if (!equations) die("cannot allocate equations");
  for (uint32_t index = 0; index < equation_count; ++index) {
    Equation *equation = &equations[index];
    equation->arity = read_u8(input);
    equation->lhs_len = read_u8(input);
    equation->rhs_len = read_u8(input);
    if (equation->arity > MAX_ARITY || equation->lhs_len > MAX_CODE ||
        equation->rhs_len > MAX_CODE) die("equation exceeds compiled limits");
    if (fread(equation->lhs, 1, equation->lhs_len, input) != equation->lhs_len ||
        fread(equation->rhs, 1, equation->rhs_len, input) != equation->rhs_len) {
      die("truncated equation payload");
    }
  }

  puts("model_index,order,satisfied_count,refuted_count,assignments_checked");
  for (uint32_t model_index = 0; model_index < model_count; ++model_index) {
    uint8_t order = read_u8(input);
    size_t table_size = (size_t)order * order;
    uint8_t *table = malloc(table_size);
    if (!table || fread(table, 1, table_size, input) != table_size) {
      die("truncated model payload");
    }
    uint32_t satisfied = 0;
    uint64_t checked = 0;
    for (uint32_t equation_index = 0; equation_index < equation_count;
         ++equation_index) {
      satisfied += equation_holds(&equations[equation_index], table, order,
                                  model_index, equation_index, &checked);
    }
    printf("%u,%u,%u,%u,%" PRIu64 "\n", model_index, order, satisfied,
           equation_count - satisfied, checked);
    fflush(stdout);
    free(table);
  }
  if (fgetc(input) != EOF) die("trailing input bytes");
  fclose(input);
  free(equations);
  return 0;
}
